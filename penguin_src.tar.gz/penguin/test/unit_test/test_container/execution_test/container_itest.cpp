/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"

#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "ac_framework.h"

#include "ac_nb_bdb.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_manager.h"
#include "ac_execution.h"
#include "anchor_implementation.h"
#include "container_implementation.h"
#include "access_implementation.h"
#include "ac_cont_test_helper.h"
#include "obj_impl_decl_compound.h"
#include "obj_impl_exec_impl.h"
#include "obj_impl_exec_obj_func.h"
#include "obj_impl_container_def.h"
#include "obj_impl_string.h"
#include "obj_impl_descriptor.h"
#include "obj_impl_interface_compound.h"
#include "obj_impl_user.h"

// ******************************* defination *********************************//
static ac_id_t g_ac_object_acid = 0;

enum impl_graph_define_t
{
    GRAPH_NODE_INT,
    GRAPH_NODE_BOOL,
	GRAPH_NODE_FLOAT,
    GRAPH_NODE_STRING,
    GRAPH_NODE_USER,
	//
	GRAPH_NODE_MIX, /* mixed nodes */
};
static impl_graph_define_t IMPL_GRAPH_DEFINE;

// ******************************* utilities *********************************//

/* simply create a node_path_t struct */
node_path_t create_path(int in_node, int in_port, int out_node, int out_port)
{	
	node_path_t path;
	path.in_node = in_node;
	path.in_port = in_port;
	path.out_node = out_node;
	path.out_port = out_port;
	return path;
}

bool generate_out_path_info(exec_impl_graph_t& impl_data)
{
	int node_size = impl_data.nodes.size();
	assert(node_size>0);
	int path_size = impl_data.paths.size();
	assert(path_size>0);

	impl_data.out_paths.clear();
	for(int node_index = 0 ; node_index < node_size ; ++node_index)
	{
		out_port_path_idx_t out_path_info;
		out_path_info.out_port = 1;/* TODO */
		// push all of a node's out_path
		for(int path_index = 0 ; path_index < path_size ; ++path_index)
		{
			if(impl_data.paths[path_index].in_node == node_index)
				out_path_info.path_idxs.push_back(path_index);
		}
		impl_data.out_paths.push_back(out_path_info);
	}

	/* another algorithm,but still need some modification */
	/*
	impl_data.out_paths.resize(node_size);
	for(int path_index = 0 ; path_index < path_size ; ++path_index)
	{
		int node_index = impl_data.paths[path_index].in_node;
		if(node_index >= 0)
			impl_data.out_paths.path_idxs.push_back(path_index);
	}*/

	return true;
}

// ******************************* handles *********************************//
nb_id_t generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id)
{
	request_nb_id_info exec_info;
    exec_info.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
    exec_info.committer_id = hc_id;

	/* build obj_func_data_t */
    exec_obj_func_data_t obj_func_data;
    obj_func_data.name = "obj_func";
    obj_func_data.selected_decl = decl_id;
    obj_func_data.recoverer = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.postcut = false;
    obj_impl_exec_obj_func::pack(obj_func_data, exec_info.raw_data);
	
	/* request nb_id */
    nb_id_t exec_obj_func_id;
	ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, exec_info, exec_obj_func_id);

	return exec_obj_func_id;
}

bool generate_decl_comp(const host_committer_id_t& hc_id, nb_id_t& decl_id)
{
    decl_compound_data_t decl_data;

    // name 
    decl_data.name = "compound_declaration";

    // in ports 
    iport_t iitem;
    iitem.name = "int";
    iitem.interface = nb_id_t(NB_INTERFACE_INT);
    iitem.default_value = nb_id_t(NB_INTERFACE_INT);
    decl_data.iports.push_back(iitem);

    // out ports 
    oport_t oitem;
    oitem.name = "int";
    oitem.interface = nb_id_t(NB_INTERFACE_INT);
    decl_data.oports.push_back(oitem);

    // request declaration id
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, decl_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, decl_info, decl_id);

    return true;
}
    
bool generate_descriptor(host_committer_id_t host_committer_id, 
        const descriptor_data_t& data,
        nb_id_t& dp_id)
{
    // request defination id
    request_nb_id_info dp_info;
    dp_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
    dp_info.committer_id = host_committer_id;
    obj_impl_descriptor::pack(data, dp_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, dp_info, dp_id);

    return true;
}

bool generate_interface_compound(host_committer_id_t host_committer_id, 
        const if_compound_data_t& data,
        nb_id_t& if_id)
{
    // request defination id
    request_nb_id_info if_info;
    if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    if_info.committer_id = host_committer_id;
    obj_impl_interface_compound::pack(data, if_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, if_info, if_id);

    return true;
}

bool generate_user(host_committer_id_t host_committer_id, 
        const user_data_t& data,
        nb_id_t& user_id)
{
    request_nb_id_info user_info;
    user_info.type = NBID_TYPE_OBJECT_USER;
    user_info.committer_id = host_committer_id;
    obj_impl_user::pack(data, user_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, user_info, user_id);

    return true;
}

bool generate_impl_int(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** constants ****************//
    nb_id_t cint1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    cint1.set_value(22);
    nb_id_t cint2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    cint2.set_value(30);
	nb_id_t cint3 = nb_id_t(NBID_TYPE_OBJECT_INT);
	cint3.set_value(4);

    impl_data.constants.push_back(cint1);
    impl_data.constants.push_back(cint2);
	impl_data.constants.push_back(cint3);

  	//*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
    //************* paths *****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ int0 -> node0:add }
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ int1 -> node0:add }
	impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:add -> node1:sub } 
	impl_data.paths.push_back(create_path(-2, 2, 1, 1));//path3{ int2 -> node1:sub }
	impl_data.paths.push_back(create_path( 1, 0,-3, 0));//path4{ node1:sub -> OUT }
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_bool(const host_committer_id_t& hc_id,
		const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

    //*************** constants ****************//
    nb_id_t bTest1 = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    bTest1.set_value(true);
    nb_id_t bTest2 = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    bTest2.set_value(true);
    
    impl_data.constants.push_back(bTest1);
    impl_data.constants.push_back(bTest2);

    //*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, NB_FUNC_BOOL_AND));
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, NB_FUNC_BOOL_NOT));
    //************* paths *****************//
    impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ bool0 -> node0:and }
    impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ bool1 -> node0:and }
    impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:and -> node1:not }
    impl_data.paths.push_back(create_path( 1, 0,-3, 0));//path3{ node1:not -> OUT }
   
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

	return true;
}

bool generate_impl_float(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** constants ****************//
    nb_id_t cont1 = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    cont1.set_value(2.0f);
    nb_id_t cont2 = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    cont2.set_value(5.0f);

    impl_data.constants.push_back(cont1);
    impl_data.constants.push_back(cont2);

  	//*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_FLOAT_ADD)));

    //************* paths *****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ float0 -> node0:add }
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ float1 -> node0:add }
	impl_data.paths.push_back(create_path(0, 0, -3, 0));//path2{ node0:add -> OUT }
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_string(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   //*************** constants ****************//
    request_nb_id_info string_info;
    string_info.type = NBID_TYPE_OBJECT_STRING;
    string_info.committer_id = hc_id;

    // const0 : str
    std::string str0 = "aa aa";
    obj_impl_string::pack(str0, string_info.raw_data);
    nb_id_t const0;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const0);
    // const1 : str
    std::string str1 = "tout le monde 1.";
    obj_impl_string::pack(str1, string_info.raw_data);
    nb_id_t const1;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const1);
	// const2 : int
	nb_id_t const2(NBID_TYPE_OBJECT_INT);
	const2.set_value(3);
	// const3 : int
	nb_id_t const3(NBID_TYPE_OBJECT_INT);
	const3.set_value(8);

	impl_data.constants.push_back(const0);
    impl_data.constants.push_back(const1);
	impl_data.constants.push_back(const2);
	impl_data.constants.push_back(const3);

   	//*************** nodes ****************//
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_APPEND)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SUBSTR)));
    //*************** paths ****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//str1->[apend]
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//str2->[apend]
	impl_data.paths.push_back(create_path( 0, 0, 1, 0));//[apend]->[substr]
	impl_data.paths.push_back(create_path(-2, 2, 1, 1));//int1->[substr]
	impl_data.paths.push_back(create_path(-2, 3, 1, 2));//int2->[substr]
	impl_data.paths.push_back(create_path( 1, 0,-3, 0));//[substr]->OUT
	// 
	generate_out_path_info(impl_data);
    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_mix(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    impl_data.name = "mix nodes test";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   //*************** constants ****************//
    request_nb_id_info string_info;
    string_info.type = NBID_TYPE_OBJECT_STRING;
    string_info.committer_id = hc_id;

    // const0 : str
    std::string str0 = "Nebutown is a";
    obj_impl_string::pack(str0, string_info.raw_data);
    nb_id_t const0;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const0);
    // const1 : str
    std::string str1 = " promising company";
    obj_impl_string::pack(str1, string_info.raw_data);
    nb_id_t const1;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const1);

	impl_data.constants.push_back(const0);
    impl_data.constants.push_back(const1);

   	//*************** nodes ****************//
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_APPEND)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SIZE)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SIZE)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SIZE)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_EQ)));
    //*************** paths ****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ str1 -> node0:append }
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ str2 -> node0:append }
	impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:append -> node1:size }
	impl_data.paths.push_back(create_path(-2, 0, 2, 0));//path3{ str1 -> node2:size }
	impl_data.paths.push_back(create_path(-2, 1, 3, 0));//path4{ str2 -> node3:size }
	impl_data.paths.push_back(create_path( 2, 0, 4, 0));//path5{ node2:size -> node4:int_add }
	impl_data.paths.push_back(create_path( 3, 0, 4, 1));//path6{ node3:size -> node4:int_add }
	impl_data.paths.push_back(create_path( 1, 0, 5, 0));//path7{ node1:size -> node5:int_eq }
	impl_data.paths.push_back(create_path( 4, 0, 5, 1));//path8{ node4:int_add -> node5:int_eq }
	impl_data.paths.push_back(create_path( 5, 0,-3, 0));//path9{ node5:int_eq -> OUT }

	// generate out_path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}


bool generate_impl_user(const host_committer_id_t& host_committer_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    // name 
    impl_data.name = "user implementation";

    // out port size
    impl_data.out_port_size = 1;

    // master
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);

    // external declaration 
    impl_data.external_decl = decl_id;

    // exception
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** user constants ****************//
    // user function
    func_pair_t func_item;
    generate_decl_comp(host_committer_id, func_item.declaration_id);
    generate_impl_mix(host_committer_id, 
            func_item.declaration_id, 
            func_item.implementation_id);

    // user interface
    if_compound_data_t user_if;
    nb_id_t if_id;

    user_if.name = "user interface";
    user_if.decls.push_back(func_item.declaration_id);

    generate_interface_compound(host_committer_id, user_if, if_id);

    // user descriptor
    descriptor_data_t dp_data;
    nb_id_t dp_id;

    dp_data.name = "user descriptor";
    dp_data.funcs.push_back(func_item);
    dp_data.subobj_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));
    dp_data.subobj_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));

    generate_descriptor(host_committer_id, dp_data, dp_id);

    // user
    user_data_t user_data;
    nb_id_t user_id;

    user_data.name = "user";
    user_data.descriptor = dp_id;
    user_data.interface = if_id;

    nb_id_t sub1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    sub1.set_value(10);
    nb_id_t sub2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    sub2.set_value(20);
    user_data.subobjs.push_back(sub1);
    user_data.subobjs.push_back(sub2);

    generate_user(host_committer_id, user_data, user_id);

    impl_data.constants.push_back(user_id);

  	//*************** user nodes ****************//
    // custom function
    //impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
    //            func_item.declaration_id));

    // builtin function
    impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
                nb_id_t(NB_FUNC_USER_DECOMPOSE)));

    //impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
    //            nb_id_t(NB_FUNC_USER_COMPOSE)));

    //************* paths *****************//
	// node0
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));
	impl_data.paths.push_back(create_path(0, 0, -3, 0));

	// save all out_paths to facilitate resolve
    out_port_path_idx_t out_path0;
    out_path0.out_port = 0;
    out_path0.path_idxs.push_back(1);
    impl_data.out_paths.push_back(out_path0);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = host_committer_id;
    obj_impl_exec_impl::pack(impl_data, impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, impl_info, impl_id);

    return true;
}

bool generate_implementation(const impl_graph_define_t graph_define,
        const host_committer_id_t host_committer_id, 
        const nb_id_t& decl_id, 
        nb_id_t& impl_id)
{
    switch(graph_define)
    {
        case GRAPH_NODE_INT:
            generate_impl_int(host_committer_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_BOOL:
            generate_impl_bool(host_committer_id, decl_id, impl_id);
            break;
		case GRAPH_NODE_FLOAT:
			generate_impl_float(host_committer_id, decl_id, impl_id);
			break;
        case GRAPH_NODE_STRING:
            generate_impl_string(host_committer_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_USER:
            generate_impl_user(host_committer_id, decl_id, impl_id);
            break;
		case GRAPH_NODE_MIX:
			generate_impl_mix(host_committer_id, decl_id, impl_id);
			break;
    }
    return true;
}

bool generate_container_defination(host_committer_id_t host_committer_id, nb_id_t& cd_id)
{
    cont_def_data_t cd_data;

    // name 
    cd_data.name = "container_defination";

    // anchor info 
    anchor_info_t an_item;
    an_item.name = "int";
    an_item.registed = true;

    func_pair_t func_item;
    generate_decl_comp(host_committer_id, func_item.declaration_id);
    generate_implementation(IMPL_GRAPH_DEFINE,
            host_committer_id, 
            func_item.declaration_id, 
            func_item.implementation_id);
    an_item.funcs.push_back(func_item);
    cd_data.anchors.push_back(an_item);

    // storages 
    cd_data.storages.push_back(NBID_TYPE_STORAGE_MULTIVALUE);
    cd_data.storages.push_back(NBID_TYPE_STORAGE_SIMPLE);

    // request defination id
    request_nb_id_info cd_info;
    cd_info.type = NBID_TYPE_OBJECT_CONTAINER_DEF;
    cd_info.committer_id = host_committer_id;
    obj_impl_container_def::pack(cd_data, cd_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, cd_info, cd_id);

    return true;
}

bool generate_anchor(host_committer_id_t host_committer_id, 
        nb_id_t& decl_id, 
        anchor_id_t& anchor_id)
{
    anchor_data_t an_data;

    // name 
    an_data.name = "anchor";

    // funcs
    func_pair_t func_item;
    func_item.declaration_id = decl_id; 
    generate_implementation(IMPL_GRAPH_DEFINE,
            host_committer_id, 
            decl_id, 
            func_item.implementation_id);
    an_data.funcs.push_back(func_item);

    an_data.registed = false;
    an_data.interface = nb_id_t(NBID_TYPE_OBJECT_INTERFACE_COMPOUND);
    an_data.parent_container = container_id_t();

    // request anchor id
    request_anchor_id_info an_info;
    anchor_implementation::pack(an_data, an_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_anchor_id(host_committer_id, an_info, anchor_id);

    return true;
}

bool generate_container(host_committer_id_t host_committer_id, 
        const anchor_id_t& an_id,
        container_id_t& container_id,
        access_id_t& root_access_id)
{
    container_data_t cont_data;

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    
    // name 
    cont_data.name = "container";

    cont_data.anchors.push_back(an_id);

    request_container_id_info cont_info;
    container_implementation::pack(cont_data, container_id_t(), cont_info.raw_data);

    // generate container 
    ptrHelper->ac_host_committer_request_container_id(host_committer_id, cont_info, container_id);

    // generate root access
    access_data_t rt_ac_data;
    rt_ac_data.name = "root_access";
    rt_ac_data.parent_container = container_id;

    request_access_id_info ac_info;
    access_implementation::pack(rt_ac_data, ac_info.raw_data);

    ptrHelper->ac_host_committer_request_access_id(host_committer_id, ac_info, root_access_id);

    return true;
}

void set_param_create_container(node_invocation_request * pParam)
{
    pParam->declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER); 
    nb_id_t cd_id;
    generate_container_defination(pParam->host_committer_id, cd_id);
    pParam->input.push_back(cd_id);
}

void set_param_generate_access_from_anchor(node_invocation_request * pParam)
{
    pParam->declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR); 
    nb_id_t an_idx = nb_id_t(NBID_TYPE_OBJECT_INT);
    an_idx.set_value(0);
    pParam->input.push_back(an_idx);
}

bool root_access_run()          
{
    access_id_t root_access_id;
    container_id_t container_id;
    host_committer_id_t host_committer_id;
    anchor_id_t an_id;

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));
    ptrHelper->ac_id_dispenser_request_host_committer_id(host_committer_id);

    // generate anchor 
    nb_id_t decl_in_an;
    generate_decl_comp(host_committer_id, decl_in_an);
    generate_anchor(host_committer_id, decl_in_an, an_id);
    generate_container(host_committer_id, an_id, 
            container_id, root_access_id);

    ac_id_t dest_id;
    if(!ac_manager::instance().request_actor(root_access_id))
        return false;

    if(!ac_manager::instance().get_ac_id(root_access_id, dest_id))
        return false;

    node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
    pParam->host_committer_id = host_committer_id;
    pParam->transaction_id = transaction_id_t();
    pParam->object_id = static_cast<nb_id_t>(root_access_id);

    // create container 
    set_param_create_container(pParam);

    // generate access from anchor
    //set_param_generate_access_from_anchor(pParam);

    return ac_manager::instance().send_asyn_message(dest_id, g_ac_object_acid, 1, e_ac_access_run, pParam);
};

ac_actor * access_run()          
{
    nb_id_t decl_id;
    access_id_t root_access_id;
    container_id_t container_id;
    root_committer_id_t root_committer_id;
    center_committer_id_t center_committer_id;
    host_committer_id_t host_committer_id;
    anchor_id_t an_id;

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(g_ac_object_acid));

    // root commmitter, centre committer, host committer
    ptrHelper->ac_id_dispenser_request_root_committer_id(root_committer_id);
    ptrHelper->ac_id_dispenser_request_center_committer_id(center_committer_id);
    ptrHelper->ac_id_dispenser_request_host_committer_id(host_committer_id);

    ptrHelper->ac_root_committer_regist_center_committer(root_committer_id, 
            center_committer_id);
    ptrHelper->ac_center_committer_set_root_committer(center_committer_id, 
            root_committer_id);
    ptrHelper->ac_center_committer_regist_host_committer(center_committer_id, 
            host_committer_id);
    ptrHelper->ac_host_committer_set_center_committer(host_committer_id, 
            center_committer_id);

    // generate decl, anchor, container 
    generate_decl_comp(host_committer_id, decl_id);
    generate_anchor(host_committer_id, decl_id, an_id);
    generate_container(host_committer_id, an_id, 
            container_id, root_access_id);

    access_data_t ac_data;
    ac_data.name = "access";
    ac_data.parent_container = container_id;
    ac_data.anchor_idx = 0;

    request_access_id_info ac_info;
    content value;
    access_implementation::pack(ac_data, value);
    access_id_t access_id = access_id_t();
    ac_actor *pActor = actor_factory(access_id, value);

    node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
    pParam->host_committer_id = host_committer_id;
    pParam->transaction_id = transaction_id_t();
    pParam->declaration_id = decl_id;
    pParam->object_id = static_cast<nb_id_t>(access_id);

    ac_message_t* pMsg = ac_memory_alloctor<ac_message_t>::instance().allocate();
    pack_message(*pMsg, g_ac_object_acid, 1, e_ac_access_run, pParam);
    

    pActor->enqueue(pMsg);
     
    return pActor;
};

int main(int argc, char* argv[])
{

    nb_configuration config(argc, argv);
    config.dump_configuration();

    if (1 >= argc)
        return -1;

    std::string cmd = argv[1];

    if (cmd == "int")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_INT;
    else if (cmd == "bool")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_BOOL;
    else if (cmd == "string")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_STRING;
    else if (cmd == "float" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_FLOAT;
    else if (cmd == "user" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_USER;
	else if (cmd == "mix" )
		IMPL_GRAPH_DEFINE = GRAPH_NODE_MIX;
	else
	{
        ;
    }

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    //Start ac_framework
    ac_framework framework(config.get_actor_thread_pool(), 
                           config.get_is_statistics(), 
                           config.get_statistics_interval());
    framework.init_framework();

    framework.run();

    ///////////// message handles

    // test access run 
    //root_access_run();

    // test access run 
    ac_actor * pActor = access_run();

    ac_manager::instance().list_add_actor(pActor);    

    ///////////// message handles

    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
