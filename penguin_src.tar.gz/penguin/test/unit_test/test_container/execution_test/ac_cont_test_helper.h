/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _AC_CONT_TEST_HELPER_H_
#define _AC_CONT_TEST_HELPER_H_

#include "ac_global.h"
#include "ac_actor.h"
#include "ac_id_dispenser.h"
#include "ac_root_committer.h"
#include "ac_center_committer.h"
#include "ac_host_committer.h"

class ac_cont_test_helper : public ac_helper
{
public :
    ac_cont_test_helper(ac_id_t ac_id): ac_helper(ac_id)
    {
    };
    
    virtual ~ac_cont_test_helper()
    {
    };

    bool ac_id_dispenser_request_root_committer_id(root_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_root_committer_id(output);
        }
        return false;
    }

    bool ac_id_dispenser_request_center_committer_id(center_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_center_committer_id(output);
        }
        return false;
    }
    
    bool ac_id_dispenser_request_host_committer_id(host_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_host_committer_id(output);
        }
        return false;
    }

    bool ac_id_dispenser_request_transaction_id(const host_committer_id_t& hc_id,
                                                transaction_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_transaction_id(hc_id, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_execution_id(const request_execution_id_info& exe_info, execution_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_execution_id(exe_info, output);
        }
        return false;
    }

    bool ac_root_committer_regist_center_committer(const root_committer_id_t& id, const center_committer_id_t& input)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_root_committer* pActor = dynamic_cast<ac_root_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->regist_center_committer(input);
	}
	return false;
    } 

    bool ac_center_committer_set_root_committer(const center_committer_id_t& id, const root_committer_id_t& input)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_center_committer* pActor = dynamic_cast<ac_center_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->set_root_committer(input);
	}
	return false;
    } 

    bool ac_center_committer_regist_host_committer(const center_committer_id_t& id, const host_committer_id_t& input)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_center_committer* pActor = dynamic_cast<ac_center_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->regist_host_committer(input);
	}
	return false;
    } 

    bool ac_host_committer_set_center_committer(const host_committer_id_t& id, const center_committer_id_t& input)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->set_center_committer(input);
	}
	return false;
    } 

    bool ac_host_committer_request_nb_id(host_committer_id_t id, const request_nb_id_info& input, nb_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_nb_id(input, output);
	}
	return false;
    }; 

    bool ac_host_committer_load_object(host_committer_id_t id, const nb_id_t& input, content& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->load_object(input, output);
	}
	return false;
    }; 

    bool ac_host_committer_create_object(host_committer_id_t id, const content& input)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->create_object(input);
	}
	return false;
    }; 

    bool ac_host_committer_request_container_id(host_committer_id_t id, const request_container_id_info& input, container_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_container_id(input, output);
	}
	return false;
    }; 

    bool ac_host_committer_request_anchor_id(host_committer_id_t id, const request_anchor_id_info& input, anchor_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_anchor_id(input, output);
	}
	return false;
    }; 

    bool ac_host_committer_request_storage_id(host_committer_id_t id, storage_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_storage_id(output);
	}
	return false;
    }; 

    bool ac_host_committer_request_access_id(host_committer_id_t id, const request_access_id_info& input, access_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_access_id(input, output);
	}
	return false;
    }; 

    bool ac_host_committer_request_facade_id(host_committer_id_t id, const request_facade_id_info& input, facade_id_t& output)
    {
	ac_id_t dest_id;
	if(!ac_manager::instance().get_ac_id(id, dest_id))
	    return false;

	ac_host_committer* pActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(dest_id));
	if(pActor)
	{
	    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
	    return pActor->request_facade_id(input, output);
	}
	return false;
    }; 

};

typedef std::tr1::shared_ptr< ac_cont_test_helper>  ac_cont_test_helper_ptr;    

#endif /* _AC_CONT_TEST_HELPER_H_ */
