#include <iostream>

#include "duke_media_base.h"
#include "duke_media_object.h"
#include "duke_media_access.h"
#include "duke_media_storage.h"
#include "duke_media_anchor.h"
#include "duke_media_compound_interface.h"
int main()
{
    /*
    duke_media_handle handle;

    std::cout << handle.idtype << std::endl;

    duke_media_int hint(duke_media_handle(NBID_TYPE_OBJECT_INT));


    std::vector<duke_media_handle> vid;
    vid.push_back(NB_FUNC_GENERAL_NULL);
    vid.push_back(NB_FUNC_GENERAL_GET_NAME);
    vid.push_back(NB_FUNC_GENERAL_IS_NULL);
    vid.push_back(NB_FUNC_GENERAL_IS_SINGLETON);

    host_committer_id_t id;
    duke_media_storage st(id, "hello");
    
    std::cout << "vid size:" << vid.size() << std::endl;

*/
    anchor_id_t id;
    host_committer_id_t host_id;

    duke_media_anchor anchor(host_id);

    std::cout << anchor.get_handle().str() << std::endl;

    id.str(anchor.get_handle().str());

    std::cout << id.str() << std::endl;



    return 0;
    //std::cout << hint.get_handle().str() << std::endl;

}

// vim:set tabstop=4 shiftwidth=4 expandtab:

