
/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"
#include "nb_configuration.h"
#include "ac_framework.h"
#include "ac_fake_object.h"

int main(int argc, char* argv[])
{
    nb_configuration config(argc, argv);
    config.dump_configuration();

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    int value = 10001;
    ac_message_t msg = {g_ac_framework_acid, 1, e_ac_object_run, &value};
    for(int j = 0; j < 10; ++j)
    {
        ac_actor *pActor = new ac_fake_object();
        pActor->initialization();
        pActor->set_initialized_status();        
        ac_manager::instance().list_add_actor(pActor);    
        pActor->enqueue(&msg);
    }

    //Start ac_framework
    ac_framework framework(config.get_actor_thread_pool(), 
                           config.get_is_statistics(), 
                           config.get_statistics_interval());
    framework.init_framework();
    framework.run();
    
    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;
}
