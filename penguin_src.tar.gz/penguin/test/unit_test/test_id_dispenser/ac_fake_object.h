/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _AC_FAKE_OBJECT_H_
#define _AC_FAKE_OBJECT_H_

#include "ac_global.h"
#include "ac_actor.h"
#include "ac_id_dispenser.h"

class ac_fake_object_helper : public ac_helper
{
public :
    ac_fake_object_helper(ac_id_t ac_id): ac_helper(ac_id)
    {
    };
    
    virtual ~ac_fake_object_helper()
    {
    };

    bool ac_id_dispenser_request_root_committer_id(root_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_root_committer_id(output);
        }
        return false;
    }

    bool ac_id_dispenser_request_center_committer_id(center_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_center_committer_id(output);
        }
        return false;
    }
    
    bool ac_id_dispenser_request_host_committer_id(host_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_host_committer_id(output);
        }
        return false;
    }

    bool ac_id_dispenser_request_storage_id(storage_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_storage_id(output);
        }
        return false;
    }

    bool ac_id_dispenser_request_anchor_id(request_anchor_id_info anchor_info, anchor_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_anchor_id(anchor_info, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_nb_id(const request_nb_id_info& req_info, nb_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_nb_id(req_info, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_transaction_id(const host_committer_id_t& hc_id,
                                                transaction_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_transaction_id(hc_id, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_facade_id(const request_facade_id_info& facade_info, facade_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_facade_id(facade_info, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_execution_id(const request_execution_id_info& exe_info, execution_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_execution_id(exe_info, output);
        }
        return false;
    }

    bool ac_id_dispenser_request_access_id(const request_access_id_info& access_info, access_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor
            = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_access_id(access_info, output);
        }
        return false;
    }
    
    bool ac_fake_object_run_respond(call_id_t call_id, int& output)
    {
#ifdef _NB_64_PLATFORM_
        LOG_FORMAT("ac_fake_object(%lu) start run_respond with output(%d) to ac_fake_object(%lu).",
                   m_ac_id, output, call_id.ac_id);
#else
        LOG_FORMAT("ac_fake_object(%x) start run_respond with output(%d) to ac_fake_object(%x).",
                   m_ac_id, output, call_id.ac_id);
#endif

        int* pData = ac_memory_alloctor<int>::instance().allocate();
    
        *pData = output;
        return ac_manager::instance().send_asyn_message(call_id.ac_id, m_ac_id, call_id.req_num, e_ac_object_run_response, pData);
    }
};

typedef std::tr1::shared_ptr< ac_fake_object_helper>  ac_fake_object_helper_ptr;    

class ac_fake_object : public ac_actor
{
private :
    virtual bool message_handle(const ac_message_t& message)
    {
        ac_actor::message_handle(message);
        switch(message.type)
        {
            case e_ac_actor_exception : 
            {
                std::string* pData = reinterpret_cast<std::string*>(message.data);
                if(pData)
                    return exception_handle(message.req_num, *pData);
                break;
            }
            case e_ac_object_run :
            {
                call_id_t call_id = {message.ac_id, message.req_num};
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return run(call_id, *pData);
                break;
            }
            default : 
            {
                std::cout<<"the message type isn't support by this actor."<<std::endl;
                break;
            }
        }
        return false;
    };
    
    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        ac_actor::exception_handle(req_num, str);
        return true;        
    }
    
    bool run(call_id_t call_id, const int& input)
    {
#ifdef _NB_64_PLATFORM_
        LOG_FORMAT("ac_fake_object(%lu) is executing run...........", m_ac_id);
#else
        LOG_FORMAT("ac_fake_object(%x) is executing run..........", m_ac_id);
#endif

        root_committer_id_t rc_id;
        m_ptrHelper->ac_id_dispenser_request_root_committer_id(rc_id);
        LOG_FORMAT("get new root committer id = %s", rc_id.str().c_str());

        center_committer_id_t cc_id;
        m_ptrHelper->ac_id_dispenser_request_center_committer_id(cc_id);
        LOG_FORMAT("get new center committer id = %s", cc_id.str().c_str());        

        host_committer_id_t hc_id;
        m_ptrHelper->ac_id_dispenser_request_host_committer_id(hc_id);
        LOG_FORMAT("get new host committer id = %s", hc_id.str().c_str());        

        storage_id_t storage_id;
        m_ptrHelper->ac_id_dispenser_request_storage_id(storage_id);
        LOG_FORMAT("get new storage id = %s", storage_id.str().c_str());        

        anchor_id_t anchor_id;
        request_anchor_id_info anchor_info;
        m_ptrHelper->ac_id_dispenser_request_anchor_id(anchor_info, anchor_id);
        LOG_FORMAT("get new anchor id = %s", anchor_id.str().c_str());        

        for(int i = 0 ; i < 10; ++i)
        {
            nb_id_t nb_id;
            request_nb_id_info req_info;
            req_info.type = 1;
            req_info.committer_id = hc_id;
            m_ptrHelper->ac_id_dispenser_request_nb_id(req_info, nb_id);
            LOG_FORMAT("get new nb id:     %s using host committer id = %s",
                       nb_id.str().c_str(), hc_id.str().c_str());

            transaction_id_t trans_id;
            m_ptrHelper->ac_id_dispenser_request_transaction_id(hc_id, trans_id);
            LOG_FORMAT("get new trans id:  %s using host committer id = %s",
                       trans_id.str().c_str(), hc_id.str().c_str());

            facade_id_t facade_id;
            request_facade_id_info facade_info;
            facade_info.committer_id = hc_id;
            m_ptrHelper->ac_id_dispenser_request_facade_id(facade_info, facade_id);
            LOG_FORMAT("get new facade id: %s using host committer id = %s",
                       facade_id.str().c_str(), hc_id.str().c_str());

            execution_id_t exe_id;
            request_execution_id_info exe_info;
            exe_info.committer_id = hc_id;
            m_ptrHelper->ac_id_dispenser_request_execution_id(exe_info, exe_id);
            LOG_FORMAT("get new exe id:    %s using host committer id = %s",
                       exe_id.str().c_str(), hc_id.str().c_str());

            access_id_t access_id;
            request_access_id_info access_info;
            access_info.type = 1;
            access_info.committer_id = hc_id;

            m_ptrHelper->ac_id_dispenser_request_access_id(access_info, access_id);
            LOG_FORMAT("get new access id: %s using host committer id = %s",
                       access_id.str().c_str(), hc_id.str().c_str());
        }
        
        return true;
    }    

public :
    ac_fake_object(): ac_actor(e_ac_bridge), m_ptrHelper(new(std::nothrow) ac_fake_object_helper(m_ac_id)) 
    {
         m_actor_name = "ac_fake_object";
    }; 
    virtual ~ac_fake_object()
    {
    };
    
private :
    ac_fake_object_helper_ptr m_ptrHelper;
}; 

#endif /* _AC_FAKE_OBJECT_H_ */
