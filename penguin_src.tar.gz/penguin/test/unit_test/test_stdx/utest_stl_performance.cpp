#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>

#include <vector>
#include <map>
#include <list>
#include <stack>
#include <iostream>
#include <iomanip>

//#include <boost/array.hpp>
#include <boost/progress.hpp>

struct id128_t
{
    int32_t data[4];
};

int main(int argc, char* argv[])
{
    // assert we defined id128_t is 128-bit
    assert(sizeof(id128_t) == 16);

    int INSERT_NUM;
    std::cout << "Please input the num of push/insert operations : ";
    std::cin >> INSERT_NUM;
    std::cout << std::endl;
 

    // stack push
    std::cout << "std::stack push() : " << std::endl;
    {
        //boost::progress_timer tm;
        boost::progress_timer tm;
        std::stack<id128_t>* pStk = new std::stack<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pStk->push(id128_t());
        delete pStk;    
    }
    std::cout << std::endl;



    // list push_back
    std::cout << "std::list push_back() : " << std::endl;
    {
        boost::progress_timer tm;
        std::list<id128_t>* pList = new std::list<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pList->push_back(id128_t());
        delete pList;
    }
    std::cout << std::endl;

   // vector push_back
    std::cout << "std::vector push_back() : " << std::endl; 
    {
        boost::progress_timer tm;
        std::vector<id128_t>* pVec = new std::vector<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pVec->push_back(id128_t());
        delete pVec;
    }
    
    std::cout << std::endl;

    // map insert
    std::cout << "std::map insert(x) : " << std::endl;
  
    {
        boost::progress_timer tm;
        std::map<int, id128_t>* pMap = new std::map<int, id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pMap->insert(std::make_pair(i, id128_t()));
        delete pMap;
    }

    std::cout << std::endl;

    // map insert back
    std::cout << "std::map insert(end, x) : " << std::endl;
    {
        boost::progress_timer tm;
        std::map<int, id128_t>* pMap = new std::map<int, id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pMap->insert(pMap->end(), std::make_pair(i, id128_t()));
        delete pMap;
    }
    std::cout << std::endl;

    // raw mem operations 
    std::cout << "malloc once : " << std::endl;
    {
        boost::progress_timer tm;
        id128_t* pMem = (id128_t*)malloc(sizeof(id128_t ) * INSERT_NUM);
        for(int i=0; i < INSERT_NUM; ++i)
            pMem[i] = id128_t();
        free(pMem);
    }
    std::cout << std::endl;

    // vector reserve first
    std::cout << "std::vector push_back() after reserve(NUM)" << std::endl;
    {
        boost::progress_timer tm;
        std::vector<id128_t>* pVec = new std::vector<id128_t>();
        pVec->reserve(INSERT_NUM);
        for(int i=0; i < INSERT_NUM; ++i)
            pVec->push_back(id128_t());
        delete pVec;

    }
    std::cout << std::endl;
    
    // boost::array 
    //std::cout << "boost::array : " << std::endl;
    //{
    //    boost::progress_timer tm;
    //    boost::array<id128_t, 100000> arr;
    //    for(int i = 0; i < INSERT_NUM; ++i)
    //        arr[i] = id128_t();
    //}
    //std::cout << std::endl;
        
}
    
