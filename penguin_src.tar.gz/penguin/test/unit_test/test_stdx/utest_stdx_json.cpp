#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include <iostream>

#include "stdx/stdx_json.h"

using namespace stdx;

void test_json_string()
{
    json_node *node = new json_string("hello");
    std::cout << "json_string=" << node->get_string() << std::endl;
    std::cout << "json_string.to_string()=" << node->to_json_string() << std::endl;
    delete node;

    node = new json_string("");
    std::cout << "json_string=" << node->get_string() << std::endl;
    std::cout << "json_string.to_string()=" << node->to_json_string() << std::endl;
    delete node;

    node = new json_string("\t");
    std::cout << "json_string=" << node->get_string() << std::endl;
    std::cout << "json_string.to_string()=" << node->to_json_string() << std::endl;
    delete node;

    node = new json_string("\\");
    std::cout << "json_string=" << node->get_string() << std::endl;
    std::cout << "json_string.to_string()=" << node->to_json_string() << std::endl;
    delete node;

    node = new json_string("hello\0world");
    std::cout << "json_string=" << node->get_string() << std::endl;
    std::cout << "json_string.to_string()=" << node->to_json_string() << std::endl;
    delete node;
}

void test_json_int()
{
    json_node *node = new json_int(9);
    std::cout << "json_int=" << node->get_int() << std::endl;
    std::cout << "json_int.to_string()=" << node->to_json_string() << std::endl;
    delete node;
}

void test_json_double()
{
    json_node *node = new json_double(9.9);
    std::cout << "json_double=" << node->get_double() << std::endl;
    std::cout << "json_double.to_string()=" << node->to_json_string() << std::endl;
    delete node;
}

void test_json_array()
{
    json_array *node = new json_array;
    node->push_back(new json_int(1));
    node->push_back(new json_int(2));
    node->push_back(new json_int(3));
    node->insert(4, new json_int(5));
    std::cout << "my_array=" << std::endl;
    for (int i = 0; i < node->size(); ++i)
    {
        json_node *obj = node->at(i);
        if (obj != NULL)
            std::cout << "\t[" << i << "]=" << obj->to_json_string() << std::endl;
        else
            std::cout << "\t[" << i << "]=" << "null" << std::endl;
        // TODO: we should generate soem null object in array object
    }
    std::cout << "json_array.to_string()=" << node->to_json_string() << std::endl;
    delete node;
}

void test_json_table()
{
    json_object* table = new json_object;
    table->insert("abc", new json_int(12));
    table->insert("foo", new json_string("bar"));
    table->insert("bool0", new json_boolean(false));
    table->insert("bool1", new json_boolean(true));

    std::cout << "my_object=" << std::endl;
    std::vector<std::pair<std::string, json_node*> >::const_iterator it = table->m_vec.begin();
    for ( ; it != table->m_vec.end(); ++it)
    {
        const std::string& key = it->first;
        json_node *val = (json_node*)it->second;
        std::cout << "\t" << key << ": " << val->to_json_string() << std::endl;
    }
    json_node* node = table;
    std::cout << "my_object.to_string()=" << node->to_json_string() << std::endl;
}

void test_json_parse()
{
    json_node *new_obj;

    new_obj = json_tokener_parse("\"liqi\"");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("\"\003\"");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("/* hello */\"foo\"");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("// hello\n\"foo\"");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("\"\\u0041\\u0042\\u0043\"");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

//  new_obj = json_tokener_parse("null");
//  std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
//  delete new_obj;;

    new_obj = json_tokener_parse("True");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("12345");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("12.3");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[\"\\n\"]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[\"\\nabc\\n\"]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[null]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[false]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("[\"abc\",null,\"def\",12]");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{}");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{ \"foo\": \"bar\" }");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{ \"foo\": \"bar\", \"baz\": null, \"bool0\": true }");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{ \"foo\": [null, \"foo\"] }");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{ \"abc\": 12, \"foo\": \"bar\", \"bool0\": false, \"bool1\": true, \"arr\": [ 1, 2, 3, null, 5 ] }");
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;
    delete new_obj;;

    new_obj = json_tokener_parse("{ foo }");
    if (is_error(new_obj))
        std::cout << "got error as expected" << std::endl;

    new_obj = json_tokener_parse("foo");
    if (is_error(new_obj))
        std::cout << "got error as expected" << std::endl;

    new_obj = json_tokener_parse("{ \"foo");
    if (is_error(new_obj))
        std::cout << "got error as expected" << std::endl;
}

void test_json_incremental_parsing()
{
    // test incremental parsing
    json_tokener tok;
    json_node *new_obj = tok.json_tokener_parse_ex("{ \"foo", 6);
    if (is_error(new_obj))
        std::cout << "got error as expected" << std::endl;

    new_obj = tok.json_tokener_parse_ex("\": {\"bar", 8);
    if (is_error(new_obj))
        std::cout << "got error as expected" << std::endl;

    new_obj = tok.json_tokener_parse_ex("\":13}}", 6);
    std::cout << "new_obj.to_string()=" << new_obj->to_json_string() << std::endl;

    delete new_obj;;  
}

int main(int argc, char **argv)
{
//  MC_SET_DEBUG(1);
    std::cout << std::string(78,'-') << std::endl;
    test_json_string();
    std::cout << std::string(78,'-') << std::endl;
    test_json_int();
    std::cout << std::string(78,'-') << std::endl;
    test_json_double();
    std::cout << std::string(78,'-') << std::endl;
    test_json_array();
    std::cout << std::string(78,'-') << std::endl;
    test_json_table();
    std::cout << std::string(78,'-') << std::endl;
    test_json_parse();
    std::cout << std::string(78,'-') << std::endl;
    test_json_incremental_parsing();

    return 0;
}

// ex:set tabstop=4 shiftwidth=4 expandtab:
