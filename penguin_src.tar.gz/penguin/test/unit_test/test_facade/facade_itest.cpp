// Posix header files
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// C 89 header files
#include <errno.h>
#include <signal.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <iostream>

// Duke header files
#include "ac_storage_db_impl.h"
#include "ac_storage_facade_impl.h"

int main(int argc, char* argv[])
{

    storage_id_t stor_id;

    ac_storage_facade_impl faca_impl(ac_storage_env_impl::instance().get_env(), stor_id.str());

    std::vector<std::pair<nb_id_t, nb_id_t> > keyval_id;
    std::vector<std::pair<nb_id_t, nb_id_t> > keyval_id1;

    nb_id_t id(NBID_TYPE_OBJECT_INT);
    id.set_value(12);

    nb_id_t id1(NBID_TYPE_OBJECT_INT);
    id1.set_value(13);

    keyval_id.push_back(std::make_pair(id, id1));

    faca_impl.insert(keyval_id);

    //bool output;
    faca_impl.commit();



    std::vector<nb_id_t> key;
    key.push_back(id);

    //ac_storage_facade_impl faca_impl1(ac_storage_env_impl::instance().get_env(), stor_id.str());

    faca_impl.get(key, keyval_id1);
    std::cout << "size:" << keyval_id1.size() << std::endl;
    std::cout << "value:" << keyval_id1[0].second.str() << std::endl;

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
