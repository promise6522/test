/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"

#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "ac_framework.h"
#include "ac_storage_db.h"
#include "ac_storage_facade.h"

int main(int argc, char* argv[])
{
    nb_configuration config(argc, argv);
    config.dump_configuration();

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    std::cout << "the first facade --------------------" << std::endl;

    storage_id_t stor_id;
    ac_storage_facade *pActor = new ac_storage_facade();
    pActor->initialization(stor_id);
    pActor->set_initialized_status();

    nb_id_t id(NBID_TYPE_OBJECT_INT);
    nb_id_t id1(NBID_TYPE_OBJECT_INT);
    id.set_value(14);
    id1.set_value(16);

    nb_id_t id2(NBID_TYPE_OBJECT_INT);
    nb_id_t id3(NBID_TYPE_OBJECT_INT);
    id2.set_value(2);
    id3.set_value(3);

    nb_id_t id4(NBID_TYPE_OBJECT_INT);
    id4.set_value(4);

    struct key_obj_id ids_insert1, ids_insert2, ids_insert3;
    ids_insert1.key_id = id;
    ids_insert1.obj_id = id1;

    ids_insert2.key_id = id;
    ids_insert2.obj_id = id3;

    ids_insert3.key_id = id;
    ids_insert3.obj_id = id4;

    struct key_obj_id ids_get1, ids_get2, ids_get3;
    ids_get1.key_id = id;
    ids_get2.key_id = id;
    ids_get3.key_id = id;

    struct key_pair_no_version1 version_insert1, version_get1, version_insert2, version_get2, version_insert3, version_get3;
    version_insert1.key_obj_ids.push_back(ids_insert1);
    version_get1.key_obj_ids.push_back(ids_get1);

    version_insert2.key_obj_ids.push_back(ids_insert2);
    version_get2.key_obj_ids.push_back(ids_get2);

    version_insert3.key_obj_ids.push_back(ids_insert3);
    version_get3.key_obj_ids.push_back(ids_get3);

    //std::cout << "the object id:" << value1.all_objects.front().object_id.str() << std::endl;

    //Start ac_framework
    ac_framework framework(config.get_actor_thread_pool());
    //framework.init_framework();
    framework.run();

    ac_manager::instance().list_add_actor(pActor);    
    ac_message_t msg_insert1 = {g_ac_framework_acid, 1, e_ac_storage_facade_insert, &version_insert1};
    pActor->enqueue(&msg_insert1);

    sleep(1);
    bool output, output1;
    output = pActor->commit(output1);
    std::cout << "commit:" << (output? "true" : "false") << std::endl;

    sleep(1);

    ac_message_t msg_get1 = {g_ac_framework_acid, 1, e_ac_storage_facade_get, &version_get1};
    pActor->enqueue(&msg_get1);

    //sleep(1);
    //int size;
    //ac_message_t msg_size = {g_ac_framework_acid, 1, e_ac_storage_facade_size, &size};
    //pActor->enqueue(&msg_size);
    sleep(5);

    std::cout << "the second facade --------------------" << std::endl;

    //storage_id_t stor_id;
    ac_storage_facade *pActor1 = new ac_storage_facade();
    pActor1->initialization(stor_id);
    pActor1->set_initialized_status();

    sleep(1);

    ac_manager::instance().list_add_actor(pActor1);
    ac_message_t msg_get4 = {g_ac_framework_acid, 1, e_ac_storage_facade_get, &version_get1};
    pActor1->enqueue(&msg_get4);

    std::cout << "the third facade --------------------" << std::endl;

    sleep(5);
    //storage_id_t stor_id;
    ac_storage_facade *pActor2 = new ac_storage_facade();
    pActor2->initialization(stor_id);
    pActor2->set_initialized_status();

    sleep(1);

    ac_manager::instance().list_add_actor(pActor2);
    ac_message_t msg_insert2 = {g_ac_framework_acid, 1, e_ac_storage_facade_insert, &version_insert2};
    pActor2->enqueue(&msg_insert2);

    sleep(3);

    ac_message_t msg_get2 = {g_ac_framework_acid, 1, e_ac_storage_facade_get, &version_get2};
    pActor2->enqueue(&msg_get2);

    sleep(1);

    ac_message_t msg_insert3 = {g_ac_framework_acid, 1, e_ac_storage_facade_insert, &version_insert3};
    pActor2->enqueue(&msg_insert3);

    sleep(3);

    ac_message_t msg_get3 = {g_ac_framework_acid, 1, e_ac_storage_facade_get, &version_get3};
    pActor2->enqueue(&msg_get3);

    std::cout << "the fourth facade --------------------" << std::endl;

    sleep(5);
    //storage_id_t stor_id;
    ac_storage_facade *pActor3 = new ac_storage_facade();
    pActor3->initialization(stor_id);
    pActor3->set_initialized_status();

    sleep(1);

    ac_manager::instance().list_add_actor(pActor3);
    ac_message_t msg_get5 = {g_ac_framework_acid, 1, e_ac_storage_facade_get, &version_get1};
    pActor3->enqueue(&msg_get5);

    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;    
}
