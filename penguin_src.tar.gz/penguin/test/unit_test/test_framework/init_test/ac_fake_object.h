/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _AC_FAKE_OBJECT_H_
#define _AC_FAKE_OBJECT_H_

#include "ac_global.h"
#include "ac_actor.h"
#include "ac_fake_db.h"

class ac_fake_object_helper : public ac_helper
{
public :
    ac_fake_object_helper(ac_id_t ac_id): ac_helper(ac_id)
    {
    }; 
    virtual ~ac_fake_object_helper()
    {
    };

    bool initialization_respond()
    {
        LOG_DEBUG("ac_fake_object("<< m_ac_id <<") start initialization_respond.");

        ac_actor * pActor = ac_manager::instance().acid_to_actor(m_ac_id);
        if(pActor)
        {
            pActor->set_initialized_status();
            return true;
        }
        return false;
    }    

    bool ac_fake_db_read(ac_id_t id, req_num_t req_num, const int& input)
    {
        LOG_DEBUG("ac_fake_object("<< m_ac_id <<") start db_read with input("
                  << input <<") to ac_fake_object("<<id <<").");

        int* pData = ac_memory_alloctor<int>::instance().allocate();
        *pData = input;
        return ac_manager::instance().send_asyn_message(id, m_ac_id, req_num,
                                                        e_ac_object_db_read, pData);
    }
    
    bool ac_fake_object_run_respond(call_id_t call_id, int& output)
    {
        LOG_DEBUG("ac_fake_object("<< m_ac_id <<") start run_respond with output("<< output
                  <<") to ac_fake_object("<< call_id.ac_id <<").");

        int* pData = ac_memory_alloctor<int>::instance().allocate();
    
        *pData = output;
        return ac_manager::instance().send_asyn_message(call_id.ac_id, m_ac_id, call_id.req_num,
                                                        e_ac_object_run_response, pData);
    }
};

typedef std::tr1::shared_ptr< ac_fake_object_helper>  ac_fake_object_helper_ptr;    

class ac_fake_object : public ac_actor
{
private :
    virtual bool message_handle(const ac_message_t& message)
    {
        ac_actor::message_handle(message);
        switch(message.type)
        {
            case e_ac_actor_exception : 
            {
                std::string* pData = reinterpret_cast<std::string*>(message.data);
                if(pData)
                    return exception_handle(message.req_num, *pData);
                break;
            }
            case e_ac_object_run :
            {
                call_id_t call_id = {message.ac_id, message.req_num};
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return run(call_id, *pData);
                break;
            }
            case e_ac_object_db_read_response :
            {
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return db_read_response(message.req_num, *pData);
                break;
            }
            default : 
            {
                LOG_ERROR("the message type isn't support by this actor.");
                break;
            }
        }
        return false;
    };
    
    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        ac_actor::exception_handle(req_num, str);
        return true;        
    }
    
    bool db_read_response(req_num_t req_num, int& output)
    {
        m_db_responses.push_back(output);

        if(m_db_responses.size() == 3)
        {
            m_ptrHelper->initialization_respond();            
        }

        assert(m_db_responses.size() <= 3);        
        return true;        
    }    
    
    bool run(call_id_t call_id, const int& input)
    {
        LOG_DEBUG("ac_fake_object("<< m_ac_id <<") is executing run...........");

        int output = input + 1;        
        m_ptrHelper->ac_fake_object_run_respond(call_id, output);        
        return true;
    }    

public :
    ac_fake_object(): ac_actor(e_ac_bridge), m_ptrHelper(new(std::nothrow) ac_fake_object_helper(m_ac_id)) 
    {
         m_actor_name = "ac_fake_object";
         LOG_DEBUG("ac_fake_object("<< m_ac_id <<") constractor");
    }; 
    virtual ~ac_fake_object()
    {
    };

    virtual bool initialization()
    {
         ac_fake_db *pActor = new ac_fake_db();
         pActor->set_initialized_status();
         ac_manager::instance().add_actor(pActor);
         int value1 = 1;
         req_num_t req_num1(1, true);         
         m_ptrHelper->ac_fake_db_read(pActor->get_actor_id(), req_num1, value1);

         pActor = new ac_fake_db();
         pActor->set_initialized_status();
         ac_manager::instance().add_actor(pActor);
         int value2 = 2;
         req_num_t req_num2(2, true);         
         m_ptrHelper->ac_fake_db_read(pActor->get_actor_id(), req_num2, value2);

         pActor = new ac_fake_db();
         pActor->set_initialized_status();
         ac_manager::instance().add_actor(pActor);
         int value3 = 3;
         req_num_t req_num3(3, true);         
         m_ptrHelper->ac_fake_db_read(pActor->get_actor_id(), req_num3, value3);
         return true;         
    }

private :
    ac_fake_object_helper_ptr m_ptrHelper;
    std::vector<req_num_t> m_db_responses;
}; 

#endif /* _AC_FAKE_OBJECT_H_ */
