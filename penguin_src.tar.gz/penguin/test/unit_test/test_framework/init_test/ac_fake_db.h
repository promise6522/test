/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _AC_FAKE_DB_H_
#define _AC_FAKE_DB_H_

#include "ac_global.h"
#include "ac_actor.h"

//---------------------------------------------------------------------------------------

class ac_fake_db_helper : public ac_helper
{
public :
    ac_fake_db_helper(ac_id_t ac_id): ac_helper(ac_id)
    {
    }; 
    virtual ~ac_fake_db_helper()
    {
    };

    bool ac_fake_db_read_respond(call_id_t call_id, int& output)
    {
        int* pData = ac_memory_alloctor<int>::instance().allocate();
        *pData = output;
        return ac_manager::instance().send_asyn_message(call_id.ac_id, m_ac_id, call_id.req_num,
                                                        e_ac_object_db_read_response, pData, true);
    }
};

typedef std::tr1::shared_ptr<ac_fake_db_helper>  ac_fake_db_helper_ptr;    

class ac_fake_db : public ac_actor
{
private :
    virtual bool message_handle(const ac_message_t& message)
    {
        ac_actor::message_handle(message);
        switch(message.type)
        {
            case e_ac_actor_exception : 
            {
                std::string* pData = reinterpret_cast<std::string*>(message.data);
                if(pData)
                    return exception_handle(message.req_num, *pData);
                break;
            }
            case e_ac_object_db_read :
            {
                call_id_t call_id = {message.ac_id, message.req_num};
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return db_read(call_id, *pData);
                break;
            }
            default : 
            {
                LOG_ERROR("the message type isn't support by this actor.");
                break;
            }
        }
        return false;
    };
    
    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        ac_actor::exception_handle(req_num, str);
        return true;        
    }
    
    bool db_read(call_id_t call_id, const int& input)
    {
        int value = input * 10;
        m_ptrHelper->ac_fake_db_read_respond(call_id, value);
        return true;        
    }    

public :
    ac_fake_db(): ac_actor(e_ac_bridge), m_ptrHelper(new(std::nothrow) ac_fake_db_helper(m_ac_id)) 
    {
         m_actor_name = "ac_fake_db";
         LOG_DEBUG("ac_fake_db("<< m_ac_id <<") constractor");
    }; 
    virtual ~ac_fake_db()
    {
    };

    virtual bool initialization()
    {
        return true;        
    }
private :
    ac_fake_db_helper_ptr m_ptrHelper;
};

#endif /* _AC_FAKE_DB_H_ */
