/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"

#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "ac_framework.h"

#include "ac_factorial.h"

int main(int argc, char* argv[])
{
    nb_configuration::instance().parse_option(argc, argv);
    nb_configuration::instance().dump_configuration();

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    //Start ac_framework
    ac_framework framework(nb_configuration::instance().get_actor_thread_pool(), 
                           nb_configuration::instance().get_is_statistics(), 
                           nb_configuration::instance().get_statistics_interval());
    //framework.init_framework();
    framework.run();

    for(int i = 0; i < 100; ++i)
    {   
        ac_actor *pActor = new ac_factorial();
        pActor->set_initialized_status();
        int* value = new int(10001);
        ac_manager::instance().add_actor(pActor);    
        ac_message_t* msg1 = new ac_message_t;
        pack_message(*msg1, g_ac_framework_acid, 1, e_ac_bridge_trigger, value, false);
        ac_manager::instance().send_asyn_message(ac_manager::instance().actor_to_acid(pActor), msg1);

        pActor = new ac_factorial();
        pActor->set_initialized_status();
        int* value2 = new int(8001);
        ac_message_t* msg2 = new ac_message_t;
        pack_message(*msg2, g_ac_framework_acid, 1, e_ac_bridge_trigger, value2, false);
        ac_manager::instance().add_actor(pActor);
        ac_manager::instance().send_asyn_message(ac_manager::instance().actor_to_acid(pActor), msg2);
    }

    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;    
}
