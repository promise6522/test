/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _AC_FACTORIAL_H_
#define _AC_FACTORIAL_H_

#include "ac_global.h"
#include "ac_actor.h"

class ac_factorial_helper : public ac_helper
{
public :
    ac_factorial_helper(ac_id_t ac_id): ac_helper(ac_id)
    {
    }
    virtual ~ac_factorial_helper()
    {
    }

    bool run(ac_id_t id, req_num_t req_num, const int& input)
    {
        int* pData = ac_memory_alloctor<int>::instance().allocate();
        *pData = input;
        return ac_manager::instance().send_asyn_message(id, m_ac_id, req_num, e_ac_bridge_trigger, pData);
    }
    
    bool run_respond(call_id_t call_id, int& output)
    {
        LOG_DEBUG("ac_factorial("<<m_ac_id<<") run_respond with output("<<output
                  <<") to ac_factorial("<<call_id.ac_id<<").");
        int* pData = ac_memory_alloctor<int>::instance().allocate();
    
        *pData = output;
        return ac_manager::instance().send_asyn_message(call_id.ac_id, m_ac_id, call_id.req_num,
                                                        e_ac_bridge_trigger_response, pData);
    }
};

typedef std::tr1::shared_ptr< ac_factorial_helper>  ac_factorial_helper_ptr;    

class ac_factorial : public ac_actor
{
private :
    virtual bool message_handle(const ac_message_t& message)
    {
        ac_actor::message_handle(message);
        switch(message.type)
        {
            case e_ac_actor_exception : 
            {
                std::string* pData = reinterpret_cast<std::string*>(message.data);
                if(pData)
                    return exception_handle(message.req_num, *pData);
                break;
            }
            case e_ac_actor_exit : 
            {
                call_id_t call_id = {message.ac_id, message.req_num};
                return exit(call_id);
                break;
            }
            case e_ac_bridge_trigger :
            {
                call_id_t call_id = {message.ac_id, message.req_num};
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return run(call_id, *pData);
                break;
            }
            case e_ac_bridge_trigger_response :
            {
                int* pData = reinterpret_cast<int*>(message.data);
                if(pData)
                    return run_response(message.req_num, *pData);
                break;
            }
            default : 
            {
                std::cout<<"the message type isn't support by this actor."<<std::endl;
                break;
            }
        }
        return false;
    }
    
    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        ac_actor::exception_handle(req_num, str);
        return true;        
    }
    
    bool run(call_id_t call_id, const int& input)
    {
        LOG_DEBUG("ac_factorial("<<m_ac_id<<") run with input("<<input<<").");
        if(input == 0)
        {
            int value = 0;            
            m_ptrHelper->run_respond(call_id, value);
        }
        else
        {
            ac_actor *pActor = new ac_factorial();
            pActor->set_initialized_status();
            m_data = input;
            int value = input - 1;
            ac_manager::instance().add_actor(pActor);
            m_call_id = call_id;
            m_sub_actor = pActor;
            m_ptrHelper->run(pActor->get_actor_id(), 0, value);
        }
        
        return true;
    }
    
    bool run_response(req_num_t req_num, int& output)
    {
        LOG_DEBUG("ac_factorial("<<m_ac_id<<") run_response with output("<<output<<").");
        ac_manager::instance().send_asyn_message(m_sub_actor->get_actor_id(), g_ac_framework_acid, req_num,
                                                 e_ac_actor_exit, NULL);
        int value = output + m_data;
        m_ptrHelper->run_respond(m_call_id, value);
        return true;
    }    

public :
    ac_factorial(): ac_actor(e_ac_bridge), m_ptrHelper(new(std::nothrow) ac_factorial_helper(m_ac_id)) 
    {
         m_actor_name = "ac_factorial";
         LOG_DEBUG("ac_factorial("<<m_ac_id<<") constractor");
    }
    virtual ~ac_factorial()
    {
    }
    virtual bool initialization()
    {
        return true;        
    }    

private :
    ac_factorial_helper_ptr m_ptrHelper;
    int m_data;
    call_id_t m_call_id;

    ac_actor *m_sub_actor;
}; 

#endif /* _AC_FACTORIAL_H_ */
