#ifndef _AC_ID_DB_TEST_HELPER_H_
#define _AC_ID_DB_TEST_HELPER_H_
#include <string>
#include <vector>
//#include <boost/crc.hpp>
#include <string>
#include <iomanip>
#include <boost/shared_ptr.hpp>
#include "nb_id.h"
//#include "ac_helper.h"
#include "ac_db/ac_id_db.h"
#include "ac_actor.h"
#include "ac_message_type.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_bytes.h"
#include "ac_manager.h"

class ac_id_db_test_helper: public ac_helper
{
public:
    ac_id_db_test_helper(ac_id_t ac_id):ac_helper(ac_id)
    {
        
    }
    virtual ~ac_id_db_test_helper()
    {
        
    }
    
    bool write_db_by_id(const nb_id_t& id, const std::string& value)
    {
        int ret = ac_id_db::instance().write(id.str(), value);
        if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        {
            std::cout<<"$$$$$ write: key="<<id.str()<<", value="<<value<<std::endl;
            return true;
        }
        else
        {
            std::cout << "write failed" << std::endl;
            return false;
        }
    }
    
    bool read_db_by_id(const nb_id_t& id, std::string& value)
    {
        std::string key = id.str();
        
        int ret = ac_id_db::instance().read(key, value);   
        if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        {
            std::cout<<"##### read: key="<<key<<", value="<<value<<std::endl;
            return true;
        }
        else if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        {
            std::cout << "not found the value" << std::endl;
        }
        else
        {
            std::cout << "read failed" << std::endl;
        }
        
        return false;
    }
    bool string_to_content(const std::string& strval, content& raw_data)
    {
        raw_data.id_value.ids.clear();
        raw_data.id_value.values.clear();
        std::vector<char> vec(strval.begin(), strval.end());
        raw_data.id_value.values.push_back(vec);
        return true;
    }
    bool content_to_string(const content& raw_data, std::string& val)
    {
        assert(raw_data.id_value.values[0].size());
        val.assign(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
        return true;
    }
    bool show_struct_data(const array_data_t& logic_data)
    {
        std::cout << "obj_impl_array" << std::endl;
        std::cout << "{" << std::endl;
        std::cout << "struct array_data_t" << std::endl;
        std::cout << "{" << std::endl;
        std::cout << " nb_id_t interface:" << logic_data.interface.str() << std::endl;
        std::cout << " nb_id_t types:" << logic_data.type.str() << std::endl;
        std::cout << " nb_id_vector objs:[";
        nb_id_vector::const_iterator it = logic_data.objs.begin();
        int i = 0;
        while(it!=logic_data.objs.end())
        {
            
            std::cout << i << ":" << it->str() << ",";
            ++i;
            ++it;
        }
        std::cout << "]" << std::endl;
        std::cout << "}" << std::endl;
        std::cout << "}" << std::endl;
        return true;
    }
    
    
    bool show_struct_data(const std::string& strval)
    {
        std::cout << "obj_impl_string:" << std::endl;
        std::cout << "{" << std::endl;
        std::cout << "  std::string m_cData: " << strval << std::endl;
        std::cout << "}" << std::endl;
        return true;
    }
    
    bool show_struct_data(const bytes_data_t& byVal)
    {
        std::cout << "obj_impl_bytes:" << std::endl;
        std::cout << "{" << std::endl;
        std::cout << " struct bytes_data_t:" << std::endl;
        std::cout << " {" << std::endl;
        std::cout << "  int crc:" << byVal.crc << std::endl;
        std::cout << "  int length:" << byVal.length << std::endl;
        std::cout << "  std::string value:" << byVal.value << std::endl;
        std::cout << " }" << std::endl;
        std::cout << "}" << std::endl;
        return true;
    }
    
    bool content_to_des_Struct(const content& raw_data, const nb_id_t& id)
    {
        nb_id_t IdType; 
        switch(id.get_type())
        {
            case NBID_TYPE_OBJECT_NONE:
                break;
            case NBID_TYPE_OBJECT_BOOL:
                break;
            case NBID_TYPE_OBJECT_INT:            
                break;
            case NBID_TYPE_OBJECT_FLOAT:           
                break;
            case NBID_TYPE_OBJECT_STRING:
                {
                    std::string strval;
                    obj_impl_string::unpack(raw_data, IdType, strval);
		    std::cout << IdType.str() << std::endl;
                    show_struct_data(strval);
                }
                break;
            case NBID_TYPE_OBJECT_BYTES:  
                {
                    bytes_data_t byVal;
                    obj_impl_bytes::unpack(raw_data, IdType, byVal);
		    std::cout << IdType.str() << std::endl;
                    show_struct_data(byVal);
                }
                break;
            case NBID_TYPE_OBJECT_INTERVAL:         
                break;
            case NBID_TYPE_OBJECT_TIME:            
                break;
            case NBID_TYPE_OBJECT_ARRAY:
                {
                    array_data_t arrData;
                    obj_impl_array::unpack(raw_data, IdType, arrData);
		    std::cout << IdType.str() << std::endl;
                    show_struct_data(arrData);
                }
                break;
            case NBID_TYPE_OBJECT_MAP:            
                break;
            case NBID_TYPE_OBJECT_DECLARATION:            
                break;
            case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:            
                break;
            case NBID_TYPE_OBJECT_INTERFACE:            
                break;
            case NBID_TYPE_OBJECT_INTERFACE_COMPOUND:               
                break;
            case NBID_TYPE_OBJECT_IMPLEMENTATION:                
                break;
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:               
                break;
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:               
                break;
            case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC:                
                break;
            case NBID_TYPE_OBJECT_EXEC_ITERATOR:                
                break;
            case NBID_TYPE_OBJECT_EXEC_CONDITION:                
                break;
            case NBID_TYPE_OBJECT_DESCRIPTOR:                
                break;
            case NBID_TYPE_OBJECT_ID_STAND_IN:                
                break;
            case NBID_TYPE_OBJECT_USER:                
                break;
            default:
                break;
        }
        return true;
    }
    
};
typedef boost::shared_ptr<ac_id_db_test_helper> ac_id_db_test_helper_ptr;
#endif /*_AC_ID_DB_TEST_HELPER_H_*/
