#include "ac_id_db.h"
#include "nb_id.h"

int main()
{
    /////////////////////////////
    nb_id_t id_ifc(NB_INTERFACE_BRIDGE);

    if (id_ifc.get_interface_type() == NB_INTERFACE_BRIDGE)
        std::cout << "ok" << std::endl;

    if (id_ifc.is_interface_bridge())
        std::cout << "ok1" << std::endl;

    std::cout << id_ifc.str() << std::endl;

    ////////////////////////////

    std::string strkey = "committer_id";
    std::string value = "16";

    int ret = ac_id_db::instance().write(strkey, value);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "write ok" << std::endl;
    else
        std::cout << "write failed" << std::endl;

    std::string strval;

    //std::string strkey1 = "41000000000000000000000000000000";
    ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "read ok" << std::endl;
    else if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        std::cout << "not found the value" << std::endl;
    else
        std::cout << "read failed" << std::endl;

    std::cout << "read value:" << strval << std::endl;

    std::cout << std::string(20, '*') << std::endl;

    host_committer_id_t com_id;
    
    std::cout << com_id.str() << std::endl;

    com_id = com_id + 1;

    std::cout << com_id.str() << std::endl;
    std::cout << std::string(20, '*') << std::endl;

    nb_id_t id_t;

    std::cout << "nb id:" << id_t.str() << std::endl;

    id_t += 1;

    std::cout << "after id:" << id_t.str() <<std::endl;

    uint32_t sum = 1;
    for (uint32_t n = 1; n <= 25; ++n)
    {
        sum = sum*2;
    }
    std::cout << sum -1 << std::endl;

    transaction_id_t trans_id;

    std::cout << trans_id.str() << std::endl;

    trans_id += 1;

    std::cout << trans_id.str() << std::endl;

    center_committer_id_t cen_id;
    std::cout << cen_id.str() << std::endl;

    cen_id += 1;

    std::cout << cen_id.str() << std::endl;

    center_committer_id_t cen_id1(cen_id);

    std::cout << cen_id1.str() << std::endl;

    center_committer_id_t cen_id2(cen_id1.str());

    std::cout << cen_id2.str() << std::endl;

    return 0;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
