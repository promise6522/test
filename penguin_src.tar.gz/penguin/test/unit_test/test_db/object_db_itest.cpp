// Posix header files
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// C 89 header files
#include <errno.h>
#include <signal.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <iostream>

// Duke header files

#include "ac_nb_bdb.h"
#include "nb_stdx_singleton.h"
#include "ac_object_db_impl.h"
#include "nb_id.h"

int main(int argc, char* argv[])
{

//    dukelog log(opt.m_progname);
//    log.priority(LOG_INFO);

    std::string strkey = "16";
    std::string value = "good";

    int flag(1);
    int ret = ac_object_db_impl::instance().write(strkey, value, flag);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "write ok" << std::endl;
    else
        std::cout << "write failed" << std::endl;

    std::string strval;

    std::string strkey1 = "41000000000000000000000000000000";

    ret = ac_object_db_impl::instance().commit(1);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "commit ok" << std::endl;
    else
        std::cout << "commit failed" << std::endl;

    ret = ac_object_db_impl::instance().read(strkey, strval, 1);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "read ok" << std::endl;
    else if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        std::cout << "not found the value" << std::endl;
    else
        std::cout << "read failed" << std::endl;

    std::cout << "read value:" << strval << std::endl;

    nb_id_t id(NBID_TYPE_OBJECT_STRING);

    std::vector<char> strchar;

    strchar.push_back('a');
    strchar.push_back('b');

    //bool b = id.set_value(strchar);
    //if (b)
    //    std::cout << "write value success" << std::endl;

    //std::vector<char> strvalue;
    //b = id.get_value(strvalue);
    //if (b)
    //{
    //    std::cout << "read char:" << strvalue[0] << "," << strvalue[1] << std::endl; 
    //}

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
