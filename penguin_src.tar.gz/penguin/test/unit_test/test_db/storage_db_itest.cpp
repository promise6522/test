// Posix header files
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// C 89 header files
#include <errno.h>
#include <signal.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <iostream>

// Duke header files

#include "ac_nb_bdb.h"
#include "nb_stdx_singleton.h"
#include "ac_storage_db_impl.h"

int main(int argc, char* argv[])
{

    ac_storage_db_impl stordb;
    std::string strname = "123456";
    stordb.run(ac_storage_env_impl::instance().get_env(), strname);


    std::string strkey = "15";
    std::string value = "jinbin";

    int ret = stordb.write(strkey, value);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "write ok" << std::endl;
    else
        std::cout << "write failed" << std::endl;

    ret = stordb.commit();
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "commit ok" << std::endl;
    else
        std::cout << "commit failed" << std::endl;

    std::string strval;

    ret = stordb.read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "read ok" << std::endl;
    else if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        std::cout << "not found the value" << std::endl;
    else
        std::cout << "read failed" << std::endl;

    std::cout << "read value:" << strval << std::endl;

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
