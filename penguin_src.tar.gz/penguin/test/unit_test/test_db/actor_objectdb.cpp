/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"
#include "ac_global_db.h"

#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "ac_framework.h"
#include "ac_object_db.h"


bool comp_vnb(const std::vector<nb_id_t>& source, const std::vector<nb_id_t>& des)
{
	int Tsize = source.size();
	if(source.size()!=des.size())
	{
		return false;
	}
	for(int i = 0; i < Tsize; ++i)
	{
		if(source[i]!=des[i])
		return false;
	}	
	return true;
}

std::string generate_string_id(int digits)
{
	std::string charset("0123456789ABCDEF");
	std::string strid;
	strid.clear();
	for( int i=0; i<digits; i++ )
	{
		strid.push_back(charset[rand()%16]);
	}

	//strid.push_back('\0');

	return strid;
}

// Generate  nb_id_t for testing
nb_id_t generate_test_nb_id()
{
    return nb_id_t(generate_string_id(32));
}

int main(int argc, char* argv[])
{
	key_pairs value_1;
	key_pairs value_2;

	value_1.key_ids.push_back(generate_test_nb_id());
	value_1.key_ids.push_back(generate_test_nb_id());
	value_1.key_ids.push_back(generate_test_nb_id());

	value_1.obj_ids.push_back(generate_test_nb_id());
	value_1.obj_ids.push_back(generate_test_nb_id());
	value_1.obj_ids.push_back(generate_test_nb_id());
	std::string strval = pack_storage(value_1);
	unpack_storage(strval, value_2);

	assert(comp_vnb(value_1.key_ids,value_2.key_ids));
	assert(comp_vnb(value_1.obj_ids, value_2.obj_ids));
	std::cout << "programe exit success" << std::endl;
//    nb_configuration config(argc, argv);
//    config.dump_configuration();
//
//    // Block all signals for background thread.
//    sigset_t new_mask;
//    sigfillset(&new_mask);
//    sigset_t old_mask;
//    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);
//
//    ac_object_db *pActor = new ac_object_db();
//    pActor->initialization();
//    pActor->set_initialized_status();
//    db_value value, value1;
//    db_id_value id_value;
//    nb_id_t id(NBID_TYPE_OBJECT_INT);
//    nb_id_t id_1(NBID_TYPE_OBJECT_INT);
//    id.set_value(2);
//    id_1.set_value(4);
//    nb_id_t id1(NBID_TYPE_OBJECT_BOOL);
//    id_value.ids.push_back(id1);
//    std::string strval = "hello";
//    std::vector<char> vchar;
//    vchar.assign(strval.begin(), strval.end());
//    id_value.values.push_back(vchar);
//
//    content con, con1;
//    con.id_value = id_value;
//    con.object_id = id;
//
//    con1.id_value = id_value;
//    con1.object_id = id;
//
//    value.all_objects.push_back(con);
//    value1.all_objects.push_back(con1);
//
//    ac_manager::instance().list_add_actor(pActor);    
//    ac_message_t msg = {g_ac_framework_acid, 1, e_ac_object_db_write, &value};
//    pActor->enqueue(&msg);
///*
//    sleep(1);
//    ac_message_t msg_1 = {g_ac_framework_acid, 1, e_ac_object_db_write, &value1};
//    pActor->enqueue(&msg_1);
//*/
//    sleep(1);
//
//    int flag(1);
//    ac_message_t msg2 = {g_ac_framework_acid, 1, e_ac_object_db_commit, &flag};
//    pActor->enqueue(&msg2);
//
//    sleep(1);
//
//    //Start ac_framework
//    ac_framework framework(config.get_actor_thread_pool());
//    //framework.init_framework();
//    framework.run();
//
//    sleep(1);
//    object_ids objids;
//    objids.ids.push_back(id);
//
//    ac_message_t msg1 = {g_ac_framework_acid, 1, e_ac_object_db_read, &objids};
//    for (int i = 0; i < 2; ++i)
//    {
//	    pActor = new ac_object_db();
//	    pActor->initialization();
//	    pActor->set_initialized_status();
//	    ac_manager::instance().list_add_actor(pActor);
//	    pActor->enqueue(&msg1);
//	    //sleep(1);
//    }
//    // Wait for signal indicating time to shut down.
//    sigset_t wait_mask;
//    sigemptyset(&wait_mask);
//    sigaddset(&wait_mask, SIGINT);
//    sigaddset(&wait_mask, SIGQUIT);
//    sigaddset(&wait_mask, SIGTERM);
//    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
//    int sig = 0;
//    sigwait(&wait_mask, &sig);   
//
//    //Stop the server
//    framework.stop();

    return 0;    
}
