/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"

#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "ac_framework.h"

#include "ac_nb_bdb.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_manager.h"
#include "ac_execution.h"
#include "anchor_implementation.h"
#include "container_implementation.h"
#include "access_implementation.h"
#include "ac_exec_test_helper.h"
#include "obj_impl_decl_compound.h"
#include "obj_impl_exec_impl.h"
#include "obj_impl_exec_obj_func.h"
#include "obj_impl_container_def.h"
#include "obj_impl_string.h"
#include "obj_impl_descriptor.h"
#include "obj_impl_interface_compound.h"
#include "obj_impl_user.h"
#include "obj_impl_array.h"
#include "obj_impl_bridge.h"
#include "obj_impl_bridge_interface.h"
#include "obj_impl_map.h"

// ******************************* defination *********************************//
static ac_id_t g_ac_object_acid = 0;
//static int32_t data_index = 9;

enum impl_graph_define_t
{	
	// single-type nodes
    GRAPH_NODE_INT,
    GRAPH_NODE_BOOL,
	GRAPH_NODE_FLOAT,
    GRAPH_NODE_STRING,
    GRAPH_NODE_USER,
    GRAPH_NODE_ARRAY,
    GRAPH_NODE_BRIDGE,
    GRAPH_NODE_MAP,
};
static impl_graph_define_t IMPL_GRAPH_DEFINE;

static std::string CASE_GENERATOR_EXPR;/* from user input to auto generate graph */

// ******************************* utilities *********************************//

/* simply create a node_path_t struct */
node_path_t create_path(int in_node, int in_port, int out_node, int out_port)
{	
	node_path_t path;
	path.in_node = in_node;
	path.in_port = in_port;
	path.out_node = out_node;
	path.out_port = out_port;
	return path;
}

bool generate_out_path_info(exec_impl_graph_t& impl_data)
{
	int node_size = impl_data.nodes.size();
	assert(node_size>0);
	int path_size = impl_data.paths.size();
	assert(path_size>0);

	impl_data.out_paths.clear();
	for(int node_index = 0 ; node_index < node_size ; ++node_index)
	{
		out_port_path_idx_t out_path_info;
		out_path_info.out_port = 1;/* TODO */
		// push all of a node's out_path
		for(int path_index = 0 ; path_index < path_size ; ++path_index)
		{
			if(impl_data.paths[path_index].in_node == node_index)
				out_path_info.path_idxs.push_back(path_index);
		}
		impl_data.out_paths.push_back(out_path_info);
	}

	/* another algorithm,but still need some modification */
	/*
	impl_data.out_paths.resize(node_size);
	for(int path_index = 0 ; path_index < path_size ; ++path_index)
	{
		int node_index = impl_data.paths[path_index].in_node;
		if(node_index >= 0)
			impl_data.out_paths.path_idxs.push_back(path_index);
	}*/

	return true;
}

nb_id_t get_builtin_compound_instruction(const nb_id_t& if_id, const std::string& ins_name)
{
    sleep(1);

    object_ids builtin_ins;
	ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_object_get_property(if_id, nb_id_t(NB_FUNC_INTERFACE_GET_BUILTIN_INS), builtin_ins);

    for (size_t i = 0;i < builtin_ins.ids.size();++i)
    {
        content decl_raw;
        ptrHelper->ac_object_get_value_sync(builtin_ins.ids[i], decl_raw);
        nb_id_t temp_decl_id;
        decl_compound_data_t decl_logic;
        obj_impl_decl_compound::unpack(decl_raw, temp_decl_id, decl_logic);

        if (decl_logic.name == ins_name)
        {
            return builtin_ins.ids[i];
        }
    }

    return nb_id_t(NBID_TYPE_OBJECT_NONE);
}

// ******************************* handles *********************************//
nb_id_t generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id)
{
	request_nb_id_info exec_info;
    exec_info.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
    exec_info.committer_id = hc_id;

	/* build obj_func_data_t */
    exec_obj_func_data_t obj_func_data;
    obj_func_data.name = "obj_func";
    obj_func_data.selected_decl = decl_id;
    obj_func_data.recoverer = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.postcut = false;
    obj_impl_exec_obj_func::pack(obj_func_data, nb_id_t(), exec_info.raw_data);
	
	/* request nb_id */
    nb_id_t exec_obj_func_id;
	ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, exec_info, exec_obj_func_id);

	return exec_obj_func_id;
}

bool generate_decl_comp(const host_committer_id_t& hc_id, nb_id_t& decl_id)
{
    decl_compound_data_t decl_data;

    // name 
    decl_data.name = "compound_declaration";

    // in ports 
    iport_t iitem;
    iitem.name = "int";
    iitem.interface = nb_id_t(NB_INTERFACE_INT);
    iitem.default_value = nb_id_t(NB_INTERFACE_INT);
    decl_data.iports.push_back(iitem);

    // out ports 
    oport_t oitem;
    oitem.name = "int";
    oitem.interface = nb_id_t(NB_INTERFACE_INT);
    decl_data.oports.push_back(oitem);

    // request declaration id
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, decl_info, decl_id);

    return true;
}
    
bool generate_descriptor(host_committer_id_t host_committer_id, 
        const descriptor_data_t& data,
        nb_id_t& dp_id)
{
    // request defination id
    request_nb_id_info dp_info;
    dp_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
    dp_info.committer_id = host_committer_id;
    obj_impl_descriptor::pack(data, nb_id_t(), dp_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, dp_info, dp_id);

    return true;
}

bool generate_decl_compound(host_committer_id_t host_committer_id, 
        const decl_compound_data_t& data,
        nb_id_t& decl_id)
{
    // request defination id
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = host_committer_id;
    obj_impl_decl_compound::pack(data, nb_id_t(), decl_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, decl_info, decl_id);

    return true;
}

bool generate_interface_compound(host_committer_id_t host_committer_id, 
        const if_compound_data_t& data,
        nb_id_t& if_id)
{
    // request defination id
    request_nb_id_info if_info;
    if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    if_info.committer_id = host_committer_id;
    obj_impl_interface_compound::pack(data, nb_id_t(), if_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, if_info, if_id);

    return true;
}

bool generate_interface_bridge(host_committer_id_t host_committer_id, 
        const bridge_interface_data_t& data,
        nb_id_t& if_id)
{
    // request defination id
    request_nb_id_info if_info;
    if_info.type = NBID_TYPE_OBJECT_BRIDGE_INTERFACE;
    if_info.committer_id = host_committer_id;
    obj_impl_bridge_interface::pack(data, nb_id_t(), if_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, if_info, if_id);

    return true;
}

bool generate_array(host_committer_id_t hc_id, 
        const nb_id_t obj_tp,
        const nb_id_vector& objs,
        nb_id_t& array_id,
        nb_id_t& tp)
{
    array_data_t array_data;
    array_data.interface = nb_id_t(NB_INTERFACE_ARRAY);

    if_compound_data_t type_data;
    type_data.name = "array type";
    type_data.type = nb_id_t(NB_INTERFACE_ARRAY_TYPE);

    if_exp_group ay_type;
    ay_type.min_if = obj_tp; 
    type_data.groups.push_back(ay_type);

    // type 
    generate_interface_compound(hc_id, type_data, array_data.type);
    tp = array_data.type;

    // objects
    array_data.objs = objs;

    request_nb_id_info array_info;
    array_info.type = NBID_TYPE_OBJECT_ARRAY;
    array_info.committer_id = hc_id;
    obj_impl_array::pack(array_data, nb_id_t(), array_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, array_info, array_id);

    return true;
}

bool generate_map(host_committer_id_t hc_id, 
        const nb_id_t key_tp,
        const nb_id_t val_tp,
        const nb_id_multimap& kv_pairs,
        nb_id_t& map_id,
        nb_id_t& tp)
{
    map_data_t map_data;
    map_data.interface = nb_id_t(NB_INTERFACE_MAP);

    if_compound_data_t map_type;
    map_type.name = "map type";
    map_type.type = nb_id_t(NB_INTERFACE_MAP_TYPE);

    if_exp_group key_type;
    key_type.min_if = key_tp; 
    if_exp_group val_type;
    val_type.min_if = val_tp; 
    map_type.groups.push_back(key_type);
    map_type.groups.push_back(val_type);

    // type 
    generate_interface_compound(hc_id, map_type, tp);
    map_data.type = tp;

    // objects
    map_data.data = kv_pairs;

    request_nb_id_info map_info;
    map_info.type = NBID_TYPE_OBJECT_MAP;
    map_info.committer_id = hc_id;
    obj_impl_map::pack(map_data, nb_id_t(), map_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, map_info, map_id);

    return true;
}

bool generate_bridge(const host_committer_id_t& host_committer_id, 
        nb_id_t& bridge_id, 
        nb_id_t& if_id)
{
    bridge_data_t bg_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    // name 
    bg_data.name = "bridge";

    // interface 
    bridge_interface_data_t if_data;
    if_data.data_index = 9; //data_index++;
    ////int
    if_data.sub_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));
    ////array
    nb_id_vector ints;
    nb_id_t int0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int0.set_value(10);
    nb_id_t int1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int1.set_value(20);
    ints.push_back(int0);
    ints.push_back(int1);
    nb_id_t array_id;
    nb_id_t array_type;
    generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), ints, array_id, array_type);
    if_data.sub_interfaces.push_back(array_type);

    // request defination id
    request_nb_id_info if_info;
    if_info.type = NBID_TYPE_OBJECT_BRIDGE_INTERFACE;
    if_info.committer_id = host_committer_id;
    obj_impl_bridge_interface::pack(if_data, nb_id_t(), if_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, if_info, if_id);

    bg_data.interface = if_id;

    // sub objects 
    ////sub0
    nb_id_t sub0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    sub0.set_value(10000);
    ////sub1
    nb_id_vector objs;
    nb_id_t obj0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    obj0.set_value(100);
    nb_id_t obj1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    obj1.set_value(200);
    objs.push_back(obj0);
    objs.push_back(obj1);
    nb_id_t sub1;
    nb_id_t sub1_type;
    generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), objs, sub1, sub1_type);
    bg_data.subobjs.push_back(sub0);
    bg_data.subobjs.push_back(sub1);

    // request implementation id
    request_nb_id_info bg_info;
    bg_info.type = NBID_TYPE_OBJECT_BRIDGE;
    bg_info.committer_id = host_committer_id;
    obj_impl_bridge::pack(bg_data, nb_id_t(), bg_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, bg_info, bridge_id);

    return true;
}

bool generate_impl_int(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** constants ****************//
    nb_id_t cint1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    cint1.set_value(22);
    nb_id_t cint2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    cint2.set_value(30);
	nb_id_t cint3 = nb_id_t(NBID_TYPE_OBJECT_INT);
	cint3.set_value(4);

    impl_data.constants.push_back(cint1);
    impl_data.constants.push_back(cint2);
	impl_data.constants.push_back(cint3);

  	//*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
    //************* paths *****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ int0 -> node0:add }
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ int1 -> node0:add }
	impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:add -> node1:sub } 
	impl_data.paths.push_back(create_path(-2, 2, 1, 1));//path3{ int2 -> node1:sub }
	impl_data.paths.push_back(create_path( 1, 0,-3, 0));//path4{ node1:sub -> OUT }
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_bool(const host_committer_id_t& hc_id,
		const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

    //*************** constants ****************//
    nb_id_t bTest1 = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    bTest1.set_value(true);
    nb_id_t bTest2 = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    bTest2.set_value(true);
    
    impl_data.constants.push_back(bTest1);
    impl_data.constants.push_back(bTest2);

    //*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, NB_FUNC_BOOL_AND));
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, NB_FUNC_BOOL_NOT));
    //************* paths *****************//
    impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ bool0 -> node0:and }
    impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ bool1 -> node0:and }
    impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:and -> node1:not }
    impl_data.paths.push_back(create_path( 1, 0,-3, 0));//path3{ node1:not -> OUT }
   
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

	return true;
}

bool generate_impl_float(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** constants ****************//
    nb_id_t cont1 = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    cont1.set_value(2.0f);
    nb_id_t cont2 = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    cont2.set_value(5.0f);

    impl_data.constants.push_back(cont1);
    impl_data.constants.push_back(cont2);

  	//*************** nodes ****************//
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_FLOAT_ADD)));

    //************* paths *****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ float0 -> node0:add }
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ float1 -> node0:add }
	impl_data.paths.push_back(create_path(0, 0, -3, 0));//path2{ node0:add -> OUT }
	// generate out path info
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_string(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   //*************** constants ****************//
    request_nb_id_info string_info;
    string_info.type = NBID_TYPE_OBJECT_STRING;
    string_info.committer_id = hc_id;

    // const0 : str
    std::string str0 = "aa aa";
    obj_impl_string::pack(str0, nb_id_t(), string_info.raw_data);
    nb_id_t const0;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const0);
    // const1 : str
    std::string str1 = "tout le monde 1.";
    obj_impl_string::pack(str1, nb_id_t(), string_info.raw_data);
    nb_id_t const1;
    ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, const1);
	// const2 : int
	nb_id_t const2(NBID_TYPE_OBJECT_INT);
	const2.set_value(3);
	// const3 : int
	nb_id_t const3(NBID_TYPE_OBJECT_INT);
	const3.set_value(8);

	impl_data.constants.push_back(const0);
    impl_data.constants.push_back(const1);
	impl_data.constants.push_back(const2);
	impl_data.constants.push_back(const3);

   	//*************** nodes ****************//
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_APPEND)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SUBSTR)));
    //*************** paths ****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));//str1->[apend]
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));//str2->[apend]
	impl_data.paths.push_back(create_path( 0, 0, 1, 0));//[apend]->[substr]
	impl_data.paths.push_back(create_path(-2, 2, 1, 1));//int1->[substr]
	impl_data.paths.push_back(create_path(-2, 3, 1, 2));//int2->[substr]
	impl_data.paths.push_back(create_path( 1, 0,-3, 0));//[substr]->OUT
	// 
	generate_out_path_info(impl_data);
    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_array(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   //*************** constants ****************//
    //// const0 : array 
    /////////////////////////// int object in array
    //nb_id_t int0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int0.set_value(10);
    //nb_id_t int1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int1.set_value(20);

    /////////////////////////// user object in array
    // user function
    //func_pair_t func_item;
    //generate_decl_comp(hc_id, func_item.declaration_id);
    //generate_impl_int(hc_id, 
    //        func_item.declaration_id, 
    //        func_item.implementation_id);

    //// user interface
    //if_compound_data_t user_if;
    //nb_id_t if_id;

    //user_if.name = "user interface";
    //user_if.decls.push_back(func_item.declaration_id);

    //generate_interface_compound(hc_id, user_if, if_id);

    //// user descriptor
    //descriptor_data_t dp_data;
    //nb_id_t dp_id;

    //dp_data.name = "user descriptor";
    //dp_data.funcs.push_back(func_item);
    //dp_data.subobj_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));
    //dp_data.subobj_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));

    //generate_descriptor(hc_id, dp_data, dp_id);

    //user_data_t user_data;
    //nb_id_t const1;

    //user_data.name = "user";
    //user_data.descriptor = dp_id;
    //user_data.interface = if_id;

    //nb_id_t sub1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //sub1.set_value(10);
    //nb_id_t sub2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //sub2.set_value(20);
    //user_data.subobjs.push_back(sub1);
    //user_data.subobjs.push_back(sub2);

    //generate_user(hc_id, user_data, const1);

    /////////////////////////// array(int) object in array
    //nb_id_vector ints;
    //nb_id_t int0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int0.set_value(10);
    //nb_id_t int1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int1.set_value(20);
    //ints.push_back(int0);
    //ints.push_back(int1);

    //nb_id_t const1;
    //nb_id_t array_type;
    //generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), ints, const1, array_type);

    //nb_id_vector objs;
    //nb_id_t const0;

    // array type 
    //nb_id_t type_id;

    //array_type.name = "user interface";
    //array_type.decls.push_back(func_item.declaration_id);
    //generate_interface_compound(hc_id, array_type, type_id);

    //generate_array(hc_id, array_type, objs, const0, type_id);

	// const1 : 
    //int
	//nb_id_t const1(NBID_TYPE_OBJECT_INT);
    //const1.set_value(30);

    /////////////////////////// bridge object in array
    // bridge interface
    bridge_interface_data_t if_data;
    nb_id_t if_id;
    ////int
    if_data.sub_interfaces.push_back(nb_id_t(NB_INTERFACE_INT));
    ////array
    nb_id_vector ints;
    nb_id_t int0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int0.set_value(10);
    nb_id_t int1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int1.set_value(20);
    ints.push_back(int0);
    ints.push_back(int1);
    nb_id_t array_id;
    nb_id_t array_type;
    generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), ints, array_id, array_type);
    if_data.sub_interfaces.push_back(array_type);

    generate_interface_bridge(hc_id, if_data, if_id);

    nb_id_vector objs;
    nb_id_t const0;
    nb_id_t type_id;
    generate_array(hc_id, if_id, objs, const0, type_id);

	impl_data.constants.push_back(const0);

    nb_id_t const1;
    //generate_bridge(hc_id, const1);
    nb_id_t bg_if_id;
    generate_interface_bridge(hc_id, if_data, bg_if_id);
    nb_id_t bg0; 
    nb_id_t bd_if;
    generate_bridge(hc_id, bg0, bd_if);
    nb_id_vector in_array_objs;
    nb_id_t in_array_type;
    in_array_objs.push_back(bg0);
    generate_array(hc_id, bg_if_id, in_array_objs, const1, in_array_type);

    impl_data.constants.push_back(const1);

   	//*************** nodes ****************//
	//impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_ARRAY_ADDHEAD)));
	impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_ARRAY_JOIN)));

    //*************** paths ****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));
	impl_data.paths.push_back(create_path(0, 0, -3, 0));
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_impl_map(const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    impl_data.name = "implementation";
    impl_data.out_port_size = 1;
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    impl_data.external_decl = decl_id;
    impl_data.handlesException = NB_EXCEPTION_NO; 

   //*************** constants ****************//
    // const0 :  
    ///////////////////////// key,value  in map 
    nb_id_vector arr_objs;
    nb_id_t key_id, key_type;
    generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), arr_objs, key_id, key_type);
    nb_id_t val_id, val_type;
    generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), arr_objs, val_id, val_type);

    nb_id_t const0;
    nb_id_t map_tp;
    nb_id_multimap map_objs;
    generate_map(hc_id, 
            key_type, 
            val_type, 
            map_objs, const0, map_tp);

    // const1 : key
    nb_id_vector c1_objs;
    nb_id_t int10 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int10.set_value(11);
    nb_id_t int11 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int11.set_value(22);
    c1_objs.push_back(int10);
    c1_objs.push_back(int11);

    nb_id_t const1, c1_type;
    generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), c1_objs, const1, c1_type);

    // const2 : value
    nb_id_vector c2_objs;
    nb_id_t int20 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int20.set_value(111);
    nb_id_t int21 = nb_id_t(NBID_TYPE_OBJECT_INT);
    int21.set_value(222);
    c2_objs.push_back(int20);
    c2_objs.push_back(int21);

    nb_id_t const2, c2_type;
    generate_array(hc_id, nb_id_t(NB_INTERFACE_INT), c2_objs, const2, c2_type);


    impl_data.constants.push_back(const0);
    impl_data.constants.push_back(const1);
    impl_data.constants.push_back(const2);

   	//*************** nodes ****************//
    sleep(1);

    object_ids builtin_ins;
    ptrHelper->ac_object_get_property(map_tp, nb_id_t(NB_FUNC_INTERFACE_GET_BUILTIN_INS), builtin_ins);

    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, 
                get_builtin_compound_instruction(map_tp, "insert")));
    impl_data.nodes.push_back(generate_exec_obj_func(hc_id, 
                get_builtin_compound_instruction(map_tp, "get")));

    //*************** paths ****************//
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));
	impl_data.paths.push_back(create_path(-2, 2, 0, 2));
	impl_data.paths.push_back(create_path(0, 0, 1, 0));
	impl_data.paths.push_back(create_path(-2, 1, 1, 1));
	impl_data.paths.push_back(create_path(1, 0, -3, 0));
	generate_out_path_info(impl_data);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(hc_id, impl_info, impl_id);

    return true;
}

bool generate_user(host_committer_id_t host_committer_id, 
        const nb_id_vector& decls,
        const nb_id_vector& sub_ifs,
        const nb_id_vector& sub_objs,
        nb_id_t& user_id,
        nb_id_t& if_id)
{
    // user function
    func_pair_t func_item;
    func_item.declaration_id = decls[0];
    generate_impl_int(host_committer_id, 
            func_item.declaration_id, 
            func_item.implementation_id);

    // user interface
    if_compound_data_t user_if;

    user_if.name = "user interface";
    user_if.type = nb_id_t(NB_INTERFACE_USER);
    user_if.decls.push_back(func_item.declaration_id);

    generate_interface_compound(host_committer_id, user_if, if_id);

    // user descriptor
    descriptor_data_t dp_data;
    nb_id_t dp_id;

    //// int interface
    dp_data.name = "user descriptor";
    dp_data.funcs.push_back(func_item);
    dp_data.subobj_interfaces = sub_ifs;

    generate_descriptor(host_committer_id, dp_data, dp_id);

    // user
    user_data_t user_data;

    user_data.name = "user";
    user_data.descriptor = dp_id;
    user_data.interface = if_id;

    user_data.subobjs = sub_objs;

    request_nb_id_info user_info;
    user_info.type = NBID_TYPE_OBJECT_USER;
    user_info.committer_id = host_committer_id;
    obj_impl_user::pack(user_data, nb_id_t(), user_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, user_info, user_id);

    return true;
}

bool generate_impl_user(const host_committer_id_t& host_committer_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    // name 
    impl_data.name = "user implementation";

    // out port size
    impl_data.out_port_size = 1;

    // master
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);

    // external declaration 
    impl_data.external_decl = decl_id;

    // exception
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** user constants ****************//
    nb_id_t declaration;
    generate_decl_comp(host_committer_id, declaration);

    nb_id_t const0;
    nb_id_vector c0_sub_ifs;
    nb_id_vector c0_sub_objs;

    // int interface
    c0_sub_ifs.push_back(nb_id_t(NB_INTERFACE_INT));

    // array type
    //nb_id_vector array_objs;
    //nb_id_t ay_id, ay_tp;
    //generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), array_objs, ay_id, ay_tp);
    //sub_ifs.push_back(ay_tp);

    // user interface
    func_pair_t func_item;
    func_item.declaration_id = declaration;
    generate_impl_int(host_committer_id, 
            func_item.declaration_id, 
            func_item.implementation_id);

    // user interface
    if_compound_data_t c0_if_sub2_logic;
    nb_id_t c0_if_sub2_if;

    c0_if_sub2_logic.name = "user interface";
    c0_if_sub2_logic.type = nb_id_t(NB_INTERFACE_USER);
    c0_if_sub2_logic.decls.push_back(func_item.declaration_id);

    generate_interface_compound(host_committer_id, c0_if_sub2_logic, c0_if_sub2_if);

    c0_sub_ifs.push_back(c0_if_sub2_if);

    //// sub1
    nb_id_t c0_sub1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    c0_sub1.set_value(11);
    c0_sub_objs.push_back(c0_sub1);

    //// sub2 
    //////array
    //nb_id_vector sub2_objs;
    //nb_id_t obj1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //obj1.set_value(22);
    //nb_id_t obj2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //obj2.set_value(33);
    //sub2_objs.push_back(obj1);
    //sub2_objs.push_back(obj2);
    //nb_id_t sub2, sub2_tp;
    //generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), sub2_objs, sub2, sub2_tp);
    //////user
    nb_id_t c0_sub2;
    nb_id_vector c0_sub2_sub_ifs;
    nb_id_vector c0_sub2_sub_objs;

    c0_sub2_sub_ifs.push_back(nb_id_t(NB_INTERFACE_INT));
    nb_id_t c0_sub2_int0 = nb_id_t(NB_INTERFACE_INT);
    c0_sub2_int0.set_value(22);
    c0_sub2_sub_objs.push_back(c0_sub2_int0);
    nb_id_t c0_sub2_if;

    nb_id_t c0_sub2_decl;
    nb_id_vector c0_sub2_decls;
    generate_decl_comp(host_committer_id, c0_sub2_decl);
    c0_sub2_decls.push_back(c0_sub2_decl);

    generate_user(host_committer_id, c0_sub2_decls, c0_sub2_sub_ifs, c0_sub2_sub_objs, c0_sub2, c0_sub2_if);
    c0_sub_objs.push_back(c0_sub2);

    nb_id_t c0_if;
    nb_id_t c0_decl;
    nb_id_vector c0_decls;
    generate_decl_comp(host_committer_id, c0_decl);
    c0_decls.push_back(c0_decl);
    generate_user(host_committer_id, c0_decls, c0_sub_ifs, c0_sub_objs, const0, c0_if);

    impl_data.constants.push_back(const0);

    //const1
    nb_id_t const1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    const1.set_value(111);

    //const2
    //// array
    //nb_id_vector cont2_objs;
    //nb_id_t cobj1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //cobj1.set_value(222);
    //nb_id_t cobj2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //cobj2.set_value(333);
    //cont2_objs.push_back(cobj1);
    //cont2_objs.push_back(cobj2);
    //nb_id_t const2, const2_tp;
    //generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), cont2_objs, const2, const2_tp);
    //////user
    nb_id_t const2;
    nb_id_vector const2_sub_ifs;
    nb_id_vector const2_sub_objs;

    const2_sub_ifs.push_back(nb_id_t(NB_INTERFACE_INT));
    nb_id_t const2_int0 = nb_id_t(NB_INTERFACE_INT);
    const2_int0.set_value(222);
    const2_sub_objs.push_back(const2_int0);
    nb_id_t c2_if;
    nb_id_vector decls;
    decls.push_back(declaration);
    generate_user(host_committer_id, decls, const2_sub_ifs, const2_sub_objs, const2, c2_if);

    impl_data.constants.push_back(const1);
    impl_data.constants.push_back(const2);

  	//*************** user nodes ****************//
    // custom function
    sleep(1);

    object_ids builtin_ins;
    ptrHelper->ac_object_get_property(c0_if, nb_id_t(NB_FUNC_INTERFACE_GET_BUILTIN_INS), builtin_ins);

    for (size_t i = 0;i < builtin_ins.ids.size();++i)
    {
        content decl_raw;
        ptrHelper->ac_object_get_value_sync(builtin_ins.ids[i], decl_raw);
        nb_id_t temp_decl_id;
        decl_compound_data_t decl_logic;
        obj_impl_decl_compound::unpack(decl_raw, temp_decl_id, decl_logic);

        if (decl_logic.name == "user_compose")
        {
            impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
                        builtin_ins.ids[i]));
            break;
        
        }
    }
    //impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
    //            func_item.declaration_id));

    // builtin function
    //impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
    //            nb_id_t(NB_FUNC_USER_DECOMPOSE)));

    //************* paths *****************//
	// node0
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));
	impl_data.paths.push_back(create_path(-2, 2, 0, 2));
	impl_data.paths.push_back(create_path(0, 0, -3, 0));

	// save all out_paths to facilitate resolve
    out_port_path_idx_t out_path0;
    out_path0.out_port = 0;
    out_path0.path_idxs.push_back(1);
    impl_data.out_paths.push_back(out_path0);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = host_committer_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, impl_info, impl_id);

    return true;
}

bool generate_impl_bridge(const host_committer_id_t& host_committer_id, 
        const nb_id_t& decl_id, nb_id_t& impl_id)
{
    exec_impl_graph_t impl_data;
    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    // name 
    impl_data.name = "bridge implementation";

    // out port size
    impl_data.out_port_size = 1;

    // master
    impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);

    // external declaration 
    impl_data.external_decl = decl_id;

    // exception
    impl_data.handlesException = NB_EXCEPTION_NO; 

   	//*************** bridge constants ****************//
    // const0 
    bridge_interface_data_t c0_if_data;
    nb_id_t c0_sub_if;
    nb_id_t c0_sub;
    generate_bridge(host_committer_id, c0_sub, c0_sub_if);
    c0_if_data.sub_interfaces.push_back(c0_sub_if);

    // request defination id
    request_nb_id_info c0_if_info;
    nb_id_t c0_if;
    c0_if_info.type = NBID_TYPE_OBJECT_BRIDGE_INTERFACE;
    c0_if_info.committer_id = host_committer_id;
    obj_impl_bridge_interface::pack(c0_if_data, nb_id_t(), c0_if_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, c0_if_info, c0_if);

    bridge_data_t c0_data;
    c0_data.interface = c0_if;

    request_nb_id_info c0_info;
    nb_id_t const0;
    c0_info.type = NBID_TYPE_OBJECT_BRIDGE;
    c0_info.committer_id = host_committer_id;
    obj_impl_bridge::pack(c0_data, nb_id_t(), c0_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, c0_info, const0);

    impl_data.constants.push_back(const0);

    // const1
    nb_id_t const1_if;
    nb_id_t const1;
    generate_bridge(host_committer_id, const1, const1_if);
    impl_data.constants.push_back(const1);

    //nb_id_t const1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //const1.set_value(11);
    //impl_data.constants.push_back(const1);

    // const2
    //nb_id_t const2;
    //nb_id_vector ints;
    //nb_id_t int0 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int0.set_value(22);
    //nb_id_t int1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    //int1.set_value(33);
    //ints.push_back(int0);
    //ints.push_back(int1);
    //nb_id_t array_id;
    //nb_id_t array_type;
    //generate_array(host_committer_id, nb_id_t(NB_INTERFACE_INT), ints, const2, array_type);
    //impl_data.constants.push_back(const2);
  	//*************** bridge nodes ****************//
    // builtin function
    sleep(1);

    object_ids builtin_ins;
    ptrHelper->ac_object_get_property(c0_if, nb_id_t(NB_FUNC_INTERFACE_GET_BUILTIN_INS), builtin_ins);

    for (size_t i = 0;i < builtin_ins.ids.size();++i)
    {
        content decl_raw;
        ptrHelper->ac_object_get_value_sync(builtin_ins.ids[i], decl_raw);
        nb_id_t temp_decl_id;
        decl_compound_data_t decl_logic;
        obj_impl_decl_compound::unpack(decl_raw, temp_decl_id, decl_logic);

        if (decl_logic.name == "bridge_compose")
        {
            impl_data.nodes.push_back(generate_exec_obj_func(host_committer_id, 
                        builtin_ins.ids[i]));
            break;
        }
    }

    //************* paths *****************//
	// node0
	impl_data.paths.push_back(create_path(-2, 0, 0, 0));
	impl_data.paths.push_back(create_path(-2, 1, 0, 1));
	//impl_data.paths.push_back(create_path(-2, 2, 0, 2));
	impl_data.paths.push_back(create_path(0, 0, -3, 0));

	// save all out_paths to facilitate resolve
    out_port_path_idx_t out_path0;
    out_path0.out_port = 0;
    out_path0.path_idxs.push_back(1);
    impl_data.out_paths.push_back(out_path0);

    // request implementation id
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = host_committer_id;
    obj_impl_exec_impl::pack(impl_data, nb_id_t(), impl_info.raw_data);

    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, impl_info, impl_id);

    return true;
}

bool generate_implementation(const impl_graph_define_t graph_define,
        const host_committer_id_t& hc_id, 
        const nb_id_t& decl_id, 
        nb_id_t& impl_id)
{
    switch(graph_define)
    {
        case GRAPH_NODE_INT:
            generate_impl_int(hc_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_BOOL:
            generate_impl_bool(hc_id, decl_id, impl_id);
            break;
		case GRAPH_NODE_FLOAT:
			generate_impl_float(hc_id, decl_id, impl_id);
			break;
        case GRAPH_NODE_STRING:
            generate_impl_string(hc_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_USER:
            generate_impl_user(hc_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_ARRAY:
            generate_impl_array(hc_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_BRIDGE:
            generate_impl_bridge(hc_id, decl_id, impl_id);
            break;
        case GRAPH_NODE_MAP:
            generate_impl_map(hc_id, decl_id, impl_id);
            break;
    }
    return true;
}

bool generate_container_defination(host_committer_id_t host_committer_id, nb_id_t& cd_id)
{
    cont_def_data_t cd_data;

    // name 
    cd_data.name = "container_defination";

    // anchor info 
    anchor_info_t an_item;
    an_item.name = "int";
    an_item.registed = true;

    func_pair_t func_item;
    generate_decl_comp(host_committer_id, func_item.declaration_id);
    generate_implementation(IMPL_GRAPH_DEFINE,
            host_committer_id, 
            func_item.declaration_id, 
            func_item.implementation_id);
    an_item.funcs.push_back(func_item);
    cd_data.anchors.push_back(an_item);

    // storages 
    cd_data.storages.push_back(NBID_TYPE_STORAGE_MULTIVALUE);
    cd_data.storages.push_back(NBID_TYPE_STORAGE_SIMPLE);

    // request defination id
    request_nb_id_info cd_info;
    cd_info.type = NBID_TYPE_OBJECT_CONTAINER_DEF;
    cd_info.committer_id = host_committer_id;
    obj_impl_container_def::pack(cd_data, nb_id_t(), cd_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_nb_id(host_committer_id, cd_info, cd_id);

    return true;
}

bool generate_anchor(host_committer_id_t host_committer_id, 
        nb_id_t& decl_id, 
        anchor_id_t& anchor_id)
{
    anchor_data_t an_data;

    // name 
    an_data.name = "anchor";

    // funcs
    func_pair_t func_item;
    func_item.declaration_id = decl_id; 
    generate_implementation(IMPL_GRAPH_DEFINE,
            host_committer_id, 
            decl_id, 
            func_item.implementation_id);
    an_data.funcs.push_back(func_item);

    an_data.registed = false;
    an_data.interface = nb_id_t(NBID_TYPE_OBJECT_INTERFACE_COMPOUND);
    an_data.parent_container = container_id_t();

    // request anchor id
    request_anchor_id_info an_info;
    anchor_implementation::pack(an_data, an_info.raw_data);

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_host_committer_request_anchor_id(host_committer_id, an_info, anchor_id);

    return true;
}

bool generate_container(host_committer_id_t host_committer_id, 
        const anchor_id_t& an_id,
        container_id_t& container_id,
        access_id_t& root_access_id)
{
    container_data_t cont_data;

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    
    // name 
    cont_data.name = "container";

    cont_data.anchors.push_back(an_id);

    request_alone_container_id_info cont_info;
    cont_info.committer_id = host_committer_id;
    ptrHelper->ac_id_dispenser_request_alone_container_id(cont_info, container_id);

    con_content con_value;
    container_implementation::pack(cont_data, container_id, con_value);
    ac_actor *pActor = actor_factory(container_id, con_value);
    ac_manager::instance().add_actor(pActor, container_id);    

    // generate root access
    access_data_t rt_ac_data;
    rt_ac_data.name = "root_access";
    rt_ac_data.parent_container = container_id;

    request_access_id_info ac_info;
    access_implementation::pack(rt_ac_data, ac_info.raw_data);

    ptrHelper->ac_host_committer_request_access_id(host_committer_id, ac_info, root_access_id);

    return true;
}

void set_param_create_container(node_invocation_request * pParam)
{
    pParam->declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER); 
    nb_id_t cd_id;
    generate_container_defination(pParam->host_committer_id, cd_id);
    pParam->input.push_back(cd_id);
}

void set_param_generate_access_from_anchor(node_invocation_request * pParam)
{
    pParam->declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR); 
    nb_id_t an_idx = nb_id_t(NBID_TYPE_OBJECT_INT);
    an_idx.set_value(0);
    pParam->input.push_back(an_idx);
}

bool root_access_run()          
{
    access_id_t root_access_id;
    container_id_t container_id;
    host_committer_id_t host_committer_id;
    anchor_id_t an_id;

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));
    ptrHelper->ac_id_dispenser_request_host_committer_id(host_committer_id);

    // generate anchor 
    nb_id_t decl_in_an;
    generate_decl_comp(host_committer_id, decl_in_an);
    generate_anchor(host_committer_id, decl_in_an, an_id);
    generate_container(host_committer_id, an_id, 
            container_id, root_access_id);

    ac_id_t dest_id;
    if(!ac_manager::instance().request_actor(root_access_id))
        return false;

    if(!ac_manager::instance().get_ac_id(root_access_id, dest_id))
        return false;

    node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
    pParam->host_committer_id = host_committer_id;
    pParam->transaction_id = transaction_id_t();
    pParam->object_id = static_cast<nb_id_t>(root_access_id);

    // create container 
    set_param_create_container(pParam);

    // generate access from anchor
    //set_param_generate_access_from_anchor(pParam);

    return ac_manager::instance().send_asyn_message(dest_id, g_ac_object_acid, 1, e_ac_access_run, pParam);
};

void access_run()          
{
    nb_id_t decl_id;
    access_id_t root_access_id;
    container_id_t container_id;
    root_committer_id_t root_committer_id;
    center_committer_id_t center_committer_id;
    host_committer_id_t host_committer_id;
    anchor_id_t an_id;

    ac_obj_test_helper_ptr ptrHelper(new (std::nothrow) ac_obj_test_helper(g_ac_object_acid));

    // root commmitter, centre committer, host committer
    ptrHelper->ac_id_dispenser_request_root_committer_id(root_committer_id);
    ptrHelper->ac_id_dispenser_request_center_committer_id(center_committer_id);
    ptrHelper->ac_id_dispenser_request_host_committer_id(host_committer_id);

    ptrHelper->ac_root_committer_regist_center_committer(root_committer_id, 
            center_committer_id);
    ptrHelper->ac_center_committer_set_root_committer(center_committer_id, 
            root_committer_id);
    ptrHelper->ac_center_committer_regist_host_committer(center_committer_id, 
            host_committer_id);
    ptrHelper->ac_host_committer_set_center_committer(host_committer_id, 
            center_committer_id);

    // generate decl, anchor, container 
    generate_decl_comp(host_committer_id, decl_id);
    generate_anchor(host_committer_id, decl_id, an_id);
    generate_container(host_committer_id, an_id, 
            container_id, root_access_id);

    access_data_t ac_data;
    ac_data.name = "access";
    ac_data.parent_container = container_id;
    ac_data.anchor_idx = 0;

    request_alone_access_id_info ac_info;
    access_id_t access_id;
    content value;
    ac_info.type = NBID_TYPE_OBJECT_ACCESS;
    ac_info.committer_id = host_committer_id;
    ptrHelper->ac_id_dispenser_request_alone_access_id(ac_info, access_id);
    access_implementation::pack(ac_data, value);
    ac_actor *pActor = actor_factory(access_id, value);
    ac_manager::instance().add_actor(pActor, access_id);    
    g_ac_object_acid = reinterpret_cast<ac_id_t>(pActor);

    node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
    pParam->host_committer_id = host_committer_id;
    pParam->transaction_id = transaction_id_t();
    pParam->declaration_id = decl_id;
    pParam->object_id = static_cast<nb_id_t>(access_id);

    ac_manager::instance().send_asyn_message(g_ac_object_acid, g_ac_object_acid, 1, e_ac_access_run, pParam);
    
};

int main(int argc, char* argv[])
{

    nb_configuration config(argc, argv);
    config.dump_configuration();

	std::string cmd;
    if (1 >= argc)
        cmd = "help";/* default cmd */
	else
		cmd = argv[1];

	/* print help message */
	if (cmd == "help")
	{	
		std::cout << " Available Test Options : " << std::endl;
		std::cout << "  >> int " << std::endl;
		std::cout << "  >> string " << std::endl;
		std::cout << "  >> float " << std::endl;
		std::cout << "  >> user " << std::endl;
		std::cout << "  >> array " << std::endl;
		std::cout << "  >> bridge " << std::endl;
		std::cout << "  >> map " << std::endl;
		return 0;
	}

    if (cmd == "int")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_INT;
    else if (cmd == "bool")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_BOOL;
    else if (cmd == "string")
        IMPL_GRAPH_DEFINE = GRAPH_NODE_STRING;
    else if (cmd == "float" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_FLOAT;
    else if (cmd == "user" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_USER;
    else if (cmd == "array" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_ARRAY;
    else if (cmd == "bridge" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_BRIDGE;
    else if (cmd == "map" )
    	IMPL_GRAPH_DEFINE = GRAPH_NODE_MAP;

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    //Start ac_framework
    ac_framework framework(config.get_actor_thread_pool(), 
                           config.get_is_statistics(), 
                           config.get_statistics_interval());
    framework.init_framework();

    framework.run();

    ///////////// message handles

    // test access run 
    access_run();

    ///////////// message handles

    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
