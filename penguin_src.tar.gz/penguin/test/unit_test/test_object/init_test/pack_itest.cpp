/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <iostream>
#include <iomanip>

#include "ac_global.h"
#include "nb_id.h"

#include "anchor_implementation.h"
#include "access_implementation.h"
#include "container_implementation.h"
#include "ac_object/obj_impl_exec_impl.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/object_data.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_container_def.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_bytes.h"
#include "../../../framework/include/ac_global_db.h"

ac_id_t g_ac_object_acid = 0;

// Generate a hex string id of defined digits
std::string generate_string_id(int digits)
{
	std::string charset("0123456789ABCDEF");
	std::string strid;
	strid.clear();
	for( int i=0; i<digits; i++ )
	{
		strid.push_back(charset[rand()%16]);
	}

	//strid.push_back('\0');

	return strid;
}

// Generate  nb_id_t for testing
nb_id_t generate_test_nb_id()
{
    return nb_id_t(generate_string_id(32));
}

// Generate  anchor_id_t for testing
anchor_id_t generate_test_anchor_id()
{
	anchor_id_t test_id(generate_string_id(16));
	return test_id;
}

// Generate storage_id_t for testing
storage_id_t generate_test_storage_id()
{
	storage_id_t test_id(generate_string_id(16));
	return test_id;
}

// Generate container_id_t for testing
container_id_t generate_test_container_id()
{
	container_id_t test_id(generate_string_id(64));
	return test_id;
}

bool anchor_pack_unpack()
{	
	struct anchor_data_t test_data,retrieved;
	content raw_data_1;
	content raw_data_2;

	// construct test data
	test_data.name = "test_anchor";
	func_pair_t fp = { generate_test_nb_id(), generate_test_nb_id() };
	test_data.funcs.push_back(fp);
	test_data.registed = true;
	test_data.interface = generate_test_nb_id();
	test_data.parent_container = generate_test_container_id();
	
	// pack
	anchor_implementation::pack(test_data, raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;

    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);
    //raw_data_2.object_id = raw_data_1.object_id;

	// unpack
	anchor_implementation::unpack(raw_data_2, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

    return true;
}

bool container_pack_unpack()
{
	struct container_data_t test_data,retrieved;
	con_content raw_data_1;
	con_content raw_data_2;

	// construct test data
	test_data.name = "test_container";
	test_data.anchors.push_back(generate_test_anchor_id());
	test_data.storages.push_back(generate_test_storage_id());
	test_data.definition = generate_test_nb_id();

	// pack
	container_implementation::pack(test_data, container_id_t(), raw_data_1);

    //container_data_packer packer;
    //container_data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.container_id = raw_data_1.container_id;
    std::string strval = pack_container(raw_data_1);
    unpack_container(strval, raw_data_2);
    

	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
	// unpack
    container_id_t id; 
	container_implementation::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.container_id==raw_data_2.container_id);

    return true;
}

bool access_pack_unpack()
{
	struct access_data_t test_data,retrieved;
	content raw_data_1;
	content raw_data_2;

	// construct test data
	test_data.name = "test_access";
	test_data.anchor_idx = 1;
	test_data.parent_container = generate_test_container_id();
	test_data.interface = generate_test_nb_id();
	test_data.is_registed = true;

	// pack
	access_implementation::pack(test_data, raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);
    //raw_data_2.object_id = raw_data_1.object_id;

	// unpack
	access_implementation::unpack(raw_data_2, retrieved);

	// check equality
	assert(test_data == retrieved);	
    assert(raw_data_1.object_id==raw_data_2.object_id);


	// check equality
	assert(test_data == retrieved);	


    return true;
}

bool decl_compound_pack_unpack()
{
	struct decl_compound_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_decl_compound";
	iport_t iport = { "test_iport", generate_test_nb_id(), generate_test_nb_id() };
	test_data.iports.push_back(iport);
	oport_t oport = { "test_oport", generate_test_nb_id() };
	test_data.oports.push_back(oport);
	decl_exp_group exp_group;
	exp_group.name = "test_decl_exp_group";
	exp_group.min_if = generate_test_nb_id();
	decl_exp_idx exp_idx = { true, 1, 1 };
	exp_group.members.push_back( exp_idx );
	exp_group.expanded = true;
	test_data.groups.push_back(exp_group);

	// pack
	obj_impl_decl_compound::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);
    //raw_data_2.object_id = raw_data_1.object_id;

	// unpack
    nb_id_t id;
	obj_impl_decl_compound::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);
	
    return true;
}

bool implementation_pack_unpack()
{
	struct exec_impl_graph_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_exec_impl";
	test_data.out_port_size = 3;
	test_data.master = generate_test_nb_id();
	test_data.external_decl = generate_test_nb_id();
	test_data.handlesException = NB_EXCEPTION_NORMAL;
	test_data.constants.push_back(generate_test_nb_id());
	test_data.nodes.push_back(generate_test_nb_id());
	struct node_path_t t1 = {1,1,2,2};
	struct node_path_t t2 = {2,2,3,3};
	test_data.paths.push_back(t1);
	test_data.paths.push_back(t2);
	struct out_port_path_idx_t p;
	p.out_port = 1;
	p.path_idxs.push_back(1);
	p.path_idxs.push_back(2);
	test_data.out_paths.push_back(p);

	// pack
	obj_impl_exec_impl::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);
    //raw_data_2.object_id = raw_data_1.object_id;

	// unpack
    nb_id_t id;
	obj_impl_exec_impl::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

    return true;
}


bool array_pack_unpack()
{
    struct array_data_t srcArr;
    struct array_data_t desArr;
    content raw_data;
    
    srcArr.interface = generate_test_nb_id();
    srcArr.type = generate_test_nb_id();
    srcArr.objs.push_back(generate_test_nb_id());
    
    //std::cout << srcArr.interface.str() << std::endl;
    //std::cout << srcArr.type.str() << std::endl;
    //std::cout << srcArr.objs[0].str() << std::endl;
    
    obj_impl_array::pack(srcArr, nb_id_t(), raw_data);
    std::string strval(raw_data.id_value.values[0].begin(),raw_data.id_value.values[0].end() );
    std::cout << strval << std::endl;
    
    nb_id_t id;
    obj_impl_array::unpack(raw_data, id, desArr);
    assert(desArr==srcArr);
    //std::cout << desArr.interface.str() << std::endl;
    //std::cout << desArr.type.str() << std::endl;
    //std::cout << desArr.objs[0].str() << std::endl;
    
    return true;
}


bool bridge_pack_unpack()
{
    struct bridge_data_t src;
    struct bridge_data_t des;
    content raw_data;
    
    src.name = "bridge_data_t_src";
    src.descriptor = generate_test_nb_id();
    src.interface = generate_test_nb_id();
    src.subobjs.push_back(generate_test_nb_id());
    src.sub_names.push_back(generate_string_id(17));
    
    //std::cout << src.name << std::endl;
    //std::cout << src.descriptor.str() << std::endl;
    //std::cout << src.interface.str() << std::endl;
    //std::cout << src.subobjs[0].str() << std::endl;
    //std::cout << src.sub_names[0] << std::endl;
    
    obj_impl_bridge::pack(src, nb_id_t(), raw_data);
    std::string strval(raw_data.id_value.values[0].begin(),raw_data.id_value.values[0].end() );
    std::cout << strval << std::endl;
    
    nb_id_t id;
    obj_impl_bridge::unpack(raw_data, id, des);
    assert(src.name==des.name);
    assert(src.descriptor==des.descriptor);
    assert(src.interface==des.interface);
    assert(src.subobjs[0]==des.subobjs[0]);
    //assert(src.sub_names[0].size()==des.sub_names[0].size());
    assert(src.sub_names[0]==des.sub_names[0]);
    //std::cout << src.sub_names[0].compare(des.sub_names[0]) << std::endl;
    //assert(src.sub_names[0].compare(des.sub_names[0])==0);
    //std::cout << des.name << std::endl;
    //std::cout << des.descriptor.str() << std::endl;
    //std::cout << des.interface.str() << std::endl;
    //std::cout << des.subobjs[0].str() << std::endl;
    //std::cout << des.sub_names[0] << std::endl;
    
    return  true;
}



bool exec_obj_func_pack_unpack()
{
	struct exec_obj_func_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_exec_obj_func";
    test_data.owner = generate_test_nb_id();
	test_data.selected_decl = generate_test_nb_id();
	test_data.recoverer = generate_test_nb_id();
	test_data.postcut = true;

	// pack
	obj_impl_exec_obj_func::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_exec_obj_func::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);
	
	return true;
}


bool bridge_interface_pack_unpack()
{
    struct bridge_interface_data_t src;
    struct bridge_interface_data_t des;
    struct content raw_data;
    
    src.data_index = 888888;
    src.external_name = generate_string_id(8);
    src.sub_interfaces.push_back(generate_test_nb_id());
    src.sub_names.push_back(generate_string_id(8));
    
    //std::cout << src.data_index << std::endl;
    //std::cout << src.external_name << std::endl;
    //std::cout << src.sub_interfaces[0].str() << std::endl;
    //std::cout << src.sub_names[0] << std::endl;
    
    obj_impl_bridge_interface::pack(src, nb_id_t(), raw_data);
    std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    std::cout << strval << std::endl;
    
    nb_id_t id;
    obj_impl_bridge_interface::unpack(raw_data, id, des);
    assert(src==des);
    
    //std::cout << src.data_index << std::endl;
    //std::cout << src.external_name << std::endl;
    //std::cout << src.sub_interfaces[0].str() << std::endl;
    //std::cout << src.sub_names[0] << std::endl;
    
    return true;
}

bool exec_anchor_func_pack_unpack()
{	
	struct exec_anchor_func_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_exec_anchor_func";
	test_data.anchor_idx = 1;
	test_data.selected_decl = generate_test_nb_id();
	test_data.recoverer = generate_test_nb_id();
	test_data.postcut = true;

	// pack
	obj_impl_exec_anchor_func::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_exec_anchor_func::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);
	
	return true;
}

bool exec_condition_pack_unpack()
{	
	struct exec_cond_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_exec_condition";
	test_data.external_decl = generate_test_nb_id();
	test_data.alternate_execs.push_back(generate_test_nb_id());
	test_data.alternate_execs.push_back(generate_test_nb_id());

	// pack
	obj_impl_exec_condition::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_exec_condition::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);
	
	return true;
}

bool exec_iterator_pack_unpack()
{	
	struct exec_iterator_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_exec_iterator";
	test_data.external_decl = generate_test_nb_id();
	test_data.repeated_exec = generate_test_nb_id();
	// pack
	obj_impl_exec_iterator::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_exec_iterator::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool exec_storage_func_pack_unpack()
{	
	struct exec_storage_func_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_storage_func";
	test_data.storage_idx = 2;
	test_data.selected_decl = generate_test_nb_id();
	// pack
	obj_impl_exec_storage_func::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_exec_storage_func::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool container_def_pack_unpack()
{
    struct cont_def_data_t  src;
    struct cont_def_data_t  des;
    struct content raw_data_1;
    struct content raw_data_2;
    
    //struct anchor_info_t sAr2;
    
    /*------construct struct anchor_info_t sAr----*/
    //src.name = generate_string_id(8);
    src.name = "hello";
    
    src.storages.push_back(NBID_TYPE_OBJECT_USER);
    src.storages.push_back(NBID_TYPE_OBJECT_BRIDGE);
    
    struct anchor_info_t sAr;
    struct anchor_info_t sAr2;
    //sAr.name = generate_string_id(6);
    sAr.name = "hello nebutown";
    sAr.registed = true;
    struct func_pair_t sPair = {generate_test_nb_id(), generate_test_nb_id()};
    sAr.funcs.push_back(sPair);
    sAr.interface = generate_test_nb_id();
    
    sAr2.name = generate_string_id(10);
    sAr2.name = "hello world";
    sAr2.registed = false;
    sAr2.funcs.push_back(sPair);
    sAr2.funcs.push_back(sPair);
    sAr2.interface = generate_test_nb_id();
    
    src.anchors.push_back(sAr);
    src.anchors.push_back(sAr2);
    
    /*-------------pack---------------*/
    obj_impl_container_def::pack(src, nb_id_t(), raw_data_1);
    
    //std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    //std::cout << strval << std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2= unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);
    
    /*------------unpack-------------*/
    nb_id_t id;
    obj_impl_container_def::unpack(raw_data_2, id, des);
    
    assert(src.name==des.name);
    for(unsigned i=0; i<src.storages.size(); ++i)
    {
        assert(src.storages[i]==des.storages[i]);
    }
    for(unsigned i=0; i<src.anchors.size(); ++i)
    {
        assert(src.anchors[i].name==des.anchors[i].name);
        assert(src.anchors[i].registed==des.anchors[i].registed);
        for(unsigned j=0; j<src.anchors[i].funcs.size(); ++j)
        {            
            assert(src.anchors[i].funcs[j].declaration_id==des.anchors[i].funcs[j].declaration_id);
            assert(src.anchors[i].funcs[j].implementation_id==des.anchors[i].funcs[j].implementation_id);
        }
        assert(src.anchors[i].interface==des.anchors[i].interface);
    }
    assert(raw_data_1.object_id==raw_data_2.object_id);
            
    return true;
}


bool user_pack_unpack()
{	
	struct user_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_user";
	test_data.descriptor = generate_test_nb_id();
	test_data.interface = generate_test_nb_id();
	test_data.water_mark = "test_user_water_mark";
	test_data.subobjs.push_back(generate_test_nb_id());
	test_data.subobjs.push_back(generate_test_nb_id());
	// pack
	obj_impl_user::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_user::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool string_pack_unpack()
{
	std::string test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data = "test_string";
	test_data = "test_string1\ntest_string2\0";
	// pack
	obj_impl_string::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_string::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool interface_compound_pack_unpack()
{	
	struct if_compound_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_interface_compound";
	test_data.is_singleton = true;
	test_data.decls.push_back(generate_test_nb_id());
	test_data.decls.push_back(generate_test_nb_id());

    if_exp_group exp_group1;
	exp_group1.name = "test_if_exp_group1";
	exp_group1.min_if = generate_test_nb_id();

	if_exp_idx exp_idx1 = {1, 1};
	if_exp_idx exp_idx2 = {2, 3};
	exp_group1.members.push_back(exp_idx1);
	exp_group1.members.push_back(exp_idx2);
	exp_group1.expanded = true;

	test_data.groups.push_back(exp_group1);

	if_exp_group exp_group2;
	exp_group2.name = "test_if_exp_group2";
	exp_group2.min_if = generate_test_nb_id();
	exp_group2.expanded = false;
	if_exp_idx exp_idx3 = {0, 10000};
	exp_group2.members.push_back(exp_idx3);
	test_data.groups.push_back(exp_group2);
	// pack
	obj_impl_interface_compound::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_interface_compound::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool descriptor_pack_unpack()
{
	struct descriptor_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.name = "test_descriptor";
    func_pair_t pair;
    pair.declaration_id = nb_id_t();
    pair.implementation_id = nb_id_t();
	test_data.funcs.push_back(pair);
	test_data.subobj_interfaces.push_back(generate_test_nb_id());
	test_data.subobj_interfaces.push_back(generate_test_nb_id());
	// pack
	obj_impl_descriptor::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_descriptor::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

bool map_pack_unpack()
{
	struct map_data_t test_data,retrieved;
	content raw_data_1;
    content raw_data_2;

	// construct test data
	test_data.interface = generate_test_nb_id();
	test_data.type = generate_test_nb_id();
//	test_data.vtype = generate_test_nb_id();
	nb_id_t test_int(NB_INTERFACE_INT);
	test_int.set_value(5);
	test_data.data.insert(std::make_pair(test_int, generate_test_nb_id()));
	test_data.data.insert(std::make_pair(test_int, generate_test_nb_id()));//same key,different value
	test_data.data.insert(std::make_pair(generate_test_nb_id(), generate_test_nb_id()));
	// pack
	obj_impl_map::pack(test_data, nb_id_t(), raw_data_1);
	// output packed string
	//std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
	//std::cout<< strval <<std::endl;
    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

	// unpack
    nb_id_t id;
	obj_impl_map::unpack(raw_data_2, id, retrieved);
	// check equality
	assert(test_data == retrieved);
    assert(raw_data_1.object_id==raw_data_2.object_id);

	return true;
}

void test_msg(const std::string& msg)
{
	const int width = 80;
	std::cout << std::endl;
	std::cout << std::string(width, '#') << std::endl;
	std::cout << std::endl;
	std::cout << msg << std::endl;
	std::cout << std::endl;
	std::cout << std::string(width, '-') << std::endl;
}


//################################################################//
//atom pack and unpack test 
//################################################################//

//obj_impl_bridge::pack and obj_impl_bridge::unpack
bool  Atom_bridge_pack_and_unpack()
{
    bridge_data_t source_data; 
    bridge_data_t des_data;
    content  raw_data_1;   
    content raw_data_2;

    source_data.name = "bridge_data_t";
    source_data.descriptor = generate_test_nb_id();
    source_data.interface = generate_test_nb_id();
    source_data.subobjs.push_back(generate_test_nb_id());
    source_data.sub_names.push_back("hello nebutown");

    nb_id_t temp(  NBID_TYPE_OBJECT_BRIDGE );
    obj_impl_bridge::pack( source_data, temp, raw_data_1 );

    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

    obj_impl_bridge::unpack(raw_data_2, temp, des_data);

    assert(source_data==des_data);
    assert(raw_data_1.object_id==raw_data_2.object_id);
    return true;
}

bool Atom_array_pack_and_unpack()
{
    array_data_t source_data;
    array_data_t des_data;
    content raw_data_1;   
    content raw_data_2;

    source_data.interface = generate_test_nb_id();
    source_data.type = generate_test_nb_id();
    source_data.objs.push_back( generate_test_nb_id() );
    source_data.objs.push_back( generate_test_nb_id() );

    nb_id_t temp(  NBID_TYPE_OBJECT_ARRAY );
    obj_impl_array::pack( source_data, temp, raw_data_1 );

    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

    obj_impl_array::unpack( raw_data_2, temp, des_data );

    assert( source_data==des_data );
    assert(raw_data_1.object_id==raw_data_2.object_id);
    return true;
}

bool Atom_bridge_interface_pack_and_unpack()
{
    bridge_interface_data_t source_data;
    bridge_interface_data_t des_data; 
    content raw_data_1;
    content raw_data_2;

    source_data.bf_id.str("12345678909876543210012345678912");
    source_data.data_index = 88;
    source_data.external_name = "hello nebutown";
    source_data.sub_interfaces.push_back( generate_test_nb_id() );
    source_data.sub_names.push_back( "hello world" );
    source_data.decls.push_back( generate_test_nb_id() );

    nb_id_t temp( NBID_TYPE_OBJECT_BRIDGE );
    obj_impl_bridge_interface::pack( source_data, temp, raw_data_1 );

    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

    obj_impl_bridge_interface::unpack( raw_data_2, temp, des_data );

    assert( source_data==des_data );
    assert(raw_data_1.object_id==raw_data_2.object_id);
    return true;
}

bool Atom_bytes_pack_and_unpack()
{
    bytes_data_t source_data;
    bytes_data_t des_data;
    content raw_data_1;
    content raw_data_2;

    source_data.crc = 8;
    source_data.length = 8;
    source_data.value = "hello nebutown";

    nb_id_t temp( NBID_TYPE_OBJECT_BYTES );
    obj_impl_bytes::pack(source_data, temp, raw_data_1);

    //data_packer packer;
    //data_unpacker unpacker;
    //std::string strval = packer.pack_to_stream(raw_data_1);
    //raw_data_2 = unpacker.unpack_from_stream(strval);
    //raw_data_2.object_id = raw_data_1.object_id;
    std::string strval = pack_object(raw_data_1);
    unpack_object(strval, raw_data_2);

    obj_impl_bytes::unpack(raw_data_2, temp, des_data);

    assert(source_data==des_data);
    assert(raw_data_1.object_id==raw_data_2.object_id);
    return true;
}

int main(int argc, char* argv[])
{
	//std::cout << std::setw(78) << std::setfill('-') << std::setiosflags(std::ios_base::left);

	test_msg("implementation_pack");
	implementation_pack_unpack();

	test_msg("anchor_pack");
	anchor_pack_unpack();

	test_msg("container_pack");
	container_pack_unpack();

	test_msg("access_pack");
	access_pack_unpack();

	test_msg("decl_compound_pack");
	decl_compound_pack_unpack();

	test_msg("exec_obj_func_pack");
	exec_obj_func_pack_unpack();
//    
//    test_msg("array_pack_unpack");    
//    array_pack_unpack();
//    
//    test_msg("bridge_pack_unpack");
//    bridge_pack_unpack();
//    
//    test_msg("bridge_interface_pack_unpack");
//    bridge_interface_pack_unpack();
//    
	test_msg("exec_anchor_func_pack");
	exec_anchor_func_pack_unpack();

	test_msg("exec_condition_pack");
	exec_condition_pack_unpack();

	test_msg("exec_iterator_pack");
	exec_iterator_pack_unpack();

	test_msg("exec_storage_func_pack");
	exec_storage_func_pack_unpack();

    test_msg("container_def_pack_unpack");
    container_def_pack_unpack();
    
	test_msg("user_pack");
	user_pack_unpack();

	test_msg("string_pack");
	string_pack_unpack();

	test_msg("interface_compound_pack");
	interface_compound_pack_unpack();

	test_msg("descriptor_pack");
	descriptor_pack_unpack();

	test_msg("map_pack");
	map_pack_unpack();

    test_msg( "atom_bridge_pack_and_unpack" );
    Atom_bridge_pack_and_unpack();    

    test_msg( "atom_array_pack_and_unpack" );
    Atom_array_pack_and_unpack();

    test_msg( "atom_bridge_interface_pack_and_unpack" );
    Atom_bridge_interface_pack_and_unpack();    

    test_msg( "atom_bytes_pack_and_unpack" );
    Atom_bytes_pack_and_unpack();    

	std::cout << std::endl;
	std::cout << " TEST SUCCESS ! " << std::endl;
	std::cout << std::endl;
    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
