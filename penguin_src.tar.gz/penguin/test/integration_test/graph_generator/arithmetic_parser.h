/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _ARITHMETIC_PARSER_H_
#define _ARITHMETIC_PARSER_H_

#include <assert.h>

#include <string>
#include <sstream>
#include <iostream>
#include <set>
#include <stack>
#include <vector>

// boost xpressive header
#include <boost/xpressive/xpressive.hpp>

struct operator_t
{
	std::string token;										/* literal symbol */
	int nOperands; 											/* num of operands */
	int nPriority;											/* priority level */

	inline operator_t(const std::string& token, int nOpnds, int nPri)
	{
		this->token = token;
		this->nPriority = nPri;
		this->nOperands = nOpnds;
	}
};

template<typename T>
class ArithmeticParser
{
	typedef T	opnd_type;									/* operand type */
	typedef std::string optr_type;
protected:
	std::vector<operator_t> m_optrSet;						/* supported operators */
	std::string m_strOpndRex;								/* operand regex_str */

private:
	std::string m_expr;										/* expression to parse */
	std::stack<opnd_type>  m_opndStack;						/* operand  stack */
	std::stack<optr_type> m_optrStack;						/* operator stack */

	bool m_bTokenized;										/* parse string has been tokenized or not */
	bool m_bRexInited;										/* regex has been inited or not */
	boost::xpressive::sregex m_regex;						/* regex to get token */
	boost::xpressive::sregex_iterator m_curItr;				/* current token */
	boost::xpressive::sregex_iterator m_endItr;				/* end of parse */

public:
	ArithmeticParser() : m_bTokenized(false), m_bRexInited(false)
	{
	};

	bool parse(const std::string& expr)
	{
		// trim the spaces and save
		m_expr.resize(expr.size());
		std::remove_copy(expr.begin(), expr.end(), m_expr.begin(), ' ');
		
		// init regex
		initRegex();

		std::string token;
		m_bTokenized = false;
		getToken(token);
		while(true)
		{
			/* end when no symbos and optrstack is empty */
			if( token == "#" )
				if(m_optrStack.empty())
					break;/* end of parse */
				else
					/* operate the top operator */
					operateTop();

			else if( isOperand(token) )
			{
				/* not an operator,push into the operand stack */
				opnd_type opnd = tokenToOperand(token);
				m_opndStack.push(opnd);
				getToken(token);
			}
			else
			{
				/* an operator,compare priority with the top optr */
				int prior = isPriorToTop(token);
				switch(prior)
				{
					case 1:		/* stack-top optr is low-priority */
						m_optrStack.push(token);
						getToken(token);
						break;
					case 0:		/* lparen meets rparen */
						m_optrStack.pop();
						getToken(token);
						break;
					case -1: 	/* stack-top optr is high-priority,do operate */
						operateTop();
						break;
				}
			}
		}/* end of while */

		/* check the parsed state */
		assert( m_optrStack.empty() && "EXPRESSION ERROR: more operators than expected" );
		assert( m_opndStack.size()==1 && "EXPRESSION ERROR: more operands than expected" );

		return true;
	}

	/* fetch the parse result from the operand stack top */
	opnd_type getResult()
	{
		assert( m_opndStack.size() == 1 && "EXPRESSION ERROR: No proper result" );
		return m_opndStack.top();
	}

	/* execute the operator and get the result */
	virtual opnd_type operate(const std::string& optr, const std::vector<opnd_type>& vOpnds) = 0;
	
	/* string token to opnd_type */
	virtual opnd_type tokenToOperand(const std::string& token) = 0;

private:
	/* checks if a token is an operand */
	bool isOperand(const std::string& token)
	{
		boost::xpressive::regex_constants::syntax_option_type x = boost::xpressive::regex_constants::ignore_white_space;
		boost::xpressive::sregex opndRex = boost::xpressive::sregex::compile(m_strOpndRex, x);
		return boost::xpressive::regex_match(token, opndRex);
	}
	
	/* checks if a token is a user-defined operator */
	bool isUserOperator(const std::string& token)
	{
		std::vector<operator_t>::const_iterator it = m_optrSet.begin();
		while(it != m_optrSet.end())
		{
			if(token == it->token)
				return true;
			++it;
		}
		return false;
	}

	/* get an operator's priority */
	int getOptrPriority(const std::string& token)
	{
		std::vector<operator_t>::const_iterator it = m_optrSet.begin();
		while(it != m_optrSet.end())
		{
			if(token == it->token)
				return it->nPriority;
			++it;
		}
		assert("false" && "EXPRESSION ERROR: Undefined operator ");
		return 0;
	}

	/* get an operator's operands num */
	int getOptrOperandsNum(const std::string& token)
	{
		std::vector<operator_t>::const_iterator it = m_optrSet.begin();
		while(it != m_optrSet.end())
		{
			if(token == it->token)
				return it->nOperands;
			++it;
		}
		assert("false" && "EXPRESSION ERROR: Undefined operator ");
		return 0;
	}

	/* fetch next token , "#" indicates the end */
	bool getToken(std::string& token)
	{
		/* check if the parsed string has been tokenized or not */
		if(!m_bTokenized)
		{	
			/* not tokenized yet,split the str into tokens */
			m_curItr = boost::xpressive::sregex_iterator(m_expr.begin(), m_expr.end(), m_regex);
			/* set the tokenized flag */
			m_bTokenized = true;
		}
		
		if( m_curItr == m_endItr )
			token = "#";
		else
		{
			token = (*m_curItr)[0];
			++m_curItr;
		}
		
		return true;
	}
	
	/* operate the top operator */
	bool operateTop()
	{
		/* pop out the operator */
		optr_type optr = m_optrStack.top(); 
		m_optrStack.pop();

		/* get the operands */
		int nOperands = getOptrOperandsNum(optr);
		std::vector<opnd_type> vOperands;
		vOperands.reserve(nOperands);
		while(nOperands--)
		{
			assert( !m_opndStack.empty() && "EXPRESSION ERROR: Not enuough operands ");
			vOperands.push_back(m_opndStack.top());
			m_opndStack.pop();
		}

		/* make sure this optr is defined by usr */
		assert( isUserOperator(optr) && "EXPRESSION ERROR: Can't operate on this operator ");
		opnd_type result = operate(optr, vOperands);/* operate is virtual */
		m_opndStack.push(result); 

		return true;
	}
	
	bool initRegex()
	{
		/* init only once */
		if(m_bRexInited)
			return true;

		/* get regex str */
		std::string strOptrRex;
		std::vector<operator_t>::const_iterator it = m_optrSet.begin();
		while( it != m_optrSet.end() )
		{
			strOptrRex.append(" | \\");
			strOptrRex.append(it->token);
			++it;
		}
		strOptrRex.append(" | \\( | \\) ");/* support for parens */
		std::string strRex = m_strOpndRex + strOptrRex; 

		/* generate regex object */
		boost::xpressive::regex_constants::syntax_option_type x = boost::xpressive::regex_constants::ignore_white_space;
		m_regex = boost::xpressive::sregex::compile(strRex, x);

		/* set regex inited flag */
		m_bRexInited = true;

		return true;
	}

	int isPriorToTop(const optr_type& optr)
	{
		if(m_optrStack.empty())
			return 1;

		if(optr == "#" )
			return -1;

		if(optr == ")" )
		{
			if(m_optrStack.top() == "(")
				return 0;/* parent match */
			else
				return -1;
		}
		if(optr == "(")
			return 1;

		if(m_optrStack.top() == "(")
			return 1;
		
		/* call customed isPrior */
		return isPrior(optr, m_optrStack.top());
	}
	
	int isPrior(optr_type optr1, optr_type optr2)
	{
		int p1 = getOptrPriority(optr1);
		int p2 = getOptrPriority(optr2);
		if( p1 < p2 )
			return -1;
		else /* p1 >= p2 */
			return 1;
	}

};

#endif /* _ARITHMETIC_PARSER_H_ */
