/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _INT_IMPL_GENERATOR_H_
#define _INT_IMPL_GENERATOR_H_

#include <string>
#include <sstream>
#include <iostream>
#include <map>

#include "arithmetic_parser.h"
#include "nb_id.h"
#include "obj_impl_exec_obj_func.h"

struct int_graph_node_t
{
	int value;			/* int value */
	bool isConstant;	/* from constants or nodes */
	int index;			/* index of constants or nodes */
};

class int_graph_generator : ArithmeticParser<int_graph_node_t>
{
public:
	std::vector<int> 						m_vecConstants;/* result: constants table */
	std::vector<char> 						m_vecFuncNodes;/* result: func_nodes table */
	std::vector<node_path_t> 				m_vecPaths;/* result: paths table */

private:
	std::map<int, int> m_constantsMap;
	int m_constantIndex;
	int m_nodeIndex;

public:
	using ArithmeticParser<int_graph_node_t>::parse;
	using ArithmeticParser<int_graph_node_t>::getResult;

	int_graph_generator(): m_constantIndex(0), m_nodeIndex(0)
	{
		// set operand regex_string
		m_strOpndRex = "\\d+";
		// init operator set
		m_optrSet.push_back(operator_t("+", 2, 1));
		m_optrSet.push_back(operator_t("-", 2, 1));
		m_optrSet.push_back(operator_t("*", 2, 2));
		m_optrSet.push_back(operator_t("/", 2, 2));
	}

	int_graph_node_t tokenToOperand(const std::string& token)
	{
		int_graph_node_t node;
		node.isConstant = true;
		/* get number */
		std::istringstream iss(token);
		iss >> node.value;
		/* get node index */
		if(m_constantsMap.find(node.value) != m_constantsMap.end())
		{
			/* already has the same constant */
			node.index = m_constantsMap.find(node.value)->second;
		}
		else
		{
			/* push into constants vec */
			m_vecConstants.push_back(node.value);
			/* register in the constant table */
			node.index = m_constantIndex++;
			m_constantsMap.insert(std::make_pair(node.value, node.index));
		}
		return node;
	}

	int_graph_node_t operate(const std::string& optr, const std::vector<int_graph_node_t>& vOpnds)
	{
		int_graph_node_t opnd1,opnd2,result;
		opnd1 = vOpnds[1];
		opnd2 = vOpnds[0];
		result.isConstant = false;
		char node_func = optr[0];/* all optrs are single-char */
		switch(node_func)
		{
			case '+':
				result.value = opnd1.value + opnd2.value;
				break;
			case '-':
				result.value = opnd1.value - opnd2.value;
				break;
			case '*':
				result.value = opnd1.value * opnd2.value;
				break;
			case '/':
				result.value = opnd1.value / opnd2.value;
				break;
		}
		/* push func node */
		m_vecFuncNodes.push_back(node_func);
		result.index = m_nodeIndex++;
		/* generate graph paths */
		node_path_t p1 = _generate_node_path(opnd1, result, 0);
		node_path_t p2 = _generate_node_path(opnd2, result, 1);
		m_vecPaths.push_back(p1);
		m_vecPaths.push_back(p2);

		return result;
	}

 private:
 	/* helper func to create a node_path */
 	node_path_t _generate_node_path(const int_graph_node_t& from, const int_graph_node_t& to, const int out_port)
	{
		node_path_t p;
		if(from.isConstant)
		{
			p.in_node = -2;
			p.in_port = from.index;
		}
		else
		{
			p.in_node = from.index;/* node index */
			p.in_port = 0;/* all int funcs have only 1 out_port */
		}
		p.out_node = to.index;
		p.out_port = out_port;
		return p;
	}
		
};

#endif /* _INT_IMPL_GENERATOR_H_ */
