/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <pthread.h>
#include <signal.h>
#include <iostream>

// boost headers
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/program_options.hpp>

// frameworks
#include "ac_global.h"
#include "ac_framework.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_global_db.h"
#include "ac_manager.h"

//implementation
#include "ac_container/anchor_implementation.h"
#include "ac_container/container_implementation.h"
#include "ac_container/access_implementation.h"
#include "ac_cont_test_helper.h"

#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_exec_impl.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_condition.h"

#include "nb_test_suite.h"

const std::size_t Default_log_level = 2;

// ******************************* utilities *********************************//
class coprse_test_builder: public nb_test_builder
{
public:
    //rewrite virtual function of build declaration
	void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "copser_test__decl";
        // in ports 
		iport_t iport = { "none", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        decl_data.iports.push_back(iport);
        // out ports
        oport_t oport = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport);
    }

    //rewrite virtual function of build implement
	void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "coprse_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 

        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(8);
        impl_data.constants.push_back(const0_int);

        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(0);
        impl_data.constants.push_back(const1_int);

        //nb_id_t const2_int(NBID_TYPE_OBJECT_INT);
        //const2_int.set_value(3);
        //impl_data.constants.push_back(const2_int);

        //nb_id_t const3_int(NBID_TYPE_OBJECT_INT);
        //const3_int.set_value(3);
        //impl_data.constants.push_back(const3_int);

        //nb_id_t const4_int(NBID_TYPE_OBJECT_INT);
        //const4_int.set_value(3);
        //impl_data.constants.push_back(const4_int);

        //nb_id_t const5_int(NBID_TYPE_OBJECT_INT);
        //const5_int.set_value(5);
        //impl_data.constants.push_back(const5_int);

        ////*************** nodes ****************//
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV), const0_int));
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));

        ////************* paths *****************//
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path1{ INPUT1 -> node0:add }
        impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ INPUT1 -> node0:add }
        impl_data.paths.push_back(create_path(0, 0, -3, 0));//path1{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(-2, 2, 0, 0));//path1{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(-2, 3, 0, 1));//path2{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(-2, 3, 1, 0));//path3{ INPUT1 -> node0:sub }
        //impl_data.paths.push_back(create_path(-2, 4, 1, 1));//path4{ INPUT1 -> node0:sub }
        //impl_data.paths.push_back(create_path(-2, 1, 2, 0));//path5{ INPUT1 -> node0:sub }
        //impl_data.paths.push_back(create_path(0, 0, 2, 1));//path6{ INPUT1 -> node0:sub }
        //impl_data.paths.push_back(create_path(-2, 5, 3, 0));//path7{ INPUT1 -> node0:idiv }
        //impl_data.paths.push_back(create_path(1, 0, 3, 1));//path8{ INPUT1 -> node0:idiv }
        //impl_data.paths.push_back(create_path(-2, 0, 4, 0));//path9{ INPUT1 -> node0:idiv }
        //impl_data.paths.push_back(create_path(2, 0, 4, 1));//path10{ INPUT1 -> node0:idiv }
        //impl_data.paths.push_back(create_path(3, 0, 5, 1));//path11{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(4, 0, 5, 0));//path12{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(5, 0, -3, 0));//path13{ INPUT1 -> node0:output }

        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

    }

    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "int_test_builder::check_result" << std::endl;
        int iResult;
        if(out.size()==1)
        {
            out[0].get_value(iResult);
            return (iResult == 1) ;
        }
        return false;
    }

};

class exception_null_test_builder : public nb_test_builder
{
    /* use the default declaration */
public:
    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "exception_null_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t const0_none(NBID_TYPE_OBJECT_NONE);
        //nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        //const0_int.set_value(5);
        //nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        //const1_int.set_value(5);
        //nb_id_t const2_bool(NBID_TYPE_OBJECT_BOOL);
        //const2_bool.set_value(true);

        //impl_data.constants.push_back(const0_int);
        //impl_data.constants.push_back(const1_int);
        //impl_data.constants.push_back(const2_bool);
        //*************** nodes ****************//
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
        //impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INTERFACE_CONVERT)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_GENERAL_EXCEPTION_IF_NULL)));

        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0, -3, 0));//path0{ INPUT1 -> node0:add }
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ INPUT1 -> node0:add }
        //impl_data.paths.push_back(create_path(-2, 1, 0, 1));//path1{ INPUT2 -> node0:add }
        //impl_data.paths.push_back(create_path( -2, 1, 1, 0));//path2{ INPUT2 -> node1:convert } 
        //impl_data.paths.push_back(create_path(-2, 2, 1,1)); //path3{INPUT3 ->node1:convert}
        //impl_data.paths.push_back(create_path(1, 0, 2, 0));//path3{ node1:convert -> node2:exception_if_null }
        //impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path4{ node0:add -> OUT }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);
    }


    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "exception_null_test_builder::check_result" << std::endl;
        int iResult;
        if(out.size()==1)
        {
            out[0].get_value(iResult);
            return (iResult == 10) ;
        }
        return false;
    }
};

class int_test_builder : public nb_test_builder
{
    /* use the default declaration */

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "int_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(5);

        impl_data.constants.push_back(const0_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path0{ INPUT1 -> node0:add }
        impl_data.paths.push_back(create_path(-1, 2, 0, 1));//path1{ INPUT2 -> node0:add }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path2{ node0:add -> node1:sub } 
        impl_data.paths.push_back(create_path(-2, 0, 1, 1));//path3{ cint0 -> node1:sub }
        impl_data.paths.push_back(create_path( 1, 0,-3, 0));//path4{ node1:sub -> OUT }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        nb_id_t input0(NBID_TYPE_OBJECT_INT);
        input0.set_value(2);
        nb_id_t input1(NBID_TYPE_OBJECT_INT);
        input1.set_value(3);

        inputs.push_back(input0);
        inputs.push_back(input1);
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "int_test_builder::check_result" << std::endl;
        int iResult;
        if(out.size()==1)
        {
            out[0].get_value(iResult);
            return (iResult == 0) ;
        }
        return false;
    }
}; /* class int_test_builder */


class str_test_builder : public nb_test_builder
{
private:
    /* the str_test actually does the following thing:
        concatenate the two strings, then get the new length */
    int get_logic_result(std::string str1, std::string str2)
    {
        std::string cat = str1 + str2;
        return cat.length();
    }

    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {        
        decl_data.name = "str_test__decl";
        // in ports 
        iport_t iport1 = { "str1", nb_id_t(NBID_TYPE_OBJECT_STRING), nb_id_t(NBID_TYPE_OBJECT_STRING) };
        decl_data.iports.push_back(iport1);
        iport_t iport2 = { "str2", nb_id_t(NBID_TYPE_OBJECT_STRING), nb_id_t(NBID_TYPE_OBJECT_STRING) };
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport = { "length", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        
        impl_data.name = "str_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//

        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_APPEND)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_STR_SIZE)));
        //*************** paths ****************//
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//INPUT1 -> [append]
        impl_data.paths.push_back(create_path(-1, 2, 0, 1));//INPUT2 -> [append]
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//[append] -> [size]
        impl_data.paths.push_back(create_path( 1, 0,-3, 0));//[size]->OUT
        //generate time node info
        generate_time_node_info(impl_data);
        generate_out_path_info(impl_data);

        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        inputs.push_back(new_nb_string("hello"));
        inputs.push_back(new_nb_string(" world!"));
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "str_test_builder::check_result" << std::endl;
        if(out.size()==1)
        {
            int iResult;
            out[0].get_value(iResult);
            std::cout << "str_test_builder::get result = "<<iResult<<std::endl;
            int logic = get_logic_result("hello", " world!");
            std::cout << "str_test_builder::logic result = "<<logic<<std::endl;
            return iResult == logic;
        }
        return false;
    }

private:
    nb_id_t new_nb_string(std::string strval)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));        
        host_committer_id_t hc_id = get_hc_id();
        
        nb_id_t str_id;
        request_nb_id_info string_info;
        string_info.type = NBID_TYPE_OBJECT_STRING;
        string_info.committer_id = hc_id;

        obj_impl_string::pack(strval, nb_id_t(), string_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, string_info, str_id);
        return str_id;
    }

}; /* class str_test_builder */

//************************************************************************
//* * class thrFigure_test_builder: include three layer figure and the last
//* *                               figure has some problem ,it will create
//* *                               corpse object
//*************************************************************************
class thrFigure_test_builder: public nb_test_builder
{
    private:
        nb_id_t m_sub_decl;
    public:

        /* override virtual */
        void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
        {
            decl_data.name = "test_thrFigure_decl";
            // in ports
            iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE)};/* the fake master */
            iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };

            decl_data.iports.push_back(iport0);
            decl_data.iports.push_back(iport1);
            // out ports
            oport_t oport = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
            decl_data.oports.push_back(oport);
        }

        /* override virtual */
        void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
        {
            impl_data.name = "test_thrFigure_impl";
            impl_data.out_port_size = 1;
            impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
            impl_data.external_decl = this->get_declaration_id();
            impl_data.handlesException = NB_EXCEPTION_NO;//TODO
            /* ======== FUNC:return the sum from lower to upper ======== */

            /* constants */
            nb_id_t cons0_usr = generate_obj_accumulator(hc_id);//construct accumulator-obj
            impl_data.constants.push_back(cons0_usr);
            /* nodes */
            impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_sub_decl, cons0_usr));
            /* paths */
            impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ cons0_usr -> node0[master] }
            impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0[lower] }
            impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path3{ node0[sum] -> OUT0 }

            //generate time node info
            generate_time_node_info(impl_data);
            // generate out path info
            generate_out_path_info(impl_data);

            // generate ss table info
            generate_ss_table_info(impl_data);
        }


        /* override virtual */
        void set_input(std::vector<nb_id_t>& inputs)
        {
            srand(time(NULL));

            nb_id_t input1(NBID_TYPE_OBJECT_INT);
            input1.set_value(0);

            inputs.push_back(input1);
        }

        bool check_result(const std::vector<nb_id_t>& outputs)
        {
            if(outputs.size())
            {
                int result;
                outputs[0].get_value(result);
                std::cout << "thrFigure result:" << result << std::endl;
                return true;
            }
            else
            {
                return false;
            }
            return true;
        }

    private:
        bool generate_inner_graph(const host_committer_id_t& hc_id, func_pair_t& fp)
        {
            ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
            request_nb_id_info req_info; 

            /*
            ** generate declaration
            */
            decl_compound_data_t decl_data;
            decl_data.name = "inner_decl";
            // in ports
            iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
            iport_t iport1 = { "add",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
            decl_data.iports.push_back(iport0);
            decl_data.iports.push_back(iport1); 
            // out ports
            oport_t oport0 = { "result",nb_id_t(NBID_TYPE_OBJECT_INT)};
            decl_data.oports.push_back(oport0);
            // request decl id
            nb_id_t decl_id;
            req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
            obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id);
            // write to db
            std::string strval = pack_object(req_info.raw_data);
            ac_object_db_impl::instance().write(decl_id.str(), strval);

            /* 
            ** generate implementation
            */
            exec_impl_graph_t impl_data;
            impl_data.name = "accumulator_inner_impl";
            impl_data.out_port_size = 1;
            impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
            impl_data.external_decl = decl_id;//generated above
            impl_data.handlesException = NB_EXCEPTION_NO;//TODO
            /*========  FUNC : master<<master, sum<<sum+add, add<<add+1, upper<<upper, break_if(add>upper)  ========*/
            /* constants */
            nb_id_t const0(NBID_TYPE_OBJECT_INT);
            const0.set_value(8);
            impl_data.constants.push_back(const0);

            /* nodes */
            impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV), const0));     
            /* paths */
            impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ const -> node0:idiv }
            impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT2 -> node0:idiv }
            impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0:result -> OUT1 }
            //generate time node info
            generate_time_node_info(impl_data);
            // generate out path info
            generate_out_path_info(impl_data);

            // generate ss table info
            generate_ss_table_info(impl_data);

            // request impl id
            nb_id_t impl_id;
            request_nb_id_info req_info2;
            obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
            req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);

            fp.declaration_id = decl_id;
            fp.implementation_id = impl_id;

            return true;
        }

        bool generate_midd_graph(const host_committer_id_t& hc_id, func_pair_t& fp)
        {
            ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
            request_nb_id_info req_info; 

            /*
            ** generate declaration
            */
            decl_compound_data_t decl_data;
            decl_data.name = "midd_decl";
            // in ports
            iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
            iport_t iport1 = { "add",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
            decl_data.iports.push_back(iport0);
            decl_data.iports.push_back(iport1); 
            // out ports
            oport_t oport0 = { "result",nb_id_t(NBID_TYPE_OBJECT_INT)};
            decl_data.oports.push_back(oport0);
            // request decl id
            nb_id_t decl_id;
            req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
            obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id);
            // write to db
            std::string strval = pack_object(req_info.raw_data);
            ac_object_db_impl::instance().write(decl_id.str(), strval);

            /* 
            ** generate implementation
            */
            exec_impl_graph_t impl_data;
            impl_data.name = "accumulator_midd_impl";
            impl_data.out_port_size = 1;
            impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
            impl_data.external_decl = decl_id;//generated above
            impl_data.handlesException = NB_EXCEPTION_NO;//TODO

            /* constants */
            func_pair_t fp_inner;
            generate_inner_graph(hc_id, fp_inner);
            nb_id_t obj_id = generate_obj_info(hc_id, fp_inner);
            impl_data.constants.push_back(obj_id);

            /* nodes */
            impl_data.nodes.push_back(generate_exec_obj_func(hc_id, fp_inner.declaration_id, obj_id));     
            /* paths */
            impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ const -> node0}
            impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT2 -> node0}
            impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0 -> OUT1 }
            //generate time node info
            generate_time_node_info(impl_data);
            // generate out path info
            generate_out_path_info(impl_data);

            // generate ss table info
            generate_ss_table_info(impl_data);

            // request impl id
            nb_id_t impl_id;
            request_nb_id_info req_info2;
            obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
            req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);

            fp.declaration_id = decl_id;
            fp.implementation_id = impl_id;

            return true;
        }

        nb_id_t generate_obj_info(const host_committer_id_t& hc_id, const func_pair_t& fp)
        {
            ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
            /*
            ** generate descriptor
            */
            descriptor_data_t desc_data;
            desc_data.name = "accumulator_desc";
            // set up funcs
            desc_data.funcs.push_back(fp);
            // generate descriptor id
            nb_id_t desc_id;
            request_nb_id_info req_info; 
            req_info.committer_id = hc_id;
            req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
            obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
            
            /*
            ** generate interface compound
            */
            if_compound_data_t if_data;
            if_data.is_singleton = false;
            if_data.decls.push_back(fp.declaration_id);
            // generate if_id;
            nb_id_t if_id;
            request_nb_id_info req_info3; 
            req_info3.committer_id = hc_id;
            req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
            obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
            /*
            ** generate usr object
            */
            nb_id_t obj_id;
            user_data_t usr_data;
            usr_data.name = "accumulator_object";
            usr_data.descriptor = desc_id;
            usr_data.interface = if_id; 
            request_nb_id_info req_info4; 
            req_info4.committer_id = hc_id;
            req_info4.type = NBID_TYPE_OBJECT_USER;
            obj_impl_user::pack(usr_data, obj_id, req_info4.raw_data);
            ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info4, obj_id); 

            std::string strval = pack_object(req_info4.raw_data);
            ac_object_db_impl::instance().write(obj_id.str(), strval);

            return obj_id;
        }

        nb_id_t generate_obj_accumulator(const host_committer_id_t& hc_id)
        {
            func_pair_t fp;
            generate_midd_graph(hc_id, fp);
            m_sub_decl = fp.declaration_id;
            return generate_obj_info(hc_id, fp);
        }
};

/*
** iterator_test_builder : result = lower + (lower+1) + (lower+2) + ... + upper
*/
class iterator_test_builder : public nb_test_builder
{
private:
    nb_id_t m_accumulator_decl;/* the generated usr obj's decl */
    int m_input_lower;
    int m_input_upper;

    int get_logic_result(int lower, int upper)
    {
        assert(lower <= upper);
        int result = 0;
        for (; lower <= upper; lower++)
            result += lower;
        return result;
    }

public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "test_iterator_decl";
        // in ports
        iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE)};/* the fake master */
        iport_t iport1 = { "lower", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "upper", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };

        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport = { "sum", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "test_iterator_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO
        /* ======== FUNC:return the sum from lower to upper ======== */

        /* constants */
        nb_id_t cons0_usr = generate_obj_accumulator(hc_id);//construct accumulator-obj
        impl_data.constants.push_back(cons0_usr);
        /* nodes */
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_accumulator_decl));
        /* paths */
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ cons0_usr -> node0[master] }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0[lower] }
        impl_data.paths.push_back(create_path(-1, 2, 0, 2));//path2{ INPUT2 -> node0[upper] }
        impl_data.paths.push_back(create_path( 0, 1,-3, 0));//path3{ node0[sum] -> OUT0 }

        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);

        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        // a fake master-input,although we won't use it
        //nb_id_t input0(NBID_TYPE_OBJECT_NONE);
       
        srand(time(NULL));
        m_input_lower = 1;
        m_input_upper = 100;//rand() % 100 + 1;

        nb_id_t input1(NBID_TYPE_OBJECT_INT);
        input1.set_value(m_input_lower);
        nb_id_t input2(NBID_TYPE_OBJECT_INT);
        input2.set_value(m_input_upper);

        //inputs.push_back(input0);
        inputs.push_back(input1);
        inputs.push_back(input2);
    }

    /* check result */
    bool check_result(const std::vector<nb_id_t>& out)
    {
        std::cout <<"++++ iterator test: input lower = " << m_input_lower << std::endl;
        std::cout <<"++++ iterator test: input upper = " << m_input_upper << std::endl;
        int logic_result = get_logic_result(m_input_lower, m_input_upper);
        std::cout <<"++++ iterator test: logic result = " << logic_result << std::endl;
        int iresult;
        out[0].get_value(iresult);
        std::cout << "++++ iterator test: get result = " << iresult << std::endl;
        return (iresult == logic_result);
    }

private:
    bool generate_accumulator_inner_func(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /*
        ** generate declaration
        */
        decl_compound_data_t decl_data;
        decl_data.name = "accumulator_inner_decl";
        // in ports
        iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "sum",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "add",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport3 = { "upper", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1); 
        decl_data.iports.push_back(iport2);
        decl_data.iports.push_back(iport3);
        // out ports
        oport_t oport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "sum",   nb_id_t(NBID_TYPE_OBJECT_INT) };
        oport_t oport2 = { "add",   nb_id_t(NBID_TYPE_OBJECT_INT) };
        oport_t oport3 = { "upper", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        decl_data.oports.push_back(oport2);
        decl_data.oports.push_back(oport3);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id);
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* 
        ** generate implementation
        */
        exec_impl_graph_t impl_data;
        impl_data.name = "accumulator_inner_impl";
        impl_data.out_port_size = 4;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
        impl_data.external_decl = decl_id;//generated above
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO
        /*========  FUNC : master<<master, sum<<sum+add, add<<add+1, upper<<upper, break_if(add>upper)  ========*/
        /* constants */
        /* nodes */
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));     
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_INC)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));      
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_BREAK_TRUE)));
        /* paths */
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path0{ INPUT1 -> node0:add }
        impl_data.paths.push_back(create_path(-1, 2, 0, 1));//path1{ INPUT2 -> node0:add }
        impl_data.paths.push_back(create_path( 0, 0,-3, 1));//path2{ node0:add -> OUT1 }
        impl_data.paths.push_back(create_path(-1, 2, 1, 0));//path3{ INPUT2 -> node1:inc }
        impl_data.paths.push_back(create_path( 1, 0,-3, 2));//path4{ node1:inc -> OUT2 }
        impl_data.paths.push_back(create_path(-1, 3, 2, 0));//path5{ INPUT3 -> node2:lt }
        impl_data.paths.push_back(create_path(-1, 2, 2, 1));//path6{ INPUT2 -> node2:lt }
        impl_data.paths.push_back(create_path( 2, 0, 3, 0));//path7{ node2:lt -> node3:b_if_true }
        impl_data.paths.push_back(create_path(-1, 3,-3, 3));//path8{ INPUT3 -> OUT3 }
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path9{ INPUT0 -> OUT0 } master-route
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);

        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);

        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;
        return true;
    }

    bool generate_accumulator_outter_func(const host_committer_id_t& hc_id, const func_pair_t& inner_func,  func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /*
        ** generate declaration
        */
        decl_compound_data_t decl_data;
        decl_data.name = "accumulator_decl";
        // in ports
        iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "lower", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "upper", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1); 
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "sum",   nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id);
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* 
        ** generate implementation
        */
        exec_impl_graph_t impl_data;
        impl_data.name = "accumulator_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
        impl_data.external_decl = decl_id;//generated above
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO
        /* constants */
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        impl_data.constants.push_back(const0_int);
        /* nodes */
        impl_data.nodes.push_back(generate_exec_iterator(hc_id, inner_func.declaration_id, inner_func.implementation_id)); 
        /* paths */
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT0 -> node0[master]} master-in
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path1{ const0 -> node0[sum] }
        impl_data.paths.push_back(create_path(-1, 1, 0, 2));//path2{ INPUT1 -> node0[add] }
        impl_data.paths.push_back(create_path(-1, 2, 0, 3));//path3{ INPUT2 -> node0[upper] }
        impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path4{ node0[master] -> OUT0 } master-out
        impl_data.paths.push_back(create_path( 0, 1,-3, 1));//path5{ node0[sum] -> OUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2; 
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;
        return true;
    }

    nb_id_t generate_obj_accumulator(const host_committer_id_t& hc_id)
    {
        
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        /*
        ** generate descriptor
        */
        descriptor_data_t desc_data;
        desc_data.name = "accumulator_desc";
        // set up funcs
        func_pair_t inner_func,outter_func;
        generate_accumulator_inner_func(hc_id, inner_func);
        //generate_accumulator_outter_func(hc_id, inner_func.declaration_id, obj_id, outter_func);
        generate_accumulator_outter_func(hc_id, inner_func, outter_func);
        desc_data.funcs.push_back(inner_func);
        desc_data.funcs.push_back(outter_func);
        m_accumulator_decl = outter_func.declaration_id;//save the main decl
        // generate descriptor id
        nb_id_t desc_id;
        request_nb_id_info req_info; 
        req_info.committer_id = hc_id;
        req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
        obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
        
        /*
        ** generate interface compound
        */
        if_compound_data_t if_data;
        if_data.is_singleton = false;
        if_data.decls.push_back(inner_func.declaration_id);
        if_data.decls.push_back(outter_func.declaration_id);
        // generate if_id;
        nb_id_t if_id;
        request_nb_id_info req_info3; 
        req_info3.committer_id = hc_id;
        req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
        /*
        ** generate usr object
        */
        nb_id_t obj_id;
        user_data_t usr_data;
        usr_data.name = "accumulator";
        usr_data.descriptor = desc_id;
        usr_data.interface = if_id; 
        request_nb_id_info req_info4; 
        req_info4.committer_id = hc_id;
        req_info4.type = NBID_TYPE_OBJECT_USER;
        obj_impl_user::pack(usr_data, obj_id, req_info4.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info4, obj_id); 

        std::string strval = pack_object(req_info4.raw_data);
        ac_object_db_impl::instance().write(obj_id.str(), strval);

        return obj_id;
    }

};/* class iterator_test_builder */

class corpIte_test_builder : public nb_test_builder
{
private:
    int m_input_lower;
    nb_id_t m_iterator_func;
    nb_id_t m_iterator_impl;
public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "test_iterator_decl";
        // in ports
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "lower", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport = { "sum", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "test_iterator_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO
        /* ======== FUNC:return the sum from lower to upper ======== */
        func_pair_t fp;
        generate_accumulator_inner_func(hc_id, fp);
        /* constants */
        nb_id_t  constant0(NBID_TYPE_OBJECT_INT);
        constant0.set_value(1);
        impl_data.constants.push_back(constant0);
        nb_id_t  constant1(NBID_TYPE_OBJECT_INT);
        constant1.set_value(1);
        impl_data.constants.push_back(constant1);
        
        /* nodes */
        impl_data.nodes.push_back(generate_iterator_node(hc_id, fp.declaration_id, fp.implementation_id));

        /* paths */
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path1{ INPUT1 -> node0[master] }
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path0{ cons0_usr -> node0[result] }
        impl_data.paths.push_back(create_path(-2, 1, 0, 2));//path0{ cons0_usr -> node0[upper] }
        impl_data.paths.push_back(create_path( 0, 2,-3, 0));//path3{ node0[sum] -> OUT0 }

        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);

        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        // a fake master-input,although we won't use it
        srand(time(NULL));
        m_input_lower = 1;

        nb_id_t input1(NBID_TYPE_OBJECT_INT);
        input1.set_value(m_input_lower);

        inputs.push_back(input1);
    }

    /* check result */
    bool check_result(const std::vector<nb_id_t>& out)
    {
        if(out.size())
        {
            std::cout <<"++++ iterator test: input lower = " << m_input_lower << std::endl;
            std::cout <<"++++ iterator test: input upper = " << "10" << std::endl;
            int iresult;
            out[0].get_value(iresult);
            std::cout << "++++ iterator test: get result = " << iresult << std::endl;
            return true;
        }
        else
        {
            return false;
        }
        return true;
    }

private:
    nb_id_t generate_iterator_node(const host_committer_id_t& hc_id, nb_id_t external_decl, nb_id_t repeated_exec)
    {
        exec_iterator_data_t exec_itr_data;
        nb_id_t exec_itr_id;

        exec_itr_data.name = "corpse iterator";
        exec_itr_data.external_decl = external_decl;
        exec_itr_data.repeated_exec = repeated_exec;
        request_nb_id_info req_info;
        req_info.type = NBID_TYPE_OBJECT_EXEC_ITERATOR;
        req_info.committer_id = hc_id;
        obj_impl_exec_iterator::pack(exec_itr_data, nb_id_t(), req_info.raw_data);

        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, exec_itr_id);

        /* save the node's decl_id for later use */
        set_node_decl_id(exec_itr_id, external_decl);
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(exec_itr_id.str(), strval);
        return  exec_itr_id;
    }
    bool generate_accumulator_inner_func(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /*
        ** generate declaration
        */
        decl_compound_data_t decl_data;
        decl_data.name = "accumulator_inner_decl";
        // in ports
        iport_t iport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "result",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = {"upper",   nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1); 
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master",nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "sum",   nb_id_t(NBID_TYPE_OBJECT_INT) };
        oport_t oport2 = { "upper", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        decl_data.oports.push_back(oport2);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id);
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);
        m_iterator_func = decl_id;

        /* 
        ** generate implementation
        */
        exec_impl_graph_t impl_data;
        impl_data.name = "accumulator_inner_impl";
        impl_data.out_port_size = 3;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);//TODO
        impl_data.external_decl = decl_id;//generated above
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO
        /*========  FUNC : master<<master, sum<<sum+add, add<<add+1, upper<<upper, break_if(add>upper)  ========*/
        /* constants */
        nb_id_t const0(NBID_TYPE_OBJECT_INT);
        const0.set_value(8);
        impl_data.constants.push_back(const0);

        nb_id_t const1(NBID_TYPE_OBJECT_INT);
        const1.set_value(6);
        impl_data.constants.push_back(const1);

        nb_id_t const2(NBID_TYPE_OBJECT_INT);
        const2.set_value(10);
        impl_data.constants.push_back(const2);
        /* nodes */
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));     
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_INC)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));      
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_BREAK_FALSE)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));
        /* paths */
        impl_data.paths.push_back(create_path(-1, 0, -3, 0));//path0{ INPUT -> output }
        impl_data.paths.push_back(create_path(-1, 2, 1, 0));//path1{ INPUT -> node1:INC }
        impl_data.paths.push_back(create_path(1, 0, -3, 2));//path1{ INPUT -> node1:INC }
        impl_data.paths.push_back(create_path( -1, 2,2, 0));//path2{ INPUT -> node2:LT }
        impl_data.paths.push_back(create_path(-2, 2, 2, 1));//path3{ const2 -> node2:lt }
        impl_data.paths.push_back(create_path( 2, 0,3, 0));//path4{ node2:lt -> node3:break false }
        impl_data.paths.push_back(create_path(-2, 1, 0, 0));//path5{ const1 -> node0:sub }
        impl_data.paths.push_back(create_path(-1, 2, 0, 1));//path5{ input -> node0:sub }
        impl_data.paths.push_back(create_path( -2, 0, 4, 0));//path7{ const0 -> node4:idiv }
        impl_data.paths.push_back(create_path(0, 0,4, 1));//path8{ node0:sub -> node4:idiv }
        impl_data.paths.push_back(create_path(4, 0,-3, 1));//path9{ node4:idiv -> output } master-route
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);

        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        // write to db
        strval = pack_object(req_info2.raw_data);
        ac_object_db_impl::instance().write(impl_id.str(), strval);
        m_iterator_impl = impl_id;

        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;
        return true;
    }
};

class corpIf_test_builder : public nb_test_builder
{
private:
    nb_id_t m_obj_tester_decl;  /* tester obj's main decl */
    nb_id_vector m_branch_decls;/* all branches' decl */
    nb_id_vector m_branch_impls;
    int m_input;                /* the input int,saved for result checking */

    /* implemented logic,for result-checking */
    int get_logic_result(int input)
    {
        if(input > 0)
            return 1;
        else if(input == 0)
            return 0;
        else
            return -1;
    }

public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "if_test_decl";
        // in ports 
        iport_t iport0 = { "none",     nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        decl_data.iports.push_back(iport0);
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "if_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t obj_id = generate_obj_if_tester(hc_id);
        impl_data.constants.push_back(obj_id);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_obj_tester_decl, obj_id));    
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ usr_obj -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path0{ INPUT1 -> node }
        impl_data.paths.push_back(create_path( 0, 1,-3, 0));//path1{ node0  -> OUT0 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        // generate an random between [-50, 50)
        srand(time(NULL));
        m_input = rand() % 100 - 50;
        std::cout << m_input << std::endl;

        nb_id_t input0(NBID_TYPE_OBJECT_INT);
        input0.set_value(m_input);

        inputs.push_back(input0);
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "if_test_builder::input = " << m_input << std::endl;
        std::cout << "if_test_builder::logic result = " << get_logic_result(m_input) << std::endl;

        int iResult;
        if (1 == out.size())
        {
            out[0].get_value(iResult);
            std::cout << "if_test_builder::get result = " << iResult << std::endl;
            return (iResult == get_logic_result(m_input)) ;
        }
        return false;
    }

private:
    bool generate_if_tester_outter_func(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_outter_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_outter_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//

        //*************** nodes ****************//
        nb_id_vector alternate_execs;
        alternate_execs.push_back(m_branch_impls[0]);
        alternate_execs.push_back(m_branch_impls[1]);
        alternate_execs.push_back(m_branch_impls[2]);

        nb_id_t exec_cond_id = generate_exec_condition(hc_id, m_branch_decls[0], alternate_execs);
        impl_data.nodes.push_back(exec_cond_id);
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT0 -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0 -> OUT0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 1));//path3{ node0 -> OUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);

        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** if_tester_branch0 : if(in > 0) return 1 else exception
    */
    bool generate_if_tester_branch0(const host_committer_id_t& hc_id, func_pair_t& fp)
    {    
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch0_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch0_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in > 0) return 1; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(1);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path1{ cint0 ->  node0:lt }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path2{ INPUT1 -> node0:lt }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:lt -> node1:ex_false }
        impl_data.paths.push_back(create_path(-1, 1,2, 0));//path4{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-1, 1,2, 1));//path5{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-2, 1,3, 0));//path6{ cint1 -> node3:idiv }
        impl_data.paths.push_back(create_path(2, 0,3, 1));//path7{ node2 -> node3:idiv }
        impl_data.paths.push_back(create_path(3, 0,-3, 1));//path8{ node3 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*  
    ** if_tester_branch1 : if(in==0) return 0 else exception 
    */
    bool generate_if_tester_branch1(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch1_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch1_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in == 0) return 0; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(0);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_EQ)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:eq }
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:eq }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:eq -> node1:ex_false }
        impl_data.paths.push_back(create_path(-1, 1,2, 0));//path4{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-1, 1,2, 1));//path5{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-2, 1,3, 0));//path6{ cint1 -> node3:idiv }
        impl_data.paths.push_back(create_path(2, 0,3, 1));//path7{ node2 -> node3:idiv }
        impl_data.paths.push_back(create_path(3, 0,-3, 1));//path8{ node3 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);


        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*  
    ** if_tester_branch2 : if(in<0) return -1 else exception 
    */
    bool generate_if_tester_branch2(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch2_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch2_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in < 0) return -1; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(-1);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:lt }
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:lt }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:lt -> node1:ex_false }
        impl_data.paths.push_back(create_path(-1, 1,2, 0));//path4{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-1, 1,2, 1));//path5{ input -> node2:sub }
        impl_data.paths.push_back(create_path(-2, 1,3, 0));//path6{ cint1 -> node3:idiv }
        impl_data.paths.push_back(create_path(2, 0,3, 1));//path7{ node2 -> node3:idiv }
        impl_data.paths.push_back(create_path(3, 0,-3, 1));//path8{ node3 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;
        return true; 
    }

    nb_id_t generate_obj_if_tester(const host_committer_id_t& hc_id)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 
        req_info.committer_id = hc_id;
        /*
        ** request obj id
        */
        nb_id_t obj_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_USER, obj_id);
        /*
        ** generate descriptor
        */
        descriptor_data_t desc_data;
        desc_data.name = "if_tester_desc";
        // set up funcs
        // branch funcs
        func_pair_t branch0, branch1, branch2;
        generate_if_tester_branch0(hc_id, branch0);
        generate_if_tester_branch1(hc_id, branch1);
        generate_if_tester_branch2(hc_id, branch2);

        desc_data.funcs.push_back(branch0);
        desc_data.funcs.push_back(branch1);
        desc_data.funcs.push_back(branch2);

        m_branch_decls.push_back(branch0.declaration_id);
        m_branch_decls.push_back(branch1.declaration_id);
        m_branch_decls.push_back(branch2.declaration_id);

        m_branch_impls.push_back(branch0.implementation_id);
        m_branch_impls.push_back(branch1.implementation_id);
        m_branch_impls.push_back(branch2.implementation_id);
        // main func
        func_pair_t outter_func;
        generate_if_tester_outter_func(hc_id,  outter_func);
        desc_data.funcs.push_back(outter_func);
        m_obj_tester_decl = outter_func.declaration_id;
        // generate descriptor id
        nb_id_t desc_id;
        req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
        obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
        
        /*
        ** generate interface compound
        */
        if_compound_data_t if_data;
        if_data.is_singleton = false;
        if_data.decls.push_back(outter_func.declaration_id);
        if_data.decls.push_back(m_branch_decls[0]);
        if_data.decls.push_back(m_branch_decls[1]);
        if_data.decls.push_back(m_branch_decls[2]);
        // generate if_id;
        nb_id_t if_id;
        request_nb_id_info req_info3; 
        req_info3.committer_id = hc_id;
        req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
        /*
        ** generate usr object
        */
        user_data_t usr_data;
        usr_data.name = "if_tester";
        usr_data.descriptor = desc_id;
        usr_data.interface = if_id;
        
        request_nb_id_info req_info4; 
        req_info4.committer_id = hc_id;
        req_info4.type = NBID_TYPE_OBJECT_USER;
        obj_impl_user::pack(usr_data, obj_id, req_info4.raw_data);
        
        std::string strval = pack_object(req_info4.raw_data);
        ac_object_db_impl::instance().write(obj_id.str(), strval);

        return obj_id;
    }
    
};/* class if_test_builder */
/*
**  if_test_builder : 
**  if(in>0) return 1
**  if(in=0) return 0
**  if(in<0) return -1
*/
class if_test_builder : public nb_test_builder
{
private:
    nb_id_t m_obj_tester_decl;  /* tester obj's main decl */
    nb_id_vector m_branch_decls;/* all branches' decl */
    nb_id_vector m_branch_impls;
    int m_input;                /* the input int,saved for result checking */

    /* implemented logic,for result-checking */
    int get_logic_result(int input)
    {
        if(input > 0)
            return 1;
        else if(input == 0)
            return 0;
        else
            return -1;
    }

public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "if_test_decl";
        // in ports 
        iport_t iport0 = { "none",     nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        decl_data.iports.push_back(iport0);
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "if_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t obj_id = generate_obj_if_tester(hc_id);
        impl_data.constants.push_back(obj_id);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_obj_tester_decl, obj_id));    
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ usr_obj -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path0{ INPUT1 -> node }
        impl_data.paths.push_back(create_path( 0, 1,-3, 0));//path1{ node0  -> OUT0 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);
    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        // generate an random between [-50, 50)
        srand(time(NULL));
        m_input = rand() % 100 - 50;

        nb_id_t input0(NBID_TYPE_OBJECT_INT);
        input0.set_value(m_input);

        inputs.push_back(input0);
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "if_test_builder::input = " << m_input << std::endl;
        std::cout << "if_test_builder::logic result = " << get_logic_result(m_input) << std::endl;

        int iResult;
        if (1 == out.size())
        {
            out[0].get_value(iResult);
            std::cout << "if_test_builder::get result = " << iResult << std::endl;
            return (iResult == get_logic_result(m_input)) ;
        }
        return false;
    }

private:
    bool generate_if_tester_outter_func(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_outter_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_outter_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//

        //*************** nodes ****************//
        nb_id_vector alternate_execs;
        alternate_execs.push_back(m_branch_impls[0]);
        alternate_execs.push_back(m_branch_impls[1]);
        alternate_execs.push_back(m_branch_impls[2]);

        nb_id_t exec_cond_id = generate_exec_condition(hc_id, m_branch_decls[0], alternate_execs);
        impl_data.nodes.push_back(exec_cond_id);
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT0 -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0 -> OUT0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 1));//path3{ node0 -> OUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);

        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** if_tester_branch0 : if(in > 0) return 1 else exception
    */
    bool generate_if_tester_branch0(const host_committer_id_t& hc_id, func_pair_t& fp)
    {    
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch0_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch0_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in > 0) return 1; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(1);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path1{ cint0 ->  node0:lt }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path2{ INPUT1 -> node0:lt }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:lt -> node1:ex_false }
        impl_data.paths.push_back(create_path(-2, 1,-3, 1));//path4{ cint1 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*  
    ** if_tester_branch1 : if(in==0) return 0 else exception 
    */
    bool generate_if_tester_branch1(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch1_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch1_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in == 0) return 0; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(0);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_EQ)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:eq }
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:eq }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:eq -> node1:ex_false }
        impl_data.paths.push_back(create_path(-2, 1,-3, 1));//path4{ cint1 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);


        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*  
    ** if_tester_branch2 : if(in<0) return -1 else exception 
    */
    bool generate_if_tester_branch2(const host_committer_id_t& hc_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        
        decl_compound_data_t decl_data;
        decl_data.name = "if_tester_branch2_decl";
        // in ports
        iport_t iport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE),nb_id_t(NBID_TYPE_OBJECT_NONE)};
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        // out ports
        oport_t oport0 = { "master",    nb_id_t(NBID_TYPE_OBJECT_NONE)};
        oport_t oport1 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */

        exec_impl_graph_t impl_data;
        impl_data.name = "if_tester_branch2_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        /* ====FUNC: if(in < 0) return -1; else exception==== */
        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(0);
        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(-1);
        impl_data.constants.push_back(const0_int);
        impl_data.constants.push_back(const1_int);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_LT)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUTPUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:lt }
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:lt }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:lt -> node1:ex_false }
        impl_data.paths.push_back(create_path(-2, 1,-3, 1));//path4{ cint1 -> OUTPUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;
        return true; 
    }

    nb_id_t generate_obj_if_tester(const host_committer_id_t& hc_id)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 
        req_info.committer_id = hc_id;
        /*
        ** request obj id
        */
        nb_id_t obj_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_USER, obj_id);
        /*
        ** generate descriptor
        */
        descriptor_data_t desc_data;
        desc_data.name = "if_tester_desc";
        // set up funcs
        // branch funcs
        func_pair_t branch0, branch1, branch2;
        generate_if_tester_branch0(hc_id, branch0);
        generate_if_tester_branch1(hc_id, branch1);
        generate_if_tester_branch2(hc_id, branch2);

        desc_data.funcs.push_back(branch0);
        desc_data.funcs.push_back(branch1);
        desc_data.funcs.push_back(branch2);

        m_branch_decls.push_back(branch0.declaration_id);
        m_branch_decls.push_back(branch1.declaration_id);
        m_branch_decls.push_back(branch2.declaration_id);

        m_branch_impls.push_back(branch0.implementation_id);
        m_branch_impls.push_back(branch1.implementation_id);
        m_branch_impls.push_back(branch2.implementation_id);
        // main func
        func_pair_t outter_func;
        generate_if_tester_outter_func(hc_id,  outter_func);
        desc_data.funcs.push_back(outter_func);
        m_obj_tester_decl = outter_func.declaration_id;
        // generate descriptor id
        nb_id_t desc_id;
        req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
        obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
        
        /*
        ** generate interface compound
        */
        if_compound_data_t if_data;
        if_data.is_singleton = false;
        if_data.decls.push_back(outter_func.declaration_id);
        if_data.decls.push_back(m_branch_decls[0]);
        if_data.decls.push_back(m_branch_decls[1]);
        if_data.decls.push_back(m_branch_decls[2]);
        // generate if_id;
        nb_id_t if_id;
        request_nb_id_info req_info3; 
        req_info3.committer_id = hc_id;
        req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
        /*
        ** generate usr object
        */
        user_data_t usr_data;
        usr_data.name = "if_tester";
        usr_data.descriptor = desc_id;
        usr_data.interface = if_id;
        
        request_nb_id_info req_info4; 
        req_info4.committer_id = hc_id;
        req_info4.type = NBID_TYPE_OBJECT_USER;
        obj_impl_user::pack(usr_data, obj_id, req_info4.raw_data);
        
        std::string strval = pack_object(req_info4.raw_data);
        ac_object_db_impl::instance().write(obj_id.str(), strval);

        return obj_id;
    }
    
};/* class if_test_builder */

class corpRecur_test_builder : public nb_test_builder
{
private:
    nb_id_t         m_obj_tester_decl;  /* tester obj's main decl */
    nb_id_vector    m_branch_decls;     /* all branches' decl */
    nb_id_vector    m_branch_impls;     /* all branches' impl*/
    int             m_input;            /* the input int,saved for result checking */

    /* implemented logic,for result-checking */
    int get_logic_result(int input, int mul)
    {
        if (1 == input)
        {
            return mul;
        }
        else
        {
            mul += --input;
            return get_logic_result(input, mul);
        }
    }

public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "recursion_test_decl";
        // in ports 
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        decl_data.iports.push_back(iport0);
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport1);
        iport_t iport2 = { "mul",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "recursion_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t obj_id = generate_obj_recur_tester(hc_id);
        impl_data.constants.push_back(obj_id);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_obj_tester_decl, obj_id));  
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ usr_obj -> node0 } 
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path0{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path(-1, 2, 0, 2));//path0{ INPUT2 -> node0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 0));//path1{ node0  -> OUT0 } 
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        srand(time(NULL));
        m_input = 3;//rand() % 100;

        nb_id_t input0(NBID_TYPE_OBJECT_INT);
        input0.set_value(m_input);
        inputs.push_back(input0);

        nb_id_t input1(NBID_TYPE_OBJECT_INT);
        input1.set_value(m_input);
        inputs.push_back(input1);
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "recursion_test_builder::input = " << m_input << std::endl;
        std::cout << "recursion_test_builder::logic result = " << get_logic_result(m_input, m_input) << std::endl;

        int iResult;
        if (1 == out.size())
        {
            out[0].get_value(iResult);
            std::cout << "recursion_test_builder::get result = " << iResult << std::endl;
            return (iResult == get_logic_result(m_input, m_input)) ;
        }
        return false;
    }

private:
    bool generate_recur_tester_outter_func(const host_committer_id_t& hc_id, const nb_id_t& exec_cond_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */

        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_outter_decl";
        // in ports
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_outter_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//

        //*************** nodes ****************//
        impl_data.nodes.push_back(exec_cond_id);

        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT0 -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path(-1, 2, 0, 2));//path1{ INPUT2 -> node0 }
        impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0 -> OUT0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 1));//path2{ node0 -> OUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** recur_tester_branch0
    */
    bool generate_recur_tester_branch0(const host_committer_id_t& hc_id,func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
        request_nb_id_info req_info;

        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_branch01_decl";

        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_branch0_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;

        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(1);
        impl_data.constants.push_back(const0_int);

        nb_id_t const1_int(NBID_TYPE_OBJECT_INT);
        const1_int.set_value(3);
        impl_data.constants.push_back(const1_int);

        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_EQ)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_SUB)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_IDIV)));

        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:eq } 
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:eq }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:eq -> node1:ex_false }
        impl_data.paths.push_back(create_path(-1, 2,-3, 1));//path4{ INPUT2 -> OUT1 } 
        //for corpse
        impl_data.paths.push_back(create_path(-2, 1,2, 0));//path5{ const1 -> node2:sub } 
        impl_data.paths.push_back(create_path(-1, 1,2, 1));//path6{ INPUT1 -> node2:sub } 
        impl_data.paths.push_back(create_path(-2, 1,3, 0));//path7{ const1 -> node3:idiv } 
        impl_data.paths.push_back(create_path(2, 0,3, 1));//path8{ node2:output -> node3:idiv } 
        impl_data.paths.push_back(create_path(3, -4,1, -4));//path9{ node3 -> node1 } attention


        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** recur_tester_branch1: else n!
    */
    bool generate_recur_tester_branch1(const host_committer_id_t& hc_id, const nb_id_t& exec_cond_id, func_pair_t& fp)
    {    
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_branch_else_decl";
        // in ports
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_branch_else_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//
        
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_DEC)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));  
        impl_data.nodes.push_back(exec_cond_id);
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path0{ INPUT1 -> node0:dec }
        impl_data.paths.push_back(create_path(-1, 2, 1, 0));//path1{ input2 -> node1:imul }
        impl_data.paths.push_back(create_path( 0, 0, 1, 1));//path2{ node0:dec ->  node1:imul }
        impl_data.paths.push_back(create_path(-1, 0, 2, 0));//path3{ input0 -> node2:muilitply }
        impl_data.paths.push_back(create_path( 0, 0, 2, 1));//path4{ node0:dec -> node2:muilitply }
        impl_data.paths.push_back(create_path( 1, 0, 2, 2));//path5{ node1:imul ->node2:muiliply }
        impl_data.paths.push_back(create_path( 2, 0,-3, 0));//path6{ node2:muiliply ->output0 }
        impl_data.paths.push_back(create_path( 2, 1,-3, 1));//path7{ node2:muiliply ->output1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    nb_id_t generate_obj_recur_tester(const host_committer_id_t& hc_id)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 
        req_info.committer_id = hc_id;
       
        // request alone nb_id
        nb_id_t obj_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_USER, obj_id);
        nb_id_t exec_cond_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_EXEC_CONDITION, exec_cond_id);
        /*
        ** generate descriptor
        */
        descriptor_data_t desc_data;
        desc_data.name = "recursion_tester_desc";

        /*
        ** set up funcs
        */

        // branch funcs
        func_pair_t branch0, branch1;
        generate_recur_tester_branch0(hc_id, branch0);

        desc_data.funcs.push_back(branch0);
        m_branch_decls.push_back(branch0.declaration_id);
        m_branch_impls.push_back(branch0.implementation_id);

        set_node_decl_id(exec_cond_id, m_branch_decls[0]);//#Attention#

        generate_recur_tester_branch1(hc_id, exec_cond_id, branch1);
        desc_data.funcs.push_back(branch1);
        m_branch_decls.push_back(branch1.declaration_id);
        m_branch_impls.push_back(branch1.implementation_id);
        // build condition func from branch funcs
        nb_id_vector alternate_execs;
        alternate_execs.push_back(m_branch_impls[0]);
        alternate_execs.push_back(m_branch_impls[1]);
        generate_exec_condition2(exec_cond_id, hc_id, m_branch_decls[0], alternate_execs); 
        // main func
        func_pair_t outter_func;
        generate_recur_tester_outter_func(hc_id, exec_cond_id, outter_func);
        desc_data.funcs.push_back(outter_func);
        m_obj_tester_decl = outter_func.declaration_id;
        // generate descriptor id
        nb_id_t desc_id;
        req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
        obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
        
        /*
        ** generate interface compound
        */
        if_compound_data_t if_data;
        if_data.is_singleton = false;
        if_data.decls.push_back(outter_func.declaration_id);
        if_data.decls.push_back(m_branch_decls[0]);
        if_data.decls.push_back(m_branch_decls[1]);
        // generate if_id;
        nb_id_t if_id;
        request_nb_id_info req_info3; 
        req_info3.committer_id = hc_id;
        req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
        /*
        ** generate usr object
        */
        user_data_t usr_data;
        usr_data.name = "recursion_tester";
        usr_data.descriptor = desc_id;
        usr_data.interface = if_id;

        content raw_data;
        obj_impl_user::pack(usr_data, obj_id, raw_data);
        std::string strval = pack_object(raw_data);
        ac_object_db_impl::instance().write(obj_id.str(), strval);

        return obj_id;
    }

};/* class corpRecur_test_builder */

class recursion_test_builder : public nb_test_builder
{
private:
    nb_id_t         m_obj_tester_decl;  /* tester obj's main decl */
    nb_id_vector    m_branch_decls;     /* all branches' decl */
    nb_id_vector    m_branch_impls;     /* all branches' impl*/
    int             m_input;            /* the input int,saved for result checking */

    /* implemented logic,for result-checking */
    int get_logic_result(int input, int mul)
    {
        if (1 == input)
        {
            return mul;
        }
        else
        {
            mul += --input;
            return get_logic_result(input, mul);
        }
    }

public:
    /* override virtual */
    void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
    {
        decl_data.name = "recursion_test_decl";
        // in ports 
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        decl_data.iports.push_back(iport0);
        iport_t iport1 = { "input",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport1);
        iport_t iport2 = { "mul",     nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "result",    nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
    }

    /* override virtual */
    void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data)
    {
        impl_data.name = "recursion_test_impl";
        impl_data.out_port_size = 1;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO; 
        //*************** constants ****************//
        nb_id_t obj_id = generate_obj_recur_tester(hc_id);
        impl_data.constants.push_back(obj_id);
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, m_obj_tester_decl, obj_id));  
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-2, 0, 0, 0));//path0{ usr_obj -> node0 } 
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path0{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path(-1, 2, 0, 2));//path0{ INPUT2 -> node0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 0));//path1{ node0  -> OUT0 } 
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

    }

    /* override virtual */
    void set_input(std::vector<nb_id_t>& inputs)
    {
        srand(time(NULL));
        m_input = 100;//rand() % 100;

        nb_id_t input0(NBID_TYPE_OBJECT_INT);
        input0.set_value(m_input);
        inputs.push_back(input0);

        nb_id_t input1(NBID_TYPE_OBJECT_INT);
        input1.set_value(m_input);
        inputs.push_back(input1);
    }

    /* override virtual */
    bool check_result(const std::vector<nb_id_t>& out)
    {   
        std::cout << "recursion_test_builder::input = " << m_input << std::endl;
        std::cout << "recursion_test_builder::logic result = " << get_logic_result(m_input, m_input) << std::endl;

        int iResult;
        if (1 == out.size())
        {
            out[0].get_value(iResult);
            std::cout << "recursion_test_builder::get result = " << iResult << std::endl;
            return (iResult == get_logic_result(m_input, m_input)) ;
        }
        return false;
    }

private:
    bool generate_recur_tester_outter_func(const host_committer_id_t& hc_id, const nb_id_t& exec_cond_id, func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */

        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_outter_decl";
        // in ports
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_outter_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//

        //*************** nodes ****************//
        impl_data.nodes.push_back(exec_cond_id);

        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0, 0, 0));//path0{ INPUT0 -> node0 }
        impl_data.paths.push_back(create_path(-1, 1, 0, 1));//path1{ INPUT1 -> node0 }
        impl_data.paths.push_back(create_path(-1, 2, 0, 2));//path1{ INPUT2 -> node0 }
        impl_data.paths.push_back(create_path( 0, 0,-3, 0));//path2{ node0 -> OUT0 }
        impl_data.paths.push_back(create_path( 0, 1,-3, 1));//path2{ node0 -> OUT1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** recur_tester_branch0
    */
    bool generate_recur_tester_branch0(const host_committer_id_t& hc_id,func_pair_t& fp)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
        request_nb_id_info req_info;

        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_branch01_decl";

        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_branch0_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;

        //*************** constants ****************//
        nb_id_t const0_int(NBID_TYPE_OBJECT_INT);
        const0_int.set_value(1);
        impl_data.constants.push_back(const0_int);


        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_EQ)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_BOOL_EXCEPTION_FALSE)));
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 0,-3, 0));//path0{ INPUT0 -> OUT0 } master-route
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path1{ INPUT1 -> node0:eq } 
        impl_data.paths.push_back(create_path(-2, 0, 0, 1));//path2{ cint0 ->  node0:eq }
        impl_data.paths.push_back(create_path( 0, 0, 1, 0));//path3{ node0:eq -> node1:ex_false }
        impl_data.paths.push_back(create_path(-1, 2,-3, 1));//path4{ INPUT2 -> OUT1 } 
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    /*
    ** recur_tester_branch1: else n!
    */
    bool generate_recur_tester_branch1(const host_committer_id_t& hc_id, const nb_id_t& exec_cond_id, func_pair_t& fp)
    {    
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 

        /* generate declaration */
        decl_compound_data_t decl_data;
        decl_data.name = "recursion_tester_branch_else_decl";
        // in ports
        iport_t iport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
        iport_t iport1 = { "input", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        iport_t iport2 = { "mul", nb_id_t(NBID_TYPE_OBJECT_INT), nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.iports.push_back(iport0);
        decl_data.iports.push_back(iport1);
        decl_data.iports.push_back(iport2);
        // out ports
        oport_t oport0 = { "master", nb_id_t(NBID_TYPE_OBJECT_NONE) };
        oport_t oport1 = { "result", nb_id_t(NBID_TYPE_OBJECT_INT) };
        decl_data.oports.push_back(oport0);
        decl_data.oports.push_back(oport1);
        // request decl id
        nb_id_t decl_id;
        req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, decl_id); 
        // write to db
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(decl_id.str(), strval);

        /* generate implementation */
        exec_impl_graph_t impl_data;
        impl_data.name = "recursion_tester_branch_else_impl";
        impl_data.out_port_size = 2;
        impl_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
        impl_data.external_decl = this->get_declaration_id();
        impl_data.handlesException = NB_EXCEPTION_NO;//TODO 
        //*************** constants ****************//
        
        //*************** nodes ****************//
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_DEC)));
        impl_data.nodes.push_back(generate_exec_obj_func(hc_id, nb_id_t(NB_FUNC_INT_ADD)));  
        impl_data.nodes.push_back(exec_cond_id);
        //************* paths *****************//
        impl_data.paths.push_back(create_path(-1, 1, 0, 0));//path0{ INPUT1 -> node0:dec }
        impl_data.paths.push_back(create_path(-1, 2, 1, 0));//path1{ input2 -> node1:imul }
        impl_data.paths.push_back(create_path( 0, 0, 1, 1));//path2{ node0:dec ->  node1:imul }
        impl_data.paths.push_back(create_path(-1, 0, 2, 0));//path3{ input0 -> node2:muilitply }
        impl_data.paths.push_back(create_path( 0, 0, 2, 1));//path4{ node0:dec -> node2:muilitply }
        impl_data.paths.push_back(create_path( 1, 0, 2, 2));//path5{ node1:imul ->node2:muiliply }
        impl_data.paths.push_back(create_path( 2, 0,-3, 0));//path6{ node2:muiliply ->output0 }
        impl_data.paths.push_back(create_path( 2, 1,-3, 1));//path7{ node2:muiliply ->output1 }
        //generate time node info
        generate_time_node_info(impl_data);
        // generate out path info
        generate_out_path_info(impl_data);
        // generate ss table info
        generate_ss_table_info(impl_data);

        // request impl id
        nb_id_t impl_id;
        request_nb_id_info req_info2;
        obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
        req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info2, impl_id);
        
        fp.declaration_id = decl_id;
        fp.implementation_id = impl_id;

        return true;
    }

    nb_id_t generate_obj_recur_tester(const host_committer_id_t& hc_id)
    {
        ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
        request_nb_id_info req_info; 
        req_info.committer_id = hc_id;
       
        // request alone nb_id
        nb_id_t obj_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_USER, obj_id);
        nb_id_t exec_cond_id;
        request_alone_nb_id(hc_id, NBID_TYPE_OBJECT_EXEC_CONDITION, exec_cond_id);
        /*
        ** generate descriptor
        */
        descriptor_data_t desc_data;
        desc_data.name = "recursion_tester_desc";

        /*
        ** set up funcs
        */

        // branch funcs
        func_pair_t branch0, branch1;
        generate_recur_tester_branch0(hc_id, branch0);

        desc_data.funcs.push_back(branch0);
        m_branch_decls.push_back(branch0.declaration_id);
        m_branch_impls.push_back(branch0.implementation_id);

        set_node_decl_id(exec_cond_id, m_branch_decls[0]);//#Attention#

        generate_recur_tester_branch1(hc_id, exec_cond_id, branch1);
        desc_data.funcs.push_back(branch1);
        m_branch_decls.push_back(branch1.declaration_id);
        m_branch_impls.push_back(branch1.implementation_id);
        // build condition func from branch funcs
        nb_id_vector alternate_execs;
        alternate_execs.push_back(m_branch_impls[0]);
        alternate_execs.push_back(m_branch_impls[1]);
        generate_exec_condition2(exec_cond_id, hc_id, m_branch_decls[0], alternate_execs); 
        // main func
        func_pair_t outter_func;
        generate_recur_tester_outter_func(hc_id, exec_cond_id, outter_func);
        desc_data.funcs.push_back(outter_func);
        m_obj_tester_decl = outter_func.declaration_id;
        // generate descriptor id
        nb_id_t desc_id;
        req_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
        obj_impl_descriptor::pack(desc_data, nb_id_t(), req_info.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, desc_id);
        
        /*
        ** generate interface compound
        */
        if_compound_data_t if_data;
        if_data.is_singleton = false;
        if_data.decls.push_back(outter_func.declaration_id);
        if_data.decls.push_back(m_branch_decls[0]);
        if_data.decls.push_back(m_branch_decls[1]);
        // generate if_id;
        nb_id_t if_id;
        request_nb_id_info req_info3; 
        req_info3.committer_id = hc_id;
        req_info3.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        obj_impl_interface_compound::pack(if_data, nb_id_t(), req_info3.raw_data);
        ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info3, if_id);
        /*
        ** generate usr object
        */
        user_data_t usr_data;
        usr_data.name = "recursion_tester";
        usr_data.descriptor = desc_id;
        usr_data.interface = if_id;

        content raw_data;
        obj_impl_user::pack(usr_data, obj_id, raw_data);
        std::string strval = pack_object(raw_data);
        ac_object_db_impl::instance().write(obj_id.str(), strval);

        return obj_id;
    }

};/* class recursion_test_builder */



/* Main test logic */
void test(const boost::program_options::variables_map& vm)
{
    // set up test suite
    nb_test_suite test_suite(pthread_self());//pass current tid for async notify

    test_suite.add_test("int_test", test_builder_ptr(new(std::nothrow) int_test_builder()));
    test_suite.add_test("str_test", test_builder_ptr(new(std::nothrow) str_test_builder()));
    test_suite.add_test("iterator_test", test_builder_ptr(new(std::nothrow) iterator_test_builder()));
    test_suite.add_test("if_test", test_builder_ptr(new(std::nothrow) if_test_builder()));
    test_suite.add_test("recursion_test", test_builder_ptr(new(std::nothrow) recursion_test_builder()));
    test_suite.add_test("corpse_test", test_builder_ptr(new(std::nothrow) coprse_test_builder()));
    test_suite.add_test("corpse_iterator_test", test_builder_ptr(new(std::nothrow) corpIte_test_builder()));
    test_suite.add_test("corpse_condition_test", test_builder_ptr(new(std::nothrow) corpIf_test_builder()));
    test_suite.add_test("corpse_recurse_test", test_builder_ptr(new(std::nothrow) corpRecur_test_builder()));
    test_suite.add_test("exception_test",  test_builder_ptr(new(std::nothrow) exception_null_test_builder()));
    test_suite.add_test("figure",  test_builder_ptr(new(std::nothrow) thrFigure_test_builder()));

    
    if(vm.count("int"))
        test_suite.run_test("int_test");
    if(vm.count("str"))
        test_suite.run_test("str_test");
    if(vm.count("if"))
        test_suite.run_test("if_test");
    if(vm.count("itr"))
        test_suite.run_test("iterator_test");
    if(vm.count("recur"))
        test_suite.run_test("recursion_test");
    if(vm.count("corpse"))
        test_suite.run_test("corpse_test");
    if(vm.count("corpIte"))
        test_suite.run_test("corpse_iterator_test");
    if(vm.count("corpIf"))
        test_suite.run_test("corpse_condition_test");
    if(vm.count("corpRecur"))
        test_suite.run_test("corpse_recurse_test");
    if(vm.count("exception"))
        test_suite.run_test("exception_test");
    if(vm.count("figure"))
        test_suite.run_test("figure");
}

void parse_test_options(int argc, char* argv[], boost::program_options::variables_map& vm)
{
    boost::program_options::options_description options("Available test options");

    try
    {            
        options.add_options()
            ("help",    "print help messages")
            ("int",     "run a test for int")
            ("str",     "run a test for string")
            ("if",      "run a test for conditions")
            ("itr",     "run a test for loops")
            ("recur",   "run a test for recursions")
            ("corpse",  "run a test for produce coprse object")
            ("corpIte", "run a test for corpse in loop")
            ("corpIf",  "run a test for corpse in condition")
            ("corpRecur", "run a test for corpse in recurse")
            ("exception", "run a test for exception")
            ("figure",   "run a test for thrFigure")
            ("log", 
              boost::program_options::value<std::size_t>(&(nb_configuration::instance().get_log_level()))->default_value(Default_log_level),
             "set log level");
        boost::program_options::store(boost::program_options::parse_command_line(argc, argv, options), vm);
        boost::program_options::notify(vm);

        if (vm.count("help") || vm.size()==0)
        {
            std::cout << options << std::endl;
            exit(0);
        }

    }
    catch(std::exception& e)
    {
        std::cerr << "Test ERROR: " << e.what() << ".\n";
        std::cout << options << "\n";
        exit(0);
    }
    catch(...)
    {
        std::cerr << "Unkown test options.\n";
        std::cout << options << "\n";
        exit(0);
    }         

}

int main(int argc, char* argv[])
{
    boost::program_options::variables_map vm;
    parse_test_options(argc, argv, vm);

    ac_time_observer::Instance()->set_print_type(3);
    //ac_time_observer::Instance()->time_observer_init(true);

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    // run framework
    // configurations specified here,we leave stdin for test-options
    const int actor_thread_pool_size = 1;
    const bool show_statistics = false;
    const bool statistics_interval = 10;
    ac_framework framework(actor_thread_pool_size,
                            show_statistics,
                            statistics_interval);
    framework.init_framework();
    framework.run();


    // run the tests
    test(vm);


    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();
    std::cout<<"Total message handle count = "<<g_message_count<<std::endl;

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
