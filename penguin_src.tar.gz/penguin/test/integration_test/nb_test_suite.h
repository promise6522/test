/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_TEST_SUITE_H_
#define _NB_TEST_SUITE_H_

#include "pthread.h"
#include "signal.h"

#include "ac_global.h"
#include "ac_framework.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_manager.h"
#include "ac_actor.h"
#include "ac_execution.h"
#include "ac_container/anchor_implementation.h"
#include "ac_container/container_implementation.h"
#include "ac_container/access_implementation.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_exec_impl.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_container_def.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_db/ac_container_db_impl.h"

#include "ac_cont_test_helper.h"
//#include "graph_generator/int_impl_generator.h"

// executables
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "nb_profiler.h"

// forward declarations
class nb_test_builder;
class nb_test_receiver;
class nb_test_suite;

// typedef
typedef boost::shared_ptr<nb_test_builder> test_builder_ptr;

//

/* nb_test_builder : inherit to generate test cases */
class nb_test_builder
{
private:
	host_committer_id_t 	m_hc_id;		    // host_committer_id passed in
	func_pair_t				m_funcPair;		    // generated funcPair
	bool					m_builtFlag;	    // indicates whether been built
    std::string             m_name;             // test-case name
    std::map<nb_id_t, nb_id_t> m_nodeDeclMap;   // exec_nodes and its decl id

public:
	nb_test_builder():m_builtFlag(false) { };
	nb_test_builder(const host_committer_id_t& hc_id):m_hc_id(hc_id), m_builtFlag(false) { };

    /* hc_id access */
	void set_hc_id(const host_committer_id_t& hc_id) { m_hc_id = hc_id; };
    host_committer_id_t get_hc_id() { return m_hc_id; };

    /* name access */
    void set_test_name(const std::string& name) { m_name = name; };
    std::string get_test_name() { return m_name; };

	func_pair_t build()
	{
		// only build once
		if(m_builtFlag)
			return m_funcPair;
		
		ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
		request_nb_id_info req_info;
		req_info.committer_id = m_hc_id;

		// generate declaration id
		decl_compound_data_t decl_data;
		build_declaration(m_hc_id, decl_data);   //build logic data
    	req_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    	obj_impl_decl_compound::pack(decl_data, nb_id_t(), req_info.raw_data);
		ptrHelper->ac_host_committer_request_nb_id(m_hc_id, req_info, m_funcPair.declaration_id);

        // write to db		
        std::string strval = pack_object(req_info.raw_data);
        ac_object_db_impl::instance().write(m_funcPair.declaration_id.str(), strval);

		// generate implementation id
		exec_impl_graph_t impl_data;
		build_implementation(m_hc_id, impl_data);//build logic data
		request_nb_id_info req_info2;
		req_info2.committer_id = m_hc_id;
    	req_info2.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    	obj_impl_exec_impl::pack(impl_data, nb_id_t(), req_info2.raw_data);
		ptrHelper->ac_host_committer_request_nb_id(m_hc_id, req_info2, m_funcPair.implementation_id);

		m_builtFlag = true;
		return m_funcPair;
	}

	nb_id_t get_declaration_id() 
	{ 
		return m_funcPair.declaration_id;
	}

	nb_id_t get_implementation_id()
	{
		assert(m_builtFlag);
		return m_funcPair.implementation_id;
	}

	/* override to get coresponding input */
	virtual void set_input(std::vector<nb_id_t>& inputs) { }

	/* override to check results */
	virtual bool check_result(const std::vector<nb_id_t>& out) { return true; }

private:
	/* override to build decl_compound_data_t */
	virtual void build_declaration(const host_committer_id_t& hc_id, decl_compound_data_t& decl_data)
	{
		/* This is default behavior : a none-in none-out declaration */
		decl_data.name = "default_test_decl";
		// in ports
		iport_t iport = { "none", nb_id_t(NBID_TYPE_OBJECT_NONE), nb_id_t(NBID_TYPE_OBJECT_NONE) };
		decl_data.iports.push_back(iport);
		// out ports
		oport_t oport = { "none", nb_id_t(NBID_TYPE_OBJECT_NONE) };
		decl_data.oports.push_back(oport);
	}

	/* override to build impl_graph_data_t */
	virtual void build_implementation(const host_committer_id_t& hc_id, exec_impl_graph_t& impl_data) = 0;

public:/* Utilities to facilitate building */
    
    /* simply create a node_path_t struct */
    static node_path_t create_path(int in_node, int in_port, int out_node, int out_port);

    /* generate all nodes' out-paths info */
    bool generate_out_path_info(exec_impl_graph_t& impl_data);

    /* generate all nodes' start size table */
    bool generate_ss_table_info(exec_impl_graph_t& impl_data);

    //generate time node info
    bool generate_time_node_info(exec_impl_graph_t& impl_data);

    /* request alone nb id */
    static void request_alone_nb_id(const host_committer_id_t& hc_id, nbid_type_t type, nb_id_t& id);

    // parsing
    static int get_iport_number(const nb_id_t& id);

    void set_node_decl_id(const nb_id_t& exec_node, const nb_id_t& decl_id)
    {  
        m_nodeDeclMap.insert(std::make_pair(exec_node, decl_id));
    }

    void get_node_decl_id(const nb_id_t& exec_node, nb_id_t& decl_id)
    {
        std::map<nb_id_t, nb_id_t>::const_iterator it;
        it = m_nodeDeclMap.find(exec_node);
        assert(it != m_nodeDeclMap.end());
        decl_id = it->second;
    }

    /* exec_obj_func */
    nb_id_t generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id);
    nb_id_t generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id, nb_id_t owner_id);

    /* exec_anchor_func */
    nb_id_t generate_exec_anchor_func(const host_committer_id_t& hc_id, 
            int anchor_idx, nb_id_t selected_decl);

    /* exec_iterator */
    nb_id_t generate_exec_iterator(const host_committer_id_t& hc_id, 
            nb_id_t external_decl, nb_id_t repeated_exec);

    /* exec_condition */
    nb_id_t generate_exec_condition(const host_committer_id_t& hc_id, 
            nb_id_t external_decl, const nb_id_vector& alternate_execs);

    void generate_exec_condition2(const nb_id_t& cond_id, 
            const host_committer_id_t& hc_id, nb_id_t external_decl, const nb_id_vector& alternate_execs);

    /* exec_storage_func */
    nb_id_t generate_exec_storage_func(const host_committer_id_t& hc_id, nb_id_t selected_decl);


};

/* ac_test_receiver : the actor to get test results */
class ac_test_receiver : public ac_actor
{
public:
	typedef std::map<req_num_t, test_builder_ptr> req_builder_map_t;
	req_builder_map_t 		m_reqMap;       /* use to check req's results */
    pthread_t               m_main_tid;     /* the main thread to notify */

public:
	ac_test_receiver():ac_actor(e_ac_access/*mock*/) { }

    void set_main_tid(pthread_t tid) { m_main_tid = tid; }

private:
	virtual bool message_handle(const ac_message_t& message)
	{
        EXECUTION_TIMER("test", false);
		ac_actor::message_handle(message);
        switch(message.type)
        {
            case e_ac_access_run_response :
            {
               	node_invocation_response* pData = reinterpret_cast<node_invocation_response*>(message.data);
                if(pData)
				{	
					// get builder from req map
					req_num_t req_num = message.req_num;
					req_builder_map_t::const_iterator it = m_reqMap.find(req_num);
					assert(it != m_reqMap.end());
					test_builder_ptr pBuilder = it->second;
					// check result
					if( pBuilder->check_result(pData->output.objects) )
						LOG_NOTICE("Test["<<pBuilder->get_test_name()<<"] Passed!");
					else
						LOG_NOTICE("Test["<<pBuilder->get_test_name()<<"] NOT pass!");
				}
				break;
            }
			default :
				return false;
		}
        //exit when finish
        pthread_kill(m_main_tid, SIGTERM);
		return true;
	}

};


class nb_test_suite
{
private:
    pthread_t                               m_main_tid;     /* main thread to notify */
	bool									m_setUpFlag;
	ac_cont_test_helper_ptr 				m_ptrHelper;
	root_committer_id_t 					m_rc_id;
	center_committer_id_t 					m_cc_id;
	host_committer_id_t	 					m_hc_id;
	container_id_t							m_container_id;
	access_id_t								m_rt_access_id;
	access_id_t								m_access_id;	/* the test entrance */
	ac_id_t									m_receiver_id;	/* the receiver-actor's id */
	ac_test_receiver*						m_pReceiver;	/* the receiver actor */
	std::map<std::string, func_pair_t> 		m_funcMap;		/* funcs generate by add_test() */
	std::map<std::string, test_builder_ptr> m_builderMap;	/* builders */

public:
	nb_test_suite(pthread_t tid): m_main_tid(tid), m_setUpFlag(false)
	{
		m_ptrHelper.reset(new (std::nothrow) ac_cont_test_helper(0/*TODO*/));
		// root commmitter, centre committer, host committer
		m_ptrHelper->ac_id_dispenser_request_root_committer_id(m_rc_id);
		m_ptrHelper->ac_id_dispenser_request_center_committer_id(m_cc_id);
		m_ptrHelper->ac_id_dispenser_request_host_committer_id(m_hc_id);
		// do some registrations
    	m_ptrHelper->ac_root_committer_regist_center_committer(m_rc_id, m_cc_id); 
    	m_ptrHelper->ac_center_committer_set_root_committer(m_cc_id, m_rc_id); 
    	m_ptrHelper->ac_center_committer_regist_host_committer(m_cc_id, m_hc_id); 
    	m_ptrHelper->ac_host_committer_set_center_committer(m_hc_id, m_cc_id);
   		
	}

	~nb_test_suite()
	{		
		// remove the receiver actor
	}

	void add_test(const std::string& test_name, test_builder_ptr pBuilder)
	{
		// call build
		pBuilder->set_hc_id(m_hc_id);
        pBuilder->set_test_name(test_name);
		pBuilder->build();
		func_pair_t fp = { pBuilder->get_declaration_id(), pBuilder->get_implementation_id() };
		// stores the builder
		m_builderMap.insert(std::make_pair(test_name, pBuilder));
		// stores the func_pair
		m_funcMap.insert(std::make_pair(test_name, fp));
	}

	bool run_test(const std::string& test_name)
	{
        EXECUTION_TIMER("test", true);
		// before run, set up the runtime environment
		if(!m_setUpFlag)
			set_up();
		// get coresponding declaration
		nb_id_t decl_id = get_declaration_id(test_name);
		// build node_invocation_request
		node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
        //request execution id
        execution_id_t exe_id;
        request_execution_id_info exec_info;
        exec_info.committer_id = m_hc_id;
        exec_info.exec_info.type = NBID_TYPE_BRIDGE;
        if(!m_ptrHelper->ac_id_dispenser_request_execution_id(exec_info, exe_id))
        {
            LOG_ERROR("Syn call failed : ac_id_dispenser_request_execution_id() in test");
            return false;
        }

        pParam->execution_id = exe_id;
		pParam->host_committer_id = m_hc_id;
		pParam->transaction_id = transaction_id_t();//TODO
		pParam->declaration_id = decl_id;
		pParam->object_id = static_cast<nb_id_t>(m_access_id);
		get_test_builder(test_name)->set_input(pParam->input);/* get input from builder */
		// send message
		ac_id_t ac_id_src = m_receiver_id;
		ac_id_t ac_id_des;
		ac_manager::instance().get_ac_id(m_access_id, ac_id_des);
		req_num_t req_num = generate_req_num();
		m_pReceiver->m_reqMap.insert(std::make_pair(req_num, get_test_builder(test_name)));/* receiver must know the {req, builder} pair */
		ac_manager::instance().send_asyn_message(ac_id_des, ac_id_src, req_num, e_ac_access_run, pParam);
		// 
		return true;
	}


	nb_id_t get_declaration_id(const std::string& name)
	{
		std::map<std::string, func_pair_t>::const_iterator it;
		it = m_funcMap.find(name);
        assert(it != m_funcMap.end());
        return it->second.declaration_id;
	}

	nb_id_t get_implementation_id(const std::string& name)
	{
		std::map<std::string, func_pair_t>::const_iterator it;
		it = m_funcMap.find(name);
		assert(it != m_funcMap.end());
        return it->second.implementation_id;
	}

	req_num_t generate_req_num()
	{
		time_t tm;
		time(&tm);
		return static_cast<req_num_t>(tm);
	}

private:
	void set_up()
	{
		// get anchors
		std::vector<func_pair_t> funcs;
		funcs.reserve(m_funcMap.size());
		std::map<std::string, func_pair_t>::const_iterator it = m_funcMap.begin();
		for(; it != m_funcMap.end(); ++it)
			funcs.push_back(it->second);
		// generate anchor0 ( all funcs in one anchor, facilitate test )
		std::vector<anchor_id_t> anchors;
		anchor_id_t anch_id = generate_anchor_id(m_hc_id, funcs);
		anchors.push_back(anch_id);
		// get storages
		std::vector<storage_id_t> storages;
		storage_id_t storage0;
		m_ptrHelper->ac_host_committer_request_storage_id(m_hc_id, storage0);
		storages.push_back(storage0);
		// generate container
		generate_container(m_hc_id, anchors, storages, m_container_id, m_rt_access_id);
		
		// generate test-access
		access_data_t acc_data;
		acc_data.name = "test_access";
		acc_data.parent_container = m_container_id;
		acc_data.anchor_idx = 0;/* all funcs in the first anchor */
        acc_data.is_outgoing = false;

		request_access_id_info acc_info;
		acc_info.committer_id = m_hc_id;
		acc_info.type = NBID_TYPE_OBJECT_ACCESS;
		access_implementation::pack(acc_data, acc_info.raw_data);
		m_ptrHelper->ac_host_committer_request_access_id(m_hc_id, acc_info, m_access_id);
		ac_manager::instance().request_actor(m_access_id);

		// generate receiver actor
		m_pReceiver = ac_memory_alloctor<ac_test_receiver>::instance().allocate();
        if(NULL == m_pReceiver)
        {
            LOG_ERROR("head actor allocate failed in test");
            return;
        }
        std::cout << m_pReceiver->get_actor_id() << std::endl;
        m_pReceiver->set_main_tid(m_main_tid);
		m_pReceiver->set_initialized_status();
		ac_manager::instance().add_actor(m_pReceiver);/* put into the to-be-processed list */
		m_receiver_id = reinterpret_cast<ac_id_t>(m_pReceiver);
		
		// set-up flag
		m_setUpFlag = true;
	}

	test_builder_ptr get_test_builder(const std::string& test_name)
	{
		return m_builderMap.find(test_name)->second;
	}

	/* HelperFunc : generate an anchor id from logic data */
	anchor_id_t generate_anchor_id(const host_committer_id_t& hc_id, const std::vector<func_pair_t> funcs, const std::string& name = "anchor",
								bool registed = false)
	{
		anchor_data_t anch_data;
		anch_data.name = name;
		anch_data.funcs = funcs;
		anch_data.registed = registed;
		anch_data.interface = nb_id_t(NBID_TYPE_OBJECT_INTERFACE_COMPOUND);//TODO

		// request anchor id
		anchor_id_t anch_id;
    	request_anchor_id_info info;
    	anchor_implementation::pack(anch_data, info.raw_data);
    	m_ptrHelper->ac_host_committer_request_anchor_id(hc_id, info, anch_id);

		return anch_id;
	}

	/* HelperFunc : generate a container and its root_access_id */
	bool generate_container(const host_committer_id_t& hc_id, 
        const std::vector<anchor_id_t>& anchors,
		const std::vector<storage_id_t>& storages,
        container_id_t& container_id,
        access_id_t& root_access_id)
	{
    	container_data_t cont_data;
    	cont_data.name = "container";
    	cont_data.anchors = anchors;
		cont_data.storages = storages;
		cont_data.definition = nb_id_t(NBID_TYPE_OBJECT_CONTAINER_DEF);//TODO

		// request container id
    	request_alone_container_id_info  ninfo;
    	ninfo.committer_id = hc_id;
        ac_id_t dest_id = g_ac_id_dispenser_acid;
        ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        pActor->request_alone_container_id(ninfo, container_id);

    	request_container_id_info info;
    	container_implementation::pack(cont_data, container_id, info.raw_data);
//    	m_ptrHelper->ac_host_committer_request_container_id(hc_id, info, container_id);

        std::string strval = pack_container(info.raw_data);
        ac_container_db_impl::instance().write(container_id.str(), strval);

    	// generate root access
    	access_data_t rt_ac_data;
    	rt_ac_data.name = "root_access";
    	rt_ac_data.parent_container = container_id;
		rt_ac_data.is_registed = true;
        rt_ac_data.is_outgoing = false;

   		request_access_id_info ac_info;
    	access_implementation::pack(rt_ac_data, ac_info.raw_data);
    	m_ptrHelper->ac_host_committer_request_access_id(hc_id, ac_info, root_access_id);

    	return true;
	}

};

/*
**
** ===================== some implementations ==================================
**
*/

/* simply create a node_path_t struct */
node_path_t nb_test_builder::create_path(int in_node, int in_port, int out_node, int out_port)
{   
    node_path_t path;
    path.in_node = in_node;
    path.in_port = in_port;
    path.out_node = out_node;
    path.out_port = out_port;
    return path;
}

/*
** generate all nodes' out-paths info 
*/
bool nb_test_builder::generate_out_path_info(exec_impl_graph_t& impl_data)
{
    // generate nodes' out_path info
    impl_data.out_paths.clear();

    impl_data.out_paths.resize(impl_data.nodes.size());

    for (size_t path_index = 0 ; path_index < impl_data.paths.size() ; ++path_index)
    {
        int from = impl_data.paths[path_index].in_node;
        if (from >= 0)  //from other nodes
            impl_data.out_paths[from].path_idxs.push_back(path_index);
    }

    return true;
}

bool nb_test_builder::generate_ss_table_info(exec_impl_graph_t& impl_data)
{
    // set the start_size length
    impl_data.m_total_size = 0;
    impl_data.m_ss_length = impl_data.nodes.size() + 1;
    impl_data.mp_start_size = new exe_impl_node_t[impl_data.m_ss_length];

    for(std::size_t index = 0; index<impl_data.nodes.size(); ++index)
    {
        nb_id_t decl_id;
        get_node_decl_id(impl_data.nodes[index], decl_id);

        int iport_num = get_iport_number(decl_id);
        impl_data.m_total_size += iport_num + impl_data.inNodeTimeNum[index];

        exe_impl_node_t exe_node;
        exe_node.m_start_position = index;
        exe_node.m_size = iport_num + impl_data.inNodeTimeNum[index];
        exe_node.m_confirm_size = iport_num;
        impl_data.mp_start_size[exe_node.m_start_position] = exe_node;
    }

    for (int i = 1; i < impl_data.m_ss_length; ++i)
    {
        impl_data.mp_start_size[i].m_start_position 
        = impl_data.mp_start_size[i-1].m_start_position + impl_data.mp_start_size[i-1].m_size;
    }
    
    impl_data.m_io_obj_lenth = impl_data.m_total_size + impl_data.out_port_size;

    return true;
}

bool nb_test_builder::generate_time_node_info(exec_impl_graph_t& impl_data)
{
    impl_data.inNodeTimeNum.resize(impl_data.nodes.size());
    for(std::size_t index = 0 ; index < impl_data.paths.size(); ++index)
    {
        if(-4 == impl_data.paths[index].out_port) 
        {
            ++impl_data.inNodeTimeNum[impl_data.paths[index].out_node];
        }
    }
    return true;
}

void nb_test_builder::request_alone_nb_id(const host_committer_id_t& hc_id, nbid_type_t type, nb_id_t& id)
{
    request_alone_nb_id_info req_info;
    req_info.type = type;
    req_info.committer_id = hc_id;
    ac_id_t dest_id = g_ac_id_dispenser_acid;
    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    pActor->request_alone_nb_id(req_info, id);
}

int nb_test_builder::get_iport_number(const nb_id_t& id)
{
    int number = 0;
    if (id.is_object_declaration())
    {
        nb_id_vector viifs, voifs;
        obj_impl_declaration::get_interfaces(id, viifs, voifs);
        number = viifs.size();
    }
    else if (id.is_object_decl_compound())
    {
        std::string strval;
        ac_object_db_impl::instance().read(id.str(), strval);
        content raw_data;
        data_unpacker::unpack_from_stream(strval, raw_data);

        nb_id_t                 temp_id;
        decl_compound_data_t    logic_data;
        obj_impl_decl_compound::unpack(raw_data, temp_id, logic_data);

        number = logic_data.iports.size();
    }
    return number;
}

nb_id_t nb_test_builder::generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id)
{
    request_nb_id_info exec_info;
    exec_info.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
    exec_info.committer_id = hc_id;

    /* build obj_func_data_t */
    exec_obj_func_data_t obj_func_data;
    obj_func_data.name = "obj_func";
    obj_func_data.selected_decl = decl_id;
    obj_func_data.recoverer = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.postcut = false;
    obj_impl_exec_obj_func::pack(obj_func_data, nb_id_t(), exec_info.raw_data);
    
    /* request nb_id */
    nb_id_t exec_obj_func_id;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, exec_info, exec_obj_func_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(exec_obj_func_id, decl_id);

    return exec_obj_func_id;
}

nb_id_t nb_test_builder::generate_exec_obj_func(const host_committer_id_t& hc_id, nb_id_t decl_id, nb_id_t owner_id)
{
    request_nb_id_info exec_info;
    exec_info.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
    exec_info.committer_id = hc_id;

    /* build obj_func_data_t */
    exec_obj_func_data_t obj_func_data;
    obj_func_data.name = "obj_func";
    obj_func_data.selected_decl = decl_id;
    obj_func_data.owner = owner_id;
    obj_func_data.recoverer = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.postcut = false;
    obj_impl_exec_obj_func::pack(obj_func_data, nb_id_t(), exec_info.raw_data);
    
    /* request nb_id */
    nb_id_t exec_obj_func_id;
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, exec_info, exec_obj_func_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(exec_obj_func_id, decl_id);

    return exec_obj_func_id;
}

nb_id_t nb_test_builder::generate_exec_anchor_func(const host_committer_id_t& hc_id, int anchor_idx, nb_id_t selected_decl)
{
    exec_anchor_func_data_t anchor_func_data;
    nb_id_t anchor_func_id;
        
    anchor_func_data.anchor_idx = anchor_idx;
    anchor_func_data.selected_decl = selected_decl;

    request_nb_id_info req_info;
    req_info.type = NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC;
    req_info.committer_id = hc_id;
    obj_impl_exec_anchor_func::pack(anchor_func_data, nb_id_t(), req_info.raw_data);
    
    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, anchor_func_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(anchor_func_id, selected_decl);

    return anchor_func_id;
}

nb_id_t nb_test_builder::generate_exec_iterator(const host_committer_id_t& hc_id, nb_id_t external_decl, nb_id_t repeated_exec)
{
    exec_iterator_data_t exec_itr_data;
    nb_id_t exec_itr_id;

    exec_itr_data.name = "exec_iterator";
    exec_itr_data.external_decl = external_decl;
    exec_itr_data.repeated_exec = repeated_exec;
    
    request_nb_id_info req_info;
    req_info.type = NBID_TYPE_OBJECT_EXEC_ITERATOR;
    req_info.committer_id = hc_id;
    obj_impl_exec_iterator::pack(exec_itr_data, nb_id_t(), req_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, exec_itr_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(exec_itr_id, external_decl);

    return exec_itr_id;
}

nb_id_t nb_test_builder::generate_exec_condition(const host_committer_id_t& hc_id, nb_id_t external_decl, const nb_id_vector& alternate_execs)
{
    exec_cond_data_t exec_cond_data;
    nb_id_t exec_cond_id;
    
    exec_cond_data.name = "exec_condition";
    exec_cond_data.external_decl = external_decl;
    exec_cond_data.alternate_execs = alternate_execs;
    
    request_nb_id_info req_info;
    req_info.type = NBID_TYPE_OBJECT_EXEC_CONDITION;
    req_info.committer_id = hc_id;
    obj_impl_exec_condition::pack(exec_cond_data, nb_id_t(), req_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, exec_cond_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(exec_cond_id, external_decl);

    return exec_cond_id;
}

void nb_test_builder::generate_exec_condition2(const nb_id_t& cond_id, const host_committer_id_t& hc_id, nb_id_t external_decl, const nb_id_vector& alternate_execs)
{
    exec_cond_data_t exec_cond_data;
    exec_cond_data.name = "exec_condition2";
    exec_cond_data.external_decl = external_decl;
    exec_cond_data.alternate_execs = alternate_execs;

    request_nb_id_info req_info;
    req_info.type = NBID_TYPE_OBJECT_EXEC_CONDITION;
    req_info.committer_id = hc_id;
    obj_impl_exec_condition::pack(exec_cond_data, cond_id, req_info.raw_data);

    std::string strval = pack_object(req_info.raw_data);
    ac_object_db_impl::instance().write(cond_id.str(), strval);

    /* save the node's decl_id for later use */
    set_node_decl_id(cond_id, external_decl);
}

nb_id_t nb_test_builder::generate_exec_storage_func(const host_committer_id_t& hc_id, nb_id_t selected_decl)
{
    exec_storage_func_data_t exec_stfn_data;
    exec_stfn_data.name = "storage_func_test";
    exec_stfn_data.storage_idx = 0;//by default, using the first storage
    exec_stfn_data.selected_decl = selected_decl;

    nb_id_t storage_func_id;
    request_nb_id_info req_info;
    req_info.type = NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC;
    req_info.committer_id = hc_id;
    obj_impl_exec_storage_func::pack(exec_stfn_data, nb_id_t(), req_info.raw_data);

    ac_cont_test_helper_ptr ptrHelper(new (std::nothrow) ac_cont_test_helper(0));
    ptrHelper->ac_host_committer_request_nb_id(hc_id, req_info, storage_func_id);

    /* save the node's decl_id for later use */
    set_node_decl_id(storage_func_id, selected_decl);

    return storage_func_id;
}


#endif /* _NB_TEST_SUITE_H_ */
