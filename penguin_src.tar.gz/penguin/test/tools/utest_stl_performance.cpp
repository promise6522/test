#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>

#include <vector>
#include <map>
#include <list>
#include <stack>
#include <iostream>

#include "obj_impl_decl_compound.h"
#include "obj_impl_string.h"
#include "obj_impl_user.h"

//#include <boost/array.hpp>

struct id128_t
{
    int32_t data[4];
};

class Timer
{
public:
    Timer()
    {
        //mark the start
        gettimeofday(&m_start_, NULL);
    }

    void reset()
    {
        //reset to current time
        gettimeofday(&m_start_, NULL);
    }

    // we use RAII to get the elapsed time 
    ~Timer()
    {
        getElapse();
    }
        
private:
    timeval m_start_;

    void getElapse()
    {
        //get current time
        timeval current;
        gettimeofday(&current, NULL);
        //get elapsed time
        long sec = current.tv_sec - m_start_.tv_sec;
        long usec = current.tv_usec - m_start_.tv_usec;
        if(usec < 0)
        {
            sec -= 1;
            usec += 1000000;
        }
        
        std::cout << "Elapsed time is " << sec + usec/1000000.0 << " seconds" << std::endl;
    }
};

class USTimer
{
public:
    USTimer()
    {
        //mark the start
        gettimeofday(&m_start_, NULL);
    }

    void reset()
    {
        //reset to current time
        gettimeofday(&m_start_, NULL);
    }

    // we use RAII to get the elapsed time 
    ~USTimer()
    {
        getElapse();
    }
        
private:
    timeval m_start_;

    void getElapse()
    {
        //get current time
        timeval current;
        gettimeofday(&current, NULL);
        //get elapsed time
        long sec = current.tv_sec - m_start_.tv_sec;
        long usec = current.tv_usec - m_start_.tv_usec;
        if(usec < 0)
        {
            sec -= 1;
            usec += 1000000;
        }
        
        std::cout << "Elapsed time is " << sec*1000000 + usec << " us" << std::endl;
    }
};



int main(int argc, char* argv[])
{
    // assert we defined id128_t is 128-bit
    assert(sizeof(id128_t) == 16);

    int INSERT_NUM;
    std::cout << "Please input the num of push/insert operations : ";
    std::cin >> INSERT_NUM;
    std::cout << std::endl;

    // stack push
    std::cout << "std::stack push() : " << std::endl;
    {
        Timer tm;
        std::stack<id128_t>* pStk = new std::stack<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pStk->push(id128_t());
        delete pStk;
    }
    std::cout << std::endl;

    // list push_back
    std::cout << "std::list push_back() : " << std::endl;
    {
        Timer tm;
        std::list<id128_t>* pList = new std::list<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pList->push_back(id128_t());
        delete pList;
    }
    std::cout << std::endl;

   // vector push_back
    std::cout << "std::vector push_back() : " << std::endl;
  
    {
        Timer tm;
        std::vector<id128_t>* pVec = new std::vector<id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pVec->push_back(id128_t());
        delete pVec;
    }
    std::cout << std::endl;

    // map insert
    std::cout << "std::map insert(x) : " << std::endl;
  
    {
        Timer tm;
        std::map<int, id128_t>* pMap = new std::map<int, id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pMap->insert(std::make_pair(i, id128_t()));
        delete pMap;
    }
    std::cout << std::endl;

    // map insert back
    std::cout << "std::map insert(end, x) : " << std::endl;
    {
        Timer tm;
        std::map<int, id128_t>* pMap = new std::map<int, id128_t>();
        for(int i=0; i < INSERT_NUM; ++i)
            pMap->insert(pMap->end(), std::make_pair(i, id128_t()));
        delete pMap;
    }
    std::cout << std::endl;

    // raw mem operations 
    std::cout << "malloc once : " << std::endl;
    {
        Timer tm;
        id128_t* pMem = (id128_t*)malloc(sizeof(id128_t ) * INSERT_NUM);
        for(int i=0; i < INSERT_NUM; ++i)
            pMem[i] = id128_t();
        free(pMem);
    }
    std::cout << std::endl;

    // vector reserve first
    std::cout << "std::vector push_back() after reserve(NUM)" << std::endl;
    {
        Timer tm;
        std::vector<id128_t>* pVec = new std::vector<id128_t>();
        pVec->reserve(INSERT_NUM);
        for(int i=0; i < INSERT_NUM; ++i)
            pVec->push_back(id128_t());
        delete pVec;

    }
    std::cout << std::endl;

    // boost::array 
    //std::cout << "boost::array : " << std::endl;
    //{
    //    Timer tm;
    //    boost::array<id128_t, 100000> arr;
    //    for(int i = 0; i < INSERT_NUM; ++i)
    //        arr[i] = id128_t();
    //}
    //std::cout << std::endl;        

    // obj_impl_user
    std::cout << "obj_impl_user new+delete time is:" << std::endl;
    {
        USTimer tm;
        for (int i = 0; i < INSERT_NUM; ++i)
        {
            obj_impl_user* pobj = new obj_impl_user();
            delete pobj;
        }
    }
    std::cout << std::endl;

    // obj_impl_string
    std::cout << "obj_impl_string new+delete time is:" << std::endl;
    {
        USTimer tm;
        for (int i = 0; i < INSERT_NUM; ++i)
        {
            obj_impl_string* pobj = new obj_impl_string();
            delete pobj;
        }
    }
    std::cout << std::endl;

    // obj_impl_decl_compound
    std::cout << "obj_impl_decl_compound new+delete time is:" << std::endl;
    {
        USTimer tm;
        for (int i = 0; i < INSERT_NUM; ++i)
        {
            obj_impl_decl_compound* pobj = new obj_impl_decl_compound;
            delete pobj;
        }
    }
    std::cout << std::endl;

}
