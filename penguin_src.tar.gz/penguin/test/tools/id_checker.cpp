// C++ 98 header files
#include <string>
#include <vector>
#include <boost/crc.hpp>
#include <string.h>

// Duke header files
//#include "core/duke_stdx_net.h"
//#include "core/duke_stdx_log.h"
//#include "core/duke_snow_snowdb.h"
//#include "logic/duke_logic_object.h"
#include "ac_db/ac_id_db.h"
#include "nb_id.h"
#include "ac_id_db_test_helper.h"
#include "ac_message_type.h"
#include "ac_manager.h"

static ac_id_t g_ac_object_acid = 0;
void test_simple_storage_write()
{
    // test case 1
    std::string key = "100";
    std::string value = "hello nebutown 1, write db";
    std::cout<<"$$$$$ write: key="<<key<<", value="<<value<<std::endl;
    
    int ret = ac_id_db::instance().write(key, value);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "write ok" << std::endl;
    else
        std::cout << "write failed" << std::endl;
/*
    // test case 2
    duke_object_string objstr("hello nebutown 2, write string-object", "");
    dukeid_t idstr = objstr.get_id();
    std::string value_str;
    idstr.get_value(value_str);
    std::cout<<"$$$$$ write: string id ="<<idstr.str()<<", value="<<value_str<<std::endl;

    // test case 3
    duke_logic_data_declaration data;
    duke_logic_declaration objdec(data, "");
    dukeid_t iddecl = objdec.get_id();
    std::string value_decl;
    iddecl.get_value(value_decl);
    std::cout<<"$$$$$ write: declaration id ="<<iddecl.str()<<", value="<<value_decl<<std::endl;
    */
}

void test_simple_storage_read()
{
    // test case 1
    std::string key = "100";
    std::string value;
    int ret = ac_id_db::instance().read(key, value);
    
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        std::cout << "read ok" << std::endl;
    else if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        std::cout << "not found the value" << std::endl;
    else
        std::cout << "read failed" << std::endl;
    std::cout<<"##### read: key="<<key<<", value="<<value<<std::endl;
}

bool show_data(const ac_id_db_test_helper_ptr& test, const nb_id_t& id)
{
    std::string strval;
    struct content raw_data;
    
    if(test->read_db_by_id(id, strval))
    {
        test->string_to_content(strval, raw_data);
        test->content_to_des_Struct(raw_data, id);
    }
    return true;
}

int main(int argc, char* argv[])
{
    std::cout << "-------id_checker------------" << std::endl;
    ac_id_db_test_helper_ptr test(new (std::nothrow) ac_id_db_test_helper(g_ac_object_acid));
    /***** simple storage test *****/
    //test_simple_storage_write();
    //test_simple_storage_read();
    /*******test by id*********/
    assert(argc==3||argc==4);
    if(strlen(argv[1])!=1)
    {
        std::cout << "parameters wrong order" << std::endl;
        return 0;
    }
    std::string key(argv[2]);
    nb_id_t nbStr(key);
    //nb_id_t nbStr(NBID_TYPE_OBJECT_STRING);
    
    //nb_id_t nbStr(NBID_TYPE_OBJECT_BYTES);
    //nb_id_t nbStr(NBID_TYPE_OBJECT_ARRAY);
    if(strcmp(argv[1], "r")==0)
    {
        show_data(test, nbStr);
    }
    else if(strcmp(argv[1], "w")==0)
    {
        /***obj_impl_string***/
        std::string value(argv[3]);
        test->write_db_by_id(nbStr, value);
        /***obj_impl_bytes***/
        //struct content raw_data;
        //bytes_data_t byVal;
        
        //byVal.crc = 1;
        //byVal.length = 8;
        //byVal.value = "hello";
        //obj_impl_bytes::pack(byVal, raw_data);
                
        /***obj_impl_array***/
        //struct content raw_data;
        //array_data_t arrData;
        //arrData.interface.str("88888888888888888888888888888888");
        //arrData.type.str("11111111111111111111111111111111");
        //nb_id_t temp;
        //temp.str("22222222222222222222222222222222");
        //arrData.objs.push_back(temp);
        //temp.str("66666666666666666666666666666666");
        //arrData.objs.push_back(temp);
        //obj_impl_array::pack(arrData, raw_data);
        
        //std::string strval;
        //test->content_to_string(raw_data, strval);
        //test->write_db_by_id(nbStr, strval);
    }
    else
    {
        std::cout << "wrong parameters" << std::endl;
        return 0;
    } 
    return 0;
}
