#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// C 89 header files
#include <errno.h>
#include <signal.h>

// C++ 98 header files
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

// Duke header files

#include "ac_nb_bdb.h"
#include "stdx_log.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_manager.h"
#include "ac_access.h"
#include "ac_id_dispenser.h"
#include "access_implementation.h"
#include "container_implementation.h"
#include "temp_anchor_impl.h"
#include "obj_impl_container_def.h"
#include "ac_message_type.h"

int main(int argc, char* argv[])
{
    // get data from temprate anchor 
    temp_anchor_impl anchorImpl;
    func_vector funcs;
    anchorImpl.get_functions(funcs);
    nb_id_t registed;
    anchorImpl.is_registed(registed);

    // create anchor
    anchor_data_t anchor_data;
    anchor_data.funcs = funcs;
    bool result;
    registed.get_value(result);
    anchor_data.registed = result; 

    anchor_id_t anchor_id;
    ac_id_dispenser *pIdActor = new ac_id_dispenser();
    request_anchor_id_info anchor_info;
    anchor_implementation::pack(anchor_data, anchor_info.raw_data);
    pIdActor->request_anchor_id(anchor_info, anchor_id);

    //create storage
    storage_id_t storage_id;
    pIdActor->request_storage_id(storage_id);

    // create container
    container_data_t cont_data;
    cont_data.anchors.push_back(anchor_id); 
    cont_data.storages.push_back(storage_id); 

    container_id_t container_id;
    request_container_id_info cont_info;
    container_implementation::pack(cont_data, cont_info.raw_data);
    pIdActor->request_container_id(cont_info, container_id);

    // create root access for container 
    access_id_t root_access_id;
    request_access_id_info access_info;
    access_info.type = NBID_TYPE_OBJECT_ACCESS;

    access_data_t access_data;
    access_data.interface = nb_id_t(NB_INTERFACE_ROOT_ACCESS);
    access_data.parent_container = container_id;
    access_data.is_registed = true;
    access_implementation::pack(access_data, access_info.raw_data);

    pIdActor->request_access_id(access_info, root_access_id);
    access_implementation accessimpl;

    //create access by using  root access of new container
    node_invocation_request anchor_param;
    anchor_param.declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_GET_ANCHOR);
    //ptrHelper->ac_access_run(anchor_param);

    // response
    node_invocation_request access_param;
    access_param.declaration_id = nb_id_t(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR);
    //ptrHelper->ac_access_run(access_param);

    // response 
    node_invocation_request normal_access_param;
    normal_access_param.declaration_id = nb_id_t(NB_FUNC_ACCESS_GET_ANCHOR);
    //ptrHelper->ac_access_run(normal_access_param);

    // response
    node_invocation_request calculate_param;
    calculate_param.declaration_id = nb_id_t(NB_FUNC_INT_ADD);
    //ptrHelper->ac_anchor_run(calculate_param);

    return 0;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
