#ifndef __TEMP_ANCHOR_IMPL_H
#define __TEMP_ANCHOR_IMPL_H

#include "anchor_implementation.h"

class temp_anchor_impl : public anchor_implementation 
{
    public:
	temp_anchor_impl(anchor_id_t& anchor_id);
	temp_anchor_impl();
	virtual ~temp_anchor_impl();
	virtual bool run(call_id_t call_id, 
            const node_invocation_request& input, 
            ac_anchor_helper * pHelper);
	void add();
	void sub();
};

typedef std::tr1::shared_ptr<temp_anchor_impl> temp_anchor_impl_ptr;

#endif // __TEMP_ANCHOR_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:

