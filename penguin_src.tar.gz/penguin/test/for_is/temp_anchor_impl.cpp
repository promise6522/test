/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "temp_anchor_impl.h"

    temp_anchor_impl::temp_anchor_impl(anchor_id_t& anchor_id)
: anchor_implementation(anchor_id)
{
    func_pair_t func_pair;
    func_pair.declaration_id = nb_id_t(NB_FUNC_INT_ADD);
    func_pair.implementation_id = nb_id_t(NB_FUNC_INT_ADD);
    m_cData.funcs.push_back(func_pair);
}

temp_anchor_impl::temp_anchor_impl()
{
    func_pair_t func_pair;
    func_pair.declaration_id = nb_id_t(NB_FUNC_INT_ADD);
    func_pair.implementation_id = nb_id_t(NB_FUNC_INT_ADD);
    m_cData.funcs.push_back(func_pair);
}

temp_anchor_impl::~temp_anchor_impl()
{
}

void temp_anchor_impl::add()
{
    std::cout<<"1+1 = 2"<<std::endl;
}

void temp_anchor_impl::sub()
{
    std::cout<<"2-1 = 0"<<std::endl;
}

bool temp_anchor_impl::run(call_id_t call_id,
	const node_invocation_request& input,
	ac_anchor_helper * pHelper)
{
    switch(input.declaration_id.get_func_type())
    {
	case NB_FUNC_INT_ADD:
	    add();
	    break;
	case NB_FUNC_INT_SUB:
	    sub();
	    break;
	default:
	    break;

    }

    return true; 
}

