/**************************************************************************
**
**  Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _NB_SCANER_H_
#define _NB_SCANER_H_

#include <vector>

//job list
#include "core_statistic_info.h"
#include "media_statistic_info.h"
#include "scaner_job_base.h"

class nb_scaner
{    
public:
    nb_scaner();
    void run();

private:
    void start_scan_db();
    void scan_core_db();
    void scan_form_db();
    void scan_tmp_db();
    void scan_all_users();
    
private:
    std::vector<scaner_job_base_ptr> m_jobs;

    std::vector<std::string>    m_users;
    nb_entire_ids               m_core_ids;
    media_entire_ids            m_form_ids;
    media_entire_ids            m_tmp_ids;
};


#endif /* _NB_SCANER_H_ */
