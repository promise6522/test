/**************************************************************************
 **
 **  Copyright 2011 Nebutown Inc.
 **
 **************************************************************************/

#include "nb_scaner.h"

#include "new_outgoing_decl/job.h"

// comment out for compilation error (tom)
//#include "add_name/job.h"

#include "new_container_decl/del.h"

// add by tom on 11/10/23
//#include "add_external_decl/add_external_decl.h"
#include "remove_unref_ids/job.h"

nb_scaner::nb_scaner()
{
    //m_jobs.push_back(scaner_job_base_ptr(new(std::nothrow) new_outgoing_decl_job()));
    //m_jobs.push_back(scaner_job_base_ptr(new(std::nothrow) new_container_decl_job()));
    //m_jobs.push_back(scaner_job_base_ptr(new(std::nothrow) add_name_decl_job()));
    //m_jobs.push_back(scaner_job_base_ptr(new(std::nothrow) add_external_decl_job()));
    m_jobs.push_back(scaner_job_base_ptr(new(std::nothrow) remove_unref_ids_job()));
}

void nb_scaner::run()
{
    //start scan database
    start_scan_db();

    for(std::vector<scaner_job_base_ptr>::iterator it = m_jobs.begin(); it != m_jobs.end(); ++it)
    {
        if(*it)
        {
            (*it)->init(&m_users, &m_core_ids, &m_form_ids, &m_tmp_ids);
            
            LOG_NOTICE("\n======================== Scan job : "<< (*it)->name() << " Starting ========================");
            if(!(*it)->start())
            {
                LOG_ERROR("start "<< (*it)->name() << " failed.");
                continue;
            }
            LOG_NOTICE("==========================================================================================");


            LOG_NOTICE("\n======================== Scan job : "<< (*it)->name() << " Running ========================");
            if(!(*it)->run())
            {
                LOG_ERROR("run "<< (*it)->name() << " failed.");
                continue;
            }
            LOG_NOTICE("==========================================================================================");

            LOG_NOTICE("\n======================== Scan job : "<< (*it)->name() << " Ending =========================");
            if(!(*it)->stop())
            {
                LOG_ERROR("stop "<< (*it)->name() << " failed.");
                continue;
            }
            LOG_NOTICE("==========================================================================================");
        }            
    }
}

void nb_scaner::start_scan_db()
{
    scan_core_db();
    scan_form_db();
    scan_tmp_db();
    scan_all_users();
}

void nb_scaner::scan_all_users()
{
    nb_user_manager::instance().get_all_users(m_users);
    LOG_NOTICE("Scan total users number is "<<m_users.size());
}

void nb_scaner::scan_core_db()
{
    std::string strcont;
    ac_container_db_impl::instance().read_handle(strcont);
    if(!strcont.empty())
    {
        duke_media_handle_vector cont_ids;
        unpack_dukeid_vector(strcont, cont_ids);

        for(duke_media_handle_vector::iterator it = cont_ids.begin(); it != cont_ids.end(); ++it)
        {
            if(it->is_container())
            {
                container_id_t id(it->str());
                m_core_ids.m_conts.cont_ids.insert(id);
            }
        }
    }

    //TBD: add scan storage db
    
    std::string strval;
    ac_object_db_impl::instance().read_all_handles(strval);
    if(strval.empty())
        return;
    
    duke_media_handle_vector vid;
    unpack_dukeid_vector(strval, vid);

    for(duke_media_handle_vector::iterator it = vid.begin(); it != vid.end(); ++it)
    {
        if(it->is_container())
        {
            container_id_t id(it->str());
            m_core_ids.m_conts.cont_ids.insert(id);
        }
        else if(it->is_access())
        {
            access_id_t id(it->str());
            m_core_ids.m_conts.ac_ids.insert(id);
        }
        else if(it->is_anchor())
        {
            anchor_id_t id(it->str());
            m_core_ids.m_conts.an_ids.insert(id);
        }
        else if(it->is_storage())
        {
            storage_id_t id(it->str());
            m_core_ids.m_conts.st_ids.insert(id);
        }
        else
        {
            nb_id_t id(it->str());
            nbid_type_t type = id.get_type();

            switch(type)
            {
            //for objects
            case NBID_TYPE_OBJECT_NONE :
            case NBID_TYPE_OBJECT_BOOL :
            case NBID_TYPE_OBJECT_INT :
            case NBID_TYPE_OBJECT_FLOAT :
            case NBID_TYPE_OBJECT_STRING :
            case NBID_TYPE_OBJECT_BYTES :
            case NBID_TYPE_OBJECT_INTERVAL :
            case NBID_TYPE_OBJECT_TIME :
            case NBID_TYPE_OBJECT_ARRAY :           
            case NBID_TYPE_OBJECT_ARRAY_INT :        
            case NBID_TYPE_OBJECT_ARRAY_BOOL :      
            case NBID_TYPE_OBJECT_ARRAY_FLOAT :      
            case NBID_TYPE_OBJECT_ARRAY_STRING :     
            case NBID_TYPE_OBJECT_MAP : 
            case NBID_TYPE_OBJECT_CORPSE :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.built_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_USER :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.user_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_DESCRIPTOR :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.des_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_ID_STAND_IN :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.id_stand_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.bridge_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXCEPTION :
            {
                m_core_ids.m_objs.total_objs.insert(id);
                m_core_ids.m_objs.exception_objs.insert(id);
                break;
            }

            //for interface
            case NBID_TYPE_OBJECT_INTERFACE :
            {
                m_core_ids.m_ifs.total_ifs.insert(id);
                m_core_ids.m_ifs.built_ifs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE_INTERFACE :
            {
                m_core_ids.m_ifs.total_ifs.insert(id);
                m_core_ids.m_ifs.bridge_ifs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_COMPOUND :
            {
                m_core_ids.m_ifs.total_ifs.insert(id);
                m_core_ids.m_ifs.com_ifs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_EXPANDED :
            {
                m_core_ids.m_ifs.total_ifs.insert(id);
                m_core_ids.m_ifs.exp_ifs.insert(id);
                break;
            }
            
            //for declaration
            case NBID_TYPE_OBJECT_DECLARATION :
            {
                m_core_ids.m_decls.total_decls.insert(id);
                m_core_ids.m_decls.built_decls.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_COMPOUND :
            {
                m_core_ids.m_decls.total_decls.insert(id);
                m_core_ids.m_decls.com_decls.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_EXPANDED :
            {
                m_core_ids.m_decls.total_decls.insert(id);
                m_core_ids.m_decls.exp_decls.insert(id);
                break;
            }
            case NBID_TYPE_FUNCTION_COMPOSE :
            case NBID_TYPE_FUNCTION_DECOMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE :
            case NBID_TYPE_FUNCTION_GET_ANCHORS :
            case NBID_TYPE_FUNCTION_GET_STORAGES :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC :
            {
                m_core_ids.m_decls.total_decls.insert(id);
                m_core_ids.m_decls.spe_decls.insert(id);
                break;
            }

            //for implementation
            case NBID_TYPE_OBJECT_IMPLEMENTATION :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.impl_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_CONDITION :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.exec_cond_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ITERATOR :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.exec_it_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.exec_st_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.exec_an_objs.insert(id);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC :
            {
                m_core_ids.m_impls.total_impls.insert(id);
                m_core_ids.m_impls.exec_obj_objs.insert(id);
                break;
            }

            //for container
            case NBID_TYPE_OBJECT_CONTAINER_DEF :
            {
                m_core_ids.m_conts.cont_des_ids.insert(id);
                break;
            }
            
            //for unkown ids
            default :
            {
                LOG_NOTICE("Scan unkown id : "<<id.str());
                m_core_ids.m_unkown_ids.insert(id);
                break;
            }
            }
        }
    }

    LOG_NOTICE("Scan core database total id number is "<<m_core_ids.size());
}

void nb_scaner::scan_form_db()
{
    std::string strval;
    duke_media_formobj_db::instance().read_handle(strval);
    if(strval.empty())
    {
        LOG_NOTICE("Scan form database total id number is "<<m_form_ids.size());
        return;
    }
    
    duke_media_handle_vector vid;
    unpack_dukeid_vector(strval, vid);
    for(duke_media_handle_vector::iterator it = vid.begin(); it != vid.end(); ++it)
    {
        if(it->is_container())
        {
            m_form_ids.m_conts.cont_ids.insert(*it);
        }
        else if(it->is_access())
        {
            m_form_ids.m_conts.ac_ids.insert(*it);
        }
        else if(it->is_anchor())
        {
            m_form_ids.m_conts.an_ids.insert(*it);
        }
        else if(it->is_storage())
        {
            m_form_ids.m_conts.st_ids.insert(*it);
        }
        else
        {
            nb_id_t id(it->str());
            nbid_type_t type = id.get_type();

            switch(type)
            {
            //for objects
            case NBID_TYPE_OBJECT_NONE :
            case NBID_TYPE_OBJECT_BOOL :
            case NBID_TYPE_OBJECT_INT :
            case NBID_TYPE_OBJECT_FLOAT :
            case NBID_TYPE_OBJECT_STRING :
            case NBID_TYPE_OBJECT_BYTES :
            case NBID_TYPE_OBJECT_INTERVAL :
            case NBID_TYPE_OBJECT_TIME :
            case NBID_TYPE_OBJECT_ARRAY :           
            case NBID_TYPE_OBJECT_ARRAY_INT :        
            case NBID_TYPE_OBJECT_ARRAY_BOOL :      
            case NBID_TYPE_OBJECT_ARRAY_FLOAT :      
            case NBID_TYPE_OBJECT_ARRAY_STRING :     
            case NBID_TYPE_OBJECT_MAP : 
            case NBID_TYPE_OBJECT_CORPSE :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.built_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_USER :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.user_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DESCRIPTOR :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.des_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_ID_STAND_IN :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.id_stand_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.bridge_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXCEPTION :
            {
                m_form_ids.m_objs.total_objs.insert(*it);
                m_form_ids.m_objs.exception_objs.insert(*it);
                break;
            }

            //for interface
            case NBID_TYPE_OBJECT_INTERFACE :
            {
                m_form_ids.m_ifs.total_ifs.insert(*it);
                m_form_ids.m_ifs.built_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE_INTERFACE :
            {
                m_form_ids.m_ifs.total_ifs.insert(*it);
                m_form_ids.m_ifs.bridge_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_COMPOUND :
            {
                m_form_ids.m_ifs.total_ifs.insert(*it);
                m_form_ids.m_ifs.com_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_EXPANDED :
            {
                m_form_ids.m_ifs.total_ifs.insert(*it);
                m_form_ids.m_ifs.exp_ifs.insert(*it);
                break;
            }
            
            //for declaration
            case NBID_TYPE_OBJECT_DECLARATION :
            {
                m_form_ids.m_decls.total_decls.insert(*it);
                m_form_ids.m_decls.built_decls.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_COMPOUND :
            {
                m_form_ids.m_decls.total_decls.insert(*it);
                m_form_ids.m_decls.com_decls.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_EXPANDED :
            {
                m_form_ids.m_decls.total_decls.insert(*it);
                m_form_ids.m_decls.exp_decls.insert(*it);
                break;
            }
            case NBID_TYPE_FUNCTION_COMPOSE :
            case NBID_TYPE_FUNCTION_DECOMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE :
            case NBID_TYPE_FUNCTION_GET_ANCHORS :
            case NBID_TYPE_FUNCTION_GET_STORAGES :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC :
            {
                m_form_ids.m_decls.total_decls.insert(*it);
                m_form_ids.m_decls.spe_decls.insert(*it);
                break;
            }

            //for implementation
            case NBID_TYPE_OBJECT_IMPLEMENTATION :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.impl_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_CONDITION :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.exec_cond_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ITERATOR :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.exec_it_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.exec_st_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.exec_an_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC :
            {
                m_form_ids.m_impls.total_impls.insert(*it);
                m_form_ids.m_impls.exec_obj_objs.insert(*it);
                break;
            }

            //for container
            case NBID_TYPE_OBJECT_CONTAINER_DEF :
            {
                m_form_ids.m_conts.cont_des_ids.insert(*it);
                break;
            }
            
            //for unkown ids
            default :
            {
                LOG_NOTICE("Scan unkown id : "<<id.str());
                m_form_ids.m_unkown_ids.insert(*it);
                break;
            }
            }
        }
    }

    LOG_NOTICE("Scan form database total id number is "<<m_form_ids.size());
}

void nb_scaner::scan_tmp_db()
{
     std::string strval;
     duke_media_tempobj_db::instance().read_handle(strval);
     if(strval.empty())
     {
         LOG_NOTICE("Scan tmp database total id number is "<<m_tmp_ids.size()); 
         return;
     }
    
     duke_media_handle_vector vid;
     unpack_dukeid_vector(strval, vid);

     for(duke_media_handle_vector::iterator it = vid.begin(); it != vid.end(); ++it)
    {
        if(it->is_container())
        {
            m_tmp_ids.m_conts.cont_ids.insert(*it);
        }
        else if(it->is_access())
        {
            m_tmp_ids.m_conts.ac_ids.insert(*it);
        }
        else if(it->is_anchor())
        {
            m_tmp_ids.m_conts.an_ids.insert(*it);
        }
        else if(it->is_storage())
        {
            m_tmp_ids.m_conts.st_ids.insert(*it);
        }
        else
        {
            nb_id_t id(it->str());
            nbid_type_t type = id.get_type();

            switch(type)
            {
            //for objects
            case NBID_TYPE_OBJECT_NONE :
            case NBID_TYPE_OBJECT_BOOL :
            case NBID_TYPE_OBJECT_INT :
            case NBID_TYPE_OBJECT_FLOAT :
            case NBID_TYPE_OBJECT_STRING :
            case NBID_TYPE_OBJECT_BYTES :
            case NBID_TYPE_OBJECT_INTERVAL :
            case NBID_TYPE_OBJECT_TIME :
            case NBID_TYPE_OBJECT_ARRAY :           
            case NBID_TYPE_OBJECT_ARRAY_INT :        
            case NBID_TYPE_OBJECT_ARRAY_BOOL :      
            case NBID_TYPE_OBJECT_ARRAY_FLOAT :      
            case NBID_TYPE_OBJECT_ARRAY_STRING :     
            case NBID_TYPE_OBJECT_MAP : 
            case NBID_TYPE_OBJECT_CORPSE :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.built_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_USER :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.user_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DESCRIPTOR :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.des_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_ID_STAND_IN :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.id_stand_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.bridge_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXCEPTION :
            {
                m_tmp_ids.m_objs.total_objs.insert(*it);
                m_tmp_ids.m_objs.exception_objs.insert(*it);
                break;
            }

            //for interface
            case NBID_TYPE_OBJECT_INTERFACE :
            {
                m_tmp_ids.m_ifs.total_ifs.insert(*it);
                m_tmp_ids.m_ifs.built_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_BRIDGE_INTERFACE :
            {
                m_tmp_ids.m_ifs.total_ifs.insert(*it);
                m_tmp_ids.m_ifs.bridge_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_COMPOUND :
            {
                m_tmp_ids.m_ifs.total_ifs.insert(*it);
                m_tmp_ids.m_ifs.com_ifs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_INTERFACE_EXPANDED :
            {
                m_tmp_ids.m_ifs.total_ifs.insert(*it);
                m_tmp_ids.m_ifs.exp_ifs.insert(*it);
                break;
            }
            
            //for declaration
            case NBID_TYPE_OBJECT_DECLARATION :
            {
                m_tmp_ids.m_decls.total_decls.insert(*it);
                m_tmp_ids.m_decls.built_decls.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_COMPOUND :
            {
                m_tmp_ids.m_decls.total_decls.insert(*it);
                m_tmp_ids.m_decls.com_decls.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_DECLARATION_EXPANDED :
            {
                m_tmp_ids.m_decls.total_decls.insert(*it);
                m_tmp_ids.m_decls.exp_decls.insert(*it);
                break;
            }
            case NBID_TYPE_FUNCTION_COMPOSE :
            case NBID_TYPE_FUNCTION_DECOMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE :
            case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE :
            case NBID_TYPE_FUNCTION_GET_ANCHORS :
            case NBID_TYPE_FUNCTION_GET_STORAGES :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC :
            case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC :
            {
                m_tmp_ids.m_decls.total_decls.insert(*it);
                m_tmp_ids.m_decls.spe_decls.insert(*it);
                break;
            }

            //for implementation
            case NBID_TYPE_OBJECT_IMPLEMENTATION :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.impl_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_CONDITION :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.exec_cond_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ITERATOR :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.exec_it_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.exec_st_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.exec_an_objs.insert(*it);
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC :
            {
                m_tmp_ids.m_impls.total_impls.insert(*it);
                m_tmp_ids.m_impls.exec_obj_objs.insert(*it);
                break;
            }

            //for container
            case NBID_TYPE_OBJECT_CONTAINER_DEF :
            {
                m_tmp_ids.m_conts.cont_des_ids.insert(*it);
                break;
            }
            
            //for unkown ids
            default :
            {
                LOG_NOTICE("Scan unkown id : "<<id.str());
                m_tmp_ids.m_unkown_ids.insert(*it);
                break;
            }
            }
        }
    }
     LOG_NOTICE("Scan tmp database total id number is "<<m_tmp_ids.size()); 
}

