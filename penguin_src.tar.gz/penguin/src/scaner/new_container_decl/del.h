/**************************************************************************
**
**  Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _NEW_CONTAINER_DECL_JOB_H_
#define _NEW_CONTAINER_DECL_JOB_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_global_db.h"

#include "../scaner_job_base.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"

#include "duke_media_formobj_db.h"
#include "duke_logic_object_data.h"

class new_container_decl_job : public scaner_job_base
{    
public:

    new_container_decl_job()
        : scaner_job_base()
    {
        m_name = "new_container_decl_job";
    }

    virtual bool start()
    {
        scaner_job_base::start();

        return true;
    }

    virtual bool run()
    {
        scaner_job_base::run();

        int ret;
        // core
        {
            int count = 0;
            std::set<container_id_t>::iterator it1 = m_core_ids->m_conts.cont_ids.begin();
            for (; it1 != m_core_ids->m_conts.cont_ids.end(); ++it1)
            {
                ret = ac_container_db_impl::instance().del(it1->str());
                count++;
            }
            LOG_DEBUG("delete container in core:"<<count);

            count = 0;
            std::set<access_id_t>::iterator it2 = m_core_ids->m_conts.ac_ids.begin();
            for (; it2 != m_core_ids->m_conts.ac_ids.end(); ++it2)
            {   
                ret = ac_object_db_impl::instance().del(it2->str());
                count++;
            }
            LOG_DEBUG("delete access in core:"<<count);

            count = 0;
            std::set<nb_id_t>::iterator it3 = m_core_ids->m_conts.cont_des_ids.begin();
            for (; it3 != m_core_ids->m_conts.cont_des_ids.end(); ++it3)
            {
                if(it3->get_type() == NBID_TYPE_OBJECT_CONTAINER_DEF)
                    ret = ac_object_db_impl::instance().del(it3->str());
                count++;
            }
            LOG_DEBUG("delete container_def in core:"<<count);
        }

        // media
        std::set<duke_media_handle>::iterator it;
        {
            int count = 0;
            //delete tempobj container_data, access_data, cont_def_data
            it = m_tmp_ids->m_conts.cont_ids.begin();
            for (; it != m_tmp_ids->m_conts.cont_ids.end(); ++it)
            {
                ret = duke_media_tempobj_db::instance().del(it->str());
                count++;
            }
            LOG_DEBUG("delete container in editing status:"<<count); 
    
            count = 0;
            it = m_tmp_ids->m_conts.ac_ids.begin();
            for (; it != m_tmp_ids->m_conts.ac_ids.end(); ++it)
            {
                ret = duke_media_tempobj_db::instance().del(it->str());
                count++;
            }
            LOG_DEBUG("delete access in editing status:"<<count);
            
            count = 0;
            it = m_tmp_ids->m_conts.cont_des_ids.begin();
            for (; it != m_tmp_ids->m_conts.cont_des_ids.end(); ++it)
            {
                if (it->get_type() == DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF)
                {
                    ret = duke_media_tempobj_db::instance().del(it->str());
                    count++;
                }
            }
            LOG_DEBUG("delete container_def in editing status:"<<count);

            // delete formobjs container_data, access_data, cont_def_data
            count = 0;
            it = m_form_ids->m_conts.cont_ids.begin();
            for (; it != m_form_ids->m_conts.cont_ids.end(); ++it)
            {
                ret = duke_media_formobj_db::instance().del(it->str());
                count++;
            }
            LOG_DEBUG("delete container in generated status:"<<count);
    
            count = 0;
            it = m_form_ids->m_conts.ac_ids.begin();
            for (; it != m_form_ids->m_conts.ac_ids.end(); ++it)
            {
                ret = duke_media_formobj_db::instance().del(it->str());
                count++;
            }
            LOG_DEBUG("delete access in generated status:"<<count);
    
            count =0;
            it = m_form_ids->m_conts.cont_des_ids.begin();
            for (; it != m_form_ids->m_conts.cont_des_ids.end(); ++it)
            {
                if(it->get_type() == DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF)
                {
                    ret = duke_media_formobj_db::instance().del(it->str());
                    count++;
                }
            }
            LOG_DEBUG("delete container_def in generated status:"<<count);

            //delete warehouse container_id, access_id, cont_def_id
            std::vector<std::string>::iterator iter = m_users->begin();
            for (; iter != m_users->end(); ++iter)
            {
                duke_media_remove_container(*iter);
                duke_media_remove_container_des(*iter);
                duke_media_remove_shared_container(*iter);
                duke_media_remove_shared_container_des(*iter);
                duke_media_remove_container_des(*iter);
                duke_media_remove_access(*iter);
                duke_media_remove_shared_access(*iter);
            }
        }
        return true;
    }

    virtual bool stop()
    {
        scaner_job_base::stop();
        
        return true;
    }

private:

};

typedef std::tr1::shared_ptr<new_container_decl_job>  new_container_decl_job_ptr;

#endif /* _NEW_CONTAINER_DECL_JOB_H_ */
