/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _CORE_STATISTIC_INFO_H_
#define _CORE_STATISTIC_INFO_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_manager.h"
#include "ac_id_dispenser.h"

struct nb_entire_objs
{
    std::set<nb_id_t>          total_objs;

    std::set<nb_id_t>          built_objs;               //0x40 ~ 0x51 (except 0x50, 0x4f)
    std::set<nb_id_t>          user_objs;                //0x80
    //std::set<nb_id_t>        access_objs;            //0x81
    //std::set<nb_id_t>        cont_des_objs;          //0x82
    //std::set<nb_id_t>        bridge_if_objs;         //0x83
    //std::set<nb_id_t>        decl_comp_objs;         //0x84
    //std::set<nb_id_t>        if_comp_objs;           //0x85
    //std::set<nb_id_t>        impl_objs;              //0x86
    //std::set<nb_id_t>        exec_cond_objs;         //0x87
    //std::set<nb_id_t>        exec_it_objs;           //0x88
    //std::set<nb_id_t>        exec_an_objs;           //0x89
    //std::set<nb_id_t>        exec_st_objs;           //0x8a
    //std::set<nb_id_t>        exec_obj_objs;          //0x8b
    std::set<nb_id_t>          des_objs;                 //0x8c
    std::set<nb_id_t>          id_stand_objs;            //0x8d
    //std::set<nb_id_t>        decl_exp_objs;          //0x8e
    //std::set<nb_id_t>        if_exp_objs;            //0x8f
    
    std::set<nb_id_t>          bridge_objs;              //0xc0
    std::set<nb_id_t>          exception_objs;           //0xc1

    std::size_t size()
    {
        /*
        std::size_t sum = built_objs.size() + user_objs.size() + access_objs.size() + cont_des_objs.size() 
            + bridge_if_objs.size() + decl_comp_objs.size() + if_comp_objs.size() + impl_objs.size() 
            + exec_cond_objs.size() + exec_it_objs.size() + exec_an_objs.size() + exec_st_objs.size()
            + exec_obj_objs.size() + des_objs.size() + id_stand_objs.size() + decl_exp_objs.size() + if_exp_objs.size()
            + bridge_objs.size() + exception_objs.size();
        */
        std::size_t sum = built_objs.size() + user_objs.size() + des_objs.size() + id_stand_objs.size() 
            + bridge_objs.size() + exception_objs.size();
        assert(sum == total_objs.size()); 
        return sum;
    }

    void clear()
    {
        total_objs.clear();

        built_objs.clear();
        user_objs.clear();
        //access_objs.clear();
        //cont_des_objs.clear()
        //bridge_if_objs.clear();
        //decl_comp_objs.clear();
        //if_comp_objs.clear();
        //impl_objs.clear();
        //exec_cond_objs.clear(); 
        //exec_it_objs.clear(); 
        //exec_an_objs.clear(); 
        //exec_st_objs.clear();
        //exec_obj_objs.clear();
        des_objs.clear(); 
        id_stand_objs.clear();
        //decl_exp_objs.clear();
        //if_exp_objs.clear();
        bridge_objs.clear();
        exception_objs.clear();
    }
};

struct nb_entire_ifs
{
    std::set<nb_id_t>        total_ifs;
    
    std::set<nb_id_t>        built_ifs;   //0x50
    std::set<nb_id_t>        bridge_ifs;  //0x83
    std::set<nb_id_t>        com_ifs;     //0x85
    std::set<nb_id_t>        exp_ifs;     //0x8f

    std::size_t size()
    {
        std::size_t sum = built_ifs.size() + bridge_ifs.size() + com_ifs.size() + exp_ifs.size();
        assert(sum == total_ifs.size()); 
        return sum;
    }

    void clear()
    {
        total_ifs.clear();
        
        built_ifs.clear();
        bridge_ifs.clear();
        com_ifs.clear();
        exp_ifs.clear();
    }
};

struct nb_entire_decls
{
    std::set<nb_id_t>        total_decls;
    
    std::set<nb_id_t>        built_decls;    //0x4f
    std::set<nb_id_t>        com_decls;      //0x84
    std::set<nb_id_t>        exp_decls;      //0x8e
    std::set<nb_id_t>        spe_decls;      //0x90 ~ 0x97

    std::size_t size()
    {
        std::size_t sum = built_decls.size() + com_decls.size() + exp_decls.size() + spe_decls.size();
        assert(sum == total_decls.size()); 
        return sum;
    }

    void clear()
    {
        total_decls.clear();
        
        built_decls.clear();
        com_decls.clear();
        exp_decls.clear();
        spe_decls.clear();
    }
};

struct nb_entire_impls
{
    std::set<nb_id_t>        total_impls;

    std::set<nb_id_t>        impl_objs;              //0x86
    std::set<nb_id_t>        exec_cond_objs;         //0x87
    std::set<nb_id_t>        exec_it_objs;           //0x88
    std::set<nb_id_t>        exec_an_objs;           //0x89
    std::set<nb_id_t>        exec_st_objs;           //0x8a
    std::set<nb_id_t>        exec_obj_objs;          //0x8b

    std::size_t size()
    {
        std::size_t sum = impl_objs.size() + exec_cond_objs.size() + exec_it_objs.size() + exec_an_objs.size()
            + exec_st_objs.size() + exec_obj_objs.size();
        assert(sum == total_impls.size()); 
        return sum;
    }

    void clear()
    {
        total_impls.clear();

        impl_objs.clear();
        exec_cond_objs.clear();
        exec_it_objs.clear();
        exec_an_objs.clear();
        exec_st_objs.clear();
        exec_obj_objs.clear();
    }
};   

struct nb_entire_conts
{
    std::set<access_id_t>           ac_ids;        //0x81
    std::set<container_id_t>        cont_ids;      //0x01
    std::set<nb_id_t>               cont_des_ids;  //0x82

    std::set<storage_id_t>          st_ids;        //0x02 ~ 0x0a
    std::set<anchor_id_t>           an_ids;        //0x0b

    std::size_t size()
    {
        return ac_ids.size() + cont_ids.size() + cont_des_ids.size() + st_ids.size() + an_ids.size();
    }

    void clear()
    {
        ac_ids.clear();
        cont_ids.clear();
        cont_des_ids.clear();
        st_ids.clear();
        an_ids.clear();
    }
};

struct nb_entire_bridges
{
    std::set<bridge_id_t>           bridge_ids;
    std::set<bridge_factory_id_t>   bf_ids;

    std::size_t size()
    {
        return bridge_ids.size() + bf_ids.size();
    }

    void clear()
    {
        bridge_ids.clear();
        bf_ids.clear();
    }
};

struct nb_entire_ids
{
    nb_entire_objs             m_objs;
    nb_entire_ifs              m_ifs;
    nb_entire_decls            m_decls;
    nb_entire_impls            m_impls;
    nb_entire_conts            m_conts;
    nb_entire_bridges          m_bridges;
    std::set<nb_id_t>          m_unkown_ids;

    std::size_t size()
    {
        return m_objs.size() + m_ifs.size() + m_decls.size() + m_impls.size() + m_conts.size()
            + m_bridges.size() + m_unkown_ids.size();
    }

    void clear()
    {
        m_objs.clear();
        m_ifs.clear();
        m_decls.clear();
        m_impls.clear();
        m_conts.clear();
        m_bridges.clear();
        m_unkown_ids.clear();
    }

    void dump()
    {
    }
};

#endif /*  _CORE_STATISTIC_INFO_H_ */
