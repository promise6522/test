/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _SCANER_JOB_BASE_H_
#define _SCANER_JOB_BASE_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_manager.h"
#include "ac_id_dispenser.h"
#include "duke_media_global.h"

class scaner_job_base
{    
public:
    scaner_job_base()
    {
    }

    virtual ~scaner_job_base()
    {
    }

    virtual void init(std::vector<std::string>* users,  nb_entire_ids* core_ids,
                      media_entire_ids* form_ids, media_entire_ids* tmp_ids)
    {
        m_users = users;
        m_core_ids = core_ids;
        m_form_ids = form_ids;
        m_tmp_ids = tmp_ids;
    }

    virtual bool start()      
    {
        return true;
    }

    virtual bool run()
    {
        return true;
    }

    virtual bool stop()
    {    
        return true;
    }

    virtual std::string name()
    {
        return m_name;
    }

protected:
    bool ac_id_dispenser_request_nb_id(const request_nb_id_info& input, nb_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_nb_id(input, output);
        }
        return false;
     };

    bool ac_id_dispenser_request_host_committer_id(host_committer_id_t& output)
    {
        ac_id_t dest_id = g_ac_id_dispenser_acid;

        ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->request_host_committer_id(output);
        }
        return false;
    }; 

protected:
    std::string m_name;

    std::vector<std::string>*    m_users;
    nb_entire_ids*               m_core_ids;
    media_entire_ids*            m_form_ids;
    media_entire_ids*            m_tmp_ids;
};

typedef std::tr1::shared_ptr<scaner_job_base>  scaner_job_base_ptr;

#endif /* _NB_SCANER_H_ */
