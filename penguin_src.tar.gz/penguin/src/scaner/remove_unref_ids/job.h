/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _REMOVE_UNREF_IDS_JOB_H_
#define _REMOVE_UNREF_IDS_JOB_H_

#include "../scaner_job_base.h"

#include <vector>
#include <boost/tr1/memory.hpp>

#include "ac_global_db.h"
#include "duke_stash_db.h"

class remove_unref_ids_job : public scaner_job_base
{    
public:

    remove_unref_ids_job() : scaner_job_base(), m_remove_count(0)
    {
        m_name = "remove_unref_ids_job";
    }
    
    virtual bool start()
    {
        scaner_job_base::start();

        return true;
    }

    virtual bool run()
    {
        scaner_job_base::run();

        scan_core_ref_ids();
        scan_is_ref_ids();

        find_core_unref_ids();
        find_core_ref_mis_ids();
        
        delete_core_unref_ids();
        
        return true;
    }

    virtual bool stop()
    {
        scaner_job_base::stop();

        LOG_NOTICE("Total size of id size in core : " << m_in_core_ids.size());
        LOG_NOTICE("Total size of ref id size in core/is : " << m_core_ref_ids.size());
        LOG_NOTICE("Total size of unreference id in core : " << m_core_unref_ids.size());
        LOG_NOTICE("Total size of refered but missing id in core : " << m_core_ref_mis_ids.size());
        LOG_NOTICE("Total removed id in core : " << m_remove_count);
        
        return true;
    }
private:
    void scan_core_ref_ids()
    {   
        //object 
        for(std::set<nb_id_t>::iterator it = this->m_core_ids->m_objs.total_objs.begin();
            it != m_core_ids->m_objs.total_objs.end(); ++it)
        {
            m_in_core_ids.insert(*it);
            add_sub_ref_ids(*it);
        }

        //interface 
        for(std::set<nb_id_t>::iterator it = m_core_ids->m_ifs.total_ifs.begin();
            it != m_core_ids->m_ifs.total_ifs.end(); ++it)
        {
            m_in_core_ids.insert(*it);
            add_sub_ref_ids(*it);
        }

        //decl 
        for(std::set<nb_id_t>::iterator it = m_core_ids->m_decls.total_decls.begin();
            it != m_core_ids->m_decls.total_decls.end(); ++it)
        {
            m_in_core_ids.insert(*it);
            add_sub_ref_ids(*it);
        }

        //impl 
        for(std::set<nb_id_t>::iterator it = m_core_ids->m_impls.total_impls.begin();
            it != m_core_ids->m_impls.total_impls.end(); ++it)
        {
            m_in_core_ids.insert(*it);
            add_sub_ref_ids(*it);
        }

        //cont des
        for(std::set<nb_id_t>::iterator it = m_core_ids->m_conts.cont_des_ids.begin();
            it != m_core_ids->m_conts.cont_des_ids.end(); ++it)
        {
            m_in_core_ids.insert(*it);
            add_sub_ref_ids(*it);

            std::string strval;
            NbDbResult ret = ac_object_db_impl::instance().read(it->str(), strval);
            assert(ret == NB_DB_RESULT_SUCCESS);
            content raw_data;
            unpack_object(strval, raw_data);

            cont_def_data_t cdef_data;
            nb_id_t cdef_id;
            obj_impl_container_def::unpack(raw_data, cdef_id, cdef_data);

            for(std::vector<storage_info_t>::iterator iter = cdef_data.storages.begin();
                iter != cdef_data.storages.end(); ++iter)
            {
                m_core_ref_ids.insert(iter->interface);
                add_sub_ref_ids(iter->interface);
            }

            for(std::vector<anchor_info_t>::iterator iter = cdef_data.anchors.begin();
                iter != cdef_data.anchors.end(); ++iter)
            {
                m_core_ref_ids.insert(iter->interface);
                add_sub_ref_ids(iter->interface);

                for(func_vector_it fit = iter->funcs.begin(); fit != iter->funcs.end(); ++fit)
                {
                    //decl
                    m_core_ref_ids.insert(fit->declaration_id);
                    add_sub_ref_ids(fit->declaration_id);
                    //impl
                    m_core_ref_ids.insert(fit->implementation_id);
                    add_sub_ref_ids(fit->implementation_id);
                }
            }
            
        }
    }

    void scan_is_ref_ids()
    {
        std::vector<std::string> users;
        duke_media_get_register_users(users);
        users.push_back("anonymous-name");

        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )        
        {
            //for object
            duke_media_handle_vector handles;
            duke_media_get_objects(*it, handles);
            add_is_ref_ids(handles);
            
            //for interface
            handles.clear();
            duke_media_get_compound_interfaces(*it, handles);
            add_is_ref_ids(handles);

            //for decl
            handles.clear();
            duke_media_get_declarations(*it, handles);
            add_is_ref_ids(handles);

            //for impl
            handles.clear();
            duke_media_get_implementations(*it, handles);
            add_is_ref_ids(handles);

            //for container des
            handles.clear();
            duke_media_get_containers_def(*it, handles);
            add_is_ref_ids(handles);

            //for access?
            /*
            handle.clear();
            duke_media_get_accesses(*it, handles);
            add_is_ref_ids(handles);
            */
            
            //for share object
            handles.clear();
            duke_media_get_shared_objs(*it, handles);
            add_is_ref_ids(handles);
        }

        //for bridge object
        duke_media_handle_vector decls;
        duke_media_handle_vector objs;
        duke_media_get_bridge(objs, decls);
        add_is_ref_ids(objs);
        add_is_ref_ids(decls);

        //for outgoing interface
        duke_media_handle out_ac_if;
        duke_media_get_outgoing_access_if(out_ac_if);
        nb_id_t id(out_ac_if.str());
        m_core_ref_ids.insert(id);
        add_sub_ref_ids(id);

        //for semi decls
        duke_media_handle_vector semi_decls;
        duke_media_get_semi_decl(semi_decls);
        add_is_ref_ids(semi_decls);
    }

    void add_is_ref_ids(const duke_media_handle_vector& handles)
    {
        for(duke_media_handle_const_iterator it = handles.begin(); it != handles.end(); ++it)
        {
            nb_id_t id(it->str());
            m_core_ref_ids.insert(id);
            add_sub_ref_ids(id);
        }
    }

    void add_sub_ref_ids(nb_id_t id)
    {
        if (!id.is_persistent_type())
            return;

        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(id.str(), strval);
        if (ret != NB_DB_RESULT_SUCCESS)
        {
            LOG_ERROR(id.str() << " not found in core.");
            return;
        }

        content raw_data;
        unpack_object(strval, raw_data);

        for(nb_id_vector_it it = raw_data.id_value.ids.begin(); it != raw_data.id_value.ids.end(); ++it)
        {
            if (it->is_persistent_type())
            {
                m_core_ref_ids.insert(*it);
            }
        }
    }

    
    void find_core_unref_ids()
    {
        for(std::set<nb_id_t>::iterator it = m_in_core_ids.begin(); it != m_in_core_ids.end(); ++it)
        {
            std::set<nb_id_t>::iterator iter = m_core_ref_ids.find(*it);
            if(iter == m_core_ref_ids.end())
            {
                m_core_unref_ids.insert(*it);
            }
        }
    }
    
    void find_core_ref_mis_ids()
    {
        for(std::set<nb_id_t>::iterator it = m_core_ref_ids.begin(); it != m_core_ref_ids.end(); ++it)
        {
            std::set<nb_id_t>::iterator iter = m_in_core_ids.find(*it);
            if(iter == m_core_ref_ids.end())
            {
                m_core_ref_mis_ids.insert(*it);
            }
        }
    }

    void delete_core_unref_ids()
    {
        // begin a txn
        bool bRet;
        DbTxn* stashTxn = NULL;
        bRet = duke_stash_db::instance().txn_begin(stashTxn);
        assert(bRet);

        // the size of records is so big that we can't commit them in one txn
        const size_t records_per_txn = 1000;

        size_t i = 0;
        for(std::set<nb_id_t>::const_iterator it = m_core_unref_ids.begin();
                it != m_core_unref_ids.end(); ++it, ++i)
        {
            nb_id_t id = *it;

            if(id.is_object_string() || id.is_object_bytes() || id.is_object_array() || id.is_object_map())
                continue;

            // read the id 
            std::string strval;
            NbDbResult ret = ac_object_db_impl::instance().read(id.str(), strval);
            assert(ret == NB_DB_RESULT_SUCCESS);


            // write into stash db in case of later use
            bRet = duke_stash_db::instance().write(id.str(), strval, stashTxn);
            assert(bRet);


            // delete it from core db
            ret = ac_object_db_impl::instance().del(id.str());
            assert(ret == NB_DB_RESULT_SUCCESS);


            // commit the txn
            if (i % records_per_txn == 0) 
            {
                bRet = duke_stash_db::instance().commit(stashTxn);
                assert(bRet);

                stashTxn = NULL;
                bRet = duke_stash_db::instance().txn_begin(stashTxn);
                assert(bRet);
            }

            m_remove_count++;

            LOG_NOTICE("Delete id [ " << id.str() << " ] success, Total size of deleted ids : " <<m_remove_count);

        }

        bRet = duke_stash_db::instance().commit(stashTxn);
        assert(bRet);

    }

private:
    //all the id in core
    std::set<nb_id_t> m_in_core_ids;
    
    // all the reference id in core
    std::set<nb_id_t> m_core_ref_ids;

    // all the unreference id in core
    std::set<nb_id_t> m_core_unref_ids;
    
    // all the reference id but not in core
    std::set<nb_id_t> m_core_ref_mis_ids;

    // the remove count for ids
    std::size_t m_remove_count;
};

typedef std::tr1::shared_ptr<remove_unref_ids_job>  remove_unref_ids_job_ptr;

#endif /* _REMOVE_UNREF_IDS_JOB_H_ */
