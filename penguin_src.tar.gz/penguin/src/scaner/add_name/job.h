/**************************************************************************
**
**  Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _ADD_NAME_DECL_JOB_H_
#define _ADD_NAME_DECL_JOB_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_global_db.h"

#include "../scaner_job_base.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"

#include "duke_media_formobj_db.h"
#include "duke_logic_object_data.h"

class add_name_decl_job : public scaner_job_base
{    
public:

    add_name_decl_job()
        : scaner_job_base()
    {
        m_name = "add_name_decl_job";
    }
    
    virtual bool start()
    {
        scaner_job_base::start();

        return true;
    }

    virtual bool run()
    {
        scaner_job_base::run();

        // A: replace the core interface
        int total_num = 0;
        std::set<nb_id_t>::iterator if_it1 = m_core_ids->m_ifs.total_ifs.begin();
        for (; if_it1 != m_core_ids->m_ifs.total_ifs.end(); ++if_it1)
        {
            if (if_it1->is_builtin_interface())
                continue;

            // 1 get the old data 

            // get the data in core
            std::string strval;
            NbDbResult ret = ac_object_db_impl::instance().read(if_it1->str(), strval);
            if (ret != NB_DB_RESULT_SUCCESS)
                return false;

            // 2 create new data
            
            content raw_data;
            unpack_object(strval, raw_data);

            if_compound_data_t if_data;
            nb_id_t if_id;
            obj_impl_interface_compound::unpack(raw_data, if_id, if_data);

            // the last general decl (12th) is get_name decl
            if (if_data.decls.size() < 11)
                continue;

            nb_id_t get_name_decl = nb_id_t(NB_FUNC_GENERAL_GET_NAME);

            // create the new interface
            if (if_data.decls.size() == 11)
                if_data.decls.push_back(get_name_decl);
            else
                if_data.decls.insert(if_data.decls.begin() + 11, get_name_decl);

            content new_raw_data;
            obj_impl_interface_compound::pack(if_data, if_it1->str(), new_raw_data);

            // 3 write
            // write data to core
            ret = ac_object_db_impl::instance().write(if_it1->str(), pack_object(new_raw_data));
            assert(ret == NB_DB_RESULT_SUCCESS);
            if (if_it1->is_builtin_interface())
                continue;

            total_num++;
        }
        LOG_NOTICE("    * 1 core total interface id count is " << m_core_ids->m_ifs.total_ifs.size());
        LOG_NOTICE("    * 1 core replace interface id count is " << total_num);

        // B: replace the media formal interface
        total_num = 0;
        std::set<duke_media_handle>::iterator if_it2 = m_form_ids->m_ifs.total_ifs.begin();
        for (; if_it2 != m_form_ids->m_ifs.total_ifs.end(); ++if_it2)
        {
            if (if_it2->is_builtin_interface())
                continue;

            // 1 get the old data 

            // get the data in core
            std::string strval;
            NbDbResult ret = duke_media_formobj_db::instance().read(if_it2->str(), strval);
            if (ret != NB_DB_RESULT_SUCCESS)
                return false;

            // 2 create new data

            duke_media_compound_interface if_data((*if_it2), 1);
            //if_data.unpack(strval);

            // get_declarations
            std::vector<duke_media_handle>  vhdecls;
            if_data.get_declarations(vhdecls);

            // the last general decl (12th) is get_name decl
            if (vhdecls.size() < 11)
                continue;

            nb_id_t get_name_decl = nb_id_t(NB_FUNC_GENERAL_GET_NAME);

            // create the new interface
            if (vhdecls.size() == 11)
                vhdecls.push_back(get_name_decl);
            else
                vhdecls.insert(vhdecls.begin() + 11, get_name_decl);

            // set_declarations
            if_data.set_declarations(vhdecls);

            // 3 write

            // write data to media
            DbTxn* txn(NULL);
            ret = duke_media_formobj_db::instance().write(if_it2->str(), if_data.pack(), txn);
            assert(ret == NB_DB_RESULT_SUCCESS);

            total_num++;
        }
        LOG_NOTICE("    * 2 media total interface id count is " << m_form_ids->m_ifs.total_ifs.size());
        LOG_NOTICE("    * 2 media replace interface id count is " << total_num);

        // C: replace the media editing interface
        total_num = 0;
        std::set<duke_media_handle>::iterator if_it3 = m_tmp_ids->m_ifs.total_ifs.begin();
        for (; if_it3 != m_tmp_ids->m_ifs.total_ifs.end(); ++if_it3)
        {
            if (if_it3->is_builtin_interface())
                continue;

            // 1 get the old data 

            // get the data in core
            std::string strval;
            NbDbResult ret = duke_media_tempobj_db::instance().read(if_it3->str(), strval);
            if (ret != NB_DB_RESULT_SUCCESS)
                return false;

            // 2 create new data

            duke_media_compound_interface if_data((*if_it3), 1);
            //if_data.unpack(strval);

            // get_declarations
            std::vector<duke_media_handle>  vhdecls;
            if_data.get_declarations(vhdecls);

            // the last general decl (12th) is get_name decl
            if (vhdecls.size() < 11)
                continue;

            nb_id_t get_name_decl = nb_id_t(NB_FUNC_GENERAL_GET_NAME);

            // create the new interface
            if (vhdecls.size() == 11)
                vhdecls.push_back(get_name_decl);
            else
                vhdecls.insert(vhdecls.begin() + 11, get_name_decl);

            // set_declarations
            if_data.set_declarations(vhdecls);

            // 3 write

            // write data to media
            DbTxn* txn(NULL);
            ret = duke_media_tempobj_db::instance().write(if_it3->str(), if_data.pack(), txn);
            assert(ret == NB_DB_RESULT_SUCCESS);

            total_num++;
        }
        LOG_NOTICE("    * 3 media editing total interface id count is " << m_tmp_ids->m_ifs.total_ifs.size());
        LOG_NOTICE("    * 3 media editing replace interface id count is " << total_num);

        return true;
    }

    virtual bool stop()
    {
        scaner_job_base::stop();
        return true;
    }
};

typedef std::tr1::shared_ptr<add_name_decl_job>  add_name_decl_job_ptr;

#endif /* _ADD_NAME_DECL_JOB_H_ */
