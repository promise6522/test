/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"
#include "nb_configuration.h"
#include "ac_framework.h"
#include "nb_scaner.h"

int main(int argc, char* argv[])
{
    nb_configuration::instance().parse_option(argc, argv);
    nb_configuration::instance().dump_configuration();
    
    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    //Start ac_framework
    ac_framework framework(nb_configuration::instance().get_actor_thread_pool(), 
                           nb_configuration::instance().get_is_statistics(), 
                           nb_configuration::instance().get_statistics_interval());
    framework.init_framework(nb_configuration::instance().get_is_gc(),
                             nb_configuration::instance().get_gc_size(),
                             nb_configuration::instance().get_gc_rate());
    framework.run();


    //scaner
    nb_scaner scaner;
    scaner.run();
    
    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    framework.stop();

    return 0;    
}
