#include "duke_media_anchor.h"
#include "duke_media_global.h"
#include "stdx_log.h"

//this only for duke_media_base_factory
duke_media_anchor::duke_media_anchor()
{
}

duke_media_anchor::duke_media_anchor(const host_committer_id_t& host_id, const std::string& username)
    : duke_media_base(DUKE_MEDIA_TYPE_ANCHOR, host_id),
    hc_id(host_id)
{
    //save anchor data 
    bool ret = this->get_handle().set_value(this->pack_helper());
    assert(ret);

    ///save handle to user (comment out by tom)
}

duke_media_anchor::duke_media_anchor(const duke_media_handle& hanchor, const std::string& username)
{
    bool ret = this->assign(hanchor);
    assert(ret);

    ///save handle to user (comment out by tom)
}


bool duke_media_anchor::assign(const duke_media_handle& hanchor)
{
    //here assignment object must be a anchor
    assert(hanchor.is_anchor());

    //get data from database and assign it to anchor data struct
    std::string   value;
    this->set_handle_status( hanchor.get_value(value) );    //we can know where this id come from

    if (value.empty())
    {
        LOG_ERROR("error : this anchor " << hanchor.str() << " has no data!");
        return false;
    }

    //unpack data and set handle to this anchor
    this->unpack_helper(value);
    this->set_handle(hanchor);

    return true;
}

bool duke_media_anchor::copy(const duke_media_handle& hanchor)
{
    if (!hanchor.is_anchor())
    {
        return false;
    }

    //get data and unpack to data struct
    std::string strval;
    hanchor.get_value(strval);
    this->unpack(strval);

    //save data
    bool ret = this->save();
    return ret;
}

bool duke_media_anchor::set_name(const std::string& name)
{
    m_anchor.m_name = name;

    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);

    return this->save();
}

bool duke_media_anchor::get_name(std::string& name) const
{
    name = m_anchor.m_name;
    return true;
}

bool duke_media_anchor::set_icon(const std::string& icon)
{
    m_anchor.m_icon = icon;
    return this->save();
}

bool duke_media_anchor::get_icon(std::string& icon) const
{
    icon = m_anchor.m_icon;
    return true;
}

bool duke_media_anchor::set_index(int index)
{
    m_anchor.index = index;
    return this->save();
}

int duke_media_anchor::get_index() const
{
    return m_anchor.index;
}

bool duke_media_anchor::clear()
{
    m_anchor.m_hdecls.clear();
    m_anchor.m_exhdecls.clear();

    return this->save();
}

bool duke_media_anchor::get_interface(duke_media_handle& hif, const host_committer_id_t& host_id) const
{
    //create a new interface to store all declaration 
    duke_media_compound_interface mif(host_id);
    for(duke_media_handle_const_iterator it = m_anchor.m_hdecls.begin();
            it != m_anchor.m_hdecls.end(); ++it)
    {
        mif.add_declaration(*it);
    }
    mif.set_decl_type(NB_INTERFACE_ANCHOR);
    hif = mif.get_handle();

    return true;        
}

void duke_media_anchor::get_hcontainer(duke_media_handle& handle) const
{
    handle = m_anchor.m_hcontainer;
}

bool duke_media_anchor::set_hcontainer(const duke_media_handle& handle)
{
    assert(handle.is_object_container_des());

    m_anchor.m_hcontainer = handle;

    return this->save();
}

bool duke_media_anchor::add_declaration(const duke_media_handle& hdecl, const enum decl_status& status, int index)
{
    assert(hdecl.is_declaration());

    if (status == Normal)
        m_anchor.m_hdecls.push_back(hdecl);
    else if (status == Excl)
        m_anchor.m_exhdecls.push_back(hdecl);

    return this->save();
}

bool duke_media_anchor::del_declaration(const duke_media_handle& hdecl, const enum decl_status& status)
{
    assert(hdecl.is_declaration());
    duke_media_handle_iterator it;
    if (status == Normal)
    {
        if ((it = std::find(m_anchor.m_hdecls.begin(), m_anchor.m_hdecls.end(), hdecl)) != m_anchor.m_hdecls.end()) 
        {
            m_anchor.m_hdecls.erase(it);
            return this->save();
        }
    }
    else if (status == Excl)
    {
        if ((it = std::find(m_anchor.m_exhdecls.begin(), m_anchor.m_exhdecls.end(), hdecl)) != m_anchor.m_exhdecls.end()) 
        {
            m_anchor.m_exhdecls.erase(it);
            return this->save();
        }
    }
    return true;
}

bool duke_media_anchor::find_declaration(const duke_media_handle& hdecl)
{
    return (std::find(m_anchor.m_hdecls.begin(), m_anchor.m_hdecls.end(), hdecl) != m_anchor.m_hdecls.end());
}

bool duke_media_anchor::find_exdeclaration(const duke_media_handle& hdecl)
{
    return (std::find(m_anchor.m_exhdecls.begin(), m_anchor.m_exhdecls.end(), hdecl) != m_anchor.m_exhdecls.end());
}

bool duke_media_anchor::add_declaration(const duke_media_handle_vector& vdecl, const enum decl_status& status)
{
    if (status == Normal)
        m_anchor.m_hdecls = vdecl;
    else if (status == Excl)
        m_anchor.m_exhdecls = vdecl;
    return this->save();
}

void duke_media_anchor::get_declaration(duke_media_handle_vector& vdecl, const enum decl_status& status) const
{
    if (status == Normal)
        vdecl = m_anchor.m_hdecls;
    else if (status == Excl)
        vdecl = m_anchor.m_exhdecls;
}        


void duke_media_anchor::set_type_index(int index)
{
    /*
    duke_media_handle_vector vdecl;
    this->get_declaration(vdecl, Normal);
    for (duke_media_handle_const_iterator it = vdecl.begin(); it != vdecl.end(); ++it)
    {
        duke_media_compound_declare mdecl(1, *it);
        mdecl.set_index(index);
    }

    vdecl.clear();
    this->get_declaration(vdecl, Excl);
    for (duke_media_handle_const_iterator it = vdecl.begin(); it != vdecl.end(); ++it)
    {
        duke_media_compound_declare mdecl(1, *it);
        mdecl.set_index(index);
    }*/
}

//bool duke_media_anchor::create_access(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id,
//                                      const std::string& accessName, const duke_media_handle& hfather)
//{
//    duke_media_access access(host_id);
//    duke_media_handle_vector vhdecls;
//
//    for (duke_media_handle_iterator it = m_anchor.m_hdecls.begin(); it != m_anchor.m_hdecls.end(); ++it)
//    {
//        if ((duke_media_get_handle_status(username, *it) == Build) ||
//           (duke_media_get_handle_status(username, *it) == Notfound))
//        {
//            vhdecls.push_back(*it);
//            continue;
//        }
//        duke_media_handle hnew;
//        bool ret = duke_media_read_pair_handle(hfather, (*it), hnew);
//        assert(ret);
//        if (hnew.is_type_null())
//            assert(false);
//        vhdecls.push_back(hnew);
//    }       
//
//    for (duke_media_handle_iterator it = m_anchor.m_exhdecls.begin(); it != m_anchor.m_exhdecls.end(); ++it)
//    {
//        if ((duke_media_get_handle_status(username, *it) == Build) ||
//                (duke_media_get_handle_status(username, *it) == Notfound))
//        {
//            vhdecls.push_back(*it);
//            continue;
//        }
//        duke_media_handle hnew;
//        bool ret = duke_media_read_pair_handle(hfather, (*it), hnew);
//        assert(ret);
//        if (hnew.is_type_null())
//            assert(false);
//        vhdecls.push_back(hnew); 
//    }
//
//    bool ret = access.add_declarations(vhdecls);
//    assert(ret);
//    ret = access.set_name(accessName);
//    ret = access.set_container(m_anchor.m_hcontainer);
//    access.set_anchor_idx(m_anchor.index);
//    assert(ret);
//
//    duke_media_handle hnew;
//    ret = access.generate(username, hnew, host_id);
//    assert(ret);
//    handle = hnew;
//    LOG_DEBUG("create access:" << handle.str());
//    return ret;
//}

bool duke_media_anchor::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//    std::string strkey = username + "-anchor";
//    std::string strval;
//    assert(this->get_handle().is_anchor());
//
//    duke_media_anchor anchor(host_id, username);
//    bool ret = this->get_handle().get_value(strval);
//    assert(ret);
//
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(anchor.get_handle(), strname);
//    assert(ret);
//
//    ret = duke_media_write_pair_handle(hfather, this->get_handle(), anchor.get_handle());
//    assert(ret);
//
//    replace_content(username, strval, host_id, hfather);
//
//    anchor.unpack(strval);
//
//    ret = anchor.get_handle().set_value(strval);
//    assert(ret);
//
//    duke_media_remove_handle("anonymous-name-tmp-anchor", anchor.get_handle());
//    duke_media_remove_handle(username + "-tmp-anchor", anchor.get_handle());
//
//    strval = ""; 
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + anchor.get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//    handle = anchor.get_handle();
//
//    anchor.pack_new_structure(username, host_id, m_anchor.m_hcontainer.str());
//
//    // remove from temp media about anchor
//    unsigned int iret = duke_media_tempobj_db::instance().del(anchor.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << anchor.get_handle().str() << " anchor in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << anchor.get_handle().str() << " anchor in temp media failed;");
//
//    return ret;
    return true;
}


std::string duke_media_anchor::pack() const
{
    return this->pack_helper();
}

std::string duke_media_anchor::pack_helper() const
{
    return m_anchor.pack();
}

void duke_media_anchor::unpack(const std::string& strval)
{
    m_anchor.unpack(strval);
}

void duke_media_anchor::unpack_helper(const std::string& strval)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_anchor.unpack(strval);
    }
    else if (status == e_handle_core)
    {
        if (!strval.empty())
        {
            content value;
            unpack_object(strval, value);
            
            anchor_data_t data_t;
            anchor_implementation::unpack(value, data_t);

            m_anchor.m_name = data_t.name;
            ifc_id = data_t.interface;
            for (func_vector_const_it it = data_t.funcs.begin(); it != data_t.funcs.end(); ++it)
            {
                duke_media_handle hdecl;
                hdecl.str(it->declaration_id.str());

                m_anchor.m_hdecls.push_back(hdecl);
            }
        }
    }
    else
    {
        LOG_ERROR("object handle: " << this->get_handle().str() << " has not exist in db");
    }
}

//bool duke_media_anchor::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    duke_media_handle hcon;
//    bool ret = duke_media_read_pair_handle(hfather, m_anchor.m_hcontainer, hcon);
//    assert(ret);
//    if (hcon.is_type_null())
//        assert(false);
//    duke_media_replace_handle(strval, m_anchor.m_hcontainer, hcon);
//    for (dukeid_vector_const_iterator it = m_anchor.m_hdecls.begin(); it != m_anchor.m_hdecls.end(); ++it)
//    {
//        if ((duke_media_get_handle_status(username, *it) == Build) ||
//                (duke_media_get_handle_status(username, *it) == Notfound))
//            continue;
//
//        duke_media_handle hnew;
//        bool ret = duke_media_read_pair_handle(hfather, (*it), hnew);
//        assert(ret);
//        if (hnew.is_type_null())
//            assert(false);
//        duke_media_replace_handle(strval, (*it), hnew); 
//    }
//
//    for (dukeid_vector_const_iterator it = m_anchor.m_exhdecls.begin(); it != m_anchor.m_exhdecls.end(); ++it)
//    {
//        if (duke_media_get_handle_status(username, *it) == Build)
//            continue;
//
//        duke_media_handle hnew;
//        bool ret = duke_media_read_pair_handle(hfather, (*it), hnew);
//        assert(ret);
//        if (hnew.is_type_null())
//            assert(false);
//        duke_media_replace_handle(strval, (*it), hnew); 
//    }
//
//    return true;
//}

//bool duke_media_anchor::pack_new_structure(const std::string& username, const host_committer_id_t& host_id, const nb_id_t& old_cid)
//{
//    // fill to new structure
//    anchor_data_t data_t;
//    data_t.name = m_anchor.m_name;
//
//    if (ifc_id.is_type_null())
//    {
//        duke_media_compound_interface ifc(host_id);
//        ifc_id.str(ifc.get_handle().str());
//    }
//
//    for (dukeid_vector_const_iterator it = m_anchor.m_hdecls.begin(); it != m_anchor.m_hdecls.end(); ++it)
//    {
//        func_pair_t tmp_func;
//        //tmp_func.declaration_id = (*it);
//        tmp_func.declaration_id.str((*it).str());
//
//        duke_media_handle holdimpl, hnewimpl, himpl;
//
//        duke_media_container con_old(1, old_cid);
//        bool ret = con_old.get_implementation((*it), holdimpl);
//        //assert(ret);
//        himpl = holdimpl;
//
//        duke_media_container con_new(1, m_anchor.m_hcontainer);
//        ret = con_new.get_implementation((*it), hnewimpl);
//        //assert(ret);
//        if (!holdimpl.is_type_null() && !hnewimpl.is_type_null())
//        {
//            /*
//            duke_media_container con_new(1, m_anchor.m_hcontainer);
//            ret = con_new.get_implementation((*it), himpl);
//            if (himpl.is_type_null())
//                assert(ret);*/
//            himpl = hnewimpl;
//        }
//        else if (holdimpl.is_type_null())
//            himpl = hnewimpl;
//        else if (hnewimpl.is_type_null())
//            himpl = holdimpl;
//        //tmp_func.implementation_id = himpl;
//        tmp_func.implementation_id.str(himpl.str());
//
//        data_t.funcs.push_back(tmp_func);
//        duke_media_compound_interface ifc(ifc_id);
//        ifc.add_declaration((*it));
//        duke_media_handle handle;
//        handle.str(ifc_id.str());
//        ifc.set_decl_type(NB_INTERFACE_ANCHOR);
//        ifc.pack_new_structure();
//    }
//
//    for (dukeid_vector_const_iterator it = m_anchor.m_exhdecls.begin(); it != m_anchor.m_exhdecls.end(); ++it)
//    {
//        func_pair_t tmp_func;
//        //tmp_func.declaration_id = it->first;
//        tmp_func.declaration_id.str((*it).str());
//        duke_media_container con(1, old_cid);
//
//        duke_media_handle himpl;
//        bool ret = con.get_implementation((*it), himpl);
//        assert(ret);
//        //tmp_func.implementation_id = himpl;
//        tmp_func.implementation_id.str(himpl.str());
//
//        data_t.funcs.push_back(tmp_func);
//        duke_media_compound_interface ifc(ifc_id);
//        ifc.add_declaration((*it));
//        duke_media_handle handle;
//        handle.str(ifc_id.str());
//        ifc.set_decl_type(NB_INTERFACE_ANCHOR);
//        ifc.pack_new_structure();
//    }
//    data_t.registed = false;
//
//    content tmp_content;
//    anchor_implementation::pack(data_t, tmp_content);
//
//    std::string strval = pack_object(tmp_content);
//
//    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//    return true;
//}

// vim:set tabstop=4 shiftwidth=4 expandtab:
