#ifndef __DUKE_MEDIA_VERIFY_H
#define __DUKE_MEDIA_VERIFY_H

// C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// duke header file
//#include "core/duke_core_base.h"
//#include "media/duke_media_header.h"

struct duke_user_info
{
    std::string username;
    std::string pwd;
    std::string id_card;

    std::string pack() const
    {
        std::string strinfo;
        strinfo += "(" + username + ")";
        strinfo += "(" + pwd + ")";
        strinfo += "(" + id_card + ")";

        return strinfo;
    }

    void unpack(const std::string& strinfo)
    {
        std::string::size_type idx(0);
        std::string strusername, strpwd, strid_card;

        // get all string
        idx = find_between(strinfo, strusername, "(", ")", idx);
        idx = find_between(strinfo, strpwd, "(", ")", idx);
        idx = find_between(strinfo, strid_card, "(", ")", idx);

        this->username = strusername;
        this->pwd = strpwd;
        this->id_card = strid_card;
    }
};

typedef struct duke_user_info du_info;

class duke_media_verify
{
private:
    std::vector<du_info> m_info;

private:
    typedef std::vector<du_info>::const_iterator du_const_iterator;

public:
    duke_media_verify()
    {
        this->attach();
    } 

    void attach()
    {
        std::string strval;
        this->get_value(strval);
        if (!strval.empty())
        {
            this->unpack(strval);
        }
    }

    bool register_user(const std::string& username, const std::string& pwd, const std::string& id_card)
    {
        if (!verify_user(username))
        {
            du_info info;
            info.username = username;
            info.pwd = pwd;
            info.id_card = id_card;
            m_info.push_back(info);
        }
        return this->save();
    }
    
    void get_info(std::vector<du_info>& info)
    {
        info = m_info;
    }

    void get_all_users(std::vector<std::string>& vusers)
    {
        for (du_const_iterator it = m_info.begin(); it != m_info.end(); ++it)
            vusers.push_back(it->username);
    }

    std::string pack() const
    {
        std::string strinfo;
        for (du_const_iterator it = m_info.begin(); it != m_info.end(); ++it)
            strinfo += "{" + it->pack() + "}";
        return strinfo;
    }

    void unpack(const std::string& strinfo)
    {
        std::string strh;
        this->m_info.clear();
        std::string::size_type pos(0);
        while ((pos = find_between(strinfo, strh, "{", "}", pos)) != std::string::npos)
        {
            du_info info;
            info.unpack(strh);
            this->m_info.push_back(info);
        }
    }

public:
    bool save()
    {
        bool ret = duke_media_write_handle("register_user", this->pack());
        assert(ret);
        return ret;    
    }

    bool get_value(std::string& strval)
    {
        duke_media_read_handle("register_user", strval);
        return true;
    }

    bool verify_user(const std::string& username)
    {
        for (du_const_iterator it = m_info.begin(); it != m_info.end(); ++it)
        {
             if (it->username == username)
                return true;
        }
        return false;
    }
};

#endif /* __DUKE_MEDIA_VERIFY_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
