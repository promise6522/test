#include "duke_media_declare_expanded.h"
#include "duke_media_global.h"

duke_media_declare_expanded::duke_media_declare_expanded()
{
}

duke_media_declare_expanded::duke_media_declare_expanded(const host_committer_id_t& host_id, 
        const std::string& username)
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_DECLARATION_EXPANDED, host_id), 
        hc_id(host_id)    
{
    bool ret = init_save();
    assert(ret);
}

duke_media_declare_expanded::duke_media_declare_expanded(const duke_media_handle& decl_handle, 
        const std::string& username)
{
    assert(decl_handle.is_object_decl_expanded());

    //recover data to data struct of declare_expanded
    bool ret = this->assign(decl_handle);
    assert(ret);
}

duke_media_declare_expanded::~duke_media_declare_expanded()
{
}

bool duke_media_declare_expanded::get_dynamic_info(duke_logic_data_declare_compound&  info) const
{
    //save compound_interface information, it can accelerate load expanded_declare informaion
    static table local_ifTable;

    //get port information from template
    get_builitin_decl_compound(m_cData.m_decl_id, info);

    //set the arguments to template
    assert(m_cData.m_vif.size() == info.groups.size());
    for(std::size_t i  = 0; i < info.groups.size(); ++i)
    {
        assert(m_cData.m_vif.at(i).is_interface());
        info.groups.at(i).min_if = m_cData.m_vif.at(i);
    }

    //here create a table,get information of every port,like every port has how many arguement of template
    mStrVid      vec;
    for(std::size_t i = 0; i < info.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < info.groups[i].members.size(); ++j)
        {
            if(-1 != info.groups[i].members[j].relay_idx)
            {
                std::string strval = (info.groups[i].members[j].is_input ? "input" : "ouput") + 
                    to_string(info.groups[i].members[j].port_idx);
                mStrVid_ite ite = vec.find(strval);

                if(ite != vec.end())
                {
                    ite->second.push_back(info.groups[i].min_if);
                }
                else
                {
                    std::vector<dukeid_t> vHandle;
                    vHandle.push_back(info.groups[i].min_if);
                    vec.insert(std::make_pair(strval, vHandle));
                }
            }
        }
    }

    //do main job: template instantiation from information in up
    for( std::size_t i = 0; i < info.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < info.groups[i].members.size(); ++j)
        {
            //instantiation groups one by one
            if( -1 == info.groups[i].members[j].relay_idx) //the same type with instantiation type:T
            {
                if(info.groups[i].members[j].is_input) //in_port
                {
                    info.iports[info.groups[i].members[j].port_idx].interface = info.groups[i].min_if;
                }
                else //out_port
                {
                    info.oports[info.groups[i].members[j].port_idx].interface = info.groups[i].min_if;
                }
            }
            else //compound interface:array<T>
            {
                std::string strval = (info.groups[i].members[j].is_input ? "input" : "ouput") + 
                    to_string(info.groups[i].members[j].port_idx);

                if(info.groups[i].members[j].is_input)
                {
                    //if the same type compound_interface existed int table, and it will not construct a new
                    table_ite if_ite = local_ifTable.find(info.iports[info.groups[i].members[j].port_idx].interface);
                    if((if_ite != local_ifTable.end()) && (if_ite->second.first == (vec.find(strval))->second))
                    {
                        info.iports[info.groups[i].members[j].port_idx].interface = if_ite->second.second;
                    }
                    else
                    {
                        if(!info.iports[info.groups[i].members[j].port_idx].interface.is_builtin_interface())
                            continue;

                        /***************************construct a new compound interface************************************/
                        duke_media_compound_interface  cIf(hc_id);
                        local_ifTable.insert(std::make_pair(info.iports[info.groups[i].members[j].port_idx].interface, 
                                    std::make_pair((vec.find(strval))->second, cIf.get_handle())));

                        duke_logic_data_interface_compound if_data;
                        get_builtin_interface_compound(info.iports[info.groups[i].members[j].port_idx].interface, if_data);
                        if_data.m_ifc = cIf.get_handle();
                        if_data.m_hext = (vec.find(strval))->second;


                        //set declare information for new port interface
                        for(std::size_t it = 0; it < if_data.m_decls.size(); ++it)
                        {
                            std::string name;
                            duke_logic_static_declaration::get_builtin_name(if_data.m_decls[it].get_func_type(), name);

                            duke_media_declare_expanded  expand_decl(hc_id);
                            expand_decl.set_name(name);
                            expand_decl.set_expanded_type(if_data.m_decls[it], if_data.m_hext);
                            if_data.m_decls[it] = expand_decl.get_handle();
                        }



                        // get general declarations
                        duke_logic_static_interface::get_general_instructions(if_data.m_decls);
                        cIf.set_data_to_handle(if_data);
                        /**********************************************************************************************/

                        //set new interface to port
                        info.iports[info.groups[i].members[j].port_idx].interface = cIf.get_handle();
                    }
                }
                else
                {
                    //if the same type compound_interface existed int table, and it will not construct a new
                    table_ite if_ite = local_ifTable.find(info.oports[info.groups[i].members[j].port_idx].interface);
                    if((if_ite != local_ifTable.end()) && (if_ite->second.first == (vec.find(strval))->second))
                    {
                        info.oports[info.groups[i].members[j].port_idx].interface = if_ite->second.second;
                    }
                    else
                    {
                        if(!info.oports[info.groups[i].members[j].port_idx].interface.is_builtin_interface())
                            continue;

                        /***************************construct a new compound interface************************************/
                        duke_media_compound_interface  cIf(hc_id);
                        //set compound interface informaton to table
                        local_ifTable.insert(std::make_pair(info.oports[info.groups[i].members[j].port_idx].interface,
                                    std::make_pair((vec.find(strval))->second, cIf.get_handle())));

                        duke_logic_data_interface_compound if_data;
                        get_builtin_interface_compound(info.oports[info.groups[i].members[j].port_idx].interface, if_data);
                        if_data.m_ifc = cIf.get_handle();
                        if_data.m_hext = (vec.find(strval)->second);


                        //set declare information for new port interface
                        for(std::size_t it = 0; it < if_data.m_decls.size(); ++it)
                        {
                            std::string name;
                            duke_logic_static_declaration::get_builtin_name(if_data.m_decls[it].get_func_type(), name);

                            duke_media_declare_expanded  expand_decl(hc_id);
                            expand_decl.set_name(name);
                            expand_decl.set_expanded_type(if_data.m_decls[it], if_data.m_hext);
                            if_data.m_decls[it] = expand_decl.get_handle();
                        }


                        // get general declarations
                        duke_logic_static_interface::get_general_instructions(if_data.m_decls);
                        cIf.set_data_to_handle(if_data);
                        /**********************************************************************************************/

                        //set new interface to oport
                        info.oports[info.groups[i].members[j].port_idx].interface = cIf.get_handle();
                    }
                }
            }
        }
    }

    return true;
}


bool duke_media_declare_expanded::assign(const dukeid_t& decl_id)
{
    if (!decl_id.is_object_decl_expanded())
    {
        return false;
    }

    //get data from database and assign it to object expanded_declare struct
    std::string   value;
    this->set_handle_status( decl_id.get_value(value) );    //we can know where this id come from

    if (value.empty())
    {
        LOG_ERROR("error : this object " << decl_id.str() << " has no data!");
        return false;
    }

    //unpack data and set handle to this expanded_declare
    this->unpack(value);
    this->set_handle(decl_id);

    return true;
}

bool duke_media_declare_expanded::generate(const std::string& username, duke_media_handle& new_handle, 
        const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//    duke_media_declare_expanded expand_decl(host_id);
//
//    if (hfather.is_type_null())
//        return false;
//
//    if (hfather != this->get_handle())
//    {
//        assert(duke_media_write_pair_handle(hfather, this->get_handle(), expand_decl.get_handle()));
//    }
//
//    std::string strname;
//    this->get_name(strname);
//    bool ret = duke_media_save_handle_name(expand_decl.get_handle(), strname);
//    assert(ret);
//
//    std::string strval;
//    this->get_handle().get_value(strval);    
//
//    replace_content(username, strval, host_id, hfather);
//    expand_decl.get_handle().set_value(strval);
//    expand_decl.unpack(strval);
//    strval = expand_decl.pack_data();
//    ac_object_db_impl::instance().write_(expand_decl.get_nb_id().str(), strval);
//
//    duke_media_remove_handle("anonymous-name-tmp-interface-expanded", expand_decl.get_handle());
//    duke_media_remove_handle(username + "-tmp-interface-expanded", expand_decl.get_handle());
//
//    std::string strkey = username + "-interface-expanded";
//    assert(duke_media_read_handle(strkey, strval)); 
//    strval += "(" + expand_decl.get_handle().str() + ")";
//    assert(duke_media_write_handle(strkey, strval));
//
//    new_handle = expand_decl.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(expand_decl.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//	    LOG_NOTICE("DEL the " << expand_decl.get_handle().str() << " decl expanded in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//	    LOG_NOTICE("DEL the " << expand_decl.get_handle().str() << " decl expanded in temp media failed;");
//
//    return true;
    return true;
}

std::string duke_media_declare_expanded::pack() const
{
    return pack_helper();
}

std::string duke_media_declare_expanded::pack_helper() const
{
    return m_cData.pack();
}

void duke_media_declare_expanded::unpack(const std::string& strdecl)
{
    unpack_helper(strdecl);
}

void duke_media_declare_expanded::unpack_helper(const std::string& strdecl)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_cData.unpack(strdecl);
    }
    else if ( e_handle_core == status )
    {
        content value;
        unpack_object(strdecl, value);

        decl_expanded_data_t tmp_data;
        nb_id_t tmp_id;
        obj_impl_decl_expanded::unpack(value, tmp_id, tmp_data);

        // name
        m_cData.name = tmp_data.name;
        if (m_cData.name.empty() && tmp_data.origin_decl_id.is_function_instruction())
        {
            duke_logic_static_declaration::get_builtin_name(tmp_data.origin_decl_id, m_cData.name);
        }

        // origin decl id
        m_cData.m_decl_id = tmp_data.origin_decl_id;

        // expanded ifs
        for(std::size_t i = 0; i < tmp_data.expanded_ifs.size(); ++i)
        {
            m_cData.m_vif.push_back(tmp_data.expanded_ifs.at(i));
        }
    }
    else
    {
        LOG_ERROR("object handle: " << this->get_handle().str() << " has not exist in db");
    }
}

bool duke_media_declare_expanded::get_name(std::string& name) const
{
    name = m_cData.name;
    return true;
}

bool duke_media_declare_expanded::set_name(const std::string& name)    
{
    m_cData.name = name;
    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);
    return this->save();
}

bool duke_media_declare_expanded::get_icon(std::string& icon) const
{
    icon = m_cData.m_icon;
    return true;
}

bool duke_media_declare_expanded::set_icon(const std::string& icon)
{
   m_cData.m_icon = icon; 
   return this->save();
}

dukeid_t duke_media_declare_expanded::get_decl_id() const
{
    return m_cData.m_decl_id;
}

bool duke_media_declare_expanded::set_decl_id(const dukeid_t& decl_id) 
{
    m_cData.m_decl_id = decl_id;
    return true;
}


dukeid_vector duke_media_declare_expanded::get_decl_vif() const
{
    return m_cData.m_vif;
}

bool duke_media_declare_expanded::set_decl_vif(const dukeid_vector& decl_vif) 
{
    m_cData.m_vif = decl_vif;
    return true;
}

bool duke_media_declare_expanded::add_constraints_if(const dukeid_t& single_if)
{
    if(!single_if.is_interface())
        return false;

    m_cData.m_vif.push_back(single_if);
    return true;
}

bool duke_media_declare_expanded::del_constraints_if(const dukeid_t& single_if)
{
    m_cData.m_vif.erase(std::find(m_cData.m_vif.begin(), m_cData.m_vif.end(), single_if));
    return true;
}

//std::string duke_media_declare_expanded::pack_data()
//{
//    decl_expanded_data_t  tmp_data;
//
//    tmp_data.origin_decl_id.str(m_cData.m_decl_id.str()); 
//    for(std::size_t i = 0; i < m_cData.m_vif.size(); ++i)
//    {
//        tmp_data.expanded_ifs.push_back(nb_id_t(m_cData.m_vif.at(i).str()));
//    }
//
//    m_nb_id.str(this->get_handle().str());
//
//    content tmp_content;
//    obj_impl_decl_expanded::pack(tmp_data, m_nb_id, tmp_content);
//
//    std::string strval = pack_object(tmp_content);
//
//    return strval;
//}

//bool duke_media_declare_expanded::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    bool ret = false;
//
//    ret = replace_string(username, strval, host_id, hfather, m_cData.m_decl_id);
//    if(!ret)
//        return false;
//
//    for(std::size_t i = 0; i < m_cData.m_vif.size(); ++i)
//    {
//        ret = replace_string(username, strval, host_id, hfather, m_cData.m_vif.at(i));
//        if(!ret)
//        {
//            return false;
//        }
//    }
//    return true;
//}
//
//bool duke_media_declare_expanded::replace_string(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather, const duke_media_handle& rep_handle)
//{
//
//    if (rep_handle.is_function_instruction() || rep_handle.is_builtin_interface())
//	    return true;
//
//    if(duke_media_get_handle_status(username, rep_handle) == Edit)
//    {
//        duke_media_handle new_handle;
//        assert(duke_media_read_pair_handle(hfather, rep_handle, new_handle));
//
//        if(new_handle.is_type_null())
//        {
//            if(rep_handle.is_object_interface())
//            {
//                return true;
//            }
//            else if(rep_handle.is_interface_compound())
//            {
//                duke_media_compound_interface tmp_decl(rep_handle);
//                assert(tmp_decl.generate(username, new_handle, host_id, hfather));
//                assert(!new_handle.is_type_null());
//            }
//            else if(rep_handle.is_object_declaration())
//            {
//                return true;
//            }
//            else if(rep_handle.is_object_decl_compound())
//            {
//                duke_media_compound_declare tmp_decl(rep_handle);
//                assert(tmp_decl.generate(username, new_handle, host_id));
//                assert(!new_handle.is_type_null());
//            }
//            else
//            {
//                return false;
//            }
//        }
//        duke_media_replace_handle(strval, rep_handle, new_handle);
//    }
//    return true;
//}


bool duke_media_declare_expanded::set_array_type(const dukeid_t& decl_id, const dukeid_t& if_type) 
{
    assert(decl_id.is_declaration());
    assert(if_type.is_interface());
    this->m_cData.m_decl_id = decl_id;

    this->m_cData.m_vif.clear();
    this->m_cData.m_vif.push_back(if_type);
    return this->save();
}

bool duke_media_declare_expanded::set_expanded_type(const dukeid_t& decl_id, const dukeid_vector& if_type) 
{
    assert(decl_id.is_declaration());
    for(std::size_t i = 0; i < if_type.size(); ++i)
    {
        assert(if_type.at(i).is_interface());
    }
    this->m_cData.m_decl_id = decl_id;

    this->m_cData.m_vif.clear();
    this->m_cData.m_vif = if_type;
    return this->save();
}

int duke_media_declare_expanded::get_iport_number() const
{
    if(m_cData.m_decl_id.is_object_decl_compound())
    {        
        duke_media_compound_declare comp_decl(m_cData.m_decl_id);
        return comp_decl.get_iport_number();
    }
    else if(m_cData.m_decl_id.is_object_decl_expanded())
    {
        duke_media_declare_expanded exp_decl(m_cData.m_decl_id);
        return exp_decl.get_iport_number();
    }    
    else
    {
        if(m_cData.m_decl_id.is_instruction_array() || m_cData.m_decl_id.is_instruction_map() || 
                m_cData.m_decl_id.is_instruction_storage())
        {   
            duke_logic_data_declare_compound decl_info;
            get_builitin_decl_compound(m_cData.m_decl_id, decl_info);
            return decl_info.iports.size();
        }

        duke_media_declare decl(m_cData.m_decl_id);
        return decl.get_iport_number();
    }    
}

int duke_media_declare_expanded::get_oport_number() const
{
    if(m_cData.m_decl_id.is_object_decl_compound())
    {        
        duke_media_compound_declare comp_decl(m_cData.m_decl_id);
        return comp_decl.get_oport_number();
    }
    else if(m_cData.m_decl_id.is_object_decl_expanded())
    {
        duke_media_declare_expanded exp_decl(m_cData.m_decl_id);
        return exp_decl.get_oport_number();
    }    
    else
    {
        if(m_cData.m_decl_id.is_instruction_array() || m_cData.m_decl_id.is_instruction_map() 
                || m_cData.m_decl_id.is_instruction_storage())
        {
            duke_logic_data_declare_compound decl_info;
            get_builitin_decl_compound(m_cData.m_decl_id, decl_info);
            return decl_info.oports.size();
        }
        duke_media_declare decl(m_cData.m_decl_id);
        return decl.get_oport_number();
    }
}

bool duke_media_declare_expanded::get_interfaces(duke_media_handle_vector& hiifs,
                                                 duke_media_handle_vector& hoifs) const
{
    if(m_cData.m_decl_id.is_object_decl_compound())
    {        
        duke_media_compound_declare comp_decl(m_cData.m_decl_id);
        return comp_decl.get_interfaces(hiifs, hoifs);
    }
    else if(m_cData.m_decl_id.is_object_decl_expanded())
    {
        duke_media_declare_expanded exp_decl(m_cData.m_decl_id);
        return exp_decl.get_interfaces(hiifs, hoifs);
    }    
    else if(m_cData.m_decl_id.is_function_instruction())
    {
        if(m_cData.m_decl_id.is_instruction_array() || m_cData.m_decl_id.is_instruction_map() 
                || m_cData.m_decl_id.is_instruction_storage())
        {
            //dynamic get information of port
            duke_logic_data_declare_compound decl_info;
            this->get_dynamic_info(decl_info);

            //push result of iport to vector
            for(iport_ite it = decl_info.iports.begin();
                    it != decl_info.iports.end(); ++it)
            {
                hiifs.push_back(it->interface);
            }

            //push result of oport to vector
            for(oport_ite it = decl_info.oports.begin();
                    it != decl_info.oports.end(); ++it)
            {
                hoifs.push_back(it->interface);
            }

            return true;
        }
        else
        {
            duke_media_declare decl(m_cData.m_decl_id);
            return decl.get_interfaces(hiifs, hoifs);
        }
    }
    return false;
}

editor_base_ptr duke_media_declare_expanded::to_xml_struct(index_manager& mgr, int& main_idx)
{
    ExpandedDeclaration_editor_ptr pDecl(new(std::nothrow) ExpandedDeclaration_editor());

    if(!pDecl)
        return pDecl;

    //declaration name
    pDecl->set_name(m_cData.name);

    //parent declaration
    int idx = mgr.get_index_from_handle(m_cData.m_decl_id);
    pDecl->set_parentDeclaration(idx);
    
    //expanded interfaces
    std::vector<int> expandedInterfaces;
    for(duke_media_handle_iterator it = m_cData.m_vif.begin(); it != m_cData.m_vif.end(); ++it)
    {
        idx = mgr.get_index_from_handle(*it);
        expandedInterfaces.push_back(idx);
    }
    pDecl->set_expandedInterfaces(expandedInterfaces);

    // main index
    main_idx = mgr.request_index_for_editor(this->get_handle(), pDecl);

    return pDecl;
}

bool duke_media_declare_expanded::init_save(DbTxn* txn)
{
    // only when handle is temp (or formal)
    // save to tempobj_db only
    if (e_handle_core != this->get_handle_status())
    {
        return this->get_handle().set_value(this->pack_helper(), txn);
    }
    else
    {
        return false;
    }
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
