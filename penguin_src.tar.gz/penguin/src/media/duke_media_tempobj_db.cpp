/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/
#include "duke_media_tempobj_db.h"

#include "nb_profiler.h"
#include "stdx_log.h"

int duke_media_tempobj_db::count=0;

duke_media_tempobj_db::duke_media_tempobj_db() : nWrites_(0), nTxnWrites_(0), keylens_(0), vallens_(0)
{
    try
    {
        std::string dbmedia = "dbmedia/";
        const std::string& db_name = "tempobjectd";
        const std::string dbhome = "dbtempobject";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "tempidvalue";

        // recover the database each time
        nb_mkdirs(dbmedia + dbhome);
        nbnv::recover(dbmedia + dbhome);

        // create database environment
        penv = new nbnv(dbmedia + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool duke_media_tempobj_db::begin_txn(DbTxn*& txn)
{
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    int ret = pdb->txn_begin(txn);
    if (ret == 0)
        return true;
    else 
        return false;
}

int duke_media_tempobj_db::write(const std::string& strkey, const std::string& value, DbTxn* txn)
{
#ifndef NDEBUG
    /* for performance evaluation */
    NEW_SCOPE_TIMER("duke_media_tempobj_db::write", false);
    nWrites_++;
    keylens_ += strkey.size();
    vallens_ += value.size();
    if(txn != NULL)
    {
        nTxnWrites_++; 
        txnIds_.insert(txn->id());
    }
#endif

    assert(pdb != NULL);

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

int duke_media_tempobj_db::write_(const std::string& strkey, const std::string& value, DbTxn* txn, int& flag)
{   
    /* for performance evaluation
    NEW_SCOPE_TIMER("duke_media_tempobj_db::write", false);
    nWrites_++;
    keylens_ += strkey.size();
    vallens_ += value.size();
    if (txn != NULL)
        nTxnWrites_++;*/

    assert(pdb != NULL);

    
    if (txn != NULL)
    {
        int index;
        {
            if ((index = find_index(txn)) == 0)
            {
                object_txn_map_type& idtxns = m_idtxns;
                boost::lock_guard<boost::mutex> guard(m_mtx_txn);
                ++count;
                flag = count;
                idtxns.insert(std::make_pair(flag, txn));
            }
            else
                flag = index;
        }
    }

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
    {
        LOG_ERROR(strkey +  ": WRITE FAILED");
        ret = NB_DB_RESULT_FAILED;
    }

    return ret;
}

int duke_media_tempobj_db::read(const std::string& strkey, std::string& value)
{
    /* for performance evaluation */
    NEW_SCOPE_TIMER("duke_media_tempobj_db::read", false);

    assert(pdb != NULL);

    int ret = pdb->read(strkey, value);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

int duke_media_tempobj_db::del(const std::string& strkey)
{
    int ret = pdb->del(strkey);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;
    return ret;
}

bool duke_media_tempobj_db::read_handle(std::string& strval)
{
    assert(pdb != NULL);

    strval.clear();
    nbdbc dbc(pdb->get_db());
    std::string strkey, str_val;
    int ret;
    while ((ret = dbc.read(strkey, str_val)) == 0)
    {
        strval += "(" + strkey + ")";
    }
    return true; 
}

int duke_media_tempobj_db::find_index(DbTxn*& txn)
{
    object_txn_map_type& idtxns = m_idtxns;
    //boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    for (object_txn_map_type::const_iterator it = idtxns.begin(); it != idtxns.end(); ++it)
    {
        if (it->second == txn)
            return it->first;
    }
    return 0;
}

bool duke_media_tempobj_db::commit(int flag)
{
    assert(pdb != NULL);

    LOG_DEBUG("duke_media_tempobj_db commit flag:" << flag);
    DbTxn* txn = find_txn(flag);
    int ret = pdb->commit(txn);
    return (ret == 0 ? true : false);
}

bool duke_media_tempobj_db::commit(DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn != NULL);

    int ret = pdb->commit(txn);
    return (ret == 0 ? true : false);
}

bool duke_media_tempobj_db::rollback(int flag)
{
    assert(pdb != NULL);
    DbTxn* txn = find_txn(flag);
    int ret = pdb->rollback(txn);
    return (ret == 0 ? true : false);
}

DbTxn* duke_media_tempobj_db::find_txn(int flag)
{
    assert(flag != 0);
    DbTxn* txn = NULL;
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it = idtxns.find(flag);
    if (it != idtxns.end())
    {
        txn = it->second;
        idtxns.erase(it);
    }
    return txn;
}

void duke_media_tempobj_db::close_txn()
{
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it;
    for (it = idtxns.begin(); it != idtxns.end(); ++it)
        pdb->rollback(it->second);
}

duke_media_tempobj_db::~duke_media_tempobj_db(void) 
{
    if (m_idtxns.size() != 0)
    {
        this->close_txn();
    }

    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }

#ifndef NDEBUG
    if(nWrites_)
    {
        LOG_DEBUG("========== duke_media_tempobj_db ==========");
        LOG_DEBUG("total writes : "<< nWrites_ << "    transactional : "<< nTxnWrites_);
        LOG_DEBUG("total transactions : "<< txnIds_.size());
        LOG_DEBUG("KEY-SIZE  avg : "<< keylens_/nWrites_ << "    total : "<< keylens_);
        LOG_DEBUG("VAL-SIZE  avg : "<< vallens_/nWrites_ << "    total : "<< vallens_);
        LOG_DEBUG(" ");
    }
#endif
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
