/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/


#ifndef __DUKE_STASH_DB_H
#define __DUKE_STASH_DB_H

// C 89 header files
#include <assert.h>

// C++ 98 header files
#include <string>
#include <vector>

//#include "nb_id.h"
#include "nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"
#include "stdx_log.h"

/// ##Mind##
/// This is a database only for stash
/// It is not directly used in core, but used by
/// scanner to temporarily store the unused ids

class duke_stash_db : public boost_singleton<duke_stash_db>
{
public:
    bool read(const std::string& strkey, std::string& value, DbTxn* txn = NULL);

    bool write(const std::string& strkey, const std::string& value, DbTxn* txn = NULL);

    bool del(const std::string& strkey, DbTxn* txn = NULL);

    bool txn_begin(DbTxn*& txn);

    bool commit(DbTxn* txn);

    bool rollback(DbTxn* txn);

private:    
    duke_stash_db();


public:
    ~duke_stash_db(); 
    friend struct boost_singleton<duke_stash_db>;


private:
    nbnv* penv;
    nbdb* pdb;
};

#endif // __DUKE_STASH_DB_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
