#ifndef __NB_LOGIC_OBJECT_H
#define __NB_LOGIC_OBJECT_H

#include <vector>
#include <string>

#include "stdx_algorithm.h"
#include "duke_logic_id.h"
#include "duke_logic_object_data.h"
#include "duke_logic_object_static.h"
#include "duke_media_compound_interface.h"
#include "duke_media_compound_declare.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object.h"
#include "duke_media_declare_expanded.h"

#define dukelog_assert(statement) LOG_ERROR(statement)

/********************************** object base ***********************************/

class duke_object_base
{
private:
    dukeid_t m_objid;


protected:
    duke_object_base(nbid_type_t type = NBID_TYPE_NULL) : m_objid(type)
    { }

    duke_object_base(nb_builtin_interface_t iftype) : m_objid(iftype)
    { }

    duke_object_base(const dukeid_t& objid) : m_objid(objid)
    { }

public:
    dukeid_t& get_id()
    {
        return m_objid;
    }

    const dukeid_t& get_id() const
    {
        return m_objid;
    }

    void set_id(const dukeid_t& objid)
    {
        m_objid = objid;
    }

    static void get_general_interface(dukeid_vector& vid)
    {
        duke_object_static_base::get_general_interface(vid);
    }

    static bool get_general_declaration(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        return duke_object_static_base::get_general_declaration(hdecl, in, out);
    }

    static bool get_general_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_base::get_general_declaration_name(hdecl, name);
    }

protected:
    template <typename _DataType>
    bool load(const dukeid_t& hid, const std::string& strtxn, _DataType& data)
    {
        std::string strval;
        bool ret = hid.get_value(strval);
        if (!ret);
            //dukelog_assert(hid.str());
        assert(ret);
        //assert(!strval.empty());
        if (!strval.empty())
            data.unpack(strval);
        return ret;
    }

    template <typename _DataType>
    bool set_value(const _DataType& data, const std::string& strtxn = "")
    {
        return get_id().set_value(data.pack());
    }
};

/********************************** built-in objects ***********************************/

class duke_object_none : public duke_object_base
{
public:
    duke_object_none() : duke_object_base(NBID_TYPE_OBJECT_NONE)
    { }

    duke_object_none(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_NONE);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_none::get_name(name);
    }
};

class duke_object_boolean : public duke_object_base
{
public:
    duke_object_boolean(bool data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_BOOL)
    {
        this->set_value(data, strtxn);
    }

    duke_object_boolean(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_BOOL);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_boolean::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_boolean::get_declaration_name(hdecl, name);
    }

    bool get_value(bool& value, const std::string& strtxn) const
    {
        bool ret = get_id().get_value(value);
        assert(ret);
        return ret;
    }

    bool set_value(bool value, const std::string& strtxn)
    {
        bool ret = get_id().set_value(value);
        assert(ret);
        return ret;
    }
};

class duke_object_integer : public duke_object_base
{
public:
    duke_object_integer(int data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_INT)
    {
        this->set_value(data, strtxn);
    }

    duke_object_integer(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_INT);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_integer::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_integer::get_declaration_name(hdecl, name);
    }

    bool get_value(int& value, const std::string& strtxn) const
    {
        return get_id().get_value(value);
    }

    bool set_value(int value, const std::string& strtxn)
    {
        return get_id().set_value(value);
    }
};

class duke_object_float : public duke_object_base
{
public:
    duke_object_float(float data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_FLOAT)
    {
        set_value(data, strtxn);
    }

    duke_object_float(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_FLOAT);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_float::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_float::get_declaration_name(hdecl, name);
    }

    bool get_value(float& value, const std::string& strtxn) const
    {
        bool ret = get_id().get_value(value);
        assert(ret);
        return ret;
    }

    bool set_value(float value, const std::string& strtxn)
    {
        bool ret = get_id().set_value(value);
        assert(ret);
        return ret;
    }
};

class duke_object_string : public duke_object_base
{
public:
    duke_object_string(const std::string& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_STRING)
    {
        bool ret = set_value(data, strtxn);
        assert(ret);
    }

    duke_object_string(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_STRING);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_string::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_string::get_declaration_name(hdecl, name);
    }

    bool get_value(std::string& strval, const std::string& strtxn) const
    {
        bool ret = get_id().get_value(strval);
        assert(ret);
        return ret;
    }

private:
    bool set_value(const std::string& strval, const std::string& strtxn)
    {
        bool ret = get_id().set_value(strval);
        assert(ret);
        return ret;
    }
};

class duke_object_bytes : public duke_object_base
{
private:
    duke_logic_data_bytes m_data;

public:
    duke_object_bytes() : duke_object_base(NBID_TYPE_OBJECT_BYTES)
    { }

    duke_object_bytes(const duke_bytes_t& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_BYTES)
    {
        set_value(data, strtxn);
    }

    duke_object_bytes(const dukeid_t& objid) : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_BYTES);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_bytes::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_bytes::get_declaration_name(hdecl, name);
    }

    bool get_value(duke_bytes_t& dbytes, const std::string& strtxn = "")
    {
        std::string strval;
        bool ret = get_id().get_value(strval);
        if (!strval.empty() && ret)
            m_data.unpack(strval, dbytes);

        return ret;
    }

    bool set_value(const duke_bytes_t& dbytes, const std::string& strtxn = "")
    {
        std::string strval = m_data.pack(dbytes);
        return get_id().set_value(strval);
    }
};

class duke_object_interval : public duke_object_base
{
private:
    duke_logic_data_interval m_data;

public:
    duke_object_interval(const duke_time_t& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_INTERVAL)
    {
        set_value(data, strtxn);
    }

    duke_object_interval(const dukeid_t& objid, const std::string& strtxn = "")
        : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_INTERVAL);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_interval::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_interval::get_declaration_name(hdecl, name);
    }

    bool get_value(duke_time_t& dtime, const std::string& strtxn = "")
    {
        uint64_t low = 0, high = 0;
        bool ret = get_id().get_value(low, high);
        assert(ret);
        m_data.unpack(low, high, dtime);
        return ret;
    }

    bool set_value(const duke_time_t& dtime, const std::string& strtxn = "")
    {
        uint64_t low = 0, high = 0;
        m_data.pack(dtime, low, high);
        return get_id().set_value(low, high);
    }
};

class duke_object_time : public duke_object_base
{
private:
    duke_logic_data_time m_data;

public:
    duke_object_time(const duke_time_t& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_TIME)
    {
        set_value(data, strtxn);
    }

    duke_object_time(const dukeid_t& objid, const std::string& strtxn = "")
        : duke_object_base(objid)
    { }

    static bool get_interface(dukeid_t& id)
    {
        id = dukeid_t(NB_INTERFACE_TIME);
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_time::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_time::get_declaration_name(hdecl, name);
    }

    bool get_value(duke_time_t& dtime, const std::string& strtxn = "")
    {
        uint64_t low = 0, high = 0;
        bool ret = get_id().get_value(low, high);
        assert(ret);
        m_data.unpack(low, high, dtime);
        return ret;
    }

    bool set_value(const duke_time_t& dtime, const std::string& strtxn = "")
    {
        uint64_t low = 0, high = 0;
        m_data.pack(dtime, low, high);
        return get_id().set_value(low, high);
    }
};


class duke_logic_declaration_compound : public duke_object_base
{
private:
    std::string   m_name;
    dukeid_t      m_interface;
    dukeid_t      m_instructionid;

public:
    MSGPACK_DEFINE(m_name, m_interface, m_instructionid);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

public:
    duke_logic_declaration_compound() 
        : duke_object_base(NBID_TYPE_OBJECT_DECLARATION_COMPOUND)
    {
    }

    duke_logic_declaration_compound(const dukeid_t& ifid, const dukeid_t& declid, const std::string& name, const std::string& strtxn)
            : duke_object_base(declid)
    {
        // save
        m_interface = ifid;
        m_name = name;
        get_id().set_value(pack());
    }

    duke_logic_declaration_compound(const dukeid_t& id, const std::string& strtxn)
            : duke_object_base(id)
    {
        // load
        std::string strval;
        get_id().get_value(strval);
        unpack(strval);
    }

    dukeid_t get_interface()
    {
        return m_interface;
    }

    std::string get_name()
    {
        return m_name;
    }

    bool set_instruction(const dukeid_t& id)
    {
        m_instructionid = id;
        get_id().set_value(pack());
        return true;
    }

    bool get_instruction(dukeid_t& id)
    {
        id = m_instructionid;
        return true;
    }
};

class duke_logic_interface_compound : public duke_object_base
{
private:
    duke_logic_data_interface_compound m_data;

public:
    duke_logic_interface_compound()
        : duke_object_base(NBID_TYPE_OBJECT_INTERFACE_COMPOUND)
    {
    }

    duke_logic_interface_compound(const duke_logic_data_interface_compound& data, const std::string& strtxn)
        : duke_object_base(data.m_ifc), m_data(data)
    {
        bool ret = set_value(data, strtxn);
        assert(ret);
    }

    duke_logic_interface_compound(const dukeid_t& objid, const std::string& strtxn) : duke_object_base(objid)
    {
//        assert(hobj.is_object_ifc());
        bool ret = load(objid, strtxn, m_data);
        assert(ret);
    }

    dukeid_t get_extension_types(int index)
    {
        if (m_data.m_hext.size() > 0)
            return m_data.m_hext[index];
        else
            return dukeid_t(NBID_TYPE_NULL);
    }

    bool get_declarations(dukeid_vector& vdecl) const
    {
        vdecl = m_data.m_decls;
        return true;
    }

    dukeid_t get_interface()
    {
        return m_data.m_ifc;
    }
	static bool get_builtin_instructions(const dukeid_t& ifid, dukeid_vector& vdecl)
	{
		return duke_logic_static_interface::get_builtin_instructions(ifid, vdecl);
	}
};

class duke_object_array : public duke_object_base
{
private:
    duke_logic_data_array m_data;

public:

    bool get_interface(dukeid_t& id)
    {
        id = m_data.m_iftype;
        return true;
    }

    bool set_null_interface()
    {
        m_data.m_iftype = duke_media_handle_null;
        std::string strval = m_data.pack();
        return get_id().set_value(strval);
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_array::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_array::get_declaration_name(hdecl, name);
    }

    bool get_type(dukeid_vector& id) const
    {
        id = m_data.m_compound.m_hext;
        return true;
    }

    bool get_value(dukeid_vector& vid, const std::string& strtxn = "")
    {
        vid = m_data.m_vid;
        return true;
    } 
    
    /* called by duke_media_array::set_value */
    bool set_value(const host_committer_id_t& host_id, const dukeid_vector& type, 
                    const dukeid_vector& vid)
    {
        dukeid_vector selftype;
        get_type(selftype);
        if (selftype.size() != 0)
        {
            if (type[0] == selftype[0])
            {
                m_data.m_vid = vid;
                std::string strval = m_data.pack();
                return get_id().set_value(strval);
            }
        }


        nb_id_t obj_id;
        content tmp_content;
        std::string strnew;

        // create <duke_media_compound_interface> first to get its handle
        duke_media_compound_interface ifc(host_id);
        ifc.set_name("array-interface");

        dukeid_t array_if = ifc.get_handle();
        dukeid_t element_if = type[0];

        duke_logic_data_interface_compound ifc_data;
        ifc_data.m_ifc = array_if;
        ifc_data.m_hext = type;
        ifc_data.m_type = duke_media_handle(NB_INTERFACE_ARRAY_TYPE); 
        ifc_data.name = "array-interface";

        // generate compound declarations
        //
        DbTxn* txn = NULL;

        DbTxn* arraytxn = NULL;

        bool bret = duke_media_tempobj_db::instance().begin_txn(arraytxn);
        assert(bret);

        int flag(0);

        ifc_data.m_decls.clear();

        duke_logic_data_interface_compound tmp_if_data;
        get_builtin_interface_compound(dukeid_t(NB_INTERFACE_ARRAY), tmp_if_data);
        for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
        {
            ifc_data.m_decls.push_back(generate_array_decl(tmp_if_data.m_decls[i].get_func_type(), 
                                        element_if, host_id, txn, arraytxn, flag));
        }

        bool ret = duke_media_tempobj_db::instance().commit(arraytxn);
        assert(ret);

        //bool ret = ac_object_db_impl::instance().commit(flag);
        //assert(ret);

        // get general declarations
        duke_logic_static_interface::get_general_instructions(ifc_data.m_decls);

        // save ifc_data to media-dbs, using handle array_if
        ifc.set_data_to_handle(ifc_data); 
        
        LOG_NOTICE("logic array: " << ifc.get_handle().str());

        m_data.m_iftype = array_if;
        m_data.m_compound = ifc_data;
        m_data.m_vid = vid; 
        std::string strval = m_data.pack();

        //return get_id().set_value(strval);
    }


private:
    dukeid_t generate_array_decl(const nb_builtin_instruction_t ins, const dukeid_t& type,
                                const host_committer_id_t& hc_id, DbTxn* txn,
                                DbTxn* arraytxn, int& flag)
    {
        /* get declaration name */
        std::string name;
        duke_logic_static_declaration::get_builtin_name(ins, name);

        duke_media_declare_expanded decl(hc_id);
        decl.set_name(name);
        decl.set_array_type(ins, type);

        //decl_expanded_data_t  cData;
        //cData.name = name;
        //cData.origin_decl_id.str(dukeid_t(ins).str());
        //cData.expanded_ifs.push_back(nb_id_t(type.str()));

        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write_(decl.get_handle().get_nb_type().str(), pack_object(tmp_content));

        return decl.get_handle();
    }

};

class duke_object_map : public duke_object_base
{
private:
    duke_logic_data_map m_data;

    dukeid_t generate_map_decl(const nb_builtin_instruction_t ins,
                                const dukeid_vector& type,
                                const host_committer_id_t& hc_id,
                                DbTxn* txn,
                                DbTxn* arraytxn,
                                int& flag)
    {
        /* get declaration name */
        std::string name;
        duke_logic_static_declaration::get_builtin_name(ins, name);

        duke_media_declare_expanded decl(hc_id);

        decl.set_name(name);
        decl.set_expanded_type(dukeid_t(ins), type);

        //decl_expanded_data_t  cData;
        //cData.name = name;
        //cData.origin_decl_id.str(dukeid_t(ins).str());
        //for(std::size_t i = 0; i < type.size(); ++i)
        //{
        //    cData.expanded_ifs.push_back(nb_id_t(type.at(i).str()));
        //}

        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write_(decl.get_handle().get_nb_type().str(), pack_object(tmp_content));

        return decl.get_handle();
    }

public:
    //duke_object_map(const host_committer_id_t& hc_id, const dukeid_vector& type,
    //                const dukeid_multimap& data, const std::string& strtxn = "")
    //    : duke_object_base(NBID_TYPE_OBJECT_MAP)
    //{
    //    set_value(hc_id, type, data, strtxn);
    //}

    //duke_object_map(const dukeid_t& hobj, const std::string& strtxn = "")
    //    : duke_object_base(hobj)
    //{
    //    assert(hobj.is_object_map());
    //    bool ret = duke_object_base::load(hobj, strtxn, m_data);
    //    assert(ret);
    //}
    
    bool get_interface(dukeid_t& id)
    {
        id = m_data.m_iftype;
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_object_static_map::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_map::get_declaration_name(hdecl, name);
    }

    bool get_type(dukeid_vector& id) const
    {
        id = m_data.m_compound.m_hext;
        return true;
    }    

    bool get_value(dukeid_multimap& vid, const std::string& strtxn = "") const
    {
        vid = m_data.m_vid;
        return true;
    }

    bool set_value(const host_committer_id_t& hc_id, const dukeid_vector& type,
                   const dukeid_multimap& data, const std::string& strtxn = "", bool isTemp = true)
    {
        if (type.size() == 2)
        {
            dukeid_vector selftype;
            get_type(selftype);
            if (selftype.size() == 2)
            {
                if ((type[0] == selftype[0]) && (type[1] == selftype[1]))
                {
                    LOG_DEBUG("duke_object_map::fill content");
                    m_data.m_vid = data;
                    std::string strval = m_data.pack();
                    return get_id().set_value(strval);
                }
            }

            LOG_DEBUG("duke_object_map::fill types and content");

            nb_id_t obj_id;
            content tmp_content;
            std::string strnew;
            
            //for compound interface
            duke_media_compound_interface comobj(hc_id);
            comobj.set_name("map_interface");

            duke_logic_data_interface_compound comdata;
            comdata.m_ifc.str(comobj.get_handle().str());
            comdata.m_hext = type;
            comdata.m_type = duke_media_handle(NB_INTERFACE_MAP_TYPE);
            comdata.name = "map-interface";

            nb_id_t id_if, id_key_eid, id_val_eid;
            id_if.str(comobj.get_handle().str());
            id_key_eid.str(type[0].str());
            id_val_eid.str(type[1].str());

            // generate the txn
            DbTxn* txn = NULL;
            //assert(ac_object_db_impl::instance().begin_txn(txn));

            DbTxn* maptxn = NULL;
            
            int flag(0);

            //----------------------create the get decl for map----------------------
            comdata.m_decls.clear();
            duke_logic_data_interface_compound tmp_if_data;
            get_builtin_interface_compound(dukeid_t(NB_INTERFACE_MAP), tmp_if_data);
            for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
            {
                comdata.m_decls.push_back(generate_map_decl(tmp_if_data.m_decls[i].get_func_type(), type, hc_id, txn, maptxn, flag));
            }

            // get general declarations
            duke_logic_static_interface::get_general_instructions(comdata.m_decls);


            //duke_media_compound_interface(comdata, "");
            //duke_media_compound_interface tmp_ifc(1, comdata.m_ifc);
            //tmp_ifc.pack_new_structure();

            comobj.set_data_to_handle(comdata);
            m_data.m_iftype = comdata.m_ifc;
            m_data.m_compound = comdata;
            m_data.m_vid = data;
            std::string strval = m_data.pack();

            return get_id().set_value(strval);


        }   
        return true; 
    }
};


class duke_logic_storage : public duke_object_base
{
private:
    duke_logic_data_storage m_data;

    dukeid_t generate_storage_decl(const nb_builtin_instruction_t ins,
                                const dukeid_vector& type,
                                const host_committer_id_t& hc_id,
                                DbTxn* txn,
                                DbTxn* storagetxn,
                                int& flag)
    {
        /* get declaration name */
        std::string name;
        duke_logic_static_declaration::get_builtin_name(ins, name);

        duke_media_declare_expanded decl(hc_id);

        decl.set_name(name);
        decl.set_expanded_type(dukeid_t(ins), type);

        //duke_media_compound_declare func(hc_id, dukeid_t(ins));
        //func.set_storage_content(name, type, storagetxn);

        //decl_expanded_data_t  cData;
        //cData.name = name;
        //cData.origin_decl_id.str(dukeid_t(ins).str());
        //for(std::size_t i = 0; i < type.size(); ++i)
        //{
        //    cData.expanded_ifs.push_back(nb_id_t(type.at(i).str()));
        //}

        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write(decl.get_handle().get_nb_type().str(), pack_object(tmp_content), txn, flag);

        return decl.get_handle();
    }

public:
    //duke_logic_storage(const host_committer_id_t& host_id, const dukeid_vector& type, const dukeid_pair_vector& data, const std::string& strtxn) : duke_object_base(NBID_TYPE_STORAGE_SINGLEVALUE)
    //{
    //    bool ret = set_value(host_id, type, data, strtxn);
    //    assert(ret);
    //}

    //duke_logic_storage(const dukeid_t& hobj, const std::string& strtxn = "") : duke_object_base(hobj)
    //{
    //    bool ret = duke_object_base::load(hobj, strtxn, m_data);
    //    assert(ret);
    //}
    
    bool get_interface(dukeid_t& id)
    {
        id = m_data.m_iftype;
        return true;
    }

    static bool get_name(std::string& name)
    {
        return duke_logic_static_storage::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_logic_static_storage::get_declaration_name(hdecl, name);
    }

    bool get_type(dukeid_vector& id) const
    {
        id = m_data.m_compound.m_hext;
        return true;
    }

    bool set_type(const dukeid_vector& id)
    {
        if (!id.empty())
        {
            m_data.m_compound.m_hext = id;
            return get_id().set_value(m_data.pack());
        }
        return true;
    }

    bool set_name(const std::string& name)
    {
        m_data.m_name = name;
        return get_id().set_value(m_data.pack());
    }
    
    bool set_storage_idx(int index)
    {
        m_data.storage_idx = index;
        return get_id().set_value(m_data.pack());
    }

    bool get_storage_idx(int& index)
    {
        index = m_data.storage_idx;
        return true;
    }

    // map type
    bool get_value(dukeid_pair_vector& vdata, const std::string& strtxn = "") const
    {
        vdata = m_data.m_objs;
        return true;
    }

    bool set_value(const host_committer_id_t& host_id, const dukeid_vector& type, const dukeid_pair_vector& vdata, const std::string& strtxn = "", int storage_index = 0, bool isTemp = true)
    {
        dukeid_vector selftype;
        get_type(selftype);
        if (selftype.size() != 0)
        {
            if (type[0] == selftype[0])
            {
                m_data.m_objs = vdata;
                std::string strval = m_data.pack();
                return get_id().set_value(strval);
            }
        }

        nb_id_t obj_id;
        content tmp_content;
        std::string strnew;

        duke_media_compound_interface comobj(host_id);
        duke_logic_data_interface_compound comdata;
        comdata.m_ifc.str(comobj.get_handle().str());

        //comdata.m_hext = type;
        comdata.m_type = duke_media_handle(NB_INTERFACE_STORAGE);


        nb_id_t key_type, val_type, self_type;
        key_type = NB_INTERFACE_INT;// key type can only be int

        val_type = type[0].get_nb_type();
        self_type = comobj.get_handle().get_nb_type();

        dukeid_vector st_type;
        st_type.push_back(key_type);
        st_type.push_back(val_type);
        comdata.m_hext = st_type;

        // generate the txn
        DbTxn* txn = NULL;
        //assert( ac_object_db_impl::instance().begin_txn(txn));

        DbTxn* stortxn = NULL;

        int flag(0);


        comdata.m_decls.clear();
        duke_logic_data_interface_compound tmp_if_data;
        get_builtin_interface_compound(dukeid_t(NB_INTERFACE_STORAGE_SIMPLE), tmp_if_data);
        for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
        {
            comdata.m_decls.push_back(generate_storage_decl(tmp_if_data.m_decls[i].get_func_type(), st_type, host_id, txn, stortxn, flag));
        }

        //duke_media_compound_interface(comdata, "");
        //duke_media_compound_interface tmp_ifc(1, comdata.m_ifc);
        //tmp_ifc.pack_new_structure();

        comobj.set_data_to_handle(comdata);
        dukeid_t idifc(NB_INTERFACE_STORAGE);
        m_data.m_sif = idifc;
        m_data.m_iftype = comdata.m_ifc;
        m_data.m_compound = comdata;
        m_data.m_objs = vdata;

        std::string strval = m_data.pack();
        return get_id().set_value(strval);
    }
};

class duke_logic_access : public duke_object_base
{
private:
    duke_logic_data_access m_data;

public:
    duke_logic_access(const duke_logic_data_access& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_ACCESS), m_data(data)
    {
        bool ret = set_value(data, strtxn);
        assert(ret);
    }

    duke_logic_access(const dukeid_t& hobj, const std::string& strtxn = "") : duke_object_base(hobj)
    {
        assert(hobj.is_access());
        bool ret = duke_object_base::load(hobj, strtxn, m_data);
        assert(ret);
    }

    bool get_name(std::string& name)
    {
        name = "access";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_logic_static_root_access::get_declaration_name(hdecl, name);
    }

    bool get_declarations(dukeid_vector& hdecls) const
    {
        hdecls = m_data.m_hdecls;
        return true;
    }

    bool get_value(duke_logic_data_access& data) const
    {
        data = m_data;
        return true;
    }
};


class duke_logic_anchor : public duke_object_base
{
private:
    duke_logic_data_anchor m_data;

public:
    duke_logic_anchor(const duke_logic_data_anchor& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_ANCHOR), m_data(data)
    {
        bool ret = this->set_value(data, strtxn);
        assert(ret);
    }

    duke_logic_anchor(const dukeid_t& hobj, const std::string& strtxn)
        : duke_object_base(hobj)
    {
        assert(hobj.is_anchor());
        bool ret = duke_object_base::load(hobj, strtxn, m_data);
        assert(ret);
    }

    static bool get_name(std::string& name)
    {
        return duke_logic_static_registered_anchor::get_name(name);
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_logic_static_registered_anchor::get_declaration_name(hdecl, name);
    }

    bool get_value(duke_logic_data_anchor& data) const
    {
        data = m_data;
        return true;
    }
};


class duke_logic_declaration : public duke_object_base
{
private:
    duke_logic_data_declaration m_data;

public:
    duke_logic_declaration(const duke_logic_data_declaration& data,
            const std::string& strtxn)
       : duke_object_base(NBID_TYPE_OBJECT_DECLARATION), m_data(data)
    {
        bool ret = this->set_value(data, strtxn);
        assert(ret);
    }

    duke_logic_declaration(const dukeid_t& hdecl, const std::string& strtxn)
        : duke_object_base(hdecl)
    {
        bool ret = this->load(hdecl, "");
        if (!ret)
            dukelog_assert(hdecl.str());
        assert(ret);
    }

    bool load(const dukeid_t& hdecl, const std::string& strtxn)
    {
        bool ret = false;
        if (!hdecl.is_declaration())
            dukelog_assert(hdecl.str());
        assert(hdecl.is_declaration());
        if (hdecl.is_function_instruction())
        {
            ret = make_builtin_interfaces(hdecl,
                    m_data.m_param.m_hiifs, m_data.m_param.m_hoifs);
        }
        else
        {
            ret = duke_object_base::load(hdecl, strtxn, m_data);
            assert(ret);
        }
        return ret;
    }

    size_t get_iport_number() const
    {
        return m_data.m_param.m_hiifs.size();
    }

    size_t get_oport_number() const
    {
        return m_data.m_param.m_hoifs.size();
    }

    bool get_interfaces(dukeid_vector& hiifs,
            dukeid_vector& hoifs) const
    {
        hiifs = m_data.m_param.m_hiifs;
        hoifs = m_data.m_param.m_hoifs;
        return true;
    }

    static bool make_builtin_interfaces(const dukeid_t& did,
            dukeid_vector& iids, dukeid_vector& oids)
    {
        return duke_logic_static_declaration::get_interfaces(did, iids, oids);
    }
};


class duke_logic_interface : public duke_object_base
{
private:
    duke_logic_data_interface m_data;

public:
    duke_logic_interface(nb_builtin_interface_t iftype, const std::string& strtxn = "") : duke_object_base(iftype)
    {
        bool ret = init();
        assert(ret);
    }

    duke_logic_interface(const duke_logic_data_interface& data, const std::string& strtxn)
        : duke_object_base(NB_INTERFACE_USER), m_data(data)
    {
        this->save();
    }

    duke_logic_interface(const dukeid_t& hif, const std::string& strtxn = "") : duke_object_base(hif)
    {
        bool ret = this->assign(hif);
        if (!ret)
            dukelog_assert(hif.str());
        assert(ret);
    }

    nbid_type_t get_object_type()
    {
        dukeid_t ifid = get_id();
        nbid_type_t objtype = NBID_TYPE_OBJECT_NONE;
        if (ifid.is_interface_bool())
            objtype = NBID_TYPE_OBJECT_BOOL;
        else if (ifid.is_interface_int())
            objtype = NBID_TYPE_OBJECT_INT;
        else if (ifid.is_interface_float())
            objtype = NBID_TYPE_OBJECT_FLOAT;
        else if (ifid.is_interface_string())
            objtype = NBID_TYPE_OBJECT_STRING;
        else if (ifid.is_interface_bytes())
            objtype = NBID_TYPE_OBJECT_BYTES;
        else if (ifid.is_interface_interval())
            objtype = NBID_TYPE_OBJECT_INTERVAL;
        else if (ifid.is_interface_time())
            objtype = NBID_TYPE_OBJECT_TIME;
        else if (ifid.is_interface_array())
            objtype = NBID_TYPE_OBJECT_ARRAY;
        //else if (ifid.is_interface_compound())
        //    objtype = NBID_TYPE_COMPOUND;
        else if (ifid.is_bridge_interface())
            objtype = NBID_TYPE_OBJECT_BRIDGE;
        return objtype;
    }

    bool init()
    {
        bool ret = get_builtin_instructions(this->get_id(), m_data.m_hdecls);
        assert(ret);
        return this->save();
    }

    bool assign(const dukeid_t& hif)
    {
        bool ret = false;
        if (!hif.is_interface())
            dukelog_assert(hif.str());
        assert(hif.is_interface());
        if (hif.is_builtin_interface())
        {
            ret = get_builtin_instructions(hif, m_data.m_hdecls);
        }
        else if (hif.is_user_interface())
        {
            std::string strif;
            ret = hif.get_value(strif);
            assert(ret);
            assert(!strif.empty());
            m_data.unpack(strif);
        }

        if (hif.is_bridge_interface() || hif.is_builtin_interface() || hif.is_interface_compound())
            return true;
        else
            return ret && this->save();
    }

    bool get_singleton() const
    {
        return m_data.m_singleton;
    }

    bool get_declarations(dukeid_vector& hdecls) const
    {
        hdecls = m_data.m_hdecls;
        return true;
    }

    bool cover(const dukeid_t& hif) const
    {
        dukeid_vector hdecls;
        duke_logic_interface mif(hif);
        mif.get_declarations(hdecls);
        return stdx::unordered_includes(m_data.m_hdecls.begin(), m_data.m_hdecls.end(),
                hdecls.begin(), hdecls.end());
        return true;
    }

    bool match(const dukeid_t& hif) const
    {
        dukeid_vector hdecls;
        duke_logic_interface mif(hif);
        mif.get_declarations(hdecls);
        return stdx::unordered_match(m_data.m_hdecls.begin(), m_data.m_hdecls.end(),
                hdecls.begin(), hdecls.end());
        return true;
    }

    bool set_interface_name(const std::string& name)
    {
        m_data.m_name = name;
        return this->save();
    }

    bool get_data(duke_logic_data_interface& data)
    {
        data = m_data;
        return true;
    }

    bool save()
    {
        return get_id().set_value(m_data.pack());
    }

    bool get_name(std::string& name) const
    {
        dukeid_t ifid = get_id();
        assert(ifid.is_builtin_interface() || ifid.is_user_interface());
        if (ifid.is_builtin_interface())
        {
            duke_logic_static_interface::get_builtin_name(ifid, name);
        }
        else if (ifid.is_user_interface())
        {
            name = m_data.m_name;
        }
        return true;
    }

    static bool get_builtin_instructions(const dukeid_t& ifid, dukeid_vector& vdecl)
    {
        return duke_logic_static_interface::get_builtin_instructions(ifid, vdecl);
    }
};

class duke_object_user : public duke_object_base
{
protected:
    duke_logic_data_user m_data;

public:
    duke_object_user(const duke_logic_data_user& data, const std::string& strtxn)
        : duke_object_base(NBID_TYPE_OBJECT_USER), m_data(data)
    {
        bool ret = set_value(data, strtxn);
        assert(ret);
    }

    duke_object_user(const dukeid_t& hobj, const std::string& strtxn = "")
        : duke_object_base(hobj)
    {
        if (!hobj.is_object_user())
            dukelog_assert(hobj.str());
        assert(hobj.is_object_user());
        bool ret = duke_object_base::load(hobj, strtxn, m_data);
        assert(ret);
    }

    bool compose(const dukeid_vector& vid) // TBD
    {
        assert(vid.size() == m_data.m_subobjs.size());
        for (dukeid_vector::size_type i = 0; i < vid.size(); ++i)
        {
            m_data.m_subobjs[i].first = vid[i];
        }
        return true;
    }

    bool decompose(dukeid_vector& vid) const
    {
        vid.clear();
        for (dukeid_pair_vector_const_iterator it = m_data.m_subobjs.begin();
                it != m_data.m_subobjs.end(); ++it)
        {
            vid.push_back(it->first);
        }
        return true;
    }

    bool get_subobject(dukeid_vector& vid) const
    {
        return decompose(vid);
    }

    bool get_subobject(dukeid_pair_vector& vidpair) const
    {
        vidpair = this->m_data.m_subobjs;
        return true;
    }

    bool get_function(dukeid_pair_vector& funcs_vector) const
    {
        funcs_vector = m_data.m_funcs;
        return true;
    }

    bool get_subinterfaces(dukeid_vector& hifs) const
    {
        hifs.clear();
        for (dukeid_pair_vector_const_iterator it = m_data.m_subobjs.begin();
                it != m_data.m_subobjs.end(); ++it)
        {
            hifs.push_back(it->second);
        }
        return true;
    }

    // object
    bool find_subobject(const dukeid_t& hobj) const
    {
        for (dukeid_pair_vector_const_iterator it = m_data.m_subobjs.begin(); it != m_data.m_subobjs.end(); ++it)
        {
            if (it->first == hobj)
                return true;
        }
        return false;
    }

    dukeid_t get_interface() const
    {
        return m_data.m_ifid;
    }

    // interface
    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return duke_object_static_user::get_declaration_name(hdecl, name);
    }

    static bool get_builtin_instructions(dukeid_vector& vid)
    {
        return duke_object_static_user::get_builtin_instructions(vid);
    }

    // declaration
    bool find_declaration(const dukeid_t& hdecl) const
    {
        return (find_decl(hdecl) != m_data.m_funcs.end());
    }

    bool get_declarations(dukeid_vector& hdecls) const
    {
        duke_logic_interface dif(m_data.m_ifid);
        return dif.get_declarations(hdecls);
    }

    // implemention
    bool get_implementation(const dukeid_t& hdecl, dukeid_t& himpl) const
    {
        bool ret = hdecl.is_declaration();
        if (!ret)
            dukelog_assert(hdecl.str());
        assert(ret);
        if (ret)
        {
            dukeid_pair_vector_const_iterator it;
            if ((it = find_decl(hdecl)) != m_data.m_funcs.end())
            {
                himpl = it->second;
                return true;
            }
        }
        return false;
    }

    dukeid_pair_vector_const_iterator find_decl(const dukeid_t& hdecl) const
    {
        bool ret = hdecl.is_declaration();
        if (!ret)
            dukelog_assert(hdecl.str());
        assert(ret);
        dukeid_pair_vector_const_iterator it;
        for (it = m_data.m_funcs.begin(); it != m_data.m_funcs.end(); ++it)
        {
            if (it->first == hdecl)
                return it;
        }
        return it;
    }

    bool load(const std::string& strtxn = "")
    {
        std::string strobj;
        bool ret = get_id().get_value(strobj);
        if (!ret)
            dukelog_assert(get_id().str());
        assert(ret);
        assert(!strobj.empty());
        m_data.unpack(strobj);
        return ret;
    }

    bool save(const std::string& strtxn = "")
    {
        return get_id().set_value(m_data.pack());
    }
};

/**************************** object bridge ********************************/
// TBD: this class has not been used
class duke_object_bri_abstraction
{
public:
/* TBD
    void get_interface(std::vector<std::string>& interface)
    {
        mp_obj->get_interface(interface);
    }
*/
    void set_obj(duke_object_base* pobj)
    {
        mp_obj = pobj;
    }

    void set_oid(const dukeid_t& objid)
    {
        mp_obj->set_id(objid);
    }

protected:
    duke_object_base* mp_obj;
};


/*
class duke_object_bridge
{
private:
    duke_object_bri_abstraction   m_bri_abs;
    duke_object_boolean           m_bool_obj;
    duke_object_integer           m_int_obj;
    duke_object_float             m_float_obj;
    duke_object_string            m_str_obj;
    duke_object_user              m_user_obj;

public:
    duke_object_bridge()
    { }

    bool get_interface(const dukeid_t& objid, std::vector<std::string>& interface)
    {
        switch (objid.get_type())
        {
        case NBID_TYPE_OBJECT_USER:
            m_bri_abs.set_obj(&m_user_obj);
            m_bri_abs.set_oid(objid);
            break;

        case NBID_TYPE_OBJECT_BOOL:
            m_bri_abs.set_obj(&m_bool_obj);
            break;

        case NBID_TYPE_OBJECT_INT:
            m_bri_abs.set_obj(&m_int_obj);
            break;

        case NBID_TYPE_OBJECT_FLOAT:
            m_bri_abs.set_obj(&m_float_obj);
            break;

        case NBID_TYPE_OBJECT_STRING:
            m_bri_abs.set_obj(&m_str_obj);
            break;

        default:
            return false;
        }

// TBD        m_bri_abs.get_interface(interface);
        return true;
    }
};
*/


#endif // __NB_LOGIC_OBJECT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
