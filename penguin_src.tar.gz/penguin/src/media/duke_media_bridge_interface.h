/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#ifndef __DUKE_MEDIA_BRIDGE_INTERFACE_H
#define __DUKE_MEDIA_BRIDGE_INTERFACE_H

#include <iostream>
#include <string>
#include <vector>

#include "duke_media_base.h"
#include "duke_logic_object_data.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_global_db.h"

// duke_media_bridge_interface simple reads data from core
// and do some query job.It should never write to db
class duke_media_bridge_interface : public duke_media_base
{
private:
    duke_bridge_interface_data m_ifc;


public:
    // #MIND# (tom)
    // We never need to create a new & empty bridge interface in media
    //
    // duke_media_bridge_interface(const host_committer_id_t& host_id, 
    //         const std::string& username = "anonymous-name") 
    //         : duke_media_base(DUKE_MEDIA_TYPE_INTERFACE_BRIDGE, host_id) 
    // {
    //     bool ret = this->save();
    //     assert(ret);
    // }

    duke_media_bridge_interface()
    {
    }

    duke_media_bridge_interface(const duke_media_handle& hif)
    {
        assert(hif.is_bridge_interface());

        //only read bridge object from ac_object_db
        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(hif.str(), strval);
        if (NB_DB_RESULT_SUCCESS != ret)
        {
            LOG_ERROR("duke_media_bridge_interface : read bridge interface from core failed.");
            return;
        }

        this->unpack(strval);

        this->set_handle(hif);

        //forbids write
        this->set_handle_status(e_handle_core);
    }

    bool get_declarations(duke_media_handle_vector& vid) const
    {
        vid = m_ifc.m_decls;
        return true;
    }

    bool get_interfaces(duke_media_handle_vector& vif) const
    {
        vif = m_ifc.m_sub_interfaces;
        return true;
    }

    bool get_center_index(int64_t& index) const
    {
        index = m_ifc.m_center_index;
        return true;
    }

    bool get_bridge_id(int64_t& id) const
    {
        id = m_ifc.m_bridge_id;
        return true;
    }

    bool get_data_index(int64_t& index) const
    {
        index = m_ifc.m_data_index;
        return true;
    }

    bool get_external_name(std::string& name) const
    {
        name = m_ifc.m_external_name;
        return true;
    }

    bool get_name(std::string& name) const
    {
        name = m_ifc.m_external_name + " interface";
        return true;
    }

    std::string pack() const
    {
        // it should not be called
        return m_ifc.pack();
    }


    void unpack(const std::string& strif)
    {
        // bridge_interface only stores in core
        // use the unpack() from core
        content con;
        unpack_object(strif, con);

        bridge_interface_data_t data_t;
        nb_id_t id;
        obj_impl_bridge_interface::unpack(con, id, data_t);

        // fill the media structures
        m_ifc.m_data_index = data_t.data_index;
        m_ifc.m_external_name = data_t.external_name;
        m_ifc.m_sub_names = data_t.sub_names;        

        typedef std::vector<nb_id_t>::const_iterator const_it;
        for (const_it it = data_t.sub_interfaces.begin(); it != data_t.sub_interfaces.end(); ++it)
            m_ifc.m_sub_interfaces.push_back(*it);

        for (const_it it = data_t.decls.begin(); it != data_t.decls.end(); ++it)
            m_ifc.m_decls.push_back(*it);

        // fill general instructions
        nb_id_vector vins;
        obj_impl_interface::get_general_instructions(vins);
        dukeid_vector vdecl;
        
        nb_id_vector_to_dukeid_vector(vins, vdecl);
        m_ifc.m_decls.insert(m_ifc.m_decls.end(), vdecl.begin(), vdecl.end());
    }

public:
    //bool cover(const duke_media_handle& hif) const
    //{
    //    duke_media_handle_vector hdecls;
    //    assert(hif.is_bridge_interface());
    //    if (hif.is_bridge_interface())
    //    {
    //        duke_media_bridge_interface mif(hif);
    //        mif.get_declarations(hdecls);
    //        return stdx::unordered_includes(m_ifc.m_decls.begin(), m_ifc.m_decls.end(),
    //                                        hdecls.begin(), hdecls.end());      
    //    }

    //    return false;        
    //}

    //bool match(const duke_media_handle& hif) const
    //{
    //    assert(hif.is_bridge_interface());
    //    duke_media_handle_vector hdecls;
    //    if (hif.is_bridge_interface())
    //    {
    //        //bridge_interface mif(hif, "");
    //        //mif.get_declarations(hdecls);
    //    }
    //    return stdx::unordered_match(m_ifc.m_decls.begin(), m_ifc.m_decls.end(), hdecls.begin(), hdecls.end());
    //}

};

#endif /* __DUKE_MEDIA_BRIDGE_INTERFACE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
