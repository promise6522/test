/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#ifndef __DUKE_CONSTANT_DEF_H
#define __DUKE_CONSTANT_DEF_H

#include <assert.h>
#include <string>
#include <vector>

#include "duke_logic_object_data.h"



// get array's built-in instructions
void get_array_builtin_instructions(dukeid_vector& vins);


// get map's built-in instructions
void get_map_builtin_instructions(dukeid_vector& vins);


// get storage's built-in instructions
void get_storage_builtin_instructions(dukeid_vector& vins);


// for a builtin interface(array/map/etc), returns a interface_compound structure
// containing all the declaration infos.
bool get_builtin_interface_compound(const dukeid_t& if_id, duke_logic_data_interface_compound& data);


// for a builtin declaration of array/map/etc, returns a declare_compound structure
// containing all the ports info and expansion groups defination
bool get_builitin_decl_compound(const dukeid_t& decl_id, duke_logic_data_declare_compound& data);



// below are internal implementations of the funcs, never mind
// --------------------------------------------------------------------------------
typedef duke_logic_data_declare_compound::m_iport_t duke_iport;
typedef duke_logic_data_declare_compound::m_oport_t duke_oport;
typedef duke_logic_data_declare_compound::m_decl_exp_group duke_exp_group;
typedef duke_logic_data_declare_compound::m_decl_exp_idx duke_exp_idx;

namespace detail {

enum decl_port_type 
{
    PORT_TYPE_NORMAL    = 0,
    PORT_TYPE_GROUP     = 1,
    PORT_TYPE_NESTED    = 2,
};

struct decl_port_def 
{
    bool input;
    decl_port_type ptype;
    dukeid_t interface;
    int idx;

    /*
     * for PORT_TYPE_NORMAL:
     *   interface: the actual interface id 
     *   idx: always 0
     *
     * for PORT_TYPE_GROUP:
     *   interface: min_if
     *   idx: exp group idx of the declare
     *
     * for PORT_TYPE_NESTED: 
     *   interface: the interface id to be expanded
     *   idx is the group idxs of the port itself
     *   (eg: 3 = 1|2, means group1 & group2 of the interface)
     */
};

struct decl_template_def
{
    std::vector<decl_port_def> iport_defs;   
    std::vector<decl_port_def> oport_defs;   

    void add_iport_def(const decl_port_type ptype, const dukeid_t& ifid, const int idx)
    {
        decl_port_def port_def;
        port_def.input = true;
        port_def.ptype = ptype;
        port_def.interface = ifid;
        port_def.idx = idx;
        iport_defs.push_back(port_def);
    }

    void add_oport_def(const decl_port_type ptype, const dukeid_t& ifid, const int idx)
    {
        decl_port_def port_def;
        port_def.input = false;
        port_def.ptype = ptype;
        port_def.interface = ifid;
        port_def.idx = idx;
        oport_defs.push_back(port_def);
    }

    /* get the corresponding decl_compound data structure
       including the expansion group info */
    bool get_decl_compound( duke_logic_data_declare_compound& data ) const;
};


bool gen_groups_from_port_def(const decl_port_def& port, 
        const int port_idx, 
        std::vector<duke_exp_group>& groups);

} /* namespace detail */

#endif // __DUKE_CONSTANT_DEF_H
