/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/


#ifndef __DUKE_MEDIA_FORMOBJ_DB_H
#define __DUKE_MEDIA_FORMOBJ_DB_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>
#include <set>

//#include "nb_id.h"
#include "nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"

class duke_media_formobj_db : public mutex_singleton<duke_media_formobj_db>
{
public:
    int write(const std::string& strkey, const std::string& value, DbTxn* txn = NULL);
    int write_(const std::string& strkey, const std::string& value, DbTxn* txn, int& flag);

    int read(const std::string& strkey, std::string& value);
    bool read_handle(std::string& strval);

    bool commit(int flag);
    bool commit(DbTxn* txn);
    bool rollback(int flag);

    int del(const std::string& strkey);

public:
    bool begin_txn(DbTxn*& txn);

private:    
    duke_media_formobj_db();

private:
    DbTxn* find_txn(int flag);
    void close_txn();
    int find_index(DbTxn*& txn);

public:
    virtual ~duke_media_formobj_db(void); 
    friend struct mutex_singleton<duke_media_formobj_db>;

private:
    typedef std::map<int, DbTxn*> object_txn_map_type;
    boost::mutex m_mtx_txn;
    object_txn_map_type m_idtxns;

    static int count;
private:
    nbnv* penv;
    nbdb* pdb;

#ifndef NDEBUG
private:
    /* for write performance evaluation */
    long nWrites_;
    long nTxnWrites_;
    std::set<uint32_t> txnIds_;
    long keylens_;
    long vallens_;
#endif
};

#endif // __DUKE_MEDIA_FORMOBJ_DB_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
