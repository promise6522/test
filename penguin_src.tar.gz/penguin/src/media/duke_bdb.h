#ifndef __DUKE_SNOW_BDB_H
#define __DUKE_SNOW_BDB_H

// Posix header files
#include <sys/stat.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>
#include "stdx_log.h"

// C++ 98 header files
#include <string>
#include <iostream>

// Boost header file
#include <boost/noncopyable.hpp>

// Berkeley DB header files
#include <db_cxx.h>

// Duke header files
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_buffer.h"
#include "ac_tool/nb_stdx_memory.h"
#include "ac_tool/nb_core_base.h"


const uint32_t SNOW_ENV_TYPE_DS  = DB_CREATE | DB_INIT_MPOOL;
const uint32_t SNOW_ENV_TYPE_CDS = SNOW_ENV_TYPE_DS | DB_INIT_CDB;
const uint32_t SNOW_ENV_TYPE_TDS = SNOW_ENV_TYPE_DS | DB_INIT_TXN | DB_INIT_LOG | DB_INIT_LOCK | DB_THREAD; // DB_RECOVER
const uint32_t SNOW_ENV_TYPE_REP = SNOW_ENV_TYPE_TDS | DB_INIT_REP | DB_RECOVER;

const uint32_t SNOW_DB_TYPE_DS  = DB_CREATE;
const uint32_t SNOW_DB_TYPE_CDS = DB_CREATE;
const uint32_t SNOW_DB_TYPE_TDS = DB_CREATE | DB_THREAD | DB_AUTO_COMMIT;
const uint32_t SNOW_DB_TYPE_REP = DB_AUTO_COMMIT | DB_THREAD;
const uint32_t SNOW_DB_TYPE_VER = SNOW_DB_TYPE_TDS | DB_MULTIVERSION;

#define IDIP_CACHESIZE  (10 * 1024 * 1024)
#define DATA_CACHESIZE  (400 * 1024 * 1024)


class nbnv
{
protected:
    DbEnv m_env_;

public:
    static void recover(const std::string dbhome)
    {
        nbnv env(dbhome, SNOW_ENV_TYPE_TDS | DB_RECOVER);
    }

    static void catastrophic_recover(const std::string dbhome)
    {
        nbnv env(dbhome, SNOW_ENV_TYPE_TDS | DB_RECOVER_FATAL);
    }

public:
    // we can pass DB_CXX_NO_EXCEPTIONS to m_env_ to suppress exception
    nbnv(const std::string dbhome, uint32_t flags = SNOW_ENV_TYPE_TDS | DB_RECOVER)
        : m_env_(0)
    {
        openenv(dbhome, flags);
    }

    ~nbnv()
    {
        closeenv();
    }

    DbEnv& get_env()
    {
        return m_env_;
    }

    const DbEnv& get_env() const
    {
        return m_env_;
    }

    DbEnv*
    operator->() throw()
    {
        return &m_env_;
    }

    const DbEnv*
    operator->() const throw()
    {
        return &m_env_;
    }

// override memthods
    int openenv(const std::string dbhome, u_int32_t flags)
    {
        if (!dbhome.empty())
            nb_mkdir(dbhome);
    //  m_env_.set_lk_detect(DB_LOCK_DEFAULT);
        m_env_.set_cachesize(0, DATA_CACHESIZE, 0);
        uint32_t pagesize = nb_getpagesize();
        assert(pagesize != 0);
        if (pagesize == 0)
            pagesize = NB_PAGE_SIZE_DEFAULT;
        m_env_.set_tx_max(DATA_CACHESIZE / nb_getpagesize());

        m_env_.log_set_config(DB_LOG_AUTO_REMOVE, 1);
        
        m_env_.set_lk_detect(DB_LOCK_DEFAULT);

        //m_env_.txn_checkpoint(0, 0.5, 0);

    //  flags |= DB_REGISTER;
        return m_env_.open(dbhome.c_str(), flags, 0);
    }

    int closeenv()
    {
        try
        {
            return m_env_.close(0);
        }
        catch (DbException& e)
        {
            return e.get_errno();
            throw e;
        }
    }
};


struct nbrep_state
{
    nbrep_state() : m_master(false), m_ready(false), m_master_eid(-1)
    { }
    bool m_master;
    bool m_ready;
    int m_master_eid;
};

class nbrep : public boost::noncopyable
{
private:
    DbEnv m_env_;
    nbrep_state m_state;
    const std::string m_dbhome_;

public:
    // election_flags can be DB_REP_MASTER, DB_REP_CLIENT or DB_REP_ELECTION
    nbrep(const std::string& dbhome, const std::string& hostname, const std::string& servname,
            const std::string& remotehost = "", const std::string& remoteport = "",
            u_int32_t election_flags = DB_REP_ELECTION)
        : m_env_(0), m_dbhome_(dbhome)
    {
        assert(!dbhome.empty());
        assert(!hostname.empty() && !servname.empty());
        assert((remotehost.empty() && remoteport.empty()) || (!remotehost.empty() && !remoteport.empty()));
        openenv(dbhome, hostname, servname, remotehost, remoteport, election_flags);
    }

    ~nbrep()
    {
        closeenv();
    }

    DbEnv& get_env()
    {
        return m_env_;
    }

    const DbEnv& get_env() const
    {
        return m_env_;
    }

    DbEnv*
    operator->() throw()
    {
        return &m_env_;
    }

    const DbEnv*
    operator->() const throw()
    {
        return &m_env_;
    }

    int openenv(const std::string& dbhome, const std::string& hostname, const std::string& servname,
            const std::string& remotehost, const std::string& remoteport, u_int32_t election_flags)
    {
        nb_mkdir(m_dbhome_.c_str());
        u_int32_t priority = (is_master() ? 10 : 5);
        return init_(hostname, servname, remotehost, remoteport, election_flags, priority);
    }

    int closeenv()
    {
        try
        {
            return m_env_.close(0);
        }
        catch (DbException& e)
        {
            return e.get_errno();
            throw e;
        }
    }

    bool is_master() const
    {
        return m_state.m_master;
    }

    bool is_ready() const
    {
        return m_state.m_ready;
    }

    int get_master_eid() const
    {
        assert(is_ready());
        return m_state.m_master_eid;
    }

    bool get_master(int eid, in_port_t& eidport, std::string& eidhost)
    {
        assert(is_ready());
        assert(eid >= 0);
        unsigned int count;
        DB_REPMGR_SITE* sitehead = NULL;
        m_env_.repmgr_site_list(&count, &sitehead);
        auto_delete<DB_REPMGR_SITE, free_functor> mem_sites(sitehead);

        assert(0 <= eid && (unsigned int)eid <= count);
        assert(sitehead != NULL);

        DB_REPMGR_SITE* site = sitehead + eid;

        eidhost = site->host;
        eidport = site->port;

        return true;
    }

protected:
    int init_(const std::string& hostname, const std::string& servname,
            const std::string& remotehost, const std::string& remoteport,
            u_int32_t election_flags, u_int32_t priority)
    {
        m_env_.set_errfile(stderr);
    //  m_env_.set_errpfx(m_progname_.c_str());
        m_env_.set_app_private(&m_state);
        m_env_.set_event_notify(this->event_callback);

        u_int16_t local_port = from_string<u_int16_t>(servname);
        int ret = 0;
        ret = m_env_.repmgr_set_local_site(hostname.c_str(), local_port, 0);

        if (!remotehost.empty())
        {
            u_int16_t remote_port = from_string<u_int16_t>(remoteport);
            ret = m_env_.repmgr_add_remote_site(remotehost.c_str(), remote_port, 0, 0);
        }

    //  if (app_config->totalsites > 0)
    //  {
    //      ret = m_env_.rep_set_nsites(app_config->totalsites);
    //  }

        m_env_.rep_set_priority(priority);

        // Permanent messages require all ack.
        m_env_.repmgr_set_ack_policy(DB_REPMGR_ACKS_ALL);
        // Give 500 microseconds to receive the ack.
    //  m_env_.rep_set_timeout(DB_REP_ACK_TIMEOUT, 500);

        // We can now open our environment, although we're not ready to
        // begin replicating.  However, we want to have a m_env_ around
        // so that we can send it into any of our message handlers.
        m_env_.set_cachesize(0, IDIP_CACHESIZE, 0);
        m_env_.set_flags(DB_TXN_NOSYNC, 1);

        m_env_.log_set_config(DB_LOG_AUTO_REMOVE, 1);

        // TODO: whether need we call DBEnv.set_data_dir()

        ret = m_env_.open(m_dbhome_.c_str(), SNOW_ENV_TYPE_REP, 0);
        assert(ret == 0);
        if (ret == 0)
        {
            ret = m_env_.repmgr_start(3, election_flags);
            while (!is_ready())
                sleep(1);
        //  std::cout << "the new master eid is " << get_master_eid() << std::endl;
        }

        return ret;
    }

protected:
    static void print_rep_event(u_int32_t which)
    {
        const char* rep_event_name[] =
        {
            "DB_EVENT_NO_SUCH_EVENT",
            "DB_EVENT_PANIC",
            "DB_EVENT_REP_CLIENT",
            "DB_EVENT_REP_ELECTED",
            "DB_EVENT_REP_MASTER",
            "DB_EVENT_REP_NEWMASTER",
            "DB_EVENT_REP_PERM_FAILED",
            "DB_EVENT_REP_STARTUPDONE",
            "DB_EVENT_WRITE_FAILED",
        };

        if (which < 0 || which > DB_EVENT_WRITE_FAILED)
            which = DB_EVENT_NO_SUCH_EVENT;

        // TODO: we hope to enable this line in the future
        //std::cout << rep_event_name[which] << " rep event is received" << std::endl;
        LOG_DEBUG(rep_event_name[which] << "rep event is received");
    //  DUKELOG_DEBUG(m_log, rep_event_name[which] << " rep event is received");
    }

    // WARNING:
    // Callback function should not attempt to make library calls(for example,
    // to release locks or close open handles), the results are undefined.
    static void event_callback(DbEnv * envp, u_int32_t which, void *info)
    {
    //  print_rep_event(which);

        nbrep_state* pstate = (nbrep_state*)envp->get_app_private();
        switch (which)
        {
        case DB_EVENT_REP_MASTER:
            pstate->m_master = true;
            pstate->m_ready = true;
            break;

        case DB_EVENT_REP_CLIENT:
            pstate->m_master = false;
            break;

        case DB_EVENT_REP_STARTUPDONE:
            pstate->m_ready = true;
            break;

        case DB_EVENT_REP_NEWMASTER:
            assert(info != NULL);
            pstate->m_master_eid = *(int*)(info);
            break;

        default:
        //  envp->errx("ignoring event %d", which);
            break;
        }
    }
};

class nbdbc
{
private:
    Dbc* m_dbc;

public:
    nbdbc(Db* dbp)
    {
        int ret;
        if ((ret = dbp->cursor(NULL, &m_dbc, 0)) != 0)
        {
        //  DUKELOG_ERROR(m_log, "can't open cursor, " << db_strerror(ret));
        }
    }

    ~nbdbc()
    {
        try
        {
            m_dbc->close();
        }
        catch (DbException& e)
        {
        //  DUKELOG_ERROR(m_log, "DbException throwed when closing cursor: " << e.what());
        }
    }

    Dbc*
    operator->() throw()
    {
        return m_dbc;
    }

    const Dbc*
    operator->() const throw()
    {
        return m_dbc;
    }

    int write(const void* key, u_int32_t nkey, const void* data, u_int32_t ndata)
    {
        Dbt dbkey(const_cast<void*>(key), nkey);
        Dbt dbdata(const_cast<void*>(data), ndata);
        return m_dbc->put(&dbkey, &dbdata, DB_CURRENT);
    }

    int read(std::string& strkey, std::string& strval)
    {
        auto_buffer<char> keybuf;
        auto_buffer<char> buf;
        int ret = this->read(keybuf, buf);
        if (ret == 0)
        {
            strkey.assign(keybuf.data(), keybuf.size());
            strval.assign(buf.data(), buf.size());
        }
        return ret;
    }

    template <typename _DataType>
    int read(auto_buffer<_DataType>& keybuf, auto_buffer<_DataType>& buf)
    {
        Dbt dbkey;
        Dbt dbdata;
        dbkey.set_flags(DB_DBT_MALLOC);
        dbdata.set_flags(DB_DBT_MALLOC);
        int ret = m_dbc->get(&dbkey, &dbdata, DB_NEXT);
        keybuf.reset(static_cast<_DataType*>(dbkey.get_data()), dbkey.get_size());
        buf.reset(static_cast<_DataType*>(dbdata.get_data()), dbdata.get_size());
        return ret;
    }
};

template <typename _EnvType, typename _DbType>
class nbdb_impl
{
public:
    typedef size_t size_type;

protected:
    _EnvType& m_env_;
    Db* m_dbp_;
    Db* m_sdbp_;

public:
    nbdb_impl(const std::string& dbfile, const std::string& dbname,
            _EnvType& env, bool dupsort, u_int32_t flags)
        : m_env_(env), m_dbp_(NULL), m_sdbp_(NULL)
    {
        _DbType* self = static_cast<_DbType*>(this);
        self->doopen(dbfile, dbname, dupsort, flags);
    }

    ~nbdb_impl()
    {
        _DbType* self = static_cast<_DbType*>(this);
        self->doclose();
    }

    Db* get_db()
    {
        return m_dbp_;
    }

    const Db* get_db() const
    {
        return m_dbp_;
    }

    Db* get_sdb()
    {
        return m_sdbp_;
    }

    const Db* get_sdb() const
    {
        return m_sdbp_;
    }

    Db*
    operator->() throw()
    {
        return m_dbp_;
    }

    int txn_begin(DbTxn*& txn)
    {
        return m_env_.get_env().txn_begin(NULL, &txn, 0);
    }

    int txn_snapshot_begin(DbTxn*& txn)
    {
        return m_env_.get_env().txn_begin(NULL, &txn, DB_TXN_SNAPSHOT);
    }

    int commit(DbTxn*& txn)
    {
        return txn->commit(0);
    }

    int rollback(DbTxn*& txn)
    {
        return txn->abort();
    }

    const Db*
    operator->() const throw()
    {
        return m_dbp_;
    }

    int associate(DbTxn* txnid, Db* sdbp,
            int (*callback)(Db*, const Dbt*, const Dbt*, Dbt*), u_int32_t flags)
    {
        assert(sdbp != NULL);
        m_sdbp_ = sdbp;
        return m_dbp_->associate(txnid, sdbp, callback, flags);
    }

    int truncate(DbTxn* txnid = NULL)
    {
        return m_dbp_->truncate(txnid, 0, 0);
    }

    int del(const std::string& strkey, DbTxn* txn = NULL)
    {
        return this->del(strkey.data(), strkey.size(), txn);
    }

    int del(const void* key, u_int32_t nkey, DbTxn* txn = NULL)
    {
        _DbType* self = static_cast<_DbType*>(this);
        self->do_prewrite();

        Dbt dbkey(const_cast<void*>(key), nkey);
        return m_dbp_->del(txn, &dbkey, 0);
    }

    size_type
    size()
    {
        DB_BTREE_STAT* db_stat_ptr = NULL;
        m_dbp_->stat(NULL, &db_stat_ptr, 0);
        auto_delete<DB_BTREE_STAT, free_functor> ptr(db_stat_ptr);
        return ptr->bt_ndata;
    }

    int write(const std::string& strkey, const std::string& strval, DbTxn* txn = NULL)
    {
        return this->write(strkey.data(), strkey.size(),
                strval.data(), strval.size(), txn);
    }

    template <typename _DataType>
    int write(const std::string& strkey, const auto_buffer<_DataType>& buf, DbTxn* txn = NULL)
    {
        return this->write(strkey.data(), strkey.size(), buf.data(), buf.size(), txn);
    }

    template <typename _DataType>
    int write(const void* key, u_int32_t nkey, const auto_buffer<_DataType>& buf, DbTxn* txn = NULL)
    {
        return this->write(key, nkey, buf.data(), buf.size(), txn);
    }

    int write(const void* key, u_int32_t nkey, const void* data, u_int32_t ndata, DbTxn* txn = NULL)
    {
        _DbType* self = static_cast<_DbType*>(this);
        self->do_prewrite();

        Dbt dbkey(const_cast<void*>(key), nkey);
        Dbt dbdata(const_cast<void*>(data), ndata);
        return m_dbp_->put(txn, &dbkey, &dbdata, 0);
    }

    int read(const std::string& strkey, std::string& strval, DbTxn* txn = NULL)
    {
        auto_buffer<char> buf;
        int ret = this->read(strkey.data(), strkey.size(), buf, txn);
        if (ret == 0)
            strval.assign(buf.data(), buf.size());
        return ret;
    }

    template <typename _DataType>
    int read(const std::string& strkey, auto_buffer<_DataType>& buf, DbTxn* txn = NULL)
    {
        return this->read(strkey.data(), strkey.size(), buf, txn);
    }

    template <typename _DataType>
    int read(const void* key, u_int32_t nkey, auto_buffer<_DataType>& buf, DbTxn* txn = NULL)
    {
        Dbt dbkey(const_cast<void*>(key), nkey);
        Dbt dbdata;
        dbdata.set_flags(DB_DBT_MALLOC);
        int ret = m_dbp_->get(txn, &dbkey, &dbdata, 0);
        buf.reset(static_cast<_DataType*>(dbdata.get_data()), dbdata.get_size());
        return ret;
    }


// overridable methods
    int doopen(const std::string dbfile, const std::string dbname, bool dupsort, u_int32_t flags)
    {
        m_dbp_ = new Db(&m_env_.get_env(), 0);

        if (dupsort)
            m_dbp_->set_flags(DB_DUPSORT);

        const int mode = S_IRUSR | S_IWUSR | S_IRGRP;
        return m_dbp_->open(NULL, dbfile.c_str(), dbname.c_str(), DB_BTREE, flags, mode);
    }

    void doclose()
    {
        if (m_dbp_ != 0)
        {
            try
            {
            //  m_dbp_->close(DB_NOSYNC);
                m_dbp_->close(0);
                delete m_dbp_;
                m_dbp_ = NULL;
            }
            catch (DbException& e)
            {
            //  DUKELOG_ERROR(m_log, "Unexpected error closing : " << e.what());
            }
        }
    }

    void do_prewrite()
    { }
};

class nbdb : public nbdb_impl<nbnv, nbdb>
{
public:
    nbdb(const std::string& dbfile, const std::string& dbname,
            nbnv& env, u_int32_t flags = SNOW_DB_TYPE_TDS, bool dupsort = false)
        : nbdb_impl<nbnv, nbdb>(dbfile, dbname, env, dupsort, flags)
    { }
};

class nbrep_db : public nbdb_impl<nbrep, nbrep_db>
{
public:
    nbrep_db(const std::string& dbfile, const std::string& dbname,
            nbrep& env, bool dupsort = false, u_int32_t flags = SNOW_DB_TYPE_REP)
        : nbdb_impl<nbrep, nbrep_db>(dbfile, dbname, env, dupsort, flags)
    { }

    bool is_master() const
    {
        return m_env_.is_master();
    }

    bool is_ready() const
    {
        return m_env_.is_ready();
    }

    int get_master_eid() const
    {
        return m_env_.get_master_eid();
    }

    bool get_master(int eid, in_port_t& eidport, std::string& eidhost)
    {
        return m_env_.get_master(eid, eidport, eidhost);
    }

    int doopen(const std::string& dbfile, const std::string& dbname,
            bool dupsort, u_int32_t flags)
    {
        int ret = 0;
        while (m_dbp_ == NULL)
        {
            m_dbp_ = new Db(&m_env_.get_env(), 0);

            try
            {
                if (dupsort)
                    m_dbp_->set_flags(DB_DUPSORT);
                uint32_t pagesize = nb_getpagesize();
                if (pagesize != 0)
                    m_dbp_->set_pagesize(pagesize);

                if (is_master())
                    flags |= DB_CREATE;
                const int mode = 0;//S_IRUSR | S_IWUSR | S_IRGRP;

                ret = m_dbp_->open(NULL, dbfile.c_str(), dbname.c_str(), DB_BTREE, flags, mode);
            }
            catch (DbException& e)
            {
                // It is expected that this condition will be triggered
                // when client sites start up.  It can take a while for
                // the master site to be found and synced, and no DB will
                // be available until then.
                ret = e.get_errno();
                if (e.get_errno() == ENOENT)
                {
                    // No IDIP database available yet - retrying ...
                    delete m_dbp_;
                    m_dbp_ = NULL;
                    sleep(3);
                }
                else
                {
                    throw e;
                }
            }
        }
        return ret;
    }

    void do_prewrite()
    {
        assert(is_master());
        assert(is_ready());
    }

public:
    int doloop()
    {
        int ret = 0;

        Db *dbp = m_dbp_;
        while (true)
        {
            if (is_master())
                LOG_DEBUG("DUKEMASTER");
            else
                //std::cout << "DUKEREPLICA " << get_master_eid();
                LOG_DEBUG("DEKEREPLICA" << get_master_eid() << ">");
            //std::cout << "> " << std::flush;

            std::string line;
            if (!std::getline(std::cin, line))
            {
                //std::cout << "std::getline() return null" << std::endl;
                LOG_DEBUG("std::getline() return null");
                break;
            }

            if (line.empty())
            {
                switch ((ret = print_items(dbp)))
                {
                case 0:
                    show_rep_sites(&m_env_.get_env());
                //  m_env_.repmgr_stat_print(DB_STAT_ALL);
                    continue;
                    break;
                case DB_REP_HANDLE_DEAD:
                    (void)dbp->close(DB_NOSYNC);
                //  DUKELOG_ERROR(m_log, "closing db handle due to rep handle dead");
                    dbp = NULL;
                    continue;
                    break;
                default:
                //  DUKELOG_ERROR(m_log, "Error traversing data, " << db_strerror(ret));
                    break;
                }
                if (ret != 0 && ret != DB_REP_HANDLE_DEAD)
                    break;
            }

            std::istringstream iss(line.c_str());
            std::string skey, sdata;
            if (!(iss >> skey) || !(iss >> sdata))
            {
                if (skey == "quit" || skey == "exit")
                    break;
                m_env_->errx("Format: KEY VALUE");
                continue;
            }

            if (!is_master())
            {
            //  DUKELOG_ERROR(m_log, "Can't update at client");
                continue;
            }

            Dbt key, data;
            memset(&key, 0, sizeof(key));
            memset(&data, 0, sizeof(data));

            key.set_data(const_cast<char*>(skey.c_str()));
            key.set_size(skey.size());
            data.set_data(const_cast<char*>(sdata.c_str()));
            data.set_size(sdata.size());

            if ((ret = dbp->put(NULL, &key, &data, 0)) != 0)
            {
            //  DUKELOG_ERROR(m_log, "DB->put, " << db_strerror(ret));
                if (ret != DB_KEYEXIST)
                    break;
            }
        }

        return (ret);
    }

    static void show_rep_sites(DbEnv* envp)
    {
        unsigned int count;
        DB_REPMGR_SITE* listp = NULL;
        envp->repmgr_site_list(&count, &listp);
        //std::cout << "the total number of replication group is " << count << std::endl;
        LOG_DEBUG("the total number of replication group is");
        for (unsigned int i = 0; i < count; ++i)
        {
            DB_REPMGR_SITE* site = listp + i;
            LOG_DEBUG(site->eid
                << ": { " << site->host << ":" << site->port
                << " }, status is " << (site->status == DB_REPMGR_CONNECTED ? "connected" : "disconnected"));
        }
        free(listp);
    }

    // Display all the stock quote information in the database.
    static int print_items(Db *dbp)
    {
        Dbc *dbc;
        int ret;
        if ((ret = dbp->cursor(NULL, &dbc, 0)) != 0)
        {
            dbp->err(ret, "can't open cursor");
            return (ret);
        }

        Dbt key, data;
        memset(&key, 0, sizeof(key));
        memset(&data, 0, sizeof(data));

        LOG_DEBUG("\tSymbol\tPrice" << std::endl << "\t======\t=====" );

        for (ret = dbc->get(&key, &data, DB_FIRST); ret == 0; ret = dbc->get(&key, &data, DB_NEXT))
        {
            std::string skey((char*)key.get_data(), key.get_size());
            std::string sdata((char*)data.get_data(), data.get_size());
            LOG_DEBUG("\t" << skey << "\t" << sdata);
        }
        //std::cout << std::endl << std::flush;

        int t_ret;
        if ((t_ret = dbc->close()) != 0 && ret == 0)
        {
            LOG_DEBUG("closed cursor");
            ret = t_ret;
        }

        switch (ret)
        {
        case 0:
        case DB_NOTFOUND:
        case DB_LOCK_DEADLOCK:
            return (0);
        default:
            return (ret);
        }
    }
};


#endif // __DUKE_SNOW_BDB_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
