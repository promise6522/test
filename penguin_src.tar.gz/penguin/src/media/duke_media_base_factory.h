/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#ifndef _DUKE_MEDIA_BASE_FACTORY_H_
#define _DUKE_MEDIA_BASE_FACTORY_H_

#include "duke_logic_id.h"
#include "duke_media_base.h"

namespace duke_media_base_factory {

// factory method
duke_media_base_ptr get_media_from_handle(const duke_media_handle& h);


}/* namespace duke_media_base_factory */

#endif /* _DUKE_MEDIA_BASE_FACTORY_H_ */
