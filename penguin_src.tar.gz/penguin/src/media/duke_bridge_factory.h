#ifndef __DUKE_BRIDGE_FACTORY_H
#define __DUKE_BRIDGE_FACTORY_H

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <sstream>

#include "duke_logic_object.h"
#include "duke_logic_object_data.h"

/*
#include "duke_bridge_data_desc.h"

class UBuffer;
class bridge_factory;
bool duke_media_set_bridge(const dukeid_t& id);
void duke_stream(const dukeid_t& interface, UBuffer& buffer, const std::string& tx);
void duke_xstream(const dukeid_t& oid, std::ostream* aStream, const std::string& tx);
void duke_create_duker_bridge(const int64_t& id, const std::string& tx);
dukeid_t duke_materialize(const std::string& buffer, bridge_factory& factory, const std::string& tx);


static std::map<int64_t, bridge_factory>  m_bf_map;
static std::map<int32_t, int32_t> m_struct_map; // <struct_number, index>

class bridge_factory
{
private:
    int64_t         m_bridge_id;
    dukeid_vector   m_interfaces;

private:
    static std::string pack_bf(const bridge_factory& bf)
    {
        std::string strhmap;
        strhmap += "[" + int64_2_str(bf.m_bridge_id) + "]";
        strhmap += "[" + pack_dukeid_vector(bf.m_interfaces) + "]";
        return strhmap;
    }

    static void unpack_bf(const std::string& strbf, bridge_factory& bf)
    {
        std::string::size_type pos(0);
        while (strbf.length())
        {
            std::string strfirst, strsecond;
            pos = find_between(strbf, strfirst, "[", "]", pos);
            if (pos == std::string::npos)
                break;
            pos = find_between(strbf, strsecond, "[", "]", pos);

            bf.m_bridge_id = str_2_id64(strfirst);
            unpack_dukeid_vector(strsecond, bf.m_interfaces);
        }
    }

    static std::string pack_bf_map(const std::map<int64_t, bridge_factory>& hmap)
    {
        std::string strhmap;
        std::map<int64_t, bridge_factory>::const_iterator it = hmap.begin();
        for (; it != hmap.end(); ++it)
        {
            strhmap += "{" + int64_2_str(it->first) + "}";
            strhmap += "{" + pack_bf(it->second) + "}";
        }
        return strhmap;
    }

    static void unpack_bf_map(const std::string& strhmap, std::map<int64_t, bridge_factory>& hmap)
    {
        std::string::size_type pos(0);
        hmap.clear();
        while (strhmap.length())
        {
            std::string strfirst, strsecond;
            pos = find_between(strhmap, strfirst, "{", "}", pos);
            if (pos == std::string::npos)
                break;
            pos = find_between(strhmap, strsecond, "{", "}", pos);

            int64_t bid = str_2_id64(strfirst);
            bridge_factory bf;
            unpack_bf(strsecond, bf);
            hmap.insert(std::make_pair(bid, bf));
        }
    }

    bridge_factory()
    { }

    static void load_bf(const int64_t& center_id)
    {
        // load the bf map from disk
        std::string key = int64_2_str(center_id);
        std::string value;
        duke_verifydb_read("localhost", "0", key, value);
//        std::cout<<"$$$$$ read, key="<<key<<", value="<<value<<std::endl;
        unpack_bf_map(value, m_bf_map);
        
        // load the struct map from disk
        std::string skey = int64_2_str(center_id+0x100); // TBD
        std::string svalue;
        duke_verifydb_read("localhost", "0", skey, svalue);
        unpack_int32t_map(svalue, m_struct_map);
    }

public:
    static int64_t get_center_id()
    {
        return 0;
    }

    static bridge_factory& get_factory(const int64_t& bridge_id, const std::string& tx)
    {
        // retrieve from storage the factory at given place.
        // if not available, call duke_create_duker_bridge and retrieve again

        // search the bridge_factory by bridge_id
        std::map<int64_t, bridge_factory>::iterator it = m_bf_map.find(bridge_id);
        if (it != m_bf_map.end())
            return it->second;

        // if not find, 1st to load
        load_bf(0);
        it = m_bf_map.find(bridge_id);
        if (it != m_bf_map.end())
            return it->second;

        // if not find, 2nd to make
        duke_create_duker_bridge(bridge_id, tx);

        // search again
        it = m_bf_map.find(bridge_id);
        return it->second;
    }

    static dukeid_t create_bridge_interface_id()
    {
        // call internal create function
        return dukeid_t(DUKEID_TYPE_INTERFACE_BRIDGE);
    }

    static dukeid_t create_bridge_object_id()
    {
        // call internal create function
        return dukeid_t(DUKEID_TYPE_OBJECT_BRIDGE);
    }

    static bool create_id(dukeid_type_t type, int32_t value, dukeid_t& id)
    {
        if (DUKEID_TYPE_OBJECT_FLOAT == type)
        {
            dukeid_t temp(type);
            float fvalue = value * 0.00001;
            temp.set_value(fvalue);
            id = temp;
            return true;
        }
        else if (DUKEID_TYPE_OBJECT_BOOL == type || DUKEID_TYPE_OBJECT_INT == type)
        {
            dukeid_t temp(type);
            temp.set_value(value);
            id = temp;
            return true;
        }
        else
        {
            dukeid_t temp(DUKEID_TYPE_EXCEPTION);
            id = temp;
            return false;
        }
    }

    // create duke object according to the data type given
    static dukeid_t create_builtin_object(const bool& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_boolean dobj(data, strtxn);
        return dobj.get_id();
    }
    static dukeid_t create_builtin_object(const int& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_integer dobj(data, strtxn);
        return dobj.get_id();
    }
    static dukeid_t create_builtin_object(const float& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_float dobj(data, strtxn);
        return dobj.get_id();
    }
    static dukeid_t create_builtin_object(const std::string& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_string dobj(data, strtxn);
        return dobj.get_id();
    }
    static dukeid_t create_builtin_object(const duke_bytes_t& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_bytes dobj(data, strtxn);
        return dobj.get_id();
    }
    static dukeid_t create_builtin_object(const duke_time_t& data, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        if (type == DUKEID_TYPE_OBJECT_INTERVAL)
        {
            duke_object_interval dobj(data, strtxn);
            return dobj.get_id();
        }
        else
        {
            duke_object_time dobj(data, strtxn);
            return dobj.get_id();
        }
    }
    static dukeid_t create_builtin_object(const dukeid_vector& arrtype, const dukeid_vector& arrdata, const std::string& strtxn, dukeid_type_t type = DUKEID_TYPE_NULL)
    {
        duke_object_array dobj(arrtype, arrdata, strtxn);
        return dobj.get_id();
    }

    static void register_factory(const int64_t& bridge_id, const std::vector<dukeid_t>& interfaces)
    {
        // create new factory, and put it at the given place in storage

        // create new factory
        bridge_factory bf(bridge_id, interfaces);

        // save in storage
        m_bf_map.insert(std::make_pair(bridge_id, bf));

        // save the bf map in disk
        std::string value = pack_bf_map(m_bf_map);
        int64_t center_id = get_center_id();
        std::string key = int64_2_str(center_id);
//        std::cout<<"$$$$$ write, key="<<key<<", value="<<value<<std::endl;
        duke_verifydb_write("localhost", "0", key, value);

        // save the struct map in disk
        std::string sval = pack_int32t_map(m_struct_map);
        std::string skey = int64_2_str(center_id+0x100); // TBD
        duke_verifydb_write("localhost", "0", skey, sval);
    }

    bridge_factory(const int64_t& center_id)
    {
        load_bf(center_id);
    }

    bridge_factory(const int64_t& bridge_id, const std::vector<dukeid_t>& interfaces)
        : m_bridge_id(bridge_id), m_interfaces(interfaces)
    { }

    const dukeid_t& get_interface(const int32_t& index)
    {
        std::map<int32_t, int32_t>::iterator it = m_struct_map.find(index);
//        assert (it != m_struct_map.end());
        return m_interfaces[it->second];
    }

    const dukeid_t createObject(const std::string& buffer, const std::string& tx)
    {
        return duke_materialize(buffer, *this, tx);
    }
};

class bridge_object : public duke_object_base
{
private:
    duke_bridge_object_data m_data;

public:
    bridge_object(const dukeid_t& bri_obj_id, const duke_bridge_object_data& data, const std::string& strtxn)
        : duke_object_base(bri_obj_id), m_data(data)
    {
        // save
        std::string strval = m_data.pack();
        get_id().set_value(strval, strtxn);
    }

    bridge_object(const dukeid_t& bri_obj_id, const std::string& strtxn) : duke_object_base(bri_obj_id)
    {
        // load
        duke_object_base::load(bri_obj_id, strtxn, m_data);
    }

    void stream(UBuffer& out, const std::string& tx)
    {
        duke_stream(get_id(), out, tx);
    }

    void xstream(std::ostream* out, const std::string& tx)
    {
        duke_xstream(get_id(), out, tx);
    }

    bool get_data(duke_bridge_object_data& data) const
    {
        data = m_data;
        return true;
    }

    dukeid_vector get_sub_objects() const
    {
        return m_data.m_sub_objects;
    }

    dukestr_vector get_sub_names() const
    {
        return m_data.m_sub_names;
    }

    bool get_name(std::string& name) const
    {
        name = m_data.m_name;
        return true;
    }

    dukeid_t get_interface() const
    {
        return m_data.m_interface;
    }
};
*/
class bridge_declaration : public duke_object_base
{
private:
    dukeid_t      m_interface;
    std::string   m_name;

    std::string pack()
    {
        std::string strval;
        strval = m_interface.str();
        strval.append(m_name);
        return strval;
    }
    
    void unpack(const std::string& strval)
    {
        std::string str = strval;
        dukeid_t id(str.substr(0, ID_LENGTH));
        m_interface = id;
        str = str.substr(ID_LENGTH);
        m_name = str;
    }

public:
    bridge_declaration(const dukeid_t& id, const dukeid_t& ifid, const std::string& name, const std::string& strtxn) : duke_object_base(id)
    {
        // save
        m_interface = ifid;
        m_name = name;
        get_id().set_value(pack());
    }

    bridge_declaration(const dukeid_t& id, const std::string& strtxn) : duke_object_base(id)
    {
        // load
        std::string strval;
        get_id().get_value(strval);
        unpack(strval);
    }

    dukeid_t get_interface()
    {
        return m_interface;
    }

    std::string get_name()
    {
        return m_name;
    }
};

class bridge_interface : public duke_logic_interface
{
private:
    duke_bridge_interface_data m_data;

public:
    bridge_interface(const dukeid_t& briifid, const duke_bridge_interface_data& data, const std::string& strtxn)
        : duke_logic_interface(briifid), m_data(data)
    {
        // save
        dukeid_t id(NBID_TYPE_FUNCTION_BRIDGE_COMPOSE);
        dukeid_t id1(NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE);
        m_data.m_decls.clear();
        m_data.m_decls.push_back(id);
        m_data.m_decls.push_back(id1);
        bridge_declaration decl(id, briifid, "compose", strtxn);
        bridge_declaration decl1(id1, briifid, "decompose", strtxn);

        std::string strval = m_data.pack();
        bool ret = get_id().set_value(strval);
        assert(ret);
    }

    bridge_interface(const dukeid_t& briifid, const std::string& strtxn) : duke_logic_interface(briifid)
    {
        // load
        std::string strval;
        briifid.get_value(strval);
        m_data.unpack(strval);
    }

    int64_t get_number_of_subobjects() const
    {
        return m_data.m_sub_interfaces.size();
    }

    bool get_data(duke_bridge_interface_data& data) const
    {
        data = m_data;
        return true;
    }

    bool get_declarations(dukeid_vector& vdecl) const
    {
        vdecl = m_data.m_decls;
        return true;
    }

    dukeid_t get_interface_for_position(const int64_t& index) const
    {
        return m_data.m_sub_interfaces[index];
    }

    bool get_interfaces(dukeid_vector& vif) const
    {
        vif = m_data.m_sub_interfaces;
        return true;
    }

    dukestr_vector get_sub_names() const
    {
        return m_data.m_sub_names;
    }

    int64_t get_data_index() const
    {
        return m_data.m_data_index;
    }
/*
    dukeid_t create_new_object(const dukeid_vector& sub_objects, const std::string& strtxn)
    {
        // the following implementation assumes perfect parameters all the time.
        // some type checking maybe necessary for debugging in the beginning.

        dukeid_t briobjid = bridge_factory::create_bridge_object_id();
        duke_bridge_object_data data;
        data.m_interface = this->get_id();
        data.m_sub_objects = sub_objects;
        bridge_object bridge(briobjid, data, strtxn);
        return bridge.get_id();
    }
*/
    std::string get_name() const
    {
        return m_data.m_external_name;
    }
};

/*
typedef std::map<std::string, dukeid_t> duke_name_handle_map;
typedef duke_name_handle_map::iterator duke_name_handle_iterator;
typedef duke_name_handle_map::const_iterator duke_name_handle_const_iterator;

typedef std::map<std::string, dukeid_t> duke_name_ifc_map;
typedef duke_name_ifc_map::iterator duke_name_ifc_iterator;
typedef duke_name_ifc_map::const_iterator duke_name_ifc_const_iterator;

typedef std::vector<duke_bridge_struct_desc*> duke_st_data; 
typedef duke_st_data::const_iterator duke_bridge_st_const_iterator;

typedef std::vector<duke_bridge_field_desc*> duke_fd_data; 
typedef duke_fd_data::const_iterator duke_bridge_fd_const_iterator;

inline void generate_name_handle_map(duke_name_handle_map& name_handle, duke_name_ifc_map& name_ifc,
        const duke_st_data& data, duke_bridge_object_data& m_data, duke_bridge_interface_data& objifc_data)
{
    int32_t index = 0;
    m_struct_map.clear();

    for (duke_bridge_st_const_iterator it = data.begin(); it != data.end(); ++it)
    {
        duke_bridge_interface_data ifc_data;
        ifc_data.m_data_index = (*it)->struct_number;
        ifc_data.m_external_name = (*it)->struct_name;
        dukeid_t ifid(DUKEID_TYPE_INTERFACE_BRIDGE);
        bridge_interface ifc(ifid, ifc_data, "");

        m_data.set_name((*it)->struct_name);
        objifc_data.m_sub_interfaces.push_back(ifid);
        dukeid_t id(DUKEID_TYPE_OBJECT_BRIDGE);
        bridge_object obj(id, m_data, "");        
        name_handle.insert(std::make_pair((*it)->struct_name, id));
        name_ifc.insert(std::make_pair((*it)->struct_name, ifid));
        duke_media_set_bridge(id);
        
        m_struct_map.insert(std::make_pair((*it)->struct_number, index++));
    }
}

inline void generate_atom_object(const duke_bridge_field_desc* fd, dukeid_t& hatomobj,
                const duke_name_handle_map& name_handle, const duke_name_ifc_map& name_ifc, dukeid_t& hif)
{
    if (fd->field_type_name == "integer")
    {
        duke_object_integer obj(0, "");
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
    else if (fd->field_type_name == "boolean")
    {
        duke_object_boolean obj(false, "");
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
    else if (fd->field_type_name == "float")
    {
        duke_object_float obj(0.0, "");
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
    else if (fd->field_type_name == "string")
    {
        duke_object_string obj("", "");
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
    else if (fd->field_type_name == "byteArray")
    {
        duke_object_bytes obj;
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
    else
    {
         duke_name_handle_const_iterator iter = name_handle.find(fd->field_type_name);
         duke_name_ifc_const_iterator it = name_ifc.find(fd->field_type_name);
         if ((iter != name_handle.end()) && (it != name_ifc.end()))
         {
             hif = it->second;
             hatomobj = iter->second;
         }
    }

    // is array
    if (fd->is_array)
    {
        dukeid_vector type, vid;
        type.push_back(hif);
        duke_object_array obj(type, vid, "");
        hatomobj = obj.get_id();
        obj.get_interface(hif);
    }
}

inline void generate_subobject(const dukeid_t& hobj, const duke_bridge_struct_desc* it,
        const duke_name_handle_map& name_handle, const duke_name_ifc_map& name_ifc)
{
    duke_name_ifc_const_iterator iter = name_ifc.find(it->struct_name);

    bridge_object tmp_obj(hobj, "");
    duke_bridge_object_data m_data;
    tmp_obj.get_data(m_data);
    if (iter != name_ifc.end())
        m_data.m_interface = iter->second;
    bridge_interface tmp_ifc(iter->second, "");
    duke_bridge_interface_data m_data_if;
    tmp_ifc.get_data(m_data_if);

    for (duke_bridge_fd_const_iterator iter = it->fields.begin(); iter != it->fields.end(); ++iter)
    {
        dukeid_t hatomobj, hifid;
        generate_atom_object(*iter, hatomobj, name_handle, name_ifc, hifid);
        m_data.m_sub_names.push_back((*iter)->field_name);
        m_data.m_sub_objects.push_back(hatomobj);
        m_data_if.m_sub_interfaces.push_back(hifid);
        m_data_if.m_sub_names.push_back((*iter)->field_name);
    }
    bridge_object subobj1(hobj, m_data, "");
    bridge_interface subif1(iter->second, m_data_if, "");
}

inline void generate_object(const duke_name_handle_map& name_handle, const duke_name_ifc_map& name_ifc,
        const duke_st_data& data, const duke_bridge_interface_data& ifc_data)
{
    for (duke_bridge_st_const_iterator it = data.begin(); it != data.end(); ++it)
    {
        std::string name = (*it)->struct_name;
        duke_name_handle_const_iterator iter = name_handle.find(name);
        if (iter != name_handle.end())
        {
            // struct handle, struct, map
            generate_subobject(iter->second, (*it), name_handle, name_ifc);
        } 
    }
}

inline void generate_the_stuff(const int64_t& id, std::vector<duke_bridge_struct_desc*>& data, const std::string& tx)
{
    duke_bridge_object_data m_data;
    duke_bridge_interface_data ifc_data;

    dukeid_t ifid(DUKEID_TYPE_INTERFACE_BRIDGE);
    m_data.m_interface = ifid;

    duke_name_handle_map name_handle;
    duke_name_ifc_map name_ifc;
    generate_name_handle_map(name_handle, name_ifc, data, m_data, ifc_data);
 
    bridge_interface ifc(ifid, ifc_data, "");
   
    for (duke_name_handle_const_iterator it = name_handle.begin(); it != name_handle.end(); ++it)
    {
        m_data.m_sub_names.push_back(it->first);
        m_data.m_sub_objects.push_back(it->second);
    }

    generate_object(name_handle, name_ifc, data, ifc_data);

    bridge_factory::register_factory(0, ifc_data.m_sub_interfaces);

    clean_up(data);
}
*/
#endif // __DUKE_BRIDGE_FACTORY_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
