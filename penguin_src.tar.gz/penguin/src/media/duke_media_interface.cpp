
#include "duke_media_interface.h"
#include "duke_media_global.h"
#include "stdx_log.h"

//this only for duke_media_base_factory
duke_media_interface::duke_media_interface()
{
}

//duke_media_interface::duke_media_interface(const host_committer_id_t& host_id, const std::string& username) : duke_media_base(DUKE_MEDIA_TYPE_INTERFACE_USER, host_id)    
//{
//    //noted by elison
//    //bool ret = clear_declaration();
//    //assert(ret);
//}


duke_media_interface::duke_media_interface(const duke_media_handle& hif, const std::string& username)
{
    bool ret = this->assign(hif);
    assert(ret);
}

bool duke_media_interface::assign(const duke_media_handle& hif)
{
    bool ret = false;
    if (!hif.is_builtin_interface())
    {
        return false;
    }

    ret = this->get_builtin_instructions(hif);
    this->set_handle(hif);

    return ret;
}


bool duke_media_interface::is_interface_array() const
{
    return this->get_handle().is_interface_array();
}

bool duke_media_interface::is_interface_map() const
{
    return this->get_handle().is_interface_map();
}

bool duke_media_interface::get_declarations(duke_media_handle_vector& hdecls) const
{
    hdecls = this->m_ifc.m_hdecls;
    return true;
}


bool duke_media_interface::cover(const duke_media_handle& hif) const
{
    if(hif.is_builtin_interface())
    {
        return false;
    }

    duke_media_handle_vector hdecls;

    duke_media_interface mif(hif);
    mif.get_declarations(hdecls);
    return stdx::unordered_includes(m_ifc.m_hdecls.begin(), m_ifc.m_hdecls.end(),
                                        hdecls.begin(), hdecls.end());
}

bool duke_media_interface::match(const duke_media_handle& hif) const
{
    if(hif.is_builtin_interface())
    {
        return false;
    }

    duke_media_handle_vector hdecls;
    if (hif.is_builtin_interface())
    {
        duke_media_interface mif(hif);
        mif.get_declarations(hdecls);
    }

    return stdx::unordered_match(m_ifc.m_hdecls.begin(), m_ifc.m_hdecls.end(),
                                 hdecls.begin(), hdecls.end());
}

bool duke_media_interface::get_name(std::string& name) const
{
    duke_media_handle hif = get_handle();

    if (hif.is_builtin_interface())
    {
        return duke_logic_static_interface::get_builtin_name(hif, name);
    }

    return false;
}

bool duke_media_interface::get_icon(std::string& icon) const
{
    icon = m_ifc.m_icon;
    return true;
}

bool duke_media_interface::set_icon(const std::string& icon)
{
    m_ifc.m_icon = icon;
    return true;
}

bool duke_media_interface::get_builtin_instructions(const duke_media_handle& hif)
{
    return duke_logic_interface::get_builtin_instructions(hif, m_ifc.m_hdecls);
}

//bool duke_media_interface::get_singleton() const
//{
//    return this->m_ifc.m_singleton;
//}
//
//bool duke_media_interface::set_singleton(bool singleton)
//{
//    this->m_ifc.m_singleton = singleton;
//    return this->save();
//}
//
//bool duke_media_interface::get_type(duke_media_handle& type) const
//{
//    type = this->m_ifc.m_type;
//    return true;
//}
//
//bool duke_media_interface::set_type(const duke_media_handle& type)
//{
//    this->m_ifc.m_type = type;
//    return this->save();
//}
//bool duke_media_interface::add_declaration(const duke_media_handle& hdecl)
//{
//    bool ret = (hdecl.is_declaration() || hdecl.is_function_instruction());
//    assert(ret);
//    if (ret)
//    {
//        this->m_ifc.m_hdecls.push_back(hdecl);
//        ret = this->save();
//    }
//    return ret;
//}

///bool duke_media_interface::del_declaration(const duke_media_handle& hdecl)
///{
///    bool ret = hdecl.is_declaration();
///    assert(ret);
///    if (ret)
///    {
///        m_ifc.m_hdecls.erase(std::remove(m_ifc.m_hdecls.begin(), m_ifc.m_hdecls.end(), hdecl),
///                             m_ifc.m_hdecls.end());
///        ret = this->save();
///    }
///    return ret;
///}
///
///bool duke_media_interface::set_declarations(const duke_media_handle_vector& hdecls)
///{
///    m_ifc.m_hdecls = hdecls;
///    return this->save();
///}


//bool duke_media_interface::clear_declaration()
//{
//    m_ifc.m_hdecls.clear();
//    duke_object_user::get_builtin_instructions(m_ifc.m_hdecls);
//    return this->save();
//}
//
//bool duke_media_interface::clear()
//{
//    m_ifc.m_hdecls.clear();
//    return this->save();
//}

//bool duke_media_interface::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{        
//    std::string strkey = username + "-interface";
//    std::string strval;
//    assert(this->get_handle().is_interface());
//
//    duke_media_interface infe(host_id);
//    infe.copy(this->get_handle());
//
//    std::string strname;
//    this->get_name(strname);
//    bool ret = duke_media_save_handle_name(infe.get_handle(), strname);
//    assert(ret);
//
//    if (hfather != this->get_handle())
//    {
//        ret = duke_media_write_pair_handle(hfather, this->get_handle(), infe.get_handle());
//        assert(ret);
//    }
//
//    ret  = this->get_handle().get_value(strval);
//    assert(ret);
//    infe.unpack(strval);
//
//    replace_content(username, strval, host_id, hfather);
//
//    infe.unpack(strval);
//
//    infe.pack_new_structure();
//
//    ret = infe.get_handle().set_value(strval);
//    assert(ret);
//
//    duke_media_remove_handle("anonymous-name-tmp-interface", infe.get_handle());
//    duke_media_remove_handle(username + "-tmp-interface", infe.get_handle());
//
//    strval.clear();
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + infe.get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//    handle = infe.get_handle();
//
//    ret = duke_media_write_pair_handle(this->get_handle(), infe.get_handle());
//    assert(ret);
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(infe.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//	    LOG_NOTICE("DEL the " << infe.get_handle().str() << " interface in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//	    LOG_NOTICE("DEL the " << infe.get_handle().str() << " interface in temp media failed;");
//
//    return ret;
//}

//bool duke_media_interface::copy(const duke_media_handle& hifc)
//{
//    bool ret = false;
//    assert(hifc.is_interface());
//    if (hifc.is_builtin_interface())
//    {
//        ret = this->get_builtin_instructions(hifc);
//        this->set_handle(hifc);
//        ret = true;
//    }
//    else
//    {
//        std::string strval;
//        ret = hifc.get_value(strval);
//        assert(ret);
//        this->unpack(strval);
//        ret = this->save();
//        assert(ret);
//    }
//    return ret;
//}

//std::string duke_media_interface::pack() const
//{
//    return m_ifc.pack();
//}

//void duke_media_interface::unpack(const std::string& strif)
//{
//    m_ifc.unpack(strif);
//}




//bool duke_media_interface::save()
//{
//    //{
//    //    //pack new structure
//    //    if_compound_data_t tmp_data;
//    //    tmp_data.name = m_ifc.m_name;
//    //    tmp_data.is_singleton = m_ifc.m_singleton;
//
//    //    for (duke_media_handle_const_iterator it = m_ifc.m_hdecls.begin(); it != m_ifc.m_hdecls.end(); ++it)
//    //    {
//    //        nb_id_t id;
//    //        id.str((*it).str());
//    //        tmp_data.decls.push_back(id);
//    //    }
//
//    //    content tmp_content;
//    //    obj_impl_interface_compound::pack(tmp_data, m_nb_id, tmp_content);
//    //    std::string strval = pack_object(tmp_content);
//
//    //    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//    //}
//    if( e_handle_core != this->get_handle_status )
//    {
//        return get_handle().set_value(this->pack());
//    }
//    else
//    {
//        return false;
//    }
//}

//bool duke_media_interface::set_interface_name(const std::string& name)
//{
//    m_ifc.m_name = name;
//    return this->save();
//}

//bool duke_media_interface::set_name(const std::string& name)
//{
//    m_ifc.m_name = name;
//    bool ret = duke_media_save_handle_name(this->get_handle(), name);
//    assert(ret);
//
//    return this->save();
//}


//bool duke_media_interface::pack_new_structure()
//{
//    //pack new structure
//    if_compound_data_t tmp_data;
//    tmp_data.name = m_ifc.m_name;
//    tmp_data.is_singleton = m_ifc.m_singleton;
//
//    for (duke_media_handle_const_iterator it = m_ifc.m_hdecls.begin(); it != m_ifc.m_hdecls.end(); ++it)
//    {
//        nb_id_t id;
//        id.str((*it).str());
//        tmp_data.decls.push_back(id);
//    }
//
//    content tmp_content;
//    obj_impl_interface_compound::pack(tmp_data, m_nb_id, tmp_content);
//    //db_value tmp_value;
//    //tmp_value.all_objects.push_back(tmp_content);
//    std::string strval = pack_object(tmp_content);
//    
//    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//    return true;
//}
//
//bool duke_media_interface::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    for( std::vector<dukeid_t>::iterator it=m_ifc.m_hdecls.begin(); it!=m_ifc.m_hdecls.end(); ++it)
//    {
//        assert(it->is_declaration());
//        if((it->is_function_instruction()) || (duke_media_get_handle_status(username,*it)==Build))
//        {
//            continue;
//        }
//
//        duke_media_handle hdecl;
//        bool ret = duke_media_read_pair_handle(hfather, *it, hdecl);
//        assert(ret);
//        if (hdecl.is_type_null())
//        {
//            duke_media_compound_declare decl(*it);
//            //assert(decl.copy(*it));
//            decl.generate(username, hdecl, host_id, hfather);
//        }
//        duke_media_replace_handle(strval, *it, hdecl);
//    }
//    if (m_ifc.m_type.get_interface_compound_type() == NB_INTERFACE_ARRAY_TYPE)
//    {    
//        if (duke_media_get_handle_status(username, m_ifc.m_hext[0]) == Edit)
//        {
//            duke_media_handle hnew;
//            bool ret = duke_media_read_pair_handle(hfather, (m_ifc.m_hext[0]), hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_compound_interface ifc(m_ifc.m_hext[0], 1);
//                bool ret = ifc.generate(username, hnew, host_id, hfather);
//                assert(ret);
//                if (hnew.is_type_null())
//                    assert(false);
//            }
//            duke_media_replace_handle(strval, m_ifc.m_hext[0], hnew);
//        }
//    } 
//    else if (m_ifc.m_type.get_interface_compound_type() == NB_INTERFACE_MAP_TYPE)
//    {}
//    return true; 
//}


// vim:set tabstop=4 shiftwidth=4 expandtab:
