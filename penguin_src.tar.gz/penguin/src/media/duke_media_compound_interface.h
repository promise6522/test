#ifndef __DUKE_MEDIA_COMPOUND_INTERFACE_H
#define __DUKE_MEDIA_COMPOUND_INTERFACE_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
//#include "duke_logic_object.h"
#include "duke_media_base.h"
#include "duke_logic_object_data.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "duke_media_declare.h"

class duke_media_compound_interface : public duke_media_base
{
private:
    duke_logic_data_interface_compound   m_data;

    nb_id_t                              id;

public:
    duke_media_compound_interface();
    duke_media_compound_interface(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");
    duke_media_compound_interface(const duke_media_handle& hif, const std::string& username = "anonymous-name");

    //set new data to compound_interface by duke_logic_data_interface_compound,
    //in particular for array map storage
    bool set_data_to_handle(const duke_logic_data_interface_compound& if_data); 

    //get compound_interface data for array, map, and storage
    duke_logic_data_interface_compound get_data_from_handle()  const;


    dukeid_vector& get_hext();
    bool get_expanded();

    bool get_singleton() const;
    
    bool set_singleton(bool singleton);
	
    bool get_icon(std::string& icon) const;
	
    bool set_icon(const std::string& icon);
	
    bool set_interface_name(const std::string& name);
	
    bool add_declaration(const duke_media_handle& hdecl);
    
    bool set_declarations(const std::vector<duke_media_handle>& vhdecls);
    
    bool set_minif(const duke_media_handle& min_if);
	
    bool clear_declaration();
	
    bool del_declaration(const duke_media_handle& hdecl);
    
    bool assign(const duke_media_handle& hif);
    
    bool get_declarations(duke_media_handle_vector& vid) const;
    
    bool get_interfaces(duke_media_handle& vif) const;
    
    bool set_interface(const duke_media_handle& hif);
    
    bool set_type(const duke_media_handle& htype);
    bool clear_type(); 

    bool get_type(duke_media_handle& htype);
    
    // decision function
    bool is_interface_array() const ;
    
    bool is_interface_user() const ;
   
    bool is_interface_map() const ;
    
    bool is_interface_access() const ;

    bool is_interface_storage() const ;

   
    bool set_decl_type(const duke_media_handle& htype);

    bool get_decl_type(duke_media_handle& htype);

    duke_media_handle get_extension_types(int index);
    
    duke_media_handle get_id() const;
    
    virtual bool get_name(std::string& name) const;
    
    virtual bool set_name(const std::string& name);
    
    bool match(const duke_media_handle& hif) const;
    
    bool cover(const duke_media_handle& hif) const;
    
    bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
    //
    //bool replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather, const duke_media_handle& newhandle = 0);

    bool pack_new_structure();
    
    bool copy(const duke_media_handle& hifc);
    
    /// pack & unpack
    virtual std::string pack() const;

    virtual void unpack(const std::string& strif);

    std::string pack_helper() const;

    void unpack_helper(const std::string& strif);
    

    /// for compiler
    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_idx);

    virtual void get_related_handles(duke_media_handle_vector& vHandles);

    virtual bool is_valid();

    bool init_save(DbTxn* txn = NULL);

};

#endif /* __DUKE_MEDIA_COMPOUND_INTERFACE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
