/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/
#include "duke_index_manager.h"

#include "duke_media_base.h"
#include "duke_media_global.h"
#include "duke_media_base_factory.h"

index_manager::index_manager() : index_(0)
{
    //request an index for null handle
    id_index_map_.insert(std::make_pair(NBID_TYPE_NULL, 0));
    index_++;
}


index_manager::~index_manager()
{
}


int index_manager::new_index()
{
    return index_++;
}


int index_manager::get_index_from_handle(const duke_media_handle& h)
{
    // for null handle, return 0
    if (duke_media_handle_null == h)
        return 0;

    int index;
    nb_handle_status st = get_media_handle_status(h);

    if (e_handle_temp == st)
    {
        // check if a same handle has requested an index
        if (handle_index_map_.find(h) != handle_index_map_.end())
            return handle_index_map_[h];
        else
        {
            // request a new_index, save the mapping
            index = new_index();
            handle_index_map_[h] = index;

            // push into the queue for later process
            handles_to_process_.push(h);

            return index;
        }

    }

    if (e_handle_core == st)
    {
        nb_id_t id = h.get_nb_type();

        // check if a same id has requested an index
        if (id_index_map_.find(id) != id_index_map_.end())
            return id_index_map_[id];
        else
        {
            // request a new_index, save the mapping
            index = new_index();
            id_index_map_[id] = index;

            return index;
        }
    }

    else if (e_handle_unknown == st)
    {
        assert(!"get_index_from_handle() from a unkown handle");
    }

    return -1;
}

int index_manager::request_index_for_editor(const duke_media_handle& h, const editor_base_ptr& pEditor)
{
    assert(pEditor.get());

    int index;

    // Use the handle's index if exists
    if (handle_index_map_.find(h) != handle_index_map_.end())
        index = handle_index_map_[h];
    else
    {
        index = new_index();
        handle_index_map_[h] = index;
    }

    // Save the editor ptr
    index_editor_map_.insert(std::make_pair(index, pEditor));

    // Set the editor's index
    pEditor->set_index(index);

    return index;
}

int index_manager::request_index_for_editor(const editor_base_ptr& pEditor)
{
    assert(pEditor.get());

    // Always request a new index
    int index = new_index();
    index_editor_map_.insert(std::make_pair(index, pEditor));

    // Set the editor's index
    pEditor->set_index(index);

    return index;
}


bool index_manager::get_index_info(index_info_t& info)
{
    // recursive search related handles & ids
    if (!check_related_handles())
        return false;

    // get the index-id map
    // (simply revert the id_index_map)
    for(std::map<nb_id_t, int>::const_iterator it = id_index_map_.begin();
            it != id_index_map_.end();
            ++it)
    {
        // make sure no two ids use the same index
        if (!info.idx_id_map.insert(std::make_pair(it->second, it->first)).second)
            LOG_ERROR("index_manager::get_index_info() error: two nb_id_t has the same index");
    }

    // get the index-editor map
    info.idx_xml_map = index_editor_map_;

    // dump the info for debug
    dump_index_id_map(info.idx_id_map);
    dump_index_editor_map(info.idx_xml_map);

    return true;
}


bool index_manager::check_related_handles()
{
    // A set to avoid repeative search
    std::set<duke_media_handle> processed_set;

    // handles_to_process_ may be exapnded during the process,
    // so we use a queue structure to avoid conflicts
    while (!handles_to_process_.empty())
    {
        duke_media_handle h = handles_to_process_.front();
        handles_to_process_.pop();

        // Already assigned an index to the handle
        assert(handle_index_map_.find(h) != handle_index_map_.end());
        int index = handle_index_map_[h];

        // Built the xml struct if has not been built
        if (index_editor_map_.find(index) == index_editor_map_.end())
        {
            duke_media_base_ptr pMedia = duke_media_base_factory::get_media_from_handle(h);

            int main_index;
            editor_base_ptr pXml = pMedia->to_xml_struct(*this, main_index);
            if(pXml.get() == NULL)
            {
                std::string name;
                duke_media_get_name(h, name);
                LOG_ERROR("index_manager : " << h.str() << " [" << name << "] validation failed.");
                LOG_ERROR("index = " << index);
                return false;
            }

            index_editor_map_.insert(std::make_pair(index, pXml));
        }

    }

    return true;
}


// Print debug info
void index_manager::dump_index_editor_map(const std::map<int, editor_base_ptr>& idx_editor_map) const
{
    // init the editor name table
    std::map<editor_type_t, std::string> name_table;
    name_table[e_StringValue_editor] = "string";
    name_table[e_UserContainerDefinition_editor] = "container";
    name_table[e_MapValue_editor] = "map";
    name_table[e_BytesValue_editor] = "bytes";
    name_table[e_ObjectFunctionExecutable_editor] = "obj_func";
    name_table[e_UserObject_editor] = "user_obj";
    name_table[e_ExpandedInterface_editor] = "expanded_if";
    name_table[e_ExpandedDeclaration_editor] = "expanded_decl";
    name_table[e_UserInterface_editor] = "compound_if";
    name_table[e_ArrayValue_editor] = "array";
    name_table[e_Declaration_editor] = "compound_decl";
    name_table[e_ConditionalExcutable_editor] = "exec_condition";
    name_table[e_StorageFunctionExecutable_editor] = "storage_func";
    name_table[e_Implementation_editor] = "implement";
    name_table[e_IterativeExcutable_editor] = "exec_iterator";
    name_table[e_UserAccess_editor] = "access";

    //
    LOG_DEBUG("#### Dump index_editor_map ####");
    for(index_editor_map_const_itr it = idx_editor_map.begin();
            it != idx_editor_map.end(); ++it)
    {
        LOG_DEBUG("Editor index : "<< it->first << " , Type = " << name_table[it->second->get_editor_type()]);
    }
    LOG_DEBUG("#### Dump index_editor_map End ####");
}

// Print debug info
void index_manager::dump_index_id_map(const std::map<int, nb_id_t>& idx_id_map) const
{
    LOG_DEBUG("#### Dump index_id_map ####");
    for(index_id_map_const_itr it = idx_id_map.begin();
            it != idx_id_map.end(); ++it)
    {
        LOG_DEBUG("nb_id_t = "<<it->second.str() << " , index = "<< it->first);
    }
    LOG_DEBUG("#### Dump index_id_map End ####");
}
