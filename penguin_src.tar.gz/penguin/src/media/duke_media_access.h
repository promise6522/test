#ifndef __DUKE_MEDIA_ACCESS_H
#define __DUKE_MEDIA_ACCESS_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
#include "duke_media_base.h"
#include "ac_container/access_implementation.h"
#include "duke_media_interface.h"

//
//{(name_handle)(icon_handle)}
//{(hdecl)...(hdecl)}
//{(isregisteraccess)}
//{(hcontainer)}
//

class duke_media_access : public duke_media_base
{
private:
    duke_logic_data_access m_data;
    duke_media_handle m_access_if;

    access_data_t data_t;
    nb_id_t access_id;

    host_committer_id_t hc_id;

public:
    duke_media_access(const host_committer_id_t& host_id, const std::string& username = "anonymous-name") : duke_media_base(DUKE_MEDIA_TYPE_ACCESS, host_id), hc_id(host_id)
    {
        bool ret = this->save();
        assert(ret);
    }

    duke_media_access(const duke_media_handle& haccess, const std::string& username = "anonymous-name") 
    {
        bool ret = this->assign(haccess);
        assert(ret);
    }

    //duke_media_access(const duke_media_handle& haccess, const std::string& username = "anonymous-name", const host_committer_id_t& host_id = 0) : hc_id(host_id)
    //{
    //    std::string strval;
    //    duke_media_read_handle(haccess.str(), strval);
    //    if (strval == ("Temp"))
    //    {
    //        bool ret = this->assign(haccess);
    //        assert(ret);
    //    }
    //    else
    //    {
    //        if (strval.empty())
    //        {
    //            ac_object_db_impl::instance().read_(haccess.str(), strval);

    //            if(!strval.empty())
    //            {
    //                content value;
    //                unpack_object(strval, value);

    //                access_implementation::unpack(value, data_t);

    //                m_data.m_name = data_t.name;
    //                m_data.anchor_index = data_t.anchor_idx;

    //                //m_data.m_hcontainer = data_t.parent_container;
    //                memcpy(&m_data.m_hcontainer, &data_t.parent_container, 32);

    //                duke_media_compound_interface ifc(data_t.interface);
    //                duke_media_handle_vector vdecls;
    //                ifc.get_declarations(vdecls);

    //                m_data.m_hdecls = vdecls;

    //                m_data.m_registered = data_t.is_registed;
    //            }
    //            else
    //            {
    //                assert(this->assign(haccess));
    //            }
    //        }
    //        this->set_handle(haccess);
    //    }
    //}

    //duke_media_access(const std::string& username, const duke_media_handle& handle, const content& raw_data,
    //                  const std::string& name)
    //{
    //    std::string strkey = username + "-access";
    //    std::string strif, strval;
    //    content vif;
    //    access_implementation::unpack(raw_data, data_t);
    //    m_data.m_name = name;
    //    m_data.anchor_index = data_t.anchor_idx;
    //    m_data.m_hcontainer = data_t.parent_container;
    //    m_data.m_registered = data_t.is_registed;

    //    if (data_t.interface.is_object_interface_compound())
    //    {
    //        ac_object_db_impl::instance().read_(data_t.interface.str(), strif);
    //        unpack_object(strif, vif);

    //        nb_id_t if_id;
    //        if_compound_data_t if_data;        
    //        obj_impl_interface_compound::unpack(vif, if_id, if_data);

    //        // fill the funcs
    //        for (nb_id_vector_const_it it = if_data.decls.begin(); it != if_data.decls.end(); ++it)
    //        {
    //            m_data.m_hdecls.push_back(duke_media_handle(it->str()));
    //        }
    //    }

    //    this->set_handle(handle);
    //    
    //    this->get_handle().set_value(this->pack());

    //    duke_media_remove_handle("anonymous-name-tmp-object", this->get_handle());
    //    duke_media_remove_handle(username + "-tmp-object", this->get_handle());

    //    strval = "";
    //    bool ret = duke_media_read_handle(strkey, strval);
    //    strval += "(" + this->get_handle().str() + ")";
    //    ret = duke_media_write_handle(strkey, strval);
    //    assert(ret);

    //    unsigned int iret = duke_media_tempobj_db::instance().del(this->get_handle().str());
    //    if (iret == NB_DB_RESULT_NOTFOUND)
    //        LOG_NOTICE("DEL the " << this->get_handle().str() << " access in temp media not found;");
    //    else if (iret == NB_DB_RESULT_FAILED)
    //        LOG_NOTICE("DEL the " << this->get_handle().str() << " access in temp media failed;");
    //}

    bool assign(const duke_media_handle& haccess)
    {
        if (!haccess.is_access())
        {
            return false;
        }

        std::string value;
        this->set_handle_status( haccess.get_value(value) );

        if(!value.empty())
        {
            this->unpack_helper(value);
        }
        else
        {
            LOG_DEBUG("this access " << haccess.str() << " has no data! Maybe in edit init period.");
        }

        //unpack data and set handle to this object
        this->set_handle(haccess);

        return true;
    }

    bool copy(const duke_media_handle& haccess)
    {
        if (!haccess.is_access())
        {
            return false;
        }
        
        //get value
        std::string strval;
        haccess.get_value(strval);
        
        //unpack data
        this->unpack(strval);

        if (this->is_singleton_object())
            return false;

        //save data to handle
        bool ret = this->save();
        return ret;
    }

    bool set_name(const std::string& name)
    {
        m_data.m_name = name;
        bool ret = duke_media_save_handle_name(this->get_handle(), name);
        assert(ret);
        return this->save();
    }

    bool get_name(std::string& name) const
    {
        name = m_data.m_name;
        return true;
    }

    bool set_icon(const std::string& icon)
    {
        m_data.m_icon = icon;
        return this->save();
    }

    bool get_icon(std::string& icon) const
    {
        icon = m_data.m_icon;
        return true;
    }

    bool set_anchor_idx(int index)
    {
        m_data.anchor_index = index;
        return this->save();
    }

    int get_anchor_idx() const
    {
        return m_data.anchor_index;
    }


    bool clear()
    {
        m_data.m_hdecls.clear();
        return this->save();
    }

    bool add_declarations(const duke_media_handle_vector& vdecl)
    {
        m_data.m_hdecls = vdecl;
        return this->save();
    }

    bool add_declaration(const duke_media_handle& hdecl)
    {
        assert(hdecl.is_declaration());
        m_data.m_hdecls.push_back(hdecl);
        return this->save();
    }

    bool del_declaration(const duke_media_handle& hdecl)
    {
        assert(hdecl.is_declaration());
        duke_media_handle_iterator it;
        if ((it = std::find(m_data.m_hdecls.begin(), m_data.m_hdecls.end(), hdecl)) != m_data.m_hdecls.end()) 
        {
            m_data.m_hdecls.erase(it);
            return this->save();
        }
        return true;
    }

    bool find_declaration(const duke_media_handle& hdecl)
    {
        return (std::find(m_data.m_hdecls.begin(), m_data.m_hdecls.end(), hdecl) != m_data.m_hdecls.end());
    }

    bool add_declaration(const duke_media_handle_vector& vdecl)
    {
        m_data.m_hdecls = vdecl;
        return this->save();
    }

    void get_declaration(duke_media_handle_vector& vdecl) const
    {
        vdecl = m_data.m_hdecls;
    }

    bool get_interface(duke_media_handle& hif)
    {
        if(duke_media_handle_null != m_access_if)
        {
            hif = m_access_if;
            return true;
        }

        if (m_data.m_hdecls.size() == 0)
        {
            //duke_logic_static_root_access::get_builtin_instructions(m_data.m_hdecls);
            hif = duke_media_handle(NB_INTERFACE_ROOT_ACCESS);
        }
        else
        {
            duke_media_compound_interface mif(hc_id);
            for(duke_media_handle_const_iterator it = m_data.m_hdecls.begin();
                    it != m_data.m_hdecls.end(); ++it)
            {
                mif.add_declaration(*it);
            }
            //mif.set_decl_type(NB_INTERFACE_ACCESS);

            // for interface name
            std::string name;
            this->get_name(name);
            name += " interface";
            mif.set_name(name);
            hif = mif.get_handle();
        }
        return true;        
    }

    bool set_isregisteraccess(bool iflag)
    {
        m_data.m_registered = iflag;
        return this->save();
    }

    bool get_isregisteraccess() const
    {
        return m_data.m_registered;
    }

    bool is_singleton_object() const
    {
        return m_data.m_registered;
    }

    bool set_container(const duke_media_handle& hcontainer)
    {
        assert(hcontainer.is_object_container_des());
        m_data.m_hcontainer = hcontainer;
        return this->save();
    }

    void get_container(duke_media_handle& hcontainer) const
    {
        hcontainer = this->m_data.m_hcontainer;
    }

    //bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0)
    //{
    //    std::string strkey = username + "-access";
    //    std::string strval;
    //    assert(this->get_handle().is_access());

    //    duke_media_remove_handle("anonymous-name-tmp-access", this->get_handle());
    //    duke_media_remove_handle(username + "-tmp-access", this->get_handle());
    //    
    //    std::string strname;
    //    this->get_name(strname);
    //    bool ret = duke_media_save_handle_name(this->get_handle(), strname);
    //    assert(ret);

    //    this->get_handle().get_value(strval);
    //    this->get_handle().set_value(strval);

    //    unsigned int iret = duke_media_tempobj_db::instance().del(this->get_handle().str());
    //    if (iret == NB_DB_RESULT_NOTFOUND)
    //        LOG_NOTICE("DEL the " << this->get_handle().str() << " access in temp media not found;");
    //    else if (iret == NB_DB_RESULT_FAILED)
    //        LOG_NOTICE("DEL the " << this->get_handle().str() << " access in temp media failed;");

    //    std::string strkey1 = username + "-login-name";
    //    ret = duke_media_write_handle(strkey1, get_handle().str());
    //    assert(ret);

    //    strval = "";
    //    ret = duke_media_read_handle(strkey, strval);
    //    strval += "(" + this->get_handle().str() + ")";
    //    ret = duke_media_write_handle(strkey, strval);
    //    assert(ret);
    //    handle = this->get_handle();

    //    // fill to new structure
    //    access_data_t tmp_data;
    //    tmp_data.name = m_data.m_name;
    //    tmp_data.anchor_idx = m_data.anchor_index; //TODO:anchor_index;
    //    tmp_data.is_outgoing = false;

    //    memcpy(&tmp_data.parent_container, &(m_data.m_hcontainer), 32);
    //    tmp_data.is_registed = m_data.m_registered;

    //    duke_media_compound_interface ifc(hc_id);
    //    duke_media_handle ifc_type(NB_INTERFACE_ACCESS);
    //    ifc.set_decl_type(ifc_type);
    //    ifc.set_declarations(m_data.m_hdecls); 
    //    ifc.pack_new_structure();
    //    //duke_media_handle new_ifc;
    //    //ifc.generate(username, new_ifc);
    //    tmp_data.interface.str(ifc.get_handle().str());

    //    content tmp_content;
    //    access_implementation::pack(tmp_data, tmp_content);
    //    //db_value tmp_value;
    //    //tmp_value.all_objects.push_back(tmp_content);
    //    strval = pack_object(tmp_content);

    //    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
    //    //////////////////
    //    LOG_INFO("duke_media_access::generate:access handle :"<<this->get_handle().str());
    //    LOG_INFO("duke_media_access::generate:if handle :"<<tmp_data.interface.str());

    //    return ret;
    //}

public:
    //bool save()
    //{
    //    {
    //        // fill to new structure
    //        access_data_t tmp_data;
    //        tmp_data.name = m_data.m_name;
    //        tmp_data.anchor_idx = m_data.anchor_index; //TODO:anchor_index;

    //        memcpy(&tmp_data.parent_container, &(m_data.m_hcontainer), 32);
    //        tmp_data.is_registed = m_data.m_registered;

    //        duke_media_compound_interface ifc(hc_id);
    //        duke_media_handle ifc_type(NB_INTERFACE_ACCESS);
    //        ifc.set_type(ifc_type);
    //        ifc.set_declarations(m_data.m_hdecls); 

    //        //duke_media_handle new_ifc;
    //        //ifc.generate(username, new_ifc);
    //        tmp_data.interface.str(ifc.get_handle().str());

    //        content tmp_content;
    //        access_implementation::pack(tmp_data, tmp_content);
    //        //db_value tmp_value;
    //        //tmp_value.all_objects.push_back(tmp_content);
    //        std::string strval = pack_object(tmp_content);

    //        ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
    //    }
    //    return this->get_handle().set_value(this->pack());
    //}

    virtual std::string pack() const
    {
        return pack_helper();
    }

    std::string pack_helper() const
    {
        return m_data.pack();
    }

    virtual void unpack(const std::string& strval)
    {
        m_data.unpack(strval);
    }

    void unpack_helper(const std::string& strval)
    {
        //do different thing by handle status
        nb_handle_status  status;
        status = this->get_handle_status();

        if (status == e_handle_temp || status == e_handle_formal)
        {
            m_data.unpack(strval);
        }
        else if (status == e_handle_core)
        {
            if (!strval.empty())
            {
                content value;
                unpack_object(strval, value);
                
                access_implementation::unpack(value, data_t);
                
                m_data.m_name = data_t.name;
                m_data.anchor_index = data_t.anchor_idx;
                m_data.m_hcontainer = data_t.parent_container;
                
                duke_media_handle_vector vdecls;
                if(data_t.interface.is_interface_root_access())
                {
                    duke_media_interface ifc(data_t.interface);
                    ifc.get_declarations(vdecls);
                    m_access_if = ifc.get_handle();
                }
                else
                {
                    duke_media_compound_interface ifc(data_t.interface);
                    ifc.get_declarations(vdecls);
                    m_access_if = ifc.get_handle();
                }

                
                m_data.m_hdecls = vdecls;
                
                m_data.m_registered = data_t.is_registed;
            }
        }
        else
        {
            LOG_ERROR("access handle: " << this->get_handle().str() << " has not exist in db");
        }
    }

};

#endif /* __DUKE_MEDIA_ACCESS_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
