#ifndef __DUKE_MEDIA_ANCHOR_H
#define __DUKE_MEDIA_ANCHOR_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
#include "duke_media_base.h"
#include "ac_container/anchor_implementation.h"
#include "duke_media_access.h"
#include "duke_media_container.h"
#include "duke_media_compound_interface.h"

class duke_media_anchor : public duke_media_base
{
private:
    duke_logic_data_anchor m_anchor;
   
    host_committer_id_t hc_id;
    nb_id_t ifc_id;

public:
    duke_media_anchor();
    duke_media_anchor(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");

    duke_media_anchor(const duke_media_handle& hanchor, const std::string& username = "anonymous-name");


    bool assign(const duke_media_handle& hanchor);
    bool copy(const duke_media_handle& hanchor);
    bool set_name(const std::string& name);

    bool get_name(std::string& name) const;

    bool set_icon(const std::string& icon);
    bool get_icon(std::string& icon) const;
    bool set_index(int index);
    int get_index() const;

    bool clear();
    void get_hcontainer(duke_media_handle& handle) const;
    bool set_hcontainer(const duke_media_handle& handle);
    bool add_declaration(const duke_media_handle& hdecl, const enum decl_status& status, int index = 0);
    bool del_declaration(const duke_media_handle& hdecl, const enum decl_status& status);

    bool find_declaration(const duke_media_handle& hdecl);
    bool find_exdeclaration(const duke_media_handle& hdecl);
    bool add_declaration(const duke_media_handle_vector& vdecl, const enum decl_status& status);
    void get_declaration(duke_media_handle_vector& vdecl, const enum decl_status& status) const;

    bool get_interface(duke_media_handle& handle, const host_committer_id_t& host_id = 0) const;
    void set_type_index(int index);
    //bool create_access(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const std::string& accessName = "access", const duke_media_handle& hfather = 0);

    //bool replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather = 0);

    bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
    //bool pack_new_structure(const std::string& username, const host_committer_id_t& host_id, const nb_id_t& old_cid);

public:
    virtual std::string pack() const;
    std::string pack_helper() const;

    virtual void unpack(const std::string& strval);
    void unpack_helper(const std::string& strval);
};

#endif /* __DUKE_MEDIA_ANCHOR_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
