#include "duke_media_compound_declare.h"
#include "stdx_string.h"
#include "duke_logic_object_static.h"
#include "duke_media_declare_expanded.h"
#include "duke_media_global.h"


//initialization staitc member
table duke_media_compound_declare::ifTable;

duke_media_compound_declare::duke_media_compound_declare()
{
}

// for compose & decompose
duke_media_compound_declare::duke_media_compound_declare(const host_committer_id_t& host_id,
        duke_media_type type, 
        const std::string& username ) 
        : duke_media_base(type, host_id), 
        hc_id(host_id)
{
    bool ret = init_save();
    assert(ret);
}

// generate a new handle of duke_media_compound_declare
duke_media_compound_declare::duke_media_compound_declare(const host_committer_id_t& host_id, 
        const std::string& username)
        : duke_media_base(DUKE_MEDIA_TYPE_FUNCTION_DECLARE, host_id), 
        hc_id(host_id)
{
    // the default port
    add_input_port(duke_media_handle(NB_INTERFACE_NONE));

    bool ret = init_save();
    assert(ret);
}

duke_media_compound_declare::duke_media_compound_declare(const duke_media_handle& hdecl, 
        const std::string& username)
{
    assert(hdecl.is_object_decl_compound());

    bool ret = this->assign(hdecl);
    assert(ret);
}

bool duke_media_compound_declare::assign(const duke_media_handle& hdecl)
{
    assert(hdecl.is_object_decl_compound());
    if (!hdecl.is_object_decl_compound())
    {
        return false;
    }

    std::string value;
    this->set_handle_status( hdecl.get_value(value) );

    if(!value.empty())
    {
        this->unpack(value);
    }
    else
    {
        LOG_DEBUG("this compound declare " << hdecl.str() << " has no data! Maybe in edit init period.");
    }

    //unpack data and set handle to this object
    this->set_handle(hdecl);

    return true;
}

duke_media_handle duke_media_compound_declare::get_id() const
{
    return get_handle();
}

bool duke_media_compound_declare::set_array_content(const std::string& name, 
        const duke_media_handle& hif, 
        DbTxn* txn)
{
    m_data.name = name;
    this->set_template_type(dukeid_vector(1, hif));

    this->template_instantiation();

    return this->save(txn);
}

bool duke_media_compound_declare::set_map_content(const std::string& name, 
        const dukeid_vector& vif, 
        DbTxn* txn)
{
    assert(vif.size() == 2);

    m_data.name = name;
    this->set_template_type(vif);

    this->template_instantiation();

    return this->save(txn);
}

bool duke_media_compound_declare::set_storage_content(const std::string& name,  
        const dukeid_vector& ifctype, 
        DbTxn* txn)
{
    assert(2 == ifctype.size());

    m_data.name = name;
    this->set_template_type(ifctype);

    this->template_instantiation();

    return this->save(txn);
}

bool duke_media_compound_declare::set_name(const std::string& name)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.name = name;
    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);
    return this->save();
}

bool duke_media_compound_declare::get_name(std::string& name) const
{
    name = m_data.name;
    return true;
}

bool duke_media_compound_declare::get_icon(std::string& icon) const
{
    icon = m_data.m_icon;
    return true;
}

bool duke_media_compound_declare::set_icon(const std::string& icon)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.m_icon = icon;
    return this->save();
}

bool duke_media_compound_declare::get_interfaces(duke_media_handle_vector& hiifs,
        duke_media_handle_vector& hoifs) const
{
    for(std::size_t i = 0; i < m_data.iports.size(); ++i)
    {
        hiifs.push_back(m_data.iports.at(i).interface);
    }

    for(std::size_t i = 0; i < m_data.oports.size(); ++i)
    {
        hoifs.push_back(m_data.oports.at(i).interface);
    }
    return true;
}

bool duke_media_compound_declare::set_interfaces(const duke_media_handle_vector& hiifs,
            const duke_media_handle_vector& hoifs)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.iports.clear();
    m_data.oports.clear();

    for (duke_media_handle_const_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
    {
        duke_logic_data_declare_compound::m_iport_t tmp;
        tmp.name = "";
        tmp.interface.str(it->str());
        //tmp.default_value.str();
        m_data.iports.push_back(tmp);
    }
    for (duke_media_handle_const_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
    {
        duke_logic_data_declare_compound::m_oport_t tmp;
        tmp.name = "";
        tmp.interface.str(it->str());
        //tmp.default_value.str();
        m_data.oports.push_back(tmp);
    }
    return this->save();
}


dukeid_t duke_media_compound_declare::get_port_interface(int index, bool is_input) const
{
    if(is_input)
    {
        return m_data.iports.at(index).interface;
    }
    else
    {
        return m_data.oports.at(index).interface;
    }
    //return dukeid_t();
}

int duke_media_compound_declare::get_iport_number() const
{
    return this->m_data.iports.size();
}

int duke_media_compound_declare::get_oport_number() const
{
    return this->m_data.oports.size();
}

bool duke_media_compound_declare::add_input_port(const duke_media_handle& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hif.is_interface());
    duke_logic_data_declare_compound::m_iport_t tmp_iport;
    tmp_iport.interface = hif;
    m_data.iports.push_back(tmp_iport);
    return this->save();
}

bool duke_media_compound_declare::del_input_port(const int& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.iports.erase(m_data.iports.begin() + hif);
    return this->save();
}

bool duke_media_compound_declare::add_output_port(const duke_media_handle& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hif.is_interface());
    duke_logic_data_declare_compound::m_oport_t tmp_oport;
    tmp_oport.interface = hif;
    m_data.oports.push_back(tmp_oport);

    return this->save();
}

bool duke_media_compound_declare::del_output_port(const int& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.oports.erase(m_data.oports.begin() + hif);
    return this->save();
}

bool duke_media_compound_declare::clear_input_ports()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.iports.clear();
    return this->save();
}

bool duke_media_compound_declare::clear_output_ports()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.oports.clear();
    return this->save();
}

bool duke_media_compound_declare::set_template_type(const dukeid_vector& inf)
{
    assert(inf.size() == m_data.groups.size());
    //if ((inf.size() == 1) && inf.back().is_type_null())
    //    return true;
    for(std::size_t i  = 0; i < m_data.groups.size(); ++i)
    {
        assert(inf.at(i).is_interface());
        m_data.groups.at(i).min_if = inf.at(i);
    }
    this->template_instantiation();
    return true;
}

bool duke_media_compound_declare::get_template_type(dukeid_vector& inf) const
{
    for(std::size_t i = 0; i < m_data.groups.size(); ++i)
    {
        inf.push_back(m_data.groups.at(i).min_if);
    }
    return true;
}

//bool duke_media_compound_declare::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    bool ret = false;
//    dukeid_vector iport_if;
//    dukeid_vector oport_if;
//
//    this->get_interfaces(iport_if, oport_if);
//
//    for(std::size_t i = 0; i < m_data.groups.size(); ++i)
//    {
//        if (m_data.groups[i].min_if.is_interface_compound())
//        {
//            if (duke_media_get_handle_status(username, m_data.groups[i].min_if) != Build)
//            {
//                duke_media_handle hnew;
//                ret = duke_media_read_pair_handle(hfather, m_data.groups[i].min_if, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface ifc(m_data.groups[i].min_if);
//                    if (!ifc.generate(username, hnew, host_id, hfather))
//                        assert(false);
//                }
//                ret = duke_media_replace_handle(strval, m_data.groups[i].min_if, hnew);
//                assert(ret);
//            }
//        }
//    }
//
//    duke_media_handle_const_iterator it;
//
//    for(it = iport_if.begin(); it != iport_if.end(); ++it)
//    {
//        if ((*it).is_interface_compound())
//        {
//            if (duke_media_get_handle_status(username, *it) != Build)
//            {
//                duke_media_handle hnew;
//                ret = duke_media_read_pair_handle(hfather, *it, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface ifc(*it);
//                    if (!ifc.generate(username, hnew, host_id, hfather))
//                        assert(false);
//                }
//                ret = duke_media_replace_handle(strval, *it, hnew);
//                assert(ret);
//            }
//        }
//    }
//
//    for(it = oport_if.begin(); it != oport_if.end(); ++it)
//    {
//        if ((*it).is_interface_compound())
//        {
//            if (duke_media_get_handle_status(username, *it) != Build)
//            {
//                duke_media_handle hnew;
//                ret = duke_media_read_pair_handle(hfather, *it, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface ifc(*it);
//                    if (!ifc.generate(username, hnew, host_id, hfather))
//                        assert(false);
//                }
//                ret = duke_media_replace_handle(strval, *it, hnew);
//                assert(ret);
//            }
//        }
//    }
//    return ret;
//}

//bool duke_media_compound_declare::pack_new_structure()
//{
//    std::string strname;
//    this->get_name(strname);
//
//    decl_compound_data_t tmp_data;
//    tmp_data.name = strname;
//
//    for (iport_ite it = m_data.iports.begin(); it != m_data.iports.end(); ++it)
//    {
//        iport_t tmp;
//        tmp.name = it->name;
//        tmp.interface.str(it->interface.str());
//        tmp.default_value.str(it->default_value.str());
//        tmp_data.iports.push_back(tmp);        
//    }
//
//    for (oport_ite it = m_data.oports.begin(); it != m_data.oports.end(); ++it)
//    {
//        oport_t tmp;
//        tmp.name = it->name;
//        tmp.interface.str(it->interface.str());
//        tmp_data.oports.push_back(tmp);        
//    }
//
//    for(group_ite it = m_data.groups.begin(); it != m_data.groups.end(); ++it)
//    {
//        decl_exp_group tmp;
//        tmp.name = it->name;
//        tmp.min_if.str(it->min_if.str());
//        for(decl_exp_ite ite = it->members.begin(); ite != it->members.end(); ++ite)
//        {
//            decl_exp_idx decl_data;
//            memcpy(&decl_data, &(*ite), sizeof(decl_data));
//            tmp.members.push_back(decl_data);
//        }
//        tmp.expanded = it->expanded;
//        tmp_data.groups.push_back(tmp);
//    }
//
//    obj_id.str(this->get_handle().str());
//
//    content tmp_content;
//    obj_impl_decl_compound::pack(tmp_data, obj_id, tmp_content);
//
//    std::string strval = pack_object(tmp_content);
//
//    //write the strval to db
//    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//    return true;
//}

bool duke_media_compound_declare::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{       
//    bool ret = duke_media_clear_pair_handle(this->get_handle());
//    assert(ret);
//
//    std::string strkey = username + "-declaration-compound";
//    std::string strval;
//    assert(this->get_handle().is_declaration_compound());
//
//    if (this->get_handle().is_function_compose())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_COMPOSE);
//        handle = decl.get_handle();
//    }
//    else if (this->get_handle().is_function_decompose())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE);
//        handle = decl.get_handle();
//    }
//    else if (this->get_handle().is_function_get_anchors())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_GET_ANCHORS);
//        handle = decl.get_handle();
//    }
//    else if (this->get_handle().is_function_get_storages())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_GET_STORAGES);
//        handle = decl.get_handle();
//    }
//    else
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_DECLARE);
//        handle = decl.get_handle();
//    }
//
//    duke_media_compound_declare decl(handle);
//    //decl.copy(this->get_handle());
//
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(decl.get_handle(), strname);
//    assert(ret);
//
//    // add replace handle
//    if (!hfather.is_type_null() && (hfather != this->get_handle()))
//    {
//        ret = duke_media_write_pair_handle(hfather, this->get_handle(), decl.get_handle());
//        assert(ret);
//    }
//    else
//    {
//        assert(duke_media_write_pair_handle(this->get_handle(), decl.get_handle()));
//    }
//
//    //replace id
//    ret = this->get_handle().get_value(strval);
//    assert(ret);
//    replace_content(username, strval, host_id, hfather);
//    decl.unpack(strval);
//    ret = decl.get_handle().set_value(strval);
//    assert(ret);
//    decl.pack_new_structure();
//
//    duke_media_remove_handle("anonymous-name-tmp-compound-declaration", decl.get_handle());
//    duke_media_remove_handle(username + "-tmp-compound-declaration", decl.get_handle());
//
//    if (handle.is_function_compose() || handle.is_function_decompose() || handle.is_function_get_anchors() || handle.is_function_get_storages());
//    else
//    {
//        strval = "";
//        ret = duke_media_read_handle(strkey, strval);
//        strval += "(" + decl.get_handle().str() + ")";
//        assert(duke_media_write_handle(strkey, strval));
//    }
//
//    //handle = decl.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(decl.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << decl.get_handle().str() << " declare compound in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << decl.get_handle().str() << " declare compound in temp media failed;");
//
//    return ret;
    return true;
}

bool duke_media_compound_declare::copy(const duke_media_handle& hdecl)
{
    std::string strval;
    nb_handle_status st = hdecl.get_value(strval);

    switch(st)
    {
        case e_handle_temp:
        case e_handle_formal:
            unpack(strval);
            break;
        case e_handle_core:
            unpack_from_core_data(strval);
            break;
        default:
            assert(!"copy from empty handle");
    }

    return this->save();
}

//virutal
std::string duke_media_compound_declare::pack() const
{
    return pack_helper();
}

std::string duke_media_compound_declare::pack_helper() const
{
    return m_data.pack();
}

//virtual
void duke_media_compound_declare::unpack(const std::string& strval)
{
    unpack_helper(strval);
}

void duke_media_compound_declare::unpack_helper(const std::string& strval)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_data.unpack(strval);
    }
    else if (status == e_handle_core)
    {
        this->unpack_from_core_data(strval);
    }
}

void duke_media_compound_declare::unpack_from_core_data(const std::string& strval)
{
    assert(!strval.empty());
    if (strval.empty())
        return;

    decl_compound_data_t  tmp_data;
    content con;
    unpack_object(strval, con);

    nb_id_t decl_id;
    obj_impl_decl_compound::unpack(con, decl_id, tmp_data);

    m_data.name = tmp_data.name;
    m_data.iports.clear();            
    for (std::vector<iport_t>::iterator it = tmp_data.iports.begin(); it != tmp_data.iports.end(); ++it)
    {
        duke_logic_data_declare_compound::m_iport_t tmp;
        tmp.name = it->name;
        tmp.interface.str(it->interface.str());
        tmp.default_value.str(it->default_value.str());
        m_data.iports.push_back(tmp);        
    }

    m_data.oports.clear();
    for (std::vector<oport_t>::iterator it = tmp_data.oports.begin(); it != tmp_data.oports.end(); ++it)
    {
        duke_logic_data_declare_compound::m_oport_t tmp;
        tmp.name = it->name;
        tmp.interface.str(it->interface.str());
        m_data.oports.push_back(tmp);        
    }

    m_data.groups.clear();            
    for(std::vector<decl_exp_group>::iterator it = tmp_data.groups.begin(); it != tmp_data.groups.end(); ++it)
    {
        duke_logic_data_declare_compound::m_decl_exp_group tmp;
        tmp.name = it->name;
        tmp.min_if.str(it->min_if.str());
        for(std::vector<decl_exp_idx>::iterator ite = it->members.begin(); ite != it->members.end(); ++ite)
        {
            duke_logic_data_declare_compound::m_decl_exp_idx decl_data;
            memcpy(&decl_data, &(*ite), sizeof(decl_data));
            tmp.members.push_back(decl_data);
        }
        tmp.expanded = it->expanded;
        m_data.groups.push_back(tmp);
    }
}

bool duke_media_compound_declare::set_func_type(const std::string& name)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_data.name = name;
    return this->save();
}

bool duke_media_compound_declare::get_func_type(std::string& func_type) const
{
    func_type = m_data.name;
    return true;
}

bool duke_media_compound_declare::set_decl_in_cif(const host_committer_id_t& host_id, duke_logic_data_interface_compound& ifData,  DbTxn* txn)
{
    for(std::size_t i = 0; i < ifData.m_decls.size(); ++i)
    {
        std::string name;
        duke_logic_static_declaration::get_builtin_name(ifData.m_decls[i].get_func_type(), name);

        duke_media_declare_expanded  expand_decl(hc_id);
        expand_decl.set_name(name);
        expand_decl.set_expanded_type(ifData.m_decls[i], ifData.m_hext);

        //decl_expanded_data_t  cData;
        //cData.name = name;
        //cData.origin_decl_id.str(ifData.m_decls[i].str());
        //for(std::size_t j = 0; j < ifData.m_hext.size(); ++j)
        //{
        //    cData.expanded_ifs.push_back(nb_id_t(ifData.m_hext.at(j).str()));
        //}

        //int flag = 0;
        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, expand_decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write(expand_decl.get_handle().get_nb_type().str(), pack_object(tmp_content), txn, flag);
        ifData.m_decls[i] = expand_decl.get_handle();
    }
    return true;
}

bool duke_media_compound_declare::find_complex_port(mStrVid& vec)
{
    for(std::size_t i = 0; i < m_data.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < m_data.groups[i].members.size(); ++j)
        {
            if(-1 != m_data.groups[i].members[j].relay_idx)
            {
                std::string strval = (m_data.groups[i].members[j].is_input ? "input" : "ouput") + 
                    to_string(m_data.groups[i].members[j].port_idx);
                mStrVid_ite ite = vec.find(strval);

                if(ite != vec.end())
                {
                    ite->second.push_back(m_data.groups[i].min_if);
                }
                else
                {
                    std::vector<dukeid_t> vId;
                    vId.push_back(m_data.groups[i].min_if);
                    vec.insert(std::make_pair(strval, vId));
                }
            }
        }
    }

    return true;
}

bool duke_media_compound_declare::template_instantiation(DbTxn* txn)
{
    mStrVid vId;
    this->find_complex_port(vId);
    for( std::size_t i = 0; i < m_data.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < m_data.groups[i].members.size(); ++j)
        {
            //instantiation groups one by one
            if( -1 == m_data.groups[i].members[j].relay_idx) //the same type with instantiation type:T
            {
                if(m_data.groups[i].members[j].is_input) //in_port
                {
                    m_data.iports[m_data.groups[i].members[j].port_idx].interface = m_data.groups[i].min_if;
                }
                else //out_port
                {
                    m_data.oports[m_data.groups[i].members[j].port_idx].interface = m_data.groups[i].min_if;
                }
            }
            else //compound interface:array<T>
            {
                std::string strval = (m_data.groups[i].members[j].is_input ? "input" : "ouput") + 
                    to_string(m_data.groups[i].members[j].port_idx);

                if(m_data.groups[i].members[j].is_input)
                {
                    table_ite if_ite = ifTable.find(m_data.iports[m_data.groups[i].members[j].port_idx].interface);
                    if((if_ite != ifTable.end()) && (if_ite->second.first == (vId.find(strval))->second))
                    {
                        m_data.iports[m_data.groups[i].members[j].port_idx].interface = if_ite->second.second;
                    }
                    else
                    {
                        if(!m_data.iports[m_data.groups[i].members[j].port_idx].interface.is_builtin_interface())
                            continue;
                        duke_media_compound_interface  cIf(hc_id);
                        ifTable.insert(std::make_pair(m_data.iports[m_data.groups[i].members[j].port_idx].interface, 
                                    std::make_pair((vId.find(strval))->second, cIf.get_handle())));

                        duke_logic_data_interface_compound if_data;
                        get_builtin_interface_compound(m_data.iports[m_data.groups[i].members[j].port_idx].interface, if_data);
                        if_data.m_ifc = cIf.get_handle();
                        if_data.m_hext = (vId.find(strval))->second;
                        this->set_decl_in_cif(hc_id, if_data,  txn);
                        // get general declarations
                        duke_logic_static_interface::get_general_instructions(if_data.m_decls);


                        cIf.set_data_to_handle(if_data);
                        m_data.iports[m_data.groups[i].members[j].port_idx].interface = cIf.get_handle();
                    }
                }
                else
                {
                    table_ite if_ite = ifTable.find(m_data.oports[m_data.groups[i].members[j].port_idx].interface);
                    if((if_ite != ifTable.end()) && (if_ite->second.first == (vId.find(strval))->second))
                    {
                        m_data.oports[m_data.groups[i].members[j].port_idx].interface = if_ite->second.second;
                    }
                    else
                    {
                        if(!m_data.oports[m_data.groups[i].members[j].port_idx].interface.is_builtin_interface())
                            continue;
                        duke_media_compound_interface  cIf(hc_id);
                        ifTable.insert(std::make_pair(m_data.oports[m_data.groups[i].members[j].port_idx].interface,
                                    std::make_pair((vId.find(strval))->second, cIf.get_handle())));

                        duke_logic_data_interface_compound if_data;
                        get_builtin_interface_compound(m_data.oports[m_data.groups[i].members[j].port_idx].interface, if_data);
                        if_data.m_ifc = cIf.get_handle();
                        if_data.m_hext = (vId.find(strval)->second);
                        this->set_decl_in_cif(hc_id, if_data, txn);
                        // get general declarations
                        duke_logic_static_interface::get_general_instructions(if_data.m_decls);

                        cIf.set_data_to_handle(if_data);
                        m_data.oports[m_data.groups[i].members[j].port_idx].interface = cIf.get_handle();
                    }
                }
            }
        }
    }
    return true;
}

bool duke_media_compound_declare::is_valid()
{
    // Check input ports
    if (this->get_iport_number() < 1)
    {
        LOG_ERROR("duke_media_compound_declare::is_valid() : iport less than 1.");
        return false;
    }

    for (size_t i = 0; i < m_data.iports.size(); ++i)
    {
        if (!m_data.iports[i].interface.is_interface())
        {
            LOG_ERROR("duke_media_compound_declare::is_valid() : iport[" << i << "] interface invalid.");
            return false;
        }

        // array/map/stroage must be expanded
        if (m_data.iports[i].interface.is_interface_array() ||
            m_data.iports[i].interface.is_interface_map()   ||
            m_data.iports[i].interface.is_interface_storage())
        {
            LOG_ERROR("duke_media_compound_declare::is_valid() : iport[" << i << "] interface unexpanded.");
            return false;
        }
    }

    // Check output ports
    for (size_t i = 0; i < m_data.oports.size(); ++i)
    {
        if (!m_data.oports[i].interface.is_interface())
        {
            LOG_ERROR("duke_media_compound_declare::is_valid() : oport[" << i << "] interface invalid.");
            return false;
        }

        // array/map/stroage must be expanded
        if (m_data.oports[i].interface.is_interface_array() ||
            m_data.oports[i].interface.is_interface_map()   ||
            m_data.oports[i].interface.is_interface_storage())
        {
            LOG_ERROR("duke_media_compound_declare::is_valid() : oport[" << i << "] interface unexpanded.");
            return false;
        }
    }

    return true;
}

editor_base_ptr duke_media_compound_declare::to_xml_struct(index_manager& mgr, int& main_idx)
{
    if (!this->is_valid())
        return editor_base_ptr();

    Declaration_editor_ptr pDecl(new(std::nothrow) Declaration_editor());

    if(!pDecl)
        return pDecl;

    //declaration type
    std::map<duke_media_type, int> decl_type_table;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_DECLARE] = 0;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_COMPOSE] = 1;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE] = 2;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_COMPOSE] = 3;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_DECOMPOSE] = 4;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_GET_ANCHORS] = 5;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_GET_STORAGES] = 6;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_SYNC] = 7;
    decl_type_table[DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_ASYNC] = 8;

    duke_media_type decl_type = this->get_handle().get_type();
    assert(decl_type_table.find(decl_type) != decl_type_table.end());
    pDecl->set_declarationType(decl_type_table[decl_type]);

    //declaration name
    pDecl->set_name(m_data.name);

    //Declaration Expansion Group
    std::vector<DeclarationExpansionGroup> expansionGroups;
    for(std::vector<duke_logic_data_declare_compound::m_decl_exp_group>::iterator it = m_data.groups.begin();
        it != m_data.groups.end(); ++it)
    {
        DeclarationExpansionGroup decl_exp_group;
        decl_exp_group.name = it->name;
        
        int idx = mgr.get_index_from_handle(it->min_if);
        decl_exp_group.minimumInterface = idx;

        decl_exp_group.expanded = it->expanded;

        std::vector<DeclarationExpansionIndex> members;
        for(std::vector<duke_logic_data_declare_compound::m_decl_exp_idx>::iterator iter = it->members.begin();
            iter != it->members.end(); ++iter)
        {
            DeclarationExpansionIndex decl_exp_idx;
            decl_exp_idx.relayIndex = iter->relay_idx;
            decl_exp_idx.portNumber = iter->port_idx;
            decl_exp_idx.isInput = iter->is_input;
            members.push_back(decl_exp_idx);
        }
        decl_exp_group.members = members;
    }
    
    pDecl->set_expansionGroups(expansionGroups);

    //set inport ports
    std::vector<InputPort> inputPorts;
    for(std::vector<duke_logic_data_declare_compound::m_iport_t>::iterator it = m_data.iports.begin();
        it != m_data.iports.end(); ++it)
    {
        InputPort port;
        port.name = it->name;
        int idx = mgr.get_index_from_handle(it->interface);
        port.interface = idx;
        idx = mgr.get_index_from_handle(it->default_value);
        port.defaultValue = idx;
        inputPorts.push_back(port);
    }
    pDecl->set_inputPorts(inputPorts);

    //set output ports
    std::vector<OutputPort> outputPorts;
    for(std::vector<duke_logic_data_declare_compound::m_oport_t>::iterator it = m_data.oports.begin();
        it != m_data.oports.end(); ++it)
    {
        OutputPort port;
        port.name = it->name;
        int idx = mgr.get_index_from_handle(it->interface);
        port.interface = idx;
        outputPorts.push_back(port);
    }
    pDecl->set_outputPort(outputPorts);
    
    // main index
    main_idx = mgr.request_index_for_editor(this->get_handle(), pDecl);

    return pDecl;
}

bool duke_media_compound_declare::init_save(DbTxn* txn)
{
    // only when handle is temp (or formal)
    // save to tempobj_db only
    if (e_handle_core != this->get_handle_status())
    {
        // call the virtual pack()
        return this->get_handle().set_value(this->pack_helper(), txn);
    }
    else
    {
        return false;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
