#include "duke_media_global.h"
#include "duke_media_storage.h"


//{(name_handle)(icon_handle)}
//{(hobj)(hpos)...(hobj)(hpos)}
//

duke_media_storage::duke_media_storage(const host_committer_id_t& host_id, const std::string& username) : duke_media_base(DUKE_MEDIA_TYPE_STORAGE, host_id), hc_id(host_id)
{
	duke_media_compound_interface mif(host_id, username);
	m_storage.m_iftype = mif.get_handle();
	bool ret = this->save_storage();
	assert(ret);
}

duke_media_storage::duke_media_storage(const duke_media_handle& hstorage, const std::string& username)
{
    bool ret = this->assign(hstorage);
    assert(ret);
    ret = read_from_new_db(hstorage);
    assert(ret);

    this->set_handle(hstorage);
}

bool duke_media_storage::assign(const duke_media_handle& hstorage)
{
	bool ret = false;
	if (!hstorage.is_storage())
		LOG_ERROR("assign storage:" + hstorage.str());

	assert(hstorage.is_storage());
	std::string strstorage;
	ret = hstorage.get_value(strstorage);
	if (!ret)
		LOG_ERROR("get value storage:" + hstorage.str()  + ":value:" + strstorage);

	assert(ret);
	assert(!strstorage.empty());
	this->unpack_helper(strstorage);
	this->set_handle(hstorage);
	return ret;
}

bool duke_media_storage::copy(const duke_media_handle& hstorage)
{
	bool ret = false;
	assert(hstorage.is_storage());

	std::string strval;
	ret = hstorage.get_value(strval);
	assert(ret);
	this->unpack_helper(strval);
	ret = this->save_storage();
	assert(ret);
	return ret;
}

bool duke_media_storage::set_name(const std::string& name)
{
	m_storage.m_name = name;
    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);
    return this->save_storage();
   	//duke_logic_storage dstor(get_handle());
	//return dstor.set_name(name);
}

bool duke_media_storage::get_name(std::string& name) const
{
    name = m_storage.m_name;
    return true;
}

bool duke_media_storage::set_icon(const std::string& icon)
{
	m_storage.m_icon = icon;
	return this->save_storage();
}

bool duke_media_storage::get_icon(std::string& icon) const
{
	icon = m_storage.m_icon;
	return true;
}

bool duke_media_storage::set_container(const duke_media_handle& handle)
{
	m_storage.m_hcontainer = handle;
	return this->save_storage();
}

bool duke_media_storage::get_container(duke_media_handle& handle)
{
	handle = m_storage.m_hcontainer;
	return true;
}

bool duke_media_storage::clear_storage_interface()
{
	duke_media_compound_interface m_mif(m_storage.m_iftype);
	bool ret = m_mif.clear_declaration();
	assert(ret);
	return ret;
}

bool duke_media_storage::clear_storage_objects()
{
	m_storage.m_objs.clear();
	return this->save_storage();
}

bool duke_media_storage::get_type(duke_media_handle& handle) const
{
	//duke_logic_storage stor(get_handle(), "");
	//duke_media_handle_vector vhandle;
	//stor.get_type(vhandle);
	if (m_storage.m_compound.m_hext.empty())
    {
        handle = duke_media_handle_null;
    }
	else if (m_storage.m_compound.m_hext.size() == 2)
    {
		handle = m_storage.m_compound.m_hext[0];
    }
    else 
    {
        handle = m_storage.m_compound.m_hext[0];
    }
	return true;
}

bool duke_media_storage::get_type(dukeid_vector& handle) const
{
	//duke_logic_storage stor(get_handle(), "");
	//duke_media_handle_vector vhandle;
	//stor.get_type(vhandle);
    if( 2 != m_storage.m_compound.m_hext.size()) 
    {
        handle.assign(2, duke_media_handle_null);
    }
    else
    {
        handle = m_storage.m_compound.m_hext;
    }

	return true;
}

//bool duke_media_storage::set_interface(const duke_media_handle& hif)
//{
//	assert(hif.is_interface());
//
//	duke_media_handle_vector vtype;
//	vtype.push_back(hif);
//	m_storage.m_compound.m_hext = vtype;
//	bool ret = this->save_storage();
//	assert(ret);
//	return ret;
//}

bool duke_media_storage::set_storage_idx(int index)
{
   	//duke_logic_storage dstor(get_handle());
	//return dstor.set_storage_idx(index);
    
	m_storage.storage_idx = index;
	return this->save_storage();
}

bool duke_media_storage::get_storage_idx(int& index)
{
   	//duke_logic_storage dstor(get_handle());
	//return dstor.get_storage_idx(index);
    
	index = m_storage.storage_idx;
	return true;
}

bool duke_media_storage::set_exdecl(const duke_media_handle& handle)
{
	m_storage.exdecl = handle;
	return this->save_storage();
}

bool duke_media_storage::get_exdecl(duke_media_handle& handle)
{
	handle = m_storage.exdecl;
	return true;
}

bool duke_media_storage::set_value(const duke_media_handle_vector& type, const duke_media_handle_pair_vector& value, const host_committer_id_t host)
{
    //here is seting value to storage
    if (type == m_storage.m_compound.m_hext)
    {
        m_storage.m_objs = value;
        return this->save_storage();
    }

    //***********************create a new compound interface to storage*****************************
    duke_media_compound_interface comobj(host);

    duke_logic_data_interface_compound comdata;
    comdata.m_ifc = comobj.get_handle();

    //not used now
    comdata.m_type = duke_media_handle(NB_INTERFACE_STORAGE);


    //nb_id_t key_type, val_type, self_type;
    //key_type = NB_INTERFACE_INT;// key type can only be int

    //val_type = type[0].get_nb_type();
    //self_type = comobj.get_handle().get_nb_type();

    //set storage type
    dukeid_vector st_type;
    st_type.push_back(NB_INTERFACE_INT);
    st_type.push_back(type[0]);
    comdata.m_hext = st_type;

    // for db transaction
    //DbTxn* txn = NULL;
    //DbTxn* stortxn = NULL;
    //int flag(0);

    comdata.m_decls.clear();
    duke_logic_data_interface_compound tmp_if_data;
    get_builtin_interface_compound(dukeid_t(NB_INTERFACE_STORAGE_SIMPLE), tmp_if_data);
    for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
    {
        comdata.m_decls.push_back(generate_storage_decl(tmp_if_data.m_decls[i].get_func_type(), st_type, host));
    }

    comobj.set_data_to_handle(comdata);
    //***************************************************************************************************

    dukeid_t idifc(NB_INTERFACE_STORAGE);
    m_storage.m_sif = idifc;
    m_storage.m_iftype = comdata.m_ifc;
    m_storage.m_compound = comdata;
    m_storage.m_objs = value;

    return this->save_storage();

	//duke_logic_storage dstor(get_handle());
	//return dstor.set_value(hc_id, type, value);
} 

dukeid_t duke_media_storage::generate_storage_decl(const nb_builtin_instruction_t ins, const dukeid_vector& type,
                            const host_committer_id_t& hc_id)
{
    /* get declaration name */
    std::string name;
    duke_logic_static_declaration::get_builtin_name(ins, name);

    duke_media_declare_expanded decl(hc_id);

    decl.set_name(name);
    decl.set_expanded_type(dukeid_t(ins), type);

    return decl.get_handle();
}

//bool duke_media_storage::set_value(const duke_media_handle_vector& type, const duke_media_handle_pair_vector& value, int index)
//{
//	duke_logic_storage dstor(get_handle());
//	return dstor.set_value(hc_id, type, value, "", index);
//} 

bool duke_media_storage::set_type(const duke_media_handle_vector& type)
{
	//duke_logic_storage dstor(get_handle());
	//return dstor.set_type(type);
    if (!type.empty())
    {
        m_storage.m_compound.m_hext = type;
        return this->save_storage();
    }
    return false;
} 

bool duke_media_storage::get_interface(duke_media_handle& hif) const
{
	get_compound_interface(hif);
	return true;
}

bool duke_media_storage::set_storage_compound_if_data(const duke_logic_data_interface_compound& comdata  )
{
    m_storage.m_compound = comdata;
    return true;
}
bool duke_media_storage::set_storage_if(const duke_media_handle& id)
{
    m_storage.m_iftype = id;
    return true;
}

//bool duke_media_storage::get_declarations(duke_media_handle_vector& hdecls)
//{
//	duke_media_interface m_mif(m_storage.m_sif);
//	return m_mif.get_declarations(hdecls);
//}

bool duke_media_storage::get_compound_interface(duke_media_handle& hif) const
{
	////duke_logic_storage dstor(get_handle());
	//hif = m_storage.m_compound.m_hext;
	//return dstor.get_interface(hif);
    hif = m_storage.m_iftype;
    return true;
}

//bool duke_media_storage::get_compound_declarations(duke_media_handle_vector& hdecls)
//{
//	duke_media_interface m_mif(m_storage.m_compound.m_hext[0]);
//	return m_mif.get_declarations(hdecls);
//}

bool duke_media_storage::add_storage_object(const duke_media_handle& hkey, const duke_media_handle& hobj)
{
   	//assert(hobj.is_object() || hobj.is_access());
	duke_media_handle_pair_vector_const_iterator it;
	for (it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
	{
		if (hkey.is_object_string() && it->first.is_object_string())
		{
			std::string strfirst, strsecond;
			duke_media_string strobjfir(hkey);
			duke_media_string strobjsec(it->first);

			strobjfir.get_value(strfirst);
			strobjsec.get_value(strsecond);
			if ((!strfirst.empty()) && strfirst == strsecond)
				return false;
		}
		else if (it->first == hkey)
			return false;
		else if (it->first.get_type() != hkey.get_type())
			return false;
	}
	if (hobj.is_object_user())
	{
		duke_media_object object(hobj);
		//assert(!object.is_singleton_object());
	}
	m_storage.m_objs.push_back(std::make_pair(hkey, hobj));
	return this->save_storage();
}

bool duke_media_storage::del_storage_object(const duke_media_handle& hkey)
{
	duke_media_handle_pair_vector_iterator it;
	for (it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
	{
		if (it->first == hkey)
		{
			m_storage.m_objs.erase(it);
			return this->save_storage();
		}
	}
	return false;
}

bool duke_media_storage::get_storage_object(duke_media_handle_vector& vid) const
{
	duke_media_handle_pair_vector_const_iterator it;
	for (it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
		vid.push_back(it->second);
	return true;
}

bool duke_media_storage::get_storage_objects(duke_media_handle_pair_vector& vid) const
{
	vid = m_storage.m_objs;
	return true;
}

bool duke_media_storage::find_storage_object(const duke_media_handle& hkey, duke_media_handle& handle) const
{
	duke_media_handle_pair_vector_const_iterator it;
	for (it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
	{
		if (it->first == hkey)
		{
			handle = it->second;
			return true;
		}
	}
	return false;
}

//bool duke_media_storage::replace_storage_object(const duke_media_handle& hkey, const duke_media_handle& hobj)
//{
//	duke_media_handle_pair_vector_iterator it;
//	for (it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
//	{
//		if (it->first == hkey)
//		{
//			it->second = hobj;
//			return this->save_storage();
//		}
//	}
//	return false;
//}

bool duke_media_storage::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//    std::string strkey = username + "-storage";
//    std::string strval;
//    assert(this->get_handle().is_storage());
//
//    duke_media_storage stor(host_id, username);
//    bool ret = this->get_handle().get_value(strval);
//    assert(ret);
//    
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(stor.get_handle(), strname);
//    assert(ret);
//
//    if (!hfather.is_type_null())
//    {
//        ret = duke_media_write_pair_handle(hfather, this->get_handle(), stor.get_handle());
//        assert(ret);
//    }
//
//    replace_content(username, strval, host_id, hfather);
//
//    ret = stor.get_handle().set_value(strval);
//    assert(ret);
//
//    stor.unpack(strval);
//    stor.pack_new_structure();
//
//    duke_media_remove_handle("anonymous-name-tmp-storage", stor.get_handle());
//    duke_media_remove_handle(username + "-tmp-storage", stor.get_handle());
//    duke_media_remove_handle(username + "-storage", stor.get_handle());
//
//    strval = "";
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + stor.get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//    handle = stor.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(stor.get_handle().str());
//    if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << stor.get_handle().str() << " storage in temp media failed;");
//
//    ac_storage_db_impl stordb;
//    stordb.run(ac_storage_env_impl::instance().get_env(), stor.get_handle().str());
//    for (dukeid_pair_vector_const_iterator it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
//        stordb.write(it->first.str(), it->second.str());
//    ret = stordb.commit();
//    return ret;
    return true;
}

bool duke_media_storage::save_storage()
{
    //bool ret = write_to_new_db(this->get_handle());
    //assert(ret);
    return this->get_handle().set_value(this->pack_helper());
}


std::string duke_media_storage::pack() const
{
    return this->pack_helper();
}

std::string duke_media_storage::pack_helper() const
{
    return m_storage.pack();
}

void duke_media_storage::unpack(const std::string& strval)
{
    this->unpack_helper(strval);
}

void duke_media_storage::unpack_helper(const std::string& strval)
{
    m_storage.unpack(strval);
}

//bool duke_media_storage::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    duke_media_handle hif;
//    this->get_interface(hif);
//
//    if (duke_media_get_handle_status(username, hif) != Build)
//    {
//        duke_media_handle hnew;
//        bool ret = duke_media_read_pair_handle(hfather, hif, hnew);
//        assert(ret);
//
//        if (hnew.is_type_null())
//        {
//            duke_media_compound_interface mif(hif);
//            if (!mif.generate(username, hnew, host_id, hfather))
//                assert(false);
//        }
//        duke_media_replace_handle(strval, hif, hnew);
//    }
//
//
//    /*
//	for (dukeid_pair_vector_const_iterator it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
//	{
//		if (it->first.is_object_user() || it->first.is_object_string() || 
//				it->first.is_object_bytes() || it->first.is_object_array())
//		{
//			if (duke_media_get_handle_status(username, it->first) == Edit)
//			{
//				duke_media_handle hnew;
//				bool ret = duke_media_read_pair_handle(hfather, it->first.str(), hnew);
//				assert(ret);
//				if (hnew.is_type_null())
//				{
//					if (it->first.is_object_user())
//					{
//						duke_media_object obj(1, it->first);
//						ret = obj.generate(username, hnew, host_id, hfather);
//						assert(ret);
//					}
//					else if (it->first.is_object_string())
//					{
//						std::string strval;
//						it->first.get_value(strval);
//						duke_media_string sobj(host_id);
//						ret = sobj.get_handle().set_value(strval);
//						hnew = sobj.get_handle();
//						assert(ret);
//					}
//					else if (it->first.is_object_bytes())
//					{
//                        duke_bytes_t sbyte;
//                        duke_media_bytes dbytes(it->first);
//                        ret = dbytes.get_value(sbyte);
//                        assert(ret);
//
//                        duke_media_bytes dbytes2(host_id);
//                        ret = dbytes2.set_value(sbyte);
//                        hnew = dbytes2.get_handle();
//                        assert(ret);
//                    }
//					else if (it->first.is_object_array())
//					{
//                        std::vector<duke_media_handle> doval;
//                        duke_media_array darr(it->first);
//                        ret = darr.get_value(doval);
//                        assert(ret);
//                        duke_media_handle_vector vtype;
//                        duke_media_handle handle(DUKE_MEDIA_TYPE_NULL);
//                        vtype.push_back(handle);
//                        ret = darr.get_type(vtype);
//                        assert(ret);
//
//                        duke_media_array aobj(host_id);
//                        ret = aobj.set_value(vtype, doval);
//                        assert(ret);
//                        hnew = aobj.get_handle();
//                    }
//				}
//				duke_media_replace_handle(strval, it->first, hnew);
//			}
//		}
//
//		if (it->second.is_object_user() || it->second.is_object_string() || 
//				it->second.is_object_bytes() || it->second.is_object_array())
//		{
//			if (duke_media_get_handle_status(username, it->second) == Edit)
//			{
//				duke_media_handle hnew;
//				bool ret = duke_media_read_pair_handle(hfather, it->second, hnew);
//				assert(ret);
//				if (hnew.is_type_null())
//				{
//					duke_media_object obj(1, it->second);
//					bool ret = obj.generate(username, hnew, host_id, hfather);
//					assert(ret);
//				}
//				else if (it->second.is_object_string())
//				{
//					std::string strval;
//					it->second.get_value(strval);
//					duke_media_string sobj(host_id);
//					ret = sobj.get_handle().set_value(strval);
//					hnew = sobj.get_handle();
//					assert(ret);
//				}
//				else if (it->second.is_object_bytes())
//				{
//                    duke_bytes_t sbyte;
//                    duke_media_bytes dbytes(it->first);
//                    ret = dbytes.get_value(sbyte);
//                    assert(ret);
//
//                    duke_media_bytes dbytes2(host_id);
//                    ret = dbytes2.set_value(sbyte);
//                    hnew = dbytes2.get_handle();
//                    assert(ret);
//                }
//				else if (it->second.is_object_array())
//				{
//                    std::vector<duke_media_handle> doval;
//                    duke_media_array darr(it->first);
//                    ret = darr.get_value(doval);
//                    assert(ret);
//                    duke_media_handle_vector vtype;
//                    duke_media_handle handle(DUKE_MEDIA_TYPE_NULL);
//                    vtype.push_back(handle);
//                    ret = darr.get_type(vtype);
//                    assert(ret);
//
//                    duke_media_array aobj(host_id);
//                    ret = aobj.set_value(vtype, doval);
//                    assert(ret);
//                    hnew = aobj.get_handle();
//                }
//				duke_media_replace_handle(strval, it->second, hnew);
//			}
//		}
//	}*/
//	return true;
//}
//
//bool duke_media_storage::pack_new_structure()
//{
//    storage_data_t tmp_data;
//    tmp_data.name = m_storage.m_name;
//   
///*
//    duke_media_handle hif;
//    this->get_interface(hif);
//*/
//  
//    duke_media_handle hif;
//    hif = m_storage.m_iftype; 
//    tmp_data.interface.str(hif.str());
//
//    duke_media_compound_interface compound(hif);
//    compound.pack_new_structure();
//
//    content tmp_con;
//    storage_implementation::pack(tmp_data, tmp_con);
//    std::string strval = pack_object(tmp_con);
//
//    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//    return true;
//}

bool duke_media_storage::read_from_new_db(const duke_media_handle& hstor)
{
    ac_storage_db_impl stordb;
    stordb.run(ac_storage_env_impl::instance().get_env(), hstor.str());
    
    std::vector<std::pair<nb_id_t, nb_id_t> > vpair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator it;

    stordb.read(vpair);
    m_storage.m_objs.clear();

    for (it = vpair.begin(); it != vpair.end(); ++it)
        m_storage.m_objs.push_back(std::make_pair(it->first, it->second));
    //return stordb.commit();
    return true;
}

bool duke_media_storage::write_to_new_db(const duke_media_handle& hstor)
{
    if (m_storage.m_objs.size() == 0)
        return true;
    ac_storage_db_impl stordb;
    stordb.run(ac_storage_env_impl::instance().get_env(), hstor.str());
    stordb.truncate();
    for (dukeid_pair_vector_const_iterator it = m_storage.m_objs.begin(); it != m_storage.m_objs.end(); ++it)
        stordb.write(it->first.str(), it->second.str());
    bool ret = stordb.commit();
    return ret;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
