#ifndef __DUKE_MEDIA_INTERFACE_H
#define __DUKE_MEDIA_INTERFACE_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
//#include "core/duke_stdx_algorithm.h"
#include "duke_logic_object_data.h"
#include "duke_media_base.h"
#include "duke_logic_id.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_global_db.h"
#include "stdx_algorithm.h"
#include "duke_logic_object.h"

/**********************note*******************************
 * duke_media_interface only standard for builtin interface
 * same id mean same builtin interface
 * *******************************************************/

// {singleton}
// {(hdecl)...(hdecl)}
class duke_media_interface : public duke_media_base
{
private:
    duke_logic_data_interface m_ifc;


public:
    duke_media_interface();

    duke_media_interface(const duke_media_handle& hif, const std::string& username = "anonymous-name");

    virtual bool get_name(std::string& name) const;

    //virtual bool set_name(const std::string& name);

    virtual bool get_icon(std::string& icon) const;

    virtual bool set_icon(const std::string& icon);

    bool assign(const duke_media_handle& hif);

    bool clear();

    bool is_interface_array() const;

    bool is_interface_map() const;

    bool get_declarations(duke_media_handle_vector& hdecls) const;

    bool cover(const duke_media_handle& hif) const;

    bool match(const duke_media_handle& hif) const;

    bool get_builtin_instructions(const duke_media_handle& hif);
};

#endif /* __DUKE_MEDIA_INTERFACE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
