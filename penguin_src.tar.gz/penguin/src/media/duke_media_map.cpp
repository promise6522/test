#include "duke_media_map.h"
#include "duke_media_global.h"

duke_media_map::duke_media_map() : m_hif(NB_INTERFACE_MAP)
{
}

duke_media_map::duke_media_map(const host_committer_id_t& host_id, const std::string& username)
: duke_media_base(DUKE_MEDIA_TYPE_OBJECT_MAP, host_id),
    m_hif(NB_INTERFACE_MAP), hc_id(host_id), user_name(username)
{
    //save  data
    this->get_handle().set_value(m_data.pack());

    //set handle name
    bool ret = duke_media_save_handle_name(this->get_handle(), "map");
    assert(ret);
}

duke_media_map::duke_media_map(const duke_media_handle& handle) : m_hif(NB_INTERFACE_MAP) 
{
    //**************************unpack data to struct*****************************
    //handle must be duke_media_map
    if(!handle.is_object_map())
    {
        LOG_ERROR("error handle assign to array!\n");
    }

    //get data from database and assign it to map data struct
    std::string value;
    this->set_handle_status( handle.get_value(value) );    //we can know where this id come from

    if(value.empty())
    {
        LOG_ERROR("error : this  map: " << this->get_handle().str() << " has no data!");
    }

    //unpack data and set handle to this array
    this->unpack_helper(value);

    //set handle to this array
    this->set_handle(handle);
}

duke_media_handle duke_media_map::clone_new_handle(const host_committer_id_t& hc_id) const
{
    // request a new map handle
    duke_media_map newMap(hc_id);
    duke_media_handle newHandle = newMap.get_handle();

    // do a shallow copy
    std::string value = this->pack();
    newHandle.set_value(value);

    return newHandle;
}

void duke_media_map::unpack_helper(const std::string& strval)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_data.unpack(strval);
    }
    else if (status == e_handle_core)
    {
        if (!strval.empty())
        {
            //fill data to map struct in core
            content value;
            unpack_object(strval, value);

            obj_impl_map::unpack(value, nb_map, data_t);

            //tranform data to map struct in media from core's struct
            m_data.m_name = data_t.name;

            //map's compound interface
            m_data.m_iftype = data_t.type;                   

            //compound_interface data
            duke_media_compound_interface map_if(data_t.type);
            m_data.m_compound = map_if.get_data_from_handle();         

            //map value
            for(std::map<nb_id_t, nb_id_t>::const_iterator it = data_t.data.begin();
                    it != data_t.data.end(); ++it)
            {
                m_data.m_vid.insert(std::make_pair(it->first, it->second));
            }
        }
    }
    else
    {
        LOG_ERROR("array handle: " << this->get_handle().str() << " has not exist in db");
    }
}

void duke_media_map::unpack(const std::string& strval)
{
    this->unpack_helper(strval);
}

std::string duke_media_map::pack() const
{
    return this->pack_helper();
}

std::string duke_media_map::pack_helper()  const
{
    return m_data.pack();
}

void duke_media_map::get_related_handles(duke_media_handle_vector& vHandles)
{
    //store  key and value interface of map
    this->get_type(vHandles);

    //store map value
    std::multimap<duke_media_handle, duke_media_handle>  value;
    this->get_value(value);
    for(std::multimap<duke_media_handle, duke_media_handle>::const_iterator it = value.begin();
            it != value.end(); ++it)
    {
        vHandles.push_back(it->first);
        vHandles.push_back(it->second);
    }

}

bool duke_media_map::is_valid()
{
    dukeid_vector vType;
    this->get_type(vType);

    // Check expansion type
    if (vType.size() != 2)
    {
        LOG_ERROR("duke_media_map::is_valid() : map not expanded completely.");
        return false;
    }

    if (!vType[0].is_interface() || !vType[1].is_interface())
    {
        LOG_ERROR("duke_media_map::is_valid() : invalid map interface.");
        return false;
    }

    // Check elements
    // TODO
    return true;
}

editor_base_ptr  duke_media_map::to_xml_struct(index_manager& mgr, int& main_index)
{
    if (!this->is_valid())
        return editor_base_ptr();

    //for xml struct
    MapValue_editor* pMap = (new (std::nothrow) MapValue_editor());


    //key and vlaue interface of map
    dukeid_vector vType;    
    this->get_type(vType);

    if(vType.size() != 2)                 //the size of map's type handle must be two
    {
        LOG_ERROR("error type for map: " << this->get_handle().str() << std::endl);
    }

    pMap->set_expansionKeyInterface( mgr.get_index_from_handle(vType[0]) );
    pMap->set_expansionValueInterface( mgr.get_index_from_handle(vType[1]) );

    //value of map
    std::vector< MapElement > vIndex;            //for request index for every value of map

    std::multimap<duke_media_handle, duke_media_handle>  value;
    this->get_value(value);
    for(std::multimap<duke_media_handle, duke_media_handle>::const_iterator it = value.begin();
            it != value.end(); ++it)
    {
        struct MapElement element;
        bzero(&element, sizeof(element));

        element.key = mgr.get_index_from_handle(it->first);
        element.value = mgr.get_index_from_handle(it->second);
        vIndex.push_back(element);
    }

    pMap->set_value(vIndex);

    //main index
    editor_base_ptr pEditor(pMap);

    main_index = mgr.request_index_for_editor(this->get_handle(), pEditor);

    return pEditor;
}

bool duke_media_map::get_value(std::multimap<duke_media_handle, duke_media_handle>& value) const 
{
    value = m_data.m_vid;
    return true;
}

dukeid_t duke_media_map::generate_expanded_decl(const nb_builtin_instruction_t ins, const dukeid_vector& type)
{
    /* get declaration name */
    std::string name;
    duke_logic_static_declaration::get_builtin_name(ins, name);
    
    duke_media_declare_expanded decl(hc_id);
    
    decl.set_name(name);
    decl.set_expanded_type(dukeid_t(ins), type);
    
    return decl.get_handle();
}

bool duke_media_map::set_value(const duke_media_handle_vector& type, 
        std::multimap<duke_media_handle, duke_media_handle> value)
{
    if (2 != type.size())
    {
        LOG_ERROR("duke_media_map::set_value() : type.size() != 2");
        return false;
    }

    //when type remains the same with the current m_hext,
    //we can only change the content
    if (m_data.m_compound.m_hext.size() == 2 && m_data.m_compound.m_hext == type)
    {
        if (m_data.m_vid != value)
        {
            m_data.m_vid = value;
            this->save();
        }
        return true;
    }

    
    //create a new compound interface to map
    duke_media_compound_interface comobj(hc_id);

    //fill data to compound_interface data
    duke_logic_data_interface_compound comdata;
    comdata.m_ifc = comobj.get_handle();
    comdata.m_hext = type;
    comdata.m_type = duke_media_handle(NB_INTERFACE_MAP_TYPE);
    comdata.name = "map-interface";


    //********************************create the get decl for map*********************************
    comdata.m_decls.clear();
    duke_logic_data_interface_compound tmp_if_data;
    get_builtin_interface_compound(dukeid_t(NB_INTERFACE_MAP), tmp_if_data);
    for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
    {
        comdata.m_decls.push_back( generate_expanded_decl(tmp_if_data.m_decls[i].get_func_type(), type) );
    }
    //***********************************************************************************************


    // get general declarations
    duke_logic_static_interface::get_general_instructions(comdata.m_decls);
    comobj.set_data_to_handle(comdata);


    m_data.m_iftype = comdata.m_ifc;
    m_data.m_compound = comdata;
    m_data.m_vid = value;

    return this->save();
}

bool duke_media_map::get_interface(duke_media_handle& hif) const
{
    get_compound_interface(hif);

    if (hif.is_type_null())
        hif = m_hif;

    return true;
}

bool duke_media_map::get_compound_interface(duke_media_handle& hif) const
{
    hif = m_data.m_iftype;
    return true;
}


//bool duke_media_map::get_declarations(duke_media_handle_vector& hdecls) const 
//{
//    duke_media_interface mif(m_hif);
//    return mif.get_declarations(hdecls);
//}

bool duke_media_map::get_type(duke_media_handle_vector& vtype) const
{
    vtype = m_data.m_compound.m_hext;
    return true;
}

bool duke_media_map::get_name(std::string& name) const 
{
    name = "map";
    return true;
}

bool duke_media_map::set_name(const std::string& /*name*/) 
{
    return true;
}

bool duke_media_map::get_icon(std::string& icon) const 
{
    if (is_expanded())
        icon = load_image(get_builtin_resource_path() + "map_ex.png");
    else
        icon = load_image(get_builtin_resource_path() + "map.png");
    if (icon.empty())
        return false;
    return true; 
}

bool duke_media_map::set_icon(const std::string& /*icon*/) 
{
    return true;
}

bool duke_media_map::is_expanded() const 
{
    duke_media_handle hif;
    this->get_interface(hif);

    if (hif.is_interface_compound())
        return true;

    return false;
}

bool duke_media_map::generate(const std::string& username, duke_media_handle& handle, 
        const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//
//    duke_media_map mmap(host_id);
//    
//    std::multimap<duke_media_handle, duke_media_handle> oldvalue, newvalue;
//    duke_media_handle_vector htype, hvtype;
//    get_type(htype);
//
//    bool ret = get_value(oldvalue);
//    assert(ret);
//    
//    ret = duke_media_write_pair_handle(hfather, this->get_handle(), mmap.get_handle());
//    assert(ret);
//    /////
//    hvtype.clear();
//    assert(htype.size() == 2);
//    
//    for (duke_media_handle_const_iterator it = htype.begin(); it != htype.end(); ++it)
//    {
//        duke_media_handle hnew = *it;
//        if (duke_media_get_handle_status(username, *it) == Edit)
//        {
//            if ((*it).is_interface_compound())
//            {
//                bool ret = duke_media_read_pair_handle(hfather, *it, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface mobj(*it);
//                    ret = mobj.generate(username, hnew, host_id, hfather);
//                    assert(ret);
//                }
//            }
//        }
//        hvtype.push_back(hnew);
//    }
//
//
//    newvalue.clear();
//    for (duke_media_handle_multimap_const_iterator iter = oldvalue.begin(); iter != oldvalue.end(); ++iter)
//    {
//        duke_media_handle hnewfirst, hnewsecond;
//
//        // replace the first value
//        {
//            if ((*iter).first.is_object_user())
//            {
//                duke_media_handle hobj = (*iter).first;
//                if (duke_media_get_handle_status(username, (*iter).first) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).first, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_object mobj((*iter).first);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewfirst = hobj;
//            }
//            else if ((*iter).first.is_object_array())
//            {}
//            else if ((*iter).first.is_object_map())
//            {}
//            else if ((iter->first).is_object_string())
//            {
//                std::string stringval;
//                iter->first.get_value(stringval);
//                duke_media_string sobj(host_id);
//                bool ret = sobj.get_handle().set_value(stringval);
//                assert(ret);
//                hnewfirst = sobj.get_handle();
//            }
//            else if ((iter->first).is_object_bytes())
//            {
//                duke_bytes_t sbyte;
//                duke_media_bytes dbytes(iter->first);
//                bool ret = dbytes.get_value(sbyte);
//                assert(ret);
//
//                duke_media_bytes dbytes2(host_id);
//                ret = dbytes2.set_value(sbyte);
//                hnewfirst = dbytes2.get_handle();
//            }
//            else if ((*iter).first.is_declaration_compound())
//            {
//                duke_media_handle hobj = (*iter).first;
//                if (duke_media_get_handle_status(username, (*iter).first) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).first, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_compound_declare mobj((*iter).first);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewfirst = hobj;
//            }
//            else if ((*iter).first.is_implementation())
//            {
//                duke_media_handle hobj = (*iter).first;
//                if (duke_media_get_handle_status(username, (*iter).first) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).first, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_implement mobj((*iter).first);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewfirst = hobj;
//            }
//            else
//                hnewfirst = (*iter).first;
//        }
//        
//        // replace the second value
//        {
//            if ((*iter).second.is_object_user())
//            {
//                duke_media_handle hobj = (*iter).second;
//                if (duke_media_get_handle_status(username, (*iter).second) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).second, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_object mobj((*iter).second);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewsecond = hobj;
//            }
//            else if ((*iter).second.is_object_array())
//            {}
//            else if ((*iter).second.is_object_map())
//            {}
//            else if ((iter->second).is_object_string())
//            {
//                std::string stringval;
//                iter->second.get_value(stringval);
//                duke_media_string sobj(host_id);
//                bool ret = sobj.get_handle().set_value(stringval);
//                assert(ret);
//                hnewsecond = sobj.get_handle();
//            }
//            else if ((iter->second).is_object_bytes())
//            {
//                duke_bytes_t sbyte;
//                duke_media_bytes dbytes(iter->second);
//                bool ret = dbytes.get_value(sbyte);
//                assert(ret);
//
//                duke_media_bytes dbytes2(host_id);
//                ret = dbytes2.set_value(sbyte);
//                hnewsecond = dbytes2.get_handle();
//            }
//            else if ((*iter).second.is_declaration_compound())
//            {
//                duke_media_handle hobj = (*iter).second;
//                if (duke_media_get_handle_status(username, (*iter).second) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).second, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_compound_declare mobj((*iter).second);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewsecond = hobj;
//            }
//            else if ((*iter).second.is_implementation())
//            {
//                duke_media_handle hobj = (*iter).second;
//                if (duke_media_get_handle_status(username, (*iter).second) == Edit)
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*iter).second, hobj);
//                    assert(ret);
//                    if (hobj.is_type_null())
//                    {
//                        duke_media_implement mobj((*iter).second);
//                        bool ret = mobj.generate(username, hobj, host_id, hfather);
//                        assert(ret);
//                    }
//                }
//                hnewsecond = hobj;
//            }
//            else
//                hnewsecond = (*iter).second;
//        }
//        assert(!(hnewfirst.is_type_null()) && !(hnewsecond.is_type_null()));
//
//        newvalue.insert(std::make_pair(hnewfirst, hnewsecond));
//    }
//    ret = mmap.set_value(hvtype, newvalue, false);
//    assert(ret);
//
//    handle = mmap.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(mmap.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << mmap.get_handle().str() << " map in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << mmap.get_handle().str() << " map in temp media failed;");
//
//    return ret;
    return true;
}
