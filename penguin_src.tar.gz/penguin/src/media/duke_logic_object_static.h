#ifndef __NB_LOGIC_OBJECT_STATIC_H
#define __NB_LOGIC_OBJECT_STATIC_H

#include <vector>
#include <string>

#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"
#include "stdx_log.h"

#include "duke_logic_id.h"
#include "duke_logic_object_data.h"


/********************************** conversion func ***********************************/

inline void nb_id_vector_to_dukeid_vector(const nb_id_vector& vin, dukeid_vector& vout)
{
    int size = vin.size();
    if(0 == size)
        return;

    // for allocation performance
    vout.reserve(vout.size() + size);

    for(nb_id_vector_const_it it = vin.begin(); it != vin.end(); ++it)
        vout.push_back( dukeid_t(*it) );
}

inline void dukeid_vector_to_nb_id_vector(const dukeid_vector& vin, nb_id_vector& vout)
{
    int size = vin.size();
    if(0 == size)
        return;

    // for allocation performance
    vout.reserve(vout.size() + size);

    for(dukeid_vector_const_iterator it = vin.begin(); it != vin.end(); ++it)
        vout.push_back( it->get_nb_type() );
}


/********************************** object base ***********************************/

class duke_object_static_base
{
public:
    static void get_general_interface(dukeid_vector& vid)
    {
        /* for consistence, we prefer get them from core modules
        **
        vid.push_back(NB_FUNC_GENERAL_GET_NAME);
        vid.push_back(NB_FUNC_GENERAL_IS_NULL);
        vid.push_back(NB_FUNC_GENERAL_IS_SINGLETON);
        vid.push_back(NB_FUNC_GENERAL_IS_JUSTID);
        vid.push_back(NB_FUNC_GENERAL_IS_BUILTIN);
        vid.push_back(NB_FUNC_GENERAL_IS_EXPORTABLE);
        vid.push_back(NB_FUNC_GENERAL_IS_LOCAL);
        vid.push_back(NB_FUNC_GENERAL_IS_VALUECOMPARED);
        vid.push_back(NB_FUNC_GENERAL_EXCEPTION_IF_NULL);
        vid.push_back(NB_FUNC_GENERAL_COMPARE);
        vid.push_back(NB_FUNC_GENERAL_GET_INTERFACE);
        vid.push_back(NB_FUNC_GENERAL_RUN);
        vid.push_back(NB_FUNC_GENERAL_GET_REGISTED_ACCESSES);
        */
        nb_id_vector vins;
        obj_impl_interface::get_general_instructions(vins);
        nb_id_vector_to_dukeid_vector(vins, vid);
    }

    static bool get_general_declaration(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        //case NB_FUNC_GENERAL_GET_NAME:
        case NB_FUNC_GENERAL_IS_NULL:
        case NB_FUNC_GENERAL_IS_SINGLETON:
        case NB_FUNC_GENERAL_IS_JUSTID:
        case NB_FUNC_GENERAL_IS_BUILTIN:
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
        case NB_FUNC_GENERAL_IS_LOCAL:
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            make_iany_obool_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            make_iany_oany_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_COMPARE:
            make_i2any_o6bool_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_GET_INTERFACE:
            make_iany_ointerface_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_GET_NAME:
            make_iany_ostring_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_RUN:
            make_iany_idecl_iarray_oarray_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static bool get_general_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_GENERAL_IS_NULL:
            name = "is null";
            break;
        case NB_FUNC_GENERAL_IS_SINGLETON:
            name = "is singleton";
            break;
        case NB_FUNC_GENERAL_IS_JUSTID:
            name = "is just id";
            break;
        case NB_FUNC_GENERAL_IS_BUILTIN:
            name = "is builtin";
            break;
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
            name = "is exportable";
            break;
        case NB_FUNC_GENERAL_IS_LOCAL:
            name = "is local";
            break;
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            name = "is value compared";
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            name = "exception if null";
            break;
        case NB_FUNC_GENERAL_COMPARE:
            name = "compare";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iany_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        out.push_back(hb);
    }

    static void make_iany_idecl_iany_ibool_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        in.push_back(hn);
        in.push_back(hb);
        out.push_back(hn);
    }

    static void make_iany_idecl_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t harr(NB_INTERFACE_ARRAY);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        out.push_back(harr);
    }

    static void make_iany_idecl_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        out.push_back(hn);
    }

    static void make_iany_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(hn);
        out.push_back(hn);
    }

    static void make_i2any_o6bool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        in.push_back(hn);
        out.push_back(hb);
        out.push_back(hb);
        out.push_back(hb);
        //out.push_back(hb);
        //out.push_back(hb);
        //out.push_back(hb);
    }

    static void make_iany_ointerface_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        in.push_back(NB_INTERFACE_NONE);
        out.push_back(NB_INTERFACE_INTERFACE);
    }

    static void make_iany_ostring_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        in.push_back(NB_INTERFACE_NONE);
        out.push_back(NB_INTERFACE_STRING);
    }

    static void make_iany_idecl_iarray_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        in.push_back(NB_INTERFACE_NONE);
        in.push_back(NB_INTERFACE_DECLARATION);//TODO
        //TODO for array interface
    }
};

/********************************** built-in objects ***********************************/

class duke_object_static_none : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "none";
        return true;
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        get_general_interface(vid);
    }
};

class duke_object_static_boolean : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "boolean";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BOOL_NOT:
            name = "not";
            break;
        case NB_FUNC_BOOL_AND:
            name = "and";
            break;
        case NB_FUNC_BOOL_OR:
            name = "or";
            break;
        case NB_FUNC_BOOL_EQ:
            name = "eq";
            break;
        case NB_FUNC_BOOL_NE:
            name = "ne";
            break;
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
            name = "exception true";
            break;
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
            name = "exception false";
            break;
        case NB_FUNC_BOOL_BREAK_TRUE:
            name = "break true";
            break;
        case NB_FUNC_BOOL_BREAK_FALSE:
            name = "break false";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("not");
        vstr.push_back("and");
        vstr.push_back("or");
        vstr.push_back("eq");
        vstr.push_back("ne");
        vstr.push_back("exception true");
        vstr.push_back("exception false");
        vstr.push_back("break true");
        vstr.push_back("break false");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_BOOL_NOT);
        vid.push_back(NB_FUNC_BOOL_AND);
        vid.push_back(NB_FUNC_BOOL_OR);
        vid.push_back(NB_FUNC_BOOL_EQ);
        vid.push_back(NB_FUNC_BOOL_NE);
        vid.push_back(NB_FUNC_BOOL_EXCEPTION_TRUE);
        vid.push_back(NB_FUNC_BOOL_EXCEPTION_FALSE);
        vid.push_back(NB_FUNC_BOOL_BREAK_TRUE);
        vid.push_back(NB_FUNC_BOOL_BREAK_FALSE);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;

        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BOOL_NOT:
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
        case NB_FUNC_BOOL_BREAK_TRUE:
        case NB_FUNC_BOOL_BREAK_FALSE:
            make_ibool_obool_declaration(in, out);
            break;
        case NB_FUNC_BOOL_AND:
        case NB_FUNC_BOOL_OR:
        case NB_FUNC_BOOL_EQ:
        case NB_FUNC_BOOL_NE:
            make_ibool_ibool_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ibool_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hb);
        out.push_back(hb);
    }

    static void make_ibool_ibool_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hb);
        in.push_back(hb);
        out.push_back(hb);
    }
};

class duke_object_static_integer : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "integer";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INT_ADD:
            name = "add";
            break;
        case NB_FUNC_INT_SUB:
            name = "sub";
            break;
        case NB_FUNC_INT_IMUL:
            name = "imul";
            break;
        case NB_FUNC_INT_IDIV:
            name = "idiv";
            break;
        case NB_FUNC_INT_EQ:
            name = "eq";
            break;
        case NB_FUNC_INT_LT:
            name = "lt";
            break;
        case NB_FUNC_INT_INC:
            name = "inc";
            break;
        case NB_FUNC_INT_DEC:
            name = "dec";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("imul");
        vstr.push_back("idiv");
        vstr.push_back("eq");
        vstr.push_back("lt");
        vstr.push_back("inc");
        vstr.push_back("dec");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_INT_ADD);
        vid.push_back(NB_FUNC_INT_SUB);
        vid.push_back(NB_FUNC_INT_IMUL);
        vid.push_back(NB_FUNC_INT_IDIV);
        vid.push_back(NB_FUNC_INT_EQ);
        vid.push_back(NB_FUNC_INT_LT);
        vid.push_back(NB_FUNC_INT_INC);
        vid.push_back(NB_FUNC_INT_DEC);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INT_ADD:
        case NB_FUNC_INT_SUB:
        case NB_FUNC_INT_IMUL:
        case NB_FUNC_INT_IDIV:
            make_iint_iint_oint_declaration(in, out);
            break;
        case NB_FUNC_INT_EQ:
        case NB_FUNC_INT_LT:
            make_iint_iint_obool_declaration(in, out);
            break;
        case NB_FUNC_INT_INC:
        case NB_FUNC_INT_DEC:
            make_iint_oint_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iint_iint_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hi);
    }

    static void make_iint_iint_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hi(NB_INTERFACE_INT);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hb);
    }

    static void make_iint_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hi);
        out.push_back(hi);
    }
};

class duke_object_static_float : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "float";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_FLOAT_ADD:
            name = "add";
            break;
        case NB_FUNC_FLOAT_SUB:
            name = "sub";
            break;
        case NB_FUNC_FLOAT_IMUL:
            name = "imul";
            break;
        case NB_FUNC_FLOAT_IDIV:
            name = "idiv";
            break;
        case NB_FUNC_FLOAT_EQ:
            name = "eq";
            break;
        case NB_FUNC_FLOAT_LT:
            name = "lt";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("imul");
        vstr.push_back("idiv");
        vstr.push_back("eq");
        vstr.push_back("lt");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_FLOAT_ADD);
        vid.push_back(NB_FUNC_FLOAT_SUB);
        vid.push_back(NB_FUNC_FLOAT_IMUL);
        vid.push_back(NB_FUNC_FLOAT_IDIV);
        vid.push_back(NB_FUNC_FLOAT_EQ);
        vid.push_back(NB_FUNC_FLOAT_LT);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_FLOAT_ADD:
        case NB_FUNC_FLOAT_SUB:
        case NB_FUNC_FLOAT_IMUL:
        case NB_FUNC_FLOAT_IDIV:
            make_ifloat_ifloat_ofloat_declaration(in, out);
            break;
        case NB_FUNC_FLOAT_EQ:
        case NB_FUNC_FLOAT_LT:
            make_ifloat_ifloat_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ifloat_ifloat_ofloat_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hf(NB_INTERFACE_FLOAT);
        in.push_back(hf);
        in.push_back(hf);
        out.push_back(hf);
    }

    static void make_ifloat_ifloat_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hf(NB_INTERFACE_FLOAT);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hf);
        in.push_back(hf);
        out.push_back(hb);
    }
};

class duke_object_static_string : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "string";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_STR_APPEND:
            name = "append";
            break;
        case NB_FUNC_STR_SUBSTR:
            name = "sub str";
            break;
        case NB_FUNC_STR_SIZE:
            name = "size";
            break;
        case NB_FUNC_STR_SPLITAT:
            name = "split at";
            break;
        //case NB_FUNC_STR_COMPARE:
        //    name = "string compare";
        //    break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("append");
        vstr.push_back("sub str");
        vstr.push_back("size");
        vstr.push_back("split at");
        vstr.push_back("string compare");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_STR_APPEND);
        vid.push_back(NB_FUNC_STR_SUBSTR);
        vid.push_back(NB_FUNC_STR_SIZE);
        vid.push_back(NB_FUNC_STR_SPLITAT);
        //vid.push_back(NB_FUNC_STR_COMPARE);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_STR_APPEND:
            make_istr_istr_ostr_declaration(in, out);
            break;
        case NB_FUNC_STR_SUBSTR:
            make_istr_iint_iint_ostr_declaration(in, out);
            break;
        case NB_FUNC_STR_SIZE:
            make_istr_oint_declaration(in, out);
            break;
        case NB_FUNC_STR_SPLITAT:
            make_istr_iint_ostr_ostr_declaration(in, out);
            break;
        //case NB_FUNC_STR_COMPARE:
        //    make_istr_istr_obool_declaration(in, out);
        //    break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_istr_istr_ostr_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STRING);
        in.push_back(hs);
        in.push_back(hs);
        out.push_back(hs);
    }

    static void make_istr_iint_iint_ostr_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STRING);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hs);
    }

    static void make_istr_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STRING);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        out.push_back(hi);
    }

    static void make_istr_iint_ostr_ostr_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STRING);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        in.push_back(hi);
        out.push_back(hs);
        out.push_back(hs);
    }

    static void make_istr_istr_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STRING);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hs);
        in.push_back(hs);
        out.push_back(hb);
    }
};

class duke_object_static_bytes : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "bytes";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BYTES_JOIN:
            name = "join";
            break;
        case NB_FUNC_BYTES_RANGE:
            name = "range";
            break;
        case NB_FUNC_BYTES_SIZE:
            name = "size";
            break;
        case NB_FUNC_BYTES_SPLIT:
            name = "split";
            break;
        case NB_FUNC_BYTES_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_BYTES_CRC:
            name = "crc";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("join");
        vstr.push_back("range");
        vstr.push_back("size");
        vstr.push_back("split");
        vstr.push_back("split at");
        vstr.push_back("crc");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_BYTES_JOIN);
        vid.push_back(NB_FUNC_BYTES_RANGE);
        vid.push_back(NB_FUNC_BYTES_SIZE);
        vid.push_back(NB_FUNC_BYTES_SPLIT);
        vid.push_back(NB_FUNC_BYTES_SPLITAT);
        vid.push_back(NB_FUNC_BYTES_CRC);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BYTES_JOIN:
            make_ibyte_ibyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_RANGE:
            make_ibyte_iint_iint_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SIZE:
            make_ibyte_oint_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SPLIT:
            make_ibyte_obyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SPLITAT:
            make_ibyte_iint_obyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_CRC:
            make_ibyte_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ibyte_ibyte_obyte_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        in.push_back(hbs);
        in.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_iint_iint_obyte_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hbs);
    }

    static void make_ibyte_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        out.push_back(hi);
    }

    static void make_ibyte_obyte_obyte_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        in.push_back(hbs);
        out.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_iint_obyte_obyte_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        in.push_back(hi);
        out.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hbs(NB_INTERFACE_BYTES);
        dukeid_t hb(NB_INTERFACE_INT);
        in.push_back(hbs);
        out.push_back(hb);
    }
};

class duke_object_static_interval : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "interval";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INTERVAL_GET:
            name = "get";
            break;
        case NB_FUNC_INTERVAL_ADD:
            name = "add";
            break;
        case NB_FUNC_INTERVAL_SUB:
            name = "sub";
            break;
        /*case NB_FUNC_INTERVAL_MUL:
            name = "mul";
            break;
        case NB_FUNC_INTERVAL_DIV:
            name = "div";
            break;*/
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("add");
        vstr.push_back("sub");
        //vstr.push_back("mul");
        //vstr.push_back("div");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_INTERVAL_GET);
        vid.push_back(NB_FUNC_INTERVAL_ADD);
        vid.push_back(NB_FUNC_INTERVAL_SUB);
        //vid.push_back(NB_FUNC_INTERVAL_MUL);
        //vid.push_back(NB_FUNC_INTERVAL_DIV);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INTERVAL_GET:
            make_iitv_o10int_declaration(in, out);
            break;
        case NB_FUNC_INTERVAL_ADD:
        case NB_FUNC_INTERVAL_SUB:
            make_iitv_iitv_oitv_declaration(in, out);
            break;
//        case NB_FUNC_INTERVAL_MUL:
//        case NB_FUNC_INTERVAL_DIV:
//            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iitv_o10int_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hitv(NB_INTERFACE_INTERVAL);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hitv);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
    }

    static void make_iitv_iitv_oitv_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hitv(NB_INTERFACE_INTERVAL);
        in.push_back(hitv);
        in.push_back(hitv);
        out.push_back(hitv);
    }
};

class duke_object_static_time : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "time";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_TIME_GET:
            name = "get";
            break;
        case NB_FUNC_TIME_ADD:
            name = "add";
            break;
        case NB_FUNC_TIME_SUB:
            name = "sub";
            break;
        case NB_FUNC_TIME_CURRENT:
            name = "current time";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("current time");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_TIME_GET);
        vid.push_back(NB_FUNC_TIME_ADD);
        vid.push_back(NB_FUNC_TIME_SUB);
        vid.push_back(NB_FUNC_TIME_CURRENT);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_TIME_GET:
        case NB_FUNC_TIME_CURRENT:
            make_itime_o10int_declaration(in, out);
            break;
        case NB_FUNC_TIME_ADD:
        case NB_FUNC_TIME_SUB:
            make_itime_iitv_otime_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_itime_o10int_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t ht(NB_INTERFACE_TIME);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(ht);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
    }

    static void make_itime_iitv_otime_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t ht(NB_INTERFACE_TIME);
        dukeid_t hitv(NB_INTERFACE_INTERVAL);
        in.push_back(ht);
        in.push_back(hitv);
        out.push_back(ht);
    }
};

class duke_object_static_array : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "array";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ARRAY_GET:
            name = "get";
            break;
        case NB_FUNC_ARRAY_GETHEAD:
            name = "get head";
            break;
        case NB_FUNC_ARRAY_GETTAIL:
            name = "get tail";
            break;
        case NB_FUNC_ARRAY_ADDHEAD:
            name = "add head";
            break;
        case NB_FUNC_ARRAY_ADDTAIL:
            name = "add tail";
            break;
        case NB_FUNC_ARRAY_REVERSE:
            name = "reverse";
            break;
        case NB_FUNC_ARRAY_INSERT:
            name = "insert";
            break;
        case NB_FUNC_ARRAY_JOIN:
            name = "join";
            break;
        case NB_FUNC_ARRAY_RANGE:
            name = "range";
            break;
        case NB_FUNC_ARRAY_SIZE:
            name = "size";
            break;
        case NB_FUNC_ARRAY_SPLIT:
            name = "split";
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_ARRAY_UNIONSET:
            name = "union set";
            break;
        case NB_FUNC_ARRAY_INTERSECTIONSET:
            name = "intersection set";
            break;
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            name = "complementary set";
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            name = "inclusion";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("get head");
        vstr.push_back("get tail");
        vstr.push_back("add head");
        vstr.push_back("add tail");
        vstr.push_back("reverse");
        vstr.push_back("insert");
        vstr.push_back("join");
        vstr.push_back("range");
        vstr.push_back("size");
        vstr.push_back("split");
        vstr.push_back("split at");
        vstr.push_back("union set");
        vstr.push_back("intersection set");
        vstr.push_back("complementary set");
        vstr.push_back("inclusion");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_ARRAY_GET);
        vid.push_back(NB_FUNC_ARRAY_GETHEAD);
        vid.push_back(NB_FUNC_ARRAY_GETTAIL);
        vid.push_back(NB_FUNC_ARRAY_ADDHEAD);
        vid.push_back(NB_FUNC_ARRAY_ADDTAIL);
        vid.push_back(NB_FUNC_ARRAY_REVERSE);
        vid.push_back(NB_FUNC_ARRAY_INSERT);
        vid.push_back(NB_FUNC_ARRAY_JOIN);
        vid.push_back(NB_FUNC_ARRAY_RANGE);
        vid.push_back(NB_FUNC_ARRAY_SIZE);
        vid.push_back(NB_FUNC_ARRAY_SPLIT);
        vid.push_back(NB_FUNC_ARRAY_SPLITAT);
        vid.push_back(NB_FUNC_ARRAY_UNIONSET);
        vid.push_back(NB_FUNC_ARRAY_INTERSECTIONSET);
        vid.push_back(NB_FUNC_ARRAY_COMPLEMENTARYSET);
        vid.push_back(NB_FUNC_ARRAY_INCLUSION);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ARRAY_GET:
            make_iarray_iint_oany_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_INSERT:
            make_iarray_iany_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_GETHEAD:
        case NB_FUNC_ARRAY_GETTAIL:
            make_iarray_oarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_JOIN:
        case NB_FUNC_ARRAY_UNIONSET:
        case NB_FUNC_ARRAY_INTERSECTIONSET:
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            make_iarray_iarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_RANGE:
            make_iarray_iint_iint_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SIZE:
            make_iarray_oint_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SPLIT:
            make_iarray_oarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            make_iarray_iint_oarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            make_iarray_iarray_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iarray_iint_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hi(NB_INTERFACE_INT);
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(har);
        in.push_back(hi);
        out.push_back(hn);
    }

    static void make_iarray_iany_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(har);
        in.push_back(hn);
        out.push_back(har);
    }

    static void make_iarray_iarray_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(har);
        in.push_back(har);
        out.push_back(har);
    }

    static void make_iarray_iint_iint_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(har);
    }

    static void make_iarray_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        out.push_back(hi);
    }

    static void make_iarray_oarray_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(har);
        out.push_back(har);
        out.push_back(har);
    }

    static void make_iarray_iint_oarray_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        in.push_back(hi);
        out.push_back(har);
        out.push_back(hi);
    }

    static void make_iarray_iarray_obool_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t har(NB_INTERFACE_ARRAY);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(har);
        in.push_back(har);
        out.push_back(hb);
    }
};

class duke_object_static_map : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "map";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_MAP_GET:
            name = "get";
            break;
        case NB_FUNC_MAP_INSERT:
            name = "insert";
            break;
        case NB_FUNC_MAP_SIZE:
            name = "size";
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            name = "get all keys";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("insert");
        vstr.push_back("size");
        vstr.push_back("get all keys");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_MAP_GET);
        vid.push_back(NB_FUNC_MAP_INSERT);
        vid.push_back(NB_FUNC_MAP_SIZE);
        vid.push_back(NB_FUNC_MAP_GETALLKEYS);
        get_general_interface(vid);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_MAP_GET:
            make_imap_iany_oarray_declaration(in, out);
            break;
        case NB_FUNC_MAP_INSERT:
            make_imap_iany_iany_omap_declaration(in, out);
            break;
        case NB_FUNC_MAP_SIZE:
            make_imap_oint_declaration(in, out);
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            make_imap_oarray_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_imap_iany_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hm(NB_INTERFACE_MAP);
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(hm);
        in.push_back(hn);
        out.push_back(har);
    }

    static void make_imap_iany_iany_omap_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hm(NB_INTERFACE_MAP);
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(hm);
        in.push_back(hn);
        in.push_back(hn);
        out.push_back(hm);
    }

    static void make_imap_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hm(NB_INTERFACE_MAP);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hm);
        out.push_back(hi);
    }

    static void make_imap_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hm(NB_INTERFACE_MAP);
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(hm);
        out.push_back(har);
    }
};

class duke_object_static_wrapper : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "wrapper";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        return true;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
    }

    static void get_builtin_instructions(const dukeid_t& hobj, dukeid_t& ifid)
    {
        ifid = NB_INTERFACE_NONE;
        if (hobj.is_wrapper())
        {
            std::string objstr;
            hobj.get_value(objstr);
            dukeid_vector  value;
            unpack_dukeid_vector(objstr, value);
            if (value.size() > 0)
            {
                if (value[0].is_object_bool())
                    ifid = NB_INTERFACE_BOOL;
                else if (value[0].is_object_int())
                    ifid = NB_INTERFACE_INT;
                else if (value[0].is_object_float())
                    ifid = NB_INTERFACE_FLOAT;
                else if (value[0].is_object_string())
                    ifid = NB_INTERFACE_STRING;
                else if (value[0].is_object_bytes())
                    ifid = NB_INTERFACE_BYTES;
                else if (value[0].is_object_interval())
                    ifid = NB_INTERFACE_INTERVAL;
                else if (value[0].is_object_time())
                    ifid = NB_INTERFACE_TIME;
                else if (value[0].is_object_array())
                    ifid = NB_INTERFACE_ARRAY;
                else if (value[0].is_object_map())
                    ifid = NB_INTERFACE_MAP;
                //else if (value[0].is_object_user())
                //    ifid = NBID_TYPE_OBJECT_INTERFACE;
            }
        }
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        return true;
    }
};

/********************************** user object ***********************************/

class duke_object_static_user : public duke_object_static_base
{
public:
    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        assert(!"duke_object_static_user::get_declaration_name()");
        return false;

    //  bool ret = true;
    //  switch (hdecl.get_func_type())
    //  {
    //  case NB_FUNC_USER_COMPOSE:
    //      name = "compose";
    //      break;
    //  case NB_FUNC_USER_DECOMPOSE:
    //      name = "decompose";
    //      break;
    //  default:
    //      ret = false;
    //      break;
    //  }
    //  return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
    //  vstr.push_back("compose");
    //  vstr.push_back("decompose");
    }

    static bool get_builtin_instructions(dukeid_vector& vid)
    {
    //  vid.push_back(NB_FUNC_USER_COMPOSE);
    //  vid.push_back(NB_FUNC_USER_DECOMPOSE);
        get_general_interface(vid);
        return true;
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        assert(!"duke_object_static_user::get_interfaces()");
        return false;

    //  bool ret = true;
    //  switch (hdecl.get_func_type())
    //  {
    //  case NB_FUNC_USER_COMPOSE:
    //      make_iuser_iarray_ouser_declaration(in, out);
    //      break;
    //  case NB_FUNC_USER_DECOMPOSE:
    //      make_iuser_oarray_declaration(in, out);
    //      break;
    //  default:
    //      ret = false;
    //      break;
    //  }
    //  return ret;
    }

private:
    /*
    static void make_iuser_iarray_ouser_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t harr(NB_INTERFACE_ARRAY);
        dukeid_t hu(NBID_TYPE_INTERFACE_USER);
        in.push_back(hu);
        in.push_back(harr);
        out.push_back(hu);
    }

    static void make_iuser_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hu(NBID_TYPE_INTERFACE_USER);
        dukeid_t harr(NB_INTERFACE_ARRAY);
        in.push_back(hu);
        out.push_back(harr);
    }
    */
};

class duke_logic_static_access : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "access";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            name = "create container";
            break;
        case NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER:
            name = "destroy container";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
            name = "get cont def";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
            name = "get storage";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
            name = "get storage type";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            name = "get anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
            name = "generate access from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            name = "get access interface from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST:
            name = "get anchor list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST:
            name = "get storage list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS:
            name = "get access";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT:
            name = "get storage content";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("create container");
        vstr.push_back("destroy container");
        vstr.push_back("get cont def");
        vstr.push_back("get storage");
        vstr.push_back("get storage type");
        vstr.push_back("get anchor");
        vstr.push_back("generate access from anchor");
        vstr.push_back("get access interface from anchor");
        vstr.push_back("get anchor list");
        vstr.push_back("get storage list");
        vstr.push_back("get access");
        vstr.push_back("get storage content");

    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER);
        vid.push_back(NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_CONT_DEF);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ACCESS);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        return ret;
    }

private:
};

class duke_logic_static_storage : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "storage";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_STORAGE_GET_SINGLE:
            name = "get single";
            break;
        case NB_FUNC_STORAGE_GET_MORE:
            name = "get more";
            break;
        case NB_FUNC_STORAGE_HAS_KEY:
            name = "has key";
            break;
        case NB_FUNC_STORAGE_INSERT_ONE:
            name = "insert one";
            break;
        case NB_FUNC_STORAGE_REPLACE_ONE:
            name = "replace one";
            break;
        case NB_FUNC_STORAGE_DELETE_ONE:
            name = "delete one";
            break;
        case NB_FUNC_STORAGE_SET_ONE:
            name = "set one";
            break;
        case NB_FUNC_STORAGE_ADD_ONE:
            name = "add one";
            break;
        case NB_FUNC_STORAGE_UPDATE:
            name = "update";
            break;
        case NB_FUNC_STORAGE_SIZE:
            name = "size";
            break;
        case NB_FUNC_STORAGE_GET_RANGE:
            name = "get range";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get single");
        vstr.push_back("get more");
        vstr.push_back("has key");
        vstr.push_back("insert one");
        vstr.push_back("replace one");
        vstr.push_back("delete one");
        vstr.push_back("set one");
        vstr.push_back("add one");
        vstr.push_back("update");
        vstr.push_back("size");
        vstr.push_back("get range");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_STORAGE_GET_SINGLE);
        vid.push_back(NB_FUNC_STORAGE_GET_MORE);
        vid.push_back(NB_FUNC_STORAGE_HAS_KEY);
        vid.push_back(NB_FUNC_STORAGE_INSERT_ONE);
        vid.push_back(NB_FUNC_STORAGE_REPLACE_ONE);
        vid.push_back(NB_FUNC_STORAGE_DELETE_ONE);
        vid.push_back(NB_FUNC_STORAGE_SET_ONE);
        vid.push_back(NB_FUNC_STORAGE_ADD_ONE);
        vid.push_back(NB_FUNC_STORAGE_UPDATE);
        vid.push_back(NB_FUNC_STORAGE_SIZE);
        vid.push_back(NB_FUNC_STORAGE_GET_RANGE);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        //switch (hdecl.get_func_type())
        //{
        //    default:
        //        ret = false;
        //        break;
        //}
        return ret;
    }

private:
    static void make_is_oint_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        out.push_back(hi);
    }

    static void make_is_iany_iany_ibool_os_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hb(NB_INTERFACE_BOOL);
        in.push_back(hs);
        in.push_back(hn);
        in.push_back(hn);
        in.push_back(hb);
        out.push_back(hs);
    }

    static void make_is_iany_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(hs);
        in.push_back(hn);
        out.push_back(hn);
    }

    static void make_is_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(hs);
        out.push_back(har);
    }

    static void make_is_iany_os_oany_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t hb(NB_INTERFACE_BOOL);
        dukeid_t hn(NB_INTERFACE_NONE);
        in.push_back(hs);
        in.push_back(hn);
        out.push_back(hb);
        out.push_back(hn);
    }

    static void make_is_os_oarray_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t hs(NB_INTERFACE_STORAGE);
        dukeid_t har(NB_INTERFACE_ARRAY);
        in.push_back(hs);
        out.push_back(hs);
        out.push_back(har);
    }
};

class duke_logic_static_root_access : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "access";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            name = "create container";
            break;
        case NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER:
            name = "destroy container";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
            name = "get cont def";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
            name = "get storage";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
            name = "get storage type";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            name = "get anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
            name = "generate access from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            name = "get access interface from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST:
            name = "get anchor list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST:
            name = "get storage list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS:
            name = "get access";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT:
            name = "get storage content";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("create container");
        vstr.push_back("destroy containter");
        vstr.push_back("get cont def");
        vstr.push_back("get storage");
        vstr.push_back("get storage type");
        vstr.push_back("get anchor");
        vstr.push_back("generate access from anchor");
        vstr.push_back("get access interface from anchor");
        vstr.push_back("get anchor list");
        vstr.push_back("get storage list");
        vstr.push_back("get access");
        vstr.push_back("get storage content");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER);
        vid.push_back(NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_CONT_DEF);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_ACCESS);
        vid.push_back(NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            make_ides_oacc_declaration(in, out);
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            make_iint_oanc_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ides_oacc_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_CONTAINER_DEF);
        nb_id_t ho(NB_INTERFACE_ROOT_ACCESS);

        in.push_back(ho);
        in.push_back(hi);
        out.push_back(ho);
    }

    static void make_iint_oanc_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_ROOT_ACCESS);
        nb_id_t hii(NB_INTERFACE_INT);
        nb_id_t ho(NB_INTERFACE_ANCHOR);

        in.push_back(hi);
        in.push_back(hii);
        out.push_back(ho);
    }

};

class duke_logic_static_container_def : public duke_object_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "container def";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER:
            name = "create container";
            break;
        //case NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE:
        //    name = "get storage type";
        //    break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("create container");
        //vstr.push_back("get storage type");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        vid.push_back(NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER);
        //vid.push_back(NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE);
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER:
            make_ides_oacc_declaration(in, out);
            break;
        //case NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE:
        //    make_iint_oanc_declaration(in, out);
        //    break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ides_oacc_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_CONTAINER_DEF);
        nb_id_t ho(NB_INTERFACE_ROOT_ACCESS);

        in.push_back(hi);
        out.push_back(ho);
    }

    static void make_iint_oanc_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_ROOT_ACCESS);
        nb_id_t hii(NB_INTERFACE_INT);
        nb_id_t ho(NB_INTERFACE_ANCHOR);

        in.push_back(hi);
        in.push_back(hii);
        out.push_back(ho);
    }
};

class duke_object_static_bridge : public duke_object_static_base
{
public:
    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        if(hdecl.is_function_bridge_compose())
            name = "compose";
        else if(hdecl.is_function_bridge_decompose())
            name = "decompose";
        else
            LOG_ERROR("duke_object_static_bridge::get_declaration_name() error");

        /*switch (hdecl.get_func_type())
        {
        case NB_FUNC_BRIDGE_COMPOSE:
            name = "compose";
            break;
        case NB_FUNC_BRIDGE_DECOMPOSE:
            name = "decompose";
            break;
        default:
            ret = false;
            break;
        }*/

        return true;
    }

    static bool get_builtin_instructions(dukeid_vector& vid)
    {
#if 0
        bridge_interface bif(ifid);
        bif.get_declarations(vdecl);
//        get_general_interface(vid);
#endif
        return true;
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        LOG_DEBUG("*** get_interfaces, declaration id="<<hdecl.str());
#if 0
        bridge_declaration bridecl(hdecl);
        bridge_interface briif(bridecl.get_interface());
        briif.get_declarations(out);

        dukeid_t hbridge(NBID_TYPE_INTERFACE_BRIDGE);
        in.push_back(hbridge);
#endif
        return true;
    }

private:
    static void make_iuser_iarray_ouser_declaration(dukeid_vector& in, dukeid_vector& out)
    {
        dukeid_t harr(NB_INTERFACE_ARRAY);
        dukeid_t hbridge(NBID_TYPE_OBJECT_BRIDGE_INTERFACE);
        in.push_back(hbridge);
        in.push_back(harr);
        out.push_back(hbridge);
    }
};



class duke_logic_static_declaration
{
public:
    static bool get_interfaces(const dukeid_t& did,
                                dukeid_vector& iids, dukeid_vector& oids,
                                const dukeid_t& owner_if = NB_INTERFACE_NONE)
    {
        assert(did.is_function_instruction());
        if (!did.is_function_instruction())
            return false;

        nb_id_t ins = did.get_nb_type();

        // NB_FUNC_INTERFACE_CONVERT
        // we need special process here
        if(NB_FUNC_INTERFACE_CONVERT == ins.get_func_type())
        {
            iids.push_back(NB_INTERFACE_INTERFACE);
            iids.push_back(NB_INTERFACE_NONE);
            oids.push_back(owner_if);
        }
        else
        {
            nb_id_vector vin, vout;
            if (obj_impl_declaration::get_interfaces(ins, vin, vout))
            {
                // convert nb_id_vector to dukeid_vector
                for(nb_id_vector_it it = vin.begin(); it != vin.end(); ++it)
                    iids.push_back(*it);
                for(nb_id_vector_it it = vout.begin(); it != vout.end(); ++it)
                    oids.push_back(*it);
            }
            else
            {
                assert(!"wrong declaration type in duke_logic_static_declaration::get_interfaces()");
                return false;
            }
        }

        return true;
    }

    static bool get_builtin_name(const dukeid_t& did, std::string& name)
    {
        nb_id_t ins = did.get_nb_type();
        assert(ins.is_function_instruction());

        return obj_impl_declaration::get_instruction_name(ins, name);

        /*
        bool ret = false;
        if (did.is_function_instruction())
        {
            if (did.is_instruction_general())
                ret = duke_object_static_base::get_general_declaration_name(did, name);
            else if (did.is_instruction_bool())
                ret = duke_object_static_boolean::get_declaration_name(did, name);
            else if (did.is_instruction_int())
                ret = duke_object_static_integer::get_declaration_name(did, name);
            else if (did.is_instruction_float())
                ret = duke_object_static_float::get_declaration_name(did, name);
            else if (did.is_instruction_string())
                ret = duke_object_static_string::get_declaration_name(did, name);
            else if (did.is_instruction_bytes())
                ret = duke_object_static_bytes::get_declaration_name(did, name);
            else if (did.is_instruction_interval())
                ret = duke_object_static_interval::get_declaration_name(did, name);
            else if (did.is_instruction_time())
                ret = duke_object_static_time::get_declaration_name(did, name);
            else if (did.is_instruction_array())
                ret = duke_object_static_array::get_declaration_name(did, name);
            else if (did.is_instruction_map())
                ret = duke_object_static_map::get_declaration_name(did, name);
            else if (did.is_instruction_user())
                ret = duke_object_static_user::get_declaration_name(did, name);
            else if (did.is_instruction_storage())
                ret = duke_logic_static_storage::get_declaration_name(did, name);
            else if (did.is_instruction_bridge())
                ret = duke_object_static_bridge::get_declaration_name(did, name);
            else
            {
                assert(!"wrong declaration type in duke_logic_static_declaration::get_builtin_name()");
            }
        }
        return ret;
        */
    }
};


class duke_logic_static_interface
{
public:
    static bool get_general_instructions(dukeid_vector& vdecl)
    {
        nb_id_vector vins;
        obj_impl_interface::get_general_instructions(vins);

        // convert nb_id_vector to dukeid_vector
        nb_id_vector_to_dukeid_vector(vins, vdecl);

        return true;
    }

    static bool get_builtin_instructions(const dukeid_t& ifid, dukeid_vector& vdecl)
    {
        assert(ifid.is_builtin_interface() || ifid.is_interface_compound());
                if(ifid.is_builtin_interface())
                {
                vdecl.clear();
                }

        nb_id_t interface = ifid.get_nb_type();
        nb_id_vector vins;
        obj_impl_interface::get_builtin_instructions(interface, true, vins);

        // convert nb_id_vector to dukeid_vector
        nb_id_vector_to_dukeid_vector(vins, vdecl);

        return true;
    }

    static bool get_builtin_name(const dukeid_t& ifid, std::string& name)
    {
        assert(ifid.is_builtin_interface());

        // read name from core module
        return obj_impl_interface::get_interface_name(ifid.get_nb_type(), name);
    }
};


struct duke_logic_static_registered_anchor : public duke_object_static_base
{
    static bool get_name(std::string& name)
    {
        name = "registered anchor";
        return true;
    }

    static bool get_declaration_name(const dukeid_t& hdecl, std::string& name)
    {
        bool ret = true;
        /*switch (hdecl.get_func_type())
        {
        case NB_FUNC_REGISTERED_ANCHOR_SET:
            name = "set";
            break;
        case NB_FUNC_REGISTERED_ANCHOR_GET:
            name = "get";
            break;
        case NB_FUNC_REGISTERED_ANCHOR_GET_ALL:
            name = "get all";
            break;
        case NB_FUNC_REGISTERED_ANCHOR_SIZE:
            name = "size";
            break;
        case NB_FUNC_REGISTERED_ANCHOR_CREATE_ACCESS:
            name = "create access";
            break;
        case NB_FUNC_REGISTERED_ANCHOR_DESTROY_ACCESS:
            name = "destroy access";
            break;
        default:
            ret = false;
            break;
        }*/
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("set");
        vstr.push_back("get");
        vstr.push_back("get all");
        vstr.push_back("size");
        vstr.push_back("create access");
        vstr.push_back("destroy access");
    }

    static void get_builtin_instructions(dukeid_vector& vid)
    {
        /*
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_SET);
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_GET);
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_GET_ALL);
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_SIZE);
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_CREATE_ACCESS);
        vid.push_back(NB_FUNC_REGISTERED_ANCHOR_DESTROY_ACCESS);*/
    }

    static bool get_interfaces(const dukeid_t& hdecl, dukeid_vector& in, dukeid_vector& out)
    {
        bool ret = true;
        /*switch (hdecl.get_func_type())
        {
        case NB_FUNC_REGISTERED_ANCHOR_SET:
            make_ianchor_iany_iac_oanchor_declaration(in, out);
            break;
        case NB_FUNC_REGISTERED_ANCHOR_GET:
            make_ianchor_iac_oanchor_oany_declaration(in, out);
            break;
        case NB_FUNC_REGISTERED_ANCHOR_GET_ALL:
            make_ianchor_oanchor_oarr_declaration(in, out);
            break;
        case NB_FUNC_REGISTERED_ANCHOR_SIZE:
            make_ianchor_oanchor_oint_declaration(in, out);
            break;
        case NB_FUNC_REGISTERED_ANCHOR_CREATE_ACCESS:
            make_ianchor_iany_icon_oanchor_oac_declaration(in, out);
            break;
        case NB_FUNC_REGISTERED_ANCHOR_DESTROY_ACCESS:
            make_ianchor_iac_oanchor_oany_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }*/
        return ret;
    }

private:
    static void make_ianchor_iany_iac_oanchor_declaration(std::vector<dukeid_t>& in, std::vector<dukeid_t>& out)
    {
        dukeid_t han(NB_INTERFACE_ANCHOR);
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hac(NB_INTERFACE_ROOT_ACCESS);
        in.push_back(han);
        in.push_back(hn);
        in.push_back(hac);
        out.push_back(han);
    }

    static void make_ianchor_iac_oanchor_oany_declaration(std::vector<dukeid_t>& in, std::vector<dukeid_t>& out)
    {
        dukeid_t han(NB_INTERFACE_ANCHOR);
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hac(NB_INTERFACE_ROOT_ACCESS);
        in.push_back(han);
        in.push_back(hac);
        out.push_back(han);
        out.push_back(hn);
    }

    static void make_ianchor_oanchor_oarr_declaration(std::vector<dukeid_t>& in, std::vector<dukeid_t>& out)
    {
        dukeid_t han(NB_INTERFACE_ANCHOR);
        dukeid_t harr(NB_INTERFACE_ARRAY);
        in.push_back(han);
        out.push_back(han);
        out.push_back(harr);
    }

    static void make_ianchor_oanchor_oint_declaration(std::vector<dukeid_t>& in, std::vector<dukeid_t>& out)
    {
        dukeid_t han(NB_INTERFACE_ANCHOR);
        dukeid_t hi(NB_INTERFACE_INT);
        in.push_back(han);
        out.push_back(han);
        out.push_back(hi);
    }

    static void make_ianchor_iany_icon_oanchor_oac_declaration(std::vector<dukeid_t>& in, std::vector<dukeid_t>& out)
    {
        dukeid_t han(NB_INTERFACE_ANCHOR);
        dukeid_t hn(NB_INTERFACE_NONE);
        dukeid_t hcon(NB_INTERFACE_CONTAINER);
        dukeid_t hac(NB_INTERFACE_ROOT_ACCESS);
        in.push_back(han);
        in.push_back(hn);
        in.push_back(hcon);
        out.push_back(han);
        out.push_back(hac);
    }
};


#endif // __NB_LOGIC_OBJECT_STATIC_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
