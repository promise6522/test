/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#include "duke_constant_def.h"

#include "ac_object/obj_impl_declaration.h"


void get_array_builtin_instructions(dukeid_vector& vins)
{
    size_t pre_sz = vins.size();

    // enumerate array instructions
    uint32_t ins = NB_FUNC_ARRAY_INSTRUCTION + 1;
    for(; ins<NB_FUNC_ARRAY_INSTRUCTION_END; ++ins)
        vins.push_back(static_cast<nb_builtin_instruction_t>(ins)); 

    LOG_DEBUG("get_array_builtin_instructions: size = " << vins.size()-pre_sz);
}


void get_map_builtin_instructions(dukeid_vector& vins)
{
    size_t pre_sz = vins.size();

    // enumerate map instructions
    uint32_t ins = NB_FUNC_MAP_INSTRUCTION + 1;
    for(; ins<NB_FUNC_MAP_INSTRUCTION_END; ++ins)
        vins.push_back(static_cast<nb_builtin_instruction_t>(ins)); 

    LOG_DEBUG("get_map_builtin_instructions: size = " << vins.size()-pre_sz);
}


void get_storage_builtin_instructions(dukeid_vector& vins)
{
    size_t pre_sz = vins.size();

    // enumerate storage instructions
    uint32_t ins = NB_FUNC_STORAGE_INSTRUCTION + 1;
    for(; ins<NB_FUNC_STORAGE_INSTRUCTION_END; ++ins)
        vins.push_back(static_cast<nb_builtin_instruction_t>(ins)); 

    LOG_DEBUG("get_storage_builtin_instructions: size = " << vins.size()-pre_sz);
}

void dump_decl_compound(const dukeid_t& id, const duke_logic_data_declare_compound& data)
{
    std::string name;
    obj_impl_declaration::get_instruction_name(id.get_nb_type(), name);
    LOG_DEBUG("Declaration{ "<<name<<" }");

    LOG_DEBUG("##iports.size() = "<<data.iports.size());
    LOG_DEBUG("##oports.size() = "<<data.oports.size());
    LOG_DEBUG("##groups.size() = "<<data.groups.size());
    for(size_t i = 0; i < data.groups.size(); ++i)
    {
        LOG_DEBUG("####groups["<<i<<"].members.size() = "<<data.groups[i].members.size());
        for(size_t j = 0; j < data.groups[i].members.size(); ++j)
        {
            LOG_DEBUG("######groups["<<i<<"].members["<<j<<"].is_input = "<<data.groups[i].members[j].is_input); 
            LOG_DEBUG("######groups["<<i<<"].members["<<j<<"].port_idx = "<<data.groups[i].members[j].port_idx); 
            LOG_DEBUG("######groups["<<i<<"].members["<<j<<"].relay_idx = "<<data.groups[i].members[j].relay_idx); 
        }
    }
}

bool get_builitin_decl_compound(const dukeid_t& id, duke_logic_data_declare_compound& data)
{
    nb_id_t decl_id = id.get_nb_type();

    // TODO add more builtin-instruction set here
    assert(decl_id.is_instruction_array() 
        || decl_id.is_instruction_map()
        || decl_id.is_instruction_storage());

    static bool _init = false;
    static std::map< nb_id_t, duke_logic_data_declare_compound > _decl_info_map;

    // if already inited, return the corresponding map entry
    if(_init) {
        data = _decl_info_map[decl_id];
        dump_decl_compound(id, data);//DEBUG
        return true;
    }
    
    /*
     * init the { declaration_id <----> decl_compound data } mapping
     */
    dukeid_vector builtin_decls;
    get_array_builtin_instructions(builtin_decls);
    get_map_builtin_instructions(builtin_decls);
    get_storage_builtin_instructions(builtin_decls);

    dukeid_vector_iterator it = builtin_decls.begin();
    for(; it != builtin_decls.end(); ++it)
    {
        detail::decl_template_def decl;

        // #### array instruction definations ####
        if (it->is_instruction_array()) 
        {
            decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);

            switch(it->get_func_type())
            {
                case NB_FUNC_ARRAY_SETTYPE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 0);
                    //decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_NONE, 0);
                    break;
                }
                case NB_FUNC_ARRAY_GETTYPE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 0);
                    break;
                }
                case NB_FUNC_ARRAY_GET:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    break;
                }

                case NB_FUNC_ARRAY_GETHEAD:
                case NB_FUNC_ARRAY_GETTAIL:
                {
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    break;
                }

                case NB_FUNC_ARRAY_SIZE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    break;
                }

                case NB_FUNC_ARRAY_SET:
                case NB_FUNC_ARRAY_INSERT:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_ERASE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_ADDHEAD:
                case NB_FUNC_ARRAY_ADDTAIL:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }
                case NB_FUNC_ARRAY_FIND:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    break;
                }

                case NB_FUNC_ARRAY_RANGE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_SPLIT:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_SPLITAT:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_REVERSE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_JOIN:
                case NB_FUNC_ARRAY_UNIONSET:
                case NB_FUNC_ARRAY_INTERSECTIONSET:
                case NB_FUNC_ARRAY_COMPLEMENTARYSET:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }

                case NB_FUNC_ARRAY_INCLUSION:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    break;
                }
            
                case NB_FUNC_ARRAY_CONTENT_COMPARE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    break;
                }

                default:
                    LOG_ERROR("unknown array instruction!");
                    //assert(false);
            }
        }

        // #### map instruction definations ####
        else if (it->is_instruction_map())
        {
            decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);

            switch(it->get_func_type())
            {
                case NB_FUNC_MAP_SETTYPE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 0);
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 1);
                    //decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_NONE, 0);
                    break;
                }
                case NB_FUNC_MAP_GETTYPE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INTERFACE, 1);
                    break;
                }
                case NB_FUNC_MAP_GET_OR:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    break;
                }
                case NB_FUNC_MAP_GET:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    break;
                }
                case NB_FUNC_MAP_INSERT:
                case NB_FUNC_MAP_REPLACE:
                case NB_FUNC_MAP_UPDATE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    break;
                }
                case NB_FUNC_MAP_ERASE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    break;
                }
                case NB_FUNC_MAP_HAS_KEY:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    break;
                }
                case NB_FUNC_MAP_SIZE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    break;
                }
                case NB_FUNC_MAP_GETALLKEYS:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }
                case NB_FUNC_MAP_CONTENT_COMPARE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    break;
                }

                default:
                    LOG_ERROR("unknown map instruction!");
            }
        }

        // #### storage instruction definations ####
        else if (it->is_instruction_storage())
        {
            decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_STORAGE_SIMPLE, 1|2);

            switch(it->get_func_type())
            {
                case NB_FUNC_STORAGE_GET_SINGLE:
                case NB_FUNC_STORAGE_DELETE_ONE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    break;
                }
                case NB_FUNC_STORAGE_GET_MORE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    break;
                }
                case NB_FUNC_STORAGE_HAS_KEY:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    break;
                }
                case NB_FUNC_STORAGE_REPLACE_ONE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    decl.add_oport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    break;
                }
                case NB_FUNC_STORAGE_SET_ONE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 0);
                    decl.add_iport_def(detail::PORT_TYPE_GROUP, NB_INTERFACE_NONE, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_BOOL, 0);
                    break;
                }
                case NB_FUNC_STORAGE_UPDATE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    decl.add_iport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 2);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_ARRAY, 1);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    break;
                }
                case NB_FUNC_STORAGE_SIZE:
                {
                    decl.add_oport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    break;
                }
                case NB_FUNC_STORAGE_GET_RANGE:
                {
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_iport_def(detail::PORT_TYPE_NORMAL, NB_INTERFACE_INT, 0);
                    decl.add_oport_def(detail::PORT_TYPE_NESTED, NB_INTERFACE_MAP, 1|2);
                    break;
                }
                default:
                    LOG_ERROR("unknown storage instruction!");
                    //assert(false);
            }
        }

        // convert to the actual decl_compound data-structure
        duke_logic_data_declare_compound decl_comp;
        decl.get_decl_compound(decl_comp);
        _decl_info_map[it->get_nb_type()] = decl_comp;

    } /* end of for */

    _init = true;
    LOG_DEBUG("get_builtin_decl_compound: instruction mapping inited!");

    data = _decl_info_map[decl_id];
    dump_decl_compound(id, data);//DEBUG

    return true;
}

bool get_builtin_interface_compound(const dukeid_t& if_id, duke_logic_data_interface_compound& data)
{
    assert(if_id.is_builtin_interface());

    //** trivial fields **
    //name = ?
    //m_type = ?
    //data.m_ifc = ?
    data.m_singleton = false;

    //** expansion group **
    data.m_hext.clear();
    //TODO

    switch(if_id.get_interface_type())
    {
        case NB_INTERFACE_ARRAY:
        { 
            get_array_builtin_instructions(data.m_decls);
            break;
        }
        case NB_INTERFACE_MAP:
        {
            get_map_builtin_instructions(data.m_decls);
            break;
        }
        case NB_INTERFACE_STORAGE_SIMPLE:
        {
            get_storage_builtin_instructions(data.m_decls);
            break;
        }
        default:
            LOG_ERROR("get_builtin_interface_compound error.");
            return false;
    }

    return true;
}


namespace detail {


bool decl_template_def::get_decl_compound(duke_logic_data_declare_compound& data) const
{
    std::vector<duke_exp_group> groups;

    // for input ports
    std::vector<decl_port_def>::const_iterator it;
    int port_idx = 0;

    it = this->iport_defs.begin();
    for (; it != this->iport_defs.end(); ++it, ++port_idx)
    {
        // fill in iports
        duke_iport iport;
        iport.interface = it->interface;
        data.iports.push_back(iport);

        // gen groups info
        gen_groups_from_port_def(*it, port_idx, groups); 
    }

    // for output ports
    port_idx = 0;
    it = this->oport_defs.begin();
    for (; it != this->oport_defs.end(); ++it, ++port_idx)
    {
        // fill in oports
        duke_oport oport;
        oport.interface = it->interface;
        data.oports.push_back(oport);

        // gen groups info 
        gen_groups_from_port_def(*it, port_idx, groups); 
    }

    data.groups = groups;

    return true;
}

bool gen_groups_from_port_def(const decl_port_def& port, 
        const int port_idx, 
        std::vector<duke_exp_group>& groups)
{
    // get port type
    decl_port_type ptype = port.ptype;
    switch (ptype)
    {
        case PORT_TYPE_NORMAL:
            // no group info
            break;
        case PORT_TYPE_GROUP:
        {
            size_t group_idx = port.idx;
            if (groups.size() < group_idx +1)
            {
                groups.resize(group_idx+1);
                groups[group_idx].min_if = NB_INTERFACE_NONE;
                groups[group_idx].expanded = false;
                groups[group_idx].members.clear();
            }
            duke_exp_idx idx = {port.input, port_idx, -1};
            groups[group_idx].members.push_back(idx);
            break;
        }
        case PORT_TYPE_NESTED:
        {
            int group_idxs = port.idx; 
            // group_idxs is a combine of bits represents deferenet groups
            // for simplicity here, we check at most 2
            // (2 is enough for array/map/storage/etc)
            if (group_idxs & 1)
            {
                if (groups.size() < 1)
                {
                    groups.resize(1);
                    groups[0].min_if = NB_INTERFACE_NONE;
                    groups[0].expanded = false;
                    groups[0].members.clear();
                }
                duke_exp_idx idx = {port.input, port_idx, 0};
                groups[0].members.push_back(idx);
            }
            if (group_idxs & 2) 
            {                   
                if (groups.size() < 2)
                {
                    groups.resize(2);
                    groups[1].min_if = NB_INTERFACE_NONE;
                    groups[1].expanded = false;
                    groups[1].members.clear();
                }
                duke_exp_idx idx = {port.input, port_idx, 1};
                groups[1].members.push_back(idx);
            }
            break;
        }
        default:
            assert(false);
            return false;
    }

    return true;
}

}/* namesapce detail */
