/****************************************************************************
**
** Copyright 2011 Duke Inc.
**
****************************************************************************/

#include "duke_logic_id.h"
#include "duke_logic_object_data.h"

bool nb_handle::is_persistent_type() const
{
    return !this->is_object_none() &&

           !this->is_object_bool() &&
           !this->is_object_int() &&
           !this->is_object_float() &&
           !this->is_object_time() &&
           !this->is_object_interval() &&

           !this->is_builtin_interface() &&
           !this->is_function_instruction();
}


nb_handle_status nb_handle::get_value(std::string& strval) const
{
    strval.clear();

    NbDbResult ret;
    // ------------------------for DB Compatibility--------------------------------
    // ## normally we read tempdb first, then ac_object_db
    // ## for historical reasons sometimes we must read ac_object_db first

    if (this->get_type() == DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT ||
            this->is_interface_compound() ||
            this->is_object_array() ||
            this->is_object_map())
    {
        //1. tempobj_db
        ret = duke_media_tempobj_db::instance().read(this->str(), strval);
        if (NB_DB_RESULT_SUCCESS == ret)
            return e_handle_temp;

        //2. ac_object_db
        ret = ac_object_db_impl::instance().read(this->str(), strval);
        if (NB_DB_RESULT_SUCCESS == ret)
            return e_handle_core;
    }
    else
    {
        //1. ac_object_db
        ret = ac_object_db_impl::instance().read(this->str(), strval);
        if (NB_DB_RESULT_SUCCESS == ret)
            return e_handle_core;
        
        //2. tempobj_db
        ret = duke_media_tempobj_db::instance().read(this->str(), strval);
        if (NB_DB_RESULT_SUCCESS == ret)
            return e_handle_temp;
    }
   
    //3. formobj_db (for backward-compability)
    ret = duke_media_formobj_db::instance().read(this->str(), strval);
    if (NB_DB_RESULT_SUCCESS == ret)
        return e_handle_formal;

    //LOG_ERROR("duke_media_handle::get_value() : " << (*this).str() << " not found!");
    return e_handle_unknown;
}


bool nb_handle::set_value(const std::string& strval, DbTxn* txn)
{
    // write to tempobj db only when it's an editing handle
    nb_handle_status st = get_media_handle_status(*this);
    if (e_handle_temp == st || e_handle_unknown == st) 
        duke_media_tempobj_db::instance().write(this->str(), strval, txn);  

    // for back-ward compability, write a copy to tempobj_db
    else if (e_handle_formal == st)
        duke_media_tempobj_db::instance().write(this->str(), strval, txn);  

    return true;
}


nb_handle_status get_media_handle_status(const nb_handle& handle)
{
    // for non-persistent type, it's core
    if (!handle.is_persistent_type())
        return e_handle_core;

    // 
    std::string tmp;
    return handle.get_value(tmp);

    // // if can be found in ac_object_db, it's core
    // NbDbResult ret = ac_object_db_impl::instance().read(key, val);
    // if (NB_DB_RESULT_SUCCESS == ret)
    //     return e_handle_core;

    // // if can be found in tempobj_db, it's temp
    // ret = duke_media_tempobj_db::instance().read(key, val);
    // if (NB_DB_RESULT_SUCCESS == ret)
    //     return e_handle_temp;

    // // if can be found in formobj_db, it's formal
    // // we main formobj_db just for backward-compability
    // ret = duke_media_formobj_db::instance().read(key, val);
    // if (NB_DB_RESULT_SUCCESS == ret)
    //     return e_handle_formal;

    // // otherwise it's unkown
    // //LOG_ERROR("get_media_handle_status() = e_handle_unknown");

    // return e_handle_unknown;
}
