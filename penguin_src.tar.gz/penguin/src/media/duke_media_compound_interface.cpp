#include "duke_media_compound_interface.h"
#include "duke_media_global.h"


//this construction only for  duke_media_base_factory
duke_media_compound_interface::duke_media_compound_interface()
{
}


duke_media_compound_interface::duke_media_compound_interface(const host_committer_id_t& host_id,
        const std::string& username)
        : duke_media_base(DUKE_MEDIA_TYPE_INTERFACE_COMPOUND, host_id)
{
    //init general declarations
    duke_object_static_user::get_builtin_instructions(m_data.m_decls);

    //init save
    bool ret = init_save();
    assert(ret);
}


duke_media_compound_interface::duke_media_compound_interface(const duke_media_handle& hif, const std::string& username)
{
    //recover object data to data struct of object
    bool ret = this->assign(hif);
    assert(ret);
}

bool duke_media_compound_interface::set_data_to_handle(const duke_logic_data_interface_compound& if_data)
{
    if(e_handle_core == this->get_handle_status())
    {
        LOG_ERROR("duke_media_compound_interface::set_data_to_handle failed");
        return false;
    }

    m_data = if_data;
    return this->save();
}


dukeid_vector& duke_media_compound_interface::get_hext()
{
    return this->m_data.m_hext;
}

bool duke_media_compound_interface::get_expanded()
{
    return this->m_data.m_expanded;
}

bool duke_media_compound_interface::get_singleton() const
{
    return this->m_data.m_singleton;
}

bool duke_media_compound_interface::set_singleton(bool singleton)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    this->m_data.m_singleton = singleton;
    return this->save();
}

bool duke_media_compound_interface::get_icon(std::string& icon) const
{
	icon = m_data.m_icon; 
	return true;
}	

bool duke_media_compound_interface::set_icon(const std::string& icon)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

	m_data.m_icon = icon;
	return this->save();
}

bool duke_media_compound_interface::set_interface_name(const std::string& name)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

   	m_data.m_name = name;

    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);
   	return this->save();
}
bool duke_media_compound_interface::add_declaration(const duke_media_handle& hdecl)
{
    bool ret = (hdecl.is_declaration() || hdecl.is_function_instruction());
    assert(ret);
    if (ret)
    {
        if (!hdecl.is_instruction_general())
        {
            this->m_data.m_decls.push_back(hdecl);
            ret = this->save();
        }
    }
    return ret;
}

bool duke_media_compound_interface::set_declarations(const std::vector<duke_media_handle>& vhdecls)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    this->m_data.m_decls = vhdecls;
    bool ret = this->save();
    return ret;
}

bool duke_media_compound_interface::clear_declaration()
{
 	m_data.m_decls.clear();
    duke_object_static_user::get_builtin_instructions(m_data.m_decls);
	return this->save();
}

bool duke_media_compound_interface::del_declaration(const duke_media_handle& hdecl)
{
	bool ret = hdecl.is_declaration();
	assert(ret);
	if (ret)
	{
   	 	m_data.m_decls.erase(std::remove(m_data.m_decls.begin(), m_data.m_decls.end(), hdecl),
                         m_data.m_decls.end());
    	ret = this->save();
	}
	return ret;
}

bool duke_media_compound_interface::assign(const duke_media_handle& hif)
{
    //hif must be duke_media_compound_interface
    if(!hif.is_interface_compound())
    {
        return false;
    }

    //get data from database and assign it to compound interface data struct
    std::string value;
    this->set_handle_status( hif.get_value(value) );    //we can know where this id come from
    
    if(!value.empty())
    {
        //unpack data and set handle to this object
        this->unpack(value);
    }
    else
    {
        LOG_DEBUG("this compound interface: " << hif.str() << " has no data! May be new compound interface");
    }
    

    //assign handle to compound struct, some place need it
    m_data.m_ifc = hif;

    //set handle to this compound_interface
    this->set_handle(hif);

    return true;
}

bool duke_media_compound_interface::get_declarations(duke_media_handle_vector& vid) const
{
    vid = m_data.m_decls;
    return true;
}

bool duke_media_compound_interface::get_interfaces(duke_media_handle& vif) const
{
    vif = m_data.m_ifc;
    return true;
}

bool duke_media_compound_interface::set_interface(const duke_media_handle& hif)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    m_data.m_ifc = hif;
    return this->save();
}

bool duke_media_compound_interface::set_type(const duke_media_handle& htype)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    m_data.m_hext.push_back(htype);
    return this->save();
}

bool duke_media_compound_interface::clear_type()
{
    m_data.m_hext.clear();
    return this->save();
}

bool duke_media_compound_interface::get_type(duke_media_handle& htype)
{
    htype = get_extension_types(0);
    return true;
}

bool duke_media_compound_interface::is_interface_array() const 
{
    for(std::size_t i = 0; i < m_data.m_decls.size(); ++i)
    {
        if(m_data.m_decls.at(i).is_object_decl_expanded())
        {
            duke_media_declare_expanded  tmp(m_data.m_decls.at(i));
            if(tmp.get_decl_id().is_instruction_array())
            {
                return true;
            }
        }
    }
    return false;
}

bool duke_media_compound_interface::is_interface_user() const 
{
    return m_data.m_type.get_interface_compound_type() == NB_INTERFACE_USER;
}

bool duke_media_compound_interface::is_interface_map() const 
{
    for(std::size_t i = 0; i < m_data.m_decls.size(); ++i)
    {
        if(m_data.m_decls.at(i).is_object_decl_expanded())
        {
            duke_media_declare_expanded  tmp(m_data.m_decls.at(i));
            if(tmp.get_decl_id().is_instruction_map())
            {
                return true;
            }
        }
    }
    return false;
}

bool duke_media_compound_interface::is_interface_access() const 
{
    return m_data.m_type.get_interface_compound_type() == NB_INTERFACE_ACCESS;
}

bool duke_media_compound_interface::is_interface_storage() const 
{
    return m_data.m_type.get_interface_compound_type() == NB_INTERFACE_STORAGE;
}

bool duke_media_compound_interface::set_decl_type(const duke_media_handle& htype)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    m_data.m_type = htype;
    return this->save();
}

bool duke_media_compound_interface::get_decl_type(duke_media_handle& htype)
{
    htype = m_data.m_type;
    return true;
}

duke_media_handle duke_media_compound_interface::get_extension_types(int index)
{
    if (m_data.m_hext.size() > 0)
        return m_data.m_hext[index];
    else
    {
        duke_media_handle id(NBID_TYPE_NULL);
        return id;
    }
}

duke_media_handle duke_media_compound_interface::get_id() const
{
    return get_handle();
}

bool duke_media_compound_interface::get_name(std::string& name) const
{
    duke_media_handle hif = get_handle();
    assert(hif.is_interface_compound());

    if (m_data.m_name.empty())
    {
        if(this->is_interface_map())
        {
            name = "map[interface]";
        }
        else if(this->is_interface_array())
        {
            name = "array[interface]";
        }
        else
        {
            name = "default-name";
        }
        return true;
    }
    name = m_data.m_name;
    return true;
}

bool duke_media_compound_interface::set_name(const std::string& name)
{
    //handle exist in core db, and it's data can not be change
    if(e_handle_core == this->get_handle_status())
    {
        return false;
    }

    m_data.m_name = name;
    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);
    return this->save();
}

bool duke_media_compound_interface::match(const duke_media_handle& hif) const
{
    assert(hif.is_interface());
    duke_media_handle_vector hdecls;
    if (hif.is_builtin_interface() || hif.is_user_interface() || hif.is_interface_compound())
    {
        duke_media_compound_interface mif(hif);
        mif.get_declarations(hdecls);
    }
    return stdx::unordered_match(m_data.m_decls.begin(), m_data.m_decls.end(),
            hdecls.begin(), hdecls.end());
}

bool duke_media_compound_interface::cover(const duke_media_handle& hif) const
{
    assert(hif.is_interface());
    duke_media_handle_vector hdecls;
    if (hif.is_builtin_interface() || hif.is_user_interface() || hif.is_interface_compound())
    {
        duke_media_compound_interface mif(hif);
        mif.get_declarations(hdecls);
    }
    return stdx::unordered_includes(hdecls.begin(), hdecls.end(),m_data.m_decls.begin(), m_data.m_decls.end());

}

bool duke_media_compound_interface::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{       
//    bool ret = duke_media_clear_pair_handle(this->get_handle());
//    assert(ret);
//
//    std::string strkey = username + "-interface-compound";
//    std::string strval;
//    assert(this->get_handle().is_interface_compound());
//
//    duke_media_compound_interface compound(host_id);
//    ret = compound.copy(this->get_handle());
//   
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(compound.get_handle(), strname);
//    assert(ret);
//
//    if (hfather.is_type_null())
//        return ret;
//    if (hfather != this->get_handle())
//    {
//        ret = duke_media_write_pair_handle(hfather, this->get_handle(), compound.get_handle());
//        assert(ret);
//    }
//
//    ret  = this->get_handle().get_value(strval);
//    assert(ret);
//    compound.unpack(strval);
//
//    replace_content(username, strval, host_id, hfather, compound.get_handle());
//
//    compound.unpack(strval);
//
//    compound.pack_new_structure();
//
//    ret = compound.get_handle().set_value(strval);
//    assert(ret);
//
//    duke_media_remove_handle("anonymous-name-tmp-compound-interface", compound.get_handle());
//    duke_media_remove_handle(username + "-tmp-compound-interface", compound.get_handle());
//
//    if (strname != "array-interface")
//    {
//        strval = "";
//        assert(ret = duke_media_read_handle(strkey, strval) ); 
//        strval += "(" + compound.get_handle().str() + ")";
//        assert(ret = duke_media_write_handle(strkey, strval) );
//    }
//    handle = compound.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(compound.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << compound.get_handle().str() << " interface compound in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << compound.get_handle().str() << " interface compound in temp media failed;");
//
//    return ret;
    return true;
}

bool duke_media_compound_interface::copy(const duke_media_handle& hifc)
{
    bool ret = false;
    //assert(hifc.is_bridge_interface());
    if (hifc.is_interface_compound())
    {
        std::string strval;
        ret = hifc.get_value(strval);
        assert(ret);
        if (!strval.empty())
            this->unpack(strval);
        ret = this->save();
        assert(ret);
    }
    return ret;
}

std::string duke_media_compound_interface::pack() const
{
    return pack_helper();
}

std::string duke_media_compound_interface::pack_helper() const
{
    return m_data.pack();
}

void duke_media_compound_interface::unpack(const std::string& strif)
{
    unpack_helper(strif);
}

void duke_media_compound_interface::unpack_helper(const std::string& strif)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_data.unpack(strif);
    }
    else if (status == e_handle_core)
    {
        if (!strif.empty())
        {
            content value;
            unpack_object(strif, value);

            if_compound_data_t temp_data; 
            obj_impl_interface_compound::unpack(value, id, temp_data);

            m_data.m_name = temp_data.name;
            m_data.m_singleton = temp_data.is_singleton;

            //push decl to duke_media_compound_interface from core struct
            for (std::vector<nb_id_t>::const_iterator it = temp_data.decls.begin(); 
                    it != temp_data.decls.end(); ++it)
            {
                m_data.m_decls.push_back(*it);
            }
          
            //push min_if,
            std::vector<if_exp_group>::const_iterator it;
            for (it = temp_data.groups.begin(); it != temp_data.groups.end(); ++it)
            {
                m_data.m_hext.push_back(it->min_if);
            }
        }
    }
    else
    {
        LOG_ERROR("object handle: " << this->get_handle().str() << " has not exist in db");
    }
}

bool duke_media_compound_interface::pack_new_structure()
{
//    //pack new structure
//    if_compound_data_t tmp_data;
//    tmp_data.name = m_data.m_name;
//    //tmp_data. = m_ifc.m_singleton;
//
//    for (duke_media_handle_const_iterator it = m_data.m_decls.begin(); it != m_data.m_decls.end(); ++it)
//    {
//        nb_id_t nb_id;
//        nb_id.str((*it).str());
//        tmp_data.decls.push_back(nb_id);
//        LOG_NOTICE((*it).str());
//    }
//
//    // fill the min if
//    /*
//    if (m_data.m_type.is_array_type())
//    {
//        if_exp_group group;
//        if (m_data.m_hext.size() != 0)
//            group.min_if.str(m_data.m_hext[0].str());
//        tmp_data.groups.push_back(group);
//    }
//    else if (m_data.m_type.is_storage_type() || m_data.m_type.is_map_type())
//    {
//        if_exp_group group, group1;
//        if (m_data.m_hext.size() == 2)
//        {
//            if (m_data.m_hext[0].is_type_null()) 
//                LOG_ERROR("map key type is null");
//            group.min_if.str(m_data.m_hext[0].str());
//            group1.min_if.str(m_data.m_hext[1].str());
//        }
//        tmp_data.groups.push_back(group);
//        tmp_data.groups.push_back(group1);
//    }*/
//
//    for (duke_media_handle_const_iterator it = m_data.m_hext.begin(); it != m_data.m_hext.end(); ++it)
//    {
//        if_exp_group group;
//        group.min_if.str(it->str());
//        tmp_data.groups.push_back(group);
//    }
//
//    ////////////////
//    //tmp_data.type.str(m_data.m_type.str());
//    //tmp_data.type.str(m_data.m_hext[0].str());
//
//    //nb_id_t id;
//    id.str(this->get_handle().str());
//
//    content tmp_content;
//    obj_impl_interface_compound::pack(tmp_data, id, tmp_content);
//    //db_value tmp_value;
//    //tmp_value.all_objects.push_back(tmp_content);
//    std::string strval = pack_object(tmp_content);
//
//    ac_object_db_impl::instance().write_(id.str(), strval);
//    
    return true;
}

//bool duke_media_compound_interface::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather, const duke_media_handle& newhandle)
//{
//    for( std::vector<dukeid_t>::iterator it=m_data.m_decls.begin(); it!=m_data.m_decls.end(); ++it)
//    {
//        assert(it->is_declaration());
//        if(it->is_function_instruction())
//            continue;
//
//        if (it->is_function_compose())
//        {
//            duke_media_handle hdecl;
//            duke_media_compound_declare decl(*it);
//            bool ret = decl.generate(username, hdecl, host_id, hfather);
//            assert(ret);
//
//            duke_media_compound_declare newdecl(hdecl);
//            newdecl.clear_output_ports();
//            newdecl.add_output_port(newhandle);
// //delete pack_new_struct           newdecl.pack_new_structure();
//            duke_media_replace_handle(strval, *it, hdecl);
//        }
//
//        if (it->is_function_decompose())
//        {
//            duke_media_handle hdecl;
//            duke_media_compound_declare decl(*it);
//            bool ret = decl.generate(username, hdecl, host_id, hfather);
//            assert(ret);
//
//            duke_media_compound_declare newdecl(hdecl);
// //delete pack_new_struct           newdecl.pack_new_structure();
//            duke_media_replace_handle(strval, *it, hdecl);
//        }
//
//        if (it->is_object_decl_expanded())
//        {
//            duke_media_handle hdecl;
//            bool ret = duke_media_read_pair_handle(hfather, *it, hdecl);
//            assert(ret);
//            if (hdecl.is_type_null())
//            {
//                duke_media_declare_expanded decl(*it);
//                bool ret = decl.generate(username, hdecl, host_id, hfather);
//                assert(ret);
//            }
//            duke_media_replace_handle(strval, *it, hdecl);
//        }
//
//        if (duke_media_get_handle_status(username, *it) == Edit)
//        {
//            duke_media_handle hdecl;
//            bool ret = duke_media_read_pair_handle(hfather, *it, hdecl);
//            assert(ret);
//            if (hdecl.is_type_null())
//            {
//                duke_media_compound_declare decl(*it);
//                decl.generate(username, hdecl, host_id, hfather);
//            }
//            duke_media_replace_handle(strval, *it, hdecl);
//        }
//    } 
//
//    if (m_data.m_ifc.is_interface_array())
//    {    
//        if (duke_media_get_handle_status(username, m_data.m_hext[0]) == Edit)
//        {
//            duke_media_handle hnew;
//            bool ret = duke_media_read_pair_handle(hfather, (m_data.m_hext[0]), hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_compound_interface ifc(m_data.m_hext[0]);
//                bool ret = ifc.generate(username, hnew, host_id, hfather);
//                assert(ret);
//                if (hnew.is_type_null())
//                    assert(false);
//            }
//            duke_media_replace_handle(strval, m_data.m_hext[0], hnew);
//        }
//    } 
//    else if (m_data.m_ifc.is_interface_array())
//    {}
//    return true;
//}


bool duke_media_compound_interface::is_valid()
{
    // Check declarations
    for (size_t i = 0; i < m_data.m_decls.size(); ++i)
    {
        if (!m_data.m_decls[i].is_declaration())
        {
            LOG_ERROR("duke_media_compound_interface::is_valid() : declaration[" << i << "] invalid.");
            return false;
        }
    }

    return true;
}


editor_base_ptr duke_media_compound_interface::to_xml_struct(index_manager& mgr, int& main_idx)
{
    if (!this->is_valid())
        return editor_base_ptr();

    UserInterface_editor_ptr pIF(new(std::nothrow) UserInterface_editor());

    if(!pIF)
        return pIF;

    //interface name
    pIF->set_name(m_data.m_name);

    //set group
    std::vector<InterfaceExpansionGroup> groups;
    for(duke_media_handle_iterator it = m_data.m_hext.begin(); it != m_data.m_hext.end(); ++it)
    {
        InterfaceExpansionGroup ife_group;
        int idx = mgr.get_index_from_handle(*it);
        ife_group.minimumInterface = idx;
        groups.push_back(ife_group);
    }
    pIF->set_groups(groups);

    //set is singleton, default false
    bool isSingleton = false;
    pIF->set_isSingleton(isSingleton);

    //set decls
    std::vector<int> declarations;
    for(duke_media_handle_iterator it = m_data.m_decls.begin(); it != m_data.m_decls.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        declarations.push_back(idx);
    }
    pIF->set_declarations(declarations);

    // main index
    main_idx = mgr.request_index_for_editor(this->get_handle(), pIF);

    return pIF;
}

void duke_media_compound_interface::get_related_handles(duke_media_handle_vector& vHandles)
{
}


duke_logic_data_interface_compound duke_media_compound_interface::get_data_from_handle()  const
{
    return m_data;
}

bool duke_media_compound_interface::init_save(DbTxn* txn)
{
    // only when handle is temp (or formal)
    // save to tempobj_db only
    if (e_handle_core != this->get_handle_status())
    {
        // call the virtual pack()
        return this->get_handle().set_value(this->pack_helper(), txn);
    }
    else
    {
        return false;
    }
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
