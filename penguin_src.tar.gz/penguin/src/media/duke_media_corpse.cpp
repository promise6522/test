#include "duke_media_corpse.h"

duke_media_corpse::duke_media_corpse(const dukeid_t& handle) : m_hif(NB_INTERFACE_CORPSE)
{
    //here assignment object must be a object
    if (!handle.is_object_corpse())
    {
        LOG_ERROR("use other type to initialization duke_media_corpse");
    }

    //get data from database and assign it to object data struct
    std::string   value;
    this->set_handle_status( handle.get_value(value) );    //we can know where this id come from

    if (value.empty())
    {
        LOG_ERROR("error : this corpse object " << handle.str() << " has no data!");
    }

    //unpack data and set handle to this object
    this->unpack_helper(value);
    this->set_handle(handle);

}

dukeid_t duke_media_corpse::get_interface()
{
    return m_hif;
}

bool    duke_media_corpse::get_name(std::string& name) const
{
    if(m_data.name.empty())
    {
        name = "corpse";
    }
    else
    {
        name = m_data.name + "-corpse";
    }
    return true;
}

void   duke_media_corpse::unpack_helper(const std::string& strval)
{
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_data.unpack(strval);
    }
    else if (status == e_handle_core)
    {
        //unpack user data
        content corpse;          
        unpack_object(strval, corpse);

        nb_id_t                obj_id;
        corpse_data_t          corp_data; 
        obj_impl_corpse::unpack(corpse, obj_id, corp_data);


        //unpack data to duke_media_corpse
        m_data.name = corp_data.name;
        m_data.node_index = corp_data.node_index;
        m_data.container_id  = corp_data.container_id;
        m_data.implement_id =  corp_data.implement_id;
        m_data.object_id  =  m_data.object_id;
        
        for(std::size_t i = 0 ; i < corp_data.inputs.size(); ++i)
        {
            m_data.inputs.push_back(corp_data.inputs[i]);
        }
        m_data.sub_corpse   = corp_data.sub_corpse;
        m_data.reason  = corp_data.reason;
    }
    else
    {
        LOG_ERROR("corpse object handle: " << this->get_handle().str() << " has not exist in db");
    }
}
