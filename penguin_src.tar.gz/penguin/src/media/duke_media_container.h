#ifndef __DUKE_MEDIA_CONTAINER_H
#define __DUKE_MEDIA_CONTAINER_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
#include "duke_media_base.h"
#include "duke_logic_object_data.h"
#include "ac_container/container_implementation.h"
#include "ac_message_type.h"
#include "ac_global_db.h"
#include "ac_object/obj_impl_container_def.h"

class duke_media_container : public duke_media_base
{
private:
    duke_logic_data_container m_container;


    host_committer_id_t       hc_id;


public:
    duke_media_container();
    // new container des
    duke_media_container(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");    
    //recover a existed container des
    duke_media_container(const duke_media_handle& hcon, const std::string& username = "anonymous-name");

    bool assign(const duke_media_handle& hcon);
    bool copy(const duke_media_handle& hcon);
    

public:
    virtual std::string pack() const;
    virtual void unpack(const std::string& strcon);
    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_idx);
    virtual bool is_valid();


    virtual bool set_name(const std::string& name);
    virtual bool get_name(std::string& name) const;
    virtual bool set_icon(const std::string& icon);
    virtual bool get_icon(std::string& icon) const;

    bool clear();

    // storage manipulation
    bool clear_storage();

    bool add_storage(const duke_media_handle& hstorage);
    bool add_storage(const duke_media_handle& hstorage, const duke_media_handle& hif);

    bool del_storage(const duke_media_handle& hstorage);
    bool del_storageifc(const duke_media_handle& hstorage);

    bool get_storages(duke_media_handle_pair_vector& vstorage) const;
    bool get_storageifc(const duke_media_handle& hstorage, duke_media_handle& hif);

    bool set_storagenum(int storage_num);    
    int get_storagenum() const;    

    // anchor manipulation
    bool clear_anchor();
    bool add_anchor(const duke_media_handle& hanchor);
    bool del_anchor(const duke_media_handle& hanchor);
    void get_anchor(duke_media_handle_vector& vanchor) const;

    // function (both declaration and implemention)
    bool clear_function();
    bool add_function(const duke_media_handle& hdecl, const duke_media_handle& himpl);
    bool add_function(const duke_media_handle& hdecl);
    
    // del the hecl from container and anchor
    bool del_function(const duke_media_handle& hdecl);
    bool get_declarations(duke_media_handle_vector& hdecls) const;
    bool get_interface(duke_media_handle& hif) const;

    // implemention
    bool get_implementation(const duke_media_handle& hdecl, duke_media_handle& himpl);
    bool del_implementation(const duke_media_handle& hdecl);

    // root anchor
    bool set_rootanchor(const duke_media_handle& handle);
    bool get_rootanchor(duke_media_handle& handle) const;

    // exclusive decl
    bool add_excldeclaration(const duke_media_handle& hdecl, const duke_media_handle& hanchor);
    bool del_excldeclaration(const duke_media_handle& hdecl);
    bool get_excldeclaration(const duke_media_handle& hdecl, duke_media_handle& hanchor);
    bool exist_excldeclaration(const duke_media_handle& hdecl);
    
    bool update_hif(const duke_media_handle& hdecl);
    bool update_funcs(const duke_media_handle& hdecl, const duke_media_handle& himpl);    
    bool update_funcs(const duke_media_handle& hdecl);

private:
    std::string pack_helper() const;
    void unpack_helper(const std::string& strcon);

    duke_media_handle_pair_vector_iterator find_decl(const duke_media_handle& hdecl);
    duke_media_handle_pair_vector_iterator find_exdecl(const duke_media_handle& hdecl);
    duke_media_handle_pair_vector_iterator find_storage(const duke_media_handle& hstorage);
    

};


#endif /* __DUKE_MEDIA_CONTAINER_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
