#include "duke_media_global.h"
#include "duke_media_declare.h"
#include "duke_media_implement.h"
#include "duke_media_anchor.h"
#include "duke_media_container.h"
#include "ac_container/anchor_implementation.h"
#include "ac_object/obj_impl_container_def.h"
#include "ac_db/ac_container_db_impl.h"
#include "stdx_log.h"

duke_media_container::duke_media_container()
{
}

duke_media_container::duke_media_container(const host_committer_id_t& host_id, const std::string& username)
    : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF, host_id),
    hc_id(host_id)
{
    duke_media_compound_interface interface(host_id, username);
    m_container.m_cif = interface.get_handle();
    m_container.m_storagenum = 0;

    // GET_ANCHORS decl   
    duke_media_compound_declare declare_anchor(host_id, DUKE_MEDIA_TYPE_FUNCTION_GET_ANCHORS);
    declare_anchor.set_name("get anchors");
    m_container.m_hgetanchors = declare_anchor.get_handle();
    declare_anchor.clear_output_ports();
    declare_anchor.clear_input_ports();
    declare_anchor.add_input_port(m_container.m_cif);

    // GET_STORAGES decl
    //duke_media_compound_declare declare_storage(host_id, DUKE_MEDIA_TYPE_FUNCTION_GET_STORAGES);
    //declare_storage.set_name("get storages");
    //declare_storage.clear_input_ports();
    //declare_storage.add_input_port(m_container.m_cif);
    //m_container.m_hgetstorages = declare_storage.get_handle();

    duke_media_implement impl(host_id);
    bool ret = this->add_function(declare_anchor.get_handle(), impl.get_handle());
    assert(ret);
    
    //ret = this->add_function(declare_storage.get_handle(), impl.get_handle());
    //assert(ret);
   
    ret = this->save();
    assert(ret);
}


duke_media_container::duke_media_container(const duke_media_handle& hcon, const std::string& username)
{
    bool ret = assign(hcon);
    assert(ret);
}


bool duke_media_container::assign(const duke_media_handle& hcon)
{
    if (!hcon.is_object_container_des())
    {
        LOG_ERROR("assign container def:" + hcon.str());
        return false;
    }

    std::string strcon;
    this->set_handle_status( hcon.get_value(strcon) );

    this->unpack_helper(strcon);
    this->set_handle(hcon);
    return true;
}


bool duke_media_container::copy(const duke_media_handle& hcon)
{
    if (!hcon.is_object_container_des())
    {
        return false;
    }
        
    std::string strval;
    hcon.get_value(strval);
    this->unpack(strval);
    //ret = this->clone();
    bool ret = this->save();
    return ret;
}


bool duke_media_container::set_name(const std::string& name)
{
    m_container.m_name = name;

    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);

    return this->save();
}


bool duke_media_container::get_name(std::string& name) const
{
    name = m_container.m_name;
    return true;
}

bool duke_media_container::set_icon(const std::string& icon)
{
    m_container.m_icon = icon;
    return this->save();
}

bool duke_media_container::get_icon(std::string& icon) const
{
    icon = m_container.m_icon;
    return true;
}

bool duke_media_container::clear()
{
    duke_media_compound_interface m_mif(m_container.m_cif);
    bool ret = m_mif.clear_declaration();
    assert(ret);

    m_container.m_anchor.clear();
    m_container.m_funcs.clear();
    m_container.m_exdecls.clear();
    m_container.m_storage.clear();
    return this->save(); 
}

bool duke_media_container::add_storage(const duke_media_handle& hstorage)
{
    if (hstorage.is_storage())
    {
        if (find_storage(hstorage) == m_container.m_storage.end())
        {
            duke_media_handle handle(NB_INTERFACE_NONE);
            m_container.m_storage.push_back(std::make_pair(hstorage, handle));

            /// update GET_STORAGES
            ///duke_media_compound_declare getstorages(m_container.m_hgetstorages);
            ///getstorages.add_output_port(handle);

            return this->save();
        }
    }
    return false;
}

bool duke_media_container::add_storage(const duke_media_handle& hstorage,
                                       const duke_media_handle& hif)
{
    if (hstorage.is_storage() && hif.is_interface())
    {
        duke_media_handle sif;
        duke_media_storage storage(hstorage);
        storage.get_interface(sif);

        duke_media_handle_pair_vector_iterator it;
        if ((it = find_storage(hstorage)) == m_container.m_storage.end())
        {
            m_container.m_storage.push_back(std::make_pair(hstorage, hif));

            /// update GET_STORAGES
            ///duke_media_compound_declare getstorages(m_container.m_hgetstorages);
            ///getstorages.add_output_port(sif);

            return this->save();
        }
        else
        {
            it->second = hif;

            /// update GET_STORAGES
            ///duke_media_compound_declare getstorages(m_container.m_hgetstorages);
            ///duke_media_handle_vector hiifs, hoifs;
            ///getstorages.get_interfaces(hiifs, hoifs);

            ///index = it - m_container.m_storage.begin();
            ///hoifs[index] = sif;
            ///getstorages.set_interfaces(hiifs, hoifs);

            return this->save();
        }
    }
    return false;
}

bool duke_media_container::clear_storage()
{
    m_container.m_storage.clear();

    ///duke_media_compound_declare getstorages(m_container.m_hgetstorages);
    ///getstorages.clear_output_ports();

    return this->save();
}

bool duke_media_container::del_storage(const duke_media_handle& hstorage)
{
    if (!hstorage.is_storage())
    {
        LOG_ERROR("duke_media_container::del_storage : must specify a storage");
        return false;
    }

    //size_t index;
    duke_media_handle_pair_vector_iterator it;
    if ((it = find_storage(hstorage)) != m_container.m_storage.end())
    {
        m_container.m_storage.erase(it);

        ///duke_media_compound_declare getstorages(m_container.m_hgetstorages);
        ///index = it - m_container.m_storage.begin();
        ///getstorages.del_output_port(index);

        return this->save();
    }        
    return false;
}

bool duke_media_container::del_storageifc(const duke_media_handle& hstorage)
{
    if (!hstorage.is_storage())
    {
        LOG_ERROR("duke_media_container::del_storageifc : must specify a storage");
        return false;
    }

    duke_media_handle_pair_vector_iterator it;
    if ((it = find_storage(hstorage)) != m_container.m_storage.end())
    {
        // TODO NBID_TYPE_NULL or NB_INTERFACE_NONE?
        duke_media_handle hif(NBID_TYPE_NULL);
        it->second = hif;
        return this->save();
    }

    return false;
}

bool duke_media_container::get_storages(duke_media_handle_pair_vector& vstorage) const
{
    vstorage = m_container.m_storage;
    return true;
}

bool duke_media_container::get_storageifc(const duke_media_handle& hstorage, duke_media_handle& hif)
{
    if (!hstorage.is_storage())
    {
        LOG_ERROR("duke_media_container::get_storageifc : must specify a storage");
        return false;
    }

    duke_media_handle_pair_vector_iterator it;
    if ((it = find_storage(hstorage)) != m_container.m_storage.end())
    {
        hif = it->second;
        return true;
    }

    return false;
}

bool duke_media_container::clear_anchor()
{
    m_container.m_anchor.clear();

    // update GET_ANCHORS
    duke_media_compound_declare getanchors(m_container.m_hgetanchors);
    getanchors.clear_output_ports();

    return this->save();
}

bool duke_media_container::add_anchor(const duke_media_handle& hanchor)
{
    assert(hanchor.is_anchor());
    m_container.m_anchor.push_back(hanchor);

    // get anchor interface
    duke_media_handle hif;
    duke_media_anchor anchor(hanchor);
    anchor.get_interface(hif, hc_id);

    // update GET_ANCHORS
    duke_media_compound_declare getanchors(m_container.m_hgetanchors);
    getanchors.add_output_port(hif);

    return this->save();
}

bool duke_media_container::del_anchor(const duke_media_handle& hanchor)
{
    assert(hanchor.is_anchor());

    // remove the anchor and get index
    size_t index;
    for (duke_media_handle_iterator it = m_container.m_anchor.begin();
            it != m_container.m_anchor.end(); ++it)
    {
        if (*it == hanchor)
        {
            m_container.m_anchor.erase(it);
            index = it - m_container.m_anchor.begin();
            break;
        }
    }


    for (duke_media_handle_pair_vector_iterator it = m_container.m_exdecls.begin();
            it != m_container.m_exdecls.end(); ++it)
    {
        if (it->second == hanchor)
        {
            m_container.m_exdecls.erase(it);
            break;
            //return this->save();
        }
    }

    // update GET_ANCHORS
    duke_media_compound_declare getanchors(m_container.m_hgetanchors);
    getanchors.del_output_port(index);

    return this->save();
}

void duke_media_container::get_anchor(duke_media_handle_vector& vanchor) const
{
    vanchor = m_container.m_anchor;
}

bool duke_media_container::set_storagenum(int storage_num)
{
    // TODO
    m_container.m_storagenum = storage_num;
    return this->save();
}

int duke_media_container::get_storagenum() const
{
    return m_container.m_storagenum;
}

bool duke_media_container::set_rootanchor(const duke_media_handle& handle)
{
    m_container.m_hroot = handle;
    return this->save();
}
    
bool duke_media_container::get_rootanchor(duke_media_handle& handle) const
{
    handle = m_container.m_hroot;
    return true;
}

// function (both declaration and implemention)

bool duke_media_container::clear_function()
{
    m_container.m_funcs.clear();
    return this->save();
}

bool duke_media_container::add_function(const duke_media_handle& hdecl,
                                        const duke_media_handle& himpl)
{
    assert(hdecl.is_declaration() && himpl.is_implementation());
    
    if (hdecl.is_function_get_anchors() || hdecl.is_function_get_storages())
    {
        bool ret = update_hif(hdecl);
        assert(ret);
    }
    bool ret = update_funcs(hdecl, himpl);
    assert(ret);
    return ret;
}

bool duke_media_container::add_function(const duke_media_handle& hdecl)
{
    assert(hdecl.is_declaration());

    if (hdecl.is_function_get_anchors() || hdecl.is_function_get_storages())
    {
        bool ret = update_hif(hdecl);
        assert(ret);
    }
    bool ret = update_funcs(hdecl);
    assert(ret);
    return ret;
}

// del the hecl from container and anchor
bool duke_media_container::del_function(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    if (ret)
    {
        int icount(0);
        duke_media_handle_pair_vector_iterator it = find_decl(hdecl);
        if (it != m_container.m_funcs.end())
        {
            m_container.m_funcs.erase(it);
        }

        for (duke_media_handle_const_iterator iter = m_container.m_anchor.begin();
             iter != m_container.m_anchor.end(); ++iter)
        {
            
            duke_media_anchor anchor(*iter);
            if (anchor.find_exdeclaration(hdecl))
            {
                ret = anchor.del_declaration(hdecl, Excl);
                assert(ret);
                duke_media_handle_pair_vector_iterator it;
                if ((it = find_exdecl(hdecl)) != m_container.m_exdecls.end())
                    m_container.m_exdecls.erase(it);    
            }
            else if (anchor.find_declaration(hdecl))
            {
                ret = anchor.del_declaration(hdecl, Normal);
                assert(ret);
            }
            duke_media_compound_declare getanchors(m_container.m_hgetanchors);
            duke_media_handle_vector hiifs, hoifs;
            getanchors.get_interfaces(hiifs, hoifs);
            
            duke_media_handle hif;
            anchor.get_interface(hif, hc_id);
            hoifs[icount] = hif;

            getanchors.set_interfaces(hiifs, hoifs);

            ++icount;
        }
        return this->save();
    }
    return ret;
}

bool duke_media_container::get_declarations(duke_media_handle_vector& hdecls) const
{
    for (duke_media_handle_pair_vector_const_iterator it = m_container.m_funcs.begin();
         it != m_container.m_funcs.end(); ++it)
    {        
        hdecls.push_back(it->first);
    }    
    return true;
}

bool duke_media_container::get_interface(duke_media_handle& hif) const
{
    hif = m_container.m_cif;
    return true;
}

// implemention
bool duke_media_container::get_implementation(const duke_media_handle& hdecl,
                                              duke_media_handle& himpl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    if (ret)
    {
        duke_media_handle_pair_vector_iterator it = find_decl(hdecl);
        if (it != m_container.m_funcs.end())
        {
            himpl = it->second;
            return true;
        }
    }
    return false;
}

bool duke_media_container::del_implementation(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    if (ret)
    {
        duke_media_handle_pair_vector_iterator it;
        if ((it = find_decl(hdecl)) != m_container.m_funcs.end())
        {
            duke_media_handle handle(NBID_TYPE_NULL);
            it->second = handle;
            return this->save();
        }
        else
            return false;
    }
    return ret;
}

// exclusive decl
bool duke_media_container::add_excldeclaration(const duke_media_handle& hdecl,
                                               const duke_media_handle& hanchor)
{
    assert(hdecl.is_declaration() && hanchor.is_anchor());
        
    if (find_decl(hdecl) == m_container.m_funcs.end())
        return false;
    if (find_exdecl(hdecl) != m_container.m_exdecls.end())
        return false;
    m_container.m_exdecls.push_back(std::make_pair(hdecl, hanchor));
    return this->save();
}

bool duke_media_container::del_excldeclaration(const duke_media_handle& hdecl)
{
    assert(hdecl.is_declaration());
    duke_media_handle_pair_vector_iterator it;
    if ((it = find_exdecl(hdecl)) != m_container.m_exdecls.end())
    {
        m_container.m_exdecls.erase(it);
        return this->save();
    }
    else
        return false;
}

bool duke_media_container::get_excldeclaration(const duke_media_handle& hdecl,
                                               duke_media_handle& hanchor)
{
    assert(hdecl.is_declaration());
    duke_media_handle_pair_vector_const_iterator it;
    if ((it = find_exdecl(hdecl)) != m_container.m_exdecls.end())
    {
        hanchor = it->second;
        return true;
    }
    return false;
}

bool duke_media_container::exist_excldeclaration(const duke_media_handle& hdecl)
{
    assert(hdecl.is_declaration());
    if (find_exdecl(hdecl) != m_container.m_exdecls.end())
        return true;
    return false;
}

//bool duke_media_container::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//
//    bool ret = duke_media_clear_pair_handle(this->get_handle());
//    assert(ret);
//    ret = duke_media_clear_cipair_handle(this->get_handle());
//    assert(ret);
//
//    std::string strkey = username + "-container-def";
//    std::string strval;
//    assert(this->get_handle().is_object_container_des());
//
//    duke_media_container Mecont(host_id, username);
//
//    if (!hfather.is_type_null())
//    {
//        bool ret = duke_media_write_pair_handle(hfather, this->get_handle(), Mecont.get_handle());
//        assert(ret);
//    }
//
//    ret = this->get_handle().get_value(strval);
//    assert(ret);
//    
//    Mecont.unpack(strval);
//    handle = Mecont.get_handle();
//
//    Mecont.generate_sub_declaration(username, strval, host_id, hfather);
//    Mecont.generate_sub_storages(username, strval, host_id, hfather);
//
//    Mecont.generate_sub_impl(username, strval, host_id, hfather);
//    Mecont.replace_compound_interface(username, strval, host_id); 
//
//    Mecont.generate_sub_exec(username, strval, host_id);
//
//    ret = Mecont.get_handle().set_value(strval);
//    Mecont.unpack(strval);
//    assert(ret);
//    Mecont.generate_sub_anchors(username, strval, host_id, hfather);
//    Mecont.replace_root_anchor(username, strval, host_id, hfather);
// 
//    ret = Mecont.get_handle().set_value(strval);
//    assert(ret);
//
//    Mecont.unpack(strval);
//    Mecont.pack_new_struct(username);
//
//    duke_media_remove_handle("anonymous-name-tmp-container-def", Mecont.get_handle());
//    duke_media_remove_handle(username + "-tmp-container-def", Mecont.get_handle());
//
//    strval = "";
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + Mecont.get_handle().str() + ")";
//    assert(duke_media_write_handle(strkey, strval));
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(Mecont.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << this->get_handle().str() << " container def in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << this->get_handle().str() << " container def in temp media failed;");
//
//    return ret;
//}

bool duke_media_container::update_hif(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    duke_media_handle_pair_vector_iterator funcs_iter;
    if ((funcs_iter = find_decl(hdecl)) == m_container.m_funcs.end())
    {
        duke_media_compound_interface m_mif(m_container.m_cif);
        return m_mif.add_declaration(hdecl);
    }
    return true;
}

bool duke_media_container::update_funcs(const duke_media_handle& hdecl,
                                        const duke_media_handle& himpl)
{
    bool ret = (hdecl.is_declaration() && himpl.is_implementation());
    duke_media_handle_pair_vector_iterator funcs_iter;
    if ((funcs_iter = find_decl(hdecl)) == m_container.m_funcs.end())
    {
        ret = hdecl.is_declaration() && himpl.is_implementation();
        assert(ret);
        if (ret)
        {
            m_container.m_funcs.push_back(std::make_pair(hdecl, himpl));
            return this->save();
        }
    }
    else
    {
        funcs_iter->second = himpl;
        return this->save();
    }
    return ret;
}

bool duke_media_container::update_funcs(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    if (ret)
    {
        duke_media_handle handle(NBID_TYPE_NULL);
        m_container.m_funcs.push_back(std::make_pair(hdecl, handle));
        return this->save();
    }
    return ret;
}

std::string duke_media_container::pack() const
{
    return this->pack_helper();
}

std::string duke_media_container::pack_helper() const
{
    return m_container.pack();
}

void duke_media_container::unpack(const std::string& strcon)
{
    this->unpack_helper(strcon);
}

void duke_media_container::unpack_helper(const std::string& strcon)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_container.m_storage.clear();
        m_container.unpack(strcon);    
    }
    else if ( e_handle_core == status )
    {
        //unpack from db to core struct
        content con;
        unpack_object(strcon, con);

        cont_def_data_t data_t;
        nb_id_t definition;
        obj_impl_container_def::unpack(con, definition, data_t);

        m_container.m_name = data_t.name;

        //anchor info
        int index_anchor = 0;
        for( std::vector<anchor_info_t>::const_iterator it = data_t.anchors.begin(); 
                 it != data_t.anchors.end(); ++it, ++index_anchor )
        {
            //produce a new anchor
            duke_media_anchor         new_anchor(host_committer_id_t(0));
            new_anchor.set_name(it->name);
            new_anchor.set_hcontainer(definition);
            new_anchor.set_index(index_anchor);

            dukeid_vector vDecl;
            for(func_vector_const_it it_func = it->funcs.begin(); it_func != it->funcs.end(); ++it_func)
            {
                vDecl.push_back(it_func->declaration_id);

                m_container.m_funcs.push_back(std::make_pair<dukeid_t, dukeid_t>(it_func->declaration_id, 
                                            it_func->implementation_id));

            }

            new_anchor.add_declaration(vDecl, Normal);
            m_container.m_anchor.push_back(new_anchor.get_handle());
        }

        //anchor stroage info
        m_container.m_storagenum = data_t.storages.size();
        int index_storage = 0;
        for( std::vector<storage_info_t>::const_iterator it = data_t.storages.begin();
                it != data_t.storages.end(); ++it, ++index_storage)
        {
            duke_media_storage  new_storage(host_committer_id_t(0));
            new_storage.set_name(it->name);

            dukeid_vector      vtype;
            vtype.push_back(NB_INTERFACE_INT);
            vtype.push_back(it->type);
            new_storage.set_type(vtype);

            new_storage.set_storage_idx(index_storage);
            new_storage.set_container(definition);

            duke_media_compound_interface recover_inf(it->interface);
            new_storage.set_storage_compound_if_data(recover_inf.get_data_from_handle());
            new_storage.set_storage_if(it->interface);

            m_container.m_storage.push_back(std::make_pair(new_storage.get_handle(), it->interface));
        }

        m_container.m_cif = NB_INTERFACE_CONTAINER_DEF;
    }
    else
    {
        LOG_ERROR("container handle: " << this->get_handle().str() << " has not exist in db");
    }
}

// declaration
duke_media_handle_pair_vector_iterator duke_media_container::find_decl(const duke_media_handle& hdecl)
{
    assert(hdecl.is_declaration());

    duke_media_handle_pair_vector_iterator it;
    for (it = m_container.m_funcs.begin(); it != m_container.m_funcs.end(); ++it)
    {
        if (it->first == hdecl)
            return it;
    }
    return it;
}

duke_media_handle_pair_vector_iterator duke_media_container::find_exdecl(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    duke_media_handle_pair_vector_iterator it;
    for (it = m_container.m_exdecls.begin(); it != m_container.m_exdecls.end(); ++it)
    {
        if (it->first == hdecl)
            return it;
    }
    return it;
}

duke_media_handle_pair_vector_iterator duke_media_container::find_storage(const duke_media_handle& hstorage)
{
    bool ret = hstorage.is_storage();
    assert(ret);
    duke_media_handle_pair_vector_iterator it;
    for (it = m_container.m_storage.begin(); it != m_container.m_storage.end(); ++it)
    {
        if (it->first == hstorage)
            return it;
    }
    return it;
}

bool duke_media_container::is_valid()
{
    if (m_container.m_name.empty())
    {
        LOG_ERROR("duke_media_container::is_valid() : container name unset.");
        return false;
    }

    // check storage type
    for (size_t i = 0; i < m_container.m_storage.size(); ++i)
    {
        duke_media_storage media_storage(m_container.m_storage[i].first);
        dukeid_vector key_value_vec;
        media_storage.get_type(key_value_vec);
        if (key_value_vec.size() != 2)
        {
            LOG_ERROR("duke_media_container::is_valid() : storage[" << i << "] type unset.");
            return false;
        }
        if (!key_value_vec[0].is_interface() || !key_value_vec[1].is_interface())
        {
            LOG_ERROR("duke_media_container::is_valid() : storage[" << i << "] type invalid.");
            return false;
        }
    }

    // check anchors
    for (size_t i = 0; i < m_container.m_anchor.size(); ++i)
    {
        duke_media_anchor media_anchor(m_container.m_anchor[i]);

        // anchor's name
        std::string anchor_name;
        media_anchor.get_name(anchor_name);
        if (anchor_name.empty())
        {
            LOG_ERROR("duke_media_container::is_valid() : anchor[" << i << "] name unset.");
            return false;
        }

        // anchor's funcs
        dukeid_vector decls;
        media_anchor.get_declaration(decls, Normal);
        if (decls.empty())
        {
            LOG_ERROR("duke_media_container::is_valid() : anchor[" << i << "] funcs empty.");
            return false;
        }

        for (size_t j = 0; j < decls.size(); ++j)
        {
            if (!decls[j].is_declaration_compound())
            {
                LOG_ERROR("duke_media_container::is_valid() : anchor[" << i << "].funcs[" << j << "] empty.");
                return false;
            }
        }
    } 

    return true;
}

editor_base_ptr duke_media_container::to_xml_struct(index_manager& mgr, int& main_idx)
{
    if (!this->is_valid())
        return editor_base_ptr();

    UserContainerDefinition_editor_ptr pUCon(new(std::nothrow) UserContainerDefinition_editor());

    if (!pUCon)
        return pUCon;

    // container_def name
    pUCon->set_name(m_container.m_name);

    // Storages
    std::vector<Storage> storages;
    for (dukeid_pair_vector::iterator it = m_container.m_storage.begin(); it != m_container.m_storage.end(); ++it)
    {
        duke_media_storage media_storage(it->first);

        Storage Simple_storage;

        // storage'name
        media_storage.get_name(Simple_storage.name);

        // storage'key-value-interface
        dukeid_vector key_value_vec;
        media_storage.get_type(key_value_vec);

        int key_idx = mgr.get_index_from_handle(key_value_vec[0]);
        int val_idx = mgr.get_index_from_handle(key_value_vec[1]);

        Simple_storage.key   = key_idx;
        Simple_storage.value = val_idx;

        // storage'type
        ///if (it->first.get_nb_type().is_singlevalue_storage())
        ///    Simple_storage.type = SINGLEVALUE_STORAGE;
        ///else if (it->first.get_nb_type().is_autokey_singlevalue_singleton_storage())
        ///    Simple_storage.type = AUTOKEY_SINGLEVALUE_SINGLETON_STORAGE;
        ///else if (it->first.get_nb_type().is_autokey_singlevalue_storage())
        ///    Simple_storage.type = AUTOKEY_SINGLEVALUE_STORAGE;
        ///else if (it->first.get_nb_type().is_autokey_multivalue_singleton_storage())
        ///    Simple_storage.type = AUTOKEY_MULTIVALUE_SINGLETON_STORAGE;
        ///else if (it->first.get_nb_type().is_autokey_multivalue_storage())
        ///    Simple_storage.type = AUTOKEY_MULTIVALUE_STORAGE;
        ///else if (it->first.get_nb_type().is_singlevalue_singleton_storage())
        ///    Simple_storage.type = SINGLEVALUE_SINGLETON_STORAGE;
        ///else if (it->first.get_nb_type().is_multivalue_singleton_storage())
        ///    Simple_storage.type = MULTIVALUE_SINGLETON_STORAGE;
        ///else
        ///    Simple_storage.type = MULTIVALUE_STORAGE;

        //##NOTICE## IS-Media only support this type of storage
        Simple_storage.type = SINGLEVALUE_STORAGE; 

        storages.push_back(Simple_storage);
    }

    pUCon->set_storages(storages);

    // Anchors
    std::vector<Anchor> anchors;
    for (dukeid_vector::iterator it = m_container.m_anchor.begin(); it != m_container.m_anchor.end(); ++it)
    {
        duke_media_anchor media_anchor(*it);

        Anchor Simple_anchor;

        // anchor's name
        media_anchor.get_name(Simple_anchor.name);

        // anchor's binding
        dukeid_vector decls;
        media_anchor.get_declaration(decls, Normal);

        for (dukeid_vector::iterator decl_it = decls.begin(); decl_it != decls.end(); ++decl_it)
        {
            Binding func_binding;

            for (dukeid_pair_vector::iterator func_it = m_container.m_funcs.begin(); func_it != m_container.m_funcs.end(); ++func_it)
            {
                if (*decl_it == func_it->first)
                {
                    int decl_idx = mgr.get_index_from_handle(*decl_it);
                    func_binding.declaration = decl_idx;

                    int impl_idx = mgr.get_index_from_handle(func_it->second);
                    func_binding.implementation = impl_idx;

                    break;
                }
            }

            Simple_anchor.bindings.push_back(func_binding);
        }

        // anchor's register
        Simple_anchor.registered = false; // NOTICE ## IS-Media does not support register anchor now ##

        anchors.push_back(Simple_anchor);
    }

    pUCon->set_anchors(anchors);

    // main index
    main_idx = mgr.request_index_for_editor(this->get_handle(), pUCon);

    return pUCon;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
