#ifndef _DUKE_MEDIA_MAP_H_
#define _DUKE_MEDIA_MAP_H_

//C 98 header file
#include <iostream>
#include <string.h>
#include <list>
#include <map>
#include <utility>

//#include "duke_media_base.h"
//#include "duke_logic_id.h"
//#include "duke_logic_object_data.h"
//#include "duke_media_interface.h"
//#include "duke_media_compound_interface.h"
#include "ac_object/obj_impl_map.h"
#include "duke_media_declare_expanded.h"
#include "duke_index_manager.h"

class duke_media_map : public duke_media_base
{
private:
    duke_logic_data_map m_data;
    duke_media_handle m_hif;

    map_data_t data_t;
    nb_id_t    nb_map;
    host_committer_id_t hc_id;
    std::string user_name;

public:
    duke_media_map();
    duke_media_map(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");
    duke_media_map(const duke_media_handle& handle);

    duke_media_handle clone_new_handle(const host_committer_id_t& hc_id) const;

    dukeid_t generate_expanded_decl(const nb_builtin_instruction_t ins, const dukeid_vector& type);

    virtual void unpack(const std::string& strval);
    void unpack_helper(const std::string& strval);
    virtual std::string pack() const;
    std::string pack_helper() const;

    virtual editor_base_ptr  to_xml_struct(index_manager& mgr, int& main_index);
    virtual void get_related_handles(duke_media_handle_vector& vHandles);
    virtual bool is_valid();

    bool get_value(std::multimap<duke_media_handle, duke_media_handle>& value) const;

    bool set_value(const duke_media_handle_vector& type, std::multimap<duke_media_handle, duke_media_handle> value); 

    bool get_interface(duke_media_handle& hif) const;

    bool get_compound_interface(duke_media_handle& hif) const;

    //bool get_declarations(duke_media_handle_vector& hdecls) const;

    bool get_type(duke_media_handle_vector& vtype) const;

    virtual bool get_name(std::string& name) const;

    virtual bool set_name(const std::string& /*name*/);

    virtual bool get_icon(std::string& icon) const;

    virtual bool set_icon(const std::string& /*icon*/);

    bool is_expanded() const;
    bool generate(const std::string& username, duke_media_handle& handle, 
            const host_committer_id_t& host_id, const duke_media_handle& hfather);

};

#endif  //_DUKE_MEDIA_MAP_H_
