/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#include "duke_stash_db.h"

#include "nb_profiler.h"

duke_stash_db::duke_stash_db()
{
    try
    {
        // home dir
        const std::string dbhome = "dbmedia/dbstash";

        // database file name
        const std::string& dbfile = "stash.db";

        // default table name
        const std::string& dbname = "";

        // recover the database each time
        nb_mkdirs(dbhome);
        nbnv::recover(dbhome);

        // create database environment
        penv = new nbnv(dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool duke_stash_db::write(const std::string& strkey, const std::string& value, DbTxn* txn)
{
    NEW_SCOPE_TIMER("duke_stash_db::write", false);

    assert(pdb != NULL);

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
        return false;
    }

    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}

bool duke_stash_db::read(const std::string& strkey, std::string& value, DbTxn* txn)
{
    assert(pdb != NULL);

    int ret = pdb->read(strkey, value, txn);

    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else if (ret == DB_NOTFOUND)
    {
        ret = NB_DB_RESULT_NOTFOUND;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}


bool duke_stash_db::del(const std::string& strkey, DbTxn* txn)
{
    assert(pdb != NULL);

    int ret = pdb->del(strkey, txn);

    return (ret == 0 ? true : false);
}


bool duke_stash_db::txn_begin(DbTxn*& txn)
{
    assert(pdb != NULL);

    int ret = pdb->txn_begin(txn);

    return (ret == 0 ? true : false);
}


bool duke_stash_db::commit(DbTxn* txn)
{
    assert(pdb != NULL);

    int ret = pdb->commit(txn);

    return (ret == 0 ? true : false);
}


bool duke_stash_db::rollback(DbTxn* txn)
{
    assert(pdb != NULL);

    int ret = pdb->rollback(txn);

    return (ret == 0 ? true : false);
}

duke_stash_db::~duke_stash_db() 
{
    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
