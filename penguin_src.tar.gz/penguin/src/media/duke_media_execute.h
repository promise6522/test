#ifndef __DUKE_MEDIA_EXECUTE_H
#define __DUKE_MEDIA_EXECUTE_H

// C++ 98 header files
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header files
#include "duke_media_base.h"
#include "duke_media_declare.h"
#include "duke_media_compound_declare.h"
#include "duke_media_declare_expanded.h"
#include "duke_logic_object_data.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_anchor_func.h"

typedef duke_logic_data_node duke_media_node;
typedef duke_logic_data_path duke_media_path;

class duke_media_graph
{
private:
    typedef std::vector<duke_media_node>::const_iterator node_const_iterator;
    typedef std::vector<duke_media_path>::const_iterator path_const_iterator;
    typedef std::vector<duke_media_node>::iterator node_iterator;
    typedef std::vector<duke_media_path>::iterator path_iterator;

public:
    duke_media_node m_inode;
    duke_media_node m_onode;
    std::vector<duke_media_node> m_nodes;
    std::vector<duke_media_path> m_paths;

    MSGPACK_DEFINE(m_inode, m_onode, m_nodes, m_paths);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

public:
    duke_media_graph()
    {
        this->set_input_node("input_node", 0);
        this->set_output_node("output_node", 0);
    }

    //judge path exist
    bool is_path_exist(const std::string& onode, const int oport,
              const std::string& inode, const int iport) const
    {
        for(std::vector<duke_media_path>::const_iterator ite = m_paths.begin(); ite != m_paths.end(); ++ite)
        {
            if((onode == ite->m_onode && oport == ite->m_oport
                    && inode == ite->m_inode && iport == ite->m_iport))
            {
                return true;
            }
        }
        return false;
    }
    // methods for nodes and paths
    void get_media_nodes(std::vector<duke_media_node>& nodes) const
    {
        nodes.push_back(m_inode);
        nodes.insert(nodes.end(), m_nodes.begin(), m_nodes.end());
        nodes.push_back(m_onode);
    }

    duke_media_node find_node_by_name(const std::string& targetNodeName)
    {
        for(std::vector<duke_media_node>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
        {
            if(it->m_name == targetNodeName)
            {
                return *it;
            }
        }
        return duke_media_node();
    }

    bool add_node_cnt(const std::string& nodeName)
    {
        for(std::vector<duke_media_node>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
        {
            if(it->m_name == nodeName)
            {
                ++it->cnt;
                return true;
            }
        }
        return false;
    }

    bool sub_node_cnt(const std::string& nodeName)
    {
        for(std::vector<duke_media_node>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
        {
            if(it->m_name == nodeName)
            {
                --it->cnt;
                return true;
            }
        }
        return false;
    }

    void get_media_paths(std::vector<duke_media_path>& paths) const
    {
        paths = m_paths;
    }

    void get_object_nodes(std::vector<duke_media_node>& nodes) const
    {
        for (std::vector<duke_media_node>::const_iterator it = m_nodes.begin();
                it != m_nodes.end(); ++it)
        {
            if ( it->is_object_node())
                nodes.push_back(*it);
        }
    }

    bool set_object_node(const dukeid_t& source, const dukeid_t& dest)
    {
        for (std::vector<duke_media_node>::iterator it = m_nodes.begin();
                it != m_nodes.end(); ++it)
        {
            if (it->m_hdecl.get_func_type() == NB_FUNC_GENERAL_IDENTITY)
            {
                dukeid_vector_iterator iter;
                for (iter = it->m_inputs.begin(); iter != it->m_inputs.end(); ++iter)
                {
                    if ((*iter) == source)
                        (*iter) = dest;
                }
            }
        }
        return true;
    }

    void get_func_nodes(std::vector<duke_media_node>& nodes) const
    {
        for (std::vector<duke_media_node>::const_iterator it = m_nodes.begin();
                it != m_nodes.end(); ++it)
        {
            if ( !it->is_object_node())
                nodes.push_back(*it);
        }
    }

    bool get_input_node(duke_media_node& node) const
    {
        node = m_inode;
        return true;
    }

    bool set_input_node(const std::string& name, int num)
    {
        duke_media_handle hdecl(NB_FUNC_GENERAL_IDENTITY);
        duke_media_handle_vector vh(num);
        return this->set_node(name, hdecl, NB_INTERFACE_NONE, vh, vh, m_inode);
    }

    bool set_input_node(const std::string& name, const duke_media_handle_vector& vin)
    {
        duke_media_handle hdecl(NB_FUNC_GENERAL_IDENTITY);
        duke_media_handle_vector vout(vin.size());
        return this->set_node(name, hdecl, NB_INTERFACE_NONE, vin, vout, m_inode);
    }

    bool get_output_node(duke_media_node& node) const
    {
        node = m_onode;
        return true;
    }

    bool set_output_node(const std::string& name, int num)
    {
        duke_media_handle hdecl(NB_FUNC_GENERAL_RETURN);
        duke_media_handle_vector vh(num);
        return this->set_node(name, hdecl, NB_INTERFACE_NONE, vh, vh, m_onode);
    }

    bool add_object_node(const std::string& name, const duke_media_handle& hobj)
    {
        // IS modules will impose these contraints

        //assert(hobj.is_object() || hobj.is_container() 
        //        || hobj.is_storage() || hobj.is_access()
        //        || hobj.is_anchor() || hobj.is_container() || hobj.is_implementation());
     

        duke_media_handle hdecl(NB_FUNC_GENERAL_IDENTITY);
        duke_media_handle_vector vin(1, hobj);
        duke_media_handle_vector vout(1);
        return this->add_node(name, hdecl, NB_INTERFACE_NONE, vin, vout);
    }
    
    bool add_func_node(const std::string& name, 
                       const duke_media_handle& hdecl, 
                       const duke_media_handle& owner_if = NB_INTERFACE_NONE,
                       const duke_media_handle& hexdecl = NBID_TYPE_NULL);//add by tom
    
    bool add_func_node(const std::string& name, nb_builtin_instruction_t oper)
    {
        return this->add_func_node(name, duke_media_handle(oper));
    }

    bool remove_node(const std::string& name)
    {
        for (node_iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
        {
            if (it->m_name == name)
            {
                m_nodes.erase(it);
                break;
            }
        }
        for (path_iterator it = m_paths.begin(); it != m_paths.end(); )
        {
            if (it->m_onode == name || it->m_inode == name)
            {
                it = m_paths.erase(it);
            }
            else
            {
                ++it;
            }
        }
        return true;
    }

    bool get_node(const std::string& name, duke_media_node& node)
    {
        for (node_iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
        {
            if (it->m_name == name)
            {
                node = *it;
                break;
            }
        }
        return true;
    }

    bool get_path(const std::string& onode, int oport, std::string& inode, int& iport)
    {
        typedef std::vector<duke_media_path>::const_iterator path_const_iterator;
        for (path_const_iterator it = m_paths.begin(); it != m_paths.end(); ++it)
        {
            if ((it->m_onode == onode) && (it->m_oport == oport))
            {
                inode = it->m_inode;
                iport = it->m_iport;
                return true;
            } 
        }
        return false;
    }

    bool add_path(const std::string& onode, int oport,
            const std::string& inode, int iport)
    {
        duke_media_path path;
        path.m_onode = onode;
        path.m_oport = oport;
        path.m_inode = inode;
        path.m_iport = iport;
        m_paths.push_back(path);
        return true;
    }

    bool add_path(const duke_media_path& path)
    {
        m_paths.push_back(path);
        return true;
    }

    bool remove_path(const std::string& onode, int oport,
            const std::string& inode, int iport)
    {
        for (path_iterator it = m_paths.begin(); it != m_paths.end(); ++it)
        {
            if (it->m_onode == onode && it->m_oport == oport &&
                it->m_inode == inode && it->m_iport == iport)
            {
                m_paths.erase(it);
                //int vSize = find_node_by_name(inode).m_inputs.size();
                //if((onode != "input_node") && (inode != "output_node") && (vSize == iport))
                //{
                //    sub_node_cnt(inode);
                //}
                LOG_DEBUG("duke_media_implement::remove_path() success");
                return true;
            }
        }
        // For Debug
        assert(!"duke_media_implement::remove_path() : path invalid");

        return true;
    }

    bool clear()
    {
        m_inode.clear();
        m_onode.clear();
        this->clear_internal_nodes();
        return true;
    }

    bool clear_internal_nodes()
    {
        m_nodes.clear();
        m_paths.clear();
        return true;
    }

    bool check() const
    {
        /*return !m_onode.m_inputs.empty() && !m_onode.m_outputs.empty()*/;
        return true;        
    }

private:
    bool add_node(const std::string& name, 
                const duke_media_handle& hdecl,
                const duke_media_handle& hOwnerIf,
                const duke_media_handle_vector& inputs, 
                const duke_media_handle_vector& outputs)
    {
        // TODO: make sure no node with the same name
        assert(hdecl.is_declaration() || hdecl.is_object_func() || hdecl.is_implementation());

        duke_media_node node;
        this->set_node(name, hdecl, hOwnerIf, inputs, outputs, node);
        m_nodes.push_back(node);
        return true;
    }

    bool set_node(const std::string& name, 
            const duke_media_handle& hdecl,
            const duke_media_handle& hOwnerIf,
            const duke_media_handle_vector& inputs,
            const duke_media_handle_vector& outputs,
            duke_media_node& node) const
    {
        assert(hdecl.is_declaration() || hdecl.is_object_func() || hdecl.is_implementation());

        node.m_name = name;
        node.m_hdecl = hdecl;
        node.m_hOwnerIf = hOwnerIf;
        node.m_inputs = inputs;
        node.m_outputs = outputs;
        node.cnt = 0;
        return true;
    }
};

class duke_media_execute : public duke_media_base
{
private:
    duke_media_graph m_graph;
    duke_logic_data_base m_base;

public:
    duke_media_execute(const host_committer_id_t& host_id, const std::string& username = "anonymous-name") : duke_media_base(DUKE_MEDIA_TYPE_FUNCTION_EXECUTE, host_id)
    {
        bool ret = this->save();
        assert(ret);
    }

    duke_media_execute(const duke_media_handle& himpl, const std::string& username = "anonymous-name")
    {
        bool ret = this->assign(himpl);
        assert(ret);
    }

public:
    // methods for implement
    bool assign(const duke_media_handle& himpl)
    {
        bool ret = false;
        assert(himpl.is_execute());
        if (himpl.is_execute())
        {
            std::string strimpl;
            ret = himpl.get_value(strimpl);
            this->unpack(strimpl);
            this->set_handle(himpl);
        }
        return ret;
    }

    bool set_name(const std::string& name)
    {
        m_base.m_name = name;
        return this->save();
    }

    bool get_name(std::string& name) const
    {
        name = m_base.m_name;
        return true;
    }

    bool set_icon(const std::string& icon)
    {
        m_base.m_icon = icon;
        return this->save();
    }

    bool get_icon(std::string& icon) const
    {
        icon = m_base.m_icon;
        return true;
    }

    // methods for nodes and paths
    void get_media_nodes(std::vector<duke_media_node>& nodes) const
    {
        return m_graph.get_media_nodes(nodes);
    }

    void get_media_paths(std::vector<duke_media_path>& paths) const
    {
        return m_graph.get_media_paths(paths);
    }

    // methods for nodes
    void get_object_nodes(std::vector<duke_media_node>& nodes) const
    {
        return m_graph.get_object_nodes(nodes);
    }

    bool add_input_node(const std::string& name, const duke_media_handle& vh)
    {
        duke_media_node node;
        m_graph.get_input_node(node);
        node.m_inputs.push_back(vh);
        m_graph.set_input_node(name, node.m_inputs);
        return this->save();
    }

    bool add_input_node(const std::string& name, const duke_media_handle_vector& vin)
    {
        m_graph.set_input_node(name, vin);
        return this->save();
    }

    bool get_output_node(duke_media_node& node) const
    {
        return m_graph.get_output_node(node);
    }

    bool add_output_node(const std::string& name)
    {
        duke_media_node node;
        m_graph.get_output_node(node);
        m_graph.set_output_node(name, node.m_outputs.size() + 1);
        return this->save();
    }

    bool add_output_node(const std::string& name, int num)
    {
        m_graph.set_output_node(name, num);
        return this->save();
    }

    bool add_func_node(const std::string& name, const duke_media_handle& hdecl)
    {
        m_graph.add_func_node(name, hdecl);
        return this->save();
    }

    bool add_func_node(const std::string& name, nb_builtin_instruction_t oper)
    {
        m_graph.add_func_node(name, oper);
        return this->save();
    }

    bool add_object_node(const std::string& name, const duke_media_handle& hobj)
    {
        m_graph.add_object_node(name, hobj);
        return this->save();
    }

    bool remove_node(const std::string& name)
    {
        m_graph.remove_node(name);
        return this->save();
    }

    // methods for paths
    bool add_path(const std::string& onode, int oport,
            const std::string& inode, int iport)
    {
        m_graph.add_path(onode, oport, inode, iport);
        return this->save();
    }

    bool remove_path(const std::string& onode, int oport,
            const std::string& inode, int iport)
    {
        m_graph.remove_path(onode, oport, inode, iport);
        return this->save();
    }

    bool clear()
    {
        m_graph.clear();
        return this->save();
    }

    bool clear_internal_nodes() 
    {
        m_graph.clear_internal_nodes();
        return this->save();
    }

public:
    bool generate(const std::string& username, duke_media_handle& handle)
    {
        assert(m_graph.check());

        std::string strkey = username + "-execute";
        std::string strval;
        assert(this->get_handle().is_execute());
        //boost::scoped_ptr<duke_media_execute> new_exec(new duke_media_execute());

        //new_exec->unpack(this->pack());
        //bool ret = new_exec->get_handle().set_value(new_exec->pack());
        //assert(ret);
 
        duke_media_remove_handle("anonymous-name-tmp-execute", this->get_handle());
       
        bool ret = duke_media_read_handle(strkey, strval);
        strval = "(" + this->get_handle().str() + ")";
        ret = duke_media_write_handle(strkey, strval);
        assert(ret);
        handle = this->get_handle();
        return ret;
    }
   
    bool copy(const duke_media_handle& hexec)
    {
        assert(hexec.is_execute());
        std::string strval;
        bool ret = hexec.get_value(strval);
        assert(ret);
        this->unpack(strval);
        ret = this->save();
        assert(ret);

        return ret;
    }

    std::string pack() const
    {
        std::string strimpl;

        // name and icon
        strimpl += "{" + m_base.pack() + "}\n";
        // graph
        strimpl += "^" + m_graph.pack() + "$\n";

        return strimpl;
    }

    void unpack(const std::string& strimpl)
    {
        if (strimpl.empty())
            return;

        std::string::size_type idx(0);
        std::string strbase, strdecl, strgraph;
        idx = find_between(strimpl, strbase, "{", "}", idx);
        idx = find_between(strimpl, strgraph, "^", "$", idx);

        // name and icon
        m_base.unpack(strbase);

        // graph
        if (!strgraph.empty())
            m_graph.unpack(strgraph);
    }

    bool save()
    {
        return get_handle().set_value(this->pack());
    }

};


#endif /* __DUKE_MEDIA_EXECUTE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
