/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

// nb file
#include "duke_name_db_impl.h"

#include "nb_profiler.h"
//#include "stdx_log.h"

duke_name_db_impl::duke_name_db_impl()
{
    try
    {
        std::string dbmedia = "dbmedia/";
        const std::string& db_name = "named";
        const std::string dbhome = "dbname";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idvalue";

        // recover the database each time
        nb_mkdirs(dbmedia + dbhome);
        nbnv::recover(dbmedia + dbhome);

        // create database environment
        penv = new nbnv(dbmedia + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool duke_name_db_impl::write(const std::string& strkey, const std::string& value)
{
    NEW_SCOPE_TIMER("duke_name_db_impl::write", false);

    assert(pdb != NULL);

    DbTxn* txn = NULL;

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
        return false;
    }

    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}

bool duke_name_db_impl::read(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);

    DbTxn* txn = NULL;

    int ret = pdb->read(strkey, value, txn);
    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else if (ret == DB_NOTFOUND)
    {
        ret = NB_DB_RESULT_NOTFOUND;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}

duke_name_db_impl::~duke_name_db_impl(void) 
{
    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
