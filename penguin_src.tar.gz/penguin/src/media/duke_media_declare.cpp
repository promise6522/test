//#include "duke_media_global.h"
//#include "duke_media_interface.h"
#include "duke_media_declare.h"
#include "duke_logic_object_static.h"
#include "duke_logic_object.h"
#include "duke_media_compound_interface.h"
#include "duke_media_global.h"
#include "stdx_log.h"

//only for duke_media_base_factory
duke_media_declare::duke_media_declare()
{
}

//duke_media_declare::duke_media_declare(const host_committer_id_t& host_id, duke_media_type type /*=DUKE_MEDIA_TYPE_FUNCTION_DECLARE*/, const std::string& username /*="anonymous-name"*/) : duke_media_base(type, host_id), hc_id(host_id)
//{
//    m_params.add_input_port(duke_media_handle(NB_INTERFACE_NONE));
//    if (type == DUKE_MEDIA_TYPE_FUNCTION_COMPOSE)
//        m_params.add_output_port(duke_media_handle(NB_INTERFACE_NONE));
//
//    bool ret = this->save();
//    assert(ret);
//}

duke_media_declare::duke_media_declare(const duke_media_handle& hdecl)
{
    if (!hdecl.is_function_instruction())
    {
        LOG_ERROR("error type assign to duke_media_declare");
    }
    this->make_builtin_interfaces(hdecl);
    this->set_handle(hdecl);
    // load the value of declare
    // unpack string to content 
    // unpack content to declare struction
    // set the data_t to m_param;
    //std::string strval;
    //ac_object_db_impl::instance().read_(hdecl.str(), strval);

    //if (strval.empty())
    //{
    //    std::string strval;
    //    duke_media_read_handle(hdecl.str(), strval);
    //    if ((strval != "bridge"))
    //    {
    //        bool ret = this->assign(hdecl);
    //        assert(ret);
    //    }
    //}
    //else
    //{
        //if (hdecl.is_function_instruction())
        //{
        //    this->make_builtin_interfaces(hdecl);
        //    this->set_handle(hdecl);
        //}
        //else
        //{
        //    typedef std::vector<iport_t>::const_iterator iconst;
        //    typedef std::vector<oport_t>::const_iterator oconst;

        //    std::string strval;
        //    ac_object_db_impl::instance().read_(hdecl.str(), strval);
        //    //db_value value;
        //    if (!strval.empty())
        //    {
        //        content con;
        //        unpack_object(strval, con);

        //        obj_impl_decl_compound::unpack(con, obj_id, data_t);

        //        duke_media_handle_vector hiif, hoif;

        //        for (iconst it = data_t.iports.begin(); it != data_t.iports.end(); ++it)
        //            hiif.push_back(it->interface);

        //        for (oconst it = data_t.oports.begin(); it != data_t.oports.end(); ++it)
        //            hoif.push_back(it->interface);

        //        m_params.m_name = data_t.name;
        //        m_params.set_interfaces(hiif, hoif);
        //    }
        //    this->set_handle(hdecl);
        //}
    //}
}

//duke_media_declare::duke_media_declare(int i, const duke_media_handle& hdecl, const std::string& username)
//{
//    std::string strval;
//    ac_object_db_impl::instance().read_(hdecl.str(), strval);
//
//    if (strval.empty())
//    {
//        std::string strval;
//        duke_media_read_handle(hdecl.str(), strval);
//        if ((strval != "bridge"))
//        {
//            bool ret = this->assign(hdecl);
//            assert(ret);
//        }
//    }
//    else
//    {
//        if (hdecl.is_function_instruction())
//        {
//            this->make_builtin_interfaces(hdecl);
//            this->set_handle(hdecl);
//        }
//        else
//        {
//            typedef std::vector<iport_t>::const_iterator iconst;
//            typedef std::vector<oport_t>::const_iterator oconst;
//
//            //db_value value;
//            if (!strval.empty())
//            {
//                content con;
//                unpack_object(strval, con);
//
//                obj_impl_decl_compound::unpack(con, obj_id, data_t);
//
//                duke_media_handle_vector hiif, hoif;
//
//                for (iconst it = data_t.iports.begin(); it != data_t.iports.end(); ++it)
//                    hiif.push_back(it->interface);
//
//                for (oconst it = data_t.oports.begin(); it != data_t.oports.end(); ++it)
//                    hoif.push_back(it->interface);
//
//                m_params.m_name = data_t.name;
//                m_params.set_interfaces(hiif, hoif);
//            }
//            this->set_handle(hdecl);
//        }
//    }
//}

//duke_media_declare::duke_media_declare(const std::string& username, const duke_media_handle& hdecl, const content& raw_data)
//{
//    std::string strkey = username + "-declare";
//    std::string strval;
//    assert(hdecl.is_declaration());
//
//    typedef std::vector<iport_t>::const_iterator iconst;
//    typedef std::vector<oport_t>::const_iterator oconst;
//
//    obj_impl_decl_compound::unpack(raw_data, obj_id, data_t);
//
//    duke_media_handle_vector hiif, hoif;
//
//    for (iconst it = data_t.iports.begin(); it != data_t.iports.end(); ++it)
//        hiif.push_back(it->interface);
//
//    for (oconst it = data_t.oports.begin(); it != data_t.oports.end(); ++it)
//        hoif.push_back(it->interface);
//
//    m_params.m_name = data_t.name;
//    m_params.set_interfaces(hiif, hoif);
//
//    this->set_handle(hdecl);
//
//    bool ret = this->save();
//    assert(ret);
//
//    duke_media_remove_handle("anonymous-name-tmp-declare", this->get_handle());
//    duke_media_remove_handle(username + "-tmp-declare", this->get_handle()); 
//
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + this->get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//}

bool duke_media_declare::assign(const duke_media_handle& hdecl)
{
    if (!hdecl.is_function_instruction())
    {
        LOG_ERROR("assign error decl:" + hdecl.str());
        return false;
    }

    bool ret = this->make_builtin_interfaces(hdecl);
    this->set_handle(hdecl);
    return ret;
         
//        std::string strdecl;
//        ret = hdecl.get_value(strdecl);
//        if (!ret)
//            LOG_ERROR("get value decl:" + hdecl.str() + ":value:" + strdecl);
//        
//        if (strdecl.empty())
//        {
//            typedef std::vector<iport_t>::const_iterator iconst;
//            typedef std::vector<oport_t>::const_iterator oconst;
//            
//            std::string strval;
//            ac_object_db_impl::instance().read_(hdecl.str(), strval);
//        
//            //db_value value;
//            if (!strval.empty())
//            {
//                content con;
//                unpack_object(strval, con);
//        
//                obj_impl_decl_compound::unpack(con, obj_id, data_t);
//        
//                duke_media_handle_vector hiif, hoif;
//        
//                for (iconst it = data_t.iports.begin(); it != data_t.iports.end(); ++it)
//                    hiif.push_back(it->interface);
//        
//                for (oconst it = data_t.oports.begin(); it != data_t.oports.end(); ++it)
//                    hoif.push_back(it->interface);
//        
//                m_params.m_name = data_t.name;
//                m_params.set_interfaces(hiif, hoif);
//                this->set_handle(hdecl);
//            }
//        }
//        assert(ret);
//        assert(!strdecl.empty());
//        if(ret)
//        {                
//            this->unpack(strdecl);               
//        }
//        ret = true;            
//        this->set_handle(hdecl);
//    }
//    return ret;
}

bool duke_media_declare::get_name(std::string& name) const
{
    duke_media_handle hdecl = get_handle();

    bool ret = false;

    if (hdecl.is_function_instruction())
    {
        ret = duke_logic_static_declaration::get_builtin_name(hdecl, name);
    }
    else
    {
        name = m_params.m_name;
        ret = true;
    }

    return ret;
}

//bool duke_media_declare::set_name(const std::string& name)
//{
//    m_params.m_name = name;
//    data_t.name = name;
//    bool ret = duke_media_save_handle_name(this->get_handle(), name);
//    assert(ret);
//    return this->save();
//}

bool duke_media_declare::get_icon(std::string& icon) const
{
    icon = m_params.m_icon;
    return true;
}

//bool duke_media_declare::set_icon(const std::string& icon)
//{
//    m_params.m_icon = icon;        
//    return this->save();
//}

bool duke_media_declare::get_interfaces(duke_media_handle_vector& hiifs,
                                        duke_media_handle_vector& hoifs)
{
    if (m_params.m_param.m_hiifs.size() == 0)
    {
        make_builtin_interfaces(this->get_handle());
    }

    return m_params.get_interfaces(hiifs, hoifs);
}

//bool duke_media_declare::set_interfaces(const duke_media_handle_vector& hiifs,
//                                        const duke_media_handle_vector& hoifs)
//{
//    m_params.set_interfaces(hiifs, hoifs);
//    return this->save();
//}

int duke_media_declare::get_iport_number() const
{
    return m_params.get_iport_number();
}

int duke_media_declare::get_oport_number() const
{
    return m_params.get_oport_number();
}

//bool duke_media_declare::add_input_port(const duke_media_handle& hif)
//{
//    bool ret = m_params.add_input_port(hif);
//    if (ret)
//        ret = this->save();
//    return ret;
//}
//
//bool duke_media_declare::del_input_port(const int& hif)
//{
//    bool ret = m_params.del_input_port(hif);
//    if (ret)
//        ret = this->save();
//    return ret;
//}
//
//bool duke_media_declare::add_output_port(const duke_media_handle& hif)
//{
//    bool ret = m_params.add_output_port(hif);
//    assert(ret);
//    if (ret)
//        ret = this->save();
//    return ret;
//}
//
//bool duke_media_declare::del_output_port(const int& hif)
//{
//    bool ret = m_params.del_output_port(hif);
//    if (ret)
//        ret = this->save();
//    return ret;
//}

bool duke_media_declare::clear_input_ports()
{
    m_params.clear_input_ports();
    return this->save();
}

bool duke_media_declare::clear_output_ports()
{
    m_params.clear_output_ports();
    return this->save();
}

bool duke_media_declare::clear()
{
    m_params.clear_input_ports();
    m_params.clear_output_ports();
    return this->save();
}

//void duke_media_declare::set_owner_if(const dukeid_t& owner_if)
//{
//    m_owner_if = owner_if;
//
//    // reload builtin instruction's interfaces
//    // such as INTERFACE_CONVERT
//    if(this->get_handle().is_function_instruction())
//        this->make_builtin_interfaces(this->get_handle());
//}
//
//dukeid_t duke_media_declare::get_owner_if() const
//{
//    return m_owner_if;
//}

//bool duke_media_declare::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    std::string strkey = username + "-declare";
//    std::string strval;
//    assert(this->get_handle().is_declaration());
//
//    if (this->get_handle().is_function_compose())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_COMPOSE);
//        handle = decl.get_handle();
//    }
//    else if (this->get_handle().is_function_decompose())
//    {
//        duke_media_compound_declare decl(host_id, DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE);
//        handle = decl.get_handle();
//    }
//    else
//    {
//        duke_media_compound_declare decl(host_id);
//        handle = decl.get_handle();
//    }
//
//    duke_media_declare decl(handle);
//    bool ret = decl.copy(this->get_handle());
//
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(decl.get_handle(), strname);
//    assert(ret);
//
//    ret = this->get_handle().get_value(strval);
//    assert(ret);
//
//    replace_content(username, strval, host_id, hfather);
//
//    decl.unpack(strval);
//    ret = decl.get_handle().set_value(strval);
//    assert(ret);
//    decl.pack_new_structure();
//
//    duke_media_remove_handle("anonymous-name-tmp-declare", decl.get_handle());
//    duke_media_remove_handle(username + "-tmp-declare", decl.get_handle()); 
//
//    strval.clear();
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + decl.get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//
//    if (!hfather.is_type_null() && (hfather != this->get_handle()))
//    {
//        ret = duke_media_write_pair_handle(hfather, this->get_handle(), decl.get_handle());
//        assert(ret);
//    }
//    handle = decl.get_handle(); 
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(decl.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//	    LOG_NOTICE("DEL the " << decl.get_handle().str() << " decl in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//	    LOG_NOTICE("DEL the " << decl.get_handle().str() << " decl in temp media failed;");
//
//    return ret;
//}
//
//bool duke_media_declare::pack_new_structure()
//{
//    std::string strname;
//    this->get_name(strname);
//
//    // pack new structure
//    duke_media_handle_vector hiifs, hoifs;
//    m_params.get_interfaces(hiifs, hoifs);
//
//    decl_compound_data_t tmp_data;
//    if (!data_t.name.empty())
//        tmp_data.name = data_t.name;
//    else
//        tmp_data.name = strname;
//
//    tmp_data.groups = data_t.groups;
//
//    for (duke_media_handle_const_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
//    {
//        nb_id_t id;
//        memcpy(&id, &(*it), sizeof(id));
//        iport_t tmp;
//        tmp.interface = id;
//        tmp_data.iports.push_back(tmp);        
//    }
//
//    for (duke_media_handle_const_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
//    {
//        nb_id_t id;
//        id.str((*it).str());
//        oport_t tmp;
//        tmp.interface = id;
//        tmp_data.oports.push_back(tmp);        
//    }
//   
//    nb_id_t obj_id; 
//    obj_id.str(this->get_handle().str());
//
//    content tmp_content;
//    obj_impl_decl_compound::pack(tmp_data, obj_id, tmp_content);
//
//    std::string strval = pack_object(tmp_content);
//
//    //write the strval to db
//    ac_object_db_impl::instance().write_(obj_id.str(), strval);
//
//    return true;
//}
//
//bool duke_media_declare::copy(const duke_media_handle& hdecl)
//{
//    LOG_DEBUG(" duke_media_declare::copy ***");
//    bool ret = false;
//    assert(hdecl.is_declaration());
//    if (hdecl.is_function_instruction())
//    {
//        //ret = this->make_builtin_interfaces(hdecl);
//        this->set_handle(hdecl);
//        ret = true;
//    }
//    else
//    {
//        typedef std::vector<iport_t>::const_iterator iconst;
//        typedef std::vector<oport_t>::const_iterator oconst;
//
//        std::string strval;
//        ac_object_db_impl::instance().read(hdecl.str(), strval);
//        //db_value value;
//        if (!strval.empty())
//        {
//            content con;
//            unpack_object(strval, con);
//
//            obj_impl_decl_compound::unpack(con, obj_id, data_t);
//
//            duke_media_handle_vector hiif, hoif;
//
//            for (iconst it = data_t.iports.begin(); it != data_t.iports.end(); ++it)
//                hiif.push_back(it->interface);
//
//            for (oconst it = data_t.oports.begin(); it != data_t.oports.end(); ++it)
//                hoif.push_back(it->interface);
//
//            m_params.m_name = data_t.name;
//            m_params.set_interfaces(hiif, hoif);
//            ret = this->save();
//            assert(ret);
//        }
//        else
//        {
//            std::string strval;
//            ret = hdecl.get_value(strval);
//            assert(ret);
//            this->unpack(strval);
//            ret = this->save();
//            assert(ret);
//        }
//    }
//    return ret;
//}
//
//std::string duke_media_declare::pack() const
//{
//    return m_params.pack();
//}
//
//void duke_media_declare::unpack(const std::string& strdecl)
//{
//    m_params.unpack(strdecl);
//}
//
//bool duke_media_declare::save()
//{
//    std::string strname;
//    this->get_name(strname);
//
//    // pack new structure
//    duke_media_handle_vector hiifs, hoifs;
//    m_params.get_interfaces(hiifs, hoifs);
//
//    decl_compound_data_t tmp_data;
//    if (!data_t.name.empty())
//        tmp_data.name = data_t.name;
//    else
//        tmp_data.name = strname;
//
//    tmp_data.groups = data_t.groups;
//
//    for (duke_media_handle_const_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
//    {
//        nb_id_t id;
//        memcpy(&id, &(*it), sizeof(id));
//        iport_t tmp;
//        tmp.interface = id;
//        tmp_data.iports.push_back(tmp);        
//    }
//
//    for (duke_media_handle_const_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
//    {
//        nb_id_t id;
//        memcpy(&id, &(*it), sizeof(id));
//        oport_t tmp;
//        tmp.interface = id;
//        tmp_data.oports.push_back(tmp);        
//    }
//    
//    obj_id.str(this->get_handle().str());
//
//    content tmp_content;
//    obj_impl_decl_compound::pack(tmp_data, obj_id, tmp_content);
//
//    std::string strval = pack_object(tmp_content);
//
//    //write the strval to db
//    ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//
//    return get_handle().set_value(this->pack());
//}
//

bool duke_media_declare::make_builtin_interfaces(const duke_media_handle& hdecl)
{
    assert(hdecl.is_function_instruction());

    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;

    if(NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_INTERFACE);

        duke_media_array  tmp_arr(hc_id);

        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_STRING));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);
    }
    else if(NB_FUNC_INTERFACE_GET_DECLARATIONS == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_INTERFACE);

        duke_media_array  tmp_arr(hc_id);
        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_DECLARATION));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);
    }
    else if(NB_FUNC_DECLARATION_GET_INTERFACES == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_DECLARATION);

        duke_media_array  tmp_arr(hc_id);
        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_INTERFACE));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);//array for inport interfaces
        hoifs.push_back(vif);//array for oport  interfaces
    }
    else if(NB_FUNC_DECLARATION_GET_IN_PORTS == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_DECLARATION);

        duke_media_array  tmp_arr(hc_id);
        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_INTERFACE));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);
    }
    else if(NB_FUNC_DECLARATION_GET_OUT_PORTS == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_DECLARATION);

        duke_media_array  tmp_arr(hc_id);
        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_INTERFACE));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);
    }
    else if(NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_DECLARATION);

        duke_media_array  tmp_arr(hc_id);
        dukeid_vector vtype(1, dukeid_t(NB_INTERFACE_INTERFACE));
        tmp_arr.set_value(vtype, dukeid_vector());
        dukeid_t  vif;
        tmp_arr.get_interface(vif);

        hoifs.push_back(vif);
    }
    else if(NB_FUNC_GENERAL_RUN == hdecl.get_nb_type().get_func_type())
    {
        hiifs.push_back(NB_INTERFACE_NONE);
        hiifs.push_back(NB_INTERFACE_DECLARATION);

        duke_media_array  tmp_in(hc_id);
        dukeid_vector vin(1, dukeid_t(NB_INTERFACE_NONE));
        tmp_in.set_value(vin, dukeid_vector());
        dukeid_t  vif;
        tmp_in.get_interface(vif);
        hiifs.push_back(vif);


        hoifs.push_back(vif);
    }
    else
    {
        duke_logic_static_declaration::get_interfaces(hdecl, hiifs, hoifs);
    }

    return m_params.set_interfaces(hiifs, hoifs);
}

//bool duke_media_declare::replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather)
//{
//    duke_media_handle_vector hiifs, hoifs;
//    this->get_interfaces(hiifs, hoifs);
//    
//    duke_media_handle_const_iterator it;
//    for (it = hiifs.begin(); it != hiifs.end(); ++it)
//    {
//        if ((*it).is_interface_compound())
//        {
//            if (duke_media_get_handle_status(username, *it) == Edit)
//            {
//                duke_media_handle hnew;
//                bool ret = duke_media_read_pair_handle(hfather, *it, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface ifc(*it);
//                    if (!ifc.generate(username, hnew, host_id, hfather))
//                        assert(false);
//                }
//                duke_media_replace_handle(strval, *it, hnew);
//            }
//        }
//    }
//    for (it = hoifs.begin(); it != hoifs.end(); ++it)
//    {
//        if ((*it).is_interface_compound())
//        {
//            if (duke_media_get_handle_status(username, *it) == Edit)
//            {
//                duke_media_handle hnew;
//                bool ret = duke_media_read_pair_handle(hfather, *it, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    duke_media_compound_interface ifc(*it);
//                    if (!ifc.generate(username, hnew, host_id, hfather))
//                        assert(false);
//                }
//                duke_media_replace_handle(strval, *it, hnew);
//            }
//        }
//    }
//    return true; 
//}

// vim:set tabstop=4 shiftwidth=4 expandtab:

