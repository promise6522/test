/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#include "duke_media_base_factory.h"

// concrete types of duke_media_base
#include "duke_media_object.h"
#include "duke_media_array.h"
#include "duke_media_map.h"
#include "duke_media_compound_declare.h"
#include "duke_media_implement.h"
#include "duke_media_container.h"


namespace duke_media_base_factory {


duke_media_base_ptr get_media_from_handle(const duke_media_handle& h)
{
    // only for editing handles
    //assert(e_handle_temp == get_media_handle_status(h));

    duke_media_base_ptr pMedia; 

    // construct media object according to the type of the handle
    duke_media_type mType = h.get_type();
    switch (mType)
    {
        // Not for those non-persistent types
        case DUKE_MEDIA_TYPE_OBJECT_NONE:
        case DUKE_MEDIA_TYPE_OBJECT_BOOL:
        case DUKE_MEDIA_TYPE_OBJECT_INT:
        case DUKE_MEDIA_TYPE_OBJECT_FLOAT:
        case DUKE_MEDIA_TYPE_OBJECT_INTERVAL:
        case DUKE_MEDIA_TYPE_OBJECT_TIME:
        case DUKE_MEDIA_TYPE_INTERFACE_USER:
        case DUKE_MEDIA_TYPE_FUNCTION_INSTRUCTION:
            assert(!"get_media_from_handle doesn't accept non-persist handle");
            break;
         // bridge handle should never be "temp"
        case DUKE_MEDIA_TYPE_OBJECT_BRIDGE:
            assert(!"get_media_from_handle doesn't accept bridge object");
            break;
         // bridge interface handle should never be "temp"
        case DUKE_MEDIA_TYPE_INTERFACE_BRIDGE:
            assert(!"get_media_from_handle doesn't accept bridge interface object");
            break;

        case DUKE_MEDIA_TYPE_OBJECT_STRING:
            pMedia.reset(new(std::nothrow) duke_media_string());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_BYTES:
            pMedia.reset(new(std::nothrow) duke_media_bytes());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_ARRAY:
            pMedia.reset(new(std::nothrow) duke_media_array());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_MAP:
            pMedia.reset(new(std::nothrow) duke_media_map());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_USER:
            pMedia.reset(new(std::nothrow) duke_media_object());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_DECLARATION_EXPANDED:
            pMedia.reset(new(std::nothrow) duke_media_declare_expanded());
            break;
        case DUKE_MEDIA_TYPE_OBJECT_INTERFACE_EXPANDED:                         
        case DUKE_MEDIA_TYPE_INTERFACE_COMPOUND:
            pMedia.reset(new(std::nothrow) duke_media_compound_interface());
            break;

        case DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT:
            pMedia.reset(new(std::nothrow) duke_media_implement());
            break;

        case DUKE_MEDIA_TYPE_FUNCTION_DECLARE:
        case DUKE_MEDIA_TYPE_FUNCTION_COMPOSE:
        case DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE:        
        case DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_COMPOSE:
        case DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_DECOMPOSE:
        case DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_SYNC:
        case DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_ASYNC:
        case DUKE_MEDIA_TYPE_FUNCTION_GET_ANCHORS:
        case DUKE_MEDIA_TYPE_FUNCTION_GET_STORAGES:                         
            pMedia.reset(new(std::nothrow) duke_media_compound_declare());
            break;

        case DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF:
            pMedia.reset(new(std::nothrow) duke_media_container());
            break;


        case DUKE_MEDIA_TYPE_CONTAINER:
        case DUKE_MEDIA_TYPE_ACCESS:
        case DUKE_MEDIA_TYPE_STORAGE:
        case DUKE_MEDIA_TYPE_ANCHOR:
        case DUKE_MEDIA_TYPE_OBJECT_DESCRIPTOR:
        case DUKE_MEDIA_TYPE_ACCESS_ROOT:
        default:
            assert(!"get_media_from_handle(): unknown handle type.");
    }
    assert(pMedia.get());

    pMedia->set_handle(h);

    // get the handle's value from tempbjdb
    std::string strval;
    h.get_value(strval);
    pMedia->unpack(strval);

    return pMedia;
}

}/* namespace duke_media_base_factory */
