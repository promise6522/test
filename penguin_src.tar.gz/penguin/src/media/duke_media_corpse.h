#ifndef   DUKE_MEDIA_CORPSE_H_
#define   DUKE_MEDIA_CORPSE_H_
#include "duke_logic_id.h"
#include "duke_media_base.h"
#include "duke_logic_object_data.h"
#include "ac_object/obj_impl_corpse.h"

class duke_media_corpse : public duke_media_base
{
    private:
        duke_logic_data_corpse    m_data;
        duke_media_handle         m_hif;

    public:
        duke_media_corpse(const dukeid_t&  handle);
        dukeid_t  get_interface();
        bool      get_name(std::string&  name)   const;
        void  unpack_helper(const std::string& strval);
};
#endif //DUKE_MEDIA_CORPSE_H_
