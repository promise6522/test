#ifndef __DUKE_MEDIA_BASE_H
#define __DUKE_MEDIA_BASE_H

//C 98 header file
#include <string>
#include <fstream>

#include <limits.h>

#include <boost/smart_ptr.hpp>

//boost file header
#define BOOST_FILESYSTEM_VERSION 2
#include <boost/filesystem.hpp>

// C 89 header files
#include <assert.h>

// C 99 header files
#include <stdint.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <iomanip>
#include <sstream>

#include <vector>

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "duke_logic_id.h"
//#include "duke_media_object_data.h"
#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_id_dispenser.h"
#include "duke_logic_object_data.h"
#include "duke_info_db_impl.h"
#include "duke_verify_db_impl.h"
#include "ac_global_db.h"
#include "nb_profiler.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "nb_profiler.h"
#include "duke_name_db_impl.h"
#include "nb_compiler_type.h"

typedef std::vector<duke_media_handle>              duke_media_handle_vector;
typedef duke_media_handle_vector::size_type         duke_media_handle_size_type;
typedef duke_media_handle_vector::iterator          duke_media_handle_iterator;
typedef duke_media_handle_vector::const_iterator    duke_media_handle_const_iterator;

typedef std::vector<duke_logic_data_node>::const_iterator node_const_iterator;
typedef std::vector<duke_logic_data_node>::iterator node_iterator;


typedef std::map<duke_media_handle, duke_media_handle> duke_media_handle_map;
typedef duke_media_handle_map::iterator duke_media_handle_map_iterator;
typedef duke_media_handle_map::const_iterator duke_media_handle_map_const_iterator;

typedef std::multimap<duke_media_handle, duke_media_handle> duke_media_handle_multimap;
typedef duke_media_handle_multimap::iterator duke_media_handle_multimap_iterator;
typedef duke_media_handle_multimap::const_iterator duke_media_handle_multimap_const_iterator;

typedef std::vector<std::pair<duke_media_handle, duke_media_handle> > duke_media_handle_pair_vector;
typedef std::vector<std::pair<duke_media_handle, duke_media_handle> >::iterator duke_media_handle_pair_vector_iterator;
typedef std::vector<std::pair<duke_media_handle, duke_media_handle> >::const_iterator duke_media_handle_pair_vector_const_iterator;

typedef std::map<duke_media_handle, std::string> duke_media_hstr_map;
typedef duke_media_hstr_map::iterator duke_media_hstr_map_iterator;
typedef duke_media_hstr_map::const_iterator duke_media_hstr_map_const_iterator;

enum decl_status {Normal, Excl};

struct gen_mem_value
{
    duke_media_handle gen_id;
    std::string name;
    std::string core_value;
};

//forward declaration to avoid cyclic-dependancy
class index_manager;

struct duke_media_base 
{    
private:
    duke_media_handle m_handle;
    nb_handle_status  m_status;

public:
    // We need a argument-less constructor which is fairly "clean"
    duke_media_base(): m_status(e_handle_temp)
    {
    }

    duke_media_base(const duke_media_type& type, const host_committer_id_t& host_comm_id) : m_status(e_handle_temp) 
    {
        if (is_persistent_type(type))
        {

            ac_id_t dest_id = g_ac_id_dispenser_acid;

            ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
            if(pActor)
            {
                if (type == DUKE_MEDIA_TYPE_ANCHOR)
                {
                    anchor_id_t output;
                    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
                    pActor->request_alone_anchor_id(output);
                    m_handle = output;
                    m_handle.set_idtype(nb_handle::Id64);
                }
                else if (type == DUKE_MEDIA_TYPE_STORAGE)
                {
                    request_alone_storage_id_info input;
                    input.type = type;
                    storage_id_t output;
                    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
                    pActor->request_alone_storage_id(input, output);
                    m_handle = output;
                    m_handle.set_idtype(nb_handle::Id64);
                }
                /*
                else if (type == DUKE_MEDIA_TYPE_CONTAINER)
                {
                    request_alone_container_id_info input;
                    input.committer_id = host_comm_id;
                    std::cout << "host_commit_id:" << host_comm_id.str() << std::endl;
                    container_id_t output;
                    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
                    pActor->request_alone_container_id(input, output);
                    m_handle = output;
                    m_handle.set_idtype(nb_handle::Id256);
                }*/
                else
                {
                    request_alone_nb_id_info input;
                    input.type = type;
                    input.committer_id = host_comm_id;
                    nb_id_t output;
                    boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
                    pActor->request_alone_nb_id(input, output);
                    m_handle = output;
                    m_handle.set_idtype(nb_handle::Id128);
                }
            }
        }
        else
        { 
            m_handle.set_type(type);
            m_handle.set_idtype(nb_handle::Id128);
        }
    }

protected:
    bool save(DbTxn* txn = NULL)
    {
        // only when handle is temp (or formal)
        // save to tempobj_db only
        if (e_handle_core != this->get_handle_status())
        {
            // call the virtual pack()
            return this->get_handle().set_value(this->pack(), txn);
        }
        else
        {
            return false;
        }
    }

    bool load(const duke_media_handle& h)
    {
        std::string strval;
        assert(e_handle_unknown != h.get_value(strval));

        // call the virtual unpack()
        this->unpack(strval);
        return true;
    }

private:
    bool is_persistent_type(const duke_media_type& type) const {
            return static_cast<nbid_type_t>(type) == NBID_TYPE_STORAGE_SINGLEVALUE || 
            static_cast<nbid_type_t>(type) == NBID_TYPE_ANCHOR ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_CONTAINER ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_ROOT_COMMITTER ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_CENTER_COMMITTER ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_HOST_COMMITTER ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_TRANSACTION ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_FACADE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_EXECUTE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_BRIDGE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_ARRAY ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_MAP ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_STRING ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_BYTES ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_DECLARATION ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_INTERFACE_COMPOUND ||
			//static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_INTERFACE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_ACCESS ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_CONTAINER_DEF ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_BRIDGE_INTERFACE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_IMPLEMENTATION ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_USER ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_BRIDGE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_INTERFACE_EXPANDED ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_DECLARATION_EXPANDED ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_FUNCTION_COMPOSE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_FUNCTION_DECOMPOSE ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_FUNCTION_GET_ANCHORS ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_FUNCTION_GET_STORAGES ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_EXEC_CONDITION ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_EXEC_ITERATOR ||
            static_cast<nbid_type_t>(type) == NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    }

public:
    virtual ~duke_media_base() {}

    bool compile(const std::string& username,
            nb_id_t& main_id,
            std::map<int, nb_id_t>& idx_id_map);

    bool set_handle_status(const nb_handle_status status)
    {
        m_status = status;
        return true;
    }

    nb_handle_status get_handle_status() const
    {
        return m_status;
    }

    duke_media_handle& get_handle() { return m_handle; }

    const duke_media_handle& get_handle() const { return m_handle; }
     
    void set_handle(const duke_media_handle& handle) { m_handle = handle; }


    //Obsoleted!!!!!
    virtual bool generate(const std::string& username, duke_media_handle& handle)
    {
        return false;
    }
   
    virtual bool get_name(std::string& name) const
    {
        return false;
    }

    virtual bool set_name(const std::string& name) 
    {
        return false;
    }

    virtual bool get_icon(std::string& icon) const
    {
        return false;
    }

    virtual bool set_icon(const std::string& icon) 
    {
        return false;
    }

    virtual std::string pack() const
    {
        return "";
    }
    
    virtual void unpack(const std::string& strval)
    {
    }

    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_index)
    {
        // TODO
        return editor_base_ptr();
    }

    virtual void get_related_handles(duke_media_handle_vector& vHandles)
    {
        // TODO
    }

    virtual bool is_valid()
    {
        return true;
    }

    const duke_media_type get_type() const 
    {
        return this->m_handle.get_type();
    }


    // handle identification
    bool is_object() const {
        return this->m_handle.is_object();
    }

    bool is_object_declaration() const {
        return this->m_handle.is_object_declaration();
    }

    bool is_object_builtin() const {
        return this->m_handle.is_object_builtin();
    }

    bool is_type_null() const {
        return this->m_handle.is_type_null();
    }

    bool is_object_none() const {
        return this->m_handle.is_object_none();
    }

    bool is_object_bool() const {
        return this->m_handle.is_object_bool();
    }

    bool is_object_int() const {
        return this->m_handle.is_object_int();
    }

    bool is_object_float() const {
        return this->m_handle.is_object_float();
    }

    bool is_object_string() const {
        return this->m_handle.is_object_string();
    }

    bool is_object_bytes() const {
        return this->m_handle.is_object_bytes();
    }

    bool is_object_time() const {
        return this->m_handle.is_object_time();
    }

    bool is_object_array() const {
        return this->m_handle.is_object_array();
    }

    bool is_object_map() const {
        return this->m_handle.is_object_map();
    }

    bool is_object_user() const {
        return this->m_handle.is_object_user();
    }

    bool is_object_interval() const {
        return this->m_handle.is_object_interval();
    }

    bool is_object_bridge() const {
        return this->m_handle.is_object_bridge();
    }

    bool is_object_container_des() const {
        return this->m_handle.is_object_container_des();
    }

    bool is_declaration() const {
        return this->m_handle.is_declaration();
    }

    bool is_implementation() const {
        return this->m_handle.is_implementation();
    }

    bool is_execute() const {
        return this->m_handle.is_execute();
    }

    bool is_object_exec_iterator() const {
        return this->m_handle.is_object_exec_iterator();
    }

    bool is_object_exec_condition() const {
        return this->m_handle.is_object_exec_condition();
    }

    bool is_interface() const {
        return this->m_handle.is_interface();
    }

    bool is_interface_bridge() const {
        return this->m_handle.is_bridge_interface();
    }

    bool is_access() const {
        return this->m_handle.is_access();
    }

    bool is_anchor() const {
        return this->m_handle.is_anchor();
    }


    bool is_storage() const {
        return this->m_handle.is_storage();
    }

    bool is_interface_compound() const {
        return this->m_handle.is_interface_compound();
    }

public:
    friend bool operator<(const duke_media_base& v1, const duke_media_base& v2);
    friend bool operator==(const duke_media_base& v1, const duke_media_base& v2);
    friend bool operator!=(const duke_media_base& v1, const duke_media_base& v2);
    friend bool operator>(const duke_media_base& v1, const duke_media_base& v2);
    friend bool operator>=(const duke_media_base& v1, const duke_media_base& v2);
    friend bool operator<=(const duke_media_base& v1, const duke_media_base& v2);
    
};

inline bool operator<(const duke_media_base& v1, const duke_media_base& v2) {
    return (v1.m_handle < v2.m_handle);
}

inline bool operator==(const duke_media_base& v1, const duke_media_base& v2) {
    return (v1.m_handle == v2.m_handle);
}

inline bool operator!=(const duke_media_base& v1, const duke_media_base& v2) {
    return !(v1 == v2);
}

inline bool operator>(const duke_media_base& v1, const duke_media_base& v2) {
    return (v2 < v1);
}

inline bool operator<=(const duke_media_base& v1, const duke_media_base& v2) {
    return !(v2 < v1);
}

inline bool operator>=(const duke_media_base& v1, const duke_media_base& v2) {
    return !(v1 < v2);
}

// (hdecl)(himpl)...(hdecl)(himpl)
inline std::string pack_duke_media_handle_map(const duke_media_handle_map& hmap)
{
    return pack_dukeid_map(hmap);
}

// (hdecl)(himpl)...(hdecl)(himpl)
inline void unpack_duke_media_handle_map(
        const std::string& strhmap, duke_media_handle_map& hmap)
{
    return unpack_dukeid_map(strhmap, hmap);
}

// (hdecl)(himpl)...(hdecl)(himpl)
inline std::string pack_duke_media_handle_pair_vector(
        const duke_media_handle_pair_vector& hmap)
{
    return pack_dukeid_pair_vector(hmap);
}

// (hdecl)(himpl)...(hdecl)(himpl)
inline void unpack_duke_media_handle_pair_vector(
        const std::string& strhmap, duke_media_handle_pair_vector& hmap)
{
    return unpack_dukeid_pair_vector(strhmap, hmap);
}
// (hdecl)(himpl)...(hdecl)(himpl)
inline std::string pack_duke_media_hstr_map(const duke_media_hstr_map& hmap)
{
    return pack_strid_map(hmap);
}

// (hdecl)(himpl)...(hdecl)(himpl)
inline void unpack_duke_media_hstr_map(
        const std::string& strhmap, duke_media_hstr_map& hmap)
{
    return unpack_strid_map(strhmap, hmap);
}

inline bool
duke_media_read_handle(const std::string& strkey, std::string& strval)
{
    bool ret = duke_verify_db_impl::instance().read(strkey, strval);
    assert(ret);
    //assert(!strval.empty());
    return true;
}

inline bool
duke_media_write_handle(const std::string& strkey, const std::string& strval)
{
    bool ret = duke_verify_db_impl::instance().write(strkey, strval);
    if(!ret)
    {
        LOG_ERROR("duke_media_write_handle error!");
    }    
    return ret;
}

inline bool
duke_media_read_info(const std::string& strkey, std::string& strval)
{
    bool ret = duke_info_db_impl::instance().read(strkey, strval);
    assert(ret);
    //assert(!strval.empty());
    return true;
}

inline bool
duke_media_write_info(const std::string& strkey, const std::string& strval)
{
    bool ret = duke_info_db_impl::instance().write(strkey, strval);
    assert(ret);
    return true;
}

inline bool 
duke_media_get_handle(const std::string& strkey, duke_media_handle_vector& vid)
{
    std::string strval;
    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty())
        unpack_duke_media_handle_vector(strval, vid);
    return ret;
}

inline bool 
duke_media_get_handle(const std::string& strkey, duke_media_handle_vector& vid, std::string& strval)
{
    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty())
        unpack_duke_media_handle_vector(strval, vid);
    return ret;
}

    inline bool 
duke_media_get_mhandle(const std::string& strkey, duke_media_handle_map& vid)
{
    std::string strval;
    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty())
        unpack_duke_media_handle_map(strval, vid);
    return ret;
}

inline bool 
duke_media_write_mhandle(const std::string& strkey, const duke_media_handle_map& vid)
{
    std::string strval;
    strval = pack_duke_media_handle_map(vid);
    bool ret = duke_media_write_handle(strkey, strval);
    return ret;
}

    inline bool 
duke_media_get_strhandle(const std::string& strkey, duke_media_hstr_map& vid)
{
    std::string strval;
    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty())
        unpack_duke_media_hstr_map(strval, vid);
    return ret;
}

inline bool 
duke_media_write_strhandle(const std::string& strkey, const duke_media_hstr_map& vid)
{
    std::string strval;
    strval = pack_duke_media_hstr_map(vid);
    bool ret = duke_media_write_handle(strkey, strval);
    return ret;
}

inline bool
duke_media_check_handle(const std::string& strkey, const duke_media_handle& handle, std::string& strval)
{
    NEW_FUNC_SCOPE_TIMER(false);

    duke_media_handle_vector vid;
    duke_media_get_handle(strkey, vid, strval);
    //assert(ret);
    if (std::find(vid.begin(), vid.end(), handle) != vid.end())
        return true;
    else
        return false;
}

inline bool
duke_media_remove_handle(const std::string& strkey, const duke_media_handle& handle)
{
    std::string strval;
    duke_media_handle_vector vid;
    duke_media_get_handle(strkey, vid, strval);
    //assert(ret);
    duke_media_handle_iterator it;
    if ((it = std::find(vid.begin(), vid.end(), handle)) != vid.end())
    {
        vid.erase(it);
    }
    bool ret = duke_media_write_handle(strkey, pack_duke_media_handle_vector(vid));
    assert(ret);
    return true;
}

inline bool
duke_media_remove_handle_func(const std::string& strkey, const duke_media_handle& handle, const duke_media_handle& hfunc)
{
    std::string strval;
    duke_media_handle_vector vid;
    duke_media_get_handle(strkey, vid, strval);
    //assert(ret);
    duke_media_handle_iterator it;
    if ((it = std::find(vid.begin(), vid.end(), handle)) != vid.end())
    {
        vid.erase(it);
    }
    bool ret = duke_media_write_handle(strkey, pack_duke_media_handle_vector(vid));
    assert(ret);
    ret = duke_media_write_handle(hfunc.str(), "Formal");
    assert(ret);
    return true;
}

inline bool
duke_media_write_pair_handle(const duke_media_handle& hold, const duke_media_handle& hnew)
{
    std::string strkey;
    strkey = "pair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);
    //assert(ret);
    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        it->second = hnew;
    else
        mid.insert(std::make_pair(hold, hnew));

    bool ret = duke_media_write_mhandle(strkey, mid);
    assert(ret);
    return ret;
}
inline bool
duke_media_read_pair_handle(const duke_media_handle& hold, duke_media_handle& hnew)
{
    std::string strkey, strval;
    strkey = "pair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);

    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        hnew = it->second;
    else
        hnew = duke_media_handle(DUKE_MEDIA_TYPE_NULL);
    return true;
}

inline bool
duke_media_write_pair_strhandle(const duke_media_handle& handle, const std::string& strval)
{
    std::string strkey;
    strkey = "pair-strhandle";
    duke_media_hstr_map smid;
    duke_media_get_strhandle(strkey, smid);
    //assert(ret);
    duke_media_hstr_map_iterator it;
    if ((it = smid.find(handle)) != smid.end())
        it->second = strval;
    else
        smid.insert(std::make_pair(handle, strval));

    bool ret = duke_media_write_strhandle(strkey, smid);
    assert(ret);
    return ret;
}

inline bool
duke_media_read_pair_strhandle(const duke_media_handle& handle, std::string& strval)
{
    std::string strkey;
    strkey = "pair-strhandle";
    duke_media_hstr_map smid;
    duke_media_get_strhandle(strkey, smid);

    duke_media_hstr_map_iterator it;
    if ((it = smid.find(handle)) != smid.end())
        strval = it->second;
    else
        strval = "";
    return true;
}

inline bool duke_media_save_handle_name(const duke_media_handle& handle, const std::string& name)
{
    NEW_SCOPE_TIMER("duke_media_save_handle_name" ,false);
    /*
    std::string strval, strkey;
    if (handle.is_object() && !handle.is_object_bridge())
        strkey = "object_handle_name";
    else if (handle.is_storage())
        strkey = "storage_handle_name";
    else if (handle.is_interface())
        strkey = "interface_handle_name";
    else if (handle.is_implementation())
        strkey = "implement_handle_name";
    else if (handle.is_declaration())
        strkey = "declare_handle_name";
    else if (handle.is_container())
        strkey = "container_handle_name";
    else if (handle.is_object_bridge())
        strkey = "bridge_handle_name";
    else if (handle.is_anchor())
        strkey = "anchor_handle_name";
    else if (handle.is_access())
        strkey = "access_handle_name";

    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty() && ret)
    {
        dukeidstr_pair_vector vpair;
        unpack_dukeidstr_pair_vector(strval, vpair); 
        for (dukeidstr_pair_vector_iterator it = vpair.begin(); it != vpair.end(); ++it)
        {
            if (handle == it->first)
            {
                it->second = name;
                strval = pack_dukeidstr_pair_vector(vpair);
                bool ret = duke_media_write_handle(strkey, strval);
                return ret;
            }
        }
        vpair.push_back(std::make_pair(handle, name));
        strval = pack_dukeidstr_pair_vector(vpair);
        ret = duke_media_write_handle(strkey, strval);
        return ret;
    }
    else
    {
        strval += "(" + handle.str() + ")" + "(" + name + ")";
        ret = duke_media_write_handle(strkey, strval);
        assert(ret);
        return ret;
    }*/
    
    bool ret(true);
    if (!name.empty())
    {
        ret = duke_name_db_impl::instance().write(handle.str(), name);
        assert(ret); 
    }
    return ret;
}

// Obsoleted
//inline bool 
//duke_media_write_bridge(const db_value& value)
//{
//    duke_media_formobj_db* pdb = &(duke_media_formobj_db::instance());
//
//    DbTxn* txn(NULL);
//    bool ret = pdb->begin_txn(txn);
//    assert(ret);
//    int flag(0);
//    for (unsigned int i = 0; i < value.all_objects.size(); ++i)
//    {
//        NbDbResult ret;
//        // save the every bridge object
//        if (value.all_objects[i].object_id.is_bridge_object())
//        {
//            bridge_data_t data_t;
//            nb_id_t obj_id;
//            obj_impl_bridge::unpack(value.all_objects[i], obj_id, data_t);
//            //duke_media_save_handle_name(obj_id, data_t.name);
//
//            ret = pdb->write_(value.all_objects[i].object_id.str(),  
//                    pack_object(value.all_objects[i]), txn, flag);
//        }
//        else if (value.all_objects[i].object_id.is_object_decl_compound())
//        {
//            decl_compound_data_t data_t;
//            nb_id_t obj_id;
//            obj_impl_decl_compound::unpack(value.all_objects[i], obj_id, data_t);
//            /*if ((data_t.name == "get_text") || (data_t.name == "get_simple") || (data_t.name == "get_ref_size") ||
//                    (data_t.name == "get_all") || (data_t.name == "get_child_id_for_move") ||
//                    (data_t.name == "insert_child") || (data_t.name == "get_shared_access") ||
//                    (data_t.name == "set_user_access_map") || (data_t.name == "set_shared_objects") ||
//                    (data_t.name == "process"))*/
//            //duke_media_save_handle_name(obj_id, data_t.name);
//
//            ret = pdb->write_(value.all_objects[i].object_id.str(),  
//			      duke_logic_data_declare_compound(data_t).pack(), txn, flag);
//        }
//	else if (value.all_objects[i].object_id.is_object_decl_expanded())
//	{
//	    decl_expanded_data_t data_t;
//	    nb_id_t decl_id;
//	    obj_impl_decl_expanded::unpack(value.all_objects[i], decl_id, data_t);
//	    //duke_media_save_handle_name(decl_id, data_t.name);
//	    ret = pdb->write_(value.all_objects[i].object_id.str(),  
//			      duke_logic_data_declare_expanded(data_t).pack(), txn, flag);
//
//	}
//	else if (value.all_objects[i].object_id.is_object_interface_compound())
//        {
//	    if_compound_data_t data_t;
//	    nb_id_t if_id;
//	    obj_impl_interface_compound::unpack(value.all_objects[i], if_id, data_t);
//	    //duke_media_save_handle_name(if_id, data_t.name);
//	    ret = pdb->write_(value.all_objects[i].object_id.str(),  
//			      duke_logic_data_interface_compound(data_t).pack(), txn, flag);
//	}
//        else
//        {
//            ret = pdb->write_(value.all_objects[i].object_id.str(),  
//                    pack_object(value.all_objects[i]), txn, flag);
//        }
//        if (ret != NB_DB_RESULT_SUCCESS)
//        {
//            LOG_ERROR("ac_media_object_db::write false");
//            return false;
//        }
//    }
//    ret = pdb->commit(flag);
//    assert(ret);
//    return ret;
//}
//
// Obsoleted
//inline bool duke_media_write_content(const content& raw_data, const std::string& name)
//{
//    duke_media_formobj_db* pdb = &(duke_media_formobj_db::instance());
//
//    DbTxn* txn(NULL);
//    bool bret = pdb->begin_txn(txn);
//    assert(bret);
//    int flag(0);
//    
//    duke_media_save_handle_name(raw_data.object_id, name);
//
//    std::string strkey = raw_data.object_id.str();
//    std::string strval;
//    if (raw_data.object_id.is_object_decl_compound())
//    {
//        decl_compound_data_t data_t;
//        nb_id_t obj_id;
//        obj_impl_decl_compound::unpack(raw_data, obj_id, data_t);
//        strval = duke_logic_data_declare_compound(data_t).pack();
//    }
//    else
//        strval = pack_object(raw_data);
//    
//    NbDbResult ret = pdb->write_(strkey, strval, txn, flag);
//    if (ret != NB_DB_RESULT_SUCCESS)
//    {
//        LOG_ERROR("ac_media_object_db::write false");
//        return false;
//    }
//    ret = pdb->commit(flag);
//    assert(ret);
//    return bret;
//}

inline bool duke_media_read_name(const std::string& strkey, dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strval;
    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty() && ret)
    {
        dukeidstr_pair_vector vpair;
        unpack_dukeidstr_pair_vector(strval, vpair);
        for (dukeidstr_pair_vector_const_iterator it = vpair.begin(); it != vpair.end(); ++it)
        {
            vhandle.push_back(it->first);
            vname.push_back(it->second);
        }
        return ret;
    }
    return true;
}

inline bool duke_media_read_name(const duke_media_handle& handle, std::string& name)
{
    std::string strval, strkey;
    if (handle.is_object() && !handle.is_object_bridge())
        strkey = "object_handle_name";
    else if (handle.is_storage())
        strkey = "storage_handle_name";
    else if (handle.is_interface())
        strkey = "interface_handle_name";
    else if (handle.is_implementation())
        strkey = "implement_handle_name";
    else if (handle.is_declaration())
        strkey = "declare_handle_name";
    else if (handle.is_object_container_des())
        strkey = "container_des_handle_name";
    else if (handle.is_object_bridge())
        strkey = "bridge_handle_name";
    else if (handle.is_anchor())
        strkey = "anchor_handle_name";
    else if (handle.is_access())
        strkey = "access_handle_name";

    bool ret = duke_media_read_handle(strkey, strval);
    if (!strval.empty() && ret)
    {
        dukeidstr_pair_vector vpair;
        unpack_dukeidstr_pair_vector(strval, vpair);
        for (dukeidstr_pair_vector_const_iterator it = vpair.begin(); it != vpair.end(); ++it)
        {
            if (it->first == handle)
            {
                name = it->second;
                return true;
            }
        }
    }
    return ret;
}

//dir_path: directory for search file
//file_name: search file name
//path_found: the full path for this file if found
inline bool find_file(const boost::filesystem::path & dir_path, const std::string & file_name,
               boost::filesystem::path & path_found)
{
    if(!boost::filesystem::exists(dir_path))
        return false;
  
    boost::filesystem::directory_iterator end_itr;
    for(boost::filesystem::directory_iterator itr( dir_path ); itr != end_itr; ++itr)
    {
        if(boost::filesystem::is_directory(itr->status()))
        {
            if(find_file(itr->path(), file_name, path_found))
                return true;
        }
        else if(itr->leaf() == file_name)
        {
            path_found = itr->path();
            return true;
        }
    }
    return false;
}

inline bool find_dir(const boost::filesystem::path & dir_path, const std::string & dir_name,
                      boost::filesystem::path & path_found)
{
    if(!boost::filesystem::exists(dir_path))
        return false;
  
    boost::filesystem::directory_iterator end_itr;
    for(boost::filesystem::directory_iterator itr( dir_path ); itr != end_itr; ++itr)
    {
        if(boost::filesystem::is_directory(itr->status()))
        {
            if(itr->leaf() == dir_name)
            {
                path_found = itr->path();
                return true;
            }
            
            if(find_dir(itr->path(), dir_name, path_found))
                return true;
        }
    }
    return false;
}

inline std::string get_cur_path()
{
    char curPath[PATH_MAX];
    getcwd(curPath, PATH_MAX);
    return std::string(curPath);   
}

inline std::string get_resource_path()
{
    static std::string res_path;

    if(!res_path.empty())
        return res_path;
    
    boost::filesystem::path search_dir(get_cur_path() + "/../../");
    //set default found resource dir is ../resource
    boost::filesystem::path found_dir;

    find_dir(search_dir, "resource", found_dir);
    res_path = found_dir.string() + "/";
    LOG_DEBUG("find resource dir = "<< res_path);    
    
    return res_path;
}

inline std::string get_builtin_resource_path()
{    
    return get_resource_path() + "/object_builtin/";
}

//Loads image from a given file.
inline std::string load_image(const std::string &fileName)
{
    std::fstream input;
    int m_byteNum;
    std::string strimg;
    //if it is a directory, return false
    //if(boost::filesystem::is_directory(fileName))
    //    return "";
    
    //Opens the file
    input.open(fileName.c_str(), std::ios::in|std::ios::binary);
    //Fails to open the file
    if (!input)
        return "";

    //Moves to the end of the file
    input.seekg(0, std::ios::end);
    //Gets the size of the file
    m_byteNum = input.tellg();
    if (m_byteNum <= 0)
        return "";
 
    //Moves to the begin of the file
    input.seekg(0, std::ios::beg);
    
    //Creates the memory for the image
    char * tempImageData = new char[m_byteNum + 1]; 
    unsigned char* m_imageData = new unsigned char[m_byteNum + 1];

    //Reads the file to the buffer
    input.read(tempImageData, m_byteNum);
    //Gets the data from the temprate buffer
    memcpy(m_imageData, tempImageData, m_byteNum);
    m_imageData[m_byteNum] = '\0';

    //Closes the file
    input.close();
    input.clear();

    for (size_t i = 0; i < (size_t)m_byteNum; i++)
        strimg += m_imageData[i];

    //release memory
    delete[] tempImageData;
    delete[] m_imageData;

    return strimg;
}

inline bool
duke_media_write_pair_handle(const duke_media_handle& handle, const duke_media_handle& hold, const duke_media_handle& hnew)
{
    assert(!handle.is_type_null());
    std::string strkey;
    strkey = handle.str() + "-pair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);
    //assert(ret);
    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        it->second = hnew;
    else
        mid.insert(std::make_pair(hold, hnew));

    bool ret = duke_media_write_mhandle(strkey, mid);
    assert(ret);
    return ret;
}
inline bool
duke_media_read_pair_handle(const duke_media_handle& handle, const duke_media_handle& hold, duke_media_handle& hnew)
{
    assert(!handle.is_type_null());
    std::string strkey, strval;
    strkey = handle.str() + "-pair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);

    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        hnew = it->second;
    else
        hnew = duke_media_handle(DUKE_MEDIA_TYPE_NULL);
    return true;
}

inline bool 
duke_media_clear_pair_handle(const duke_media_handle& handle)
{
    assert(!handle.is_type_null());
    std::string strkey, strval;
    strkey = handle.str() + "-pair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);

    duke_media_handle_map_iterator it;
    for (it = mid.begin(); it != mid.end(); ++it)
        it->second = duke_media_handle(DUKE_MEDIA_TYPE_NULL);

    bool ret = duke_media_write_mhandle(strkey, mid);
    assert(ret);
    return ret;
}

inline bool 
duke_media_clear_cipair_handle(const duke_media_handle& handle)
{
    assert(!handle.is_type_null());
    std::string strkey, strval;
    strkey = handle.str() + "-cipair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);

    duke_media_handle_map_iterator it;
    for (it = mid.begin(); it != mid.end(); ++it)
        it->second = duke_media_handle(DUKE_MEDIA_TYPE_NULL);

    bool ret = duke_media_write_mhandle(strkey, mid);
    assert(ret);
    return ret;
}

inline bool
duke_media_write_cipair_handle(const duke_media_handle& handle, const duke_media_handle& hold, const duke_media_handle& hnew)
{
    assert(!handle.is_type_null());
    std::string strkey;
    strkey = handle.str() + "-cipair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);
    //assert(ret);
    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        it->second = hnew;
    else
        mid.insert(std::make_pair(hold, hnew));

    bool ret = duke_media_write_mhandle(strkey, mid);
    assert(ret);
    return ret;
}
inline bool
duke_media_read_cipair_handle(const duke_media_handle& handle, const duke_media_handle& hold, duke_media_handle& hnew)
{
    assert(!handle.is_type_null());
    std::string strkey, strval;
    strkey = handle.str() + "-cipair-handle";
    duke_media_handle_map mid;
    duke_media_get_mhandle(strkey, mid);

    duke_media_handle_map_iterator it;
    if ((it = mid.find(hold)) != mid.end())
        hnew = it->second;
    else
        hnew = duke_media_handle(DUKE_MEDIA_TYPE_NULL);
    return true;
}

inline bool
duke_media_write_fromto_handle(const duke_media_handle& hold, const duke_media_handle& hnew)
{
    assert(!hold.is_type_null());
    assert(!hnew.is_type_null());

    std::string keyold, keynew;
    keyold = hold.str() + "-pair-handle";
    keynew = hnew.str() + "-pair-handle";

    duke_media_handle_map mid;
    duke_media_get_mhandle(keyold, mid);

    bool ret = duke_media_write_mhandle(keynew, mid);
    assert(ret);
    return ret;
}

typedef std::tr1::shared_ptr<duke_media_base> duke_media_base_ptr;

#endif /* __DUKE_MEDIA_BASE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
