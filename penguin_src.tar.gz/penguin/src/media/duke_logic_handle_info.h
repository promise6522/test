#ifndef __DUKE_LOGIC_HANDLE_INFO_H
#define __DUKE_LOGIC_HANDLE_INFO_H

#include <string>
#include <vector>

#include "duke_logic_id.h"
#include "duke_logic_object_data.h"

struct package
{
    std::string pkg_name;
    std::string pkg_owner;
    std::string create_time;
    std::string modify_time;
    bool is_shared;
    uint32_t pkg_version;

    MSGPACK_DEFINE(pkg_name, pkg_owner, create_time, modify_time,
        is_shared, pkg_version);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    } 
};

struct node_info
{
    std::string name;
    int x;
    int y;
    int w;
    int h;

    MSGPACK_DEFINE(name, x, y, w, h);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    } 
};

inline std::string pack_node_vector(const std::vector<struct node_info>& vs)
{
    return serialize_by_msgpack(vs);
}

inline void unpack_node_vector(const std::string& strval, std::vector<struct node_info>& vnode)
{
    deserialize_by_msgpack(strval, vnode);
}

struct handle_attr
{
    std::string owner;
    std::string create_time;
    std::string modify_time;
    bool is_shared;
    uint32_t version;
    std::vector<struct node_info> node;

    MSGPACK_DEFINE(owner, create_time, modify_time,
        is_shared, version, node);


    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    } 
};

typedef dukeid_t package_id;

struct group
{
    std::vector<package_id> g_sub_package;
    std::vector<dukeid_t> g_handles;
    MSGPACK_DEFINE(g_sub_package, g_handles);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval) 
    {
        deserialize_by_msgpack(strval, *this);
    }
};

typedef struct package duke_media_package;
typedef struct handle_attr duke_media_hattr;
typedef struct group duke_media_group;
typedef struct node_info duke_media_node_info;


inline bool duke_media_set_hattr_node(const duke_media_handle& handle, const std::vector<duke_media_node_info>& node)
{
    std::string strval;

    strval = pack_node_vector(node);
    bool ret = duke_media_write_info(handle.str(), strval);
    assert(ret);
    return ret;
}

inline bool duke_media_set_hattr_node(const duke_media_handle& handle, const std::string& strval)
{
    bool ret = duke_media_write_info(handle.str(), strval);
    assert(ret);
    return ret;
}

inline bool duke_media_get_hattr_node(const duke_media_handle& handle, std::vector<duke_media_node_info>& node)
{
    std::string strval;
    duke_media_read_info(handle.str(), strval);
    if (!strval.empty())
        unpack_node_vector(strval, node);

    return true;
}

inline bool duke_media_get_hattr_node(const duke_media_handle& handle, std::string& strval)
{
    duke_media_read_info(handle.str(), strval);
    return true;
}

#endif /* __DUKE_LOGIC_HANDLE_INFO_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
