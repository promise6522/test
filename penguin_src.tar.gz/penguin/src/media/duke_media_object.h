#ifndef __DUKE_MEDIA_OBJECT_H
#define __DUKE_MEDIA_OBJECT_H

//C 98 header file
#include <iostream>
#include <string.h>
#include <list>
#include <map>
#include <utility>

#include <boost/smart_ptr.hpp>

//duke header file
#include "duke_logic_id.h"
//#include "ac_object/obj_impl_array.h"
//#include "logic/duke_logic_object.h"
#include "duke_media_base.h"
#include "duke_logic_object_data.h"
#include "duke_media_interface.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_descriptor.h"
#include "duke_media_compound_interface.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_map.h"
#include "duke_media_declare_expanded.h"
#include "duke_index_manager.h"

class duke_media_none : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //by duke_media_base_factory::get_media_from_handle
    duke_media_none() : m_hif(NB_INTERFACE_NONE)
    {
    }

    duke_media_none(const host_committer_id_t& host_comm_id) 
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_NONE, host_comm_id), 
        m_hif(NB_INTERFACE_NONE)
    {
        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "none");
        //assert(ret);
    }

    duke_media_none(const duke_media_handle& handle) : m_hif(NB_INTERFACE_NONE) 
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_NONE);

        //set handle status and you can know where this id come from
        this->set_handle_status( get_media_handle_status(handle) );

        this->set_handle(handle);

        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "none");
        //assert(ret);
    }

    bool get_value() const 
    {
        return true;
    }

    bool set_value() 
    {
        return true;
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "none";
        return true;
    }

    virtual bool set_name(const std::string& name) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "none.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& icon) 
    {
        return true;
    }
};

class duke_media_bool : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //by duke_media_base_factory::get_media_from_handle
    duke_media_bool() : m_hif(NB_INTERFACE_BOOL)
    {
    }

    duke_media_bool(const host_committer_id_t& host_id) : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_BOOL, host_id), 
                                                          m_hif(NB_INTERFACE_BOOL) 
    {
        bool ret = this->get_handle().set_value(false);
        assert(ret);

        //here noted by elison
        //ret = duke_media_save_handle_name(this->get_handle(), "boolean");
        //assert(ret);
    }

    duke_media_bool(const duke_media_handle& handle) : m_hif(NB_INTERFACE_BOOL) 
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_BOOL);
        
        //set handle status, and you can know where id come from
        this->set_handle_status( get_media_handle_status(handle) );
        this->set_handle(handle);
        
        //here noted by elison
        //bool ret = duke_media_save_handle_name(this->get_handle(), "boolean");
        //assert(ret);
    }

    bool get_value(bool& value) const 
    {
        return this->get_handle().get_value(value);
    }

    bool set_value(bool value) 
    {
        return get_handle().set_value(value);
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "boolean";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "boolean.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }
};


class duke_media_int : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //by duke_media_base_factory::get_media_from_handle
    duke_media_int() : m_hif(NB_INTERFACE_INT)
    {
    }

    duke_media_int(const host_committer_id_t& host_id) : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_INT, host_id), 
                                                        m_hif(NB_INTERFACE_INT)
    {
        bool ret = this->get_handle().set_value(0);
        assert(ret);

        //here noted by elison
        //ret = duke_media_save_handle_name(this->get_handle(), "integer");
        //assert(ret);
    }

    duke_media_int(const duke_media_handle& handle) : m_hif(NB_INTERFACE_INT)
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_INT);

        //set handle status and you can know where this id come from
        this->set_handle_status( get_media_handle_status(handle) );
        this->set_handle(handle);

        //here noted by elison
        //bool ret = duke_media_save_handle_name(this->get_handle(), "integer");
        //assert(ret);
    }

    bool get_value(int& value) const 
    {
        return get_handle().get_value(value);
    }

    bool set_value(int value) 
    {
        return get_handle().set_value(value);
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "integer";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "integer.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }
};

class duke_media_float : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //by duke_media_base_factory::get_media_from_handle
    duke_media_float() : m_hif(NB_INTERFACE_FLOAT)
    {
    }

    duke_media_float(const host_committer_id_t& host_id): duke_media_base(DUKE_MEDIA_TYPE_OBJECT_FLOAT, host_id), 
                                                        m_hif(NB_INTERFACE_FLOAT)
    {
        bool ret = this->get_handle().set_value(0);
        assert(ret);

        //here noted by elison
        //ret = duke_media_save_handle_name(this->get_handle(), "float");
        //assert(ret);
    }

    duke_media_float(const duke_media_handle& handle) : m_hif(NB_INTERFACE_FLOAT)
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_FLOAT);
        this->set_handle(handle);

        //here noted by elison
        //bool ret = duke_media_save_handle_name(this->get_handle(), "float");
        //assert(ret);
    }

    bool get_value(float& value) const 
    {
        return get_handle().get_value(value);
    }

    bool set_value(float value) 
    {
        if (value <= 0.00001 && value >= -0.00001)
            return get_handle().set_value(0);
        return get_handle().set_value(value);
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "float";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "float.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }
};

class duke_media_string : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //By duke_media_base_factory::get_media_from_handle()
    duke_media_string() : m_hif(NB_INTERFACE_STRING)
    {
    }
    
    duke_media_string(const host_committer_id_t& host_id) 
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_STRING, host_id), 
        m_hif(NB_INTERFACE_STRING)
    {
        bool ret = this->get_handle().set_value(std::string(""));
        assert(ret);

        //here noted by elison.wu
        //ret = duke_media_save_handle_name(this->get_handle(), "string");
        //assert(ret);
    }

    duke_media_string(const duke_media_handle& handle) : m_hif(NB_INTERFACE_STRING) {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_STRING);

        //By seting status and you can know where this id come from
        this->set_handle_status(get_media_handle_status(handle));

        this->set_handle(handle);
        
        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "string");
        //assert(ret);
    }

    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_index)
    {
        StringValue_editor_ptr pString(new (std::nothrow) StringValue_editor());

        //value of the object
        std::string value;
        this->get_value(value);
        pString->set_value(value);

        //main index
        main_index = mgr.request_index_for_editor(this->get_handle(), pString);

        return pString;
    }

    // clone a new handle with the same content
    duke_media_handle clone_new_handle(const host_committer_id_t& hc_id) const
    {
        // request a temp handle
        duke_media_string newStr(hc_id);

        // copy the content
        std::string value;
        this->get_value(value);
        newStr.set_value(value);

        return newStr.get_handle();
    }

    bool get_value(std::string& value) const 
    {
        this->get_handle().get_value(value);
        return true;
    }

    bool set_value(std::string value) 
    {
        return this->get_handle().set_value(value);
    }

    bool get_interface(duke_media_handle& hif) const {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const {
        name = "string";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) {
        return true;
    }

    virtual bool get_icon(std::string& icon) const {
        icon = load_image(get_builtin_resource_path() + "string.png");
        if (icon.empty())
            return false;
        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) {
        return true;
    }

    friend bool operator<(const duke_media_string& v1, const duke_media_string& v2);
    friend bool operator==(const duke_media_string& v1, const duke_media_string& v2);
    friend bool operator>(const duke_media_string& v1, const duke_media_string& v2);
};

inline bool operator<(const duke_media_string& v1, const duke_media_string& v2)
{
    std::string strval, strval1;
    bool ret = v1.get_value(strval);
    assert(ret);
    ret = v2.get_value(strval1);
    assert(ret);

    return (strval < strval1);
}

inline bool operator==(const duke_media_string& v1, const duke_media_string& v2)
{
    std::string strval, strval1;
    bool ret = v1.get_value(strval);
    assert(ret);
    ret = v2.get_value(strval1);
    assert(ret);

    return (strval == strval1);
}

inline bool operator>(const duke_media_string& v1, const duke_media_string& v2)
{
    return (v2 < v1);
}

class duke_media_bytes : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //By duke_media_base_factory::get_media_from_handle()
    duke_media_bytes() : m_hif(NB_INTERFACE_BYTES)
    {
    }

    duke_media_bytes(const host_committer_id_t& host_id)
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_BYTES, host_id),
        m_hif(NB_INTERFACE_BYTES)
    {
        duke_bytes_t value;
        value.m_crc = 0;
        value.m_length = 0;
        value.m_value = "";

        bool ret = this->set_value(value);
        assert(ret);

        //here noted by elison.wu
        //ret = duke_media_save_handle_name(this->get_handle(), "bytes");
        //assert(ret);
    }

    duke_media_bytes(const duke_media_handle& handle) : m_hif(NB_INTERFACE_BYTES) 
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_BYTES);

        //by set handle status, you can know where data related with id come from 
        this->set_handle_status( get_media_handle_status(handle) );

        this->set_handle(handle);

        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "bytes");
        //assert(ret);
    }

    // clone a new handle with the same content
    duke_media_handle clone_new_handle(const host_committer_id_t& hc_id) const
    {
        // request a temp handle
        duke_media_bytes newBytes(hc_id);

        // copy the content
        duke_bytes_t value;
        this->get_value(value);
        newBytes.set_value(value);

        return newBytes.get_handle();
    }

    //transform data of bytes to xml struct of compiler
    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_index)
    {
        BytesValue_editor_ptr pBytes(new (std::nothrow) BytesValue_editor());

        // the value of bytes
        std::string value;
        this->get_handle().get_value(value);
        duke_bytes_t bytes_value;
        unpack_bytes(value, bytes_value);
        //pBytes->set_value(std::vector<char>(value.begin(), value.end()));
        pBytes->set_value(std::vector<char>(bytes_value.m_value.begin(), bytes_value.m_value.end()));
        
        // main index
        main_index = mgr.request_index_for_editor(this->get_handle(), pBytes);

        return pBytes;
    }

    bool get_value(duke_bytes_t& value) const 
    {
        std::string strval;
        if (e_handle_core == this->get_handle().get_value(strval))
        {
            content raw_data;
            unpack_object(strval, raw_data);

            bytes_data_t m_cData;
            nb_id_t id;
            obj_impl_bytes::unpack(raw_data, id, m_cData);

            value.m_crc = m_cData.crc;
            value.m_length = m_cData.length;
            value.m_value = m_cData.value;
        }
        else
        {
            unpack_bytes(strval, value);
        }

        return true;
    }

    bool set_value(const duke_bytes_t& value)
    {
        return this->get_handle().set_value( pack_bytes(value) );           
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "bytes";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "bytes.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }

    friend bool operator<(const duke_media_bytes& v1, const duke_media_bytes& v2);
    friend bool operator==(const duke_media_bytes& v1, const duke_media_bytes& v2);
    friend bool operator>(const duke_media_bytes& v1, const duke_media_bytes& v2);
};

inline bool operator<(const duke_media_bytes& v1, const duke_media_bytes& v2)
{
    duke_bytes_t strval, strval1;
    bool ret = v1.get_value(strval);
    assert(ret);
    ret = v2.get_value(strval1);
    assert(ret);

    return (strval.m_value < strval1.m_value);
}

inline bool operator==(const duke_media_bytes& v1, const duke_media_bytes& v2)
{
    duke_bytes_t strval, strval1;
    bool ret = v1.get_value(strval);
    assert(ret);
    ret = v2.get_value(strval1);
    assert(ret);

    return (strval.m_value == strval1.m_value);
}

inline bool operator>(const duke_media_bytes& v1, const duke_media_bytes& v2)
{
    return (v2 < v1);
}

class duke_media_interval : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //By duke_media_base_factory::get_media_from_handle()
    duke_media_interval() : m_hif( DUKE_MEDIA_TYPE_OBJECT_INTERVAL )
    {
    }

    duke_media_interval(const host_committer_id_t& host_id): duke_media_base(DUKE_MEDIA_TYPE_OBJECT_INTERVAL, host_id),
                                                            m_hif(NB_INTERFACE_INTERVAL)
    {
        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "interval");
        //assert(ret);
    }

    duke_media_interval(const duke_media_handle& handle) : m_hif(NB_INTERFACE_INTERVAL) 
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_INTERVAL);

        //by set handle status and you can know where this handle come from
        this->set_handle_status( get_media_handle_status(handle) );
        this->set_handle(handle);

        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "interval");
        //assert(ret);
    }

    bool get_value(duke_time_t& value) const 
    {
        return get_handle().get_value(value.second_cnt, value.pico_second_cnt);
    }

    bool set_value(duke_time_t value) 
    {
        return get_handle().set_value(value.second_cnt, value.pico_second_cnt);
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "interval";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "interval.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }
};

class duke_media_time : public duke_media_base
{
private:
    duke_media_handle m_hif;

public:
    //By duke_media_base_factory::get_media_from_handle()
    duke_media_time() : m_hif( DUKE_MEDIA_TYPE_OBJECT_TIME )
    {
    }

    duke_media_time(const host_committer_id_t& host_id) : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_TIME, host_id),
                                                          m_hif(NB_INTERFACE_TIME)
    {
        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "time");
        //assert(ret);
    }

    duke_media_time(const duke_media_handle& handle) : m_hif(NB_INTERFACE_TIME) 
    {
        assert(handle.get_type() == DUKE_MEDIA_TYPE_OBJECT_TIME);

        //set handle status, and you can know where id come from
        this->set_handle_status( get_media_handle_status(handle) );
        this->set_handle(handle);

        //here noted by elison.wu
        //bool ret = duke_media_save_handle_name(this->get_handle(), "time");
        //assert(ret);
    }

    bool get_value(duke_time_t& value) const 
    {
        return this->get_handle().get_value(value.second_cnt, value.pico_second_cnt);
    }

    bool set_value(duke_time_t value) 
    {
        return get_handle().set_value(value.second_cnt, value.pico_second_cnt);
    }

    bool get_interface(duke_media_handle& hif) const 
    {
        hif = m_hif;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const 
    {
        duke_media_interface mif(m_hif);
        return mif.get_declarations(hdecls);
    }

    virtual bool get_name(std::string& name) const 
    {
        name = "time";
        return true;
    }

    virtual bool set_name(const std::string& /*name*/) 
    {
        return true;
    }

    virtual bool get_icon(std::string& icon) const 
    {
        icon = load_image(get_builtin_resource_path() + "time.png");
        if (icon.empty())
            return false;

        return true; 
    }

    virtual bool set_icon(const std::string& /*icon*/) 
    {
        return true;
    }
};



// {(name_handle)(icon_handle)}
// {interface_handle}
// {(hdecl)(himpl)...(hdecl)(himpl)}
// {(hobj)(hif)...(hobj)(hif)}
//
class duke_media_object : public duke_media_base
{
protected:
    duke_logic_data_user m_user;
    bool is_singletonobj;
    int singletonobjnum;

    descriptor_data_t desc_data;
    user_data_t data_t;
    nb_id_t obj_id, desc_id;

    host_committer_id_t hc_id;
    std::string user_name;
public:
    duke_media_object();
    duke_media_object(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");
    duke_media_object(const duke_media_handle& hobj, const std::string& username = "anonymous-name");

private:
    bool add_decl_to_interface(const duke_media_handle& hdecl);
    bool update_funcs(const duke_media_handle& hdecl, const duke_media_handle& himpl);
    bool update_funcs(const duke_media_handle& hdecl);    

public:
    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_index);
    virtual void get_related_handles(duke_media_handle_vector& vHandles);
    virtual bool is_valid();

    // basic
    bool assign(const duke_media_handle& hobj);
    bool is_singleton_object() const;
    bool get_name(std::string& name) const;    
    bool set_name(const std::string& name);    
    bool get_icon(std::string& icon) const;
    bool set_icon(const std::string& icon);

    // compose/decompose
    bool compose(const duke_media_handle& hadd, const duke_media_handle& hdel);
    bool decompose(duke_media_handle_vector& hobjs) const;

    // sub object
    bool get_subobjects(duke_media_handle_vector& hobjs) const;

    bool get_subinterfaces(duke_media_handle_vector& hifs) const;

    bool get_subobject_and_interfaces(duke_media_handle_pair_vector& objs_vector) const;

    bool get_function_except_compose(duke_media_handle_pair_vector& funcs_vector) const;    

    // object
    bool find_subobject(const duke_media_handle& hobj) const;
    bool add_subobject(const duke_media_handle& hobj, const duke_media_handle& hcif);
    bool exist_singleton_object(const duke_media_handle& hobj);    
    bool del_subobject(const duke_media_handle& hobj);
    bool clear_subobject();

    // interface
    bool get_interface(duke_media_handle& hif) const;
    
    // declaration
    bool get_declarations(duke_media_handle_vector& hdecls) const;

    // implemention
    bool get_implementation(const duke_media_handle& hdecl, duke_media_handle& himpl);
    bool del_implementation(const duke_media_handle& hdecl);

    // function (both declaration and implemention)
    bool add_function(const duke_media_handle& hdecl, const duke_media_handle& himpl);
    bool add_function(const duke_media_handle& hdecl);
    bool del_function(const duke_media_handle& hdecl);
    bool clear_function();
    bool clear();

    //generate & copy
    bool copy(const duke_media_handle& hobj);
    bool check() const;

    // OBSOLETED!!!
     bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
    // bool generate_sub_item(const std::string& username);
    // bool pack_new_structure(const std::string& username, const duke_media_handle& hfather);
    // bool replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather = 0);

public:
    virtual std::string pack() const;
    virtual void unpack(const std::string& strval);

    bool save();    

private:
    std::string non_virtual_pack() const;
    void unpack_helper(const std::string& strval);

    duke_media_handle_pair_vector_iterator find_decl(const duke_media_handle& hdecl);    

    bool find_declaration(const duke_media_handle& hdecl);    

    bool clone();
};


#endif /* __DUKE_MEDIA_OBJECT_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
