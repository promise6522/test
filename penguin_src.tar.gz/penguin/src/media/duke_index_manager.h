/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#ifndef _DUKE_INDEX_MANAGER_H_
#define _DUKE_INDEX_MANAGER_H_

#include "duke_media_base_factory.h"
#include "nb_compiler_type.h"
#include "nb_compiler.h"


class index_manager
{
public:
    // get_index_form_handle()
    // called by duke_media_base::to_xml_struct()
    int get_index_from_handle(const duke_media_handle& h);


    // request_index_for_editor()
    // Always request a new index for a editor with no coresponding handle
    int request_index_for_editor(const editor_base_ptr& pEditor);

    // request_index_for_editor()
    // request a new index according to the handle
    int request_index_for_editor(const duke_media_handle& h, const editor_base_ptr& pEditor);


    // get_index_info
    // generate the information the compiler needed
    bool get_index_info(index_info_t& info);


public:
    index_manager();
    ~index_manager();


private:
    int new_index();

    bool check_related_handles();

private:
    void dump_index_editor_map(const std::map<int, editor_base_ptr>& idx_editor_map) const;
    void dump_index_id_map(const std::map<int, nb_id_t>& idx_id_map) const;

private:
    int                                     index_;
    std::map<duke_media_handle, int>        handle_index_map_;
    std::map<nb_id_t,           int>        id_index_map_;
    std::map<int, editor_base_ptr>          index_editor_map_;

    std::queue<duke_media_handle>           handles_to_process_;
};

#endif /* _DUKE_INDEX_MANAGER_ */
