#ifndef __DUKE_MEDIA_IMPLEMENT_H
#define __DUKE_MEDIA_IMPLEMENT_H

// C++ 98 header files
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header files
#include "stdx_algorithm.h"
#include "duke_media_base.h"
#include "duke_media_declare.h"
#include "duke_media_execute.h"
#include "duke_logic_object_data.h"
#include "ac_object/obj_impl_exec_impl.h"

#include "duke_logic_handle_info.h"


const uint32_t DUKE_NODE_DEFAULT = 0x00;
const uint32_t DUKE_NODE_LOOP    = 0x01;
const uint32_t DUKE_NODE_COND    = 0x02;
const uint32_t DUKE_NODE_NONE    = 0x03;

//bool duke_media_clone(const duke_media_handle& hold, duke_media_handle& hnew);


class duke_media_implement : public duke_media_base
{
private:
    // ----------------------MSGPACK_DEFINE----------------------
    // for name store and in/out ports
    duke_media_declare_parameters m_decl;

    // for nodes and paths
    duke_media_graph m_graph;

    /// OBSOLETED, remain for backward-compatibility
    duke_media_handle_vector m_in_ports;    
    duke_media_handle_vector m_out_ports;

    // <obj, func>
    dukeidstr_pair_vector m_ownerfuncs;

    // default/cond/loop
    uint32_t m_type;

    // master and share option
    duke_media_handle m_master;
    bool m_shared;
    // ----------------------MSGPACK_DEFINE----------------------

public:
    MSGPACK_DEFINE(m_decl, m_graph, m_type, m_in_ports, m_out_ports, m_ownerfuncs,
        m_shared, m_master);


public:
    virtual std::string pack() const
    {
        return pack_helper();
    }

    virtual void unpack(const std::string& strval);

    std::string pack_helper() const
    {
        return serialize_by_msgpack(*this);
    }
    void unpack_helper(const std::string& strval);

private:
    bool unpack_from_core_data(const std::string& strval);


public:
    duke_media_implement();

    duke_media_implement(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");

    duke_media_implement(const duke_media_handle& himpl, const std::string& username = "anonymous-name");

    ~duke_media_implement();

public:
    // methods for implement
    bool assign(const duke_media_handle& himpl);
    
    bool clear_flags();
    bool loop() const;
    bool set_loop();
    bool cond() const;
    bool set_cond();
    bool general() const;    
    bool set_general();    
    bool none() const;    
    bool set_none();
    bool get_name(std::string& name) const;    
    bool set_name(const std::string& name);
    bool get_icon(std::string& icon) const;
    bool set_icon(const std::string& icon);    

    // interfaces
    bool get_interfaces(duke_media_handle_vector& hiifs,
                        duke_media_handle_vector& hoifs) const;    
    bool get_in_interfaces(duke_media_handle_vector& hiifs) const;    
    bool get_out_interfaces(duke_media_handle_vector& hoifs) const;
    int get_iport_number() const;
    int get_oport_number() const;
    bool match_declaration(const duke_media_handle& hdecl) const;
    bool match_declaration(const duke_media_handle_vector& hiifs_decl, const duke_media_handle_vector& hoifs_decl) const;

    // input interfaces for declaration 
    bool add_input_port(const duke_media_handle& hif);    
    bool del_input_port(const int& hif);
    
    // output interfaces for declaration 
    bool add_output_port(const duke_media_handle& hif);    
    bool del_output_port(const int& hif);
    bool clear_input_ports();
    bool clear_output_ports();    
    bool clear_internal_nodes();

    bool is_node_outport_time(const std::string& nodeName, const unsigned portNum);
    bool is_node_inport_time(const std::string& nodeName, const unsigned portNum);

    // methods for nodes and paths
    void get_media_nodes(std::vector<duke_media_node>& nodes) const;
    void get_object_nodes(std::vector<duke_media_node>& nodes) const;
    void get_func_nodes(std::vector<duke_media_node>& nodes) const;
    void get_media_paths(std::vector<duke_media_path>& paths) const;
    bool replace_path_name(const std::string& srcName, const std::string& targetName);

    // methods for nodes
    bool add_func_node(const std::string& name, 
                    const duke_media_handle& hDecl,
                    const duke_media_handle& hOwnerIf = NB_INTERFACE_NONE,
                    const duke_media_handle& hexdecl = NBID_TYPE_NULL);    

    bool add_object_node(const host_committer_id_t& host_id, const std::string& name,
                         const duke_media_handle& hobj);
    bool remove_node(const std::string& name);
    bool set_object_node(const dukeid_t& source, const dukeid_t& dest);
   
    // methods for paths
    bool add_path(const std::string& onode, int oport,
                  const std::string& inode, int iport);    
    bool remove_path(const std::string& onode, int oport,
                     const std::string& inode, int iport);

    bool add_time_path(const std::string& onode, int oport,
                  const std::string& inode, int iport, int timePort);    
    bool remove_time_path(const std::string& onode, int oport,
                     const std::string& inode, int iport, int timePort);

    bool add_owner_func_pair(const duke_media_handle& owner, const std::string& func);
    bool del_owner_func_pair(const duke_media_handle& owner, const std::string& func);
    bool find_owner_func_pair(const duke_media_handle& owner, const std::string& func);
    bool find_owner(const std::string& func, duke_media_handle& owner);
    bool clear_owner_func();

    bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
    bool generate_sub_item(const std::string& username);

    bool copy(const duke_media_handle& himpl);

    bool check() const;

    bool set_ports_by_declaration(const duke_media_handle& hdecl);

    void generate_out_path_info(exec_impl_graph_t& tmp_graph);

    //add by mike
    //duke_media_handle get_decl_id() const;

    //add by bruce
    bool set_share();
    bool get_share() const;
    bool set_master(const duke_media_handle& master);
    duke_media_handle get_master() const;

    //
    virtual bool is_valid();

    //new interface for generate xml struct for compiler by ning
    virtual editor_base_ptr  to_xml_struct(index_manager& mgr, int& main_index);
    
    //helper function for get related handles
    virtual void get_related_handles(duke_media_handle_vector& vHandles);

private:

    void print_info(const exec_impl_graph_t& graph_t);

    //int get_iport_number(const nb_id_t& id);
    //void insert_ss_table(const nb_id_t& id, int index, int timelinecnt);

    Coordinate get_coordinate_by_name(const std::vector<node_info>& vNodeInfo, const std::string& name);

    editor_base_ptr to_xml_general(index_manager& mgr, int& main_index);
    editor_base_ptr to_xml_exec_iterator(index_manager& mgr, int& main_index);
    editor_base_ptr to_xml_exec_condition(index_manager& mgr, int& main_index);

    int to_xml_obj_func(const duke_media_handle& decl_id, index_manager& mgr);

    int to_xml_storage_func(const int storage_idx,
            const duke_media_handle& hdecl, 
            index_manager& mgr);
    

public:
    bool get_inports(duke_media_handle_vector& vinports) const;
    bool get_outports(duke_media_handle_vector& voutports) const;
    bool set_port_interfaces(const duke_media_handle_vector& viifs,
            const duke_media_handle_vector& voifs);

    bool init_save(DbTxn* txn = NULL);
};

#endif /* __DUKE_MEDIA_IMPLEMENT_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
