#ifndef _DUKE_MEDIA_DECLARE_EXPANDED_H_
#define _DUKE_MEDIA_DECLARE_EXPANDED_H_
#include "duke_media_base.h"
#include "nb_id.h"
#include "ac_object/obj_impl_decl_expanded.h"

class duke_media_declare_expanded : public duke_media_base
{
private:
    duke_logic_data_declare_expanded m_cData;
    host_committer_id_t hc_id;

public:
    duke_media_declare_expanded();
    duke_media_declare_expanded(const host_committer_id_t& host_id,
                                const std::string& username = "anonymous-name");    
    duke_media_declare_expanded(const duke_media_handle& decl_handle,
                                const std::string& username = "anonymous-name");
    ~duke_media_declare_expanded();

    bool assign(const dukeid_t& decl_id);
    bool generate(const std::string& username, duke_media_handle& new_handle, 
                  const host_committer_id_t& host_id, const duke_media_handle& hfather);

    virtual std::string pack() const;
    virtual void unpack(const std::string& strdecl);
    std::string pack_helper() const;
    void unpack_helper(const std::string& strdecl);

    bool get_name(std::string& name) const;
    virtual bool set_name(const std::string& name);    
    virtual bool get_icon(std::string& icon) const;
    virtual bool set_icon(const std::string& icon);

    dukeid_t get_decl_id() const;
    bool set_decl_id(const dukeid_t& decl_id); 

    dukeid_vector get_decl_vif() const;
    bool set_decl_vif(const dukeid_vector& decl_vif);

    bool add_constraints_if(const dukeid_t& single_if);
    bool del_constraints_if(const dukeid_t& single_if);

    int get_iport_number() const;
    int get_oport_number() const;

    bool get_interfaces(duke_media_handle_vector& hiifs, duke_media_handle_vector& hoifs) const;

    nb_id_t get_nb_id() const;
    bool set_array_type(const dukeid_t& decl_id, const dukeid_t& if_type);
    bool set_expanded_type(const dukeid_t& decl_id, const dukeid_vector& if_type);

    //for compiler
    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_idx);
private: 
    //calculate expanded_declare's port information
    bool get_dynamic_info(duke_logic_data_declare_compound&  info) const;

    //std::string pack_data();
    //bool replace_content(const std::string& username, std::string& strval, 
    //                     const host_committer_id_t& host_id, const duke_media_handle& hfather); 
    //bool replace_string(const std::string& username, std::string& strval, const host_committer_id_t& host_id,
    //                    const duke_media_handle& hfather, const duke_media_handle& rep_handle);

    bool init_save(DbTxn* txn = NULL);

};
#endif //_duke_media_declare_expanded_h_
