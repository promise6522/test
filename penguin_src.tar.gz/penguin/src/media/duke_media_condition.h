#ifndef __DUKE_MEDIA_CONDITION_H
#define __DUKE_MEDIA_CONDITION_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

#include "ac_object/obj_impl_exec_condition.h"

class duke_media_condition : public duke_media_base
{
private:
    exec_cond_data_t condition_info; 

public:
    duke_media_condition(const duke_media_handle& hcondition, const std::string& username = "anonymous-name") 
    {
        assert(hcondition.is_object_exec_condition());
        
        std::string strval;
        ac_object_db_impl::instance().read(hcondition.str(), strval);
        if (!strval.empty())
        {
            content con;
            unpack_object(strval, con);
            nb_id_t id;
            obj_impl_exec_condition::unpack(con, id, condition_info);
        }
    }

    bool get_name(std::string& name) const
    {
        name = condition_info.name;
        return true;
    }

    bool get_icon(std::string& icon) const
    {
        icon = "";
        return true;
    }

    bool get_external_decl(duke_media_handle& hdecl)
    {
        hdecl.str(condition_info.external_decl.str());
        return true;
    }

    bool get_interfaces(duke_media_handle_vector& hiifs, duke_media_handle_vector& hoifs) const
    {
        assert(condition_info.external_decl.is_object_decl_compound());
        
        duke_media_compound_declare declMedia(condition_info.external_decl);
        declMedia.get_interfaces(hiifs, hoifs);
        return true;
    }
};

#endif /* __DUKE_MEDIA_CONDITION_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
