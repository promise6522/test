#ifndef __DUKE_MEDIA_COMPOUND_DECLARATION_H
#define __DUKE_MEDIA_COMPOUND_DECLARATION_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "duke_media_base.h"
#include "duke_constant_def.h"
#include "duke_logic_object_data.h"
#include "duke_media_compound_interface.h"

typedef std::map<dukeid_t, std::pair<dukeid_vector, dukeid_t> >    table;
typedef std::map<dukeid_t, std::pair<dukeid_vector, dukeid_t> >::iterator    table_ite;

typedef std::map<std::string, dukeid_vector> mStrVid;
typedef std::map<std::string, dukeid_vector>::iterator mStrVid_ite;

typedef std::vector<duke_logic_data_declare_compound::m_iport_t>::iterator  iport_ite;
typedef std::vector<duke_logic_data_declare_compound::m_oport_t>::iterator  oport_ite;
typedef std::vector<duke_logic_data_declare_compound::m_decl_exp_group>::iterator group_ite;
typedef std::vector<duke_logic_data_declare_compound::m_decl_exp_idx>::iterator decl_exp_ite;

class duke_media_compound_declare : public duke_media_base
{
private:
    duke_logic_data_declare_compound m_data;
    nb_id_t  obj_id;

    host_committer_id_t hc_id;
public:
    static table ifTable;
        
public:
    duke_media_compound_declare();

    // for compose & decompose
    duke_media_compound_declare(const host_committer_id_t& host_id, 
            duke_media_type type, 
            const std::string& username = "anonymous-name");

    // for an existing handle (either from temp or core)
    duke_media_compound_declare(const duke_media_handle& hdecl, 
            const std::string& username = "anonymous-name");


    // generate a new handle
    duke_media_compound_declare(const host_committer_id_t& host_id, 
            const std::string& username = "anonymous-name");



    bool set_func_type(const std::string& name);

    bool get_func_type(std::string& func_type) const;


    bool assign(const duke_media_handle& hif);



    duke_media_handle get_id() const;

    bool set_array_content(const std::string& name, 
            const duke_media_handle& hif,
            DbTxn* txn); 

    bool set_map_content(const std::string& name, 
            const dukeid_vector& vif, 
            DbTxn* txn);

    bool set_storage_content(const std::string& name,
            const dukeid_vector& ifctype,
            DbTxn* txn);

    virtual bool set_name(const std::string& name);

    virtual bool get_name(std::string& name) const;

    virtual bool get_icon(std::string& icon) const;

    virtual bool set_icon(const std::string& icon);

    bool get_interfaces(duke_media_handle_vector& hiifs,
            duke_media_handle_vector& hoifs) const;

    bool set_interfaces(const duke_media_handle_vector& hiifs,
            const duke_media_handle_vector& hoifs);

    int get_iport_number() const;

    dukeid_t get_port_interface(int index, bool is_input = true) const;

    int get_oport_number() const;

    bool add_input_port(const duke_media_handle& hif);

    bool del_input_port(const int& hif);

    bool add_output_port(const duke_media_handle& hif);

    bool del_output_port(const int& hif);

    bool clear_input_ports();

    bool clear_output_ports();

    bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = duke_media_handle_null);

    bool copy(const duke_media_handle& hdecl);

    /// pack & unpack
    virtual std::string pack() const;

    virtual void unpack(const std::string& strif);

    std::string pack_helper() const;

    void unpack_helper(const std::string& strif);

    void unpack_from_core_data(const std::string& strval);


    /// template instantiation
    bool set_template_type(const dukeid_vector& inf);

    bool get_template_type(dukeid_vector& inf) const;

    bool template_instantiation(DbTxn* txn = NULL);

    bool set_decl_in_cif(const host_committer_id_t& host_id, duke_logic_data_interface_compound& ifData , DbTxn* txn);

    bool find_complex_port(mStrVid& vec);


    //for compiler
    virtual bool is_valid();

    virtual editor_base_ptr to_xml_struct(index_manager& mgr, int& main_idx);


    bool init_save(DbTxn* txn = NULL);
};


#endif /* __DUKE_MEDIA_COMPOUND_DECLARATION_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
