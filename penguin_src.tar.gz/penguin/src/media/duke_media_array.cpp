#include "duke_media_array.h"
#include "duke_media_global.h"

duke_media_array::duke_media_array() : m_hif(NB_INTERFACE_ARRAY)
{
}

duke_media_array::duke_media_array(const host_committer_id_t& host_id, const std::string& username) 
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_ARRAY, host_id), 
        m_hif(NB_INTERFACE_ARRAY), 
        hc_id(host_id)
{
    //save  data
    this->get_handle().set_value(m_data.pack());

    //set handle name
    bool ret = duke_media_save_handle_name(this->get_handle(), "array");
    assert(ret);
}

duke_media_array::duke_media_array(const duke_media_handle& handle) : m_hif(NB_INTERFACE_ARRAY)
{
    //**************************unpack data to struct*****************************
    //handle must be duke_media_array
    if(!handle.is_object_array())
    {
        LOG_ERROR("error handle assign to array!\n");
    }

    //get data from database and assign it to array data struct
    std::string value;
    this->set_handle_status( handle.get_value(value) );    //we can know where this id come from

    if(value.empty())
    {
        LOG_ERROR("error : this  array: " << this->get_handle().str() << " has no data!");
    }

    //unpack data and set handle to this array
    this->unpack_helper(value);

    //set handle to this array
    this->set_handle(handle);
}

duke_media_handle duke_media_array::clone_new_handle(const host_committer_id_t& hc_id) const
{
    // request a new array handle
    duke_media_array newArray(hc_id);
    duke_media_handle newHandle = newArray.get_handle();

    // do a shallow copy
    std::string value = this->pack();
    newHandle.set_value(value);

    return newHandle;
}

void duke_media_array::unpack(const std::string& strval)
{
    this->unpack_helper(strval);
}

void duke_media_array::unpack_helper(const std::string& strval)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_data.unpack(strval);
    }
    else if (status == e_handle_core)
    {
        if (!strval.empty())
        {
            //fill data to array struct in core
            content value;
            unpack_object(strval, value);

            array_data_t    tmp_data;
            obj_impl_array::unpack(value, array_id, tmp_data);

            //tranform data to array struct in media from core's struct
            m_data.m_name = tmp_data.name;

            //array's compound interface
            m_data.m_iftype = tmp_data.type;                   

            //compound_interface data
            duke_media_compound_interface array_if(tmp_data.type);
            m_data.m_compound = array_if.get_data_from_handle();         

            //array value
            for(std::vector<nb_id_t>::const_iterator it = tmp_data.objs.begin();
                    it != tmp_data.objs.end(); ++it)
            {
                m_data.m_vid.push_back(*it);
            }
        }
    }
    else
    {
        LOG_ERROR("array handle: " << this->get_handle().str() << " has not exist in db");
    }
}

std::string duke_media_array::pack() const
{
    return pack_helper();
}

std::string duke_media_array::pack_helper() const
{
    return m_data.pack();
}

//get all handles in array, except array's handle
void duke_media_array::get_related_handles(duke_media_handle_vector& vHandles)
{
    //get array value
    this->get_elements(vHandles);

    //get array type
    dukeid_vector vType;
    this->get_type(vType);

    if(vType.size() != 1)               // the size of array type must be one
    {
        LOG_ERROR("the size of array type wrong");
    }

    vHandles.push_back(vType[0]);

}

bool duke_media_array::is_valid()
{
    // Check expansion interface
    duke_media_handle_vector hif;
    this->get_type(hif);
    if (hif.size() != 1)
    {
        LOG_ERROR("duke_media_array::is_valid() : array not expanded completely.");
        return false;
    }

    if (!hif[0].is_interface())
    {
        LOG_ERROR("duke_media_array::is_valid() : invalid array interface.");
        return false;
    }

    // Check elements
    // TODO

    return true;
}

//transform all data of array to xml data struct, except array's handle
editor_base_ptr duke_media_array::to_xml_struct(index_manager& mgr, int& main_index)
{
    if (!this->is_valid())
        return editor_base_ptr();

    //xml struct
    ArrayValue_editor_ptr pArray(new (std::nothrow) ArrayValue_editor());

    //array expanded interface 
    duke_media_handle expand_if;
    this->get_type(expand_if);
    //duke_media_handle expand_inf;
    //this->get_interface(expand_inf);
    pArray->set_expansionInterface(mgr.get_index_from_handle(expand_if));


    //the value of the array
    std::vector<int> vIndex;

    dukeid_vector value; 
    this->get_elements(value);
    for(dukeid_vector_iterator it = value.begin(); it != value.end(); ++it)
    {
        vIndex.push_back(mgr.get_index_from_handle(*it));
    }

    pArray->set_value(vIndex);

    //main index
    main_index = mgr.request_index_for_editor(this->get_handle(), pArray);

    return pArray;
}

bool duke_media_array::get_elements(duke_media_handle_vector& elements) const 
{
    elements = m_data.m_vid;
    return true;
}

bool duke_media_array::clear()
{
    return this->get_handle().set_value("");
}

dukeid_t duke_media_array::generate_expanded_decl(const nb_builtin_instruction_t ins, const dukeid_t& type)
{
    /* get declaration name */
    std::string name;
    duke_logic_static_declaration::get_builtin_name(ins, name);

    duke_media_declare_expanded decl(hc_id);
    decl.set_name(name);
    decl.set_array_type(ins, type);

    return decl.get_handle();
}

bool duke_media_array::set_value(const duke_media_handle_vector& type, std::vector<duke_media_handle> value)
{
    if(1 != type.size())
    {
        return false;
    }

    //here is add value to array
    if (m_data.m_compound.m_hext.size() == 1 && type[0] == m_data.m_compound.m_hext[0])
    {
        m_data.m_vid = value;
        return this->save();
    }
    
    
    //change the type of array, and here produce a new compound interface to array
    duke_media_compound_interface ifc(hc_id);

    //fill compound interface data
    duke_logic_data_interface_compound ifc_data;
    ifc_data.m_ifc = ifc.get_handle();
    ifc_data.m_hext = type;
    ifc_data.m_type = duke_media_handle(NB_INTERFACE_ARRAY_TYPE); 
    ifc_data.name = "array-interface";
    
    // ********************produce expanded_declare to compound_interface*******************
    //DbTxn* txn = NULL;
    //DbTxn* arraytxn = NULL;
    //bool bret = duke_media_tempobj_db::instance().begin_txn(arraytxn);
    //assert(bret);
    //int flag(0);
    
    ifc_data.m_decls.clear();
    duke_logic_data_interface_compound tmp_if_data;
    get_builtin_interface_compound(dukeid_t(NB_INTERFACE_ARRAY), tmp_if_data);
    for(std::size_t i = 0; i < tmp_if_data.m_decls.size(); ++i)
    {
        ifc_data.m_decls.push_back( generate_expanded_decl(tmp_if_data.m_decls[i].get_func_type(), type[0]) );
    }
    
    //bool ret = duke_media_tempobj_db::instance().commit(arraytxn);
    //assert(ret);
    //******************************************************************************************
    
    // insert general declarations
    duke_logic_static_interface::get_general_instructions(ifc_data.m_decls);
    
    // save ifc_data to media-dbs, using handle array_if
    ifc.set_data_to_handle(ifc_data); 
    
    
    m_data.m_iftype = ifc.get_handle();
    m_data.m_compound = ifc_data;
    m_data.m_vid = value; 
    
    return this->save();
}

bool duke_media_array::set_null_interface()
{
    return this->clear();
}

bool duke_media_array::get_type(duke_media_handle& type) const
{
    if(m_data.m_compound.m_hext.size() != 1)
    {
        return false;
    }

    type = m_data.m_compound.m_hext[0];
    return true;
}

bool duke_media_array::get_type(duke_media_handle_vector& vtype) const
{
    vtype = m_data.m_compound.m_hext;
    return true;
}

bool duke_media_array::get_interface(duke_media_handle& hif) const 
{
    get_compound_interface(hif);

    if (hif.is_type_null())
        hif = m_hif;

    return true;
}

bool duke_media_array::get_compound_interface(duke_media_handle& hif) const 
{
    hif = m_data.m_iftype;
    return true;
}

//bool duke_media_array::get_declarations(duke_media_handle_vector& hdecls) const 
//{
//    duke_media_interface mif(m_hif);
//    return mif.get_declarations(hdecls);
//}

bool duke_media_array::get_name(std::string& name) const 
{
    name = "array";
    return true;
}

bool duke_media_array::set_name(const std::string& name) 
{
    return true;
}

bool duke_media_array::get_icon(std::string& icon) const 
{
    if (is_expanded())
        icon = load_image(get_builtin_resource_path() + "array_ex.png");
    else
        icon = load_image(get_builtin_resource_path() + "array.png");
    if (icon.empty())
        return false;
    return true; 
}

bool duke_media_array::set_icon(const std::string& icon) {
    return true;
}

bool duke_media_array::is_expanded() const
{
    duke_media_handle hif;
    this->get_interface(hif);

    if (hif.is_interface_compound())
        return true;

    return false;
}


bool duke_media_array::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//
//    duke_media_array marr(host_id);
//
//    duke_media_handle_vector htype, oldvalue, newvalue, hvtype;
//    get_type(htype);
//
//    bool ret = get_value(oldvalue);
//    assert(ret);
//    
//    ret = duke_media_write_pair_handle(hfather, this->get_handle(), marr.get_handle());
//    assert(ret);
//    /////
//    hvtype.clear();
//    duke_media_handle hnew = htype[0];
//    if (duke_media_get_handle_status(username, htype[0]) == Edit)
//    {
//        if ((htype[0]).is_interface_compound())
//        {
//            bool ret = duke_media_read_pair_handle(hfather, htype[0], hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_compound_interface mobj(htype[0]);
//                ret = mobj.generate(username, hnew, host_id, hfather);
//                assert(ret);
//            }
//        }
//    }
//    hvtype.push_back(hnew);
//
//    newvalue.clear();
//    for (duke_media_handle_const_iterator iter = oldvalue.begin(); iter != oldvalue.end(); ++iter)
//    {
//        if ((*iter).is_object_user())
//        {
//            duke_media_handle hobj = *iter;
//            if (duke_media_get_handle_status(username, *iter) == Edit)
//            {
//                bool ret = duke_media_read_pair_handle(hfather, (*iter), hobj);
//                assert(ret);
//                if (hobj.is_type_null())
//                {
//                    duke_media_object mobj(*iter);
//                    bool ret = mobj.generate(username, hobj, host_id, hfather);
//                    assert(ret);
//                }
//            }
//            newvalue.push_back(hobj);
//        }
//        else if ((*iter).is_object_array())
//        {}
//        else if ((*iter).is_object_map())
//        {}
//        else
//            newvalue.push_back(*iter);
//    }
//    //TODO
//    //ret = marr.set_value(hvtype, newvalue, host_id, hfather, false);
//    assert(ret);
//
//    handle = marr.get_handle();
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(marr.get_handle().str());
//    if (iret == NB_DB_RESULT_NOTFOUND)
//        LOG_NOTICE("DEL the " << marr.get_handle().str() << " array in temp media not found;");
//    else if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << marr.get_handle().str() << " aarray in temp media failed;");
//
//
//    return ret;
    return true;
}

