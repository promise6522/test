
#include "duke_media_global.h"
#include "duke_media_execute.h"
#include "duke_media_implement.h"

bool duke_media_graph::add_func_node(const std::string& name, 
                                     const duke_media_handle& hdecl, 
                                     const duke_media_handle& owner_if /*= NB_INTERFACE_NONE */,
                                     const duke_media_handle& hexdecl /* = NBID_TYPE_NULL */)//add by tom
{
    assert(hdecl.is_declaration() || hdecl.is_object_func() || hdecl.is_implementation());
    duke_media_handle_vector vin, vout;
    if (hdecl.is_declaration())
    {
        if(hdecl.is_object_decl_compound())
        {
            duke_media_compound_declare mdecl(hdecl);
            vin.clear();
            vout.clear();                
            mdecl.get_interfaces(vin, vout);
        }
        else if(hdecl.is_object_decl_expanded())
        {
            duke_media_declare_expanded mdecl(hdecl);
            vin.clear();
            vout.clear();
            mdecl.get_interfaces(vin, vout);
        }
        else
        {
            duke_media_declare mdecl(hdecl);
            //mdecl.set_owner_if(owner_if);//add by tom
            //vin.clear();
            //vout.clear();
            mdecl.get_interfaces(vin, vout);
        }
    }
    else if (hdecl.is_implementation()
             && (!hdecl.is_object_exec_iterator()) && (!hdecl.is_object_exec_condition()))
    {
        duke_media_implement implMedia(hdecl);            
        vin.clear();
        vout.clear();
        implMedia.get_in_interfaces(vin);
        implMedia.get_out_interfaces(vout);
    }
    else
    {
        std::string strval;
        ac_object_db_impl::instance().read(hdecl.str(), strval);
        assert(!strval.empty());
        nb_id_t obj_id;
        duke_media_handle tmp_hdecl;
        if (hdecl.is_object_exec_iterator())
        {
            duke_media_loop loopMedia(hdecl);
            loopMedia.get_interfaces(vin, vout);
        }
        else if (hdecl.is_object_exec_condition())
        {
            duke_media_condition condMedia(hdecl);
            condMedia.get_interfaces(vin, vout);
        }
        else if (hdecl.is_object_exec_anchor_func())
        {
            content con;
            exec_anchor_func_data_t anchor_data;
            unpack_object(strval, con);
            obj_impl_exec_anchor_func::unpack(con, obj_id, anchor_data);
            tmp_hdecl = anchor_data.selected_decl;
            duke_media_declare mdecl(tmp_hdecl);
            vin.clear();
            vout.clear();
            mdecl.get_interfaces(vin, vout);
        }
        else if (hdecl.is_object_exec_storage_func())
        {
            content con;
            exec_storage_func_data_t stor_data;
            unpack_object(strval, con);
            obj_impl_exec_storage_func::unpack(con, obj_id, stor_data);
            tmp_hdecl = stor_data.selected_decl;
            duke_media_declare mdecl(tmp_hdecl);
            vin.clear();
            vout.clear();
            mdecl.get_interfaces(vin, vout);
        }
    }
    
    return this->add_node(name, hdecl, owner_if, vin, vout);
}
