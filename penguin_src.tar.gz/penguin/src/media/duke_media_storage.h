#ifndef __DUKE_MEDIA_STORAGE_H
#define __DUKE_MEDIA_STORAGE_H

//C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// Duke header file
#include "stdx_algorithm.h"
#include "duke_media_base.h"
#include "duke_logic_object.h"
#include "duke_media_interface.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_db/ac_storage_db_impl.h"
#include "ac_container/storage_implementation.h"

class duke_media_storage : public duke_media_base
{
private:
    duke_logic_data_storage m_storage;

    host_committer_id_t hc_id;

public:
    duke_media_storage(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");
    duke_media_storage(const duke_media_handle& hstorage, const std::string& username = "anonymous-name");
    bool assign(const duke_media_handle& hstorage);
    
    bool copy(const duke_media_handle& hstorage);

    bool set_name(const std::string& name);
    bool get_name(std::string& name) const;
    bool set_icon(const std::string& icon);
    bool get_icon(std::string& icon) const;
    bool set_container(const duke_media_handle& handle);

    bool get_container(duke_media_handle& handle);
    bool set_storage_compound_if_data(const duke_logic_data_interface_compound& comdata  );
    bool set_storage_if(const duke_media_handle& id);
    bool clear_storage_interface();
    bool clear_storage_objects();
    bool get_type(dukeid_vector& handle) const;
    bool get_type(duke_media_handle& handle) const;

    //bool set_interface(const duke_media_handle& hif);
    bool set_storage_idx(int index);

    bool get_storage_idx(int& index);

    bool set_exdecl(const duke_media_handle& handle);
    bool get_exdecl(duke_media_handle& handle);

    dukeid_t generate_storage_decl(const nb_builtin_instruction_t ins, const dukeid_vector& type, const host_committer_id_t& hc_id);
    bool set_value(const duke_media_handle_vector& type, const duke_media_handle_pair_vector& value, const host_committer_id_t host = 0);
    //bool set_value(const duke_media_handle_vector& type, const duke_media_handle_pair_vector& value, int index);

    bool set_type(const duke_media_handle_vector& type);
    bool get_interface(duke_media_handle& hif) const;

    //bool get_declarations(duke_media_handle_vector& hdecls);
    bool get_compound_interface(duke_media_handle& hif) const;
    bool get_compound_declarations(duke_media_handle_vector& hdecls);
    bool add_storage_object(const duke_media_handle& hkey, const duke_media_handle& hobj);
    bool del_storage_object(const duke_media_handle& hkey);

    bool get_storage_object(duke_media_handle_vector& vid) const;
    bool get_storage_objects(duke_media_handle_pair_vector& vid) const;
    bool find_storage_object(const duke_media_handle& hkey, duke_media_handle& handle) const;
    //bool replace_storage_object(const duke_media_handle& hkey, const duke_media_handle& hobj);
    //bool replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id, const duke_media_handle& hfather = 0);
    bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);

    //bool pack_new_structure();
    bool read_from_new_db(const duke_media_handle& hstor);
    bool write_to_new_db(const duke_media_handle& hstor);

    bool save_storage();
    virtual std::string pack()  const;
    std::string pack_helper()   const;
    virtual void unpack(const std::string& strval);
    void unpack_helper(const std::string& strval);
};

#endif  //__DUKE_MEDIA_STORAGE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
