#ifndef __DUKE_MEDIA_DECLARE_H
#define __DUKE_MEDIA_DECLARE_H

// C 98 header file
#include <iostream>
#include <string>
#include <vector>

#include <boost/smart_ptr.hpp>

// duke header file
#include "duke_logic_id.h"
#include "duke_logic_object_data.h"
#include "duke_media_base.h"
#include "ac_global_db.h"
#include "ac_object/obj_impl_decl_compound.h"

// {(handle)...(handle)}
// {(handle)...(handle)}
class duke_media_declare_parameters : public duke_logic_data_declaration
{
public:
    bool get_interfaces(duke_media_handle_vector& hiifs,
            duke_media_handle_vector& hoifs) const
    {
        hiifs = this->m_param.m_hiifs;
        hoifs = this->m_param.m_hoifs;
        return true;
    }

    bool set_interfaces(const duke_media_handle_vector& hiifs,
            const duke_media_handle_vector& hoifs)
    {
        this->m_param.m_hiifs = hiifs;
        this->m_param.m_hoifs = hoifs;
        return true;
    }

    int get_iport_number() const
    {
        return this->m_param.m_hiifs.size();
    }

    int get_oport_number() const
    {
        return this->m_param.m_hoifs.size();
    }

    bool add_input_port(const duke_media_handle& hif)
    {
        bool ret = hif.is_interface();
        assert(ret);
        if (ret)
        {
            m_param.m_hiifs.push_back(hif);
        }
        return ret;
    }

    bool del_input_port(const int& hif)
    {
        m_param.m_hiifs.erase(m_param.m_hiifs.begin() + hif);
        return true;
    }

    bool add_output_port(const duke_media_handle& hif)
    {
        bool ret = hif.is_interface();
        assert(ret);
        if (ret)
        {
            m_param.m_hoifs.push_back(hif);
        }
        return ret;
    }

    bool del_output_port(const int& hif)
    {
        m_param.m_hoifs.erase(m_param.m_hoifs.begin() + hif);
        return true;
    }

    bool clear_input_ports()
    {
        m_param.m_hiifs.clear();
        return true;
    }

    bool clear_output_ports()
    {
        m_param.m_hoifs.clear();
        return true;
    }
};

// {(handle)...(handle)}
// {(handle)...(handle)}
class duke_media_declare : public duke_media_base
{
private:
    duke_media_declare_parameters m_params;
    decl_compound_data_t data_t;    
    nb_id_t obj_id;

    host_committer_id_t hc_id;

    /*
    ** m_owner_if : optional param needed by some funcs
    */
    dukeid_t m_owner_if;

public:
    //this only for duke_media_base_factory
    duke_media_declare();
    duke_media_declare(const duke_media_handle& hdecl);

    bool assign(const duke_media_handle& hdecl);
    bool get_name(std::string& name) const;
    bool clear();
    virtual bool get_icon(std::string& icon) const;
    bool get_interfaces(duke_media_handle_vector& hiifs,
                        duke_media_handle_vector& hoifs);
    int get_iport_number() const;
    int get_oport_number() const;
    //virtual bool set_name(const std::string& name);    
    //virtual bool set_icon(const std::string& icon);
    //bool set_interfaces(const duke_media_handle_vector& hiifs,
    //                   const duke_media_handle_vector& hoifs);
    
    //bool add_input_port(const duke_media_handle& hif);
    //bool del_input_port(const int& hif);
    //bool add_output_port(const duke_media_handle& hif);    
    //bool del_output_port(const int& hif);
    bool clear_input_ports();    
    bool clear_output_ports();
    
    //bool generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
    
    //bool pack_new_structure();

    //bool copy(const duke_media_handle& hdecl);
    //std::string pack() const;
    //void unpack(const std::string& strdecl);

    //add by tom
    //void set_owner_if(const dukeid_t& owner_if);
    //dukeid_t get_owner_if() const;

    //bool replace_content(const std::string& username, std::string& strval, const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
private:
    //bool save();
    bool make_builtin_interfaces(const duke_media_handle& hdecl);
    
};


#endif /* __DUKE_MEDIA_DECLARE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
