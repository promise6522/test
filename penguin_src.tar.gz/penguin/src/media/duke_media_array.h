#ifndef _DUKE_MEDIA_ARRAY_H_
#define _DUKE_MEDIA_ARRAY_H_

//C 98 header file
#include <iostream>
#include <string.h>
#include <list>
#include <map>
#include <utility>

#include "ac_object/obj_impl_array.h"
#include "duke_media_declare_expanded.h"
#include "duke_index_manager.h"

class duke_media_array : public duke_media_base
{
private:
    duke_media_handle m_hif;
    duke_logic_data_array m_data;

    host_committer_id_t hc_id;
    nb_id_t     array_id;

public:
    //this only for duke_media_base_factory
    duke_media_array();

    duke_media_array(const host_committer_id_t& host_id, const std::string& username = "anonymous-name");
        
    duke_media_array(const duke_media_handle& handle);

    duke_media_handle clone_new_handle(const host_committer_id_t& hc_id) const;


    //used when expanded array' interface
    dukeid_t generate_expanded_decl(const nb_builtin_instruction_t ins, const dukeid_t& type);

    virtual void unpack(const std::string& strval);
    void unpack_helper(const std::string& strval);
    virtual std::string pack() const;
    std::string pack_helper() const;

    virtual editor_base_ptr  to_xml_struct(index_manager& mgr, int& main_index);
    virtual void get_related_handles(duke_media_handle_vector& vHandles);

    virtual bool is_valid();

    bool clear();

    bool set_null_interface();

    bool set_value(const duke_media_handle_vector& type, std::vector<duke_media_handle> value); 

    bool get_type(duke_media_handle& type) const;

    bool get_type(duke_media_handle_vector& vtype) const;

    bool get_elements(duke_media_handle_vector& elements) const;

    bool get_interface(duke_media_handle& hif) const;

    bool get_compound_interface(duke_media_handle& hif) const;

    //bool get_declarations(duke_media_handle_vector& hdecls) const;

    virtual bool get_name(std::string& name) const;

    virtual bool set_name(const std::string& name);

    virtual bool get_icon(std::string& icon) const;

    virtual bool set_icon(const std::string& icon);

    bool is_expanded() const;

    bool generate(const std::string& username, duke_media_handle& handle, 
            const host_committer_id_t& host_id = 0, const duke_media_handle& hfather = 0);
};

#endif  //_DUKE_MEDIA_ARRAY_H_
