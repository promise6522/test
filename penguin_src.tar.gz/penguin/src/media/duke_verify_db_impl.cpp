/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

// nb file
#include "duke_verify_db_impl.h"

#include "nb_profiler.h"
//#include "stdx_log.h"

duke_verify_db_impl::duke_verify_db_impl()
{
    try
    {
        std::string dbmedia = "dbmedia/";
        const std::string& db_name = "verifyd";
        const std::string dbhome = "dbverify";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idvalue";

        // recover the database each time
        nb_mkdirs(dbmedia + dbhome);
        nbnv::recover(dbmedia + dbhome);

        // create database environment
        penv = new nbnv(dbmedia + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool duke_verify_db_impl::write(const std::string& strkey, const std::string& value)
{
    NEW_SCOPE_TIMER("duke_verify_db_impl::write", false);

    assert(pdb != NULL);

    DbTxn* txn = NULL;

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
        return false;
    }

    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}

bool duke_verify_db_impl::read(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);

    DbTxn* txn = NULL;

    int ret = pdb->read(strkey, value, txn);
    if (ret == 0)
    {
        ret = NB_DB_RESULT_SUCCESS;
        return true;
    }
    else if (ret == DB_NOTFOUND)
    {
        ret = NB_DB_RESULT_NOTFOUND;
        return true;
    }
    else
        ret = NB_DB_RESULT_FAILED;

    return false;
}

bool duke_verify_db_impl::commit(int flag)
{
    assert(pdb != NULL);

    DbTxn* txn = find_txn(flag);
    int ret = pdb->commit(txn);
    return (ret == 0 ? true : false);
}

bool duke_verify_db_impl::rollback(int flag)
{
    assert(pdb != NULL);
    DbTxn* txn = find_txn(flag);
    int ret = pdb->rollback(txn);
    return (ret == 0 ? true : false);
}

DbTxn* duke_verify_db_impl::find_txn(int flag)
{
    assert(flag != 0);
    DbTxn* txn = NULL;
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it = idtxns.find(flag);
    if (it != idtxns.end())
    {
        txn = it->second;
        idtxns.erase(it);
    }
    return txn;
}

void duke_verify_db_impl::close_txn()
{
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it;
    for (it = idtxns.begin(); it != idtxns.end(); ++it)
        pdb->rollback(it->second);
}

duke_verify_db_impl::~duke_verify_db_impl(void) 
{
    if (m_idtxns.size() != 0)
    {
        this->close_txn();
    }

    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
