#include "duke_media_global.h"
#include "duke_media_object.h"
#include "duke_media_interface.h"
#include "duke_media_declare.h"
#include "duke_media_implement.h"
#include "duke_logic_object_data.h"
#include "stdx_log.h"

duke_media_object::duke_media_object()
{
}

duke_media_object::duke_media_object(const host_committer_id_t& host_id, const std::string& username)
        : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_USER, host_id), 
        is_singletonobj(false), 
        singletonobjnum(0), 
        hc_id(host_id), 
        user_name(username)
{
    // produce interface for user object
    duke_media_compound_interface m_mif(host_id, username);
    m_mif.set_decl_type(NB_INTERFACE_USER);
    m_user.m_ifid = m_mif.get_handle();

    // make a declare of "user_compose" for duke_media_object
    duke_media_compound_declare hCompose(host_id, DUKE_MEDIA_TYPE_FUNCTION_COMPOSE);
    hCompose.set_name("user_compose");
    hCompose.clear_output_ports();
    hCompose.clear_input_ports();
    hCompose.add_input_port(m_user.m_ifid);
    hCompose.add_output_port(m_user.m_ifid);

    m_user.m_hcompose = hCompose.get_handle();

    // make a declare of "user_decompose" for duke_media_object
    duke_media_compound_declare hDecompose(host_id, DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE);
    hDecompose.set_name("user_decompose");
    hDecompose.clear_input_ports();
    hDecompose.add_input_port(m_user.m_ifid);

    m_user.m_hdecompose = hDecompose.get_handle();

    // create an dummy impl id for compose & decompose 
    duke_media_handle hImpl;
    hImpl.set_type(DUKE_MEDIA_TYPE_NULL);
    hImpl.set_idtype(nb_handle::Id128);

    this->add_function(hCompose.get_handle(), hImpl);
    this->add_function(hDecompose.get_handle(), hImpl);


    // save to tempobj_db
    this->get_handle().set_value(non_virtual_pack());
}


duke_media_object::duke_media_object(const duke_media_handle& hobj, const std::string& username)
{
    //recover object data to data struct of object
    bool ret = this->assign(hobj);
    assert(ret);
}


bool duke_media_object::add_decl_to_interface(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());

    duke_media_handle_pair_vector_iterator it;

    if ((it = find_decl(hdecl)) == m_user.m_funcs.end())
    {
        duke_media_compound_interface m_mif(m_user.m_ifid);
        m_mif.add_declaration(hdecl);

        this->save();
    }

    return true;
}

bool duke_media_object::update_funcs(const duke_media_handle& hdecl, const duke_media_handle& himpl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());
    assert(himpl.is_implementation() || himpl.is_type_null());

    duke_media_handle_pair_vector_iterator funcs_iter;
    if ((funcs_iter = find_decl(hdecl)) == m_user.m_funcs.end())
    {
        // add new func-impl pair
        m_user.m_funcs.push_back(std::make_pair(hdecl, himpl));
        
        // update interface of itself
        this->add_decl_to_interface(hdecl);

        if (!this->check())
        {
            LOG_ERROR("exist the null implementation!");
            return false;
        }
    }
    else
    {
        funcs_iter->second = himpl;

        if (!this->check())
        {
            LOG_ERROR("exist the null implementation!");
            return false;
        }
    }

    return this->save();
}

bool duke_media_object::update_funcs(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());

    // create an dummy impl id 
    duke_media_handle hImpl; 
    //hImpl.set_type(DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT);
    //hImpl.set_idtype(nb_handle::Id128);

    // 
    return this->update_funcs(hdecl, hImpl);
}

//bool duke_media_object::get_value(std::string& value) const
//{
//    return this->get_handle().get_value(value);
//}

//bool duke_media_object::set_value(std::string value)
//{
//    return this->get_handle().set_value(value);
//}

bool duke_media_object::assign(const duke_media_handle& hobj)
{
    //here assignment object must be a object
    if (!hobj.is_object())
    {
        return false;
    }

    //get data from database and assign it to object data struct
    std::string   value;
    this->set_handle_status( hobj.get_value(value) );    //we can know where this id come from

    if (value.empty())
    {
        LOG_ERROR("error : this object " << hobj.str() << " has no data!");
        return false;
    }

    //unpack data and set handle to this object
    this->unpack_helper(value);
    this->set_handle(hobj);

    return true;
}

bool duke_media_object::is_singleton_object() const
{
    return is_singletonobj;
}

bool duke_media_object::get_name(std::string& name) const
{
    name = m_user.m_name;
    return true;
}

bool duke_media_object::set_name(const std::string& name)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_user.m_name = name;

    //set new name to this object's interface
    duke_media_compound_interface ifc(m_user.m_ifid);
    ifc.set_interface_name(name + "-interface");

    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);

    return this->save();
}

bool duke_media_object::get_icon(std::string& icon) const
{
    icon = m_user.m_icon;
    return true;
}

bool duke_media_object::set_icon(const std::string& icon)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_user.m_icon = icon;
    return this->save();
}

bool duke_media_object::decompose(duke_media_handle_vector& hobjs) const
{
    //get subobject of the this object
    hobjs.clear();
    for (duke_media_handle_pair_vector_const_iterator it = m_user.m_subobjs.begin();
         it != m_user.m_subobjs.end(); ++it)
    {
        hobjs.push_back(it->first);
        LOG_DEBUG("object decompose:\n" << it->first.str());
    }

    return true;
}

bool duke_media_object::get_subobjects(duke_media_handle_vector& hobjs) const
{
    return decompose(hobjs);
}

bool duke_media_object::get_subobject_and_interfaces(duke_media_handle_pair_vector& objs_vector) const
{
    objs_vector = this->m_user.m_subobjs;

    if (objs_vector.size() != 0)
        LOG_DEBUG("get obj:\n" << (objs_vector[0]).first.str());

    return true;
}

bool duke_media_object::get_function_except_compose(duke_media_handle_pair_vector& funcs_vector) const
{
    //get functions of this object except compose and decompose
    for (duke_media_handle_pair_vector_const_iterator it = m_user.m_funcs.begin(); 
         it != m_user.m_funcs.end(); ++it)
    {

        if (it->first.is_function_compose() || it->first.is_function_decompose())
            continue;

        funcs_vector.push_back(std::make_pair(it->first, it->second));
    }

    return true;
}

bool duke_media_object::get_subinterfaces(duke_media_handle_vector& hifs) const
{
    hifs.clear();
    for (duke_media_handle_pair_vector_const_iterator it = m_user.m_subobjs.begin();
         it != m_user.m_subobjs.end(); ++it)
    {
        hifs.push_back(it->second);
    }
    return true;
}

// object
bool duke_media_object::find_subobject(const duke_media_handle& hobj) const
{
    assert(hobj.is_object());

    for (duke_media_handle_pair_vector_const_iterator it = m_user.m_subobjs.begin();
         it != m_user.m_subobjs.end(); ++it)
    {
        if (it->first == hobj)
            return true;
    }
    return false;
}

bool duke_media_object::add_subobject(const duke_media_handle& hobj,
                                      const duke_media_handle& hcif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hobj.is_object());
    assert(hcif.is_interface());

    //TODO why we need special process on array/map ?
    duke_media_handle ht;
    if (hobj.is_object_array())
    {
        duke_media_array oarr(hobj);
        oarr.get_interface(ht);
        LOG_DEBUG("   ht1="<<ht.str());
        if (ht.is_type_null())
        {
            ht = hcif;
        }
    }
    else if (hobj.is_object_map())
    {
        duke_media_map omap(hobj);
        omap.get_interface(ht);
        LOG_DEBUG("   ht1="<<ht.str());
        if (ht.is_type_null())
            ht = hcif;
    }
    else
    {            
        ht = hcif;
    }        

    m_user.m_subobjs.push_back(std::make_pair(hobj, ht));

    // update compose/decompose 
    duke_media_compound_declare compose(m_user.m_hcompose);
    compose.add_input_port(ht);
    duke_media_compound_declare decompose(m_user.m_hdecompose);
    decompose.add_output_port(ht);

    return this->save();
}

bool duke_media_object::exist_singleton_object(const duke_media_handle& hobj)
{
    /*
    duke_media_access access(hobj);
    if (access.is_singleton_object())
    {
        return (!(--singletonobjnum == 0));
    }
    else
        return (!(singletonobjnum == 0));*/
    return true;
}

bool duke_media_object::del_subobject(const duke_media_handle& hobj)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hobj.is_object());

    int index = 0;
    for (duke_media_handle_pair_vector_iterator it = m_user.m_subobjs.begin(); it != m_user.m_subobjs.end();)
    {
        if (it->first == hobj)
        {
            //update compose/decompose
            duke_media_compound_declare compose(m_user.m_hcompose);
            compose.del_input_port(index + 1);
            duke_media_compound_declare decompose(m_user.m_hdecompose);
            decompose.del_output_port(index);

            // if del singleton
            if (it->first.is_access())
            {
                if (!exist_singleton_object(it->first))
                    is_singletonobj = false;
            }

            // remove subobj
            m_user.m_subobjs.erase(it);

            return this->save();
        }
        ++it;
        ++index;
    }

    return false; 
}

//bool duke_media_object::replace_subinterface(const duke_media_handle& hobj,
//                                             const duke_media_handle& hcif)
//{
//    bool ret = ((hobj.is_object() || hobj.is_access()) && hcif.is_interface());
//    assert(ret);
//        int index = 0;
//        for (duke_media_handle_pair_vector_iterator it = m_user.m_subobjs.begin(); it != m_user.m_subobjs.end();)
//        {
//            if (it->first == hobj)
//            {
//                duke_media_handle ht;
//                /*
//                if (hobj.is_object_array())
//                {
//                    duke_object_array oarr(hobj);
//                    oarr.get_interface(ht);
//                    if (ht.is_type_null())
//                        ht = hcif;
//                }
//                else
//                    ht = hcif;
//                */
//                duke_media_compound_declare compose(m_user.m_hcompose);
//                compose.del_input_port(index + 1);
//                compose.add_input_port(ht);
//                duke_media_compound_declare decompose(m_user.m_hdecompose);
//                decompose.del_output_port(index);
//                decompose.add_output_port(ht);
//                it->second = ht;
//                return this->save();
//            }
//             ++it;
//             ++index;
//        }
//        return false;
//    }

bool duke_media_object::clear_subobject()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_user.m_subobjs.clear();
    
    //update compose/decompose
    duke_media_compound_declare compose(m_user.m_hcompose);
    compose.clear_input_ports();
    compose.add_input_port(m_user.m_ifid);

    duke_media_compound_declare decompose(m_user.m_hdecompose);
    decompose.clear_output_ports();

    return this->save();
}

// interface
bool duke_media_object::get_interface(duke_media_handle& hif) const
{
    hif = m_user.m_ifid;
    return true;
}

// declaration
duke_media_handle_pair_vector_iterator duke_media_object::find_decl(const duke_media_handle& hdecl)
{
    bool ret = hdecl.is_declaration();
    assert(ret);
    duke_media_handle_pair_vector_iterator it;
    for (it = m_user.m_funcs.begin(); it != m_user.m_funcs.end(); ++it)
    {
        if (it->first == hdecl)
            return it;
    }
    return it;
}

bool duke_media_object::find_declaration(const duke_media_handle& hdecl)
{
    return (find_decl(hdecl) != m_user.m_funcs.end());
}

bool duke_media_object::get_declarations(duke_media_handle_vector& hdecls) const
{
    duke_media_compound_interface m_mif(m_user.m_ifid);
    return m_mif.get_declarations(hdecls);
}

// implemention
bool duke_media_object::get_implementation(const duke_media_handle& hdecl,
                                           duke_media_handle& himpl)
{
    assert(hdecl.is_declaration());

    duke_media_handle_pair_vector_iterator it; 
    if ((it = find_decl(hdecl)) != m_user.m_funcs.end())
    {
        himpl = it->second;
        return true;
    }

    return false;
}

bool duke_media_object::del_implementation(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());

    duke_media_handle_pair_vector_iterator it;
    if ((it = find_decl(hdecl)) != m_user.m_funcs.end())
    {
        duke_media_handle handle(NBID_TYPE_NULL);
        it->second = handle;
        return this->save();
    }

    return false;
}

// function (both declaration and implemention)
bool duke_media_object::add_function(const duke_media_handle& hdecl,
                                     const duke_media_handle& himpl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration() && (himpl.is_implementation() || himpl.is_type_null()));

    // update user interface
    bool ret = add_decl_to_interface(hdecl);
    assert(ret);

    ret = update_funcs(hdecl, himpl);
    assert(ret);
    return ret;
}

bool duke_media_object::add_function(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());

    // update user interface
    bool ret = add_decl_to_interface(hdecl);
    assert(ret);

    ret = update_funcs(hdecl);
    assert(ret);
    return ret;
}

bool duke_media_object::del_function(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    assert(hdecl.is_declaration());

    // delete from interface
    duke_media_compound_interface m_mif(m_user.m_ifid);
    bool ret = m_mif.del_declaration(hdecl);
    assert(ret);

    // remove from func pair
    duke_media_handle_pair_vector_iterator it = find_decl(hdecl);
    if (it != m_user.m_funcs.end())
    {
        m_user.m_funcs.erase(it);
        return this->save();
    }

    return ret;
}

bool duke_media_object::clear_function()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    // update interface
    duke_media_compound_interface m_mif(m_user.m_ifid);
    bool ret = m_mif.clear_declaration();
    assert(ret);

    // clear funcs pair
    m_user.m_funcs.clear();

    // rework on compose/decompose
    duke_media_compound_declare hCompose(m_user.m_hcompose);
    duke_media_compound_declare hDecompose(m_user.m_hdecompose);

    duke_media_handle hImpl;
    hImpl.set_type(DUKE_MEDIA_TYPE_NULL);
    hImpl.set_idtype(nb_handle::Id128);

    this->add_function(hCompose.get_handle(), hImpl);
    this->add_function(hDecompose.get_handle(), hImpl);

    return this->save();
}

bool duke_media_object::clear()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    duke_media_compound_interface m_mif(m_user.m_ifid);
    bool ret = m_mif.clear_declaration();
    assert(ret);
    
    m_user.m_funcs.clear();
    m_user.m_subobjs.clear();

    duke_media_compound_declare compose(m_user.m_hcompose);
    compose.clear_input_ports();
    compose.add_input_port(m_user.m_ifid);

    duke_media_compound_declare decompose(m_user.m_hdecompose);
    decompose.clear_output_ports();

    return this->save();
}

//get all duke_media_handle in duke_media_object except this object's handle
void duke_media_object::get_related_handles(duke_media_handle_vector& vHandles)
{
    vHandles.clear();

    //object's interface
    vHandles.push_back(m_user.m_ifid);

    //subobject and subobject's interface
    for(dukeid_pair_vector_iterator it = m_user.m_subobjs.begin();
            it != m_user.m_subobjs.end(); ++it)
    {
        vHandles.push_back(it->first);           //subobject
        vHandles.push_back(it->second);          //subobject's interface
    }

    //object's decl and implement
    for(dukeid_pair_vector_iterator it = m_user.m_funcs.begin();
            it != m_user.m_funcs.end(); ++it)
    {
        vHandles.push_back(it->first);          //declaration
        vHandles.push_back(it->second);         //implementation
    }

}

//transfrom duke_media_object's data struct to a xml struct(prepare for compiler)
editor_base_ptr duke_media_object::to_xml_struct(index_manager& mgr, int& main_index)
{
    if (!this->is_valid())
        return editor_base_ptr();

    UserObject_editor_ptr pObj(new (std::nothrow) UserObject_editor());

    // obj name
    pObj->set_name(m_user.m_name);

    // obj interface
    int interface = mgr.get_index_from_handle(m_user.m_ifid);
    pObj->set_interface(interface);


    // subobject and subobj interface included in duke_media_object
    std::vector<int>  vObj;
    std::vector<int>  vInf;
    for(dukeid_pair_vector_iterator it = m_user.m_subobjs.begin();
            it != m_user.m_subobjs.end(); ++it)
    {
        vObj.push_back(mgr.get_index_from_handle(it->first));
        vInf.push_back(mgr.get_index_from_handle(it->second));
    }

    pObj->set_subobjects(vObj);
    pObj->set_subobjectInterfaces(vInf);

    // binding (decl, impl)
    std::vector<Binding> vBind;

    for(dukeid_pair_vector_iterator it = m_user.m_funcs.begin();
            it != m_user.m_funcs.end(); ++it)
    {
        struct Binding  element;
        bzero(&element, sizeof(element));

        element.declaration = mgr.get_index_from_handle(it->first);

        if (it->first.is_function_compose() || it->first.is_function_decompose())
            element.implementation = mgr.get_index_from_handle(duke_media_handle_null);
        else
            element.implementation = mgr.get_index_from_handle(it->second);

        vBind.push_back(element);
    }

    pObj->set_bindings(vBind);

    // main index
    main_index = mgr.request_index_for_editor(this->get_handle(), pObj);

    return pObj;
}

bool duke_media_object::generate(const std::string& username, 
                                duke_media_handle& handle, 
                                const host_committer_id_t& host_id, 
                                const duke_media_handle& hfather)
{
//    if (!this->check())
//        return false;  
//
//    std::string strkey = username + "-object";
//    std::string strval;
//    assert(this->get_handle().is_object());
//
//    bool ret = duke_media_clear_pair_handle(this->get_handle());
//    assert(ret);
//    ret = duke_media_clear_cipair_handle(this->get_handle());
//    assert(ret);
//
//    duke_media_object obj(host_id);
//    ret = this->get_handle().get_value(strval);
//    assert(ret);
//
//    std::string strname;
//    this->get_name(strname);
//    ret = duke_media_save_handle_name(obj.get_handle(), strname);
//    assert(ret);
//
//    ret = duke_media_write_pair_handle(hfather, this->get_handle(), obj.get_handle());
//    assert(ret);
//
//    replace_content(username, strval, host_id, hfather);
//
//    obj.unpack(strval);
//    ret = obj.get_handle().set_value(strval);
//    assert(ret);
//
//    obj.pack_new_structure(username, hfather);
//
//    duke_media_remove_handle("anonymous-name-tmp-object", obj.get_handle());
//    duke_media_remove_handle(username + "-tmp-object", obj.get_handle());
//
//    strval = "";
//    ret = duke_media_read_handle(strkey, strval);
//    strval += "(" + obj.get_handle().str() + ")";
//    ret = duke_media_write_handle(strkey, strval);
//    assert(ret);
//
//    handle = obj.get_handle();    
//
//    unsigned int iret = duke_media_tempobj_db::instance().del(obj.get_handle().str());
//    //if (iret == NB_DB_RESULT_NOTFOUND)
//    //    LOG_NOTICE("DEL the " << obj.get_handle().str() << " object in temp media not found;");
//    if (iret == NB_DB_RESULT_FAILED)
//        LOG_NOTICE("DEL the " << obj.get_handle().str() << " object in temp media failed;");
//
//    return ret;
    return true;
}

//bool duke_media_object::generate_sub_item(const std::string& username)
//{
//    for (duke_media_handle_pair_vector_iterator it = m_user.m_subobjs.begin(); 
//         it != m_user.m_subobjs.end(); ++it)
//    {
//        //if sub-object is edit
//        if(duke_media_get_handle_status(username, it->first) == Edit)
//        {
//            duke_media_object mobj(it->first);
//            duke_media_handle hobj;                
//            if(!mobj.generate(username, hobj))
//            {
//                return false;
//            }
//        }
//
//        //if sub-object interface is edit
//        if(duke_media_get_handle_status(username, it->second) == Edit)
//        {
//            duke_media_compound_interface mif(it->second);
//            duke_media_handle hif;                
//            if(!mif.generate(username, hif))
//            {
//                return false;
//            }
//        }            
//    }
//
//    for (duke_media_handle_pair_vector_iterator it = m_user.m_funcs.begin(); 
//         it != m_user.m_funcs.end(); ++it)
//    {
//        //if declaration is edit
//        if(duke_media_get_handle_status(username, it->first) == Edit)
//        {
//            duke_media_compound_declare mdecl(it->first);
//            duke_media_handle hdecl;                
//            if(!mdecl.generate(username, hdecl))
//            {
//                return false;
//            }
//        }
//
//        //if implement is edit
//        if(duke_media_get_handle_status(username, it->second) == Edit)
//        {
//            duke_media_implement mimpl(it->second);
//            duke_media_handle himpl;                
//            if(!mimpl.generate(username, himpl))
//            {
//                return false;
//            }
//        }            
//    }        
//    return true;    
//}

// TODO to be update
//bool duke_media_object::copy(const duke_media_handle& hobj)
//{
//    bool ret = false;
//    assert(hobj.is_object_user());
//
//    std::string strval;
//    ret = hobj.get_value(strval);
//    assert(ret);
//    this->unpack(strval);
//    if (this->is_singleton_object())
//        return false;
//    ret = this->clone();
//    assert(ret);
//    ret = this->save();
//    assert(ret);
//    return ret;
//}

// TODO to be update
//bool duke_media_object::clone()
//{
//    std::string strval;
//    dukeid_pair_vector tmp_subobj, tmp_funcs;
//    bool ret = m_user.m_ifid.get_value(strval);
//    assert(ret);
//    duke_media_compound_interface ifc(hc_id);
//    ifc.get_handle().set_value(strval);        
//
//    m_user.m_ifid = ifc.get_handle();
//
//    for (dukeid_pair_vector_iterator iter = m_user.m_funcs.begin(); iter != m_user.m_funcs.end();
//            ++iter)
//    {
//        /*
//        std::string strval = "";
//        bool ret = iter->first.get_value(strval);
//        assert(ret);
//        duke_media_declare decl(hc_id);
//        decl.get_handle().set_value(strval);
//
//        strval = "";
//        ret = iter->second.get_value(strval);
//        assert(ret);
//        duke_media_implement impl(hc_id);
//        impl.get_handle().set_value(strval);
//
//        tmp_funcs.push_back(std::make_pair(decl.get_handle(), impl.get_handle())); */
//    }
//
//    for (dukeid_pair_vector_iterator iter = m_user.m_subobjs.begin(); iter != m_user.m_subobjs.end();
//            ++iter)
//    {
//        strval = "";
//        if (iter->first.is_object_array())
//        {
//            ret = iter->first.get_value(strval);
//            assert(ret);
//            boost::scoped_ptr<duke_media_array> new_handle(new duke_media_array(hc_id));
//            ret = new_handle->get_handle().set_value(strval);
//            assert(ret);
//            tmp_subobj.push_back(std::make_pair(new_handle->get_handle(), iter->second));
//        }
//        else if (iter->first.is_object_string())
//        {
//            ret = iter->first.get_value(strval);
//            assert(ret);
//            boost::scoped_ptr<duke_media_string> new_handle(new duke_media_string(hc_id));
//            ret = new_handle->get_handle().set_value(strval);
//            assert(ret);
//            tmp_subobj.push_back(std::make_pair(new_handle->get_handle(), iter->second));
//        }
//        else if (iter->first.is_object_bytes())
//        {
//            ret = iter->first.get_value(strval);
//            assert(ret);
//            boost::scoped_ptr<duke_media_bytes> new_handle(new duke_media_bytes(hc_id));
//            ret = new_handle->get_handle().set_value(strval);
//            assert(ret);
//            tmp_subobj.push_back(std::make_pair(new_handle->get_handle(), iter->second));
//        }
//        else 
//        {
//            tmp_subobj.push_back(std::make_pair(iter->first, iter->second));
//        }
//    }
//    m_user.m_subobjs = tmp_subobj;
//
//    return true;
//}

bool duke_media_object::check() const
{
    if (!m_user.m_funcs.empty())
    {
        for (duke_media_handle_pair_vector_const_iterator it = m_user.m_funcs.begin();
             it != m_user.m_funcs.end(); ++it)
        {
            if ((!it->first.is_declaration()) && (!it->second.is_implementation()))
                return false;
        }
    }
    if (!m_user.m_subobjs.empty())
    {
        for (duke_media_handle_pair_vector_const_iterator it = m_user.m_subobjs.begin();
             it != m_user.m_subobjs.end(); ++it)
        {
            if (!it->first.is_object())
                return false;
            if (!it->second.is_interface())
                return false;
        }
    }
    return true;
}


// Validation check before generate
bool duke_media_object::is_valid()
{
    // Check funcs
    for (size_t i = 0; i < m_user.m_funcs.size(); ++i)
    {
        if (!m_user.m_funcs[i].first.is_declaration())
        {
            LOG_ERROR("duke_media_object::is_valid() : decl[" << i << "] invalid.");
            return false;
        }

        // we don't care compose/decompose impl
        if (m_user.m_funcs[i].first.is_function_compose() ||
            m_user.m_funcs[i].first.is_function_decompose())
            continue;

        if (!m_user.m_funcs[i].second.is_implementation())
        {
            LOG_ERROR("duke_media_object::is_valid() : impl[" << i << "] invalid.");
            return false;
        }
    }

    // Check subobjs
    for (size_t i = 0; i < m_user.m_subobjs.size(); ++i)
    {
        if (!m_user.m_subobjs[i].first.is_object())
        {
            LOG_ERROR("duke_media_object::is_valid() : subobj[" << i << "] invalid.");
            return false;
        }

        if (e_handle_unknown == get_media_handle_status(m_user.m_subobjs[i].first))
        {
            LOG_ERROR("duke_media_object::is_valid() : subobj[" << i << "] invalid.");
            return false;
        }

        if (!m_user.m_subobjs[i].second.is_interface())
        {
            LOG_ERROR("duke_media_object::is_valid() : subif[" << i << "] invalid.");
            return false;
        }
    }

    return true;
}


// real pack()
std::string duke_media_object::non_virtual_pack() const
{
    return m_user.pack();
}

// virtual pack()
std::string duke_media_object::pack() const
{
    return this->non_virtual_pack();
}

void duke_media_object::unpack(const std::string& strval)
{
    this->unpack_helper(strval);
}

void duke_media_object::unpack_helper(const std::string& strval)
{
    //do different thing by handle status
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        m_user.unpack(strval);

        //if (e_handle_core == get_media_handle_status(m_user.m_ifid))
        //{
        //    std::string strval;
        //    ac_object_db_impl::instance().read_(m_user.m_ifid.str(), strval);

        //    content raw_data;
        //    unpack_object(strval, raw_data);

        //    if_compound_data_t if_data;
        //    nb_id_t id;
        //    obj_impl_interface_compound::unpack(raw_data, id, if_data);
        //    duke_logic_data_interface_compound ifc_data(if_data);

        //    host_committer_id_t hc_id;
        //    duke_media_compound_interface ifc(hc_id);
        //    ifc_data.m_ifc = ifc.get_handle();
        //    ifc.set_data_to_handle(ifc_data);

        //    m_user.m_ifid = ifc.get_handle();

        //    //TODO
        //    this->save();
        //}
    }
    else if (status == e_handle_core)
    {
        //unpack user data
        content user;          
        unpack_object(strval, user);
        obj_impl_user::unpack(user, obj_id, data_t);
        m_user.m_ifid = data_t.interface;
        m_user.m_name = data_t.name;

        //unpack descirptor data
        std::string value_desc;
        content vdesc;
        duke_media_handle(data_t.descriptor).get_value(value_desc);
        //ac_object_db_impl::instance().read_(data_t.descriptor.str(), value_desc);
        unpack_object(value_desc, vdesc);
        obj_impl_descriptor::unpack(vdesc, desc_id, desc_data);

        // fill the funcs
        for (func_vector_const_it it = desc_data.funcs.begin(); it != desc_data.funcs.end(); ++it)
        {
            m_user.m_funcs.push_back(std::make_pair(it->declaration_id, it->implementation_id));
        }

        // fill sub objects
        assert(data_t.subobjs.size() == desc_data.subobj_interfaces.size());
        int icount(0);
        for (nb_id_vector_const_it it = data_t.subobjs.begin(); it != data_t.subobjs.end(); ++it)
        {
            m_user.m_subobjs.push_back(std::make_pair(*it, desc_data.subobj_interfaces[icount]));
            icount++;
        }

    }
    else
    {
        LOG_ERROR("object handle: " << this->get_handle().str() << " has not exist in db");
    }
}

bool duke_media_object::save()
{
    if(e_handle_core != this->get_handle_status())
    {
        return this->get_handle().set_value(this->pack());
    }
    else
    {
        return false;
    }
}

//bool duke_media_object::pack_new_structure(const std::string& username, const duke_media_handle& hfather)
//{
//    user_data_t tmp_user;
//    descriptor_data_t tmp_desc;
//
//    for (dukeid_pair_vector_const_iterator it = m_user.m_funcs.begin(); it != m_user.m_funcs.end(); ++it)
//    {
//        func_pair_t tmp_func;
//        //tmp_func.declaration_id = it->first;
//        memcpy(&tmp_func.declaration_id, &(it->first), sizeof(tmp_func.declaration_id));
//        //tmp_func.implementation_id = it->second;
//        memcpy(&tmp_func.implementation_id, &(it->second), sizeof(tmp_func.implementation_id));
//
//        tmp_desc.funcs.push_back(tmp_func);
//        LOG_DEBUG("decl in decscriptor:" << it->first.str());
//        LOG_DEBUG("impl in decscriptor:" << it->second.str());
//    }
//
//    for (dukeid_pair_vector_const_iterator it = m_user.m_subobjs.begin(); it != m_user.m_subobjs.end(); ++it)
//    {
//        nb_id_t id, ifid;
//        memcpy(&id, &(it->first), sizeof(id));
//        tmp_user.subobjs.push_back(id);
//        memcpy(&ifid, &(it->second), sizeof(ifid));
//        tmp_desc.subobj_interfaces.push_back(ifid);
//    }
//  
//    tmp_user.name = m_user.m_name;
//    //tmp_user.interface = m_user.m_ifid; 
//    //memcpy(&tmp_user.interface, &m_user.m_ifid, 16);
//    tmp_user.interface.str(m_user.m_ifid.str());
//    assert(m_user.m_ifid.is_interface_compound());
//    {
//        duke_media_compound_interface m_mif(m_user.m_ifid);
//        m_mif.set_decl_type(NB_INTERFACE_USER);
//        m_mif.pack_new_structure();
//
//        duke_media_handle_vector decls;
//        m_mif.get_declarations(decls);
//        for (duke_media_handle_const_iterator it = decls.begin(); it != decls.end(); ++it)
//        {
//            LOG_DEBUG("decl in interface:" << it->str());
//        }
//    }
//
//    if (desc_id.is_type_null())
//    {
//        request_alone_nb_id_info input;
//        input.type = NBID_TYPE_OBJECT_DESCRIPTOR;
//        input.committer_id = hc_id;
//
//        nb_id_t output;
//        ac_id_t dest_id = g_ac_id_dispenser_acid;
//
//        ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
//        if(pActor)
//        {
//            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
//            pActor->request_alone_nb_id(input, output);
//            tmp_user.descriptor = output;
//            desc_id = output;
//        }
//    }
//    else
//        tmp_user.descriptor = desc_id;
//
//    content con_user, con_desc;
//    //db_value vuser, vdesc;
//
//    obj_impl_descriptor::pack(tmp_desc, desc_id, con_desc);
//    //vdesc.all_objects.push_back(con_desc);
//    std::string strval;
//    strval = pack_object(con_desc);
//
//    ac_object_db_impl::instance().write_(desc_id.str(), strval);
//
//    //memcpy(&obj_id, &(this->get_handle()), 16);
//
//    obj_id.str(this->get_handle().str());
//
//    std::string strmark = "NO";
//    tmp_user.water_mark = strmark;
//    obj_impl_user::pack(tmp_user, obj_id, con_user);
//    strval = pack_object(con_user);
//    
//    bool ret = ac_object_db_impl::instance().write_(this->get_handle().str(), strval);
//
//    return ret;
//}

//bool duke_media_object::replace_content(const std::string& username, 
//                                        std::string& strval, 
//                                        const host_committer_id_t& host_id, 
//                                        const duke_media_handle& hfather)
//{
//    duke_media_handle hnewif = m_user.m_ifid;
//    if(duke_media_get_handle_status(username, m_user.m_ifid) == Edit)
//    {
//        bool ret = duke_media_read_pair_handle(hfather, m_user.m_ifid, hnewif);
//        assert(ret);
//        
//        if (hnewif.is_type_null())
//        {
//            duke_media_compound_interface compoundIf(m_user.m_ifid);
//
//            if(!compoundIf.generate(username, hnewif, host_id, hfather))
//            {
//                return false;
//            }
//        }
//        duke_media_replace_handle(strval, m_user.m_ifid, hnewif);
//    }
//
//    int icount(0);
//    for (duke_media_handle_pair_vector_iterator it = m_user.m_subobjs.begin(); 
//         it != m_user.m_subobjs.end(); ++it)
//    {
//        //if sub-object is edit 
//        ++icount;
//        if ((it->first).is_object_array())
//        {
//            duke_media_handle hnew, hif, htype;
//            bool ret = duke_media_read_pair_handle(hfather, (it->first), hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_array marr(it->first);
//                bool ret = marr.generate(username, hnew, host_id, hfather); 
//                assert(ret);
//                if (hnew.is_type_null())
//                    assert(false);
//
//                duke_media_array newarr(hnew);
//                ret = newarr.get_type(htype);
//                assert(ret);
//                ret = newarr.get_interface(hif);
//                assert(ret);
//                if (hif.is_type_null())
//                    assert(false);
//            }
//            LOG_NOTICE("&&&&&&&&&&&old array harr, hif:" << it->first.str() << " " << it->second.str());
//            duke_media_replace_handle(strval, it->first, hnew);
//            duke_media_replace_handle(strval, it->second, hif);
//            LOG_NOTICE("&&&&&&&&&&&new array harr, hif:" << hnew.str() << " " << hif.str());
//
//            duke_media_compound_interface ifc(hnewif);
//            duke_media_handle_vector vdecls;
//            ifc.get_declarations(vdecls);
//
//            //set decompose array
//            for (duke_media_handle_iterator it = vdecls.begin(); it != vdecls.end(); ++it)
//            {
//                if (it->is_function_instruction())
//                    continue;
//
//                duke_media_handle hdecl = *it;
//                if ((*it).is_function_decompose())
//                {
//                    if (duke_media_get_handle_status(username, *it) == Notfound)
//                    {
//                        duke_media_compound_declare decl(*it);
//                        LOG_NOTICE("&&&&&&&&&&&old decompose handle:" << (*it).str());
//                        bool ret = decl.generate(username, hdecl, host_id, hfather);
//                        assert(ret);
//                        assert(!hdecl.is_type_null());
//                        *it = hdecl;
//                        LOG_NOTICE("&&&&&&&&&&&new decompose handle:" << (*it).str());
//                    }
//
//                    duke_media_compound_declare newdecl(hdecl);
//                    duke_media_handle_vector hiifs, hoifs;
//                    newdecl.get_interfaces(hiifs, hoifs);
//                    
//                    hoifs[icount - 1] = hif;
//                    newdecl.set_interfaces(hiifs, hoifs);
////delete pack_new_struct                    newdecl.pack_new_structure();
//                    ifc.set_declarations(vdecls);
//                    ifc.pack_new_structure();
//                    break;
//                }
//            }
//            
//            //
//        }
//        else if ((it->first).is_object_map())
//        {
//            duke_media_handle hnew, hif;
//            bool ret = duke_media_read_pair_handle(hfather, (it->first), hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_map mmap(it->first, host_id, username);
//                bool ret = mmap.generate(username, hnew, host_id, hfather); 
//                assert(ret);
//                if (hnew.is_type_null())
//                    assert(false);
//
//                duke_media_map newmap(hnew, host_id, username);
//                /*ret = newmap.get_type(htype);
//                assert(ret);*/
//                ret = newmap.get_interface(hif);
//                assert(ret);
//                if (hif.is_type_null())
//                    assert(false);
//            }
//            LOG_NOTICE("&&&&&&&&&&&old map handle, hif:" << it->first.str() << " " << it->second.str());
//            duke_media_replace_handle(strval, it->first, hnew);
//            duke_media_replace_handle(strval, it->second, hif);
//            LOG_NOTICE("&&&&&&&&&&&new map handle, hif:" << hnew.str() << " " << hif.str());
//
//            duke_media_compound_interface ifc(hnewif);
//            duke_media_handle_vector vdecls;
//            ifc.get_declarations(vdecls);
//
//            //set decompose map
//            for (duke_media_handle_iterator it = vdecls.begin(); it != vdecls.end(); ++it)
//            {
//                if (it->is_function_instruction())
//                    continue;
//                
//                if ((*it).is_function_decompose())
//                {
//                    duke_media_handle hdecl = *it;
//                    duke_media_compound_declare decl(*it);
//                    if ((duke_media_get_handle_status(username, *it) == Notfound) ||
//                            (duke_media_get_handle_status(username, *it) == Edit))
//
//                    {
//                        LOG_NOTICE("&&&&&&&&&&&old decompose handle:" << (*it).str());
//                        bool ret = decl.generate(username, hdecl, host_id, hfather);
//                        assert(ret);
//                        assert(!hdecl.is_type_null());
//                        *it = hdecl;
//                        LOG_NOTICE("&&&&&&&&&&&new decompose handle:" << (*it).str());
//                    }
//
//                    duke_media_compound_declare newdecl(hdecl);
//                    duke_media_handle_vector hiifs, hoifs;
//                    newdecl.get_interfaces(hiifs, hoifs);
//                    
//                    hoifs[icount - 1] = hif;
//                    newdecl.set_interfaces(hiifs, hoifs);
// //delete pack_new_struct                   newdecl.pack_new_structure();
//                    ifc.set_declarations(vdecls);
//                    ifc.pack_new_structure();
//                    break;
//                }
//            }
//        }
//        else if ((it->first).is_object_string())
//        {
//            std::string stringval;
//            it->first.get_value(stringval);
//            duke_media_string sobj(host_id);
//            bool ret = sobj.get_handle().set_value(stringval);
//            assert(ret);
//            duke_media_replace_handle(strval, it->first, sobj.get_handle());
//        }
//        else if ((it->first).is_object_bytes())
//        {
//            duke_bytes_t sbyte;
//            duke_media_bytes dbytes(it->first);
//            bool ret = dbytes.get_value(sbyte);
//            assert(ret);
//
//            duke_media_bytes dbytes2(host_id);
//            ret = dbytes2.set_value(sbyte);
//            duke_media_replace_handle(strval, it->first, dbytes2.get_handle());
//        }
//        else if(duke_media_get_handle_status(username, it->first) == Edit)
//        {
//            if ((it->first).is_object_user())
//            {
//                duke_media_object obj(it->first);
//                duke_media_handle hnew, hif;
//                bool ret = duke_media_read_pair_handle(hfather, it->first, hnew);
//                assert(ret);
//                if (hnew.is_type_null())
//                {
//                    bool ret = obj.generate(username, hnew, host_id, hfather);
//                    assert(ret);
//                    
//                    duke_media_object newobj(hnew);
//                    ret = newobj.get_interface(hif);
//                    assert(ret);
//                    if (hif.is_type_null())
//                        assert(false);
//                }
//                duke_media_replace_handle(strval, it->first, hnew);
//                duke_media_replace_handle(strval, it->second, hif);
//            }
//        }
//    }
//
//    for (duke_media_handle_pair_vector_iterator it = m_user.m_funcs.begin(); 
//         it != m_user.m_funcs.end(); ++it)
//    {
//        if (it->first.is_function_instruction())
//            continue;
//
//        //if declaration is edit
//        if(duke_media_get_handle_status(username, it->first) == Edit)
//        {
//            duke_media_handle hnew;
//            bool ret = duke_media_read_pair_handle(hfather, it->first, hnew);
//            assert(ret);
//            if (hnew.is_type_null())
//            {
//                duke_media_compound_declare mdecl(it->first);
//                bool ret = mdecl.generate(username, hnew, host_id, hfather);
//                assert(ret);
//            }
//            duke_media_replace_handle(strval, it->first, hnew);
//        }
//        else
//        {
///*
//            if (it->first.is_function_compose() || it->first.is_function_decompose())
//            {
//                duke_media_compound_declare decl(it->first);
//                duke_media_handle hnew;
//                bool ret = duke_media_read_pair_handle(hfather, it->first, hnew);
//                assert(ret);
//                if (hnew.is_type_null() && it->first.is_function_decompose())
//                {
//                    LOG_NOTICE("&&&&&&&&&&&old decompose handle:" << (*it).first.str());
//                    bool ret = decl.generate(username, hnew, host_id, hfather);
//                    assert(ret);
//                    assert(!hnew.is_type_null());
//                    LOG_NOTICE("&&&&&&&&&&&new decompose handle:" << hnew.str());
//                }
//                duke_media_replace_handle(strval, it->first, hnew);
//                LOG_NOTICE("&&&&&&&&&&&func compose and decompose handle:" << it->first.str() << " " << hnew.str());
//
//            }*/
//        }
//
//        //if implement is edit
//        if(duke_media_get_handle_status(username, it->second) == Edit)
//        {
//            duke_media_handle himpl;
//            
//            bool ret = duke_media_read_pair_handle(hfather, it->second, himpl);
//            assert(ret);
//
//            if (himpl.is_type_null())
//            {
//                duke_media_implement mimpl(it->second);
//                bool ret = mimpl.generate(username, himpl, host_id, hfather);
//                assert(ret);
//            }
//            duke_media_replace_handle(strval, it->second, himpl);
//        }            
//    }        
//
//    return true;
//}


// map
//

// vim:set tabstop=4 shiftwidth=4 expandtab:
