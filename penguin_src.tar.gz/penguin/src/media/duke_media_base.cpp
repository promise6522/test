/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#include "duke_media_base.h"

#include "duke_index_manager.h"
#include "nb_compiler.h"

bool duke_media_base::compile(const std::string& username,
        nb_id_t& main_id,
        std::map<int, nb_id_t>& idx_id_map)
{
    index_manager mgr;
    int main_index;

    //invoke the virual to_xml_struct()
    editor_base_ptr pEditor = this->to_xml_struct(mgr, main_index);

    // check if validation passed
    if (pEditor.get() == NULL)
    {
        LOG_ERROR("duke_media_base::compile() : checking failed.");
        return false;
    }

    // retrieve compiler info from the manager
    index_info_t info;
    bool ret = mgr.get_index_info(info);
    if (!ret)
    {
        LOG_ERROR("duke_media_base::compile() : checking failed.");
        return false;
    }

    // set the main_index
    info.main_idx = main_index;
    LOG_DEBUG("Main index for this struct is "<<main_index);
    
    // call the compiler
    std::map<int, std::string> idx_error_map;
    ret = ::compile(info, idx_id_map, idx_error_map);

    // print debug info
    if (ret)
    {
        main_id = idx_id_map[main_index];
        LOG_NOTICE("The generated main id is " << main_id.str());

        // save the generated handle name for easy retrieval
        // TODO for now, we just save the name for the main id
        std::string name;
        this->get_name(name);//invoke virtual
        if (!name.empty())
            duke_media_save_handle_name(main_id, name);


        // ## Dump content of the id ##
        duke_media_handle hMain(main_id);
        std::string strval;
        assert(e_handle_core == hMain.get_value(strval));
        //LOG_NOTICE("    Value of the id is " << strval);

        // ## print generated ids ##
        LOG_DEBUG(" #### Dump generated ids from compiler ####");
        for(std::map<int, nb_id_t>::const_iterator it = idx_id_map.begin();
                it != idx_id_map.end(); ++it)
        {
            LOG_DEBUG(" index = " << it->first << " , id = " << it->second.str());
        }

        return true;
    }
    else
    {
        LOG_ERROR("duke_media_base::compile() failed.");

        // print error info
        for(std::map<int, std::string>::const_iterator it = idx_error_map.begin();
                it != idx_error_map.end(); ++it)
        {
            LOG_DEBUG(" index = " << it->first << " , error = " << it->second);
        }

        return false;
    }

}
