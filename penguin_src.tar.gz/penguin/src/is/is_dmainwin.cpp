/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

// Duke header files
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dapplication.h"
#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dmultiwidgets.h"
#include "is_dobjeditor.h"

DMainWin::DMainWin(DWidget *parent /* = 0 */, WFlags f /* = 0 */ )
    : DWidget(parent, f),
      m_pToolWin(NULL),
      m_pDragWidget(NULL)
{
    setObjectName(MainWin_ObjName);
    initMainWin();
}

DMainWin::~DMainWin()
{
}

DToolWin * DMainWin::toolWin()
{
    return m_pToolWin;
}

void DMainWin::setToolWin(DToolWin * toolWin)
{
    m_pToolWin = toolWin;
}

DWidget* DMainWin::getRootWidget()
{
    return m_ptrBgLabel.get();
}

DWidget * DMainWin::dragWidget()
{
    return m_pDragWidget;    
}

void DMainWin::setDragWidget(DWidget * pWidget)
{
    m_pDragWidget = pWidget;    
}

DWidget * DMainWin::activeWidget()
{
    return m_pActiveWidget;
}

void DMainWin::setActiveWidget(DWidget * pWidget)
{
    m_pActiveWidget = pWidget;

    //updated display order
    MainWidgetsIt it = m_mainWidgets.begin();
    int maxDisOrder = 0;

    for (; it != m_mainWidgets.end(); ++it)
    {
        DWidget *pWidget = (*it).get();
        int displayOrder = pWidget->displayOrder();
        displayOrder = displayOrder < MainWin_Display_StartOrder ? 
            MainWin_Display_StartOrder : displayOrder;            
        pWidget->setDisplayOrder(displayOrder + Default_Dialog_DisplaySpacing);
        DEditor *pEditor = dynamic_cast<DEditor *>(pWidget);
        if(pEditor != NULL)
        {
            pEditor->setSubEditorsOrder(displayOrder + Default_Dialog_DisplaySpacing - 1);
        }
        
        pWidget->updateAll();
        maxDisOrder = displayOrder > maxDisOrder ? displayOrder : maxDisOrder;
    }
    
    //make the background with big value
    m_ptrBgLabel->setDisplayOrder(maxDisOrder + MainWin_Background_DisplayOrder);
    m_pActiveWidget->setDisplayOrder(MainWin_Display_StartOrder);
    DEditor *pEditor = dynamic_cast<DEditor *>(m_pActiveWidget);
    if(pEditor != NULL)
    {
        pEditor->setSubEditorsOrder(MainWin_Display_StartOrder - 1);
    }

    m_ptrBgLabel->updateAll();
}

MainWidgetsIdx DMainWin::insertWidget(DWidgetPtr ptrWidget)
{    
    m_mainWidgets.push_back(ptrWidget);
    ptrWidget->registerEvent(DEvent::Select);
    ptrWidget->registerEvent(DEvent::DnD_Start);
    //ptrWidget->registerEvent(DEvent::Drag);
    ptrWidget->registerEvent(DEvent::DnD_Release, true);
    ptrWidget->registerEvent(DEvent::Resize_Start);
    ptrWidget->registerEvent(DEvent::Resize_Release);
    ptrWidget->setEventRoutine(DEvent::Select,
                               this, 
                               static_cast<EventRoutine>(&DMainWin::onSelect));
    ptrWidget->setEventRoutine(DEvent::DnD_Start,
                               this, 
                               static_cast<EventRoutine>(&DMainWin::onDnDStart));
    /*ptrWidget->setEventRoutine(DEvent::Drag,
                               this, 
                               static_cast<EventRoutine>(&DMainWin::onDnDDrag));*/
    ptrWidget->setEventRoutine(DEvent::DnD_Release,
                               this, 
                               static_cast<EventRoutine>(&DMainWin::onDnDRelease));
    setActiveWidget(ptrWidget.get());
    
    return m_mainWidgets.size() - 1;
}

void DMainWin::eraseWidget(DWidget* pDelWidget)
{
    MainWidgetsIt it = m_mainWidgets.begin();

    for (; it != m_mainWidgets.end(); ++it)
    {
        DWidget *pWidget = (*it).get();
        if(pWidget == pDelWidget)
        {
            LOG_DEBUG("=========>erase "<<pWidget->objectName());
            m_mainWidgets.erase(it);
            return;
        }
    }
}    

DWidget* DMainWin::findWidget(const DPath& widgetPath)
{
    DWidget* pWidget = NULL;
    
    for (MainWidgetsIt it = m_mainWidgets.begin(); it != m_mainWidgets.end(); ++it)
    {
        pWidget = (*it).get();
        if(pWidget->objectPath() == widgetPath)
            return pWidget;
    }

    return NULL;    
}

void DMainWin::destoryWidgetAndButton(DWidget *pWidget, const is_response_call& response_call)
{
    if(m_pToolWin == NULL)
    {
        assert(!"Could not find tool windows management information.");
        return;
    }

    DButton *pButton = m_pToolWin->findButtonFromWidget(pWidget);
    if(pButton == NULL)
    {
        assert(!"Could not find the related Button according to pWidget");
        return;
    }

    if(pWidget == m_pDragWidget)
        m_pDragWidget = NULL;

    //destory the widget and button
    m_pToolWin->destoryWidgetAndButton(pWidget, pButton, response_call);

    //destory the managed children from mainwin
    //destoryChildWidgets(pWidget->children(), con);
}

//Destory the managed children from mainwin
void DMainWin::destoryChildWidgets(DObjectList * pChildWidgets, const is_response_call& response_call)
{
    std::vector<DWidget *> allWidgets;    
    if(pChildWidgets != NULL)
    {
        //get all the widget in children
        DObjectListIt it;
        for (it = pChildWidgets->begin(); it != pChildWidgets->end(); ++it)
        {
            DWidget * pChildWidget = dynamic_cast<DWidget *>(*it);                        
            getWidgetRecursive(pChildWidget, allWidgets);
        }

        //erase the widget which in m_mainWidgets
        std::vector<DWidget *>::iterator itWidget;
        for (itWidget = allWidgets.begin(); itWidget != allWidgets.end(); ++itWidget)
        {
            (*itWidget)->destory(response_call);
            eraseWidget(*itWidget);
        }        
    }
}

//Helper for get the managed children from mainwin 
void DMainWin::getWidgetRecursive(DWidget *pWidget, std::vector<DWidget *> &allWidgets)
{
    if(pWidget != NULL)
    {
        DObjectList* pChildWidgets = pWidget->children();

        if (pChildWidgets != NULL)
        {
            DObjectListIt it;            
            
            for (it = pChildWidgets->begin(); it != pChildWidgets->end(); ++it)
            {
                DWidget * pChildWidget = dynamic_cast<DWidget *>(*it);                        
                getWidgetRecursive(pChildWidget, allWidgets);
            }
        }

        //store widget in allWidgets anyway
        allWidgets.push_back(pWidget);
    }
}

void DMainWin::eraseButtonAndMap(DWidget *pWidget, const is_response_call& response_call)
{
    if(m_pToolWin == NULL)
    {
        assert(!"Could not find tool windows management information.");
        return;
    }

    DButton *pButton = m_pToolWin->findButtonFromWidget(pWidget);
    if(pButton == NULL)
    {
        //assert(!"Could not find the related Button according to pWidget");
        return;
    }

    //destory the button
    pButton->destory(response_call);

    //remove button's smart_ptr from the toolwin
    m_pToolWin->eraseButton(pButton);
    m_pToolWin->eraseButtonWidgetMap(pButton);

    //update and repaint
    m_pToolWin->updateAll();
    m_pToolWin->repaint(response_call);
}

void DMainWin::insertButtonAndMap(DWidget *pWidget, const is_response_call& response_call)
{
    if(m_pToolWin == NULL)
    {
        assert(!"Could not find tool windows management information.");
        return;
    }

    //Create new Button
    DButton * pButton = m_pToolWin->createButtonForWidget(pWidget);
    if(pButton == NULL)
    {
        assert(!"Could not create the related Button according to pWidget");
        return;
    }

    //show Button
    pButton->show(response_call);
    m_pToolWin->repaint(response_call);
}

void DMainWin::initMainWin()
{
    //Init background ImageLabel
    DImage img;
    img.load(getResPath() + MainWin_BackgroundImg_FileName);
    img.setXScale(DImage::Tile);
    img.setYScale(DImage::Tile);
    m_ptrBgLabel.reset(new(std::nothrow) DImageLabel("",
                                                     img,
                                                     this));
    m_ptrBgLabel->setObjectName(MainWin_Background_ObjName);    
    m_ptrBgLabel->setDisplayOrder(MainWin_Background_DisplayOrder);
    assert(m_ptrBgLabel.get() != NULL);
    m_ptrBgLabel->setBackgroundColor(MainWin_Background_Color);

    //Init event handle
    /*m_ptrBgLabel->registerEvent(DEvent::Drag);
    m_ptrBgLabel->setEventRoutine(DEvent::Drag,
                                  this, 
                                  static_cast<EventRoutine>(&DMainWin::onDnDDrag));*/

    m_ptrBgLabel->registerEvent(DEvent::DnD_Release);
    m_ptrBgLabel->setEventRoutine(DEvent::DnD_Release,
                                  this, 
                                  static_cast<EventRoutine>(&DMainWin::onDnDRelease));
}

void DMainWin::update()
{
    DWidget *pMainFrame = dynamic_cast<DWidget *>(parent());
    if(pMainFrame == NULL)
    {
        assert(!"Could not get pMainFrame.");
        return;
    }
    pMainFrame->updateAll();
}

void DMainWin::repaintAllAndSubEditor(const is_response_call& response_call, bool hasData /* = true */)
{
    //if need repaint all the desktop
    if(hasData)
    {
        m_ptrBgLabel->updateAll();
        m_ptrBgLabel->repaint(response_call);
        return;
    }

    //else, just updated the placement in desktop
    DMultiWidgets multiWidgets;
    multiWidgets.addWidget(m_ptrBgLabel.get());
    
    for (MainWidgetsIt it = m_mainWidgets.begin() ; it != m_mainWidgets.end(); ++it)
    {
        DWidget *pWidget = (*it).get();
        if((pWidget == NULL) || (pWidget->isHide()))            
        {
            continue;
        }
                
        multiWidgets.addWidget(pWidget);
        DEditor * pEditor = dynamic_cast<DEditor *>(pWidget);
        if(pEditor == NULL)
        {
            continue;
        }

        //if current widget is editor, try to update the subEditor
        pEditor->updateSubEditors();
        SubEditors * pSubEditors =  pEditor->subEditors();
        for(SubEditorIt it = pSubEditors->begin(); it != pSubEditors->end(); ++it)
        {
            DWidget* pSubWidget = (*it).get();
            if(pSubWidget != NULL)
            {
                multiWidgets.addWidget(pSubWidget);
            }            
        }
    }

    m_ptrBgLabel->updateAll();
    multiWidgets.repaintAll(response_call, hasData);
}

void DMainWin::repaintAll(const is_response_call& response_call, bool hasData /*= true*/)
{
    //if need repaint all the desktop
    if(hasData)
    {
        m_ptrBgLabel->updateAll();
        m_ptrBgLabel->repaint(response_call);
        return;
    }

    //else, just updated the placement in desktop
    DMultiWidgets multiWidgets;
    multiWidgets.addWidget(m_ptrBgLabel.get());

    DObjectList * pChildren = m_ptrBgLabel->children();    
    for (DObjectListIt it = pChildren->begin() ; it != pChildren->end(); ++it)
    {
        DWidget *pWidget = dynamic_cast<DWidget *>(*it);
        if((pWidget == NULL) || (pWidget->isHide()))            
        {
            continue;
        }
                
        multiWidgets.addWidget(pWidget);

        //if current widget is editor, try to update placement for its subEditors;
        DEditor * pEditor = dynamic_cast<DEditor *>(pWidget);
        if(pEditor != NULL)
        {
            pEditor->updateSubEditors();
        }
    }

    m_ptrBgLabel->updateAll();
    multiWidgets.repaintAll(response_call, hasData);
}

//--------event handle-------------------
void DMainWin::onSelect(const DEvent &event)
{    
    LOG_DEBUG("---------DMainWin::onSelect");
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_ptrBgLabel->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject);

    //repaint current dialog's menu
    //Beacause we only register one message handle for one widget, so we could not call
    //dialog on select event anyway.
    //If current widget is dialog, we just call the event handle manully

    if(typeid(DRunEditor) == typeid(*pWidget))
    {
        DRunEditor* pRunEditor = static_cast<DRunEditor*>(pWidget);
        pRunEditor->deletePopMenu(event);
        pRunEditor->updateAll();
    }
    else if(typeid(DImplEditor) == typeid(*pWidget))
    {
        DImplEditor* pImplEditor = static_cast<DImplEditor*>(pWidget);
        pImplEditor->deletePopMenu(event);
        pImplEditor->updateAll();
    }

    DDialog * pDlg = dynamic_cast<DDialog*>(pWidget);
    if((pDlg != NULL) && (pDlg->popMenu() != NULL))
    {
        pDlg->minimizeMenu();
        pDlg->popMenu()->updateAll();
        pDlg->popMenu()->repaint(event.getCon(), false);
    }
        
    ////////Benchmark/////////
    timeval start;
    timeval end;
    gettimeofday(&start, NULL);
    //////////////////////////

    //set select item to be active item
    setActiveWidget(pWidget);
    //only update the Dialog and subEditor's placement
    repaintAll(event.getCon(), false);

    ////////Benchmark/////////
    gettimeofday(&end, NULL);
    int timeUse = 1000000 * ( end.tv_sec - start.tv_sec ) + end.tv_usec - start.tv_usec; 
    LOG_DEBUG("Active spend time:" << timeUse <<"ms");
    //////////////////////////
    
    //empty drag widget
    m_pDragWidget = NULL;
}

void DMainWin::onDnDStart(const DEvent &event)
{
    LOG_DEBUG("----------DMainWin::onDnDStart");
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_ptrBgLabel->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject);

    //if draged item is not the active item, then active it at first
    if(pWidget !=  m_pActiveWidget)
    {
        setActiveWidget(pWidget);
    }
    m_pDragWidget = pWidget;
    m_dragPoint = event.getEventPosition();
    DApplication* pApp =  getApplication();
    if(pApp != NULL)
    {
        pApp->setDragCursor(DCursor::DragCursor);
    }
}

void DMainWin::onDnDDrag(const DEvent &event)
{
    //std::cout<<"----------DMainWin::onDnDDrag"<<std::endl;
    if(m_pDragWidget == NULL)
        return;

    DApplication* pApp =  getApplication();
    if(pApp != NULL)
    {
        pApp->setDragCursor(DCursor::DragCursor);
    }
    //TBD: Change to other cursor types.
}

void DMainWin::onDnDRelease(const DEvent &event)
{ 
    LOG_DEBUG("--------------DMainWin::onDnDRelease");

    DApplication* pApp =  getApplication();
    if(pApp != NULL)
    {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pDragObject = findChild(childPath[1]);
    DWidget* pDragWidget = dynamic_cast<DDialog *>(pDragObject);
    if (NULL == pDragWidget)
        return;

    //DWidget* pNewParent = dynamic_cast<DWidget*>(pObject); 
    DWidget *pOldParent =  dynamic_cast<DWidget *>(pDragWidget->parent());
   // if ((pNewParent == NULL) || (pNewParent != m_ptrBgLabel.get()))
     //   return;    
   
    //change the parent following below regulation
    //1. Can't set itself as its parent
    //2. newParent can't be NULL
    //3. oldParent == NULL
    //4. Or, oldParent != NewParent
    /*if( (m_pDragWidget != pNewParent) 
        && ((m_pDragWidget->parent() == NULL) || (m_pDragWidget->parent() != pNewParent)))
    {          
        //update old parent if there is
        m_pDragWidget->setParent(pNewParent);
        if(pOldParent != NULL)
        {
            pOldParent->updateAll();
            pOldParent->repaint(event.getCon());            
            
            if(pOldParent == m_ptrBgLabel.get())
            {
                //remove button and buttonWidgetMap if move from destop to widget
                eraseButtonAndMap(m_pDragWidget, event.getCon());
            }
        }                     
    } */   

    DPoint widgetNewPos;
    DSize widgetSize = pDragWidget->geometrySize();
    widgetNewPos.setX(event.getEventPosition().x() - m_dragPoint.x() * widgetSize.width() / 10000);
    widgetNewPos.setY(event.getEventPosition().y() - m_dragPoint.y() * widgetSize.height() / 10000);
    
    ////////Benchmark/////////
    timeval start;
    timeval end;
    gettimeofday(&start, NULL);
    //////////////////////////

    //move
    pDragWidget->move(widgetNewPos);

    //update the information
    m_ptrBgLabel->updateAll();
    
    //update the current parent    
    DWidget* pDragParent = dynamic_cast<DWidget*>(pDragWidget->parent());

    //do not repaint the parent, only change palcement    
    //if drag widget is Editor, try to update subEditor's position
    repaintAll(event.getCon(), false);   

    //if move the item to desktop
    if( (pOldParent != m_ptrBgLabel.get()) && 
        (pDragParent == m_ptrBgLabel.get()) )
    {
        //Add button and buttonWidgetMap if move from widget to desktop
        insertButtonAndMap(m_pDragWidget, event.getCon());
    }

    ////////Benchmark/////////
    gettimeofday(&end, NULL);
    int timeUse = 1000000 * ( end.tv_sec - start.tv_sec ) + end.tv_usec - start.tv_usec; 
    LOG_DEBUG("Drag spend time:" << timeUse << "ms");
    //////////////////////////

    pDragWidget = NULL;
}

DRunEditorPtr DMainWin::createNewRunEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DRunEditorPtr ptrDlg(new(std::nothrow) DRunEditor(RunEditor_ObjName, 
                                                    DEditor::DialogModel, 
                                                    this,
                                                    getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_RunButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_RunSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initRunEditor();
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

DContEditorPtr DMainWin::createNewContEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DContEditorPtr ptrDlg(new(std::nothrow) DContEditor(ContEditor_ObjName, 
                                                        DEditor::DialogModel, 
                                                        this,
                                                        getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ContButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ContSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initContEditor();
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

DImplEditorPtr DMainWin::createNewImplEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DImplEditorPtr ptrDlg(new(std::nothrow) DImplEditor(ImplEditor_ObjName, 
                                                        DEditor::DialogModel, 
                                                        this,
                                                        getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ImplButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ImplSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initDialog();
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

DObjEditorPtr DMainWin::createNewObjEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DObjEditorPtr ptrDlg(new(std::nothrow) DObjEditor(ObjEditor_ObjName, 
                                                        DEditor::DialogModel, 
                                                        this,
                                                        getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ObjectButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ObjectSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initObjEditor();
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

DDeclEditorPtr DMainWin::createNewDeclEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DDeclEditorPtr ptrDlg(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                                                        DEditor::DialogModel, 
                                                        this,
                                                        getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_DeclButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_DeclSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initDeclEditor();
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

DIFEditorPtr DMainWin::createNewIFEditor(const duke_media_handle& rDukeMediaHandle)
{
    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    DIFEditorPtr ptrDlg(new(std::nothrow) DIFEditor(IFEditor_ObjName, 
                                                      DEditor::DialogModel, 
                                                      this,
                                                      getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_IFButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_IFSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    insertWidget(ptrDlg);
    ptrDlg->setMediaByHandle(rDukeMediaHandle);
    ptrDlg->initIFEditor(false);
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    return ptrDlg;
}

//synchronize editor with same handle
void DMainWin::synchronizeEditors(const is_response_call& response_call, DEditor * pSrcEditor)
{
    /*
    DMultiWidgets multiWidgets;

    DObjectList * pChildren = m_ptrBgLabel->children();    
    for (DObjectListIt it = pChildren->begin() ; it != pChildren->end(); ++it)
    {
        DEditor *pEditor = dynamic_cast<DEditor *>(*it);
        if( (pEditor == NULL) || pEditor->isHide()
            || pEditor == pSrcEditor || !pEditor->getMedia()
            || (pEditor->getMediaHandle() != pSrcEditor->getMediaHandle()) )
        {
            continue;
        }
                
        pEditor->destorySubEditors(response_call);
        pEditor->reload();
        multiWidgets.addWidget(pEditor);        
    }

    m_ptrBgLabel->updateAll();
    multiWidgets.repaintAll(response_call);
    */
}

bool DMainWin::createEditorByHandle(const duke_media_handle& rDukeMediaHandle)
{
    LOG_DEBUG("=========Create Editor for handle("<<rDukeMediaHandle.str()<<")");
    
    if (rDukeMediaHandle.is_object_user()) 
    {
        DObjEditorPtr ptrObjEditor = createNewObjEditor(rDukeMediaHandle);
        assert(NULL != ptrObjEditor.get());
        return true;
    }
    else if (rDukeMediaHandle.is_declaration()) 
    {
        DDeclEditorPtr ptrDeclEditor  = createNewDeclEditor(rDukeMediaHandle);
        assert(NULL != ptrDeclEditor.get());
        return true;
    }   
    else if (rDukeMediaHandle.is_implementation()) 
    {
        DImplEditorPtr ptrImplEditor  = createNewImplEditor(rDukeMediaHandle);
        assert(NULL != ptrImplEditor.get());
        return true;
    }
    else if (rDukeMediaHandle.is_execute()) 
    {
        DRunEditorPtr ptrRunEditor  = createNewRunEditor(rDukeMediaHandle);
        assert(NULL != ptrRunEditor.get());
        return true;
    }
    else if (rDukeMediaHandle.is_interface()) 
    {
        DIFEditorPtr ptrIFEditor  = createNewIFEditor(rDukeMediaHandle);
        assert(NULL != ptrIFEditor.get());
        return true;
    }
    else if (rDukeMediaHandle.is_object_container_des()) 
    {
        DContEditorPtr ptrContEditor  = createNewContEditor(rDukeMediaHandle);
        assert(NULL != ptrContEditor.get());
        return true;
    }
    return false; 
}

void DMainWin::saveInitScene()
{
    //add the root 
    stdx::json_object scene_root;
    scene_root.insert("username", new stdx::json_string(getApplication()->username()));
    scene_root.insert("dialog_num", new stdx::json_int(m_mainWidgets.size()));
    stdx::json_array* widgets = new stdx::json_array();
    scene_root.insert("widgets", widgets);

    //try to assure login dialog and warehouses is existed
    assert(m_mainWidgets.size() >= 9);
    for (MainWidgetsIdx idx= 0; idx < m_mainWidgets.size(); ++idx)
    {        
        DWidget* pDialog = dynamic_cast<DWidget *>(m_mainWidgets[idx].get());
        if (NULL != pDialog)
        {
            stdx::json_object* dialog_info = new(std::nothrow) stdx::json_object();
            widgets->push_back(dialog_info);

            //insert dialog pos
            stdx::json_object* dialog_pos = new(std::nothrow) stdx::json_object();
            dialog_pos->insert("x", new stdx::json_int(pDialog->geometryPos().x()));
            dialog_pos->insert("y", new stdx::json_int(pDialog->geometryPos().y()));
            dialog_pos->insert("z", new stdx::json_int(pDialog->geometryPos().z()));
            dialog_info->insert("pos", dialog_pos);

            //insert dialog size
            stdx::json_object* dialog_size = new(std::nothrow) stdx::json_object();
            dialog_size->insert("w", new stdx::json_int(pDialog->geometrySize().width()));
            dialog_size->insert("h", new stdx::json_int(pDialog->geometrySize().height()));
            dialog_size->insert("d", new stdx::json_int(pDialog->geometrySize().depth()));
            dialog_info->insert("size", dialog_size);

            //insert dialog hide flag
            dialog_info->insert("hide", new stdx::json_boolean(pDialog->isHide()));
            
            //insert dialog display order flag
            dialog_info->insert("order", new stdx::json_int(pDialog->displayOrder()));

            //insert dialog media handle
            dialog_info->insert("handle", new stdx::json_string(pDialog->getMediaHandle().str()));
        }
    }    
    
    duke_media_set_scene(getApplication()->username(), scene_root.to_json_string());
}

//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wenum-compare"
void DMainWin::restoreInitScene()
{
    std::string restoreInfoStr;
    std::string userName = getApplication()->username();
    duke_media_get_scene(userName, restoreInfoStr);

    if(restoreInfoStr.empty())
        return;    

    //start parse root
    boost::scoped_ptr<stdx::json_object> scene_root(dynamic_cast<stdx::json_object*>
                                                    (stdx::json_tokener_parse(restoreInfoStr)));
    assert(scene_root);

    stdx::json_array *widgets = dynamic_cast<stdx::json_array*>(scene_root->find("widgets"));
    assert(widgets);

    assert((widgets->size() >= 9) && (m_mainWidgets.size() >= 9));
    //resotre login dialog and warehouse at first
    for(int i = 0; i < widgets->size(); ++i)
    {        
        stdx::json_object* dialog_info = dynamic_cast<stdx::json_object*>(widgets->at(i));
        assert(dialog_info);

        std::string strval = dialog_info->find("handle")->get_string();
        duke_media_handle handle;
        handle.str(strval);
        if (i > 8)
        {
            if(!createEditorByHandle(handle))
                continue;            
        }

        stdx::json_object* dialog_pos = dynamic_cast<stdx::json_object*>(dialog_info->find("pos"));
        assert(dialog_pos);

        stdx::json_object* dialog_size = dynamic_cast<stdx::json_object*>(dialog_info->find("size"));
        assert(dialog_size);        
	
	if(i < static_cast<int>(m_mainWidgets.size()))
        {
            DRect rect(dialog_pos->find("x")->get_int(), dialog_pos->find("y")->get_int(),
                       dialog_size->find("w")->get_int(), dialog_size->find("h")->get_int());
            m_mainWidgets[i]->setGeometry(rect);
            m_mainWidgets[i]->setHideProperty(dialog_info->find("hide")->get_boolean());
            m_mainWidgets[i]->setDisplayOrder(dialog_info->find("order")->get_int());
            m_mainWidgets[i]->setMediaByHandle(handle);        
        }
    }
    
    for (MainWidgetsIdx index = 0; index < m_mainWidgets.size(); ++index)
    {
        DButton* pButton = m_pToolWin->findButtonFromWidget(m_mainWidgets[index].get());
        assert(NULL != pButton);
        if (!m_mainWidgets[index]->isHide())
        {
            pButton->setSelected(true);
        }
        else
        {
            pButton->setSelected(false);
        }
    }
    updateAll();
    return;
}
//#pragma GCC diagnostic pop

// vim:set tabstop=4 shiftwidth=4 expandtab:
