/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author    Yinlii 
****************************************************************************/

#ifndef DIMAGEEX_H
#define DIMAGEEX_H

// Boost header files
#include <boost/tr1/memory.hpp>
#include "is_dwidget.h"
#include "is_dtool.h"
#include "is_dimage.h"

class DImageExCell;

class DImageEx : public DWidget {
public:
    DImageEx(DWidget *parent = 0, WFlags f = 0);
    DImageEx(const DImage &image, DWidget *parent = 0, WFlags f = 0);
    virtual ~DImageEx();

    int minAspectRatio() const;
    void setMinAspectRatio(const int minRatio);
    int maxAspectRatio() const;
    void setMaxAspectRatio(const int maxRatio);
    DImage * image() const;
    void setImage(const DImage &);
    
private:
    int m_minRadio;
    int m_maxRadio;
    DImagePtr m_ptrImage;

    D_DECLARE_CELL(DImageEx)
};

/***************************************************************************
 * DImageEx inline functions
 **************************************************************************/
inline int DImageEx::minAspectRatio() const
{ return m_minRadio; } 

inline void DImageEx::setMinAspectRatio(const int minRadio)
{ m_minRadio = minRadio; }

inline int DImageEx::maxAspectRatio() const
{ return m_maxRadio; } 

inline void DImageEx::setMaxAspectRatio(const int maxRadio)
{ m_maxRadio = maxRadio; }

class DImageExCell : public DWidgetCell {
public:
    DImageExCell();
    virtual ~DImageExCell();

    void init();
    virtual void update();
private:
    D_DECLARE_PUBLIC(DImageEx)
};

typedef std::tr1::shared_ptr<DImageEx>  DImageExPtr;
typedef std::tr1::shared_ptr<DImageExCell>  DImageExCellPtr;

const std::string DImageEx_ObjName("DImageEx_Object");

#endif //DIMAGEEX_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
