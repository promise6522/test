/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei 
**
****************************************************************************/

#include "is_dobjeditor.h"
#include "is_difeditor.h"
#include "is_ddecleditor.h"
#include "is_dimpleditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"

DObjEditor::DObjEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f),
      m_curObjPage(0), m_curFuncPage(0), m_funcLayer(0), m_subLayer(0)
{
    m_funcLayerHeight = m_subLayerHeight = ObjEditor_Layer;
    setObjectName(ObjEditor_ObjName);
    assert(pMainWin != NULL);    
}

DObjEditor::DObjEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f),
      m_curObjPage(0), m_curFuncPage(0), m_funcLayer(0), m_subLayer(0)
{
    m_funcLayerHeight = m_subLayerHeight = ObjEditor_Layer;
    setObjectName(ObjEditor_ObjName);
    assert(pMainWin != NULL);
}

DObjEditor::~DObjEditor()
{
}

void DObjEditor::duplicateItemsByHandle(const duke_media_handle& hobj)
{
// TODO to be updated
//    if (!hobj.is_object()) {//TODO
//        assert(!"Invalid object handle.");
//        return;
//    }
//    if (m_ptr)
//        releaseMedia();
//        
//    duke_media_object* pObjMedia = 
//        new(std::nothrow) duke_media_object(this->getApplication()->get_host_committer_id(), getApplication()->username());
//    pObjMedia->copy(hobj);
//    m_ptr = pObjMedia;
//    m_handle = pObjMedia->get_handle();
//    assert(m_ptr != NULL);    
}

void DObjEditor::reload()
{
    LOG_DEBUG("DObjEditor:: reload ......");

    //clear wideget
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        if (it->first) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget((it->first).get());
            if (pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrFuncFrame->detachChildWidget(it->first.get());
            
            if (it->second) {
                //delete subEditor if there is
                pEditor = findSubEditorByWidget((it->second).get());
                if (pEditor != NULL) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }

                m_ptrFuncFrame->detachChildWidget(it->second.get());
            }
        }
    }
    m_funcWidgets.clear();

    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it) {
        if (it->first) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget((it->first).get());
            if (pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrSubFrame->detachChildWidget(it->first.get());
        }

        if (it->second) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget((it->second).get());
            if (pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            
            m_ptrSubFrame->detachChildWidget(it->second.get());
        }
    }
    m_subWidgets.clear();

    // clear
    m_subLayer = 0;
    m_funcLayer = 0;
    m_funcLayerHeight = ObjEditor_Layer;
    m_subLayerHeight = ObjEditor_Layer;

    setMediaByHandle(m_handle);
    // get name & icon
    duke_media_object *pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia) {
        releaseMedia();
        return;
    }
    pObjMedia->get_name(m_dukeName);
    pObjMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    // reload media data
    initFuncExisted();
    initSubExisted();

    // update
    updateFuncView();
    updateSubView();
}

void DObjEditor::initObjEditor()
{
    // get name & icon
    duke_media_object *pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia) {
        releaseMedia();
        return;
    }
    pObjMedia->get_name(m_dukeName);
    pObjMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    //dumpObjectInfo();
    initFuncFrame();
    initSubFrame();

    updateFuncView();
    updateSubView();
}

void DObjEditor::initFuncFrame()
{
    m_ptrFuncFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrFuncFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrFuncFrame.get());
    m_ptrFuncFrame->setGeometry(MAX_COORD/2, MIN_COORD, MAX_COORD/2, MAX_COORD);
    m_ptrFuncFrame->setHideProperty(false);
    m_ptrFuncFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncFrame->setAutoFill(false);
    m_ptrFuncFrame->setFrameStyle(DFrame::Panel);

    // set pass though
    m_ptrFuncFrame->registerEvent(DEvent::Detail, true);
    m_ptrFuncFrame->registerEvent(DEvent::Select, true);
    m_ptrFuncFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrFuncFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrFuncFrame->registerEvent(DEvent::DnD_Start, true);
    
    //m_ptrFuncFrame->registerEvent(DEvent::Drag);
    m_ptrFuncFrame->registerEvent(DEvent::DnD_Release);
    m_ptrFuncFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DObjEditor::onDnDReleaseFuncFrame));

    DImage img;    
    DImage hoverImg;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    hoverImg.setXScale(DImage::Stretch);
    hoverImg.setYScale(DImage::Stretch);
    hoverImg.setRelation(DImage::Disrelated);

    img.load(getResPath() + ObjEditor_LeftArrowButton_Filename);
    hoverImg.load(getResPath() + ObjEditor_LeftArrowHoverButton_Filename);
    m_ptrFuncLArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrFuncFrame.get()));
    assert(m_ptrFuncLArrow.get() != NULL);
    m_ptrFuncLArrow->setGeometry(ObjEditor_LArrow_X,
                                 ObjEditor_Arrow_Y,
                                 ObjEditor_Arrow_Width,
                                 ObjEditor_Arrow_Height);
    m_ptrFuncLArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncLArrow->setSelected(false);
    m_ptrFuncLArrow->registerEvent(DEvent::Select);
    m_ptrFuncLArrow->registerEvent(DEvent::Grab);
    m_ptrFuncLArrow->registerEvent(DEvent::PassingIn);
    m_ptrFuncLArrow->registerEvent(DEvent::PassingOut);
    m_ptrFuncLArrow->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DObjEditor::onFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::Grab,
                                     this,
                                     static_cast<EventRoutine>(&DObjEditor::onFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::PassingIn, 
                                     this, 
                                     (EventRoutine)(&DObjEditor::onPassingInFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DObjEditor::onPassingOutFuncArrow));

    img.load(getResPath() + ObjEditor_RightArrowButton_Filename);
    hoverImg.load(getResPath() + ObjEditor_RightArrowHoverButton_Filename);
    m_ptrFuncRArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrFuncFrame.get()));
    assert(m_ptrFuncRArrow.get() != NULL);
    m_ptrFuncRArrow->setGeometry(ObjEditor_RArrow_X,
                                 ObjEditor_Arrow_Y,
                                 ObjEditor_Arrow_Width,
                                 ObjEditor_Arrow_Height);
    m_ptrFuncRArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncRArrow->setSelected(false);
    m_ptrFuncRArrow->registerEvent(DEvent::Select);
    m_ptrFuncRArrow->registerEvent(DEvent::Grab);
    m_ptrFuncRArrow->registerEvent(DEvent::PassingIn);
    m_ptrFuncRArrow->registerEvent(DEvent::PassingOut);
    m_ptrFuncRArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DObjEditor::onFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::Grab,
                                     this,
                                     static_cast<EventRoutine>(&DObjEditor::onFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::PassingIn, 
                                     this, 
                                     (EventRoutine)(&DObjEditor::onPassingInFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DObjEditor::onPassingOutFuncArrow));

    initFuncExisted();
}

void DObjEditor::initFuncExisted()
{
    if (!m_ptr || !m_ptr->is_object_user()) {
        releaseMedia();
        return;
    }

    duke_media_handle_pair_vector funcsMap;
    dynamic_cast<duke_media_object *>(m_ptr)->get_function_except_compose(funcsMap);

    for (duke_media_handle_pair_vector_const_iterator it = funcsMap.begin(); 
            it != funcsMap.end(); 
            ++it) {
        
        LOG_DEBUG("objeditor init decl = "<<it->first.str()
                 <<", impl = "<<it->second.str());

        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, getApplication()->username(), it->first,
                             ObjEditor_DeclButton_Filename, ObjEditor_DeclButton_Unfin_Filename);
        DImage declSelImg;
        declSelImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declSelImg, getApplication()->username(), it->first,
                             ObjEditor_SelDeclButton_Filename, ObjEditor_SelDeclButton_Unfin_Filename);
        DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                    declImg,
                    declSelImg,
                    m_ptrFuncFrame.get()));
        ptrDeclButton->setSelected(false);
        ptrDeclButton->setFocusAttr(true);
        ptrDeclButton->registerEvent(DEvent::Activate);
        ptrDeclButton->registerEvent(DEvent::Select);
        ptrDeclButton->registerEvent(DEvent::Hover);
        ptrDeclButton->registerEvent(DEvent::PassingOut);
        ptrDeclButton->registerEvent(DEvent::Delete);
        ptrDeclButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DObjEditor::onDeleteFunc)); 
        ptrDeclButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::Select,
                this,
                static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn)); 
        ptrDeclButton->setMediaByHandle(it->first);

        if (it->second.is_type_null()) {
            m_funcWidgets.push_back(ObjWidgetPair(ptrDeclButton, DWidgetPtr()));
            continue;
        }

        DImage implImg;
        implImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(implImg, getApplication()->username(), it->second,
			     ObjEditor_ImplButton_Filename, ObjEditor_ImplButton_Unfin_Filename);
        DImage implSelImg;
        implSelImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(implSelImg, getApplication()->username(), it->second,
			     ObjEditor_SelImplButton_Filename, ObjEditor_SelImplButton_Unfin_Filename);
        DButtonPtr ptrImplButton(new(std::nothrow) DButton("",
                    implImg,
                    implSelImg,
                    m_ptrFuncFrame.get()));
        ptrImplButton->setSelected(false);
        ptrImplButton->setFocusAttr(true);
        ptrImplButton->registerEvent(DEvent::Activate);
        ptrImplButton->registerEvent(DEvent::Hover);
        ptrImplButton->registerEvent(DEvent::PassingOut);
        ptrImplButton->registerEvent(DEvent::Delete);
        ptrImplButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DObjEditor::onDeleteFunc)); 
        ptrImplButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrImplButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrImplButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn)); 
        ptrImplButton->setMediaByHandle(it->second);

        m_funcWidgets.push_back(ObjWidgetPair(ptrDeclButton, ptrImplButton));
    }

    std::size_t totalPage = m_funcWidgets.size() ? ((m_funcWidgets.size() - 1) / ObjEditor_Total_Layer) : 0;
    m_ptrFuncRArrow->setHideProperty(true);
    m_ptrFuncLArrow->setHideProperty(true);
    if(m_curFuncPage < totalPage )
    {
        m_ptrFuncRArrow->setHideProperty(false);        
    }

    if((m_curFuncPage != 0) && (totalPage != 0))
    {
        m_ptrFuncLArrow->setHideProperty(false);        
    }
}

void DObjEditor::initSubFrame()
{
    m_ptrSubFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrSubFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrSubFrame.get());
    m_ptrSubFrame->setGeometry(MIN_COORD + 1, MIN_COORD, MAX_COORD/2, MAX_COORD);    
    m_ptrSubFrame->setHideProperty(false);
    m_ptrSubFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSubFrame->setAutoFill(false);
    m_ptrSubFrame->setFrameStyle(DFrame::Panel);

    //set pass though
    m_ptrSubFrame->registerEvent(DEvent::Detail, true);
    m_ptrSubFrame->registerEvent(DEvent::Select, true);
    m_ptrSubFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrSubFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrSubFrame->registerEvent(DEvent::DnD_Start, true);

    //m_ptrSubFrame->registerEvent(DEvent::Drag);
    m_ptrSubFrame->registerEvent(DEvent::DnD_Release);
    m_ptrSubFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DObjEditor::onDnDReleaseSubFrame));

    DImage img;    
    DImage hoverImg;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    hoverImg.setXScale(DImage::Stretch);
    hoverImg.setYScale(DImage::Stretch);
    hoverImg.setRelation(DImage::Disrelated);

    img.load(getResPath() + ObjEditor_LeftArrowButton_Filename);
    hoverImg.load(getResPath() + ObjEditor_LeftArrowHoverButton_Filename);
    m_ptrObjLArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrSubFrame.get()));
    assert(m_ptrObjLArrow.get() != NULL);
    m_ptrObjLArrow->setGeometry(ObjEditor_LArrow_X,
                                ObjEditor_Arrow_Y,
                                ObjEditor_Arrow_Width,
                                ObjEditor_Arrow_Height);
    m_ptrObjLArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrObjLArrow->setSelected(false);
    m_ptrObjLArrow->registerEvent(DEvent::Select);
    m_ptrObjLArrow->registerEvent(DEvent::Grab);
    m_ptrObjLArrow->registerEvent(DEvent::PassingIn);
    m_ptrObjLArrow->registerEvent(DEvent::PassingOut);
    m_ptrObjLArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DObjEditor::onObjArrow));
    m_ptrObjLArrow->setEventRoutine(DEvent::Grab,
                                    this,
                                    static_cast<EventRoutine>(&DObjEditor::onObjArrow));
    m_ptrObjLArrow->setEventRoutine(DEvent::PassingIn, 
                                    this, 
                                    (EventRoutine)(&DObjEditor::onPassingInObjArrow));
    m_ptrObjLArrow->setEventRoutine(DEvent::PassingOut, 
                                    this, 
                                    (EventRoutine)(&DObjEditor::onPassingOutObjArrow));

    img.load(getResPath() + ObjEditor_RightArrowButton_Filename);
    hoverImg.load(getResPath() + ObjEditor_RightArrowHoverButton_Filename);
    m_ptrObjRArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrSubFrame.get()));
    assert(m_ptrObjRArrow.get() != NULL);
    m_ptrObjRArrow->setGeometry(ObjEditor_RArrow_X,
                                ObjEditor_Arrow_Y,
                                ObjEditor_Arrow_Width,
                                ObjEditor_Arrow_Height);
    m_ptrObjRArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrObjRArrow->setSelected(false);
    m_ptrObjRArrow->registerEvent(DEvent::Select);
    m_ptrObjRArrow->registerEvent(DEvent::Grab);
    m_ptrObjRArrow->registerEvent(DEvent::PassingIn);
    m_ptrObjRArrow->registerEvent(DEvent::PassingOut);
    m_ptrObjRArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DObjEditor::onObjArrow));
    m_ptrObjRArrow->setEventRoutine(DEvent::Grab,
                                    this,
                                    static_cast<EventRoutine>(&DObjEditor::onObjArrow));
    m_ptrObjRArrow->setEventRoutine(DEvent::PassingIn, 
                                    this, 
                                    (EventRoutine)(&DObjEditor::onPassingInObjArrow));
    m_ptrObjRArrow->setEventRoutine(DEvent::PassingOut, 
                                    this, 
                                    (EventRoutine)(&DObjEditor::onPassingOutObjArrow));

    initSubExisted();
}

void DObjEditor::initSubExisted()
{
    if (!m_ptr || !m_ptr->is_object_user()) {
        releaseMedia();
        return;
    }

    //modify by roger 10/26/07
    duke_media_handle_pair_vector subobjsMap;
    dynamic_cast<duke_media_object *>(m_ptr)->get_subobject_and_interfaces(subobjsMap);

    for (duke_media_handle_pair_vector_const_iterator it = subobjsMap.begin(); 
            it != subobjsMap.end(); 
            ++it) {

        DImage objImg;
        objImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(objImg, getApplication()->username(), it->first,
			     ObjEditor_ObjectButton_Filename, ObjEditor_ObjectButton_Unfin_Filename);
        DImage objSelImg;
        objSelImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(objSelImg, getApplication()->username(), it->first,
			     ObjEditor_SelObjectButton_Filename, ObjEditor_SelObjectButton_Unfin_Filename);
        DButtonPtr ptrObjButton(new(std::nothrow) DButton("",
                    objImg,
                    objSelImg,
                    m_ptrSubFrame.get()));
        ptrObjButton->setSelected(false);
        ptrObjButton->setFocusAttr(true);
        ptrObjButton->registerEvent(DEvent::Activate);
        ptrObjButton->registerEvent(DEvent::Select);
        ptrObjButton->registerEvent(DEvent::Hover);
        ptrObjButton->registerEvent(DEvent::PassingOut);
        ptrObjButton->registerEvent(DEvent::Delete);
        ptrObjButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DObjEditor::onDeleteSub)); 
        ptrObjButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrObjButton->setEventRoutine(DEvent::Select,
                this,
                static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
        ptrObjButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrObjButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn)); 
        ptrObjButton->setMediaByHandle(it->first);

        DImage ifImg;
        ifImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(ifImg, getApplication()->username(), it->second,
			     ObjEditor_IFButton_Filename, ObjEditor_IFButton_Unfin_Filename);
        DImage ifSelImg;
        ifSelImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(ifSelImg, getApplication()->username(), it->second,
			     ObjEditor_SelIFButton_Filename, ObjEditor_SelIFButton_Unfin_Filename);
        DButtonPtr ptrIfButton(new(std::nothrow) DButton("",
                    ifImg,
                    ifSelImg,
                    m_ptrSubFrame.get()));
        ptrIfButton->setSelected(false);
        ptrIfButton->setFocusAttr(true);
        ptrIfButton->registerEvent(DEvent::Activate);
        ptrIfButton->registerEvent(DEvent::Select);
        ptrIfButton->registerEvent(DEvent::Hover);
        ptrIfButton->registerEvent(DEvent::PassingOut);
        ptrIfButton->registerEvent(DEvent::Delete);
        ptrIfButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DObjEditor::onDeleteSub)); 
        ptrIfButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrIfButton->setEventRoutine(DEvent::Select,
                this,
                static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
        ptrIfButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrIfButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn)); 
        ptrIfButton->setMediaByHandle(it->second);

        m_subWidgets.push_back(ObjWidgetPair(ptrObjButton, ptrIfButton));
    }

    std::size_t totalPage = m_subWidgets.size() ? ((m_subWidgets.size() - 1) / ObjEditor_Total_Layer) : 0;
    m_ptrObjRArrow->setHideProperty(true);
    m_ptrObjLArrow->setHideProperty(true);
    if(m_curFuncPage < totalPage )
    {
        m_ptrObjRArrow->setHideProperty(false);        
    }

    if((m_curFuncPage != 0) && (totalPage != 0))
    {
        m_ptrObjLArrow->setHideProperty(false);        
    }
}

void DObjEditor::updateFuncView()
{
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it)
    {
        DWidget * pDecl = it->first.get();
        assert(pDecl != NULL);
        pDecl->setGeometry(0, 0, 0, 0);

        if (it->second)
        {            
            it->second->setGeometry(0, 0, 0, 0);
        }
    }
    
    for(std::size_t i = ObjEditor_Total_Layer * m_curFuncPage, count = 0;
        (i < m_funcWidgets.size()) && (count < ObjEditor_Total_Layer); ++i)
    {
        DWidget * pDecl =  m_funcWidgets[i].first.get();
        assert(pDecl != NULL);
        pDecl->setGeometry(1500, count*ObjEditor_Layer + 100, 5000 - 3000, ObjEditor_Layer - 200);

        if (m_funcWidgets[i].second)
            m_funcWidgets[i].second->setGeometry(6500, count*ObjEditor_Layer + 100,
                                                 5000 - 3000, ObjEditor_Layer - 200);
        count++;
    }

    std::size_t totalPage =  m_funcWidgets.size() ? (m_funcWidgets.size() - 1) / ObjEditor_Total_Layer : 0;
    m_ptrFuncRArrow->setHideProperty(true);
    m_ptrFuncLArrow->setHideProperty(true);
    if(m_curFuncPage < totalPage )
    {
        m_ptrFuncRArrow->setHideProperty(false);        
    }

    if((m_curFuncPage != 0) && (totalPage != 0))
    {
        m_ptrFuncLArrow->setHideProperty(false);        
    }
}

DButton * DObjEditor::createWidgetForFunc(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc);

    DButtonPtr ptrItemButton;
    duke_media_handle handle = pSrc->getMediaHandle();

    if (handle.is_implementation())
    {
        int layer = pt.y() / ObjEditor_Layer;

        for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it)
        {
            if (it->first->geometryY()/m_funcLayerHeight == layer && !it->second)
            {
                duke_media_handle_vector oifs;
                duke_media_implement implMedia(handle);
                implMedia.get_in_interfaces(oifs);
                
                duke_media_handle hif;
                duke_media_get_interface_by_object(getMediaHandle(), hif);
                if (!duke_media_implement_match_declare(handle, it->first->getMediaHandle())
                    || (!duke_media_interface_cover_interface(hif, oifs[0])) || (!(oifs.size() > 0)))
                {
                    return NULL;
                }
                if (!(implMedia.get_share() || (implMedia.get_master() == this->getMediaHandle())))
                {
                    LOG_ERROR("this object is not the implement's master!");
                    return NULL; 
                }

                DImage implImg;
                implImg.setRelation(DImage::KeepSmall);
                setImageDataByHandle(implImg, getApplication()->username(), handle, 
                                     ObjEditor_ImplButton_Filename, ObjEditor_ImplButton_Unfin_Filename);   
     
                // create new implementation
                ptrItemButton.reset(new(std::nothrow) DButton("", implImg, m_ptrFuncFrame.get()));
                ptrItemButton->setFocusAttr(true);
                ptrItemButton->registerEvent(DEvent::Activate);
                ptrItemButton->registerEvent(DEvent::Hover);
                ptrItemButton->registerEvent(DEvent::PassingOut);
                ptrItemButton->registerEvent(DEvent::Delete);
                ptrItemButton->setEventRoutine(DEvent::Delete,
                                               this,
                                               static_cast<EventRoutine>(&DObjEditor::onDeleteFunc)); 
                ptrItemButton->setEventRoutine(DEvent::Activate,
                                               this,
                                               static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
                ptrItemButton->setEventRoutine(DEvent::Hover,
                                               this,
                                               static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
                ptrItemButton->setEventRoutine(DEvent::PassingOut,
                                               this,
                                               static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn));                
                ptrItemButton->setMediaByHandle(handle);

                it->second = ptrItemButton;
                dynamic_cast<duke_media_object *>(m_ptr)->add_function(
                        it->first->getMediaHandle(), it->second->getMediaHandle());

                break;
            }
        }

    }

    else if (handle.is_declaration())
    {
        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, getApplication()->username(), handle,
                             ObjEditor_DeclButton_Filename, ObjEditor_DeclButton_Unfin_Filename);
     
        // create new declaration
        ptrItemButton.reset(new(std::nothrow) DButton("", declImg, m_ptrFuncFrame.get()));
        ptrItemButton->setFocusAttr(true);
        ptrItemButton->registerEvent(DEvent::Activate);
        ptrItemButton->registerEvent(DEvent::Hover);
        ptrItemButton->registerEvent(DEvent::PassingOut);
        ptrItemButton->registerEvent(DEvent::Delete);
        ptrItemButton->setEventRoutine(DEvent::Delete,
                                       this,
                                       static_cast<EventRoutine>(&DObjEditor::onDeleteFunc)); 
        ptrItemButton->setEventRoutine(DEvent::Activate,
                                       this,
                                       static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrItemButton->setEventRoutine(DEvent::Hover,
                                       this,
                                       static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrItemButton->setEventRoutine(DEvent::PassingOut,
                                       this,
                                       static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn));       
        ptrItemButton->setMediaByHandle(handle);

        dynamic_cast<duke_media_object *>(m_ptr)->add_function(handle);
        m_funcWidgets.push_back(ObjWidgetPair(ptrItemButton, DWidgetPtr()));
        m_curFuncPage = (m_funcWidgets.size() - 1) / ObjEditor_Total_Layer;
    }
 
    // update all layers
    updateFuncView();

    return ptrItemButton.get();
}

void DObjEditor::onDnDReleaseFuncFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onDnDReleaseFuncFrame");

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
 
    // if a dialog release to frame
    DDialog* pDialog = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL  != pDialog) {
        dialogReleaseToFrame(event, m_ptrSubFrame.get());
        return;
    }

    duke_media_handle handle = pSrcWidget->getMediaHandle();
    
    // only receive duke declaration and implementation
    if (!handle.is_declaration() && !handle.is_implementation()) 
    {
        LOG_ERROR("must drag in a decl or implementation.");
        return;
    }
 
    // to check the valid implementation add by roger
    if (handle.is_implementation())
    {
        duke_media_implement implMedia(handle);

        if (!implMedia.check())
        {
            LOG_ERROR("the implement is a invalid!");
            return;
        }

        std::vector<duke_media_node> nodes;
        implMedia.get_object_nodes(nodes);
        for (size_t i = 0; i < nodes.size(); ++i ) 
        {
            if (nodes[i].m_inputs[0].is_storage())
            {
                LOG_ERROR("current implementation including storages shouldn't be dragged into objEditor."); 
                return;
            }
            else if (nodes[i].m_inputs[0].is_object_container_des())
            {
                LOG_ERROR("current implementation including container shouldn't be dragged into objEditor."); 
                return;
            }
        }    
    } 

    // Check if a same declaration already exists
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it)
    {        
        if (it->first && (handle == it->first->getMediaHandle()))
        {
            LOG_ERROR("A same declaration already exists.");
            return;
        }

        // (comment by tom) : two decls share the same impl is allowed
        //if (it->second && (handle == it->second->getMediaHandle()))
        //{
        //    LOG_ERROR("A same implementation already exists.");
        //    return;
        //}
    }

    //set dirty
    m_isModified = true;
    
    // only add new layer for new duke declaration 
    DPoint pos = event.getEventPosition();
    if (pos.y()/m_funcLayerHeight >= m_funcLayer && pos.x() < 5000)
        m_funcLayer++;

    // create widget for duke object
    createWidgetForFunc(event.getEventPosition(), pSrcWidget);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DObjEditor::updateSubView()
{
    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it)
    {
        DWidget * pSubObj = it->first.get();
        assert(pSubObj != NULL);
        pSubObj->setGeometry(0, 0, 0, 0);

        if (it->second)
        {            
            it->second->setGeometry(0, 0, 0, 0);
        }
    }
    
    for(std::size_t i = ObjEditor_Total_Layer * m_curObjPage, count = 0;
        (i < m_subWidgets.size()) && (count < ObjEditor_Total_Layer); ++i)
    {
        DWidget * pSubObj =  m_subWidgets[i].first.get();
        assert(pSubObj != NULL);
        pSubObj->setGeometry(1500, count*ObjEditor_Layer + 100, 5000 - 3000, ObjEditor_Layer - 200);

        if (m_subWidgets[i].second)
            m_subWidgets[i].second->setGeometry(6500, count*ObjEditor_Layer + 100,
                                                5000 - 3000, ObjEditor_Layer - 200);
        count++;
    }

    std::size_t totalPage =  m_subWidgets.size() ? (m_subWidgets.size() - 1) / ObjEditor_Total_Layer : 0;
    m_ptrObjRArrow->setHideProperty(true);
    m_ptrObjLArrow->setHideProperty(true);
    if(m_curObjPage < totalPage )
    {
        m_ptrObjRArrow->setHideProperty(false);        
    }

    if((m_curObjPage != 0) && (totalPage != 0))
    {
        m_ptrObjLArrow->setHideProperty(false);        
    }
}

DButton * DObjEditor::createWidgetForSub(const DPoint &pt, DWidget *pSrc)
{
    duke_media_handle handle = pSrc->getMediaHandle();

    DButtonPtr ptrObjButton;
    if (handle.is_interface())
    {
        std::size_t layer = pt.y() / ObjEditor_Layer;

        for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it)
        {
            if (it->first->geometryY()/ObjEditor_Layer == layer && !it->second)
            {
                DImage ifImg;
                ifImg.setRelation(DImage::KeepSmall);
                setImageDataByHandle(ifImg, getApplication()->username(), pSrc->getMediaHandle(), ObjEditor_IFButton_Filename, 
				     ObjEditor_IFButton_Unfin_Filename);
                DImage ifSelImg;
                ifSelImg.setRelation(DImage::KeepSmall);
                setImageDataByHandle(ifSelImg, getApplication()->username(), pSrc->getMediaHandle(), 
				     ObjEditor_SelIFButton_Filename, ObjEditor_SelIFButton_Unfin_Filename);
                
                // create default interface widget from subobject
                DButtonPtr ptrIFButton(new(std::nothrow) DButton("", ifImg, ifSelImg, m_ptrSubFrame.get()));
                ptrIFButton->setSelected(false);
                ptrIFButton->setFocusAttr(true);
                ptrIFButton->registerEvent(DEvent::Activate);
                ptrIFButton->registerEvent(DEvent::Select);
                ptrIFButton->registerEvent(DEvent::Hover);
                ptrIFButton->registerEvent(DEvent::PassingOut);
                ptrIFButton->registerEvent(DEvent::Delete);
                ptrIFButton->setEventRoutine(DEvent::Delete,
                                             this,
                                             static_cast<EventRoutine>(&DObjEditor::onDeleteSub)); 
                ptrIFButton->setEventRoutine(DEvent::Activate,
                                             this,
                                             static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
                ptrIFButton->setEventRoutine(DEvent::Select,
                                             this,
                                             static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
                ptrIFButton->setEventRoutine(DEvent::Hover,
                                             this,
                                             static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
                ptrIFButton->setEventRoutine(DEvent::PassingOut,
                                             this,
                                             static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn));
                ptrIFButton->setMediaByHandle(handle);

                it->second = ptrIFButton;                
                dynamic_cast<duke_media_object *>(m_ptr)->add_subobject(it->first->getMediaHandle(),
                                                                        it->second->getMediaHandle());
            }
        }
    }
    else if (handle.is_object())
    {
        // get interface of this subobject
        duke_media_handle hobj = pSrc->getMediaHandle();
        /*
        if (hobj.is_object_builtin())
            duke_media_clone(this->getApplication()->get_host_committer_id(), pSrc->getMediaHandle(), hobj);
        */
            
        DImage objImg;
        objImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(objImg, getApplication()->username(), hobj, 
			     ObjEditor_ObjectButton_Filename, ObjEditor_ObjectButton_Unfin_Filename);

        DImage objSelImg;
        objSelImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(objSelImg, getApplication()->username(), hobj, 
			     ObjEditor_SelObjectButton_Filename, ObjEditor_SelObjectButton_Unfin_Filename);

        // create new object
        ptrObjButton.reset(new(std::nothrow) DButton("", objImg, objSelImg, m_ptrSubFrame.get()));
        ptrObjButton->setSelected(false);
        ptrObjButton->setFocusAttr(true);
        ptrObjButton->registerEvent(DEvent::Activate);
        ptrObjButton->registerEvent(DEvent::Select);
        ptrObjButton->registerEvent(DEvent::Hover);
        ptrObjButton->registerEvent(DEvent::PassingOut);
        ptrObjButton->registerEvent(DEvent::Delete);
        ptrObjButton->setEventRoutine(DEvent::Delete, this,
                                      static_cast<EventRoutine>(&DObjEditor::onDeleteSub)); 
        ptrObjButton->setEventRoutine(DEvent::Activate, this,
                                      static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
        ptrObjButton->setEventRoutine(DEvent::Select, this,
                                      static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
        ptrObjButton->setEventRoutine(DEvent::Hover, this,
                                      static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
        ptrObjButton->setEventRoutine(DEvent::PassingOut, this,
                                      static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn));

        duke_media_handle hif;
        duke_media_get_interface_by_object(hobj, hif);
        if (hif.is_interface())
        {
            DImage ifImg;
            ifImg.setRelation(DImage::KeepSmall);
            setImageDataByHandle(ifImg, getApplication()->username(), hif, 
				 ObjEditor_IFButton_Filename, ObjEditor_IFButton_Unfin_Filename);
            DImage ifSelImg;
            ifSelImg.setRelation(DImage::KeepSmall);
            setImageDataByHandle(ifSelImg, getApplication()->username(), hif, 
				 ObjEditor_SelIFButton_Filename, ObjEditor_SelIFButton_Unfin_Filename);
            // create default interface widget from subobject
            DButtonPtr ptrIFButton(new(std::nothrow) DButton("", ifImg, ifSelImg, m_ptrSubFrame.get()));
            ptrIFButton->setSelected(false);
            ptrIFButton->setFocusAttr(true);
            ptrIFButton->registerEvent(DEvent::Activate);
            ptrIFButton->registerEvent(DEvent::Select);
            ptrIFButton->registerEvent(DEvent::Hover);
            ptrIFButton->registerEvent(DEvent::PassingOut);
            ptrIFButton->registerEvent(DEvent::Delete);
            ptrIFButton->setEventRoutine(DEvent::Delete,
                                         this,
                                         static_cast<EventRoutine>(&DObjEditor::onDeleteSub)); 
            ptrIFButton->setEventRoutine(DEvent::Activate,
                                         this,
                                         static_cast<EventRoutine>(&DObjEditor::onActivateBtn)); 
            ptrIFButton->setEventRoutine(DEvent::Select,
                                         this,
                                         static_cast<EventRoutine>(&DObjEditor::onSelectBtn)); 
            ptrIFButton->setEventRoutine(DEvent::Hover,
                                         this,
                                         static_cast<EventRoutine>(&DObjEditor::onHoverBtn)); 
            ptrIFButton->setEventRoutine(DEvent::PassingOut,
                                         this,
                                         static_cast<EventRoutine>(&DObjEditor::onPassingOutBtn));
            ptrObjButton->setMediaByHandle(hobj);
            ptrIFButton->setMediaByHandle(hif);

            dynamic_cast<duke_media_object *>(m_ptr)->add_subobject(hobj, hif);
            m_subWidgets.push_back(ObjWidgetPair(ptrObjButton, ptrIFButton));
            m_curObjPage = (m_subWidgets.size() - 1) / ObjEditor_Total_Layer;
        }
    }

    // update all layers
    updateSubView();

    return ptrObjButton.get();
}

void DObjEditor::dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame)
{
    assert(NULL != m_pMainWin);
    DPoint releasePos = rEvent.getEventPosition();
   
    DWidget *pWidget = pFrame;
    DWidget *pParentWidget = dynamic_cast<DWidget *>(pWidget->parent());

    while ((pParentWidget != NULL) && (pParentWidget != m_pMainWin)) {
        DPoint pPos = pWidget->geometryPos();
        DSize pSize = pWidget->geometrySize();
        releasePos.setX(releasePos.x() * pSize.width() / MAX_COORD + pPos.x());
        releasePos.setY(releasePos.y() * pSize.height() / MAX_COORD + pPos.y());
        pWidget = pParentWidget;
        pParentWidget = dynamic_cast<DWidget *>(pParentWidget->parent());
    }

    DEvent& eventRef = const_cast<DEvent &>(rEvent);
    eventRef.setEventPosition(releasePos);
    m_pMainWin->onDnDRelease(rEvent); 
}

void DObjEditor::onDnDReleaseSubFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onDnDReleaseSubFrame");

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
 
    // if a dialog release to frame
    DDialog* pDialog = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL  != pDialog) {
        dialogReleaseToFrame(event, m_ptrSubFrame.get());
        return;
    }
    
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    //set dirty
    m_isModified = true;
    
    // only add new layer for new duke object
    DPoint pos = event.getEventPosition();
    if (pos.y()/m_subLayerHeight >= m_subLayer && pos.x() < 5000)
        m_subLayer++;

    // create widget for duke object
    createWidgetForSub(event.getEventPosition(), pSrcWidget);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DObjEditor::onDeleteSub(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onDeleteSub");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
    
    //set dirty
    m_isModified = true;
    
    // if subobject, delete relevant interface 
    for (SubWidgetsIt it = m_subWidgets.begin(); 
            it != m_subWidgets.end(); 
            ++it) {
        if (it->first.get() == pSrcWidget) {
            m_ptrSubFrame->detachChildWidget(it->first.get());
            if (it->second)
                m_ptrSubFrame->detachChildWidget(it->second.get());
            dynamic_cast<duke_media_object *>(m_ptr)->del_subobject(
                    it->first->getMediaHandle());
            m_subWidgets.erase(it);
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    std::size_t totalPage = m_subWidgets.size() ? ((m_subWidgets.size() - 1) / ObjEditor_Total_Layer) : 0;
    m_curObjPage = m_curObjPage > totalPage ? totalPage : m_curObjPage;

    // repaint
    updateSubView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DObjEditor::onDeleteFunc(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onDeleteFunc");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
    
    //set dirty
    m_isModified = true;

    // if declaration, delete relevant implementation 
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); 
            it != m_funcWidgets.end(); 
            ++it) {
        if (it->first.get() == pSrcWidget) {
            m_ptrFuncFrame->detachChildWidget(it->first.get());
            if (it->second)
                m_ptrFuncFrame->detachChildWidget(it->second.get());
            dynamic_cast<duke_media_object *>(m_ptr)->del_function(
                    it->first->getMediaHandle());
            m_funcWidgets.erase(it);
            break;
        }

        if (it->second.get() == pSrcWidget) {
            m_ptrFuncFrame->detachChildWidget(it->second.get());
            dynamic_cast<duke_media_object *>(m_ptr)->del_implementation(
                    it->first->getMediaHandle());
            it->second = DWidgetPtr();
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());
    std::size_t totalPage = m_funcWidgets.size() ? ((m_funcWidgets.size() - 1) / ObjEditor_Total_Layer) : 0;
    m_curFuncPage = m_curFuncPage > totalPage ? totalPage : m_curFuncPage;

    // repaint
    updateFuncView();
    updateAll();
    repaint(event.getCon());

    // synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DObjEditor::onSelectBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onSelectBtn");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pSrcWidget = dynamic_cast<DButton*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it) {
        if (it->first) {
            DButton* pBtn = dynamic_cast<DButton*>(it->first.get()); 
            pBtn->setSelected(false);
        }

        if (it->second) {
            DButton* pBtn = dynamic_cast<DButton*>(it->second.get()); 
            pBtn->setSelected(false);
        }
    }

    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        if (it->first) {
            DButton* pBtn = dynamic_cast<DButton*>(it->first.get()); 
            pBtn->setSelected(false);
        }

        if (it->second) {
            DButton* pBtn = dynamic_cast<DButton*>(it->second.get()); 
            pBtn->setSelected(false);
        }
    }

    pSrcWidget->setSelected(true);

    updateAll();
    repaint(event.getCon());
}

void DObjEditor::onActivateBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onActivateBtn");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();

        //if it is readonly, just show/hide dialog
        if(m_isReadOnly)
        {
            if(pEditor->isHide())
            {
                pEditor->display(event.getCon());
            }
            else
            {
                pEditor->hideAllSubEditors(event.getCon());
                pEditor->hide(event.getCon());
            }
            return;
        }
        
        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pEditor->isHide()) {
            if (pInput) {
                // Set initial value
                std::string value;
                if (pSrcWidget->getMediaValue(value))
                    pInput->setInputString(value);
            }
            pEditor->updateAll();
            pEditor->display(event.getCon());
        }
        else
        {
            //reload the media
            pSrcWidget->setMediaByHandle(pSrcWidget->getMediaHandle());
            
            if (pInput)
            {   
                pSrcWidget->setMediaValue(pInput->getInputString());
                std::string value;
                pSrcWidget->getMediaValue(value);
                pInput->setInputString(value);
                m_isModified = true;
            }
            else if (pSrcWidget->getMedia()->is_object_array())
            {
                DButton* pButton = dynamic_cast<DButton *>(pSrcWidget);
                if (pButton)
                {
                    duke_media_array* pMedia = dynamic_cast<duke_media_array *>(pButton->getMedia());
                    if(pMedia)
                    {
                        DImage img;
                        img.setXScale(DImage::Stretch);
                        img.setYScale(DImage::Stretch);
                        img.setRelation(DImage::Disrelated);                
                        //change the icon
                        if(pMedia->is_expanded())
                        {
                            img.load(get_builtin_resource_path() + ObjEditor_ArrayExImg_FileName);
                            pButton->setImage(img);
                            pButton->setSelImage(img);
                        }
                        else
                        {
                            img.load(get_builtin_resource_path() + ObjEditor_ArrayImg_FileName);
                            pButton->setImage(img);
                            pButton->setSelImage(img);
                        }
                    }
                }

                pButton->updateAll();
                pButton->repaint(event.getCon());
            }
            else if (pSrcWidget->getMedia()->is_object_map())
            {
                DButton* pButton = dynamic_cast<DButton *>(pSrcWidget);
                if (pButton)
                {
                    duke_media_map* pMedia = dynamic_cast<duke_media_map *>(pButton->getMedia());
                    if(pMedia)
                    {
                        DImage img;
                        img.setXScale(DImage::Stretch);
                        img.setYScale(DImage::Stretch);
                        img.setRelation(DImage::Disrelated);                
                        //change the icon
                        if(pMedia->is_expanded())
                        {
                            img.load(get_builtin_resource_path() + ObjEditor_MapExImg_FileName);
                            pButton->setImage(img);
                            pButton->setSelImage(img);
                        }
                        else
                        {
                            img.load(get_builtin_resource_path() + ObjEditor_MapImg_FileName);
                            pButton->setImage(img);
                            pButton->setSelImage(img);
                        }
                    }
                }

                pButton->updateAll();
                pButton->repaint(event.getCon());
            }

            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if (pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }
        
        //save information
        saveSubObjInfo();
        saveFuncInfo();

        return;
    }

    pEditor = createSubEditor(pSrcWidget);
    if(pEditor)
    {        
        pEditor->updateAll();
        pEditor->show(event.getCon());
    }    
}

void DObjEditor::onHoverBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onHoverBtn");

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip)) {
        if (pSrcWidget->getMedia()->is_object_builtin()) {
            std::string val;
            pSrcWidget->getMediaValue(val);
            strTip = strTip + " " + val; 
        }
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    } else {
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    }
}

void DObjEditor::onPassingOutBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DObjEditor::onPassingOut");

    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DObjEditor::setReadonly()
{
    DEditor::setReadonly();

    //m_ptrSubFrame->unRegisterEvent(DEvent::Drag);
    m_ptrSubFrame->unRegisterEvent(DEvent::DnD_Release);

    //m_ptrFuncFrame->unRegisterEvent(DEvent::Drag);
    m_ptrFuncFrame->unRegisterEvent(DEvent::DnD_Release);

    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it) {
        if (it->first) {
            it->first->unRegisterEvent(DEvent::Activate);
            it->first->unRegisterEvent(DEvent::Delete);
        }

        if (it->second) {
            it->second->unRegisterEvent(DEvent::Activate);
            it->second->unRegisterEvent(DEvent::Delete);
        }
    }

    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        if (it->first) {
            it->first->unRegisterEvent(DEvent::Activate);
            it->first->unRegisterEvent(DEvent::Delete);
        }

        if (it->second) {
            it->second->unRegisterEvent(DEvent::Activate);
            it->second->unRegisterEvent(DEvent::Delete);
        }
    }
}

void DObjEditor::saveSubObjInfo()
{
    duke_media_object* pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia)
        return;

    //clear subobject
    pObjMedia->clear_subobject();

    // save subObject and IF
    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it) {
        DWidget * pObjWidget = it->first.get();
        if(pObjWidget == NULL)
            continue;

        duke_media_handle hobj = pObjWidget->getMediaHandle();

        if (hobj == duke_media_handle_null)
            continue;

        duke_media_handle hcif = duke_media_handle_null;
        DWidget * pIFWidget = it->second.get();

        if (pIFWidget != NULL) 
            hcif = pIFWidget->getMediaHandle();

        pObjMedia->add_subobject(hobj, hcif);        
    }
}

void DObjEditor::saveFuncInfo()
{
    duke_media_object* pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia)
        return;

    //clear subobject
    pObjMedia->clear_function();

    //save subObject and IF
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        DWidget * pDeclWidget = it->first.get();
        if (pDeclWidget == NULL)
            continue;

        duke_media_handle hdecl = pDeclWidget->getMediaHandle();

        if (hdecl == duke_media_handle_null)
            continue;

        duke_media_handle himpl = duke_media_handle_null;
        DWidget * pImplWidget = it->second.get();

        if (pImplWidget != NULL)
        {
            himpl = pImplWidget->getMediaHandle();
            pObjMedia->add_function(hdecl, himpl);
        }
        else
        {
            pObjMedia->add_function(hdecl);
        }            
    }    
}

void DObjEditor::onGenerate(const DEvent &event)
{
    generate();
    destorySubEditors(event.getCon());
    clearSubEditors();

    //dump info
    //dumpObjectInfo();
}

void DObjEditor::generateSubItems()
{
//    for (SubWidgetsIt it = m_subWidgets.begin(); it != m_subWidgets.end(); ++it) {
//        if (it->first) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->first.get());
//
//            // current widget have the subEditor and subEditor contain Media information
//            if (pEditor && pEditor->isModified() && pEditor->getMedia() 
//                && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                   && (newh != duke_media_handle_null)) {
//                it->first->setMediaByHandle(newh);
//                pEditor->generateSubItems();
//            } else if ( it->first->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->first->getMediaHandle()) == Edit)
//                    && it->first->getMedia()->generate(getApplication()->username(), newh) 
//                    && newh != duke_media_handle_null) {
//                createSubEditor(it->first.get())->generateSubItems();
//                it->first->setMediaByHandle(newh);
//            }
//        }
//
//        if (it->second) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->second.get());
//            
//            if (pEditor && pEditor->isModified() && pEditor->getMedia() 
//                    && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                    && (newh != duke_media_handle_null)) {
//                it->first->setMediaByHandle(newh);
//                pEditor->generateSubItems();
//            } else if ( it->second->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->second->getMediaHandle()) == Edit)
//                    && it->second->getMedia()->generate(getApplication()->username(), newh) 
//                    && newh != duke_media_handle_null) {
//                createSubEditor(it->first.get())->generateSubItems();
//                it->first->setMediaByHandle(newh);
//            }
//        }
//    }
//
//    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
//        if (it->first) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->first.get());
//
//            // current widget have the subEditor and subEditor contain Media information
//            if (pEditor && pEditor->isModified() && pEditor->getMedia() 
//                    && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                    && (newh != duke_media_handle_null)) {
//                it->first->setMediaByHandle(newh);
//                pEditor->generateSubItems();
//            } else if ( it->first->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->first->getMediaHandle()) == Edit)
//                    && it->first->getMedia()->generate(getApplication()->username(), newh) 
//                    && newh != duke_media_handle_null) {
//                createSubEditor(it->first.get())->generateSubItems();
//                it->first->setMediaByHandle(newh);
//            }
//        }
//
//        if (it->second) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->second.get());
// 
//            if (pEditor && pEditor->isModified() && pEditor->getMedia() 
//                    && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                    && (newh != duke_media_handle_null)) {
//                it->second->setMediaByHandle(newh);
//                pEditor->generateSubItems();
//            } else if ( it->second->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->second->getMediaHandle()) == Edit)
//                    && it->second->getMedia()->generate(getApplication()->username(), newh) 
//                    && newh != duke_media_handle_null) {
//                createSubEditor(it->first.get())->generateSubItems();
//                it->second->setMediaByHandle(newh);
//            }
//        }
//    }
}

duke_media_handle DObjEditor::generate()
{
    //if current object already have been generated, just return.
    if (e_handle_core == get_media_handle_status(m_handle))
    {
        LOG_NOTICE("This object already have been generated");
        return m_handle;        
    }    

    //DEditor::generate();

    duke_media_object* pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia)
        return duke_media_handle_null;

    LOG_DEBUG("==========Generate the "<<m_dukeName<<" Object==========");
    duke_media_handle newh = duke_media_handle_null;

    if (isValidObj(pObjMedia))
    {
        nb_id_t new_id;
        std::map<int, nb_id_t> idx_id_map;

        if(pObjMedia->compile(getApplication()->username(), new_id, idx_id_map))
        {
            //saveSubObjInfo();
            //saveFuncInfo();

            LOG_INFO("Generate the Object and subItems successful.");

            // save the generated id to warehouse
            newh = new_id;
            save_generated_handle(newh, getApplication()->username());

            // save generated compound declarations
            int decl_num = 0;
            for (std::map<int, nb_id_t>::const_iterator it = idx_id_map.begin();
                    it != idx_id_map.end(); ++it)
            {
                duke_media_handle hdecl;
                // specify the actual type
                if (it->second.get_type() == NBID_TYPE_OBJECT_DECLARATION_COMPOUND)
                {
                    hdecl = it->second;
                    if (save_generated_handle(hdecl, getApplication()->username()))
                        decl_num++;
                }
            }
            LOG_INFO("Generate " << decl_num << " sub declarations.");

            return newh;            
        }
    }

    LOG_ERROR("It is not a valid Object, could not generate Object!");
    return duke_media_handle_null;
}

bool DObjEditor::isValidObj(duke_media_object* pObjMedia)
{
    if (pObjMedia == NULL)
        return false;

    LOG_DEBUG("Check Object Completeness: ");

    // check the name is not empty
    std::string name;
    pObjMedia->get_name(name);
    if (name.empty()) {
        LOG_NOTICE("Error, missing name");
        return false;
    }

    // check the subObj
    duke_media_handle_vector hobjs;
    pObjMedia->get_subobjects(hobjs);
    for (size_t i = 0; i < hobjs.size(); ++i)  {
        if (hobjs[i] == duke_media_handle_null) {
            LOG_NOTICE("Error, the subObject is null");
            return false;
        }
    }

    // check subObj's IF
    duke_media_handle_vector hifs;
    pObjMedia->get_subinterfaces(hifs);
    if (hifs.size() != hobjs.size()) {
        LOG_NOTICE("Error, missing subObject's interface");
        return false;
    }
    for (size_t i = 0; i < hifs.size(); ++i) {
        if (hifs[i] == duke_media_handle_null) {
            LOG_NOTICE("Error, the subObject's interface is null");
            return false;
        }
    }

    // check object declaration
    duke_media_handle_vector hdecl;
    pObjMedia->get_declarations(hdecl);
    for (size_t i = 0; i < hdecl.size(); ++i)  {
        if (hdecl[i] == duke_media_handle_null) {
            LOG_NOTICE("Error, the declaration"" is null");
            return false;
        }

        duke_media_handle himpl = duke_media_handle_null;
        pObjMedia->get_implementation(hdecl[i], himpl);
        if (!hdecl[i].is_function_instruction() && !hdecl[i].is_function_compose()
            && !hdecl[i].is_function_decompose() && himpl == duke_media_handle_null) {
            LOG_NOTICE("Error, missing the implementation");
            return false;
        }
    }

    return true;
}

void DObjEditor::dumpObjectInfo()
{
    LOG_DEBUG("===================================");
    
    duke_media_object* pObjMedia = dynamic_cast<duke_media_object *>(m_ptr);
    if (NULL == pObjMedia) {
        LOG_DEBUG("Error: No duke media.");
        LOG_DEBUG("===================================");
        return;
    }

    //dump name & icon
    std::string name;
    std::string icon;
    pObjMedia->get_name(name);
    pObjMedia->get_icon(icon);
    LOG_DEBUG("Object name = "<<name<<std::endl
             <<"Object icon = "/*<<toHexString(icon)*/);

    //dump subObject
    duke_media_handle_vector hobjs;
    pObjMedia->get_subobjects(hobjs);
    LOG_DEBUG("\nsubobject size = "<<hobjs.size());
    for (size_t i = 0; i < hobjs.size(); ++i) {
        std::string objName;
        if(!duke_media_get_name(hobjs[i], objName))
            continue;

        LOG_DEBUG("\t("<<objName<<") ");
    }

    //dump subObject's Interface
    duke_media_handle_vector hifs;
    pObjMedia->get_subinterfaces(hifs);
    LOG_DEBUG("\nsubobject's interface size = "<<hifs.size());
    for (size_t i = 0; i < hifs.size(); ++i) {
        std::string ifName;
        if(!duke_media_get_name(hifs[i], ifName))
            continue;

        LOG_DEBUG("\t("<<ifName<<") ");
    }

    //dump declaration
    duke_media_handle_vector hdecl;
    pObjMedia->get_declarations(hdecl);
    LOG_DEBUG("\ndeclaration size = "<<hdecl.size());
    for (size_t i = 0; i < hdecl.size(); ++i) {
        std::string declName;
        if(!duke_media_get_name(hdecl[i], declName))
            continue;

        LOG_DEBUG("\t("<<declName<<") ");

        duke_media_handle himpl = duke_media_handle_null;
        pObjMedia->get_implementation(hdecl[i], himpl);
        std::string implName;
        if( (himpl != duke_media_handle_null) 
            && duke_media_get_name(himpl, implName) ) {
            LOG_DEBUG("\t<-->\t("<<implName<<") ");            
        }
    }
}

void DObjEditor::onObjArrow(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);

    if(pButton == m_ptrObjLArrow.get())
    {
        m_curObjPage = m_curObjPage <= 0 ? 0 :  m_curObjPage - 1;
    }
    else if(pButton == m_ptrObjRArrow.get())
    {
        m_curObjPage = (m_curObjPage + 1) * ObjEditor_Total_Layer > m_subWidgets.size() ? m_curObjPage
            :  m_curObjPage + 1;
    }
    else
    {
        return;
    }

    updateSubView();
    updateAll();
    repaint(event.getCon());
}

void DObjEditor::onPassingInObjArrow(const DEvent &event)
{
}

void DObjEditor::onPassingOutObjArrow(const DEvent &event)
{
}

void DObjEditor::onFuncArrow(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);

    if(pButton == m_ptrFuncLArrow.get())
    {
        m_curFuncPage = m_curFuncPage <= 0 ? 0 :  m_curFuncPage - 1;
    }
    else if(pButton == m_ptrFuncRArrow.get())
    {
        m_curFuncPage = (m_curFuncPage + 1) * ObjEditor_Total_Layer >= m_funcWidgets.size() ? m_curFuncPage
            :  m_curFuncPage + 1;
    }
    else
    {
        return;
    }

    updateFuncView();
    updateAll();
    repaint(event.getCon());
}

void DObjEditor::onPassingInFuncArrow(const DEvent &event)
{
}

void DObjEditor::onPassingOutFuncArrow(const DEvent &event)
{
}

DObjEditorCell::DObjEditorCell()
{
}

DObjEditorCell::~DObjEditorCell()
{
}

void DObjEditorCell::init()
{
}

void DObjEditorCell::update()
{
    // call parent class at first
    DDialogCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
