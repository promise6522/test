/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

// Duke header files
#include "is_dpackagesetting.h"
#include "is_dpackageexplorer.h"
#include "is_dpackagesheet.h"

DPackageSetting::DPackageSetting(const std::string& title, int model /* = PanelModel */, 
                                 DPackageSheet *pPackageSheet /* = NULL */, 
                                 DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */)
    :DEditor(title, model, pMainWin, parent),
     m_pPackageSheet(pPackageSheet)
{
    setObjectName(DPackageSetting_ObjName);
    assert(pMainWin);
    assert(m_pPackageSheet);
}

DPackageSetting::~DPackageSetting()
{
}

void DPackageSetting::initDialog()
{
    DEditor::initDialog();  

    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //Package Name background
    img.load(getResPath() + DPackageSetting_NameImg_FileName);
    m_ptrPackageName.reset(new(std::nothrow) DImageLabel("", img, getBodyFrame()));    
    assert(m_ptrPackageName.get() != NULL);
    m_ptrPackageName->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrPackageName->setGeometry(Package_Name_X, Package_Name_Y,
                                  Package_Name_W, Package_Name_H);
    m_ptrPackageName->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPackageName->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrPackageName->setAutoFill(false);
    m_ptrPackageName->registerEvent(DEvent::DnD_Start, true);
    //m_ptrPackageName->registerEvent(DEvent::Drag, true);
    m_ptrPackageName->registerEvent(DEvent::DnD_Release, true);
    m_ptrPackageName->registerEvent(DEvent::Detail, true);

    //Name Edit
    m_ptrNameEdit.reset(new(std::nothrow) DLineEdit(Default_Package_Name, getBodyFrame()));
    assert(m_ptrNameEdit.get() != NULL);
    m_ptrNameEdit->setGeometry(Package_NameEdit_X, Package_NameEdit_Y,
                               Package_NameEdit_W, Package_NameEdit_H);
    m_ptrNameEdit->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNameEdit->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrNameEdit->setEventRoutine(DEvent::Input, this,
                                   (EventRoutine)(&DPackageSetting::onInputMsg));
    m_ptrNameEdit->setAlignment(AlignLeft);

    //Package Path button
    img.load(getResPath() + DPackageSetting_ButtonImg_FileName);
    selImg.load(getResPath() + DPackageSetting_ButtonSelImg_FileName);
    m_ptrPackagePath.reset(new(std::nothrow) DButton("Move Path", img, selImg, getBodyFrame()));
    assert(m_ptrPackagePath.get() != NULL);
    m_ptrPackagePath->setGeometry(Package_Path_X, Package_Path_Y, 
                                  Package_Path_W, Package_Path_H);
    m_ptrPackagePath->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPackagePath->registerEvent(DEvent::DnD_Start, true);
    //m_ptrPackagePath->registerEvent(DEvent::Drag, true);
    m_ptrPackagePath->registerEvent(DEvent::DnD_Release, true);
    m_ptrPackagePath->registerEvent(DEvent::Detail, true);
    m_ptrPackagePath->setEventRoutine(DEvent::Select,
                                      this,
                                      static_cast<EventRoutine>(&DPackageSetting::onSetPath));
    m_ptrPackagePath->setSelected(false);

    //Duplicate package Path button
    m_ptrDupPath.reset(new(std::nothrow) DButton("Duplicate Path", img, selImg, getBodyFrame()));
    assert(m_ptrPackagePath.get() != NULL);
    m_ptrDupPath->setGeometry(Package_DupPath_X, Package_DupPath_Y, 
                              Package_DupPath_W, Package_DupPath_H);
    m_ptrDupPath->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDupPath->registerEvent(DEvent::DnD_Start, true);
    //m_ptrDupPath->registerEvent(DEvent::Drag, true);
    m_ptrDupPath->registerEvent(DEvent::DnD_Release, true);
    m_ptrDupPath->registerEvent(DEvent::Detail, true);
    m_ptrDupPath->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DPackageSetting::onDupPath));
    m_ptrDupPath->setSelected(false);

    //Readable button
    m_ptrReadable.reset(new(std::nothrow) DButton("Readable", img, selImg, getBodyFrame()));
    assert(m_ptrPackagePath.get() != NULL);
    m_ptrReadable->setGeometry(Package_Readable_X, Package_Readable_Y, 
                               Package_Readable_W, Package_Readable_H);
    m_ptrReadable->setBackgroundColor(Duke_Transparent_Color);
    m_ptrReadable->registerEvent(DEvent::DnD_Start, true);
    //m_ptrReadable->registerEvent(DEvent::Drag, true);
    m_ptrReadable->registerEvent(DEvent::DnD_Release, true);
    m_ptrReadable->registerEvent(DEvent::Detail, true);
    m_ptrReadable->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DPackageSetting::onSetReadable));
    m_ptrReadable->setSelected(false);

    //Writeable button
    m_ptrWriteable.reset(new(std::nothrow) DButton("Writeable", img, selImg, getBodyFrame()));
    assert(m_ptrPackagePath.get() != NULL);
    m_ptrWriteable->setGeometry(Package_Writeable_X, Package_Writeable_Y, 
                                Package_Writeable_W, Package_Writeable_H);
    m_ptrWriteable->setBackgroundColor(Duke_Transparent_Color);
    m_ptrWriteable->registerEvent(DEvent::DnD_Start, true);
    //m_ptrWriteable->registerEvent(DEvent::Drag, true);
    m_ptrWriteable->registerEvent(DEvent::DnD_Release, true);
    m_ptrWriteable->registerEvent(DEvent::Detail, true);
    m_ptrWriteable->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSetting::onSetWriteable));
    m_ptrWriteable->setSelected(false);
}

void DPackageSetting::onClose(const DEvent& event)
{
    onMinimize(event);
}

void DPackageSetting::onInputMsg(const DEvent &event)
{
    m_ptrNameEdit->onInputEvent(event);
    m_packageName = m_ptrNameEdit->content();
    m_pPackageSheet->setPackageName(m_packageName);
    m_pPackageSheet->updateAll();
    m_pPackageSheet->repaint(event.getCon());    
}

void DPackageSetting::onSetPath(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            m_ptrPackagePath->setSelected(true);
            pEditor->display(event.getCon());
        }
        else
        {
            m_ptrPackagePath->setSelected(false);
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        m_ptrPackagePath->repaint(event.getCon());        
        return;
    }

    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                     pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    DPackageExplorerPtr ptrEditor(new(std::nothrow) DPackageExplorer(DEditor::BodyModel,
                                                    m_pMainWin, m_pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->initDialog();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(),
                           ExplorerW_InMainWin, ExplorerH_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());
}

void DPackageSetting::onSetReadable(const DEvent &event)
{
    if(m_ptrReadable->isSelected())
    {
        m_ptrReadable->setSelected(false);
    }
    else
    {
        m_ptrReadable->setSelected(true);
    }    

    m_ptrReadable->updateAll();
    m_ptrReadable->repaint(event.getCon());
}

void DPackageSetting::onSetWriteable(const DEvent &event)
{
    if(m_ptrWriteable->isSelected())
    {
        m_ptrWriteable->setSelected(false);
    }
    else
    {
        m_ptrWriteable->setSelected(true);
        m_ptrReadable->setSelected(true);
    }    

    updateAll();
    repaint(event.getCon());
}

void DPackageSetting::onDupPath(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            m_ptrDupPath->setSelected(true);
            pEditor->display(event.getCon());
        }
        else
        {
            m_ptrDupPath->setSelected(false);
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        m_ptrDupPath->repaint(event.getCon());
        return;
    }

    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                     pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    DPackageExplorerPtr ptrEditor(new(std::nothrow) DPackageExplorer(DEditor::BodyModel,
                                                    m_pMainWin, m_pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->initDialog();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(),
                           ExplorerW_InMainWin, ExplorerH_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
