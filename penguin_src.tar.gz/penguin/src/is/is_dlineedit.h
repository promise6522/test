#ifndef DLINEEDIT_H
#define DLINEEDIT_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dframe.h"
#include "is_dtool.h"

class DLineEditCell;

class DLineEdit : public DFrame {
public:
    //ctor & detor
    explicit DLineEdit(DWidget * parent = 0);
    explicit DLineEdit(const std::string &, DWidget * parent = 0);
    virtual ~DLineEdit();

    //set&get methods
    DText text() const;
    void setText(DText &text);
    std::string content() const;
    void setContent(const std::string &content);
    DFont font() const;
    void setFont(const DFont& font);
    AlignmentFlag alignment() const;
    void setAlignment(AlignmentFlag align);
    DColor color() const;
    void setColor(const DColor & color);
    bool isWrap();
    void setWrap(bool isWarp);
    DMargin margin();
    void setMargin(const DMargin&);
    bool localEditable() const;
    void setLocalEditable(bool editable);

    //event handle
    bool event(DEvent *);
    void onInputEvent(const DEvent& rEvent);
        
private:
    DText m_text;

    D_DECLARE_CELL(DLineEdit)
};

const std::string LineEdit_ObjName("LineEdit_Object");

class DLineEditCell : public DFrameCell {
public:
    DLineEditCell();
    virtual ~DLineEditCell();
    
    void init();
    virtual void update();
    
private:
    void saveData(DLineEdit * q, TPlacement *place);

    D_DECLARE_PUBLIC(DLineEdit)
};
      
typedef std::tr1::shared_ptr<DLineEdit>  DLineEditPtr;
typedef std::tr1::shared_ptr<DLineEditCell>  DLineEditCellPtr;

#endif // DLINEEDIT_H 

// vim:set tabstop=4 shiftwidth=4 expandtab:
