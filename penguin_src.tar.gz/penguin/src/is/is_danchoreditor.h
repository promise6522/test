#ifndef DANCHOREDITOR_H
#define DANCHOREDITOR_H

#include <boost/tr1/memory.hpp>

#include "is_ddialog.h"
#include "is_dfunc.h"
#include "is_deditor.h"

class DAnchorEditorCell;

typedef std::vector<DWidgetPtr> ShareWidgets;
typedef ShareWidgets::iterator ShareWidgetIt;
typedef std::vector<DWidgetPtr> ExcWidgets;
typedef ExcWidgets::iterator ExcWidgetIt;

class DAnchorEditor : public DEditor {
public:
    explicit DAnchorEditor(EditorModel model = DialogModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DAnchorEditor(const std::string& title,
            EditorModel model = DialogModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DAnchorEditor();

    // duplicate the acs content from handle
    void duplicateItemsByHandle(const duke_media_handle& hstorage);

    // Init
    void initShareFrame();
    void initExcFrame();
    void initShareExisted();
    void initExcExisted();
    void initAnchorEditor();    

    // reload and generate
    virtual void reload();

    // manage widget in the editor
    DButton * createWidgetForShare(const DPoint &, DWidget *);
    DButton * createWidgetForExc(const DPoint &, DWidget *);
    void updateShareView();
    void updateExcView();
    void setReadonly();
    void setSourceWidget(DWidget * pWidget);
    void updateChildWidgets();
    bool findChildWidgets(DWidget * pWidget);
   

    // Event handle
    void onDnDReleaseShareFrame(const DEvent &event);
    void onDnDReleaseExcFrame(const DEvent &event);
    void onDeleteShare(const DEvent &event);
    void onDeleteExc(const DEvent &event);
    void onActivateBtn(const DEvent &event);
    void onHoverBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);

private:
    void saveShareInfo();
    void saveExcInfo();
    void dumpAnchorInfo();

private:
    DFramePtr m_ptrShareFrame;
    DFramePtr m_ptrExcFrame;
    DWidget* m_pSourceWidget;

    int m_shareLayer;
    int m_excLayer;
    int m_shareLayerHeight;
    int m_excLayerHeight;
    int m_shareRow;
    int m_excRow;

    ShareWidgets m_shareWidgets;
    ExcWidgets m_excWidgets;

    D_DECLARE_CELL(DAnchorEditor)
};

class DAnchorEditorCell : public DDialogCell
{
public:
    DAnchorEditorCell();
    virtual ~DAnchorEditorCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DAnchorEditor)    
};


typedef std::tr1::shared_ptr<DAnchorEditor>  DAnchorEditorPtr;
typedef std::tr1::shared_ptr<DAnchorEditorCell>  DAnchorEditorCellPtr;

const int AnchorEditor_Width = 336;
const int AnchorEditor_Heigth = 448;
const int Default_AnchorEditor_W_InMainWin = AnchorEditor_Width * MAX_COORD / 1366;
const int Default_AnchorEditor_H_InMainWin = AnchorEditor_Heigth * MAX_COORD / 768;

const std::string AnchorEditor_ShareDeclBtn_Filename("decl_origin.png");
const std::string AnchorEditor_ExcDeclBtn_Filename("decl_origin.png");

const std::string AnchorEditor_ObjName("Anchor_Editor");
const int AnchorEditor_Layer = 1000;
const int AnchorEditor_Col_Items = 4;
const int AnchorEditor_Row_Height = 2000;

#endif // DANCHOREDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
