/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_danchoreditor.h"
#include "is_ddecleditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"

DAnchorEditor::DAnchorEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    m_shareLayer = m_excLayer = 0;
    m_shareRow = m_excRow = 0;
    m_excLayerHeight = m_shareLayerHeight = AnchorEditor_Layer;
    setObjectName(AnchorEditor_ObjName);
    assert(pMainWin != NULL);    
    m_pSourceWidget = NULL;
}

DAnchorEditor::DAnchorEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    m_shareLayer = m_excLayer = 0;
    m_shareRow = m_excRow = 0;
    m_excLayerHeight = m_shareLayerHeight = AnchorEditor_Layer;
    setObjectName(AnchorEditor_ObjName);
    assert(pMainWin != NULL);
    m_pSourceWidget = NULL;
}

DAnchorEditor::~DAnchorEditor()
{
}

void DAnchorEditor::duplicateItemsByHandle(const duke_media_handle& hanchor)
{
    if (!hanchor.is_anchor()) {
        assert(!"Invalid anchor handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();

    duke_media_anchor* pAnchorMedia = 
        new(std::nothrow) duke_media_anchor(this->getApplication()->get_host_committer_id(), getApplication()->username());
    pAnchorMedia->copy(hanchor);
    m_ptr = pAnchorMedia;
    m_handle = pAnchorMedia->get_handle();
    assert(m_ptr != NULL);    
}

void DAnchorEditor::reload()
{
    LOG_DEBUG("DAnchorEditor:: reload ......");

    //clear wideget
    for (ShareWidgetIt it = m_shareWidgets.begin(); it != m_shareWidgets.end(); ++it) 
    {
        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget(it->get());
        if(pEditor != NULL)
        {
            m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
            eraseSubEditor(pEditor);        
        }

        m_ptrShareFrame->detachChildWidget(it->get());
    }
    m_shareWidgets.clear();

    for (ExcWidgetIt it = m_excWidgets.begin(); it != m_excWidgets.end(); ++it) 
    {
        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget(it->get());
        if(pEditor != NULL)
        {
            m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
            eraseSubEditor(pEditor);        
        }

        m_ptrExcFrame->detachChildWidget(it->get());
    }
    m_excWidgets.clear();

    // clear
    m_shareLayer = 0;
    m_excLayer = 0;
    m_excLayerHeight = m_shareLayerHeight = AnchorEditor_Layer;

    setMediaByHandle(m_handle);

    duke_media_anchor *pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia) {
        releaseMedia();
        return;
    }
    pAnchorMedia->get_name(m_dukeName);
    pAnchorMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);
 
    // reload media data
    initShareExisted();
    initExcExisted();

    // update
    updateShareView();
    updateExcView();
}

void DAnchorEditor::initAnchorEditor()
{
    duke_media_anchor *pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia) {
        releaseMedia();
        return;
    }
    pAnchorMedia->get_name(m_dukeName);
    pAnchorMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);

    dumpAnchorInfo();

    initShareFrame();
    updateShareView();

    initExcFrame();
    updateExcView();
}

void DAnchorEditor::initExcFrame()
{
    m_ptrExcFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrExcFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrExcFrame.get());
    m_ptrExcFrame->setGeometry(MAX_COORD/2, MIN_COORD, MAX_COORD/2, MAX_COORD);
    m_ptrExcFrame->setHideProperty(false);
    m_ptrExcFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrExcFrame->setAutoFill(false);
    m_ptrExcFrame->setFrameStyle(DFrame::Panel);

    // set pass though
    m_ptrExcFrame->registerEvent(DEvent::Detail, true);
    m_ptrExcFrame->registerEvent(DEvent::Select, true);
    m_ptrExcFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrExcFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrExcFrame->registerEvent(DEvent::DnD_Start, true);
    
    //m_ptrExcFrame->registerEvent(DEvent::Drag);
    m_ptrExcFrame->registerEvent(DEvent::DnD_Release);
    m_ptrExcFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onDnDReleaseExcFrame)); 

    initExcExisted();
}

void DAnchorEditor::initExcExisted()
{
    if (!m_ptr || !m_ptr->is_anchor()) {
        releaseMedia();
        return;
    }

    duke_media_handle_vector decls;
    dynamic_cast<duke_media_anchor *>(m_ptr)->get_declaration(decls, Excl);

    for (duke_media_handle_const_iterator it = decls.begin(); 
            it != decls.end(); 
            ++it) {

        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, (*it),
                             AnchorEditor_ExcDeclBtn_Filename);
        DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                    declImg,
                    m_ptrExcFrame.get()));
        ptrDeclButton->setFocusAttr(true);
        ptrDeclButton->registerEvent(DEvent::Activate);
        ptrDeclButton->registerEvent(DEvent::Hover);
        ptrDeclButton->registerEvent(DEvent::PassingOut);
        ptrDeclButton->registerEvent(DEvent::Delete);
        ptrDeclButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onDeleteExc)); 
        ptrDeclButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onActivateBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onHoverBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onPassingOutBtn)); 
        ptrDeclButton->setMediaByHandle(*it);

        m_excWidgets.push_back(ptrDeclButton);
    }
}

void DAnchorEditor::initShareFrame()
{
    m_ptrShareFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrShareFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrShareFrame.get());

    m_ptrShareFrame->setGeometry(MIN_COORD, MIN_COORD, MAX_COORD/2, MAX_COORD);

    m_ptrShareFrame->setHideProperty(false);
    m_ptrShareFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrShareFrame->setAutoFill(false);
    m_ptrShareFrame->setFrameStyle(DFrame::Panel);

    // set pass though
    m_ptrShareFrame->registerEvent(DEvent::Detail, true);
    m_ptrShareFrame->registerEvent(DEvent::Select, true);
    m_ptrShareFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrShareFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrShareFrame->registerEvent(DEvent::DnD_Start, true);
    
    //m_ptrShareFrame->registerEvent(DEvent::Drag);
    m_ptrShareFrame->registerEvent(DEvent::DnD_Release);
    m_ptrShareFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onDnDReleaseShareFrame)); 

    initShareExisted();
}

void DAnchorEditor::initShareExisted()
{
    if (!m_ptr || !m_ptr->is_anchor()) {
        releaseMedia();
        return;
    }

    duke_media_handle_vector decls;
    dynamic_cast<duke_media_anchor *>(m_ptr)->get_declaration(decls, Normal);

    for (duke_media_handle_const_iterator it = decls.begin(); 
            it != decls.end(); 
            ++it) {

        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, *it,
                             AnchorEditor_ShareDeclBtn_Filename);
        DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                    declImg,
                    m_ptrShareFrame.get()));
        ptrDeclButton->setFocusAttr(true);
        ptrDeclButton->registerEvent(DEvent::Activate);
        ptrDeclButton->registerEvent(DEvent::Hover);
        ptrDeclButton->registerEvent(DEvent::PassingOut);
        ptrDeclButton->registerEvent(DEvent::Delete);
        ptrDeclButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onDeleteShare)); 
        ptrDeclButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onActivateBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onHoverBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DAnchorEditor::onPassingOutBtn)); 
        ptrDeclButton->setMediaByHandle(*it);

        m_shareWidgets.push_back(ptrDeclButton);
    }
}

void DAnchorEditor::updateChildWidgets()
{
    for (ShareWidgetIt it = m_shareWidgets.begin(); it != m_shareWidgets.end(); ++it) {
        m_ptrShareFrame->detachChildWidget(it->get());
    }
    m_shareWidgets.clear();

    for (ExcWidgetIt it = m_excWidgets.begin(); it != m_excWidgets.end(); ++it) {
        m_ptrExcFrame->detachChildWidget(it->get());
    }
    m_excWidgets.clear();

    m_shareLayer = 0;
    m_excLayer = 0;
    m_excLayerHeight = m_shareLayerHeight = AnchorEditor_Layer;

    duke_media_anchor *pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia) {
        releaseMedia();
        return;
    }

    initShareExisted();
    updateShareView();

    initExcExisted();
    updateExcView();
}

bool DAnchorEditor::findChildWidgets(DWidget * pWidget)
{
    for (ShareWidgetIt it = m_shareWidgets.begin(); it != m_shareWidgets.end(); ++it) {
        if (pWidget->getMediaHandle() == it->get()->getMediaHandle())
            return true;
    }

    for (ExcWidgetIt it = m_excWidgets.begin(); it != m_excWidgets.end(); ++it) {
        if (pWidget->getMediaHandle() == it->get()->getMediaHandle())
            return true;
    }

    return false;
}

void DAnchorEditor::setSourceWidget(DWidget * pWidget)
{
    if (NULL != pWidget)
        m_pSourceWidget = pWidget;
}

void DAnchorEditor::updateExcView()
{
    m_excRow = (m_excWidgets.size() % AnchorEditor_Col_Items) ?
            (m_excWidgets.size() / AnchorEditor_Col_Items + 1) :
            (m_excWidgets.size() / AnchorEditor_Col_Items); 
    if (AnchorEditor_Row_Height*m_excRow > MAX_COORD)
        m_excLayerHeight = MAX_COORD / m_excRow;
    int colWidth = MAX_COORD / AnchorEditor_Col_Items;

    int rcnt = 0;
    int ccnt = 0;
    for (ExcWidgetIt it = m_excWidgets.begin();
            it != m_excWidgets.end();
            ++it) {
        DWidget * pDecl = (*it).get();;
        assert(pDecl != NULL);
        pDecl->setGeometry(ccnt*colWidth + 100,
                rcnt*m_excLayerHeight + 100,
                colWidth - 200,
                m_excLayerHeight - 200);

        ccnt++;
        if (ccnt == AnchorEditor_Col_Items) {
            rcnt++;
            ccnt = 0;
        }
    }
}

DButton * DAnchorEditor::createWidgetForExc(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc || pSrc->getMedia());

    DImage declImg;
    declImg.setRelation(DImage::KeepSmall);
    setImageDataByHandle(declImg, pSrc->getMediaHandle(),
                        AnchorEditor_ExcDeclBtn_Filename);

    if (AnchorEditor_Layer*m_excLayer > MAX_COORD) 
        m_excLayerHeight = MAX_COORD / m_excLayer;

    // create new declaration 
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                declImg,
                m_ptrExcFrame.get()));
    ptrItemButton->setFocusAttr(true);
    ptrItemButton->registerEvent(DEvent::Activate);
    ptrItemButton->registerEvent(DEvent::Hover);
    ptrItemButton->registerEvent(DEvent::PassingOut);
    ptrItemButton->registerEvent(DEvent::Delete);
    ptrItemButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onDeleteExc)); 
    ptrItemButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onActivateBtn)); 
    ptrItemButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onHoverBtn)); 
    ptrItemButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onPassingOutBtn)); 

    ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());
    dynamic_cast<duke_media_anchor *>(m_ptr)->add_declaration(
            pSrc->getMediaHandle(), Excl);
    m_excWidgets.push_back(ptrItemButton);

    // update all layers
    updateExcView();

    return ptrItemButton.get();
}

void DAnchorEditor::onDnDReleaseExcFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DAnchorEditor::onDnDReleaseExcFrame");
    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DAnchorEditor* pAnchorEditor = dynamic_cast<DAnchorEditor *>(pObject);
    if (NULL != pAnchorEditor) {
        return;
    }

    // only receive duke declaration and implementation
    // test
    if (!pSrcWidget->getMedia() || 
            (!pSrcWidget->getMedia()->is_declaration())) 
        return;

    // widget is only from container editor
    DWidget * pSource = dynamic_cast<DWidget *>(pSrcWidget->parent());
    if (NULL == m_pSourceWidget
            || NULL == pSource 
            || m_pSourceWidget != pSource)
        return;

    duke_media_handle hcontainer = duke_media_handle_null;
    dynamic_cast<duke_media_anchor *>(m_ptr)->get_hcontainer(hcontainer);
    duke_media_container container(hcontainer);
    duke_media_handle hdecl = pSrcWidget->getMediaHandle();

    duke_media_handle_vector vanchor;
    container.get_anchor(vanchor);
    for (duke_media_handle_iterator it = vanchor.begin();
            it != vanchor.end();
            ++it) {
        //'8' determinate which construct func will to be used
        duke_media_anchor anchorItem(*it);

        // check if the widget has been in exc of other anchors
        if (anchorItem.find_exdeclaration(hdecl))
            return;

        // check if the widget has been in share of other anchors
        // if so, delete it from other anchors.
        if (anchorItem.find_declaration(hdecl))
            return;
    }

    // set dirty
    m_isModified = true;

    // check if the widget has been in share
    if (dynamic_cast<duke_media_anchor *>(m_ptr)->find_declaration(pSrcWidget->getMediaHandle()))
        dynamic_cast<duke_media_anchor *>(m_ptr)->del_declaration(pSrcWidget->getMediaHandle(), Normal);

    // only add new layer for new duke declaration 
    DPoint pos = event.getEventPosition();
    if (pos.y()/m_excLayerHeight >= m_excLayer)
        m_excLayer++;

    // create widget for exclusive declaration 
    createWidgetForExc(event.getEventPosition(), pSrcWidget);

    // add exclusive for container
    container.add_excldeclaration(pSrcWidget->getMediaHandle(), getMediaHandle());

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DAnchorEditor::updateShareView()
{
    m_shareRow = (m_shareWidgets.size() % AnchorEditor_Col_Items) ?
            (m_shareWidgets.size() / AnchorEditor_Col_Items + 1) :
            (m_shareWidgets.size() / AnchorEditor_Col_Items); 
    if (AnchorEditor_Row_Height*m_shareRow > MAX_COORD)
        m_shareLayerHeight = MAX_COORD / m_shareRow;
    int colWidth = MAX_COORD / AnchorEditor_Col_Items;

    int rcnt = 0;
    int ccnt = 0;
    for (ShareWidgetIt it = m_shareWidgets.begin();
            it != m_shareWidgets.end();
            ++it) {
        DWidget * pDecl = (*it).get();;
        assert(pDecl != NULL);
        pDecl->setGeometry(ccnt*colWidth + 100,
                rcnt*m_shareLayerHeight + 100,
                colWidth - 200,
                m_shareLayerHeight - 200);

        ccnt++;
        if (ccnt == AnchorEditor_Col_Items) {
            rcnt++;
            ccnt = 0;
        }
    }
}

DButton * DAnchorEditor::createWidgetForShare(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc || pSrc->getMedia());

    DImage declImg;
    declImg.setRelation(DImage::KeepSmall);
    setImageDataByHandle(declImg, pSrc->getMediaHandle(),
                        AnchorEditor_ShareDeclBtn_Filename);

    if (AnchorEditor_Layer*m_shareLayer > MAX_COORD) 
        m_shareLayerHeight = MAX_COORD / m_shareLayer;

    // create new declaration or implementation
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                declImg,
                m_ptrShareFrame.get()));
    ptrItemButton->setFocusAttr(true);
    ptrItemButton->registerEvent(DEvent::Activate);
    ptrItemButton->registerEvent(DEvent::Hover);
    ptrItemButton->registerEvent(DEvent::PassingOut);
    ptrItemButton->registerEvent(DEvent::Delete);
    ptrItemButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onDeleteShare)); 
    ptrItemButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onActivateBtn)); 
    ptrItemButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onHoverBtn)); 
    ptrItemButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DAnchorEditor::onPassingOutBtn)); 

    ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());
    dynamic_cast<duke_media_anchor *>(m_ptr)->add_declaration(
            pSrc->getMediaHandle(), Normal);
    m_shareWidgets.push_back(ptrItemButton);
    // update all layers
    updateShareView();

    return ptrItemButton.get();
}

void DAnchorEditor::onDnDReleaseShareFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DAnchorEditor::onDnDReleaseShareFrame");

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DAnchorEditor* pAnchorEditor = dynamic_cast<DAnchorEditor *>(pObject);
    if (NULL != pAnchorEditor) {
        return;
    }

    // only receive duke declaration 
    if (!pSrcWidget->getMedia() || 
            (!pSrcWidget->getMedia()->is_declaration())) 
        return;

    // widget is only from container editor
    DWidget * pSource = dynamic_cast<DWidget *>(pSrcWidget->parent());
    if (NULL == m_pSourceWidget
            || NULL == pSource 
            || m_pSourceWidget != pSource)
        return;

    // check if the widget has been in exc of other anchors
    duke_media_handle hcontainer = duke_media_handle_null;
    dynamic_cast<duke_media_anchor *>(m_ptr)->get_hcontainer(hcontainer);
    duke_media_container container(hcontainer);
    duke_media_handle hdecl = pSrcWidget->getMediaHandle();

    duke_media_handle_vector vanchor;
    container.get_anchor(vanchor);
    for (duke_media_handle_iterator it = vanchor.begin();
            it != vanchor.end();
            ++it) {
        //'8' determinate which construct func will to be used
        duke_media_anchor anchorItem(*it);

        // check if the widget has been in exc of other anchors
        if (anchorItem.find_exdeclaration(hdecl))
            return;
    }

    // check if the widget has been in share
    if (dynamic_cast<duke_media_anchor *>(m_ptr)->find_declaration(pSrcWidget->getMediaHandle()))
        return;

    // set dirty
    m_isModified = true;

    // only add new layer for new duke declaration 
    DPoint pos = event.getEventPosition();
    if (pos.y()/m_shareLayerHeight >= m_shareLayer)
        m_shareLayer++;

    // create widget for share declaration 
    createWidgetForShare(event.getEventPosition(), pSrcWidget);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DAnchorEditor::onDeleteShare(const DEvent &event)
{
    std::cout << "--------------DAnchorEditor::onDeleteShare" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    // set dirty
    m_isModified = true;

    for (ShareWidgetIt it = m_shareWidgets.begin(); 
            it != m_shareWidgets.end(); 
            ++it) {
        if (it->get() == pSrcWidget) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->get());
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrShareFrame->detachChildWidget(it->get());
            dynamic_cast<duke_media_anchor *>(m_ptr)->del_declaration(
                    it->get()->getMediaHandle(), Normal);
            m_shareWidgets.erase(it);
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    // repaint
    updateShareView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DAnchorEditor::onDeleteExc(const DEvent &event)
{
    std::cout << "--------------DAnchorEditor::onDeleteExc" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    // set dirty
    m_isModified = true;

    for (ExcWidgetIt it = m_excWidgets.begin(); 
            it != m_excWidgets.end(); 
            ++it) {
        if (it->get() == pSrcWidget) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->get());
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrExcFrame->detachChildWidget(it->get());
            dynamic_cast<duke_media_anchor *>(m_ptr)->del_declaration(
                    it->get()->getMediaHandle(), Excl);

            // delete it from exc in container
            duke_media_handle hcontainer = duke_media_handle_null;
            dynamic_cast<duke_media_anchor *>(m_ptr)->get_hcontainer(hcontainer);
            duke_media_container container(hcontainer);
            container.del_excldeclaration(it->get()->getMediaHandle());

            m_excWidgets.erase(it);
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    // repaint
    updateExcView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DAnchorEditor::onActivateBtn(const DEvent &event)
{
    std::cout << "--------------DAnchorEditor::onActivateBtn" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide()) {
            pEditor->display(event.getCon());
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        
        if(pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        return;
    }

    if (pSrcWidget->getMedia()->is_declaration()) {

        // Create new DeclEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        DDeclEditorPtr ptrEditor(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                    DEditor::PanelModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        ptrEditor->initDialog();
        insertSubEditor(pSrcWidget, ptrEditor);

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_DeclEditor_W_InMainWin, 
                Default_DeclEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder()- 1);

        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

        ptrEditor->initDeclEditor();

        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    } 

    //synchronize 
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DAnchorEditor::onHoverBtn(const DEvent &event)
{
    std::cout << "--------------DAnchorEditor::onHoverBtn" << std::endl;

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip)) {
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    } else {
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    }
}

void DAnchorEditor::onPassingOutBtn(const DEvent &event)
{
    std::cout << "--------------DAnchorEditor::onPassingOut" << std::endl;

    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DAnchorEditor::setReadonly()
{
    //DEditor::setReadonly();

    //m_ptrShareFrame->unRegisterEvent(DEvent::Drag);
    //m_ptrExcFrame->unRegisterEvent(DEvent::Drag);
    for (ShareWidgetIt it = m_shareWidgets.begin(); it != m_shareWidgets.end(); ++it) {
        if (NULL != it->get()) {
            it->get()->unRegisterEvent(DEvent::Activate);
        }
    }

    for (ExcWidgetIt it = m_excWidgets.begin(); it != m_excWidgets.end(); ++it) {
        if (NULL != it->get()) {
            it->get()->unRegisterEvent(DEvent::Activate);
        }
    }
}

void DAnchorEditor::saveShareInfo()
{
    duke_media_anchor* pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia)
        return;

    // save share
    for (ShareWidgetIt it = m_shareWidgets.begin(); it != m_shareWidgets.end(); ++it) {
        DWidget * pDeclWidget = it->get();
        if(pDeclWidget == NULL)
            continue;

        duke_media_handle hdecl = pDeclWidget->getMediaHandle();

        if (hdecl == duke_media_handle_null)
            continue;

        pAnchorMedia->add_declaration(hdecl, Normal);        
    }
}

void DAnchorEditor::saveExcInfo()
{
    duke_media_anchor* pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia)
        return;

    // save share
    for (ExcWidgetIt it = m_excWidgets.begin(); it != m_excWidgets.end(); ++it) {
        DWidget * pDeclWidget = it->get();
        if(pDeclWidget == NULL)
            continue;

        duke_media_handle hdecl = pDeclWidget->getMediaHandle();

        if (hdecl == duke_media_handle_null)
            continue;

        pAnchorMedia->add_declaration(hdecl, Excl);        
    }
}

void DAnchorEditor::dumpAnchorInfo()
{
    std::cout<<"==================================="<<std::endl;

    duke_media_anchor* pAnchorMedia = dynamic_cast<duke_media_anchor *>(m_ptr);
    if (NULL == pAnchorMedia) {
        std::cout<<"Error: No duke media."<<std::endl;
        std::cout<<"==================================="<<std::endl;
        return;
    }

    //dump name & icon
    std::string name;
    std::string icon;
    pAnchorMedia->get_name(name);
    pAnchorMedia->get_icon(icon);
    std::cout<<"Anchor name = "<<name<<std::endl
             <<"Anchor icon = "<<toHexString(icon)<<std::endl;

    //dump share 
    duke_media_handle_vector hsharedecls;
    pAnchorMedia->get_declaration(hsharedecls, Normal);
    std::cout<<"\nthe size of share declaration in anchor = "<<hsharedecls.size()<<std::endl;
    for (size_t i = 0; i < hsharedecls.size(); ++i) {
        std::string declName;
        if(!duke_media_get_name(hsharedecls[i], declName))
            continue;

        std::cout<<"\t("<<declName<<") "<<std::endl;
    }

    // dump exc
    duke_media_handle_vector hexcdeclss;
    pAnchorMedia->get_declaration(hexcdeclss, Excl);
    std::cout<<"\nthe size of exclusive declaration in anchor = "<<hexcdeclss.size()<<std::endl;
    for (size_t i = 0; i < hexcdeclss.size(); ++i) {
        std::string declName;
        if(!duke_media_get_name(hexcdeclss[i], declName))
            continue;

        std::cout<<"\t("<<declName<<") "<<std::endl;
    }
}

DAnchorEditorCell::DAnchorEditorCell()
{
}

DAnchorEditorCell::~DAnchorEditorCell()
{
}

void DAnchorEditorCell::init()
{
}

void DAnchorEditorCell::update()
{
    // call parent class at first
    DDialogCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
