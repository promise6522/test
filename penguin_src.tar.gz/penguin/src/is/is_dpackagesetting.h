/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/
#ifndef DPACKAGE_SETTING_H
#define DPACKAGE_SETTING_H

#include "is_ddialog.h"
#include "is_dmainwin.h"

class DPackageSheet;

class DPackageSetting : public DEditor
{
public:
    explicit DPackageSetting(const std::string& title, int model = PanelModel, 
                             DPackageSheet *pPackageSheet = NULL, DMainWin *pMainWin = NULL, 
                             DWidget * parent = 0);
    virtual ~DPackageSetting();
    
    //Init    
    virtual void initDialog();

protected:
    void onInputMsg(const DEvent &event);
    void onSetPath(const DEvent &event); 
    void onSetReadable(const DEvent &event);    
    void onSetWriteable(const DEvent &event);
    void onDupPath(const DEvent &event);

    virtual void onClose(const DEvent& event);    
private:
    //Package Name
    DImageLabelPtr m_ptrPackageName;
    DLineEditPtr m_ptrNameEdit;
    std::string m_packageName;

    //Package Path
    DButtonPtr m_ptrPackagePath;
    DButtonPtr m_ptrDupPath;

    //Showing Package Path
    DLabelPtr m_ptrShowPath;

    //Permissions
    DButtonPtr m_ptrReadable;
    DButtonPtr m_ptrWriteable;

    //DPackageSetting point
    DPackageSheet *m_pPackageSheet;
};

typedef std::tr1::shared_ptr<DPackageSetting>  DPackageSettingPtr;

const std::string DPackageSetting_ObjName("Package_Setting");
const std::string DPackageSetting_TitleName("Package Setting");
const std::string Default_Package_Name("Default Package");

//resource
const std::string DPackageSetting_NameImg_FileName("editor_name.png");
const std::string DPackageSetting_ButtonImg_FileName("package_button.png");
const std::string DPackageSetting_ButtonSelImg_FileName("package_button_sel.png");

//geometry pixel
const int Default_PackageSetting_W_Pixel = 336;
const int Default_PackageSetting_H_Pixel = 176;

const int Package_Name_X_Pixel = 92;
const int Package_Name_Y_Pixel = 23;
const int Package_Name_W_Pixel = 151;
const int Package_Name_H_Pixel = 20;

const int Package_NameEdit_X_Pixel = 136;
const int Package_NameEdit_Y_Pixel = 23;
const int Package_NameEdit_W_Pixel = 151;
const int Package_NameEdit_H_Pixel = 20;

const int Package_Path_X_Pixel = 12;
const int Package_Path_Y_Pixel = 53;
const int Package_Path_W_Pixel = 151;
const int Package_Path_H_Pixel = 20;

const int Package_DupPath_X_Pixel = 172;
const int Package_DupPath_Y_Pixel = 53;
const int Package_DupPath_W_Pixel = 151;
const int Package_DupPath_H_Pixel = 20;

const int Package_ShowPath_X_Pixel = 14;
const int Package_ShowPath_Y_Pixel = 53;
const int Package_ShowPath_W_Pixel = 309;
const int Package_ShowPath_H_Pixel = 80;

const int Package_Readable_X_Pixel = 14;
const int Package_Readable_Y_Pixel = 143;
const int Package_Readable_W_Pixel = 151;
const int Package_Readable_H_Pixel = 20;

const int Package_Writeable_X_Pixel = 172;
const int Package_Writeable_Y_Pixel = 143;
const int Package_Writeable_W_Pixel = 151;
const int Package_Writeable_H_Pixel = 20;

//geometry relative
const int Default_PackageSetting_W = 336*MAX_COORD/1366;
const int Default_PackageSetting_H = 176*MAX_COORD/768 ;

const int Package_Name_X = Package_Name_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Name_Y = Package_Name_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;
const int Package_Name_W = Package_Name_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Name_H = Package_Name_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;

const int Package_NameEdit_X = Package_NameEdit_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel; 
const int Package_NameEdit_Y = Package_NameEdit_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel; 
const int Package_NameEdit_W = Package_NameEdit_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel; 
const int Package_NameEdit_H = Package_NameEdit_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel; 

const int Package_Path_X = Package_Path_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Path_Y = Package_Path_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;
const int Package_Path_W = Package_Path_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Path_H = Package_Path_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;

const int Package_DupPath_X = Package_DupPath_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_DupPath_Y = Package_DupPath_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;
const int Package_DupPath_W = Package_DupPath_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_DupPath_H = Package_DupPath_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;

const int Package_ShowPath_X = Package_ShowPath_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_ShowPath_Y = Package_ShowPath_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;
const int Package_ShowPath_W = Package_ShowPath_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_ShowPath_H = Package_ShowPath_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;

const int Package_Readable_X = Package_Readable_X_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Readable_Y = Package_Readable_Y_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;
const int Package_Readable_W = Package_Readable_W_Pixel*MAX_COORD/Default_PackageSetting_W_Pixel;
const int Package_Readable_H = Package_Readable_H_Pixel*MAX_COORD/Default_PackageSetting_H_Pixel;

const int Package_Writeable_X = Package_Writeable_X_Pixel*MAX_COORD
                                /Default_PackageSetting_W_Pixel;
const int Package_Writeable_Y = Package_Writeable_Y_Pixel*MAX_COORD
                                /Default_PackageSetting_H_Pixel;
const int Package_Writeable_W = Package_Writeable_W_Pixel*MAX_COORD
                                /Default_PackageSetting_W_Pixel;
const int Package_Writeable_H = Package_Writeable_H_Pixel*MAX_COORD
                                /Default_PackageSetting_H_Pixel;

#endif /* DPACKAGE_SETTING_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
