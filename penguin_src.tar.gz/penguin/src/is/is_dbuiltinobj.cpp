/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei 
**
****************************************************************************/

#include "is_dbuiltinobj.h"
#include "is_dfunc.h"
#include "is_dobjicon.h"

DBuiltinObj::DBuiltinObj(DWidget *parent, WFlags f)
    : DWidget(*new DBuiltinObjCell, parent, f)
{
    setObjectName(DBuiltinObj_ObjName);    
    d_func()->init();

    initView();
}

DBuiltinObj::DBuiltinObj(const duke_media_handle & h_obj,
        DWidget *parent, WFlags f)
    : DWidget(*new DBuiltinObjCell, parent, f)
{
    setObjectName(DBuiltinObj_ObjName);    
    d_func()->init();
    setMediaByHandle(h_obj);
    initView();
}

DBuiltinObj::~DBuiltinObj()
{
}

void DBuiltinObj::initView()
{
    // register event
    registerEvent(DEvent::Select);
    //registerEvent(DEvent::Drag, true);
    registerEvent(DEvent::Delete);
    setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DBuiltinObj::onDestroy));
    registerEvent(DEvent::DnD_Release);
    setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DBuiltinObj::onDnDRelease));
    setDisplayOrder(BuiltinObj_Default_Display_Order);

    // init port
    m_ptrPort.reset(new(std::nothrow) DPort(this));
    m_ptrPort->setDirection(DPort::Left);
    m_ptrPort->setBackgroundColor(BuiltinObj_Port_Background);
    m_ptrPort->setHighlightColor(BuiltinObj_Port_Highlight);
    m_ptrPort->registerEvent(DEvent::Hover);
    m_ptrPort->registerEvent(DEvent::PassingOut);
    m_ptrPort->registerEvent(DEvent::DnD_Start);
    m_ptrPort->setEventRoutine(DEvent::DnD_Start,
            this,
            static_cast<EventRoutine>(&DBuiltinObj::onPortDnDStart));
    m_ptrPort->registerEvent(DEvent::DnD_Release, true);
    m_ptrPort->setGeometry(MIN_COORD, 2500, BuiltinObj_Port_Width, 7500);  
    m_ptrPort->setDisplayOrder(BuiltinObj_Port_Display_Order);

    // init label
    m_ptrBody.reset(new(std::nothrow) DLabel(this));
    m_ptrBody->rframeRect().setRadius(2000);
    m_ptrBody->setBackgroundColor(BuiltinObj_Body_Background);
    m_ptrBody->setFrameBorderColor(BuiltinObj_Body_Background);
    m_ptrBody->registerEvent(DEvent::DnD_Release, true);
    m_ptrBody->setGeometry(BuiltinObj_Port_Width, MIN_COORD, 
            MAX_COORD - BuiltinObj_Port_Width, MAX_COORD); 
    m_ptrBody->setDisplayOrder(BuiltinObj_Default_Display_Order);
}

void DBuiltinObj::initMedia()
{
    assert(m_ptr && m_ptr->is_object()); 
    duke_media_handle hif;
    if (duke_media_get_interface_by_object(getMediaHandle(), hif))  
        m_ptrPort->setMediaByHandle(hif);
}

void DBuiltinObj::updateEdgePos()
{
    for (EdgeIt it = m_outEdges.begin(); it != m_outEdges.end(); it++) {
        DRect objRect = geometry();
        DRect portRect = m_ptrPort->geometry();
        DPoint eP(objRect.x() + (portRect.right() * objRect.width()) / MAX_COORD, 
                objRect.y() + (portRect.bottom() * objRect.height()) / MAX_COORD);
        it->get()->setSourceParentCoord(eP); 
    }

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    pParent->updateAll();
}

DEdgePtr DBuiltinObj::createEdge()
{
    DWidget * pParent = dynamic_cast<DWidget *>(parent());

    DEdgePtr eItem(new(std::nothrow) DEdge(pParent));
    assert(eItem);

    // Register Events
    eItem->registerEvent(DEvent::DnD_Start);

    // Calculate the coordinate of the source port linked by current edge 
    DRect objRect = geometry();
    DRect portRect = m_ptrPort->geometry();
    int eX = objRect.x() + (portRect.right() * objRect.width()) / MAX_COORD;
    int eY = objRect.y() + (portRect.bottom() * objRect.height()) / MAX_COORD;
    DPoint eP(eX, eY);
    eItem->initGeometry(eX, eY, 200, 200);
    eItem->setSourceParentCoord(eP);
    eItem->setSourceWidget(m_ptrPort.get());
    eItem->setDisplayOrder(BuiltinObj_Edge_Display_Order);

    m_outEdges.push_back(eItem);
    
    return eItem;
}

void DBuiltinObj::deleteEdge(DEdge *pEdge)
{
    for (EdgeIt it = m_outEdges.begin(); it != m_outEdges.end(); ++it) {
        if (pEdge != it->get())
            continue;

        // Delete the edge from the relative func
        if (NULL != pEdge->targetWidget()) {
            DPort * pTargetPort = dynamic_cast<DPort *>(pEdge->targetWidget()); 
            assert(NULL != pTargetPort);
            dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, pEdge);
        }

        // Delete the edge from current objiconc
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        pParent->detachChildWidget(pEdge);
        
        it->reset();
        m_outEdges.erase(it);
        break;
    }
}

void DBuiltinObj::clearAllEdges()
{
    for (EdgeIt it = m_outEdges.begin(); it != m_outEdges.end(); ++it) {
        if (NULL == it->get())  
            continue;

        // Delete the edge from input port
        if (NULL != it->get()->targetWidget()) {
            DPort * pTargetPort = dynamic_cast<DPort *>(it->get()->targetWidget()); 
            assert(NULL != pTargetPort);
            dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, it->get());
        }

        // Delete the edge from current output port
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        pParent->detachChildWidget(it->get());
    }

    m_outEdges.clear();
}

DEdgePtr DBuiltinObj::getSuspendEdge()
{
    for (EdgeIt it = m_outEdges.begin(); it != m_outEdges.end(); ++it) {
        if (NULL != it->get() && NULL == it->get()->targetWidget())  
            return (*it);
    }

    return DEdgePtr();
}

EdgeItems DBuiltinObj::outEdges() 
{
    return m_outEdges;
}

bool DBuiltinObj::checkPos(const DPoint &p, int len)
{
    for (EdgeIt it = m_outEdges.begin(); it != m_outEdges.end(); it++) {
        if (NULL == it->get() || NULL == it->get()->targetWidget())
            continue;

        // Compare with the relative func linked by the same edge.
        DFunc* pTargetFunc = dynamic_cast<DFunc *>(it->get()->targetWidget()->parent());
        if (NULL != pTargetFunc) {
            if (pTargetFunc->geometryY() <= p.y() + len)
                return false;
        } 
    }

    return true;
}

void DBuiltinObj::connect(DFunc *pFunc, unsigned int idx)
{
    if (NULL == pFunc || idx >= pFunc->inPortsSize())
        return;

    // create edge and set its source coordinate
    DEdgePtr currEdge = createEdge();
    if (!currEdge)
        return; 

    // set target coordinate of current edge
    pFunc->setEdgeToInPort(currEdge, idx);
}

void DBuiltinObj::onPortDnDStart(const DEvent &rEvent)
{
    LOG_DEBUG("--------------DObjEditor::onPortDnDStart");

    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcPort = dynamic_cast<DPort *>(pObject); 
    if (pSrcPort == NULL || pSrcPort != m_ptrPort.get())
        return;

    // create a new edge
    createEdge();

    // Create a edge,if current port is not linked by any edge.
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DBuiltinObj::onDestroy(const DEvent &rEvent)
{
    LOG_DEBUG("--------------DObjEditor::onDestroy");

    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DBuiltinObj* pObj = dynamic_cast<DBuiltinObj *>(pObject); 
    if (pObj == NULL)
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(pObj->parent());

    pObj->clearAllEdges();
    pParent->detachChildWidget(pObj);

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DBuiltinObj::onDnDRelease(const DEvent &rEvent)
{
    LOG_DEBUG("--------------DObjEditor::onDnDRelease");

    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[1]);
    DPort* pSrcPort = dynamic_cast<DPort *>(pObject); 
    if (pSrcPort == NULL || pSrcPort != m_ptrPort.get())
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(parent());

    // If the parent of output port is func
    DFunc * pSrcFunc = dynamic_cast<DFunc *>(pSrcPort->parent());
    if (NULL != pSrcFunc) {
        DEdgePtr ptrCurrE = pSrcFunc->getSuspendEdge(pSrcPort);
        if (!ptrCurrE )
            return;

        pSrcFunc->deleteEdgeFromOutPort(pSrcPort, ptrCurrE.get());

        pParent->updateAll();
        pParent->repaint(rEvent.getCon());
        return;
    }

    // If the parent of output port is object
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon* >(pSrcPort->parent());
    if (NULL != pSrcObj) {
        DEdgePtr ptrCurrE = pSrcObj->getSuspendEdge();
        if (!ptrCurrE)
            return;

        pSrcObj->deleteOutEdge(ptrCurrE.get());

        pParent->updateAll();
        pParent->repaint(rEvent.getCon());
        return;
    }
}

/***************************************************************************
 * DBuiltinObjCell member functions
 **************************************************************************/
DBuiltinObjCell::DBuiltinObjCell()
{
}

DBuiltinObjCell::~DBuiltinObjCell()
{
}

void DBuiltinObjCell::init()
{
}

void DBuiltinObjCell::update()
{
    DWidgetCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
