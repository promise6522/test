/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>
#include <pthread.h>
#include <signal.h>

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>

#include "ac_global.h"
#include "nb_configuration.h"
#include "nb_net_tool.h"
#include "nb_server.h"
#include "ac_framework.h"
#include "nb_db_manager.h"
//#include "ac_object_db_impl.h"

int main(int argc, char* argv[])
{
    nb_configuration::instance().parse_option(argc, argv);
    nb_configuration::instance().dump_configuration();

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    // Start nb_db_manager
    nb_db_manager::instance().run();

    //Start ac_framework
    ac_framework framework(nb_configuration::instance().get_actor_thread_pool(), 
                           nb_configuration::instance().get_is_statistics(), 
                           nb_configuration::instance().get_statistics_interval());
    framework.init_framework(nb_configuration::instance().get_is_gc(),
                             nb_configuration::instance().get_gc_size(),
                             nb_configuration::instance().get_gc_rate());
    framework.run();

    // Run server in background thread.
    nb_server server(nb_getifaddr_v4(),
                     nb_configuration::instance().get_port_number(),
                     nb_configuration::instance().get_socket_thread_pool());
    boost::thread t(boost::bind(&nb_server::run, &server));

    // Wait for signal indicating time to shut down.
    sigset_t wait_mask;
    sigemptyset(&wait_mask);
    sigaddset(&wait_mask, SIGINT);
    sigaddset(&wait_mask, SIGQUIT);
    sigaddset(&wait_mask, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
    int sig = 0;
    sigwait(&wait_mask, &sig);   

    //Stop the server
    nb_db_manager::instance().stop();
    framework.stop();
    server.stop();
    t.join();

    return 0;    
}
