#ifndef __EXECUTION_IMPL_STRING_H
#define __EXECUTION_IMPL_STRING_H

#include "execution_base.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_time.h"
#include "ac_object/obj_impl_bytes.h"


class func_string : public execution_base
{
protected:
    std::string m_cData;

public:
    func_string(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);

    virtual ~func_string();

private:
	bool append(const nb_id_t& in);
    bool append_response(std::string& strval);
    
    bool generate_compare(const nb_id_t& input);
	bool compare(const nb_id_t& in);
    bool compare_response(std::string& strval);

    bool find(const nb_id_t& in);
    bool find_response(std::string& strval);

	bool substr(const nb_id_t& in1, const nb_id_t& in2, nb_id_t& out);
	bool size(nb_id_t& out);
	bool split_at(const nb_id_t& in, nb_id_vector& vout);
    
    bool IsDigit(std::string& strval);
    bool to_int(nb_id_t& in, nb_id_t& out);
    bool to_bool(nb_id_t& in, nb_id_t& out);
    bool to_float(nb_id_t& in, nb_id_t& out);
    bool convert(std::string& strval, time_data_t& time_data);
    bool to_interval(nb_id_t& in, nb_id_t& out);
    bool to_time(nb_id_t& in, nb_id_t& out);
    bool to_bytes(nb_id_t& out);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output);
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }

    virtual bool get_value_response(req_num_t req_num, 
            content& output);

};


#endif // __EXECUTION_IMPL_STRING_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
