#ifndef __EXECUTION_IMPL_EXEC_OBJ_FUNC_H
#define __EXECUTION_IMPL_EXEC_OBJ_FUNC_H

#include "execution_base.h"
#include "ac_object/obj_impl_exec_obj_func.h"

class exec_obj_func : public execution_base
{
protected:
    exec_obj_func_data_t m_cData;
public:
    exec_obj_func(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exec_obj_func();

private:
    bool get_name(nb_id_t& out);
    bool get_declaration(nb_id_t& decl_id);
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);


public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output);

};


#endif // __EXECUTION_IMPL_EXEC_OBJ_FUNC_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
