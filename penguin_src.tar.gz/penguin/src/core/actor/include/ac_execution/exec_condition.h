#ifndef __EXECUTION_IMPL_EXEC_CONDITION_H
#define __EXECUTION_IMPL_EXEC_CONDITION_H

#include "execution_base.h"
#include "ac_object/obj_impl_exec_condition.h"


class exec_condition : public execution_base
{
protected:
    exec_cond_data_t m_cData;

protected:
    uint32_t m_cond_num;
    req_num_t m_req;

public :
    exec_condition(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exec_condition();

private:
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output);
};


#endif // __EXECUTION_IMPL_EXEC_CONDITION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
