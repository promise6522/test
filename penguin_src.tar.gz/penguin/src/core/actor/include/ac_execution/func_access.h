#ifndef __EXECUTION_IMPL_ACCESS_H
#define __EXECUTION_IMPL_ACCESS_H

#include "nb_typedef.h"
#include "ac_message_type.h"
#include "execution_base.h"
#include "ac_container/access_implementation.h"
#include "ac_container/container_implementation.h"
#include "ac_container/anchor_implementation.h"

class func_access : public execution_base 
{
protected:
    access_data_t m_cData;
    container_data_t m_parent_cont_data;

protected:
    access_id_t m_access_id;
    nb_id_vector m_accesses;
    size_t m_anchor_num; 
    obj_message_info<int> m_req_anchor_map;

public:
    func_access();
    func_access(const nb_id_t& access_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_access();

public:
    bool is_registed(nb_id_t& result);
    //root access
    bool destroy_container(const container_id_t& cont_id);
    bool get_anchor_list(std::vector<anchor_id_t>& output);
    bool get_storage_list(std::vector<storage_id_t>& output);
    bool generate_access_from_anchor(const anchor_data_t& an_data,
            const int an_idx,
            access_id_t& access_id);
    bool get_storage_content(const int& idx, nb_id_vector& content);
    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        nb_builtin_instruction_t builtin_ins;
        if (get_ins_call(req_num, builtin_ins))
        {
            switch (builtin_ins)
            {
                case NB_FUNC_GENERAL_RUN:
                    end_incoming_ins_call(req_num);
                    return execution_base::obj_run_response(req_num, output);
                default:
                    break;
            }
        }
        return true;
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output);
    bool create_container_get_value_response(const content& output);
    bool get_container_value_response(req_num_t req_num, con_content& output);
    bool get_anchor_value_response(req_num_t req_num, content& output);
    bool bridge_send_out_response(req_num_t req_num, nb_id_t& output);
};


#endif // __EXECUTION_IMPL_ACCESS_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
