#ifndef __EXECUTION_IMPL_NONE_H
#define __EXECUTION_IMPL_NONE_H

#include "execution_base.h"
#include "ac_object/obj_impl_none.h"


/****************************** user ******************************/
class func_none : public execution_base
{
public:
    func_none(nb_id_t& obj_id, 
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper)
        : execution_base(obj_id, exe_id, pHelper)
    { 
    }; 
    virtual ~func_none()
    {
    };

private:
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output);
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output);
    }

};


#endif // __EXECUTION_IMPL_NONE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
