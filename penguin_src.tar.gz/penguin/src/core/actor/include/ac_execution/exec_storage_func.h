#ifndef __EXECUTION_IMPL_EXEC_STORAGE_FUNC_H
#define __EXECUTION_IMPL_EXEC_STORAGE_FUNC_H

#include "execution_base.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/object_data.h"

class exec_storage_func : public execution_base
{
protected:
    exec_storage_func_data_t    m_cData;
    facade_id_t                 m_facade;
    storage_id_t                m_storage;

    nb_id_t                     m_key_if;
    nb_id_t                     m_val_if;

    obj_message_info<sv_update_input> m_update_map;

public:
    exec_storage_func(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exec_storage_func();

private:
    bool get_declaration(nb_id_t& decl_id);
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    // new functions
    bool get_single();
    bool get_more();
    bool has_key();
    bool insert_one();
    bool replace_one();
    bool delete_one();
    bool set_one();
    bool update();
    bool size();
    bool get_range();

    bool get_name(nb_id_t& out);
	
private:
	bool storage_facade_respond(node_invocation_response& response);
public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true;
    }
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

    // for new functions
    bool storage_facade_get_single_response(req_num_t req_num, const object_id& output);
    bool storage_facade_get_more_response(req_num_t req_num, const key_pair_no_version1& output);
    bool storage_facade_has_key_response(req_num_t req_num, const key_array& output);
    bool storage_facade_replace_one_response(req_num_t req_num, const object_id& output);
    bool storage_facade_delete_one_response(req_num_t req_num, const object_id& output);
    bool storage_facade_set_one_response(req_num_t req_num, const bool& output);
    bool storage_facade_update_response(req_num_t req_num, const sv_update_output& output);
    bool storage_facade_size_response(req_num_t req_num, const int& output);
    bool storage_facade_get_range_response(req_num_t req_num, const key_pair_no_version1& output);

    bool get_container_value_response(req_num_t req_num, con_content& output);
    bool get_storage_value_response(req_num_t req_num, content& output);
};


#endif // __EXECUTION_IMPL_EXEC_STORAGE_FUNC_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
