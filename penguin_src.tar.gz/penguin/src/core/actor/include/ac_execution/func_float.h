#ifndef __EXECUTION_IMPL_FLOAT_H
#define __EXECUTION_IMPL_FLOAT_H

#include "execution_base.h"
#include "ac_object/obj_impl_float.h"

/****************************** float ******************************/
class func_float : public execution_base
{
public:
    func_float(nb_id_t& obj_id, 
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper) 
        : execution_base(obj_id, exe_id, pHelper)
    { 
    }; 
    virtual ~func_float()
    {
    };

private:
    bool add(const nb_id_t& in, nb_id_t& out);
    bool sub(const nb_id_t& in, nb_id_t& out);
    bool mul(const nb_id_t& in, nb_id_t& out);
    bool div(const nb_id_t& in, nb_id_t& out);
    bool eq(const nb_id_t& in, nb_id_t& out);
    bool lt(const nb_id_t& in, nb_id_t& out);
    bool to_int(nb_id_t& out);
    bool to_string(nb_id_t& out);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }

};

#endif // __EXECUTION_IMPL_FLOAT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
