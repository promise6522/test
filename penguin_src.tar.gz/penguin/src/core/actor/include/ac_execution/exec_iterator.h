#ifndef __EXECUTION_IMPL_EXEC_ITERATOR_H
#define __EXECUTION_IMPL_EXEC_ITERATOR_H

#include "execution_base.h"
#include "ac_object/obj_impl_exec_iterator.h"


class exec_iterator : public execution_base
{
protected:
    exec_iterator_data_t    m_cData;
    req_num_t               m_req;
    nb_id_t                 m_object;

public:
    exec_iterator(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exec_iterator();

private:
    bool get_name(nb_id_t& name);
    bool set_type(const nb_id_t& type_id) { return true; }
    bool get_type(nb_id_t& type_id) { return true; }

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, content& output);

    virtual bool access_run_response(req_num_t req_num, node_invocation_response& output) { return true; }
};


#endif // __EXECUTION_IMPL_EXEC_ITERATOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
