#ifndef __FUNC_BRIDGE_INTERFACE_H
#define __FUNC_BRIDGE_INTERFACE_H

#include "execution_base.h"
#include "ac_object/obj_impl_bridge_interface.h"

class func_bridge_interface : public execution_base
{
protected:
    bridge_interface_data_t m_cData;

public:
    func_bridge_interface();
    func_bridge_interface(const nb_id_t& obj_id, 
	    const content& raw_data,
	    const execution_id_t& exe_id, 
	    ac_execution_helper * pHelper);
    virtual ~func_bridge_interface();

private:
    bool get_name(nb_id_t& out);
    bool eq(const nb_id_t& if_id);
    bool cover(const nb_id_t& if_id);
    bool convert(const nb_id_t& if_id);

    bool eq_response(const bridge_interface_data_t& in, nb_id_t& result);
    bool cover_response(const bridge_interface_data_t& in, nb_id_t& result);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }

};

#endif // __FUNC_BRIDGE_INTERFACE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
