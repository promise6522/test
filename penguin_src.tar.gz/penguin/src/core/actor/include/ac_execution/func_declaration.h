#ifndef __EXECUTION_IMPL_DECLARATION_H
#define __EXECUTION_IMPL_DECLARATION_H

#include "execution_base.h"


class func_declaration : public execution_base
{
protected:
    nb_id_vector m_viif;
    nb_id_vector m_voif;

public :
    func_declaration(nb_id_t& obj_id, 
            const execution_id_t& exe_id,
            ac_execution_helper * pHelper);
    virtual ~func_declaration();

private:
    bool get_interfaces(nb_id_vector& vout);
    bool get_in_ports(nb_id_t& out);
    bool get_out_ports(nb_id_t& out);
    bool get_iport_number(nb_id_t& num);
    bool get_oport_number(nb_id_t& num);

    bool get_expanded_ifs(nb_id_t& out);
public:
    bool get_name(nb_id_t& out);

    bool set_type(const nb_id_t& type_id)
    {
        return true;
    }

    bool get_type(nb_id_t& type_id)
    {
        type_id = nb_id_t(NB_INTERFACE_DECLARATION);
        return true;
    }

public:
    virtual bool run();

    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output);
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output);
    }
};


#endif // __EXECUTION_IMPL_DECLARATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
