#ifndef __EXECUTION_IMPL_BYTES_H
#define __EXECUTION_IMPL_BYTES_H

#include "execution_base.h"
#include "ac_object/obj_impl_bytes.h"


/****************************** user ******************************/
class func_bytes : public execution_base
{
protected:
    bytes_data_t m_cData;
public :
    func_bytes(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
        ac_execution_helper * pHelper);
    virtual ~func_bytes();

private:
    bool make_bytes(bytes_data_t& data);
private:
	bool join();
    bool compare(const nb_id_t& input);
    bool generate_compare(const nb_id_t& input);
    bool range(const nb_id_t& start_pos, 
            const nb_id_t& end_pos, nb_id_t& out);
	bool size(nb_id_t& out);
	bool split(nb_id_t& out0, nb_id_t& out1);
    bool split_at(const nb_id_t& start_pos, 
            nb_id_t& out0, 
            nb_id_t& out1);
	bool crc(nb_id_t& out);
    bool to_string(nb_id_t& out);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output);
    bool compare_result(const bytes_data_t& val);

};


#endif // __EXECUTION_IMPL_BYTES_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
