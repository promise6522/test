#ifndef __EXECUTION_IMPL_BASE_H
#define __EXECUTION_IMPL_BASE_H

#include <math.h>

#include <stdlib.h>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <functional>

#include "stdx_log.h"
#include "nb_typedef.h"
#include "ac_object/obj_impl_corpse.h"
#include "run_error_type_t.h"

class ac_execution_helper;

class execution_base
{
protected:
    nb_id_t                     m_obj_id;
    execution_id_t              m_id;

    // request number
    req_num_t                   m_top_req_num;
    req_map                     m_req_info_map;
    builtin_instruction_map     m_ins_call_map;
    builtin_instruction_map     m_ins_call_out_map;
    std::vector<req_num_t>      m_reqs;
    req_num_t                   m_req;
    num_ins_pair_map            m_num_ins_pair_map;
    num_obj_map                 m_num_obj_map;
    std::map<req_num_t, int>    m_req_flag;
    std::map<req_num_t, node_invocation_request>    m_param_info_map;

    call_id_t                   m_call_id;
    ac_execution_helper*        m_pHelper;
    node_invocation_request     m_param;

    execution_id_t              m_parent_execution;
    root_committer_id_t         m_root_commit;
    node_invocation_response    m_result;

    //get accesses
    nb_id_vector                m_accesses;
    std::vector<access_id_t>    m_reg_accesses;
    int                         m_get_ac_req;
    int                         m_get_ac_res;
    int                         m_reg_ac_res;

    nb_id_t                     m_array_key;

public :
    execution_base(const nb_id_t& obj_id, 
            const execution_id_t& exe_id,
            ac_execution_helper * pHelper);
    execution_base();
    virtual ~execution_base();

    // set id
    void set_id(const execution_id_t& id);
    bool get_id(execution_id_t& id);

    void set_object_id(const nb_id_t& id);
    bool get_object_id(nb_id_t& id);
    bool get_transaction_id(transaction_id_t& id);

private:
    // general instruction implementation
    bool is_null(nb_id_t& out);
    bool is_singleton(nb_id_t& out);
    bool is_justid(nb_id_t& out);
    bool is_builtin(nb_id_t& out);
    bool is_exportable(nb_id_t& out);
    bool is_local(nb_id_t& out);
    bool is_valuecompared(nb_id_t& out);
    bool exception_if_null(nb_id_t& out);
    bool is_independ(nb_id_t& out);
    bool compare(const nb_id_t& in, nb_id_vector& vout);
    bool general_run();

    bool get_registed_accesses();

protected:
    virtual bool get_name(nb_id_t& out) = 0;

public:
    bool return_bool_result(const bool result, const transaction_id_t& tr_id);
    // run and response handles
    bool run_prepare(call_id_t call_id, const node_invocation_request& input);
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool access_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, content& output);

    bool pre_commit_response(req_num_t req_num, bool& output);
    bool commit_response(req_num_t req_num, bool& output);

    // request number handles
    req_num_t generate_req_num();

    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    bool get_call_id(req_num_t req_num, call_id_t& call_id);
    
    void begin_incoming_ins_call(req_num_t req_num, nb_builtin_instruction_t instruction);
    void end_incoming_ins_call(req_num_t req_num);
    bool get_ins_call(req_num_t req_num, nb_builtin_instruction_t& instruction);

    void begin_incoming_ins_call_out(req_num_t req_num, nb_builtin_instruction_t instruction);
    void end_incoming_ins_call_out(req_num_t req_num);
    bool get_ins_call_out(req_num_t req_num, nb_builtin_instruction_t& instruction);

    void insert_num_ins_pair(const req_num_t req_num, const instruction_pair_t ins_pair);
    void erase_num_ins_pair(const req_num_t req_num);
    bool get_ins_pair(const req_num_t req_num, instruction_pair_t& ins_pair);

    void insert_num_param_pair(req_num_t req_num, const node_invocation_request& param);
    void erase_num_param_pair(req_num_t req_num);
    bool get_param(req_num_t req_num, node_invocation_request& param);

    bool set_parent(const execution_id_t& input);
    bool set_root_commit(const root_committer_id_t& input);

    bool run_respond(node_invocation_response& output);
    bool run_exception_respond(const transaction_id_t& tr_id, int corpse_type = CORPSE_GENERAL_ERROR_TYPE);
    bool run_execution_respond(bool output);

    bool generate_map(const std::vector< key_obj_id >& key_obj_ids, const nb_id_t& key_min_if, 
                      const nb_id_t& val_min_if, nb_id_t& map_id);
    bool generate_array(const nb_id_vector& keys, const nb_id_t& key_min_if, nb_id_t& array_id);

protected:
    // internal handles
    bool run_instruction(const nb_id_t& principal, 
            const node_invocation_request& input,
            const nb_builtin_instruction_t ins_call,
            const nb_builtin_instruction_t ins_call_out);

    bool access_run_instruction(const access_id_t& principal, 
            const node_invocation_request& input,
            const nb_builtin_instruction_t ins_call,
            const nb_builtin_instruction_t ins_call_out);

    bool throw_exeception(req_num_t req_num, std::string exception_string);
    bool exception_respond(std::string& output);

    bool request_nb_id(host_committer_id_t id, const request_nb_id_info& input, nb_id_t& output, bool is_corpse = false);
    bool request_facade_id(host_committer_id_t id, const request_facade_id_info& input, facade_id_t& output);
    bool request_host_committer_id(host_committer_id_t& output);
    bool transaction_get_host_committer(transaction_id_t id);
    bool create_object(host_committer_id_t id, const content& input);
    bool load_object(host_committer_id_t id, const nb_id_t& input, content& output);
    bool request_string_object(const std::string& name, nb_id_t& out);

    bool object_run(nb_id_t id, req_num_t req_num, const node_invocation_request& input);
    bool object_get_value(nb_id_t id, content& output);
    bool object_get_value_async(nb_id_t id, req_num_t req_num);
    bool get_value_async(const nb_id_t& id, const nb_builtin_instruction_t& ins);
    bool access_run(access_id_t id, req_num_t req_num, const node_invocation_request& input);

    bool get_accesses(const nb_id_t& parent_obj, nb_id_vector& vout);

};

typedef std::tr1::shared_ptr<execution_base> execution_impl_ptr;

#endif // __EXECUTION_IMPLEMENTATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
