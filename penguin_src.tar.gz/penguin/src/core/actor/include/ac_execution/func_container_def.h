#ifndef __EXECUTION_IMPL_CONTAINER_DEF_H
#define __EXECUTION_IMPL_CONTAINER_DEF_H

#include "execution_base.h"
#include "ac_object/obj_impl_container_def.h"


class func_container_def: public execution_base
{
protected:
    cont_def_data_t m_cData;
public:
	func_container_def();
	func_container_def(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
        ac_execution_helper * pHelper);
    virtual ~func_container_def();

private:
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);
    bool get_cont_information(cont_def_data_t& cont_info);
    bool get_storage_type(const nb_id_t idx, nb_id_t storage_type);
    bool create_container();

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }

};

#endif // __EXECUTION_IMPL_CONTAINER_DEF_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
