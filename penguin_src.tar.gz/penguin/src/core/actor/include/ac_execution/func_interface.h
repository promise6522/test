#ifndef __EXECUTION_IMPL_INTERFACE_H
#define __EXECUTION_IMPL_INTERFACE_H

#include "execution_base.h"
#include "ac_object/obj_impl_interface.h"

class func_interface : public execution_base
{
public:
	func_interface(nb_id_t& obj_id, 
            const execution_id_t& exe_id,
            ac_execution_helper * pHelper);

    virtual ~func_interface();


private:
    bool do_get_declarations_name(nb_id_t& decls_array_id);
    bool do_get_declarations(nb_id_t& names_array_id);
    bool do_convert(const nb_id_t& obj, nb_id_t& out);

    bool do_equal(const nb_id_t& obj_if, nb_id_vector& out);
    bool do_cover(const nb_id_t& obj_if, nb_id_vector& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }

    bool get_name(nb_id_t& out);

    bool set_type(const nb_id_t& type_id)
    {
        return true;
    }

    bool get_type(nb_id_t& type_id)
    {
        type_id = nb_id_t(NB_INTERFACE_INTERFACE);
        return true;
    }
};


#endif // __EXECUTION_IMPL_INTERFACE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
