#ifndef __EXECUTION_IMPL_DECL_COMPOUND_H
#define __EXECUTION_IMPL_DECL_COMPOUND_H

#include "execution_base.h"
#include "ac_object/obj_impl_decl_compound.h"


class func_decl_compound : public execution_base
{
protected:
    decl_compound_data_t m_cData;

public :
    func_decl_compound(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_decl_compound();

private:
    bool get_ports(bool input, bool output, nb_id_vector& vout);
    bool get_interfaces(nb_id_vector& vout);
    bool get_in_ports(nb_id_vector& vout);
    bool get_out_ports(nb_id_vector& vout);

    bool get_iport_number(nb_id_t& num);
    bool get_oport_number(nb_id_t& num);
    bool get_expanded_ifs(nb_id_t& out);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }

};


#endif // __EXECUTION_IMPL_DECL_COMPOUND_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
