#ifndef __EXE_BRIDGE_H
#define __EXE_BRIDGE_H

#include "execution_base.h"

class exe_bridge : public execution_base
{
public:
    exe_bridge(const nb_id_t& obj_id,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exe_bridge();

    bool trigger_end(call_id_t call_id, bridge_end_response response);

public:
    virtual bool get_name(nb_id_t& out)
    {
        return true; 
    }
    virtual bool run()
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
};


#endif // __EXE_BRIDGE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
