#ifndef __EXECUTION_IMPL_BOOL_H
#define __EXECUTION_IMPL_BOOL_H

#include "execution_base.h"

/****************************** boolean ******************************/
class func_bool : public execution_base 
{
public :
    func_bool(nb_id_t& obj_id, 
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_bool();

private:
    bool bit_not(nb_id_t& out);
    bool bit_and(const nb_id_t& in, nb_id_t& out);
    bool bit_or(const nb_id_t& in, nb_id_t& out);
    bool eq(const nb_id_t& in, nb_id_t& out);
    bool ne(const nb_id_t& in, nb_id_t& out);
    bool to_int(nb_id_t& out);
    bool to_string(nb_id_t& out);
    bool true_to_exception(nb_id_t& out);
    bool false_to_exception(nb_id_t& out);

    bool exception_if_true(nb_id_t& out);
    bool exception_if_false(nb_id_t& out);
    bool break_if_true(nb_id_t& out);
    bool break_if_false(nb_id_t& out);
    bool _break_if(bool match, nb_id_t& out);
	bool _exception_if(bool match, nb_id_t& out);
	
	bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }
};


#endif // __EXECUTION_IMPL_BOOL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
