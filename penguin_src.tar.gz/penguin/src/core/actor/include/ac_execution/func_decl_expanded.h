/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef __EXECUTION_IMPL_DECL_EXPANDED_H
#define __EXECUTION_IMPL_DECL_EXPANDED_H

#include "execution_base.h"
#include "ac_object/obj_impl_decl_expanded.h"

class func_decl_expanded : public execution_base
{
protected:
    decl_expanded_data_t m_cData;
    std::vector<nb_id_t> m_in_expanded_ifs;
    std::vector<nb_id_t> m_expanded_ifs;
    std::size_t m_expanded_if_idx;

public :
    func_decl_expanded(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_decl_expanded();

private:
    bool get_all_ports_async();
    bool get_in_ports_async();
    bool get_out_ports_async();

    bool get_port_number(bool input);

    bool get_decl_id(nb_id_t& id);
    bool get_expanded_ifs(nb_id_t& out);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

    bool compare_respond(int result);

    // helper func to get expanded_decl's port interface
    bool generate_expanded_if(const nb_id_t& origin_if, const nb_id_vector& expanded_ifs, nb_id_t& new_if_id);

    // for a expanded declaration, caculate its in&out ports
    bool get_expanded_decl_interfaces(const decl_expanded_data_t& decl_expanded_data, 
        nb_id_vector& viifs, nb_id_vector& voifs);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

};


#endif // __EXECUTION_IMPL_DECL_COMPOUND_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
