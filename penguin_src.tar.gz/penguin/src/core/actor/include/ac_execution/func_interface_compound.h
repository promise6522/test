#ifndef __EXECUTION_IMPL_INTERFACE_COMPOUND_H
#define __EXECUTION_IMPL_INTERFACE_COMPOUND_H

#include "execution_base.h"
#include "ac_object/obj_impl_interface_compound.h"

class func_interface_compound : public execution_base
{
protected:
    if_compound_data_t m_cData;
    nb_id_vector m_builtin_ins;

    std::size_t m_cover_idx;
    std::size_t m_covered_idx;
    if_compound_data_t m_covered_if;
    if_compound_data_t m_cover_if;

    int m_eq_count;

    size_t                      m_decls_count;
    std::vector< std::string >  m_decl_names;

public:
	func_interface_compound();
    func_interface_compound(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_interface_compound();

private:
    bool get_name(nb_id_t& out);

    bool set_builtin_instructions(const nb_id_vector& vins);

    bool get_general_instructions(nb_id_vector& vins);
    bool get_access_instructions(nb_id_vector& vins);
    bool get_user_instructions(nb_id_vector& vins);
    bool get_builtin_instructions(nb_id_vector& vins);
    bool get_declarations(nb_id_t& decls_array_id);
    bool get_declarations_name();

    bool get_general_instructions_name(nb_id_vector& vnames);
    bool get_access_instructions_name(nb_id_vector& vnames);
    bool get_user_instructions_name(nb_id_vector& vnames);
    bool get_builtin_instruction_names(nb_id_vector& vnames);

    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);
    bool is_singleton(nb_id_t& result);
    bool get_min_ifs(nb_id_vector& vif);

    bool eq(const nb_id_vector& decls, const nb_id_vector& in_decls);
    bool cover(const nb_id_vector& decls, const nb_id_vector& in_decls);
    bool convert(const nb_id_vector& decls, const nb_id_vector& in_decls);

    bool get_decls_custom(const nb_id_vector& src, nb_id_vector& dest);
    bool check_expanded(const std::vector<if_exp_group>& groups, int expanded_flag);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output);

};

#endif // __EXECUTION_IMPL_INTERFACE_COMPOUND_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
