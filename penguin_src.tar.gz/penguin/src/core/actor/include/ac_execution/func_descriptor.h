#ifndef __EXECUTION_IMPL_DESCRIPTER_H
#define __EXECUTION_IMPL_DESCRIPTER_H

#include "execution_base.h"
#include "ac_object/obj_impl_descriptor.h"

class func_descriptor : public execution_base
{
protected:
    descriptor_data_t m_cData;
public :
    func_descriptor(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_descriptor();

private:
    bool get_function(const nb_id_t& decl_id, nb_id_t& impl_id);
    bool get_subobj_ifs(nb_id_vector& interfaces);
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output); 
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output); 
    }

};


#endif // __EXECUTION_IMPL_DESCRIPTER_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
