#ifndef __FUNC_CORPSE_H
#define __FUNC_CORPSE_H

#include"execution_base.h"
#include"ac_object/obj_impl_corpse.h"


class func_corpse : public execution_base
{
protected:
    corpse_data_t m_cData;
    std::string m_value;
    bool m_is_single;

public:
    func_corpse();
    virtual ~func_corpse();

    func_corpse(const nb_id_t& obj_id,
                content& raw_data,  
                execution_id_t& exec_id,
                ac_execution_helper* pHelper);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, content& output);

private:
    std::string assemb_string();
    bool print_format_async();
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);
    bool get_name(nb_id_t& out);
    nb_id_t  request_string_id(const std::string& result);

};

#endif //__FUNC_CORPSE_H
