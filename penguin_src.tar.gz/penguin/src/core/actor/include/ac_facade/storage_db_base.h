/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**  
**                author: Roger
**************************************************************************/


#ifndef __STORAGE_DB_BASE_H
#define __STORAGE_DB_BASE_H

#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

// NB header file
#include "ac_actor_type.h"
#include "nb_id.h"
#include "ac_db/ac_storage_db_impl.h"
#include "ac_message_type.h"


enum ins_type_t
{
    INS_TYPE_ADD,
    INS_TYPE_DEL,
    INS_TYPE_MOD,
};

// fill the add/sub ids in struct return to upper
struct change_data_st
{
    std::vector<nb_id_t> add_vid;
    std::vector<nb_id_t> ssub_vid;
};

// records the operate in struct
struct record_ins_st
{
    ins_type_t r_type;
    std::vector<std::pair<nb_id_t, nb_id_t> > r_data;
};

// 
struct result_st
{
    std::vector<std::pair<nb_id_t, nb_id_t> > key_obj_ids;
    int version;
};

class storage_db_base
{
private:    
    typedef std::vector<std::pair<nb_id_t, nb_id_t> > keyval_vid;
    typedef keyval_vid::const_iterator const_kval_it;

    typedef std::vector<nb_id_t> key_vid;
    typedef key_vid::const_iterator const_key_it;

    typedef std::map<std::string, int>::iterator version_iterator;
    typedef std::map<std::string, int>::const_iterator version_const_iterator;

public:
    storage_db_base(nbnv* penv, const std::string& sstrid);
    ~storage_db_base();

public:
    bool get(const key_vid& input, keyval_vid& output, DbTxn* txn = NULL);
    bool delete_object(call_id_t call_id, const key_vid& input, keyval_vid& output, int version, DbTxn* txn);
    int size(DbTxn* txn = NULL);
    bool delete_all(DbTxn* txn);
    bool get_change(call_id_t call_id, change_data_st& record_ins);
    bool insert(const keyval_vid& input, int version, DbTxn* txn);
    bool update(const keyval_vid& input, int version, DbTxn* txn);
    bool get_range(const key_pair& input, keyval_vid& output, DbTxn* txn = NULL);
    bool has_key(const key_vid& input, keyval_vid& output, DbTxn* txn);
    bool has_change(bool& output);
    bool replaceOne(const keyval_vid& input, nb_id_t& output, int version, DbTxn* txn);
    bool update(const key_vid& d_key, const keyval_vid& s_map, const keyval_vid& r_map, key_vid& d_o, key_vid& s_o, keyval_vid& r_o, int version, DbTxn* txn);

    bool commit(DbTxn* txn = NULL);
    bool rollback(DbTxn* txn = NULL);
    bool write();
    nbdb* get() const;

private:
    ac_storage_db_impl* pdb;
    change_data_st m_change_data;
    std::vector<record_ins_st> m_ins_records;
    result_st m_result_data;
    
    //
    std::string m_stor_id;
};

typedef std::tr1::shared_ptr<storage_db_base> storage_db_ptr;


#endif // __STORAGE_DB_BASE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
