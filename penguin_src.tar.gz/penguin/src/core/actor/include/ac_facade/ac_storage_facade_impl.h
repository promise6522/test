/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**  
**                author: Roger
**************************************************************************/


#ifndef __AC_STORAGE_FACADE_IMPL_H
#define __AC_STORAGE_FACADE_IMPL_H

#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

// NB header file
#include "ac_actor_type.h"
#include "nb_id.h"
#include "ac_db/ac_storage_db_impl.h"
#include "ac_message_type.h"

/*
enum ins_type_t
{
    INS_TYPE_ADD,
    INS_TYPE_DEL,
    INS_TYPE_MOD,
};

// fill the add/sub ids in struct return to upper
struct change_data_st
{
    std::vector<nb_id_t> add_vid;
    std::vector<nb_id_t> ssub_vid;
};

// records the operate in struct
struct record_ins_st
{
    ins_type_t r_type;
    std::vector<std::pair<nb_id_t, nb_id_t> > r_data;
};

// 
struct result_st
{
    std::vector<std::pair<nb_id_t, nb_id_t> > key_obj_ids;
    int version;
};

class ac_storage_facade_impl
{
private:    
    typedef std::vector<std::pair<nb_id_t, nb_id_t> > keyval_vid;
    typedef keyval_vid::const_iterator const_kval_it;

    typedef std::vector<nb_id_t> key_vid;
    typedef key_vid::const_iterator const_key_it;

    typedef std::map<std::string, int>::iterator version_iterator;
    typedef std::map<std::string, int>::const_iterator version_const_iterator;

public:
    ac_storage_facade_impl(nbnv* penv, const std::string& sstrid);
    ~ac_storage_facade_impl();

public:
    bool get(const key_vid& input, keyval_vid& output);
    bool delete_object(call_id_t call_id, const key_vid& input, keyval_vid& output, int version);
    int size();
    bool delete_all();
    bool get_change(call_id_t call_id, change_data_st& record_ins);
    bool insert(const keyval_vid& input, int version);
    bool update(const keyval_vid& input, int version);
    bool get_range(const key_pair& input, keyval_vid& output);
    bool has_key(const key_vid& input, keyval_vid& output);
    bool has_change(bool& output);
    bool replaceOne(const keyval_vid& input, nb_id_t& output, int version);
    bool update(const key_vid& d_key, const keyval_vid& s_map, const keyval_vid& r_map, key_vid& d_o, key_vid& s_o, keyval_vid& r_o, int version);

    bool commit();
    bool rollback();
    bool write();

    int get_version(int& version);
    bool set_version(int version);


    bool get_version(int& version);
private:
    bool init_w_version(const std::string& storid, int version);
    bool init_zerow_version(const std::string& storid);
    bool insert_w_version(const std::string& storid, int version);
    int get_w_version(const std::string& storid);

private:
    ac_storage_db_impl* pdb;
    change_data_st m_change_data;
    std::vector<record_ins_st> m_ins_records;
    result_st m_result_data;
    
    //
    std::string m_stor_id;
    static std::map<std::string, int> m_version_map;
    static int m_version;
    static boost::mutex m_mtx;
};
*/
class ac_storage_facade_impl
{
private:
    // request number
    req_num_t                                       m_top_req_num;
    std::map<req_num_t, call_id_t>                  m_req_info_map;
    std::map<req_num_t, nb_builtin_instruction_t>   m_ins_call_map;

    typedef std::map<req_num_t, nb_builtin_instruction_t>::const_iterator builtin_instruction_map_it;
    
    boost::mutex m_mutex;

public:

    ac_storage_facade_impl(const storage_id_t& sid);
    // request number handles
    req_num_t generate_req_num();
    storage_id_t                    m_storage_id;

    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    bool get_call_id(req_num_t req_num, call_id_t& call_id);

    void begin_incoming_ins_call(req_num_t req_num, nb_builtin_instruction_t instruction);
    void end_incoming_ins_call(req_num_t req_num);
    bool get_ins_call(req_num_t req_num, nb_builtin_instruction_t& instruction);
};

typedef std::tr1::shared_ptr<ac_storage_facade_impl> facade_impl_ptr;

#endif // __AC_STORAGE_FACADE_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
