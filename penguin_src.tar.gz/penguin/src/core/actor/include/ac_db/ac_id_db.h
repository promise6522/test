/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/


#ifndef __AC_ID_DB_H
#define __AC_ID_DB_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

#include "nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"


class ac_id_db : public mutex_singleton<ac_id_db>
{
public:
    int write(const std::string& strkey, const std::string& value, DbTxn* txn = NULL);
    int read(const std::string& strkey, std::string& value);

private:
    ac_id_db();

public:
    virtual ~ac_id_db(void); 
    friend struct mutex_singleton<ac_id_db>;

private:
    nbnv* penv;
    nbdb* pdb;
};


#endif // __AC_ID_DB_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
