/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/
#ifndef __AC_OBJECT_DB_IMPL_H
#define __AC_OBJECT_DB_IMPL_H

// C 89 header files
#include <assert.h>

// C++ 98 header files
#include <string>
#include <vector>

#include "nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"


class ac_object_db_impl : public boost_singleton<ac_object_db_impl>
{
public:
    /// read/write/del
    int read(const std::string& strkey, std::string& value, DbTxn* txn = NULL);

    bool exist(const std::string& strval, DbTxn* txn = NULL);

    int write(const std::string& strkey, const std::string& value, DbTxn* txn = NULL);

    int del(const std::string& strkey, DbTxn* txn = NULL);

    bool read_all_handles(std::string& strval);

    /// for transactions
    bool begin_txn(DbTxn*& txn);

    bool commit(DbTxn* txn);

    bool rollback(DbTxn* txn);

private:    
    ac_object_db_impl();
    int checked_write_(const std::string& key, const std::string& val, DbTxn* txn);

public:
    virtual ~ac_object_db_impl(); 
    friend struct boost_singleton<ac_object_db_impl>;

private:
    nbnv* penv;
    nbdb* pdb;

#ifndef NDEBUG
private:
    /* for write performance evaluation */
    long nWrites_;
    long keylens_;
    long vallens_;
#endif
};

#endif // __AC_OBJECT_DB_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
