#ifndef __nb_STDX_FS_H
#define __nb_STDX_FS_H


// Posix header files
#include <sys/stat.h>

// C 89 header files
#include <assert.h>
#include <errno.h>

// C++ 98 header files
#include <string>
#include <stdlib.h>

inline bool
file_exist(const std::string& filename)
{
    assert(!filename.empty());
    struct stat st;
    return (stat(filename.c_str(), &st) == 0 && S_ISREG(st.st_mode));
}

inline bool
nb_mkdir(const std::string& dir)
{
    assert(!dir.empty());
    bool result = false;
    struct stat sb;
    if (!dir.empty() && stat(dir.c_str(), &sb) == -1)
    {
        if (mkdir(dir.c_str(), S_IRWXU) == -1)
            result = false;
        else
            result = true;
    }
    return result;
}

inline bool
nb_mkdirs(const std::string& dir)
{
    char *saved_path, *cp;
    int saved_ch;
    struct stat st;
    int rc;

    cp = saved_path = strdup(dir.c_str());
    while (*cp && *cp == '/')
        ++cp;

    while (1)
    {
        while (*cp && *cp != '/')
            ++cp;

        if ((saved_ch = *cp) != 0)
            *cp = 0;

        if ((rc = stat(saved_path, &st)) >= 0)
        {
            if (!S_ISDIR(st.st_mode))
            {
                errno = ENOTDIR;
                rc = -1;
                break;
            }
        }
        else
        {
            if (errno != ENOENT)
                break;

            if ((rc = mkdir(saved_path, S_IRWXU)) < 0)
            {
                if (errno != EEXIST)
                    break;

                if ((rc = stat(saved_path, &st)) < 0)
                    break;

                if (!S_ISDIR(st.st_mode))
                {
                    errno = ENOTDIR;
                    rc = -1;
                    break;
                }
            }
        }
        if (saved_ch != 0)
            *cp = saved_ch;

        while (*cp && *cp == '/')
            ++cp;
        if (*cp == 0)
            break;
    }
    free(saved_path);
    return rc;
}

#define NB_PAGE_SIZE_DEFAULT 4096

inline uint32_t
nb_getpagesize(void)
{
#ifdef PAGE_SIZE
    uint32_t pagesize = PAGE_SIZE;
#else
    uint32_t pagesize = 0;
#endif
    if (pagesize == 0)
    {
        errno = 0;
        if ((pagesize = sysconf(_SC_PAGE_SIZE)) < 0)
        {
            if (errno == 0)
                pagesize = NB_PAGE_SIZE_DEFAULT;
            else
                assert(!"sysconf error for _SC_PAGE_SIZE");
        }
    }
    return pagesize;
}

#endif // __nb_STDX_FS_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
