#ifndef __DUKE_CORE_BASE_H
#define __DUKE_CORE_BASE_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>

// Duke header files
#include "nb_stdx_string.h"

typedef u_int32_t NbDbResult;

const NbDbResult NB_DB_RESULT_SUCCESS  = 0;
const NbDbResult NB_DB_RESULT_NOTFOUND = 1;
const NbDbResult NB_DB_RESULT_FAILED   = 2;

inline void
millisleep(int ms)
{
    struct timespec ts = { 0, 1000*1000*ms };
    nanosleep(&ts, NULL);
}


//////////////////////////////////////////////////////////////////////////////
// Duke Command Type and Result
//////////////////////////////////////////////////////////////////////////////

typedef u_int32_t DukeCmdType;
typedef u_int32_t DukeCmdResult;


//////////////////////////////////////////////////////////////////////////////
// Duke Process Default Port
//////////////////////////////////////////////////////////////////////////////

const std::string BACKUPD_HOME = "dbhome";
const std::string TABLED_HOME = "dbtabled";
const std::string VERIFYD_HOME = "dbverifyd";
const std::string INFOD_HOME = "dbinfod";

const std::string STR_LOCALHOST = "localhost";
const std::string IDIP_FILE = "idip.db";
const std::string IDIP_NAME = "idip";
const std::string IDIP_IPIDX = "ipidx";
const std::string IDVAL_FILE = "idval.db";
const std::string IDVAL_NAME = "idval";

//add by roger at 06/25/10
const std::string IDHANDLE_FILE = "idhandle.db";
const std::string IDHANDLE_NAME = "idhandle";

//add by roger at 09/08/10
const std::string HANDLEINFO_FILE = "handleinfo.db";
const std::string HANDLEINFO_NAME = "handleinfo";


const u_int16_t DUKELOGD_PORT = 6004;
const u_int16_t DUKEISD_PORT  = 6005;
const u_int16_t TRACKD_PORT   = 6006;
const u_int16_t ITEST_PORT    = 9500;
const u_int16_t REPLICA_PORT  = 8100;
const u_int16_t TABLED_PORT   = 8200;
const u_int16_t BACKUPD_PORT  = 8300;
const u_int16_t CRASHD_PORT   = 8400;
const u_int16_t SNOWD_PORT    = 8500;
const u_int16_t TRANSD_PORT   = 8600;
const u_int16_t VERIFYD_PORT  = 8700;
const u_int16_t INFOD_PORT    = 8800;


inline in_port_t
get_daemonport(in_port_t hostid, in_port_t portbase)
{
    return hostid + portbase;
}

inline std::string
get_daemonport(const std::string& hostid, in_port_t portbase)
{
    in_port_t port = from_string<in_port_t>(hostid) + portbase;
    return to_string(port);
}

inline std::string
get_daemonport(const std::string& hostid, const std::string& portbase)
{
    return get_daemonport(hostid, from_string<in_port_t>(portbase));
}

inline in_port_t
get_backupd_port(in_port_t hostid)
{
    return get_daemonport(hostid, BACKUPD_PORT);
}

inline std::string
get_backupd_port(const std::string& hostid)
{
    return get_daemonport(hostid, BACKUPD_PORT);
}

inline in_port_t
get_snowd_port(in_port_t hostid)
{
    return get_daemonport(hostid, SNOWD_PORT);
}

inline std::string
get_snowd_port(const std::string& hostid)
{
    return get_daemonport(hostid, SNOWD_PORT);
}

inline in_port_t
get_transd_port(in_port_t hostid)
{
    return get_daemonport(hostid, TRANSD_PORT);
}

inline std::string
get_transd_port(const std::string& hostid)
{
    return get_daemonport(hostid, TRANSD_PORT);
}

inline in_port_t
get_crashd_port(in_port_t hostid)
{
    return get_daemonport(hostid, CRASHD_PORT);
}

inline std::string
get_crashd_port(const std::string& hostid)
{
    return get_daemonport(hostid, CRASHD_PORT);
}

inline in_port_t
get_tabled_port(in_port_t hostid)
{
    return get_daemonport(hostid, TABLED_PORT);
}

inline std::string
get_tabled_port(const std::string& hostid)
{
    return get_daemonport(hostid, TABLED_PORT);
}

//add by roger at 06/25/10
inline in_port_t
get_verifyd_port(in_port_t hostid)
{
    return get_daemonport(hostid, VERIFYD_PORT);
}

inline std::string
get_verifyd_port(const std::string& hostid)
{
    return get_daemonport(hostid, VERIFYD_PORT);
}

//add by roger at 09/08/10
inline in_port_t
get_infod_port(in_port_t hostid)
{
    return get_daemonport(hostid, INFOD_PORT);
}

inline std::string
get_infod_port(const std::string& hostid)
{
    return get_daemonport(hostid, INFOD_PORT);
}

inline in_port_t
get_replica_port(in_port_t hostid)
{
    return get_daemonport(hostid, REPLICA_PORT);
}

inline std::string
get_replica_port(const std::string& hostid)
{
    return get_daemonport(hostid, REPLICA_PORT);
}

#endif // __DUKE_CORE_BASE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
