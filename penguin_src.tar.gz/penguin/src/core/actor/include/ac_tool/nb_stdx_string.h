#ifndef __DUKE_STDX_STRING_H
#define __DUKE_STDX_STRING_H


// Posix header files

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>

// Duke header files


template <typename _Tp>
inline _Tp
from_string(const std::string& str) {
    assert(!str.empty());
    _Tp x;
    std::istringstream(str) >> x;
    return x;
}

template <typename _Tp>
inline _Tp&
from_string(const std::string& str, _Tp& x) {
    assert(!str.empty());
    std::istringstream iss(str);
    iss >> x;
    return x;
}

template <typename _Tp>
inline std::string
to_string(const _Tp& x) {
    std::ostringstream oss;
    oss << x;
    return oss.str();
}

inline std::string
nb_strerror(const std::string& strprefix = "") {
    char strerr[128] = { 0 };
    strerror_r(errno, strerr, sizeof(strerr));
    return strprefix + strerr;
}

inline std::string::size_type
find_between(const std::string& str, std::string& strresult,
        const std::string& strbegin, const std::string& strend,
        std::string::size_type index = 0)
{
    assert(!str.empty() && !strbegin.empty() && !strend.empty());
    assert(strbegin.size() <= str.size() && strend.size() < str.size());
    std::string::size_type nnext = std::string::npos;
    std::string::size_type nstart = str.find(strbegin, index);
    std::string::size_type nend = str.find(strend, nstart + strbegin.size());
    if (nstart != std::string::npos && nend != std::string::npos) {
        nstart += strbegin.size();
        if (nstart <= nend) {
            nnext = nend + strend.size();
            strresult = str.substr(nstart, nend - nstart);
        }
    }
    return nnext;
}

inline std::string::size_type
find_close_between(const std::string& str, std::string& strresult,
        const std::string& strbegin, const std::string& strend,
        std::string::size_type index = 0)
{
    assert(!str.empty() && !strbegin.empty() && !strend.empty());
    assert(strbegin.size() <= str.size() && strend.size() < str.size());
    std::string::size_type nnext = std::string::npos;
    std::string::size_type nstart = str.find(strbegin, index);
    std::string::size_type nend = str.find(strend, nstart + strbegin.size());
    if (nstart != std::string::npos && nend != std::string::npos) {
        if (nstart <= nend) {
            nnext = nend = nend + strend.size();
            strresult = str.substr(nstart, nend - nstart);
        }
    }
    return nnext;
}

#endif // __DUKE_STDX_STRING_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
