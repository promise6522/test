#ifndef __DUKE_STDX_BUFFER_H
#define __DUKE_STDX_BUFFER_H


// C 89 header files
#include <stdlib.h>

// Boost header file
#include <boost/noncopyable.hpp>


template<typename _Tp>
class auto_buffer_base : private boost::noncopyable
{
public:
    typedef _Tp element_type;
    typedef uint32_t size_type;

public:
    explicit
    auto_buffer_base(element_type* ptr = 0, size_type size = 0) throw()
        : m_ptr(ptr), m_size(size)
    { }

    ~auto_buffer_base() { reset(); }

    element_type*
    data() const throw() { return m_ptr; }

    size_type
    size() const throw() { return m_size; }

    void
    reset(element_type* ptr = 0, size_type size = 0) throw()
    {
        if (ptr != m_ptr)
        {
            if (m_ptr != 0)
                free(m_ptr);
            m_ptr = ptr;
            m_size = size;
        }
    }

protected:
    element_type* m_ptr;
    size_type m_size;
};

template<typename _Tp>
class auto_buffer : public auto_buffer_base<_Tp>
{
public:
    typedef typename auto_buffer_base<_Tp>::element_type element_type;
    typedef typename auto_buffer_base<_Tp>::size_type size_type;
    typedef auto_buffer_base<_Tp> _baseclass;

public:
    explicit
    auto_buffer(element_type* ptr = 0, size_type size = 0) throw()
        : auto_buffer_base<_Tp>(ptr, size)
    { }

    element_type&
    operator*() const throw()
    {
        assert(_baseclass::m_ptr != 0);
        return *_baseclass::m_ptr;
    }

    element_type*
    operator->() const throw()
    {
        assert(_baseclass::m_ptr != 0);
        return _baseclass::m_ptr;
    }
};

template<>
class auto_buffer<void> : public auto_buffer_base<void>
{
public:
    explicit
    auto_buffer(element_type* ptr = 0, size_type size = 0) throw()
        : auto_buffer_base<void>(ptr, size)
    { }
};


#endif // __DUKE_STDX_BUFFER_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
