/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_ID_DISPENSER_IMPL_H_
#define _AC_ID_DISPENSER_IMPL_H_

#include "nb_id.h"
#include "ac_message_type.h"

const std::size_t Default_Id_Block_Size = 0x100;

typedef std::pair<root_committer_id_t, std::size_t> root_committer_id_block;
typedef std::pair<center_committer_id_t, std::size_t> center_committer_id_block;
typedef std::pair<host_committer_id_t, std::size_t> host_committer_id_block;

typedef std::pair<storage_id_t, std::size_t> storage_id_block;
typedef std::pair<anchor_id_t, std::size_t> anchor_id_block;
typedef std::pair<bridge_id_t, std::size_t> bridge_id_block;

class ac_id_dispenser_impl
{
public :
    ac_id_dispenser_impl();    
    ~ac_id_dispenser_impl();

    void initialize();

    void set_host_id(host_id_t host_id);
    host_id_t get_host_id();    
	void set_center_id(center_id_t center_id);
    center_id_t get_center_id();

    //root committer id
    void alloc_rc_id_block();
    root_committer_id_t request_root_committer_id();
    root_committer_id_t get_first_free_rcid();

    //center committer id
    void alloc_cc_id_block();
    center_committer_id_t request_center_committer_id();
    center_committer_id_t get_first_free_ccid();

    //host committer id
    void alloc_hc_id_block();
    host_committer_id_t request_host_committer_id();
    host_committer_id_t get_first_free_hcid();

    //storage id
    void alloc_storage_id_block();
    storage_id_t request_storage_id(std::size_t type);
    storage_id_t get_first_free_storageid();

    //anchor id
    void alloc_anchor_id_block();
    anchor_id_t request_anchor_id();
    anchor_id_t get_first_free_anchorid();

    //bridge id
    bridge_id_t request_bridge_id();
    void alloc_bridge_id_block();
    bridge_id_t get_first_free_bridgeid();
    
    //request id according to host committer id
    nb_id_t request_nb_id(const host_committer_id_t& hc_id, std::size_t type);
    transaction_id_t request_transaction_id(const host_committer_id_t& hc_id);
    facade_id_t request_facade_id(const host_committer_id_t& hc_id);
    access_id_t request_access_id(const host_committer_id_t& hc_id, std::size_t type);
    execution_id_t request_execution_id(const host_committer_id_t& host_comm_id);
    container_id_t request_container_id(const host_committer_id_t& hc_id);

private:
    host_id_t m_host_id;
    center_id_t m_center_id;

    root_committer_id_block m_rc_id_block;
    center_committer_id_block m_cc_id_block;
    host_committer_id_block m_hc_id_block;
    storage_id_block m_storage_id_block;
    anchor_id_block m_anchor_id_block;
    bridge_id_block m_bridge_id_block;
    
    std::map<host_committer_id_t, nb_id_t> m_hcid_nbid_map;
    std::map<host_committer_id_t, transaction_id_t> m_hcid_trid_map;
    std::map<host_committer_id_t, facade_id_t> m_hcid_fdid_map;
    std::map<host_committer_id_t, execution_id_t> m_hcid_exeid_map;
    std::map<host_committer_id_t, access_id_t> m_hcid_acid_map;
    std::map<host_committer_id_t, container_id_t> m_hcid_contid_map;
};

#endif /* _AC_ID_DISPENSER_IMPL_H_ */
