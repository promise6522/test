/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _BRIDGE_IMPL_BASE_H_
#define _BRIDGE_IMPL_BASE_H_

#include <vector>
#include <map>

#include "stdx_json.h"
#include "ac_global.h"
#include "nb_typedef.h"
#include "ac_message_type.h"
#include "ac_bridge_helper.h"

class bridge_impl_base
{
protected:
    bridge_impl_base(ac_bridge_helper * pHelper, const bridge_id_t& bridge_id)
        : m_pHelper(pHelper), m_bridge_id(bridge_id)
    {
        time_t tm;    
        time(&tm);
        m_top_req_num = tm;
    }
    ~bridge_impl_base()
    {
    }    

public:    
    req_num_t generate_req_num()
    {
        return m_top_req_num++;  
    }

    //initialize()
    virtual void initialize(const bridge_content& bridge_content)
    {
        m_bridge_content = bridge_content;
    }
    
    virtual void initialize_with_bridge_content(const bridge_content& data)
    {
    }

    virtual bool run_impl(call_id_t call_id, nb_id_t impl_id)
    {
        return true;        
    }

    virtual bool send_out(call_id_t call_id, const send_out_info& bobj_id)
    {
        return false;        
    }

    virtual bool run_impl_response(req_num_t req_num, run_impl_results& output)
    {
        return true;        
    }
    
    //async function
    virtual bool trigger(call_id_t call_id, const byte_stream& input)
    {
        return true;        
    }

    virtual bool client_response(call_id_t call_id, const byte_stream& input)
    {
        return true;    
    }
    
    virtual bool throw_exeception(req_num_t req_num, std::string exception_string)
    {
        return true;        
    }

    virtual bool ac_bridge_factory_uncreate_bridge_object_response(req_num_t req_num, byte_stream& output)
    {
        return true;        
    }

    virtual bool ac_access_run_response(req_num_t req_num, node_invocation_response& output)
    {
        return true;        
    }

    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        return true;        
    }

    virtual bool ac_object_run_response(req_num_t req_num, node_invocation_response& data)
    {
        return true;        
    }

    virtual bool ac_object_get_value_async_response(req_num_t req_num, content& raw_data)
    {
        return true;        
    }
   
    virtual bool ac_root_committer_pre_commit_response(req_num_t req_num, bool& output)
    {
        return true;
    }

    virtual bool ac_execution_trigger_end_response(req_num_t req_num, bool& output)
    {
        return true;
    }
    
    bool unpack(const std::string& strval)
    {
        return unpack(strval, m_bridge_content);
    }

    bool pack(std::string& strval)
    {
        return pack(m_bridge_content, strval);
    }

    static bool unpack(const std::string& strval, bridge_content& bcont)
    {
        boost::scoped_ptr<stdx::json_object> bridge_root(dynamic_cast<stdx::json_object*>
                                                         (stdx::json_tokener_parse(strval)));
        assert(bridge_root);
        bcont.access_id.str(bridge_root->find("access_id")->get_string());
        bcont.bf_id.str(bridge_root->find("bf_id")->get_string());
        bcont.user_name_id.str(bridge_root->find("user_name_id")->get_string());
        return true;
    }

    static bool pack(const bridge_content& bcont, std::string& strval)
    {
        stdx::json_object bridge_root;
        bridge_root.insert("access_id", new stdx::json_string(bcont.access_id.str()));
        bridge_root.insert("bf_id", new stdx::json_string(bcont.bf_id.str()));
        bridge_root.insert("user_name_id", new stdx::json_string(bcont.user_name_id.str()));
        strval = bridge_root.to_json_string(); 
        return true;
    }

protected:
    ac_bridge_helper* m_pHelper;

    req_num_t m_top_req_num;    
    bridge_id_t m_bridge_id;
    bridge_content m_bridge_content;
};

typedef std::tr1::shared_ptr<bridge_impl_base> bridge_impl_base_ptr;

#endif
