/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_BRIDGE_IMPL_H_
#define _AC_BRIDGE_IMPL_H_

#include <vector>
#include <map>

#include "ac_global.h"
#include "nb_typedef.h"
#include "ac_message_type.h"
#include "bridge_impl_base.h"

struct bridge_info
{
    call_id_t call_id;
    req_num_t req_num;
    byte_stream stream;
    std::string user_name;
    bridge_factory_id_t bf_id;    
    
    root_committer_id_t rc_id;
    center_committer_id_t cc_id;
    host_committer_id_t hc_id;
    transaction_id_t trans_id;
    execution_id_t exe_id;
    
    bool is_run;
    bool is_start;
    bool is_finish;    
    bool is_no_builtin_decl;
    bool is_no_general_decl;
    
    bool is_outgoing;
    bool is_send_out_async;
    bool is_uncreate_done;
    
    nb_id_vector in_objs;
    nb_id_vector out_objs;

    nb_id_t exe_decl;    

    nb_id_vector access_decls;
    nb_id_vector access_start_decls;
    nb_id_t      access_general_decl;

    nb_id_t user_name_id;
    access_id_t outgoing_ac;
    nb_id_vector async_outgoing_ids;

    std::map<nb_id_t, content> decl_data_map;    
};

typedef std::pair<req_num_t, bridge_info> req_info_pair;

class ac_bridge_impl : public bridge_impl_base
{
public:
    ac_bridge_impl(ac_bridge_helper * pHelper, const bridge_id_t& bridge_id);
    ~ac_bridge_impl();

    //initialize()
    virtual void initialize(const bridge_content& bridge_content);
    virtual void initialize_with_bridge_content(const bridge_content& data);    
    
    //save
    void begin_incoming_trigger(req_num_t req_num, call_id_t call_id, const byte_stream& stream);
    void begin_outgoing_trigger(req_num_t req_num, call_id_t call_id,  const send_out_info& out_info);
    void end_incoming_trigger(req_num_t req_num);
    void end_outgoing_trigger(req_num_t req_num);

    //set id in bridge
    void set_access_id(access_id_t access_id)
    {
        m_bridge_content.access_id = access_id;
    }
    void set_bf_id(bridge_factory_id_t bf_id)
    {
        m_bridge_content.bf_id = bf_id;
    }

    //get call_in_id/ac_id/objects according to call_out_id;
    bool get_call_id(req_num_t req_num, call_id_t& call_id);
    
    virtual bool trigger(call_id_t call_id, const byte_stream& input);
    virtual bool client_response(call_id_t call_id, const byte_stream& input);
    virtual bool throw_exeception(req_num_t req_num, std::string exception_string);

    virtual bool ac_bridge_factory_uncreate_bridge_object_response(req_num_t req_num, byte_stream& output);
    virtual bool ac_access_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool exception_handle(req_num_t req_num, const std::string& str);
    virtual bool ac_object_run_response(req_num_t req_num, node_invocation_response& data);
    virtual bool ac_object_get_value_async_response(req_num_t req_num, content& raw_data);
    virtual bool send_out(call_id_t call_id, const send_out_info& bobj_id);
    virtual bool ac_execution_trigger_end_response(req_num_t req_num, bool& output);

private:
    bool create_root_committer(bridge_info& info);
    bool create_center_committer(bridge_info& info);
    bool create_host_committer(bridge_info& info);
    bool create_transaction(bridge_info& info);
    bool create_execution(bridge_info& info);
    bool create_outgoing_access(bridge_info& info);
    bool run_access_decls(bridge_info& info);
    bool find_req_num_by_hc_id(const host_committer_id_t& hc_id, req_num_t& req_num);
    bool uncreate_bridge_object(req_num_t req_num);

private:
    std::map<req_num_t, bridge_info> m_req_info_map;
    bridge_decl_info m_bf_decls_info;
};

#endif /* _AC_BRIDGE_IMPL_H_ */
