/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_BRIDGE_FACTORY_IMPL_H_
#define _AC_BRIDGE_FACTORY_IMPL_H_

#include <set>

#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/exception/all.hpp>

#include "duc.h"
#include "nb_id.h"
#include "ac_bridge_factory_helper.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_bytes.h"
#include "ac_object/obj_impl_exec_impl.h"

struct asyn_pack_bf_info
{
    asyn_pack_bf_info(const nb_id_t& bid, const call_id_t& cid, const req_num_t& rid) 
        : bobj_id(bid), call_id(cid), req_num(rid)
    {
    }
    
    ~asyn_pack_bf_info()
    {
    }
    
    std::set<nb_id_t> waiting_ids;
    std::map<nb_id_t, content> id_cont_map;

    nb_id_t bobj_id;

    //key
    call_id_t call_id;
    req_num_t req_num;
};

typedef boost::multi_index_container<
    asyn_pack_bf_info,
    boost::multi_index::indexed_by< 
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(asyn_pack_bf_info, call_id_t, call_id)>, 
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(asyn_pack_bf_info, req_num_t, req_num)> 
    >
> async_pack_multi_set;

typedef async_pack_multi_set::nth_index<0>::type pack_set_by_call_id;
typedef async_pack_multi_set::nth_index<1>::type pack_set_by_req_num;

struct bridge_factory_info
{
    bridge_factory_info(int32_t num, std::string name, nb_id_t ifid, nb_id_t objid)
        : struct_num(num), struct_name(name), if_id(ifid), obj_id(objid)
    {
    }

    bridge_factory_info(int32_t num, std::string name, nb_id_t ifid,
                        bridge_interface_data_t idata, nb_id_t objid, bridge_data_t odata)
        : struct_num(num), struct_name(name), if_id(ifid), if_data(idata), obj_id(objid), obj_data(odata)
    {
    }

    ~bridge_factory_info()
    {
    }

    int32_t                    struct_num;
    std::string                struct_name;
    
    nb_id_t                    if_id;
    bridge_interface_data_t    if_data;

    nb_id_t                    obj_id;
    bridge_data_t              obj_data;
};

typedef boost::multi_index_container<
    bridge_factory_info,
    boost::multi_index::indexed_by< 
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(bridge_factory_info, int32_t, struct_num)>, 
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(bridge_factory_info, std::string, struct_name)>,
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(bridge_factory_info, nb_id_t, if_id)>,
        boost::multi_index::ordered_unique< 
            BOOST_MULTI_INDEX_MEMBER(bridge_factory_info, nb_id_t, obj_id)>
    >
> bridge_factory_info_set;

typedef bridge_factory_info_set::nth_index<0>::type bf_info_set_by_idx;
typedef bridge_factory_info_set::nth_index<1>::type bf_info_set_by_name;
typedef bridge_factory_info_set::nth_index<2>::type bf_info_set_by_if;
typedef bridge_factory_info_set::nth_index<3>::type bf_info_set_by_obj;

//-----------------exception----------------------------
typedef boost::error_info<struct tag_bif_err_info, std::string> bif_err_info;
typedef boost::error_info<struct tag_bidx_err_info, int32_t> bidx_err_info;
typedef boost::error_info<struct tag_bidx_err_info, UBuffer> ubuf_err_info;
struct create_bobj_error: virtual boost::exception, virtual std::exception { };

class ac_bridge_factory_impl
{
public:
    ac_bridge_factory_impl()
    {
        time_t tm;    
        time(&tm);
        m_top_req_num = tm;
    }
    
    ~ac_bridge_factory_impl()
    {
    }

    void set_ac_helper(ac_bridge_factory_helper * pHelper)
    {
        m_pHelper = pHelper;
    }

    void set_bridge_factory_id(const bridge_factory_id_t& bf_id)
    {
        m_bf_id = bf_id;
    }

    //for create bridge factory
    bool load_bridge_factory();
    bool create_bridge_factory();
    bool save_bridge_factory();
    bool ac_object_db_write_response(req_num_t req_num, int& output);
    bool ac_object_db_commit_response(req_num_t req_num, bool& output);

    //for create/uncreate bridge object
    bool create_bridge_object(const host_committer_id_t& hc_id, UBuffer& buf, nb_id_t& output);
    bool uncreate_bridge_object(call_id_t call_id, const nb_id_t& obj_id);
    bool ac_object_get_value_async_response(req_num_t req_num, content& obj_cont);

    //get bridge factory infomation
    nb_id_t get_ifid_by_idx(const int32_t& index);    
    nb_id_t get_ifid_by_name(const std::string& name);    
    bridge_interface_data_t get_bif_data_by_id(const nb_id_t& bif_id);

    //get bridge factory decls
    bridge_decl_info get_bf_decl_info();
    nb_id_t get_outgoing_ac_if();

    bool pack(std::string& str_value);
    bool unpack(const std::string& str_value);
    static bool pack(const bridge_factory_info_set& bf_info_set, const bridge_decl_info& decl_ids, const nb_id_t& out_ac_if,
                     bridge_factory_id_t bf_id, std::string& str_value);
    static bool unpack(const std::string& str_value, bridge_factory_id_t bf_id,
                       bridge_factory_info_set& bf_info_set, bridge_decl_info& decl_ids, nb_id_t& out_ac_if);

private:
    //generator the req_num
    req_num_t generate_req_num()
    {
        return m_top_req_num++;
    }

    //for genenrate the bridge factory element. (only once)
    void generate_bridge_factory_stuff(const std::vector<nb_bridge_struct_desc*>& bf_info,
                                       const host_committer_id_t& hc_id);
    bool generate_sub_bridge_item(nb_bridge_field_desc* fd, host_committer_id_t hc_id, nb_id_t& obj_id,
                                  nb_id_t& if_id, db_value& bf_raw_datas);
    void generate_bridge_object_additional_info(const host_committer_id_t& hc_id,
                                      bridge_factory_info& bf_info, db_value& bf_raw_datas);
    void generate_bridge_object_descriptor(const host_committer_id_t& hc_id,
                                           bridge_factory_info& bf_info, db_value& bf_raw_datas);
    func_vector generate_bridge_object_funcs(const host_committer_id_t& hc_id,
                                             bridge_factory_info& bf_info, db_value& bf_raw_datas);
    nb_id_t generate_bridge_object_set_decl(std::size_t pos, const host_committer_id_t& hc_id,
                                            bridge_factory_info& bf_info, db_value& bf_raw_datas);
    nb_id_t generate_bridge_object_set_impl(std::size_t pos, const nb_id_t& decl_id,
                                            const host_committer_id_t& hc_id,
                                            bridge_factory_info& bf_info, db_value& bf_raw_datas);
    nb_id_t generate_bridge_object_get_decl(std::size_t pos, const host_committer_id_t& hc_id,
                                            bridge_factory_info& bf_info, db_value& bf_raw_datas);
    nb_id_t generate_bridge_object_get_impl(std::size_t pos, const nb_id_t& decl_id,
                                            const host_committer_id_t& hc_id,
                                            bridge_factory_info& bf_info, db_value& bf_raw_datas);
    nb_id_t generate_exec_obj_func(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                   db_value& bf_raw_datas);
    void generate_out_path_info(exec_impl_graph_t& impl_data);
    void generate_ss_table_info(exec_impl_graph_t& impl_data,
                                const std::map<nb_id_t, nb_id_t>& node_decl_map,
                                const std::map<nb_id_t, int>& decl_inum_map);
    void generate_array_expanded_decls(const nb_id_t& if_id, const host_committer_id_t& hc_id,
                                       if_compound_data_t& ifc_data,db_value& bf_raw_datas);    

    //for un-create bridge object
    void pre_uncreate_bridge_object(call_id_t call_id, const nb_id_t& obj_id);
    void recur_uncreate_bridge_object(const nb_id_t& obj_id, const asyn_pack_bf_info& info, UBuffer& buf);
    void real_uncreate_bridge_object(req_num_t req_num);
    bool check_pre_uncreate_completed(req_num_t req_num);
    void unpack_string_object(std::string& str, UBuffer& buf);
    void unpack_int_object(int32_t d, UBuffer& buf);
    void unpack_array_object(array_data_t& array, const asyn_pack_bf_info& info, UBuffer& buf);
    void unpack_bridge_object(const bridge_data_t& data, const asyn_pack_bf_info& info, UBuffer& buf);

    //for create bridge object
    nb_id_t pack(const host_committer_id_t& hc_id, 
                   const nb_id_t& if_id, const std::string& tx, UBuffer& buf);
    nb_id_t pack_string_object(const host_committer_id_t& hc_id, UBuffer& buf);
    nb_id_t pack_bytes_object(const host_committer_id_t& hc_id, UBuffer& buf);
    nb_id_t pack_builtin_object(const host_committer_id_t& hc_id, const nb_id_t& if_id, UBuffer& buf);
    nb_id_t pack_array_object(const host_committer_id_t& hc_id, const nb_id_t& if_id, UBuffer& buf);
    nb_id_t pack_bridge_object(const host_committer_id_t& hc_id, UBuffer& buf);
    void pack(std::string& d, UBuffer& buf);
    int32_t check_type(PACKTYPE t, UBuffer& buf);
    nb_id_t create_bridge_object(const host_committer_id_t& hc_id, const nb_id_t& if_id, UBuffer& buf);

    //for dump bridge factory info
    void dump_bridge_factory();    

private:
    bridge_factory_id_t                           m_bf_id;

    async_pack_multi_set                          m_async_pack_set;
    bridge_factory_info_set                       m_bf_info_set;
    bridge_decl_info                              m_bf_decls;
    nb_id_t                                       m_out_ac_if;

    req_num_t                                     m_top_req_num;    
    ac_bridge_factory_helper*                     m_pHelper;    
};

const req_num_t write_bf_init_req_num(0, true);

#endif /* _AC_BRIDGE_IMPL_H_ */
