/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _BRIDGE_IMPL_EXE_H_
#define _BRIDGE_IMPL_EXE_H_

#include "bridge_impl_base.h"
#include "ac_object/obj_impl_string.h"

struct bridge_exe_info
{
    call_id_t call_id;
    req_num_t req_num;
    nb_id_t impl_id;
    nb_id_vector outputs;

    root_committer_id_t rc_id;
    center_committer_id_t cc_id;
    host_committer_id_t hc_id;
    transaction_id_t trans_id;
    execution_id_t exe_id;
    bool is_corpse_run;
};

typedef std::pair<req_num_t, bridge_exe_info> req_exeinfo_pair;

class bridge_impl_exe : public bridge_impl_base
{
public:
    bridge_impl_exe(ac_bridge_helper * pHelper, const bridge_id_t& bridge_id)
        : bridge_impl_base(pHelper, bridge_id)
    {
    }

    ~bridge_impl_exe()
    {
    }

    virtual bool run_impl(call_id_t call_id, nb_id_t impl_id);
    virtual bool ac_object_run_response(req_num_t req_num, node_invocation_response& data);
    virtual bool ac_execution_trigger_end_response(req_num_t req_num, bool& output);

private:
    void begin_incoming_execution(req_num_t req_num, call_id_t call_id, const nb_id_t& impl_id);
    void end_incoming_execution(req_num_t req_num);    
    
    bool create_root_committer(bridge_exe_info& info);
    bool create_center_committer(bridge_exe_info& info);
    bool create_host_committer(bridge_exe_info& info);
    bool create_transaction(bridge_exe_info& info);
    bool create_execution(bridge_exe_info& info);

private:
    std::map<req_num_t, bridge_exe_info> m_req_info_map;
};


#endif
