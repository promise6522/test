#ifndef __OBJ_IMPL_MAP_H
#define __OBJ_IMPL_MAP_H

#include "obj_impl_base.h"

struct map_data_t
{
    std::string name;
    /*
    ** type : interface_expanded
    ** groups[0].min_if is the key interface
    ** groups[1].min_if is the value interface
    */
	nb_id_t type;

    /*
    ** data : content of the map
    */
	std::map<nb_id_t, nb_id_t> data;

    bool operator== (const map_data_t& val)
    {
         return  this->type == val.type &&
                 this->data == val.data;
	}
};

class obj_impl_map : public object_implementation_base
{
protected:
	map_data_t m_cData;

public:
    obj_impl_map(const nb_id_t& obj_id, 
            const content& raw_data, 
            ac_object_helper * pHelper);
    virtual ~obj_impl_map();

	bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const map_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool json_unpack(const content& raw_data, 
            nb_id_t& id,
            map_data_t& logic_data);

    static bool pack(const map_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool unpack(const content& raw_data, 
            nb_id_t& id,
            map_data_t& logic_data);

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);
    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }


};


#endif // __OBJ_IMPL_MAP_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
