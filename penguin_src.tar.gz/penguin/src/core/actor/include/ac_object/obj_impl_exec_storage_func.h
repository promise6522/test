#ifndef __OBJ_IMPL_EXEC_STORAGE_FUNC_H
#define __OBJ_IMPL_EXEC_STORAGE_FUNC_H

#include "obj_impl_base.h"

struct exec_storage_func_data_t
{
    std::string name;
    int storage_idx;
    nb_id_t selected_decl;

	bool operator== (const exec_storage_func_data_t& val){
		return this->name == val.name &&
				this->storage_idx == val.storage_idx &&
				this->selected_decl == val.selected_decl;
	}
};

class obj_impl_exec_storage_func : public object_implementation_base
{
protected:
    exec_storage_func_data_t m_cData;
public:
	obj_impl_exec_storage_func(); 
    obj_impl_exec_storage_func(const nb_id_t& obj_id, 
            const content& raw_data, 
            ac_object_helper * pHelper);
    virtual ~obj_impl_exec_storage_func();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }


    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const exec_storage_func_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool json_unpack(const content& raw_data, 
            nb_id_t& id,
            exec_storage_func_data_t& logic_data);

    static bool pack(const exec_storage_func_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool unpack(const content& raw_data, 
            nb_id_t& id,
            exec_storage_func_data_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }


};


#endif // __OBJ_IMPL_EXEC_STORAGE_FUNC_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
