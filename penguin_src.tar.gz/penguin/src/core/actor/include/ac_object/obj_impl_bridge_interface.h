#ifndef __OBJ_IMPL_BRIDGE_INTERFACE_H
#define __OBJ_IMPL_BRIDGE_INTERFACE_H

#include "obj_impl_interface_compound.h"

struct bridge_interface_data_t
{
    bridge_factory_id_t       bf_id;
    int32_t                   data_index;   
    std::string               external_name;    

    nb_id_vector              sub_interfaces;
    std::vector<std::string>  sub_names;
    nb_id_vector              decls;
    
    bool operator==(const bridge_interface_data_t& des)
    {
        return (bf_id == des.bf_id) && (data_index == des.data_index) && (external_name == des.external_name)
            && (sub_interfaces == des.sub_interfaces) && (sub_names == des.sub_names)
            && (decls == des.decls);
    }
};

class obj_impl_bridge_interface : public object_implementation_base
{
protected:
    bridge_interface_data_t m_cData;
    nb_id_vector m_builtin_ins;
public:
	obj_impl_bridge_interface();
    obj_impl_bridge_interface(const nb_id_t& obj_id, 
            const content& raw_data,
            ac_object_helper * pHelper);
	virtual ~obj_impl_bridge_interface();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

    bool get_value(content& data);
    bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output);
    virtual bool set_property(const property_info& input);

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const bridge_interface_data_t& logic_data, const nb_id_t& id, content& raw_data );
    static bool json_unpack(const content& raw_data, nb_id_t& id, bridge_interface_data_t& logic_data);

    static bool pack(const bridge_interface_data_t& logic_data, const nb_id_t& id, content& raw_data);
    static bool unpack(const content& raw_data, nb_id_t& id, bridge_interface_data_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
};

#endif // __OBJ_IMPL_BRIDGE_INTERFACE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
