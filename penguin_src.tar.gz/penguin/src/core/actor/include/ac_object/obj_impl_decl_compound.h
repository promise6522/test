#ifndef __OBJ_IMPL_DECL_COMPOUND_H
#define __OBJ_IMPL_DECL_COMPOUND_H

#include "obj_impl_base.h"

struct iport_t
{
    std::string name;
    nb_id_t interface;
    nb_id_t default_value;

	bool operator== (const iport_t& val){
		return this->name == val.name &&
				this->interface == val.interface &&
				this->default_value == val.default_value;
	}
};

struct oport_t
{
    std::string name;
    nb_id_t interface;

	bool operator== (const oport_t& val){
		return this->name == val.name &&
				this->interface == val.interface;
	}
};

struct decl_exp_idx
{
    bool is_input;
    int port_idx;
    int relay_idx;

	bool operator== (const decl_exp_idx& val){
		return this->is_input == val.is_input &&
				this->port_idx == val.port_idx &&
				this->relay_idx == val.relay_idx;
	}
};

struct decl_exp_group
{
    std::string name;
    nb_id_t min_if;
    std::vector<decl_exp_idx> members;
    bool expanded;

	bool operator== (const decl_exp_group& val){
		return this->name == val.name &&
				this->min_if == val.min_if &&
				this->members.size() == val.members.size() &&
                std::equal(this->members.begin(), this->members.end(), val.members.begin()) &&
				this->expanded == val.expanded;
	}
};

struct decl_compound_data_t 
{
    std::string name;
    nb_id_t visualInformation;
    std::vector<iport_t> iports;
    std::vector<oport_t> oports;
    std::vector<decl_exp_group> groups;

	bool operator== (const decl_compound_data_t& val){
		return this->name == val.name &&
                this->visualInformation == val.visualInformation &&
               this->iports.size() == val.iports.size() &&
               this->oports.size() == val.oports.size() &&
               this->groups.size() == val.groups.size() &&
			   std::equal(this->iports.begin(), this->iports.end(), val.iports.begin()) &&
			   std::equal(this->oports.begin(), this->oports.end(), val.oports.begin()) &&
			   std::equal(this->groups.begin(), this->groups.end(), val.groups.begin());
	}
};

class obj_impl_decl_compound : public object_implementation_base
{
protected:
    decl_compound_data_t m_cData;

public :
    obj_impl_decl_compound()
    {
    };

    obj_impl_decl_compound(const nb_id_t& obj_id, 
            const content& raw_data,
            ac_object_helper * pHelper);
    virtual ~obj_impl_decl_compound();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const decl_compound_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool json_unpack(const content& raw_data, 
            nb_id_t& id,
            decl_compound_data_t& logic_data);

    static bool pack(const decl_compound_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool unpack(const content& raw_data, 
            nb_id_t& id,
            decl_compound_data_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }


};

#endif // __OBJ_IMPL_DECL_COMPOUND_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
