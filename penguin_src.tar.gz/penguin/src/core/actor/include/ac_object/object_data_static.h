#ifndef __OBJECT_DATA_STATIC_H
#define __OBJECT_DATA_STATIC_H

#include <vector>
#include <string>

#include "nb_id.h"
#include "nb_typedef.h"

/********************************** object base ***********************************/

class object_data_static_base
{
public:
    static void get_general_interface(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_GENERAL_IS_NULL);
        vid.push_back(NB_FUNC_GENERAL_IS_SINGLETON);
        vid.push_back(NB_FUNC_GENERAL_IS_JUSTID);
        vid.push_back(NB_FUNC_GENERAL_IS_BUILTIN);
        vid.push_back(NB_FUNC_GENERAL_IS_EXPORTABLE);
        vid.push_back(NB_FUNC_GENERAL_IS_LOCAL);
        vid.push_back(NB_FUNC_GENERAL_IS_VALUECOMPARED);
        vid.push_back(NB_FUNC_GENERAL_EXCEPTION_IF_NULL);
        vid.push_back(NB_FUNC_GENERAL_COMPARE);
        vid.push_back(NB_FUNC_GENERAL_GET_INTERFACE);
        vid.push_back(NB_FUNC_GENERAL_RUN);
    }

    static bool get_general_declaration(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_GENERAL_IS_NULL:
        case NB_FUNC_GENERAL_IS_SINGLETON:
        case NB_FUNC_GENERAL_IS_JUSTID:
        case NB_FUNC_GENERAL_IS_BUILTIN:
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
        case NB_FUNC_GENERAL_IS_LOCAL:
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            make_iany_obool_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            make_iany_oany_declaration(in, out);
            break;
        case NB_FUNC_GENERAL_COMPARE:
            make_i2any_o6bool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static bool get_general_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_GENERAL_IS_NULL:
            name = "is null";
            break;
        case NB_FUNC_GENERAL_IS_SINGLETON:
            name = "is singleton";
            break;
        case NB_FUNC_GENERAL_IS_JUSTID:
            name = "is just id";
            break;
        case NB_FUNC_GENERAL_IS_BUILTIN:
            name = "is builtin";
            break;
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
            name = "is exportable";
            break;
        case NB_FUNC_GENERAL_IS_LOCAL:
            name = "is local";
            break;
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            name = "is value compared";
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            name = "exception if null";
            break;
        case NB_FUNC_GENERAL_COMPARE:
            name = "compare";
            break;
        case NB_FUNC_GENERAL_GET_INTERFACE:
            name = "get interface";
            break;
        case NB_FUNC_GENERAL_RUN:
            name = "run";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iany_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        out.push_back(hb);
    }

    static void make_iany_idecl_iany_ibool_oany_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        in.push_back(hn);
        in.push_back(hb);
        out.push_back(hn);
    }

    static void make_iany_idecl_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        nb_id_t harr(NB_INTERFACE_ARRAY);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        out.push_back(harr);
    }

    static void make_iany_idecl_oany_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        in.push_back(hn);
        in.push_back(hn);// TODO decl
        out.push_back(hn);
    }

    static void make_iany_oany_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        in.push_back(hn);
        out.push_back(hn);
    }

    static void make_i2any_o6bool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hn(NB_INTERFACE_NONE);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hn);
        in.push_back(hn);
        out.push_back(hb);
        out.push_back(hb);
        out.push_back(hb);
        out.push_back(hb);
        out.push_back(hb);
        out.push_back(hb);
    }
};

/********************************** built-in objects ***********************************/

class object_data_static_none : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "none";
        return true;
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        get_general_interface(vid);
    }
};

class object_data_static_boolean : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "boolean";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BOOL_NOT:
            name = "not";
            break;
        case NB_FUNC_BOOL_AND:
            name = "and";
            break;
        case NB_FUNC_BOOL_OR:
            name = "or";
            break;
        case NB_FUNC_BOOL_EQ:
            name = "eq";
            break;
        case NB_FUNC_BOOL_NE:
            name = "ne";
            break;
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
            name = "exception true";
            break;
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
            name = "exception false";
            break;
        case NB_FUNC_BOOL_BREAK_TRUE:
            name = "break true";
            break;
        case NB_FUNC_BOOL_BREAK_FALSE:
            name = "break false";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("not");
        vstr.push_back("and");
        vstr.push_back("or");
        vstr.push_back("eq");
        vstr.push_back("ne");
        vstr.push_back("exception true");
        vstr.push_back("exception false");
        vstr.push_back("break true");
        vstr.push_back("break false");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_BOOL_NOT);
        vid.push_back(NB_FUNC_BOOL_AND);
        vid.push_back(NB_FUNC_BOOL_OR);
        vid.push_back(NB_FUNC_BOOL_EQ);
        vid.push_back(NB_FUNC_BOOL_NE);
        vid.push_back(NB_FUNC_BOOL_EXCEPTION_TRUE);
        vid.push_back(NB_FUNC_BOOL_EXCEPTION_FALSE);
        vid.push_back(NB_FUNC_BOOL_BREAK_TRUE);
        vid.push_back(NB_FUNC_BOOL_BREAK_FALSE);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BOOL_NOT:
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
        case NB_FUNC_BOOL_BREAK_TRUE:
        case NB_FUNC_BOOL_BREAK_FALSE:
            make_ibool_obool_declaration(in, out);
            break;
        case NB_FUNC_BOOL_AND:
        case NB_FUNC_BOOL_OR:
        case NB_FUNC_BOOL_EQ:
        case NB_FUNC_BOOL_NE:
            make_ibool_ibool_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hb);
        out.push_back(hb);
    }

    static void make_ibool_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hb);
        in.push_back(hb);
        out.push_back(hb);
    }
};

class object_data_static_integer : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "integer";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INT_ADD:
            name = "add";
            break;
        case NB_FUNC_INT_SUB:
            name = "sub";
            break;
        case NB_FUNC_INT_IMUL:
            name = "imul";
            break;
        case NB_FUNC_INT_IDIV:
            name = "idiv";
            break;
        case NB_FUNC_INT_EQ:
            name = "eq";
            break;
        case NB_FUNC_INT_LT:
            name = "lt";
            break;
        case NB_FUNC_INT_INC:
            name = "inc";
            break;
        case NB_FUNC_INT_DEC:
            name = "dec";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("imul");
        vstr.push_back("idiv");
        vstr.push_back("eq");
        vstr.push_back("lt");
        vstr.push_back("inc");
        vstr.push_back("dec");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_INT_ADD);
        vid.push_back(NB_FUNC_INT_SUB);
        vid.push_back(NB_FUNC_INT_IMUL);
        vid.push_back(NB_FUNC_INT_IDIV);
        vid.push_back(NB_FUNC_INT_EQ);
        vid.push_back(NB_FUNC_INT_LT);
        vid.push_back(NB_FUNC_INT_INC);
        vid.push_back(NB_FUNC_INT_DEC);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INT_ADD:
        case NB_FUNC_INT_SUB:
        case NB_FUNC_INT_IMUL:
        case NB_FUNC_INT_IDIV:
            make_iint_iint_oint_declaration(in, out);
            break;
        case NB_FUNC_INT_EQ:
        case NB_FUNC_INT_LT:
            make_iint_iint_obool_declaration(in, out);
            break;
        case NB_FUNC_INT_INC:
        case NB_FUNC_INT_DEC:
            make_iint_oint_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iint_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hi);
    }

    static void make_iint_iint_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_INT);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hb);
    }

    static void make_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hi);
        out.push_back(hi);
    }
};

class object_data_static_float : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "float";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_FLOAT_ADD:
            name = "add";
            break;
        case NB_FUNC_FLOAT_SUB:
            name = "sub";
            break;
        case NB_FUNC_FLOAT_IMUL:
            name = "imul";
            break;
        case NB_FUNC_FLOAT_IDIV:
            name = "idiv";
            break;
        case NB_FUNC_FLOAT_EQ:
            name = "eq";
            break;
        case NB_FUNC_FLOAT_LT:
            name = "lt";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("imul");
        vstr.push_back("idiv");
        vstr.push_back("eq");
        vstr.push_back("lt");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_FLOAT_ADD);
        vid.push_back(NB_FUNC_FLOAT_SUB);
        vid.push_back(NB_FUNC_FLOAT_IMUL);
        vid.push_back(NB_FUNC_FLOAT_IDIV);
        vid.push_back(NB_FUNC_FLOAT_EQ);
        vid.push_back(NB_FUNC_FLOAT_LT);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_FLOAT_ADD:
        case NB_FUNC_FLOAT_SUB:
        case NB_FUNC_FLOAT_IMUL:
        case NB_FUNC_FLOAT_IDIV:
            make_ifloat_ifloat_ofloat_declaration(in, out);
            break;
        case NB_FUNC_FLOAT_EQ:
        case NB_FUNC_FLOAT_LT:
            make_ifloat_ifloat_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ifloat_ifloat_ofloat_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hf(NB_INTERFACE_FLOAT);
        in.push_back(hf);
        in.push_back(hf);
        out.push_back(hf);
    }

    static void make_ifloat_ifloat_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hf(NB_INTERFACE_FLOAT);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hf);
        in.push_back(hf);
        out.push_back(hb);
    }
};

class object_data_static_string : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "string";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_STR_APPEND:
            name = "append";
            break;
        case NB_FUNC_STR_SUBSTR:
            name = "sub str";
            break;
        case NB_FUNC_STR_SIZE:
            name = "size";
            break;
        case NB_FUNC_STR_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_STR_COMPARE:
            name = "string compare";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("append");
        vstr.push_back("sub str");
        vstr.push_back("size");
        vstr.push_back("split at");
        vstr.push_back("string compare");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_STR_APPEND);
        vid.push_back(NB_FUNC_STR_SUBSTR);
        vid.push_back(NB_FUNC_STR_SIZE);
        vid.push_back(NB_FUNC_STR_SPLITAT);
        vid.push_back(NB_FUNC_STR_COMPARE);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_STR_APPEND:
            make_istr_istr_ostr_declaration(in, out);
            break;
        case NB_FUNC_STR_SUBSTR:
            make_istr_iint_iint_ostr_declaration(in, out);
            break;
        case NB_FUNC_STR_SIZE:
            make_istr_oint_declaration(in, out);
            break;
        case NB_FUNC_STR_SPLITAT:
            make_istr_iint_ostr_ostr_declaration(in, out);
            break;
        case NB_FUNC_STR_COMPARE:
            make_istr_istr_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_istr_istr_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hs(NB_INTERFACE_STRING);
        in.push_back(hs);
        in.push_back(hs);
        out.push_back(hs);
    }

    static void make_istr_iint_iint_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hs(NB_INTERFACE_STRING);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hs);
    }

    static void make_istr_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hs(NB_INTERFACE_STRING);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        out.push_back(hi);
    }

    static void make_istr_iint_ostr_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hs(NB_INTERFACE_STRING);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hs);
        in.push_back(hi);
        out.push_back(hs);
        out.push_back(hs);
    }

    static void make_istr_istr_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hs(NB_INTERFACE_STRING);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(hs);
        in.push_back(hs);
        out.push_back(hb);
    }
};

class object_data_static_bytes : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "bytes";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BYTES_JOIN:
            name = "join";
            break;
        case NB_FUNC_BYTES_RANGE:
            name = "range";
            break;
        case NB_FUNC_BYTES_SIZE:
            name = "size";
            break;
        case NB_FUNC_BYTES_SPLIT:
            name = "split";
            break;
        case NB_FUNC_BYTES_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_BYTES_CRC:
            name = "crc";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("join");
        vstr.push_back("range");
        vstr.push_back("size");
        vstr.push_back("split");
        vstr.push_back("split at");
        vstr.push_back("crc");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_BYTES_JOIN);
        vid.push_back(NB_FUNC_BYTES_RANGE);
        vid.push_back(NB_FUNC_BYTES_SIZE);
        vid.push_back(NB_FUNC_BYTES_SPLIT);
        vid.push_back(NB_FUNC_BYTES_SPLITAT);
        vid.push_back(NB_FUNC_BYTES_CRC);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_BYTES_JOIN:
            make_ibyte_ibyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_RANGE:
            make_ibyte_iint_iint_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SIZE:
            make_ibyte_oint_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SPLIT:
            make_ibyte_obyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_SPLITAT:
            make_ibyte_iint_obyte_obyte_declaration(in, out);
            break;
        case NB_FUNC_BYTES_CRC:
            make_ibyte_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_ibyte_ibyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        in.push_back(hbs);
        in.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_iint_iint_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(hbs);
    }

    static void make_ibyte_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        out.push_back(hi);
    }

    static void make_ibyte_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        in.push_back(hbs);
        out.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_iint_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hbs);
        in.push_back(hi);
        out.push_back(hbs);
        out.push_back(hbs);
    }

    static void make_ibyte_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hbs(NB_INTERFACE_BYTES);
        nb_id_t hb(NB_INTERFACE_INT);
        in.push_back(hbs);
        out.push_back(hb);
    }
};

class object_data_static_interval : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "interval";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INTERVAL_GET:
            name = "get";
            break;
        case NB_FUNC_INTERVAL_ADD:
            name = "add";
            break;
        case NB_FUNC_INTERVAL_SUB:
            name = "sub";
            break;
        case NB_FUNC_INTERVAL_MUL:
            name = "mul";
            break;
        case NB_FUNC_INTERVAL_DIV:
            name = "div";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("add");
        vstr.push_back("sub");
//        vstr.push_back("mul");
//        vstr.push_back("div");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_INTERVAL_GET);
        vid.push_back(NB_FUNC_INTERVAL_ADD);
        vid.push_back(NB_FUNC_INTERVAL_SUB);
//        vid.push_back(NB_FUNC_INTERVAL_MUL);
//        vid.push_back(NB_FUNC_INTERVAL_DIV);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_INTERVAL_GET:
            make_iitv_o10int_declaration(in, out);
            break;
        case NB_FUNC_INTERVAL_ADD:
        case NB_FUNC_INTERVAL_SUB:
            make_iitv_iitv_oitv_declaration(in, out);
            break;
//        case NB_FUNC_INTERVAL_MUL:
//        case NB_FUNC_INTERVAL_DIV:
//            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iitv_o10int_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hitv(NB_INTERFACE_INTERVAL);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hitv);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
    }

    static void make_iitv_iitv_oitv_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hitv(NB_INTERFACE_INTERVAL);
        in.push_back(hitv);
        in.push_back(hitv);
        out.push_back(hitv);
    }
};

class object_data_static_time : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "time";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_TIME_GET:
            name = "get";
            break;
        case NB_FUNC_TIME_ADD:
            name = "add";
            break;
        case NB_FUNC_TIME_SUB:
            name = "sub";
            break;
        case NB_FUNC_TIME_CURRENT:
            name = "current time";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("add");
        vstr.push_back("sub");
        vstr.push_back("current time");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_TIME_GET);
        vid.push_back(NB_FUNC_TIME_ADD);
        vid.push_back(NB_FUNC_TIME_SUB);
        vid.push_back(NB_FUNC_TIME_CURRENT);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_TIME_GET:
        case NB_FUNC_TIME_CURRENT:
            make_itime_o10int_declaration(in, out);
            break;
        case NB_FUNC_TIME_ADD:
        case NB_FUNC_TIME_SUB:
            make_itime_iitv_otime_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_itime_o10int_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t ht(NB_INTERFACE_TIME);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(ht);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
        out.push_back(hi);
    }

    static void make_itime_iitv_otime_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t ht(NB_INTERFACE_TIME);
        nb_id_t hitv(NB_INTERFACE_INTERVAL);
        in.push_back(ht);
        in.push_back(hitv);
        out.push_back(ht);
    }
};

class object_data_static_array : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "array";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ARRAY_GET:
            name = "get";
            break;
        case NB_FUNC_ARRAY_GETHEAD:
            name = "get head";
            break;
        case NB_FUNC_ARRAY_GETTAIL:
            name = "get tail";
            break;
        case NB_FUNC_ARRAY_ADDHEAD:
            name = "add head";
            break;
        case NB_FUNC_ARRAY_ADDTAIL:
            name = "add tail";
            break;
        case NB_FUNC_ARRAY_REVERSE:
            name = "reverse";
            break;
        case NB_FUNC_ARRAY_INSERT:
            name = "insert";
            break;
        case NB_FUNC_ARRAY_JOIN:
            name = "join";
            break;
        case NB_FUNC_ARRAY_RANGE:
            name = "range";
            break;
        case NB_FUNC_ARRAY_SIZE:
            name = "size";
            break;
        case NB_FUNC_ARRAY_SPLIT:
            name = "split";
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_ARRAY_UNIONSET:
            name = "union set";
            break;
        case NB_FUNC_ARRAY_INTERSECTIONSET:
            name = "intersection set";
            break;
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            name = "complementary set";
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            name = "inclusion";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("get head");
        vstr.push_back("get tail");
        vstr.push_back("add head");
        vstr.push_back("add tail");
        vstr.push_back("reverse");
        vstr.push_back("insert");
        vstr.push_back("join");
        vstr.push_back("range");
        vstr.push_back("size");
        vstr.push_back("split");
        vstr.push_back("split at");
        vstr.push_back("union set");
        vstr.push_back("intersection set");
        vstr.push_back("complementary set");
        vstr.push_back("inclusion");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_ARRAY_GET);
        vid.push_back(NB_FUNC_ARRAY_GETHEAD);
        vid.push_back(NB_FUNC_ARRAY_GETTAIL);
        vid.push_back(NB_FUNC_ARRAY_ADDHEAD);
        vid.push_back(NB_FUNC_ARRAY_ADDTAIL);
        vid.push_back(NB_FUNC_ARRAY_REVERSE);
        vid.push_back(NB_FUNC_ARRAY_INSERT);
        vid.push_back(NB_FUNC_ARRAY_JOIN);
        vid.push_back(NB_FUNC_ARRAY_RANGE);
        vid.push_back(NB_FUNC_ARRAY_SIZE);
        vid.push_back(NB_FUNC_ARRAY_SPLIT);
        vid.push_back(NB_FUNC_ARRAY_SPLITAT);
        vid.push_back(NB_FUNC_ARRAY_UNIONSET);
        vid.push_back(NB_FUNC_ARRAY_INTERSECTIONSET);
        vid.push_back(NB_FUNC_ARRAY_COMPLEMENTARYSET);
        vid.push_back(NB_FUNC_ARRAY_INCLUSION);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_ARRAY_GET:
            make_iarray_iint_oany_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_INSERT:
            make_iarray_iany_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_JOIN:
        case NB_FUNC_ARRAY_UNIONSET:
        case NB_FUNC_ARRAY_INTERSECTIONSET:
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            make_iarray_iarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_RANGE:
            make_iarray_iint_iint_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SIZE:
            make_iarray_oint_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SPLIT:
            make_iarray_oarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            make_iarray_iint_oarray_oarray_declaration(in, out);
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            make_iarray_iarray_obool_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_iarray_iint_oany_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hi(NB_INTERFACE_INT);
        nb_id_t hn(NB_INTERFACE_NONE);
        in.push_back(har);
        in.push_back(hi);
        out.push_back(hn);
    }

    static void make_iarray_iany_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hn(NB_INTERFACE_NONE);
        in.push_back(har);
        in.push_back(hn);
        out.push_back(har);
    }

    static void make_iarray_iarray_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        in.push_back(har);
        in.push_back(har);
        out.push_back(har);
    }

    static void make_iarray_iint_iint_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        in.push_back(hi);
        in.push_back(hi);
        out.push_back(har);
    }

    static void make_iarray_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        out.push_back(hi);
    }

    static void make_iarray_oarray_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        in.push_back(har);
        out.push_back(har);
        out.push_back(har);
    }

    static void make_iarray_iint_oarray_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(har);
        in.push_back(hi);
        out.push_back(har);
        out.push_back(hi);
    }

    static void make_iarray_iarray_obool_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t har(NB_INTERFACE_ARRAY);
        nb_id_t hb(NB_INTERFACE_BOOL);
        in.push_back(har);
        in.push_back(har);
        out.push_back(hb);
    }
};

class object_data_static_map : public object_data_static_base
{
public:
    static bool get_name(std::string& name)
    {
        name = "map";
        return true;
    }

    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_MAP_GET:
            name = "get";
            break;
        case NB_FUNC_MAP_INSERT:
            name = "insert";
            break;
        case NB_FUNC_MAP_SIZE:
            name = "size";
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            name = "get all keys";
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
        vstr.push_back("get");
        vstr.push_back("insert");
        vstr.push_back("size");
        vstr.push_back("get all keys");
    }

    static void get_builtin_instructions(nb_id_vector& vid)
    {
        vid.push_back(NB_FUNC_MAP_GET);
        vid.push_back(NB_FUNC_MAP_INSERT);
        vid.push_back(NB_FUNC_MAP_SIZE);
        vid.push_back(NB_FUNC_MAP_GETALLKEYS);
        get_general_interface(vid);
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        bool ret = true;
        switch (hdecl.get_func_type())
        {
        case NB_FUNC_MAP_GET:
            make_imap_iany_oarray_declaration(in, out);
            break;
        case NB_FUNC_MAP_INSERT:
            make_imap_iany_iany_omap_declaration(in, out);
            break;
        case NB_FUNC_MAP_SIZE:
            make_imap_oint_declaration(in, out);
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            make_imap_oarray_declaration(in, out);
            break;
        default:
            ret = false;
            break;
        }
        return ret;
    }

private:
    static void make_imap_iany_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hm(NB_INTERFACE_MAP);
        nb_id_t hn(NB_INTERFACE_NONE);
        nb_id_t har(NB_INTERFACE_ARRAY);
        in.push_back(hm);
        in.push_back(hn);
        out.push_back(har);
    }

    static void make_imap_iany_iany_omap_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hm(NB_INTERFACE_MAP);
        nb_id_t hn(NB_INTERFACE_NONE);
        in.push_back(hm);
        in.push_back(hn);
        in.push_back(hn);
        out.push_back(hm);
    }

    static void make_imap_oint_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hm(NB_INTERFACE_MAP);
        nb_id_t hi(NB_INTERFACE_INT);
        in.push_back(hm);
        out.push_back(hi);
    }

    static void make_imap_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hm(NB_INTERFACE_MAP);
        nb_id_t har(NB_INTERFACE_ARRAY);
        in.push_back(hm);
        out.push_back(har);
    }
};


/********************************** user object ***********************************/

class object_data_static_user : public object_data_static_base
{
public:
    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        assert(!"object_data_static_user::get_declaration_name()");
        return false;

    //  bool ret = true;
    //  switch (hdecl.get_func_type())
    //  {
    //  case NB_FUNC_USER_COMPOSE:
    //      name = "compose";
    //      break;
    //  case NB_FUNC_USER_DECOMPOSE:
    //      name = "decompose";
    //      break;
    //  default:
    //      ret = false;
    //      break;
    //  }
    //  return ret;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
    //  vstr.push_back("compose");
    //  vstr.push_back("decompose");
    }

    static bool get_builtin_instructions(nb_id_vector& vid)
    {
    //  vid.push_back(NB_FUNC_USER_COMPOSE);
    //  vid.push_back(NB_FUNC_USER_DECOMPOSE);
        get_general_interface(vid);
        return true;
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        assert(!"object_data_static_user::get_interfaces()");
        return false;

    //  bool ret = true;
    //  switch (hdecl.get_func_type())
    //  {
    //  case NB_FUNC_USER_COMPOSE:
    //      make_iuser_iarray_ouser_declaration(in, out);
    //      break;
    //  case NB_FUNC_USER_DECOMPOSE:
    //      make_iuser_oarray_declaration(in, out);
    //      break;
    //  default:
    //      ret = false;
    //      break;
    //  }
    //  return ret;
    }

private:
    /*
    static void make_iuser_iarray_ouser_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t harr(NB_INTERFACE_ARRAY);
        nb_id_t hu(DUKEID_TYPE_INTERFACE_USER);
        in.push_back(hu);
        in.push_back(harr);
        out.push_back(hu);
    }

    static void make_iuser_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
    {
        nb_id_t hu(DUKEID_TYPE_INTERFACE_USER);
        nb_id_t harr(NB_INTERFACE_ARRAY);
        in.push_back(hu);
        out.push_back(harr);
    }
    */
};

class object_data_static_descriptor : public object_data_static_base
{
public:
    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        assert(!"object_data_static_descriptot::get_declaration_name()");
        return false;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
    }

    static bool get_builtin_instructions(nb_id_vector& vid)
    {
        get_general_interface(vid);
        return true;
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        assert(!"object_data_static_descriptor::get_interfaces()");
        return false;
    }

private:
};

class object_data_static_declaration
{
public:
    static bool get_interfaces(const nb_id_t& did, nb_id_vector& iids, nb_id_vector& oids)
    {
        assert(did.is_function_instruction());
        if (!did.is_function_instruction())
            return false;

        if (did.is_instruction_general())
            object_data_static_boolean::get_general_declaration(did, iids, oids);
        else if (did.is_instruction_bool())
            object_data_static_boolean::get_interfaces(did, iids, oids);
        else if (did.is_instruction_int())
            object_data_static_integer::get_interfaces(did, iids, oids);
        else if (did.is_instruction_float())
            object_data_static_float::get_interfaces(did, iids, oids);
        else if (did.is_instruction_string())
            object_data_static_string::get_interfaces(did, iids, oids);
        else if (did.is_instruction_bytes())
            object_data_static_bytes::get_interfaces(did, iids, oids);
        else if (did.is_instruction_interval())
            object_data_static_interval::get_interfaces(did, iids, oids);
        else if (did.is_instruction_time())
            object_data_static_time::get_interfaces(did, iids, oids);
        else if (did.is_instruction_array())
            object_data_static_array::get_interfaces(did, iids, oids);
        else if (did.is_instruction_map())
            object_data_static_map::get_interfaces(did, iids, oids);
        else
        {
            assert(!"wrong declaration type in object_data_static_declaration::get_interfaces()");
            return false;
        }
        return true;
    }

    static bool get_builtin_name(const nb_id_t& did, std::string& name)
    {
        assert(did.is_function_instruction());

        bool ret = false;
        if (did.is_function_instruction())
        {
            if (did.is_instruction_general())
                ret = object_data_static_base::get_general_declaration_name(did, name);
            else if (did.is_instruction_bool())
                ret = object_data_static_boolean::get_declaration_name(did, name);
            else if (did.is_instruction_int())
                ret = object_data_static_integer::get_declaration_name(did, name);
            else if (did.is_instruction_float())
                ret = object_data_static_float::get_declaration_name(did, name);
            else if (did.is_instruction_string())
                ret = object_data_static_string::get_declaration_name(did, name);
            else if (did.is_instruction_bytes())
                ret = object_data_static_bytes::get_declaration_name(did, name);
            else if (did.is_instruction_interval())
                ret = object_data_static_interval::get_declaration_name(did, name);
            else if (did.is_instruction_time())
                ret = object_data_static_time::get_declaration_name(did, name);
            else if (did.is_instruction_array())
                ret = object_data_static_array::get_declaration_name(did, name);
            else if (did.is_instruction_map())
                ret = object_data_static_map::get_declaration_name(did, name);
            else if (did.is_instruction_user())
                ret = object_data_static_user::get_declaration_name(did, name);
            else
            {
                assert(!"wrong declaration type in object_data_static_declaration::get_builtin_name()");
            }
        }
        return ret;
    }
};


class object_data_static_interface
{
public:
    static bool get_builtin_instructions(const nb_id_t& ifid, nb_id_vector& vdecl)
    {
        assert(ifid.is_builtin_interface());

        vdecl.clear();
        if (ifid.is_interface_none())
            object_data_static_none::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_bool())
            object_data_static_boolean::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_int())
            object_data_static_integer::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_float())
            object_data_static_float::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_string())
            object_data_static_string::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_bytes())
            object_data_static_bytes::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_interval())
            object_data_static_interval::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_time())
            object_data_static_time::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_array())
            object_data_static_array::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_map())
            object_data_static_map::get_builtin_instructions(vdecl);
        else if (ifid.is_interface_user())
            object_data_static_user::get_builtin_instructions(vdecl);
        //else if (ifid.is_interface_root_access())
            //object_data_static_root_access::get_builtin_instructions(vdecl);
        //else if (ifid.is_interface_storage())
            //object_data_static_storage::get_builtin_instructions(vdecl);
        else
        {
            assert(!"wrong interface type in object_data_static_interface::get_builtin_instructions()");
            return false;
        }

        return true;
    }

    static bool get_builtin_name(const nb_id_t& ifid, std::string& name)
    {
        assert(ifid.is_builtin_interface());

        bool ret = false;
        if (ifid.is_builtin_interface())
        {
            if (ifid.is_interface_none())
                ret = object_data_static_none::get_name(name);
            else if (ifid.is_interface_bool())
                ret = object_data_static_boolean::get_name(name);
            else if (ifid.is_interface_int())
                ret = object_data_static_integer::get_name(name);
            else if (ifid.is_interface_float())
                ret = object_data_static_float::get_name(name);
            else if (ifid.is_interface_string())
                ret = object_data_static_string::get_name(name);
            else if (ifid.is_interface_bytes())
                ret = object_data_static_bytes::get_name(name);
            else if (ifid.is_interface_interval())
                ret = object_data_static_interval::get_name(name);
            else if (ifid.is_interface_time())
                ret = object_data_static_time::get_name(name);
            else if (ifid.is_interface_array())
                ret = object_data_static_array::get_name(name);
            else if (ifid.is_interface_map())
                ret = object_data_static_map::get_name(name);
            else
            {
                assert(!"wrong interface type in object_data_static_interface::get_builtin_name()");
            }
            name += " interface";
        }

        return ret;
    }
};

class object_data_static_root_access : public object_data_static_base
{
public:
    static bool get_declaration_name(const nb_id_t& hdecl, std::string& name)
    {
        assert(!"object_data_static_root_access::get_declaration_name()");
        return false;
    }

    static void get_builtin_instructions(std::vector<std::string>& vstr)
    {
    }

    static bool get_builtin_instructions(nb_id_vector& vid)
    {
        get_general_interface(vid);
        return true;
    }

    static bool get_interfaces(const nb_id_t& hdecl, nb_id_vector& in, nb_id_vector& out)
    {
        assert(!"object_data_static_root_access::get_interfaces()");
        return false;

    }

};

#endif // __OBJECT_DATA_STATIC_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
