#ifndef __OBJ_IMPL_NONE_H
#define __OBJ_IMPL_NONE_H

#include "obj_impl_base.h"


/****************************** user ******************************/
class obj_impl_none : public object_implementation_base
{
public:
	obj_impl_none(nb_id_t& obj_id, ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
    { 
    }; 
    virtual ~obj_impl_none()
    {
    };

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);
    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }



};


#endif // __OBJ_IMPL_NONE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
