#ifndef __DATA_UNPACKER_H
#define __DATA_UNPACKER_H

#include "ac_message_type.h"
#include <vector>
#include <string>

class data_unpacker
{
private:
    //db_id_value     m_data;
    content*     m_data;
    //std::string     m_stream;

public:
    // we use uint32_t to represents size here
    typedef uint32_t size_type;
    static const uint SIZE_LENGTH = sizeof(size_type);
    static const uint ID_LENGTH = 32;

    data_unpacker() { m_data = NULL;}
    data_unpacker(const content& data){ m_data = const_cast<content*>(&data);}
	//data_unpacker(const db_id_value& data):m_data(data) { }
    ~data_unpacker() { }

    //db_id_value unpack_from_stream(const std::string& stream);
    static bool unpack_from_stream(const std::string& stream, content& raw_data);

    void set_data(const content& data);
    content get_unpack_data();

    std::vector<nb_id_t> unpack_ids();
    nb_id_t unpack_id(int index);

    std::vector< std::vector<char> > unpack_values();
    std::vector<char> unpack_chars(int index);
    std::string unpack_string(int index);
    int unpack_int(int index);
    bool unpack_bool(int index);

private:
    static size_type str_to_size(const std::string& str);

};

#endif // __DATA_UNPACKER_H
