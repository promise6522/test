#ifndef __OBJ_IMPL_BASE_H
#define __OBJ_IMPL_BASE_H
#include <math.h>

#include <stdlib.h>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <functional>

#include "stdx_log.h"
#include "nb_typedef.h"
#include "ac_object/data_packer.h"
#include "ac_object/data_unpacker.h"
#include "ac_object/object_data.h"

class ac_object_helper;

class object_implementation_base
{
protected:
    nb_id_t m_obj_id;
    req_map m_req_info_map;
    req_num_t m_top_req_num;
    std::vector<req_num_t> m_reqs;
    std::map<req_num_t, int> m_req_idx;

    ac_object_helper* m_pHelper;

    obj_message_info<req_info_t> m_msg;

public :
    object_implementation_base();
    object_implementation_base(const nb_id_t& obj_id,
            ac_object_helper * pHelper);
    virtual ~object_implementation_base();

public:
    bool run_prepare(node_invocation_request& input);
    virtual bool run(call_id_t call_id, const node_invocation_request& input) 
    {
        return false;
    }
    virtual bool get_value(content& data) 
    {
        return false;
    }
    virtual bool set_value(const content& data)
    {
        return false;
    }
    virtual bool get_value_response(req_num_t req_num, content& output)
    {
        return false;
    }
    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return false;
    }
    virtual bool set_property(const property_info& input)
    {
        return false;
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return false;
    }

    //bool request_string_object(const std::string& name, nb_id_t& out);


public:
    req_num_t generate_req_num();

    // call id
    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    bool get_call_id(req_num_t req_num, call_id_t& call_id);

    // call builtin instruction
    void begin_incoming_ins_call(req_num_t req_num, nb_builtin_instruction_t instruction);
    void end_incoming_ins_call(req_num_t req_num);
    bool get_ins_call(req_num_t req_num, nb_builtin_instruction_t& instruction);

    bool run_exception_respond(call_id_t call_id, const transaction_id_t& tr_id);

    void end_incoming_call_info(req_num_t req_num);
    bool pop_call_info(req_num_t req_num,
            req_info_t& req_info);
    bool get_call_info(req_num_t req_num,
            req_info_t& req_info);
    void begin_incoming_call_info(req_num_t req_num,
            call_id_t call_id,
            const node_invocation_request& input);
protected:
    bool initialization_respond();
    bool throw_exeception(req_num_t req_num, std::string exception_string);
    bool run_respond(call_id_t call_id, node_invocation_response& output);
    bool exception_respond(call_id_t call_id, std::string& output);
    bool machine_is_local(const trans_comm_pair_t& input, bool& output);
    bool request_nb_id(host_committer_id_t id, const request_nb_id_info& input, nb_id_t& output);
    bool request_execution_id(const request_execution_id_info exec_info, execution_id_t& output);
    bool request_host_committer_id(host_committer_id_t& output);
    bool request_transaction_id(const host_committer_id_t& input, transaction_id_t& output);
    bool transaction_begin(transaction_id_t id, const trans_comm_pair_t& input);
    bool transaction_get_host_committer(transaction_id_t id);
    bool execution_start(call_id_t call_id, 
            const request_execution_id_info& exec_info, 
            const node_invocation_request& input);
    bool execution_set_parent(execution_id_t id, const execution_id_t& input);
    bool execution_set_root_committer(execution_id_t id, const root_committer_id_t& input);
    bool db_read(req_num_t req_num, const object_ids& input);
    bool create_actor(nb_id_t id, const content& raw_data);
    bool object_set_value(nb_id_t id, content& output);
    bool object_get_value(nb_id_t id, content& output);
    bool object_get_value_async(nb_id_t id, req_num_t req_num);
    bool object_run(nb_id_t id, 
            req_num_t req_num, 
            const node_invocation_request& input);
    bool object_set_property(nb_id_t id, const property_info& input);
    bool object_get_property(nb_id_t id, const nb_id_t& input, object_ids& output);

};

typedef std::tr1::shared_ptr<object_implementation_base> object_impl_ptr;


#endif // __OBJECT_IMPLEMENTATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
