#ifndef __OBJ_IMPL_DECLARATION_H
#define __OBJ_IMPL_DECLARATION_H

#include "obj_impl_base.h"
#include "obj_constant_def.h"
#include "obj_impl_decl_compound.h"


class obj_impl_declaration : public object_implementation_base
{
protected:
    nb_id_vector m_viif;
    nb_id_vector m_voif;

public :
    obj_impl_declaration(const nb_id_t& obj_id, ac_object_helper * pHelper);
    virtual ~obj_impl_declaration();

public:
    // for a built-in instruction, return its name
    static bool get_instruction_name(const nb_id_t& ins, std::string& name);

    // for a built-in instruction, return its in_ports & out_ports interfaces
    static bool get_interfaces(const nb_id_t& ins, nb_id_vector& vin, nb_id_vector& vout);
    
    static bool get_portNums_by_decl(const nb_id_t& decl_id, std::pair<int, int>& portNums);

private:
    static void make_iany_onone_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_iany_obool_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iany_idecl_iany_ibool_oany_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iany_idecl_oarray_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iany_idecl_oany_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iany_oany_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibool_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_iint_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iint_iint_oint_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iint_iint_obool_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_ifloat_ifloat_ofloat_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ifloat_ifloat_obool_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_istr_istr_ostr_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_istr_iint_iint_ostr_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_istr_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_istr_istr_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_istr_iint_ostr_ostr_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_istr_istr_obool_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_ibyte_ibyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibyte_iint_iint_obyte_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibyte_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibyte_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibyte_iint_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_ibyte_obool_declaration(nb_id_vector& in, nb_id_vector& out);

    //static void make_iitv_o10int_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iitv_oint_oint_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iitv_iitv_oitv_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_itime_o10int_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_itime_iitv_otime_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_itime_itime_oitv_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_itime_otime_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_iuser_oarray_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iarray_oarray_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_oint_declaration(nb_id_vector& in, nb_id_vector& out);

    static void make_ides_oaccess_declaration(nb_id_vector& in, nb_id_vector& out);
    static void make_iint_oanc_declaration(nb_id_vector& in, nb_id_vector& out);

    bool get_name(nb_id_t& out);
    bool get_general_interfaces(nb_id_vector& vifs);
    static bool get_interfaces(nb_id_vector& vout);
    bool get_in_ports(nb_id_vector& viif);
    bool get_out_ports(nb_id_vector& voif);
    bool get_iport_number(nb_id_t& num);
    bool get_oport_number(nb_id_t& num);

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);
    virtual bool get_property(const nb_id_t& input, object_ids& output);
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }


};


#endif // __OBJ_IMPL_DECLARATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
