/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#ifndef __OBJ_CONSTANT_DEF_H
#define __OBJ_CONSTANT_DEF_H

#include <assert.h>
#include <string>
#include <vector>

#include "nb_id.h"
#include "obj_impl_declaration.h"
#include "obj_impl_decl_compound.h"
#include "obj_impl_decl_expanded.h"
#include "obj_impl_interface.h"
#include "obj_impl_interface_compound.h"


namespace nb_const {

// for a builtin interface(array/map/etc), returns a interface_compound structure
// containing all the declaration infos.
bool get_builtin_interface_compound(const nb_id_t& if_id, if_compound_data_t& data);


// for a builtin declaration of array/map/etc, returns a declare_compound structure
// containing all the ports info and expansion groups defination
bool get_builtin_decl_compound(const nb_id_t& decl_id, decl_compound_data_t& data);



// below are internal implementations of the funcs, never mind
// --------------------------------------------------------------------------------


namespace detail {

enum decl_port_type 
{
    PORT_TYPE_NORMAL    = 0,
    PORT_TYPE_GROUP     = 1,
    PORT_TYPE_NESTED    = 2,
};

struct decl_port_def 
{
    bool input;
    decl_port_type ptype;
    nb_id_t interface;
    int idx;

    /*
     * for PORT_TYPE_NORMAL:
     *   interface: the actual interface id 
     *   idx: always 0
     *
     * for PORT_TYPE_GROUP:
     *   interface: min_if
     *   idx: exp group idx of the declare
     *
     * for PORT_TYPE_NESTED: 
     *   interface: the interface id to be expanded
     *   idx is the group idxs of the port itself
     *   (eg: 3 = 1|2, means group1 & group2 of the interface)
     */
};

struct decl_template_def
{
    std::vector<decl_port_def> iport_defs;   
    std::vector<decl_port_def> oport_defs;   

    void add_iport_def(const decl_port_type ptype, const nb_id_t& ifid, const int idx)
    {
        decl_port_def port_def;
        port_def.input = true;
        port_def.ptype = ptype;
        port_def.interface = ifid;
        port_def.idx = idx;
        iport_defs.push_back(port_def);
    }

    void add_oport_def(const decl_port_type ptype, const nb_id_t& ifid, const int idx)
    {
        decl_port_def port_def;
        port_def.input = false;
        port_def.ptype = ptype;
        port_def.interface = ifid;
        port_def.idx = idx;
        oport_defs.push_back(port_def);
    }

    /* get the corresponding decl_compound data structure
       including the expansion group info */
    bool get_decl_compound( decl_compound_data_t& data ) const;
};


bool gen_groups_from_port_def(const decl_port_def& port, 
        const int port_idx, 
        std::vector<decl_exp_group>& groups);

} /* namespace detail */

} /* namespace nb_const */

#endif // __OBJ_CONSTANT_DEF_H
