#ifndef __DATA_PACKER_H
#define __DATA_PACKER_H

#include "ac_message_type.h"
#include <vector>
#include <string>

class data_packer
{
private:
    content*        m_pData;

    bool            m_refData;//indicates ownership of m_pData

    char            m_buf[30];//buffer for type conversion

public:
    typedef uint32_t size_type;
    static const uint SIZE_LENGTH = sizeof(size_type);

    // when construct with no param, new a content and manage it by self
    data_packer(): m_pData(new(std::nothrow) content()), m_refData(false) 
    { 
        assert(m_pData);
    }

    // when construct with content's ref, manage the pointer
    //     for permance : avoid the cost of copy content between funcs
    data_packer(content& data): m_pData(&data), m_refData(true)
    {
        assert(m_pData);
    }

    // on destruction : only deletes internal data
    ~data_packer() 
    {
        if(!m_refData)
            delete m_pData;
    }

    content get_pack_data()
    {
        return *m_pData;
    }

    bool set_obj_id(const nb_id_t& id)
    {
        m_pData->object_id = id;
        return true;
    }

    //std::string pack_to_stream(const db_id_value& data);
	std::string packer_to_stream();
    static std::string pack_to_stream(const content& data);
    //db_id_value get_pack_data();

    void pack(const std::vector<nb_id_t>& ids, const std::vector< std::vector<char> >& values);

    void pack(const std::vector<nb_id_t>& ids);
    void pack(const nb_id_t& id);

    void pack(const std::vector< std::vector<char> >& values);
    void pack(const std::vector<char>& value);
    void pack(const std::string& value);
	void pack(const std::vector< std::string >& value);
    void pack(int value);
    void pack(bool value);

private:
    static std::string size_to_str(size_type sz);

private:
    // disable copy ctor & assignment
    data_packer(const data_packer&);
    data_packer& operator=(const data_packer&);

};

#endif // __DATA_PACKER_H
