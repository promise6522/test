#ifndef __OBJ_IMPL_INTERFACE_COMPOUND_H
#define __OBJ_IMPL_INTERFACE_COMPOUND_H

#include "obj_impl_base.h"
struct if_exp_idx
{
    int decl_idx;
    int group_idx;
	bool operator==(const if_exp_idx& val) const{
		return this->decl_idx == val.decl_idx &&
				this->group_idx == val.group_idx;
	}
};

struct if_exp_group
{
    std::string name;
    nb_id_t min_if;
    std::vector<if_exp_idx> members;
    bool expanded;

	bool operator==(const if_exp_group& val) const{
		return this->name == val.name &&
			   this->min_if == val.min_if &&
			   this->expanded == val.expanded &&
               this->members == val.members;
	}
};

struct if_compound_data_t
{
    std::string name;
    nb_id_t visualInformation;
    bool is_singleton;
    nb_id_vector decls;
    std::vector<if_exp_group> groups;

	bool operator==(const if_compound_data_t& val) const{
		return this->name == val.name &&
               this->visualInformation == val.visualInformation &&
			   this->is_singleton == val.is_singleton &&
			   this->decls == val.decls &&
               this->groups == val.groups;
	}
};

class obj_impl_interface_compound : public object_implementation_base
{
protected:
    if_compound_data_t m_cData;
    nb_id_vector m_decl_names;
    nb_id_vector m_builtin_ins;

public:
	obj_impl_interface_compound();
    obj_impl_interface_compound(const nb_id_t& obj_id, 
            const content& raw_data,
            ac_object_helper * pHelper);
    virtual ~obj_impl_interface_compound();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

	bool get_value(content& data);
    bool set_value(const content& data);
    bool set_builtin_instructions(const nb_id_vector& vins);

    virtual bool get_property(const nb_id_t& declaration, object_ids& objects);
    virtual bool set_property(const property_info& input);

    bool set_array_type();
    bool set_map_type();

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const if_compound_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool json_unpack(const content& raw_data, 
            nb_id_t& id,
            if_compound_data_t& logic_data);

    static bool pack(const if_compound_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool unpack(const content& raw_data, 
            nb_id_t& id,
            if_compound_data_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }

};


#endif // __OBJ_IMPL_INTERFACE_COMPOUND_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
