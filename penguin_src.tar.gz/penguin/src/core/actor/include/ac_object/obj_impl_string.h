#ifndef __OBJ_IMPL_STRING_H
#define __OBJ_IMPL_STRING_H

#include "obj_impl_base.h"


class obj_impl_string : public object_implementation_base
{
protected:
    std::string m_cData;

public:
    obj_impl_string() { }
    obj_impl_string(const nb_id_t& obj_id, 
            const content& raw_data, 
            ac_object_helper * pHelper);
    virtual ~obj_impl_string();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
	bool get_value(content& data);
    bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }


    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const std::string& logic_data, const nb_id_t& id, content& raw_data);
    static bool json_unpack(const content& raw_data, nb_id_t& id, std::string& logic_data);

    static bool pack(const std::string& logic_data, const nb_id_t& id, content& raw_data);
    static bool unpack(const content& raw_data, nb_id_t& id, std::string& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }

};


#endif // __OBJ_IMPL_STRING_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
