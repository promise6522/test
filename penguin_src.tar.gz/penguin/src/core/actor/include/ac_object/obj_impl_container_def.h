#ifndef __OBJ_IMPL_CONTAINER_DEF_H
#define __OBJ_IMPL_CONTAINER_DEF_H

#include "obj_impl_base.h"


struct anchor_info_t
{
    std::string name;
    bool registed;
    func_vector funcs;
    nb_id_t interface;
};

struct storage_info_t
{
    std::string name;
    nb_type_t type;
    nb_id_t interface;
};

struct cont_def_data_t
{
    std::string name;
    nb_id_t visualInformation;
    std::vector<storage_info_t> storages;
    std::vector<anchor_info_t> anchors;
};

class obj_impl_container_def: public object_implementation_base
{
protected:
    cont_def_data_t m_cData;
public:
	obj_impl_container_def();
	obj_impl_container_def(const nb_id_t& obj_id, 
            const content& raw_data,
            ac_object_helper * pHelper);
    virtual ~obj_impl_container_def();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

    bool get_value(content& data);
    bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output)
    {
        return true; 
    }
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const cont_def_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool json_unpack(const content& raw_data, 
            nb_id_t& id,
            cont_def_data_t& logic_data);
    static bool pack(const cont_def_data_t& logic_data, 
            const nb_id_t& id,
            content& raw_data);
    static bool unpack(const content& raw_data, 
            nb_id_t& id,
            cont_def_data_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }



};
#endif // __OBJ_IMPL_CONTAINER_DEF_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
