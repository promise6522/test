#ifndef __OBJ_MESSAGE_INFO_H
#define __OBJ_MESSAGE_INFO_H

#include <vector>
#include <string>
#include <map>

#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_req_num.h"
#include "ac_global.h"

struct req_info_t
{
    call_id_t call_id;
    node_invocation_request input;
};
 
typedef std::vector<req_num_t> req_num_vector; 
typedef req_num_vector::iterator    req_num_it;
typedef req_num_vector::const_iterator    req_num_const_it;


template <typename Tid>
class obj_message_info
{
public:
    obj_message_info()
    {}

    void begin_incoming_req_info(req_num_t req_num, const Tid& req_info)
    {
        m_req_info.insert(std::make_pair(req_num, req_info));    
    };

    void end_incoming_req_info(req_num_t req_num)
    {
        typename std::map<req_num_t, Tid>::iterator it = m_req_info.find(req_num);
        if (it != m_req_info.end())
            m_req_info.erase(it);
    };

    typename std::map<req_num_t, Tid>::iterator find_req_info(req_num_t req_num)
    {
        return m_req_info.find(req_num);
    }

    bool get_req_info(req_num_t req_num, Tid& req_info)
    {
        typename std::map<req_num_t, Tid>::iterator it = m_req_info.find(req_num);

        if (it == m_req_info.end())
            return false;

        req_info = it->second;
        return true;
    }

    void begin_incoming_req_record(const std::vector<req_num_t>& reqs)
    {
        m_req_record.push_back(reqs);    
    };

    bool end_incoming_req_record(req_num_t req, int sub_size)
    {
        bool ret = false;

        for (std::vector<std::vector<req_num_t> >::iterator it = m_req_record.begin();
                it != m_req_record.end();
                ++it)
        {
            for (std::vector<req_num_t>::iterator sub_it = it->begin();
                    sub_it != it->end();
                    ++sub_it)
            {
                if ((*sub_it) == req)
                {
                    it->erase(sub_it);
                    ret =  true;
                    break;
                }
            }

            if (ret)
            {
                sub_size = it->size();
                break;
            }
        }

        return ret;
    };

protected:
    std::map<req_num_t, Tid> m_req_info;
    std::vector<std::vector<req_num_t> > m_req_record;

}; 



#endif // __OBJ_MESSAGE_INFO_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
