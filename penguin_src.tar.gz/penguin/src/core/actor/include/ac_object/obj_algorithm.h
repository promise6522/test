#ifndef __OBJ_ALGORITHM_H
#define __OBJ_ALGORITHM_H

// Posix header files

// C++ 98 header files
#include <algorithm>

// Duke header files

namespace nb_obj {

template <typename _FlagType>
inline void set_flag(_FlagType& flags, _FlagType flag)
{
    flags |= flag;
}

template <typename _FlagType>
inline void clear_flag(_FlagType& flags, _FlagType flag)
{
    flags &= ~flag;
}

template <typename _FlagType>
inline bool has_flag(_FlagType flags, _FlagType flag)
{
    return (flag & flags) != 0;
}

template <typename _InputIterator1, typename _InputIterator2>
inline bool unordered_includes(_InputIterator1 first1, _InputIterator1 last1,
                               _InputIterator2 first2, _InputIterator2 last2)
{
    typedef typename std::iterator_traits<_InputIterator1>::value_type  _ValueType1;
    typedef typename std::iterator_traits<_InputIterator2>::value_type  _ValueType2;

    for ( ; first2 != last2; ++first2)
    {
        if (std::find(first1, last1, *first2) == last1)
            break;
    }
    return first2 == last2;
}

template <typename _InputIterator1, typename _InputIterator2>
inline bool unordered_match(_InputIterator1 first1, _InputIterator1 last1,
                            _InputIterator2 first2, _InputIterator2 last2)
{
    typedef typename std::iterator_traits<_InputIterator1>::value_type  _ValueType1;
    typedef typename std::iterator_traits<_InputIterator2>::value_type  _ValueType2;

    return unordered_includes(first1, last1, first2, last2)
        && unordered_includes(first2, last2, first1, last1);
}

} // namespace nb_obj 

#endif // __OBJ_ALGORITHM_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
