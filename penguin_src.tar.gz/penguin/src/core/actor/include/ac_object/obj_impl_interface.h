#ifndef __OBJ_IMPL_INTERFACE_H
#define __OBJ_IMPL_INTERFACE_H

#include "obj_impl_base.h"


/****************************** user ******************************/
class obj_impl_interface : public object_implementation_base
{
protected:
    nb_id_vector m_vdecl;

public:
	obj_impl_interface(const nb_id_t& obj_id, ac_object_helper * pHelper);
    virtual ~obj_impl_interface();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
	virtual bool get_value(content& data);
    virtual bool set_value(const content& data);
    virtual bool get_property(const nb_id_t& input, object_ids& output);
    virtual bool set_property(const property_info& input)
    {
        return true; 
    }

    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return true; 
    }
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }

public:
    // get interface name
    static bool get_interface_name(const nb_id_t& interface, std::string& name);
    // get interface declarations name
    static bool get_interface_declarations_name(const nb_id_t& interface, 
            std::vector<std::string>& vnames);

    // get instructions
    static bool get_general_instructions(nb_id_vector& vins);
    static bool get_builtin_instructions(const nb_id_t& interface, 
            bool includeGeneral, 
            nb_id_vector& vins);

private:
    // instructions
    static bool enumerate_instructions(const nb_builtin_instruction_t lower,
        const nb_builtin_instruction_t upper,
        nb_id_vector& vins);

    static bool get_root_access_instructions(nb_id_vector& vins);
    static bool get_array_instructions(nb_id_vector& vins);
    static bool get_bool_instructions(nb_id_vector& vins);
    static bool get_bridge_instructions(nb_id_vector& vins);
    static bool get_bridge_interface_instructions(nb_id_vector& vins);
    static bool get_bytes_instructions(nb_id_vector& vins);
    static bool get_container_def_instructions(nb_id_vector& vins);
    static bool get_descriptor_instructions(nb_id_vector& vins);
    static bool get_exec_anchor_func_instructions(nb_id_vector& vins);
    static bool get_exec_obj_func_instructions(nb_id_vector& vins);
    static bool get_exec_condition_instructions(nb_id_vector& vins);
    static bool get_exec_impl_instructions(nb_id_vector& vins);
    static bool get_exec_iterator_instructions(nb_id_vector& vins);
    static bool get_exec_storage_func_instructions(nb_id_vector& vins);
    static bool get_float_instructions(nb_id_vector& vins);
    static bool get_id_stand_in_instructions(nb_id_vector& vins);
    static bool get_integer_instructions(nb_id_vector& vins);
    static bool get_interval_instructions(nb_id_vector& vins);
    static bool get_map_instructions(nb_id_vector& vins);
    static bool get_none_instructions(nb_id_vector& vins);
    static bool get_string_instructions(nb_id_vector& vins);
    static bool get_time_instructions(nb_id_vector& vins);
	static bool get_container_instructions(nb_id_vector& vins);
	static bool get_anchor_instructions(nb_id_vector& vins);
	static bool get_storage_instructions(nb_id_vector& vins);
    static bool get_corpse_instructions(nb_id_vector& vins);

    static bool get_interface_instructions(nb_id_vector& vins);
    static bool get_interface_compound_instructions(nb_id_vector& vins);
    static bool get_interface_expanded_instructions(nb_id_vector& vins);

    static bool get_declaration_instructions(nb_id_vector& vins);
    static bool get_decl_compound_instructions(nb_id_vector& vins);
    static bool get_decl_expanded_instructions(nb_id_vector& vins);

private:
    bool get_declarations(nb_id_vector& vdecl);
    bool get_declarations_name(nb_id_vector& vnames);

};


#endif // __OBJ_IMPL_INTERFACE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
