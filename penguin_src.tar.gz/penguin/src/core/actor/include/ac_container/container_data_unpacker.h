#ifndef CONTAINER__DATA_UNPACKER_H
#define CONTAINER__DATA_UNPACKER_H

#include "ac_message_type.h"
#include <vector>
#include <string>

class container_data_unpacker
{
private:

    //con_id_value     m_data;
    con_content*     m_data;
    //std::string     m_stream;

public:
    // we use uint32_t to represents size here
    typedef uint32_t size_type;
    static const uint SIZE_LENGTH = sizeof(size_type);
    static const uint ID_LENGTH = 32;

    container_data_unpacker() { m_data = NULL;}
    //container_data_unpacker(const con_id_value& data) : m_data(data) { }
    container_data_unpacker(const con_content& data) : m_data(const_cast<con_content*>(&data)) { }
    ~container_data_unpacker() { }

    //con_id_value unpack_from_stream(const std::string& stream);
    static bool unpack_from_stream(const std::string& stream, con_content& raw_data);

    //void set_data(const con_id_value& data);
    //con_id_value get_unpack_data();
    void set_data(const con_content& data);
    con_content get_unpack_data();

    std::vector<container_id_t> unpack_ids();
    container_id_t unpack_id(int index);

    std::vector< std::vector<char> > unpack_values();
    std::vector<char> unpack_chars(int index);
    std::string unpack_string(int index);
    int unpack_int(int index);
    bool unpack_bool(int index);

private:
    static size_type str_to_size(const std::string& str);
};

#endif // __DATA_UNPACKER_H
