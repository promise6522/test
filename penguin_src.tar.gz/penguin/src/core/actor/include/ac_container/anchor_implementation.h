#ifndef __ANCHOR_IMPLEMENTATION_H
#define __ANCHOR_IMPLEMENTATION_H

#include "nb_typedef.h"
#include "ac_message_type.h"
#include "ac_anchor_helper.h"

struct an_exp_idx
{
    int decl_idx;
    int group_idx;
	bool operator==(const an_exp_idx& val){
		return this->decl_idx == val.decl_idx &&
				this->group_idx == val.group_idx;
	}
};

struct an_exp_group
{
    std::string name;
    nb_id_t min_if;
    std::vector<an_exp_idx> members;
    bool expanded;

	bool operator==(const an_exp_group& val){
		return this->name == val.name &&
			   this->min_if == val.min_if &&
			   this->expanded == val.expanded &&
               this->members.size() == val.members.size() &&
			   std::equal(this->members.begin(), this->members.end(), val.members.begin());
	}
};

struct anchor_data_t
{
    std::string name;
    func_vector funcs;
    bool registed;
    nb_id_t interface;
    std::vector<an_exp_group> groups;       //this member not used now

	bool operator== (const anchor_data_t& val){
		// check func_vector funcs
		if(this->funcs.size() != val.funcs.size())
			return false;
		std::vector<func_pair_t>::const_iterator it1 = this->funcs.begin();
		std::vector<func_pair_t>::const_iterator it2 = val.funcs.begin();
		while(it1 != this->funcs.end())
		{
			if(it1->declaration_id != it2->declaration_id)
				return false;
			if(it1->implementation_id != it2->implementation_id)
				return false;
			++it1;
			++it2;
		}
		// check other fields
		return this->name == val.name &&
				this->registed == val.registed &&
				this->interface == val.interface &&
                this->groups.size() == val.groups.size() &&
                std::equal(this->groups.begin(), this->groups.end(), val.groups.begin());
	}
};

class anchor_implementation 
{
protected:
    anchor_data_t m_cData;
    anchor_id_t m_id;
    ac_anchor_helper * m_pHelper;
    req_num_t m_top_req_num;

protected:
    req_map m_req_info_map;
	call_id_t m_call_id;

public:
	anchor_implementation();
    anchor_implementation(const anchor_id_t& anchor_id);
    anchor_implementation(const anchor_id_t& anchor_id, 
            const content& data,
            ac_anchor_helper * pHelper);
    virtual ~anchor_implementation();

public:
    bool is_registed(nb_id_t& result);
    bool get_implementation(const nb_id_t& decl_id, 
            nb_id_t& impl_id);
    bool generate_access(const node_invocation_request& request, access_id_t& result);
    bool destroy_access(access_id_t& result);
    bool get_interface(nb_id_t& result);
    bool get_functions(func_vector& output);
    bool find_declaration(const nb_id_t& decl_id, bool& result);
	bool get_value(content& data);
    bool set_value(const content& data);
    bool pack(content& raw_data);
    bool unpack(const content& raw_data);
	static bool pack(const anchor_data_t& logic_data, content& raw_data);
	static bool unpack(const content& raw_data, anchor_data_t& logic_data);

	static bool json_pack(const anchor_data_t& logic_data, content& raw_data);
	static bool json_unpack(const content& raw_data, anchor_data_t& logic_data);

    virtual bool run(call_id_t call_id, 
            const node_invocation_request& input, 
            ac_anchor_helper * pHelper)
    {
        return true; 
    }

public:
    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    req_num_t generate_req_num();
    bool get_call_id(req_num_t req_num, call_id_t& call_id);

};

typedef std::tr1::shared_ptr<anchor_implementation> anchor_impl_ptr;

#endif // __ANCHOR_IMPLEMENTATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
