#ifndef __CONTAINER_IMPLEMENTATION_H
#define __CONTAINER_IMPLEMENTATION_H

#include "ac_message_type.h"
#include "nb_typedef.h"
#include "ac_container_helper.h"
#include "container_data_packer.h"
#include "container_data_unpacker.h"


struct container_data_t
{
    std::string name;
    std::vector<anchor_id_t> anchors;
    std::vector<storage_id_t> storages;
    nb_id_t definition;

    bool operator== (const container_data_t& val){
        return this->name == val.name &&
               this->anchors.size() == val.anchors.size() &&
               this->storages.size() == val.storages.size() &&
               std::equal(this->anchors.begin(), this->anchors.end(), val.anchors.begin()) &&
               std::equal(this->storages.begin(), this->storages.end(), val.storages.begin()) &&
               this->definition == val.definition;
    }
};

class container_implementation 
{
protected:
    container_data_t m_cData;

protected:
    req_map m_req_info_map;
    container_id_t m_id;
    ac_container_helper * m_pHelper;
    req_num_t m_top_req_num;

public:
    container_implementation();
    container_implementation(const container_id_t& cont_id,
            const con_content& data);
    virtual ~container_implementation();

public:
    bool get_definition(nb_id_t& output);
    bool get_anchors(anchor_ids& output);
    bool get_storages(storage_ids& output);
    bool get_anchor(const int& input, anchor_id_t& output);
    bool get_storage(const int& input, storage_id_t& output);
    bool get_storage_type(const int& input, nb_id_t& output);
    bool info_store_singleton_object(const nb_id_t& obj_id);

public:
    bool get_value(con_content& data);
    bool set_value(const con_content& data);
    bool pack(con_content& raw_data);
    bool unpack(const con_content& raw_data);
    static bool json_pack(const container_data_t& logic_data, const container_id_t& id, con_content& raw_data);
    static bool json_unpack(const con_content& raw_data, container_id_t& id, container_data_t& logic_data);

    static bool pack(const container_data_t& logic_data, const container_id_t& id, con_content& raw_data);
    static bool unpack(const con_content& raw_data, container_id_t& id, container_data_t& logic_data);
    virtual bool run(call_id_t call_id, const node_invocation_request& input)
    {
        return true; 
    }

public:
    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    req_num_t generate_req_num();
    bool get_call_id(req_num_t req_num, call_id_t& call_id);
};

typedef std::tr1::shared_ptr<container_implementation> container_impl_ptr;

#endif // __CONTAINER_IMPLEMENTATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
