#ifndef CONTAINER__DATA_PACKER_H
#define CONTAINER__DATA_PACKER_H

#include "ac_message_type.h"
#include <vector>
#include <string>

class container_data_packer
{
private:

    //con_id_value     m_data;
	con_content       m_data;
    //std::string     m_stream;

public:
    typedef uint32_t size_type;
    static const uint SIZE_LENGTH = sizeof(size_type);

public:

    container_data_packer() { }
    ~container_data_packer() { }

    //std::string pack_to_stream(const con_id_value& data);
	std::string packer_to_stream();
    static std::string pack_to_stream(const con_content& data);
    con_content get_pack_data();
    //con_id_value get_pack_data();
	bool set_con_id(const container_id_t& id);

    void pack(const std::vector<container_id_t>& ids, const std::vector< std::vector<char> >& values);

    void pack(const std::vector<container_id_t>& ids);
    void pack(const container_id_t& id);

    void pack(const std::vector< std::vector<char> >& values);
    void pack(const std::vector<char>& value);
    void pack(const std::string& value);
    void pack(int value);
    void pack(bool value);

private:
    static std::string size_to_str(size_type sz);

};

#endif // __CONTAINER__DATA_PACKER_H
