#ifndef __STORAGE_IMPLEMENTATION_H
#define __STORAGE_IMPLEMENTATION_H

#include "nb_typedef.h"
#include "ac_message_type.h"
#include "ac_storage_helper.h"

struct storage_data_t
{
    std::string name;
    nb_id_t interface;

	bool operator== (const storage_data_t& val){
		return this->name == val.name &&
				this->interface == val.interface;
	}
};

class storage_implementation 
{
protected:
    storage_data_t m_cData;
    storage_id_t m_id;
    ac_storage_helper * m_pHelper;
    req_num_t m_top_req_num;

protected:
    req_map m_req_info_map;
    call_id_t m_call_id;

public:
    storage_implementation();
    storage_implementation(const storage_id_t& storage_id);
    storage_implementation(const storage_id_t& storage_id, 
		    const content& data,
		    ac_storage_helper * pHelper);
    virtual ~storage_implementation();

public:
    bool get_interface(nb_id_t& result);
    bool get_value(content& data);
    bool set_value(const content& data);
    bool pack(content& raw_data);
    bool unpack(const content& raw_data);
    static bool pack(const storage_data_t& logic_data, content& raw_data);
    static bool unpack(const content& raw_data, storage_data_t& logic_data);

    static bool json_pack(const storage_data_t& logic_data, content& raw_data);
    static bool json_unpack(const content& raw_data, storage_data_t& logic_data);

    virtual bool run(call_id_t call_id, 
            const node_invocation_request& input, 
            ac_storage_helper * pHelper)
    {
        return true; 
    }

public:
    void begin_incoming_call(req_num_t req_num, call_id_t call_id);
    void end_incoming_call(req_num_t req_num);
    req_num_t generate_req_num();
    bool get_call_id(req_num_t req_num, call_id_t& call_id);

};

typedef std::tr1::shared_ptr<storage_implementation> storage_impl_ptr;

#endif // __STORAGE_IMPLEMENTATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
