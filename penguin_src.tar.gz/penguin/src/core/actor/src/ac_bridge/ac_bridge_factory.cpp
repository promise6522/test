/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_bridge_factory.h"

bool ac_bridge_factory::initialization()
{
    m_impl.set_bridge_factory_id(m_id);
    m_impl.set_ac_helper(m_ptrHelper.get());
    
    //1. try to load it from DB
    if(m_impl.load_bridge_factory())
    {
        LOG_DEBUG("ac_bridge_factory() load bridge factory successfully.");    
        m_ptrHelper->initialization_respond();
        return true;        
    }    
    
    //2. if not find, try to create it
    if(!m_impl.create_bridge_factory())
    {
        LOG_ERROR("Create bridge factory fail.");        
    }    
    
    return true;
}

bool ac_bridge_factory::exception_handle(req_num_t req_num, const std::string& str)
{    
    ac_actor::exception_handle(req_num, str);    
    return throw_exeception(req_num, "ac_bridge_factory exception->" + str);
}

bool ac_bridge_factory::throw_exeception(req_num_t req_num, std::string exception_string)
{
    return true;
}

bool ac_bridge_factory::create_bridge_object(const create_bridge_object_info& input, bridge_object& output)
{
    UBuffer ubuf((uint8_t *)(&input.buffer.data[0]), input.buffer.data.size());
    ubuf.printData();
    ubuf.reset();
    return  m_impl.create_bridge_object(input.hc_id, ubuf, output.bridge_id);
}

bool ac_bridge_factory::ac_object_db_read_response(req_num_t req_num, db_value& output)
{
    return true;    
}

bool ac_bridge_factory::ac_object_db_write_response(req_num_t req_num, int& output)
{
    return m_impl.ac_object_db_write_response(req_num, output);
}

bool ac_bridge_factory::ac_object_db_commit_response(req_num_t req_num, bool& output)
{
    return m_impl.ac_object_db_commit_response(req_num, output);
}

bool ac_bridge_factory::ac_object_get_value_async_response(req_num_t req_num, content& obj_cont)
{
    return m_impl.ac_object_get_value_async_response(req_num, obj_cont);
}

bool ac_bridge_factory::uncreate_bridge_object(call_id_t call_id, const bridge_object& obj)
{
    return m_impl.uncreate_bridge_object(call_id, obj.bridge_id);
}

bool ac_bridge_factory::get_decl_info(bridge_decl_info& output)
{
    output = m_impl.get_bf_decl_info();
    return true;
}

bool ac_bridge_factory::get_outgoing_ac_if(nb_id_t& output)
{
    output = m_impl.get_outgoing_ac_if();
    return true;
}
