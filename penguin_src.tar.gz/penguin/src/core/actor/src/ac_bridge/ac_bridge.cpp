/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_global_db.h"
#include "ac_bridge.h"
#include "ac_bridge/bridge_impl_is.h"
#include "ac_bridge/bridge_impl_exe.h"
#include "ac_bridge/ac_bridge_impl.h"

bool ac_bridge::initialization()
{    
    std::string strval;
    if(!read_bridge_id_content(m_id, strval))
    {
        LOG_ERROR("read_bridge_id failed.");
        assert(!"read_bridge_id failed.");
        return false;
    }

    bridge_content bcont;    
    ac_bridge_impl::unpack(strval, bcont);

    if(bcont.access_id == default_transit_access_id)
    {
        m_ptr_impl.reset(new(std::nothrow) bridge_impl_is(m_ptrHelper.get(), m_id));
    }
    else
    {
        m_ptr_impl.reset(new(std::nothrow) ac_bridge_impl(m_ptrHelper.get(), m_id));
    }
    
    m_ptr_impl->initialize(bcont);
    m_ptrHelper->initialization_respond();
    return true;
}

bool ac_bridge::initialization(const bridge_content& data)
{
    if(data.access_id == default_transit_access_id)
    {
        m_ptr_impl.reset(new(std::nothrow) bridge_impl_is(m_ptrHelper.get(), m_id));
        m_ptr_impl->initialize_with_bridge_content(data);
    }
    else
    {
        m_ptr_impl.reset(new(std::nothrow) ac_bridge_impl(m_ptrHelper.get(), m_id));
        m_ptr_impl->initialize_with_bridge_content(data);
    }    
    return true;
}

bool ac_bridge::initialization(bridge_execute_impl_flag const& flag)
{
    m_ptr_impl.reset(new(std::nothrow) bridge_impl_exe(m_ptrHelper.get(), m_id));
    return true;
}

bool ac_bridge::exception_handle(req_num_t req_num, const std::string& str)
{    
    ac_actor::exception_handle(req_num, str);    
    return m_ptr_impl->exception_handle(req_num, str);
}

bool ac_bridge::trigger(call_id_t call_id, const byte_stream& input)
{
	std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return m_ptrHelper->exception_respond(call_id, val);

    return m_ptr_impl->trigger(call_id, input);
}

bool ac_bridge::ac_access_run_response(req_num_t req_num, node_invocation_response& output)
{
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, "ac_bridge initialization failed");

    return m_ptr_impl->ac_access_run_response(req_num, output);
}

bool ac_bridge::ac_object_db_read_response(req_num_t req_num, db_value& output)
{
    return true;
}

bool ac_bridge::ac_bridge_factory_uncreate_bridge_object_response(req_num_t req_num, byte_stream& output)
{
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, "ac_bridge initialization failed");

    return m_ptr_impl->ac_bridge_factory_uncreate_bridge_object_response(req_num, output);
}

bool ac_bridge::ac_object_run_response(req_num_t req_num, node_invocation_response& data)
{
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, "ac_bridge initialization failed");

    return m_ptr_impl->ac_object_run_response(req_num, data);
}

bool ac_bridge::ac_object_db_write_response(req_num_t, int& output)
{
    return true;
}

bool ac_bridge::ac_transaction_begin_response(req_num_t req_num)
{
    return true;
}

bool ac_bridge::ac_object_get_value_async_response(req_num_t req_num, content& raw_data)
{
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, "ac_bridge initialization failed");

    return m_ptr_impl->ac_object_get_value_async_response(req_num, raw_data);
}

bool ac_bridge::run_impl(call_id_t call_id, const nb_id_t& input)
{
	std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return m_ptrHelper->exception_respond(call_id, val);

    return m_ptr_impl->run_impl(call_id, input);    
}

bool ac_bridge::ac_bridge_run_impl_response(req_num_t req_num, run_impl_results& output)
{
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, std::string("ac_bridge initialization failed"));

    return m_ptr_impl->run_impl_response(req_num, output);    
}

bool ac_bridge::send_out(call_id_t call_id, const send_out_info& input)
{
	std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return m_ptrHelper->exception_respond(call_id, val);

    return m_ptr_impl->send_out(call_id, input);    
}

bool ac_bridge::client_response(call_id_t call_id, const byte_stream& input)
{
	std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return m_ptrHelper->exception_respond(call_id, val);

    return m_ptr_impl->client_response(call_id, input);    
}

bool ac_bridge::ac_root_committer_pre_commit_response(req_num_t req_num, bool& output)
{
	std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, val);

    return m_ptr_impl->ac_root_committer_pre_commit_response(req_num, output);    
}

bool ac_bridge::ac_execution_trigger_end_response(req_num_t req_num, bool& output)
{
    std::string val("ac_bridge initialization failed");
	if(!this->has_impl_ptr())
		return ac_actor::exception_handle(req_num, val);

    return m_ptr_impl->ac_execution_trigger_end_response(req_num, output);  
}

bool ac_bridge::ac_root_committer_commit_response(req_num_t req_num, bool& output)
{
    return true;
}

bool ac_bridge::has_impl_ptr() const
{
    return (NULL != m_ptr_impl.get());
}

