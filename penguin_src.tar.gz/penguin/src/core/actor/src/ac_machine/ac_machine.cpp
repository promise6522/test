/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_machine.h"

bool ac_machine::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_machine::is_local(const trans_comm_pair_t& input, bool& output)
{
    output = true;
    return true;
}

bool ac_machine::remote_execute(call_id_t call_id, const node_invocation_request& input)
{
    return true;
}
/*
bool ac_machine::add_active_child_transaction(const transaction_pair_t& input)
{
    return true;
}

bool ac_machine::transaction_prepare_for_commit(const transaction_id_t& input)
{
    return true;
}

bool ac_machine::remove_actor(const transaction_id_t& input)
{
    return true;
}

bool ac_machine::add_success_child_pair(const ac_and_pair_t& input)
{
    return true;
}

bool ac_machine::remove_active_child(const transaction_pair_t& input)
{
    return true;
}

bool ac_machine::transaction_fail(const transaction_id_t& input)
{
    return true;
}
*/
bool ac_machine::start_cut_run(const nb_ids_t& input)
{
    return true;
}
