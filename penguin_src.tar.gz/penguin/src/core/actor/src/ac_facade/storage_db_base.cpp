/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**  
**                author: Roger
**************************************************************************/

#include "ac_facade/storage_db_base.h"
#include "stdx_log.h"

storage_db_base::storage_db_base(nbnv* penv, const std::string& storid) : m_stor_id(storid)
{
    pdb = new ac_storage_db_impl();
    pdb->run(penv, storid);
}

storage_db_base::~storage_db_base()
{
    delete pdb;
}

bool storage_db_base::get(const key_vid& input, keyval_vid& output, DbTxn* txn)
{
    assert(pdb != NULL);

    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        if (iter->get_type() != NBID_TYPE_NULL)
        {
            std::string value;
            NbDbResult ret = pdb->read(iter->str(), value, txn);
            if (ret == NB_DB_RESULT_SUCCESS)/*0 && !value.empty())*/
            {
                nb_id_t id(NBID_TYPE_NULL);
                id.str(value);
                output.push_back(std::make_pair(*iter, id));
            }
        }
    }
    return true;
} 

bool storage_db_base::delete_object(call_id_t call_id, const key_vid& input, keyval_vid& output, int version, DbTxn* txn)
{
    std::string value;
    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        int ret = pdb->read(iter->str(), value, txn);
        if (ret != 0)
        {
            LOG_DEBUG("storage_db_base::delete_object : DB read error!");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);
        
        // record the data
        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_DEL;
        ins_record.r_data.push_back(std::make_pair((*iter), id));
        m_ins_records.push_back(ins_record);
        
        // add the change records
        if (id.is_singleton())
            m_change_data.ssub_vid.push_back(id);

        output.push_back(std::make_pair((*iter), id));
        
        ret = pdb->del(iter->str(), txn);
        if (ret != 0)
        {
            LOG_DEBUG("storage_db_base::delete_object : DB delete error!");
            return false;
        }
    }
    return true;
} 

int storage_db_base::size(DbTxn* txn)
{
    return pdb->size(txn);
}

bool storage_db_base::delete_all(DbTxn* txn)
{
    int ret = pdb->truncate(txn);

    if (ret != 0) return false;
    return true;
}


bool storage_db_base::get_change(call_id_t call_id, change_data_st& facade_ch)
{
    facade_ch = m_change_data;
    return true;
}

bool storage_db_base::insert(const keyval_vid& input, int version, DbTxn* txn)
{
    assert(pdb != NULL);
    NbDbResult result;

    const_kval_it iter;
    for (iter = input.begin(); iter != input.end(); ++iter)
    {
        // check if the record already exists in the db
        std::string oldValue;
        result = pdb->read(iter->first.str(), oldValue, txn);
        if (NB_DB_RESULT_SUCCESS == result)
        {
            LOG_ERROR("storage_db_base::insert() failed : key already exists");
            return false;
        }

        // write the record to db
        result = pdb->write(iter->first.str(), iter->second.str(), txn);
        if (NB_DB_RESULT_FAILED == result)
        {
            LOG_ERROR("storage_db_base::insert() failed : db write error");
            return false;
        }

        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_ADD;
        ins_record.r_data.push_back(std::make_pair(iter->first, iter->second));
        std::cout << "first:" << iter->first.str() << " second:" << iter->second.str() << std::endl;
        this->m_ins_records.push_back(ins_record);

        m_change_data.add_vid.push_back(iter->second);

    }
    return true;
}

bool storage_db_base::replaceOne(const keyval_vid& input, nb_id_t& output, int version, DbTxn* txn)
{
    assert(input.size() == 1);

    std::string oldValue;
    // check if the key already exists
    NbDbResult result = pdb->read(input[0].first.str(), oldValue, txn);
    if (NB_DB_RESULT_SUCCESS != result)
    {
        LOG_ERROR("storage_db_base::replaceOne() failed : no such key to replace");
        output = NBID_TYPE_NULL;
        return true;
    }
    //key_vid key_input;
    //keyval_vid keyval_output;
    //key_input.push_back(input.back().first);
    //this->get(key_input, keyval_output);

    output.str(oldValue);

    pdb->write(input[0].first.str(), input[0].second.str(), txn);
    return true;
}

bool  storage_db_base::update(const key_vid& d_key, const keyval_vid& s_map, const keyval_vid& r_map, key_vid& d_o, key_vid& s_o, keyval_vid& r_o, int version, DbTxn* txn)
{
    const_kval_it iter;
    const_key_it  kiter;
    // delete the key
    for (kiter = d_key.begin(); kiter != d_key.end(); ++kiter)
    {
        std::string value;
        int ret = pdb->read(kiter->str(), value, txn);
        if (ret != 0)
        {
            LOG_DEBUG("storage_db_base::delete_object : DB read error!");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);

        d_o.push_back(id);

        ret = pdb->del(kiter->str(), txn);
        if (ret != 0)
        {
            LOG_DEBUG("storage_db_base::delete_object : DB delete error!");
            return false;
        }
    }
    // set the key, value
    for (iter = s_map.begin(); iter != s_map.end(); ++iter)
    {
        std::string oldValue;
        NbDbResult ret = pdb->read(iter->first.str(), oldValue, txn);
        if (NB_DB_RESULT_SUCCESS == ret)
        {
            LOG_ERROR("ac_storage_facade_impl::insert() failed : key already exists.");
            return false;
        }
        ret = pdb->write(iter->first.str(), iter->second.str(), txn);
        if (ret == NB_DB_RESULT_FAILED)
            return false;
        s_o.push_back(iter->first);
    }

    // replace the value
    for (iter = r_map.begin(); iter != r_map.end(); ++iter)
    {
        std::string value;
        NbDbResult ret = pdb->read(iter->first.str(), value, txn);
        if (ret != NB_DB_RESULT_SUCCESS)
        {
            LOG_DEBUG("ac_storage_facade_impl::replaceOne() failed! : no such key to replace");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);

        ret = pdb->write(iter->first.str(), iter->second.str(), txn);
        if (ret == NB_DB_RESULT_FAILED)
            return false;

        r_o.push_back(std::make_pair(iter->first, id));
    }
    return true;
}

bool  storage_db_base::update(const keyval_vid& input, int version, DbTxn* txn)
{
    const_kval_it iter;
    key_vid key_input;

    keyval_vid keyval_output;
    this->get(key_input, keyval_output, txn);

    for (iter = keyval_output.begin(); iter != keyval_output.end(); ++iter)
    {
        if ((iter->second).is_singleton())
            m_change_data.ssub_vid.push_back(iter->second);
    }

    for (iter = input.begin(); iter != input.end(); ++iter)
    {
        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_MOD;
        ins_record.r_data.push_back(std::make_pair(iter->first, iter->second));
        m_ins_records.push_back(ins_record);
        key_input.push_back(iter->first);

        m_change_data.add_vid.push_back(iter->second);

        pdb->write(iter->first.str(), iter->second.str(), txn);
    }

    return true;
}

bool storage_db_base::write()
{
    /*
    std::vector<record_ins_st>::const_iterator const_it;
    int i(0);
    for (const_it = m_ins_records.begin(); const_it != m_ins_records.end(); ++const_it, ++i)
    {
        if (const_it->r_type == INS_TYPE_ADD)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "add write ok" << std::endl;
            }
            else
            {
                std::cout << "add write failed" << std::endl;
            }

            std::cout << (const_it->r_data)[i].first.str() << " " << (const_it->r_data)[i].second.str() << std::endl;
        }
        else if (const_it->r_type == INS_TYPE_MOD)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "mod write ok" << std::endl;
            }
            else
            {
                std::cout << "mod write failed" << std::endl;
            }
        }
        else if (const_it->r_type == INS_TYPE_DEL)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "del write ok" << std::endl;
            }
            else
            {
                std::cout << "del write failed" << std::endl;
            }
        }
    }

    bool ret = set_version(++this->version);
    */
    return true;
}

bool storage_db_base::commit(DbTxn* txn)
{
    assert(pdb != NULL);
    return pdb->commit(txn);
}

bool storage_db_base::rollback(DbTxn* txn)
{
    assert(pdb != NULL);
    return pdb->rollback(txn);
}

bool storage_db_base::get_range(const key_pair& input, keyval_vid& output, DbTxn* txn)
{
    return pdb->get_range(input.start_num, input.end_num, output, txn);
}

bool storage_db_base::has_key(const key_vid& input, keyval_vid& output, DbTxn* txn)
{ 
    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        std::string value;
        int ret = pdb->read(iter->str(), value, txn);
        if (ret == 0)
        {
            ret = NB_DB_RESULT_SUCCESS;
            nb_id_t id(NBID_TYPE_NULL);
            id.str(value);
            output.push_back(std::make_pair(*iter, id));
        }
       else if (ret == DB_NOTFOUND)
        {
            ret = NB_DB_RESULT_NOTFOUND;
            return false;
        }
        else
        {
            ret = NB_DB_RESULT_FAILED;
            return false;
        }

    }
    return true;
}


bool storage_db_base::has_change(bool& output)
{
    if ((m_change_data.add_vid.size() != 0) || (m_change_data.ssub_vid.size() != 0))
        output = true;
    else
        output = false;
    return true;
}

nbdb* storage_db_base::get() const
{
    return pdb->get();
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
