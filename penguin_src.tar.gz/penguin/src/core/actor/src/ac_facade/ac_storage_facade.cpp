/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_storage_facade.h"

bool ac_storage_facade::initialization(const storage_id_t& data)
{
    m_ptrImpl.reset(new(std::nothrow) ac_storage_facade_impl(data));
    
    req_num_t req_num = m_ptrImpl->generate_req_num();   
    req_num.set_init_flag(true); 

    m_isReadable = true;
    
    LOG_NOTICE("ac_storage_facade::storage id:" << m_ptrImpl->m_storage_id.str());
    return m_ptrHelper->ac_storage_get_version(m_ptrImpl->m_storage_id, req_num, m_id);
}

bool ac_storage_facade::destruction()
{
    return true;
}

bool ac_storage_facade::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}


bool ac_storage_facade::get_single(call_id_t call_id, const storage_key& input)
{
    if (!can_read())
    {
        struct object_id oid;
        oid.id = nb_id_t(NBID_TYPE_NULL);
        return m_ptrHelper->ac_storage_facade_get_single_respond(call_id, oid);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_GET_SINGLE);

    key_array_version iparam;
    iparam.keys.push_back(input.key);
    iparam.version = this->m_version;
    iparam.fid = m_id;
    return m_ptrHelper->ac_storage_read(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::get_more(call_id_t call_id, const key_array& input)
{
    if (!can_read())
    {
        key_pair_no_version1 output;
        return m_ptrHelper->ac_storage_facade_get_more_respond(call_id, output);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_GET_MORE);

    key_array_version iparam;
    iparam.keys = input.keys;
    iparam.version = this->m_version;
    iparam.fid = m_id;
    return m_ptrHelper->ac_storage_read(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::delete_one(call_id_t call_id, const storage_key& input)
{
   
    if (!can_read())
    {
        struct object_id oid;
        oid.id = nb_id_t(NBID_TYPE_NULL);
        return m_ptrHelper->ac_storage_facade_delete_one_respond(call_id, oid);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_DELETE_ONE);

    sv_update_input_version iparam;
    iparam.sv_d_update_input.keys.push_back(input.key);
    iparam.version = this->m_version;
    iparam.fid = m_id;
    
    LOG_NOTICE("++ac_storage_facade("<<m_id.str()<<") : "<<m_ptrImpl->m_storage_id.str() << " " << __func__ << " version = " << m_version);
    m_isReadable = false;
    return m_ptrHelper->ac_storage_update(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::add_one(call_id_t call_id, const key_obj_id& input)
{
    return true;
}

bool ac_storage_facade::replace_one(call_id_t call_id, const key_obj_id& input)
{
    if (!can_write())
    {
        struct object_id oid;
        oid.id = nb_id_t(NBID_TYPE_NULL);
        return m_ptrHelper->ac_storage_facade_replace_one_respond(call_id, oid);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_REPLACE_ONE);

    sv_update_input_version iparam;
    iparam.sv_r_update_input.push_back(input);
    iparam.version = this->m_version;
    iparam.fid = m_id;
    
    m_isReadable = false;
    LOG_NOTICE("++ac_storage_facade("<<m_id.str()<<") : "<<m_ptrImpl->m_storage_id.str() << " " << __func__ << " version = " << m_version);
    return m_ptrHelper->ac_storage_update(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::set_one(call_id_t call_id, const key_obj_id& input)
{
    if (!can_write())
    {
        bool ret = false;
        return m_ptrHelper->ac_storage_facade_set_one_respond(call_id, ret);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_SET_ONE);

    sv_update_input_version iparam;
    iparam.sv_s_update_input.push_back(input);
    iparam.version = this->m_version;
    iparam.fid = m_id;
    
    m_isReadable = false;
    LOG_NOTICE("++ac_storage_facade("<<m_id.str()<<") : "<<m_ptrImpl->m_storage_id.str() << " " << __func__ << " version = " << m_version);
    return m_ptrHelper->ac_storage_update(m_ptrImpl->m_storage_id, req_num, iparam);

}

bool ac_storage_facade::has_key(call_id_t call_id, const key_array& input)
{ 
    //TODO 
    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);

    key_array_version iparam;
    iparam.keys = input.keys;
    iparam.version = this->m_version;
    iparam.fid = m_id;
    return m_ptrHelper->ac_storage_has_key(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::size(call_id_t call_id)
{
    //TODO
    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);

    storage_version iparam;
    iparam.version = this->m_version;
    iparam.fid = m_id;
    return m_ptrHelper->ac_storage_size(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::get_range(call_id_t call_id, const key_pair& input)
{
    if (!can_read())
    {
        key_pair_no_version1 output;
        return m_ptrHelper->ac_storage_facade_get_range_respond(call_id, output);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);

    key_pair_version iparam;
    iparam.start_num = input.start_num;
    iparam.end_num = input.end_num;
    iparam.version = this->m_version;
    iparam.fid = m_id;
    return m_ptrHelper->ac_storage_get_range(m_ptrImpl->m_storage_id, req_num, iparam);
}

bool ac_storage_facade::get_change(call_id_t call_id)
{
    //TODO
    /*
    change_data_st facade_ch;
    bool ret = m_facade_impl->get_change(call_id, facade_ch);
    change_id ids;
    ids.add_id = facade_ch.add_vid;
    ids.sub_id_singleton = facade_ch.ssub_vid;
    if (ret)
        return m_ptrHelper->ac_storage_facade_get_change_respond(call_id, ids);
    else */
    return true;
}

bool ac_storage_facade::commit(call_id_t call_id)
{
    if (m_isReadable)
    {
        bool output = true;
        return m_ptrHelper->ac_storage_facade_commit_respond(call_id, output);
    }
    req_num_t req_num = m_ptrImpl->generate_req_num();
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    
    struct storage_version iversion;
    iversion.version = m_version;
    iversion.fid = m_id;
    
    m_isReadable = false;
    return m_ptrHelper->ac_storage_commit(m_ptrImpl->m_storage_id, req_num, iversion);
}

bool ac_storage_facade::rollback(call_id_t call_id)
{
    req_num_t req_num = m_ptrImpl->generate_req_num();
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    
    struct storage_version iversion;
    iversion.version = m_version;
    iversion.fid = m_id;

    return m_ptrHelper->ac_storage_rollback(m_ptrImpl->m_storage_id, req_num, iversion);
}

bool ac_storage_facade::ac_storage_commit_response(req_num_t req_num, bool& output)
{
    call_id_t call_id;
    bool ret = m_ptrImpl->get_call_id(req_num, call_id);
    assert(ret);
    if (ret)
    {
        m_ptrImpl->end_incoming_call(req_num);
        return m_ptrHelper->ac_storage_facade_commit_respond(call_id, output);
    }
    return true;
}

bool ac_storage_facade::ac_storage_rollback_response(req_num_t req_num, bool& output)
{
    call_id_t call_id;
    bool ret = m_ptrImpl->get_call_id(req_num, call_id);
    assert(ret);
    if (ret)
    {
        m_ptrImpl->end_incoming_call(req_num);
        return m_ptrHelper->ac_storage_facade_rollback_respond(call_id, output);
    }
    return true;
}


bool  ac_storage_facade::update(call_id_t call_id, const sv_update_input& input)
{
    if (!can_write())
    {
        sv_update_output output;
        return m_ptrHelper->ac_storage_facade_update_respond(call_id, output);
    }

    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);
    m_ptrImpl->begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_UPDATE);

    sv_update_input_version iparam;
    iparam.sv_s_update_input = input.sv_s_update_input;
    iparam.sv_r_update_input = input.sv_r_update_input;
    iparam.sv_d_update_input = input.sv_d_update_input;
    iparam.version = this->m_version;
    iparam.fid = m_id;
    LOG_NOTICE("++ac_storage_facade("<<m_id.str()<<") : "<<m_ptrImpl->m_storage_id.str() << " " << __func__ << " version = " << m_version);
    m_isReadable = false;
    return m_ptrHelper->ac_storage_update(m_ptrImpl->m_storage_id, req_num, iparam);
}


bool ac_storage_facade::get_version(call_id_t call_id)
{          
    /*
    req_num_t req_num = m_ptrImpl->generate_req_num();    
    m_ptrImpl->begin_incoming_call(req_num, call_id);

    LOG_NOTICE("ac_storage_facade::storage id:" << m_ptrImpl->m_storage_id.str());
    return m_ptrHelper->ac_storage_get_version(m_ptrImpl->m_storage_id, req_num);*/
    return true;
}

// ==============
    
bool ac_storage_facade::ac_storage_get_range_response(req_num_t req_num, key_pair_no_version1& output)
{
    call_id_t call_id;
    bool ret = m_ptrImpl->get_call_id(req_num, call_id);
    assert(ret);
    if (ret)
    {
        m_ptrImpl->end_incoming_call(req_num);
        return m_ptrHelper->ac_storage_facade_get_range_respond(call_id, output);
    }
    return true;
}

bool ac_storage_facade::ac_storage_size_response(req_num_t req_num, duke_integer& output)
{
    call_id_t call_id;
    bool ret = m_ptrImpl->get_call_id(req_num, call_id);
    assert(ret);
    if (ret)
    {
        m_ptrImpl->end_incoming_call(req_num);
        return m_ptrHelper->ac_storage_facade_size_respond(call_id, output.integer);
    }
    return true;
}
        
bool ac_storage_facade::ac_storage_has_key_response(req_num_t req_num, key_array& output)
{
    call_id_t call_id;
    bool ret = m_ptrImpl->get_call_id(req_num, call_id);
    assert(ret);
    if (ret)
    {
        m_ptrImpl->end_incoming_call(req_num);
        return m_ptrHelper->ac_storage_facade_has_key_respond(call_id, output);
    }
    return true;
}
    
bool ac_storage_facade::ac_storage_update_response(req_num_t req_num, sv_update_output& output)
{
    nb_builtin_instruction_t  builtin_ins;

    if (!m_ptrImpl->get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("ac_storage_read_response::instruction doesn't exist.");
        assert(true);
    }
    m_ptrImpl->end_incoming_ins_call(req_num);

    call_id_t call_id;
    if (!m_ptrImpl->get_call_id(req_num, call_id))
    {
        LOG_ERROR("ac_storage_read_response::invalid call id.");
        assert(true);
    }
    m_ptrImpl->end_incoming_call(req_num);
    
    switch (builtin_ins)
    {
        case NB_FUNC_STORAGE_REPLACE_ONE:
        {
            struct object_id oid;
            if (output.sv_r_update_output.size() == 0)
                oid.id = nb_id_t(NBID_TYPE_NULL);
            else
                oid.id = output.sv_r_update_output.back().obj_id;
            return m_ptrHelper->ac_storage_facade_replace_one_respond(call_id, oid);
        }
        case NB_FUNC_STORAGE_DELETE_ONE:
        {
            struct object_id oid;
            if (output.sv_d_update_output.keys.size() == 0)
                oid.id = nb_id_t(NBID_TYPE_NULL);
            else
                oid.id = output.sv_d_update_output.keys.back();
            return m_ptrHelper->ac_storage_facade_delete_one_respond(call_id, oid);
        }
        case NB_FUNC_STORAGE_SET_ONE:
        {
            bool ret = (output.sv_s_update_output.keys.size() == 1); 
            return m_ptrHelper->ac_storage_facade_set_one_respond(call_id, ret);
        }
        case NB_FUNC_STORAGE_UPDATE:
        {
            return m_ptrHelper->ac_storage_facade_update_respond(call_id, output);
        }
        default:
            assert(true);
    }
    return true;
}

bool ac_storage_facade::ac_storage_read_response(req_num_t req_num, key_pair_no_version1& output)
{
    nb_builtin_instruction_t  builtin_ins;

    if (!m_ptrImpl->get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("ac_storage_read_response::instruction doesn't exist.");
        assert(true);
    }
    m_ptrImpl->end_incoming_ins_call(req_num);

    call_id_t call_id;
    if (!m_ptrImpl->get_call_id(req_num, call_id))
    {
        LOG_ERROR("ac_storage_read_response::invalid call id.");
        assert(true);
    }
    m_ptrImpl->end_incoming_call(req_num);
    
    switch (builtin_ins)
    {
        case NB_FUNC_STORAGE_GET_SINGLE:
        {
            struct object_id oid;
            if (output.key_obj_ids.size() == 0)
                oid.id = nb_id_t(NBID_TYPE_NULL);
            else
                oid.id = output.key_obj_ids.back().obj_id; 
            return m_ptrHelper->ac_storage_facade_get_single_respond(call_id, oid);
        }
        case NB_FUNC_STORAGE_GET_MORE:
            return m_ptrHelper->ac_storage_facade_get_more_respond(call_id, output);
        default:
            assert(true);
    }
    return true;
}

bool ac_storage_facade::ac_storage_get_version_response(req_num_t req_num, unsigned int& output)
{
    m_version = output;
    LOG_NOTICE("ac_storage_facade::get_version:" << this->m_version);

    return m_ptrHelper->initialization_respond();
}

bool ac_storage_facade::can_write()
{
    return m_isReadable;
}
     
bool ac_storage_facade::can_read()
{
    return m_isReadable;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
