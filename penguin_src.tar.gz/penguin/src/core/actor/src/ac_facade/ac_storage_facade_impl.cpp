/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**  
**                author: Roger
**************************************************************************/

#include "ac_facade/ac_storage_facade_impl.h"
#include "stdx_log.h"
/*
std::map<std::string, int> ac_storage_facade_impl::m_version_map;
int ac_storage_facade_impl::m_version = 0;
boost::mutex ac_storage_facade_impl::m_mtx;

ac_storage_facade_impl::ac_storage_facade_impl(nbnv* penv, const std::string& storid) : m_stor_id(storid)
{
    pdb = new ac_storage_db_impl();
    pdb->run(penv, storid);
    init_w_version(storid, 0);
    //m_stor_db->initialization(storid);
}

ac_storage_facade_impl::~ac_storage_facade_impl()
{
    if (pdb != NULL)
        pdb->~ac_storage_db_impl();
}

bool ac_storage_facade_impl::get(const key_vid& input, keyval_vid& output)
{
    assert(pdb != NULL);

    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        if (iter->get_type() != NBID_TYPE_NULL)
        {
            std::string value;
            NbDbResult ret = pdb->read(iter->str(), value);
            if (ret == NB_DB_RESULT_SUCCESS)0 && !value.empty())*/
            /*{
                nb_id_t id(NBID_TYPE_NULL);
                id.str(value);
                output.push_back(std::make_pair(*iter, id));
            }
        }
    }

    //  if ((*iter).get_type() == NBID_TYPE_NULL)
    //      continue;
    //  int ret = pdb->read(iter->str(), value);
    //  if (ret == 0)
    //      ret = NB_DB_RESULT_SUCCESS;
    //  else if (ret == DB_NOTFOUND)
    //      ret = NB_DB_RESULT_NOTFOUND;
    //  else
    //      ret = NB_DB_RESULT_FAILED;

    //  if (!value.empty())
    //  {
    //      nb_id_t id(NBID_TYPE_NULL);
    //      id.str(value);
    //      output.push_back(std::make_pair(*iter, id));
    //  }
    return true;
} 

bool ac_storage_facade_impl::delete_object(call_id_t call_id, const key_vid& input, keyval_vid& output, int version)
{
    {
        boost::lock_guard<boost::mutex> guard(m_mtx);
        int t_version = get_w_version(m_stor_id);
        if (t_version == 0)
            insert_w_version(m_stor_id, version);
        else if (t_version != version)
            return false;
    }

    std::string value;
    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        int ret = pdb->read(iter->str(), value);
        if (ret != 0)
        {
            LOG_DEBUG("ac_storage_facade_impl::delete_object : DB read error!");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);
        
        // record the data
        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_DEL;
        ins_record.r_data.push_back(std::make_pair((*iter), id));
        m_ins_records.push_back(ins_record);
        
        // add the change records
        if (id.is_singleton())
            m_change_data.ssub_vid.push_back(id);

        output.push_back(std::make_pair((*iter), id));
        
        ret = pdb->del(iter->str());
        if (ret != 0)
        {
            LOG_DEBUG("ac_storage_facade_impl::delete_object : DB delete error!");
            return false;
        }
    }
    return true;
} 

int ac_storage_facade_impl::size()
{
    return pdb->size();
}

bool ac_storage_facade_impl::delete_all()
{
    int ret = pdb->truncate();

    if (ret != 0) return false;
    return true;
}


bool ac_storage_facade_impl::get_change(call_id_t call_id, change_data_st& facade_ch)
{
    facade_ch = m_change_data;
    return true;
}

bool ac_storage_facade_impl::insert(const keyval_vid& input, int version)
{

    {
        boost::lock_guard<boost::mutex> guard(m_mtx);
        int t_version = get_w_version(m_stor_id);
        if (t_version == 0)
            insert_w_version(m_stor_id, version);
        else if (t_version != version)
            return false;
    }

    assert(pdb != NULL);
    NbDbResult result;

    const_kval_it iter;
    for (iter = input.begin(); iter != input.end(); ++iter)
    {
        // check if the record already exists in the db
        std::string oldValue;
        result = pdb->read(iter->first.str(), oldValue);
        if (NB_DB_RESULT_SUCCESS == result)
        {
            LOG_ERROR("ac_storage_facade_impl::insert() failed : key already exists");
            return false;
        }

        // write the record to db
        result = pdb->write(iter->first.str(), iter->second.str());
        if (NB_DB_RESULT_FAILED == result)
        {
            LOG_ERROR("ac_storage_facade_impl::insert() failed : db write error");
            return false;
        }

        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_ADD;
        ins_record.r_data.push_back(std::make_pair(iter->first, iter->second));
        std::cout << "first:" << iter->first.str() << " second:" << iter->second.str() << std::endl;
        this->m_ins_records.push_back(ins_record);

        m_change_data.add_vid.push_back(iter->second);

    }
    return true;
}

bool ac_storage_facade_impl::replaceOne(const keyval_vid& input, nb_id_t& output, int version)
{
    {
        boost::lock_guard<boost::mutex> guard(m_mtx);
        int t_version = get_w_version(m_stor_id);
        if (t_version == 0)
            insert_w_version(m_stor_id, version);
        else if (t_version != version)
            return false;
    }

    assert(input.size() == 1);

    std::string oldValue;
    // check if the key already exists
    NbDbResult result = pdb->read(input[0].first.str(), oldValue);
    if (NB_DB_RESULT_SUCCESS != result)
    {
        LOG_ERROR("ac_storage_facade_impl::replaceOne() failed : no such key to replace");
        output = NBID_TYPE_NULL;
        return true;
    }
    //key_vid key_input;
    //keyval_vid keyval_output;
    //key_input.push_back(input.back().first);
    //this->get(key_input, keyval_output);

    output.str(oldValue);

    pdb->write(input[0].first.str(), input[0].second.str());
    return true;
}

bool  ac_storage_facade_impl::update(const key_vid& d_key, const keyval_vid& s_map, const keyval_vid& r_map, key_vid& d_o, key_vid& s_o, keyval_vid& r_o, int version)
{
    {
        boost::lock_guard<boost::mutex> guard(m_mtx);
        int t_version = get_w_version(m_stor_id);
        if (t_version == 0)
            insert_w_version(m_stor_id, version);
        else if (t_version != version)
            return false;
    }

    const_kval_it iter;
    const_key_it  kiter;
    // delete the key
    for (kiter = d_key.begin(); kiter != d_key.end(); ++kiter)
    {
        std::string value;
        int ret = pdb->read(kiter->str(), value);
        if (ret != 0)
        {
            LOG_DEBUG("ac_storage_facade_impl::delete_object : DB read error!");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);

        d_o.push_back(id);

        ret = pdb->del(kiter->str());
        if (ret != 0)
        {
            LOG_DEBUG("ac_storage_facade_impl::delete_object : DB delete error!");
            return false;
        }
    }
    // set the key, value
    for (iter = s_map.begin(); iter != s_map.end(); ++iter)
    {
        NbDbResult ret = pdb->write(iter->first.str(), iter->second.str());
        if (ret == NB_DB_RESULT_FAILED)
            return false;
        s_o.push_back(iter->first);
    }

    // replace the value
    for (iter = r_map.begin(); iter != r_map.end(); ++iter)
    {
        std::string value;
        NbDbResult ret = pdb->read(iter->first.str(), value);
        if (ret == NB_DB_RESULT_FAILED)
        {
            LOG_DEBUG("ac_storage_facade_impl::replace_object : DB read error!");
            return false;
        }

        nb_id_t id(NBID_TYPE_NULL);
        id.str(value);

        ret = pdb->write(iter->first.str(), iter->second.str());
        if (ret == NB_DB_RESULT_FAILED)
            return false;

        r_o.push_back(std::make_pair(iter->first, id));
    }
    return true;
}

bool  ac_storage_facade_impl::update(const keyval_vid& input, int version)
{
    {
        boost::lock_guard<boost::mutex> guard(m_mtx);
        int t_version = get_w_version(m_stor_id);
        if (t_version == 0)
            insert_w_version(m_stor_id, version);
        else if (t_version != version)
            return false;
    }

    const_kval_it iter;
    key_vid key_input;

    keyval_vid keyval_output;
    this->get(key_input, keyval_output);

    for (iter = keyval_output.begin(); iter != keyval_output.end(); ++iter)
    {
        if ((iter->second).is_singleton())
            m_change_data.ssub_vid.push_back(iter->second);
    }

    for (iter = input.begin(); iter != input.end(); ++iter)
    {
        record_ins_st ins_record;
        ins_record.r_type = INS_TYPE_MOD;
        ins_record.r_data.push_back(std::make_pair(iter->first, iter->second));
        m_ins_records.push_back(ins_record);
        key_input.push_back(iter->first);

        m_change_data.add_vid.push_back(iter->second);

        pdb->write(iter->first.str(), iter->second.str());
    }

    return true;
}

bool ac_storage_facade_impl::write()
{
    *
    std::vector<record_ins_st>::const_iterator const_it;
    int i(0);
    for (const_it = m_ins_records.begin(); const_it != m_ins_records.end(); ++const_it, ++i)
    {
        if (const_it->r_type == INS_TYPE_ADD)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "add write ok" << std::endl;
            }
            else
            {
                std::cout << "add write failed" << std::endl;
            }

            std::cout << (const_it->r_data)[i].first.str() << " " << (const_it->r_data)[i].second.str() << std::endl;
        }
        else if (const_it->r_type == INS_TYPE_MOD)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "mod write ok" << std::endl;
            }
            else
            {
                std::cout << "mod write failed" << std::endl;
            }
        }
        else if (const_it->r_type == INS_TYPE_DEL)
        {
            int ret = pdb->write((const_it->r_data)[i].first.str(), (const_it->r_data)[i].second.str());
            if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            {
                std::cout << "del write ok" << std::endl;
            }
            else
            {
                std::cout << "del write failed" << std::endl;
            }
        }
    }

    bool ret = set_version(++this->version);
    */
    /*return true;
}

bool ac_storage_facade_impl::commit()
{
    assert(pdb != NULL);
    init_zerow_version(m_stor_id);
    return pdb->commit();
}

bool ac_storage_facade_impl::rollback()
{
    assert(pdb != NULL);
    init_zerow_version(m_stor_id);
    return pdb->rollback();
}

bool ac_storage_facade_impl::get_range(const key_pair& input, keyval_vid& output)
{
    return pdb->get_range(input.start_num, input.end_num, output);
}

bool ac_storage_facade_impl::has_key(const key_vid& input, keyval_vid& output)
{ 
    for (const_key_it iter = input.begin(); iter != input.end(); ++iter)
    {
        std::string value;
        int ret = pdb->read(iter->str(), value);
        if (ret == 0)
        {
            ret = NB_DB_RESULT_SUCCESS;
            nb_id_t id(NBID_TYPE_NULL);
            id.str(value);
            output.push_back(std::make_pair(*iter, id));
        }
       else if (ret == DB_NOTFOUND)
        {
            ret = NB_DB_RESULT_NOTFOUND;
            return false;
        }
        else
        {
            ret = NB_DB_RESULT_FAILED;
            return false;
        }

    }
    return true;
}


bool ac_storage_facade_impl::has_change(bool& output)
{
    if ((m_change_data.add_vid.size() != 0) || (m_change_data.ssub_vid.size() != 0))
        output = true;
    else
        output = false;
    return true;
}

bool ac_storage_facade_impl::get_version(int& version)
{
    boost::lock_guard<boost::mutex> guard(m_mtx);
    version = ++this->m_version;
    return true;
}

bool ac_storage_facade_impl::init_w_version(const std::string& storid, int version)
{
    if ((m_version_map.find(storid)) == m_version_map.end())
        m_version_map.insert(std::make_pair(storid, version));
    return true;
}

bool ac_storage_facade_impl::init_zerow_version(const std::string& storid)
{
    assert(m_version_map.find(storid) != m_version_map.end());
    version_iterator it = m_version_map.find(storid);
    it->second = 0;
    return true;
}

bool ac_storage_facade_impl::insert_w_version(const std::string& storid, int version)
{
    version_iterator it;
    if ((it = m_version_map.find(storid)) == m_version_map.end())
    {
        m_version_map.insert(std::make_pair(storid, version));
    }
    else
        it->second = version;
    return true;
}

int ac_storage_facade_impl::get_w_version(const std::string& storid)
{
    assert(m_version_map.find(storid) != m_version_map.end());
    version_iterator it = m_version_map.find(storid);
    return it->second;
}
*/


ac_storage_facade_impl::ac_storage_facade_impl(const storage_id_t& sid)
{
   m_storage_id = sid; 
}

/**************************** request number ****************************/
req_num_t ac_storage_facade_impl::generate_req_num()
{
    //boost::lock_guard<boost::mutex> locked(m_mutex);
    return ++m_top_req_num;    
}

void ac_storage_facade_impl::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void ac_storage_facade_impl::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool ac_storage_facade_impl::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if (it == m_req_info_map.end())
        return false;

    call_id = it->second;
    return true;
}

void ac_storage_facade_impl::begin_incoming_ins_call(req_num_t req_num, nb_builtin_instruction_t instruction)
{
    m_ins_call_map.insert(std::make_pair(req_num, instruction));    
}

void ac_storage_facade_impl::end_incoming_ins_call(req_num_t req_num)
{
    m_ins_call_map.erase(req_num);
}

bool ac_storage_facade_impl::get_ins_call(req_num_t req_num, nb_builtin_instruction_t& instruction)
{
    builtin_instruction_map_it it = m_ins_call_map.find(req_num);

    if (it == m_ins_call_map.end())
        return false;

    instruction = it->second;
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
