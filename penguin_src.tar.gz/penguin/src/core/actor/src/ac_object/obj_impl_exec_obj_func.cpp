/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
// stdx header files
#include "stdx_json.h"

#include "ac_message_type.h"
#include "ac_object/obj_impl_exec_obj_func.h"

obj_impl_exec_obj_func::obj_impl_exec_obj_func(const nb_id_t& obj_id, 
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{ 
    assert(obj_id.is_object_exec_obj_func());
    set_value(raw_data);
} 

obj_impl_exec_obj_func::~obj_impl_exec_obj_func()
{
}

bool obj_impl_exec_obj_func::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_exec_obj_func::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_exec_obj_func::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_exec_obj_func::pack(const exec_obj_func_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.owner);
    packer.pack(logic_data.selected_decl);
    packer.pack(logic_data.recoverer);
    packer.pack(logic_data.postcut);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_exec_obj_func::unpack(const content& raw_data, nb_id_t& id, exec_obj_func_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data.name = unpack.unpack_string(0);
    logic_data.postcut = unpack.unpack_bool(1);

    logic_data.owner = unpack.unpack_id(0);
    logic_data.selected_decl = unpack.unpack_id(1);
    logic_data.recoverer = unpack.unpack_id(2);
    return true;
}

bool obj_impl_exec_obj_func::json_pack(const exec_obj_func_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    pObj->insert("owner", new stdx::json_string(logic_data.owner.str()));
    pObj->insert("selected_decl", new stdx::json_string(logic_data.selected_decl.str()));
    pObj->insert("recoverer", new stdx::json_string(logic_data.recoverer.str()));
    pObj->insert("postcut", new stdx::json_boolean(logic_data.postcut));
    
    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
    // save all internal ids
    raw_data.id_value.ids.clear();
    raw_data.id_value.ids.push_back(logic_data.owner);
    raw_data.id_value.ids.push_back(logic_data.selected_decl);
    raw_data.id_value.ids.push_back(logic_data.recoverer);
    // save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);

    return true;
}

bool obj_impl_exec_obj_func::unpack(const content& raw_data)
{
    nb_id_t id;    
    unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);
    return true;
}

bool obj_impl_exec_obj_func::json_unpack(const content& raw_data, nb_id_t& id, exec_obj_func_data_t& logic_data)
{
    id = raw_data.object_id;
    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj);

    stdx::json_node* item;
    item = pObj->find("name");
    logic_data.name = item->get_string();
    item = pObj->find("owner");
    logic_data.owner.str(item->get_string());
    item = pObj->find("selected_decl");
    logic_data.selected_decl.str(item->get_string());
    item = pObj->find("recoverer");
    logic_data.recoverer.str(item->get_string());
    item = pObj->find("postcut");
    logic_data.postcut = item->get_boolean();

    return true;
}

bool obj_impl_exec_obj_func::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_exec_obj_func::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
