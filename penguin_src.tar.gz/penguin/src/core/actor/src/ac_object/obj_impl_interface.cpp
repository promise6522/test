/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"

obj_impl_interface::obj_impl_interface(const nb_id_t& obj_id, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_interface());

    get_builtin_instructions(m_obj_id, true, m_vdecl);
} 

obj_impl_interface::~obj_impl_interface()
{
} 

bool obj_impl_interface::set_value(const content& data)
{
    return true;
}

bool obj_impl_interface::get_value(content& data)
{
    return true;
}

bool obj_impl_interface::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_interface::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;

    return execution_start(call_id, exec_info, input);
}

bool obj_impl_interface::get_builtin_instructions(const nb_id_t& interface, 
        bool includeGeneral, 
        nb_id_vector& vdecls)
{
    assert(interface.is_object_interface());

    //vdecls.clear();

    switch(interface.get_interface_type())
    {
        case NB_INTERFACE_NONE:
            get_none_instructions(vdecls);
            break;
        case NB_INTERFACE_BOOL:
            get_bool_instructions(vdecls);
            break;
        case NB_INTERFACE_INT:
            get_integer_instructions(vdecls);
            break;
        case NB_INTERFACE_FLOAT:
            get_float_instructions(vdecls);
            break;
        case NB_INTERFACE_STRING:
            get_string_instructions(vdecls);
            break;
        case NB_INTERFACE_BYTES:
            get_bytes_instructions(vdecls);
            break;
        case NB_INTERFACE_INTERVAL:
            get_interval_instructions(vdecls);
            break;
        case NB_INTERFACE_TIME:
            get_time_instructions(vdecls);
            break;
        case NB_INTERFACE_ARRAY:
            get_array_instructions(vdecls);
            break;
        case NB_INTERFACE_MAP:
            get_map_instructions(vdecls);
            break;
        case NB_INTERFACE_CONTAINER_DEF:
            get_container_def_instructions(vdecls);
            break;
        case NB_INTERFACE_DECLARATION:
            get_declaration_instructions(vdecls);
            break;
        case NB_INTERFACE_DESCRIPTOR:
            get_descriptor_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_IMPLEMENTATION:
            get_exec_impl_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_CONDITION:
            get_exec_condition_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_ITERATOR:
            get_exec_iterator_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_OBJ_FUNC:
            get_exec_obj_func_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_STORAGE_FUNC:
            get_exec_storage_func_instructions(vdecls);
            break;
        case NB_INTERFACE_EXEC_ANCHOR_FUNC:
            get_exec_anchor_func_instructions(vdecls);
            break;
        case NB_INTERFACE_BRIDGE:
            get_bridge_instructions(vdecls);
            break;
        case NB_INTERFACE_ROOT_ACCESS:
            get_root_access_instructions(vdecls);
            break;
        //case NB_INTERFACE_ANCHOR:
        //    get_anchor_instructions(vdecls);
        //    break;
        case NB_INTERFACE_CONTAINER:
            return get_container_instructions(vdecls);

        case NB_INTERFACE_STORAGE_SIMPLE:
            return get_storage_instructions(vdecls);

        case NB_INTERFACE_INTERFACE:
            get_interface_instructions(vdecls);
            break;
        case NB_INTERFACE_CORPSE:
            get_corpse_instructions(vdecls);
            break;

        default:
            //TODO
            break;
    }

    if (includeGeneral)
        get_general_instructions(vdecls);

    return true;
}

/******************************** instruction ***************************************/

bool obj_impl_interface::get_root_access_instructions(nb_id_vector& vins)
{
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER));
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER));
    vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GET_CONT_DEF));
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GET_STORAGE));
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE));
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GET_ANCHOR));
    vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR));
    //vins.push_back(nb_id_t(NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR));
    return true;
}

bool obj_impl_interface::get_array_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_ARRAY_INSTRUCTION, 
        NB_FUNC_ARRAY_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_bool_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_BOOL_INSTRUCTION, 
        NB_FUNC_BOOL_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_bridge_instructions(nb_id_vector& vins)
{
    //Compose/Decompose
    vins.push_back(NBID_TYPE_FUNCTION_BRIDGE_COMPOSE);
    vins.push_back(NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE);

    vins.push_back(NB_FUNC_BRIDGE_GET_DESCRIPTOR);

    return true;
}

bool obj_impl_interface::get_bridge_interface_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION, 
        NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_bytes_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_BYTES_INSTRUCTION, 
        NB_FUNC_BYTES_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_container_def_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_CONTAINER_DEF_INSTRUCTION, 
        NB_FUNC_CONTAINER_DEF_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_declaration_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_DECLARATION_INSTRUCTION, 
        NB_FUNC_DECLARATION_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_descriptor_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_DESCRIPTOR_INSTRUCTION, 
        NB_FUNC_DESCRIPTOR_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_exec_anchor_func_instructions(nb_id_vector& vins)
{
	//TODO
    return true;
}

bool obj_impl_interface::get_exec_obj_func_instructions(nb_id_vector& vins)
{
    //TODO
    return true;
}

bool obj_impl_interface::get_exec_condition_instructions(nb_id_vector& vins)
{
    //TODO
    return true;
}

bool obj_impl_interface::get_exec_impl_instructions(nb_id_vector& vins)
{
    //none

    return true;
}

bool obj_impl_interface::get_exec_iterator_instructions(nb_id_vector& vins)
{
    //TODO
    return true;
}

bool obj_impl_interface::get_exec_storage_func_instructions(nb_id_vector& vins)
{
    //TODO
    return true;
}

bool obj_impl_interface::get_float_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_FLOAT_INSTRUCTION, 
        NB_FUNC_FLOAT_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_id_stand_in_instructions(nb_id_vector& vins)
{
    //TODO
    return true;
}

bool obj_impl_interface::get_integer_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_INT_INSTRUCTION, 
        NB_FUNC_INT_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_corpse_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_CORPSE_INSTRUCTION, 
        NB_FUNC_CORPSE_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_interface_instructions(nb_id_vector& vins)
{
    vins.push_back(nb_id_t(NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME));
    vins.push_back(nb_id_t(NB_FUNC_INTERFACE_GET_DECLARATIONS));
    vins.push_back(nb_id_t(NB_FUNC_INTERFACE_EQ));
    vins.push_back(nb_id_t(NB_FUNC_INTERFACE_COVERS));
    vins.push_back(nb_id_t(NB_FUNC_INTERFACE_CONVERT));
    return true;
}

bool obj_impl_interface::get_interface_expanded_instructions(nb_id_vector& vins)
{
    // currently the same with interface-instructions
    get_interface_instructions(vins);
    return true;
}

bool obj_impl_interface::get_interface_compound_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_INTERFACE_INSTRUCTION, 
        NB_FUNC_INTERFACE_INSTRUCTION_END,
        vins);
    return true;
}

bool obj_impl_interface::get_interval_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_INTERVAL_INSTRUCTION, 
        NB_FUNC_INTERVAL_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_map_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_MAP_INSTRUCTION, 
        NB_FUNC_MAP_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_none_instructions(nb_id_vector& vins)
{
	//TODO
    return true;
}

bool obj_impl_interface::get_string_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_STR_INSTRUCTION, 
        NB_FUNC_STR_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_time_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_TIME_INSTRUCTION, 
        NB_FUNC_TIME_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_container_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_CONTAINER_INSTRUCTION, 
        NB_FUNC_CONTAINER_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_anchor_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_ANCHOR_INSTRUCTION, 
        NB_FUNC_ANCHOR_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_storage_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_STORAGE_INSTRUCTION, 
        NB_FUNC_STORAGE_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_interface_declarations_name(const nb_id_t& interface, 
        std::vector<std::string>& vnames)
{
    // get all instructions
    nb_id_vector vins;
    get_builtin_instructions(interface, true, vins);

    // get instruction's name
    for(nb_id_vector_const_it it = vins.begin(); it != vins.end(); ++it)
    {
        std::string name;
        if (!obj_impl_declaration::get_instruction_name(*it, name))
        {
            LOG_ERROR("obj_impl_interface::get_interface_declarations_name error!");
            name = "unknown decl name";
        }

        vnames.push_back(name);
    }

    return true;
}

bool obj_impl_interface::get_declarations_name(nb_id_vector& vnames)
{
    //TODO
    //get_interface_declarations_name(m_obj_id, vnames);
    return true;
}

bool obj_impl_interface::enumerate_instructions(const nb_builtin_instruction_t lower,
        const nb_builtin_instruction_t upper,
        nb_id_vector& vins)
{
    // lower MUST be NB_FUNC_XXX_INSTRUCTION;
    // upper MUST be NB_FUNC_XXX_INSTRUCTION_END;
    uint32_t ins;
    for(ins = lower+1; ins < static_cast<uint32_t>(upper); ++ins)
        vins.push_back(static_cast<nb_builtin_instruction_t>(ins));

    /*
     * TODO
     *
    vnames.clear();

    switch(interface.get_interface_type())
    {
        case NB_INTERFACE_NONE:
            get_none_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_BOOL:
            get_bool_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_INT:            
            get_integer_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_FLOAT:
            get_float_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_STRING:
            get_string_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_BYTES:
            get_bytes_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_INTERVAL:
            get_interval_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_TIME:
            get_time_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_ARRAY:
            get_array_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_MAP:
            get_map_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_CONTAINER_DEF:
            get_container_def_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_DECLARATION_COMPOUND:
            get_decl_compound_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_DECLARATION:
            get_declaration_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_DESCRIPTOR:
            get_descriptor_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_IMPLEMENTATION:
            get_exec_impl_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_CONDITION:
            get_exec_condition_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_ITERATOR:
            get_exec_iterator_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_OBJ_FUNC:
            get_exec_obj_func_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_ANCHOR_FUNC:
            get_exec_anchor_func_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_EXEC_STORAGE_FUNC:
            get_exec_storage_func_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_BRIDGE:
            get_bridge_instructions_name(vnames);
            break;
        case NB_INTERFACE_ROOT_ACCESS:
            get_root_access_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        //case NB_INTERFACE_ANCHOR:
        //    get_anchor_instructions_name(vnames);
        //    break;
        case NB_INTERFACE_CONTAINER:
            get_container_instructions_name(vnames);
            break;

        //case NB_INTERFACE_STORAGE:
        //    get_storage_instructions_name(vnames);
        //    break;
        default:
            //TODO
            get_general_instructions_name(vnames);
            break;
    }
    */

    return true;
}

bool obj_impl_interface::get_general_instructions(nb_id_vector& vins)
{
    enumerate_instructions(NB_FUNC_GENERAL_INSTRUCTION, 
        NB_FUNC_GENERAL_INSTRUCTION_END,
        vins);

    return true;
}

bool obj_impl_interface::get_declarations(nb_id_vector& vdecl)
{
    vdecl = m_vdecl;
    return true;
}

bool obj_impl_interface::get_property(const nb_id_t& input, object_ids& output)
{ 
    LOG_ERROR("&&& obj_impl_interface::get_property()");

    switch (input.get_func_type())
    {
	case NB_FUNC_INTERFACE_GET_DECLARATIONS:
	    get_declarations(output.ids);
	    break;
	case NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME:
	    get_declarations_name(output.ids);
	    break;
	default:
	    break;
    }

    return true;
}

// TODO can be optimized to use a map
bool obj_impl_interface::get_interface_name(const nb_id_t& interface, std::string& name)
{
    assert(interface.is_builtin_interface());
    if(!interface.is_builtin_interface())
    {
        name = "UNKOWN";
        return false;
    }

    std::string suffix = " [interface]";
    switch(interface.get_interface_type())
    {    
        case NB_INTERFACE_NONE:
            name = "none";
            break;
        case NB_INTERFACE_BOOL:
            name = "bool";
            break;
        case NB_INTERFACE_INT:
            name = "int";
            break;
        case NB_INTERFACE_FLOAT:
            name = "float";
            break;
        case NB_INTERFACE_STRING:
            name = "string";
            break;
        case NB_INTERFACE_BYTES:
            name = "bytes";
            break;
        case NB_INTERFACE_INTERVAL:
            name = "interval";
            break;
        case NB_INTERFACE_TIME:
            name = "time";
            break;
        case NB_INTERFACE_ARRAY:
            name = "array";
            break;
        case NB_INTERFACE_ARRAY_INT:
            name = "array[int]";
            break;
        case NB_INTERFACE_ARRAY_BOOL:
            name = "array[bool]";
            break;
        case NB_INTERFACE_ARRAY_FLOAT:
            name = "array[float]";
            break;
        case NB_INTERFACE_ARRAY_STRING:
            name = "array[string]";
            break;
        case NB_INTERFACE_MAP:
            name = "map";
            break;
        case NB_INTERFACE_CONTAINER_DEF:
            name = "container def";
            break;
        case NB_INTERFACE_DECLARATION:
            name = "declaration";
            break;
        //case NB_INTERFACE_DECLARATION_COMPOUND:
        //    name = "declaration-compound";
        //    break;
        //case NB_INTERFACE_DECLARATION_EXPANDED:
        //    name = "declaration-expanded";
        //    break;
        case NB_INTERFACE_DESCRIPTOR:
            name = "descriptor";
            break;
        case NB_INTERFACE_EXEC_IMPLEMENTATION:
            name = "implementation";
            break;
        case NB_INTERFACE_EXEC_CONDITION:
            name = "exec condition";
            break;
        case NB_INTERFACE_EXEC_ITERATOR:
            name = "exec iterator";
            break;
        case NB_INTERFACE_EXEC_OBJ_FUNC:
            name = "exec obj func";
            break;
        case NB_INTERFACE_EXEC_ANCHOR_FUNC:
            name = "exec anchor func";
            break;
        case NB_INTERFACE_EXEC_STORAGE_FUNC:
            name = "exec storage func";
            break;
        case NB_INTERFACE_BRIDGE:
            name = "bridge";
            break;
        case NB_INTERFACE_CORPSE:
            name = "corpse";
            break;

        case NB_INTERFACE_INTERFACE:
            name = "interface";
            break;
        //case NB_INTERFACE_INTERFACE_COMPOUND:
        //    name = "compound interface";
        //    break;
        case NB_INTERFACE_INTERFACE_BRIDGE:
            name = "interface bridge";
            break;

        case NB_INTERFACE_ROOT_ACCESS:
            name = "root access";
            break;
        case NB_INTERFACE_CONTAINER:
            name = "container";
            break;
        default:
            assert(!"Unkown interface type!");
    }

    name += suffix;
    return true;
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
