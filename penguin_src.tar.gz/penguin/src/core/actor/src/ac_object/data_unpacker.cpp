#include "ac_object/data_unpacker.h"


//db_id_value data_unpacker::unpack_from_stream(const std::string& stream)
bool data_unpacker::unpack_from_stream(const std::string& stream, content& raw_data)
{
    //m_stream = stream;
	//m_data = &raw_data;
    std::string strval = stream;

    // 1. unpack id size
    size_type total_size = data_unpacker::str_to_size(strval.substr(0, SIZE_LENGTH));
    strval = strval.substr(SIZE_LENGTH);
	size_type id_size = data_unpacker::str_to_size(strval.substr(0, SIZE_LENGTH));
    strval = strval.substr(SIZE_LENGTH);

    // 2. unpack ids
    size_type    i;
    for (i = 0; i < id_size; ++i)
    {
        nb_id_t id;
        id.str(strval.substr(0, ID_LENGTH));
        raw_data.id_value.ids.push_back(id);
        strval = strval.substr(ID_LENGTH);
    }

    // 3. unpack values
    size_type value_size = total_size - id_size;
    for (i = 0; i < value_size; ++i)
    {
        // 4.1. get each value size
        size_type size = data_unpacker::str_to_size(strval.substr(0, SIZE_LENGTH));
        strval = strval.substr(SIZE_LENGTH);

        // 4.2. get value
        std::string s = strval.substr(0, size);
        raw_data.id_value.values.push_back(std::vector<char>(s.begin(), s.end()));
        strval = strval.substr(size);
    }

	//raw_data.id_value = m_data;
	//raw_data.object_id = nb_id_t(strval.substr(0));
	//raw_data.object_id.str(strval.substr(0));
	raw_data.object_id.str(strval.substr(0));
    return true;
}

void data_unpacker::set_data(const content& data)
{
    m_data = const_cast<content*>(&data);
}

content data_unpacker::get_unpack_data()
{
	if(m_data!=NULL)
	{
    	return *m_data;
	}
	return  content();
}

std::vector<nb_id_t> data_unpacker::unpack_ids()
{
	assert(m_data!=NULL);
    return m_data->id_value.ids;
}

nb_id_t data_unpacker::unpack_id(int index)
{
	assert(m_data!=NULL);
    return m_data->id_value.ids[index];
}

std::vector< std::vector<char> > data_unpacker::unpack_values()
{
	assert(m_data!=NULL);
    return m_data->id_value.values;
}

std::vector<char> data_unpacker::unpack_chars(int index)
{
	assert(m_data!=NULL);
    return m_data->id_value.values[index];
}

std::string data_unpacker::unpack_string(int index)
{
    //std::string strval(m_data.values[index].begin(), m_data.values[index].end());
    //return strval;
	assert(m_data!=NULL);
	return std::string(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
}

int data_unpacker::unpack_int(int index)
{
	assert(m_data!=NULL);
    std::string strval(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
    return atoi(strval.c_str());
}

bool data_unpacker::unpack_bool(int index)
{
	assert(m_data!=NULL);
    std::string strval(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
    bool ret = (strval == "true") ? true : false;
    return ret;
}

data_unpacker::size_type data_unpacker::str_to_size(const std::string& str)
{
    assert(str.size() == SIZE_LENGTH);

    size_type sz;
    memcpy(&sz, str.c_str(), SIZE_LENGTH);

    return sz;
}
