/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_object/obj_impl_string.h"

obj_impl_string::obj_impl_string(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{ 
    assert(obj_id.is_object_string());
    set_value(raw_data);
    LOG_DEBUG("obj_impl_string init with string = "<<m_cData);
} 

obj_impl_string::~obj_impl_string()
{
}

bool obj_impl_string::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_string::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_string::pack(content& raw_data)
{
	pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_string::pack(const std::string& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_string::unpack(const content& raw_data, nb_id_t& id, std::string& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data = unpack.unpack_string(0);
    return true;
}

bool obj_impl_string::json_pack(const std::string& logic_data, const nb_id_t& id, content& raw_data)
{
	// duke string's internal implementation is std::string 
	std::string strval = logic_data;

	raw_data.id_value.ids.clear();
	raw_data.id_value.values.clear();
    raw_data.object_id = id;
	std::vector<char> vchar(strval.begin(), strval.end());
	raw_data.id_value.values.push_back(vchar);

    return true;
}

bool obj_impl_string::unpack(const content& raw_data)
{
    nb_id_t id;    
	unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);
    return true;
}

bool obj_impl_string::json_unpack(const content& raw_data, nb_id_t& id, std::string& logic_data)
{
	assert(!raw_data.id_value.values.empty());
	std::vector<char> vchar = raw_data.id_value.values[0];
	std::string strval(vchar.begin(), vchar.end());
    id = raw_data.object_id;

	logic_data = strval;
    return true;
}

bool obj_impl_string::run(call_id_t call_id, const node_invocation_request& input)
{
    LOG_DEBUG("*** obj_impl_string::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
