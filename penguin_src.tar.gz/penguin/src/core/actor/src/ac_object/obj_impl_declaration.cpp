/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_array.h"

obj_impl_declaration::obj_impl_declaration(const nb_id_t& obj_id, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_declaration());

    //get_interfaces(m_obj_id, m_viif, m_voif);
}

obj_impl_declaration::~obj_impl_declaration()
{
}

bool obj_impl_declaration::set_value(const content& data)
{
    return true;
}

bool obj_impl_declaration::get_value(content& data)
{
    return true;
}

bool obj_impl_declaration::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_declaration::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;

    return execution_start(call_id, exec_info, input);
}

bool obj_impl_declaration::get_portNums_by_decl(const nb_id_t& decl_id, std::pair<int, int>& portNums)
{
    if (!decl_id.is_function_instruction())
        return false;

    if (decl_id.is_instruction_array() ||
        decl_id.is_instruction_map()   ||
        decl_id.is_instruction_storage())
    {
        decl_compound_data_t data;
        if (!nb_const::get_builtin_decl_compound(decl_id, data))
            return false;

        portNums = std::make_pair(data.iports.size(), data.oports.size());
    }
    else
    {
        nb_id_vector vin, vout;
        if (!get_interfaces(decl_id, vin, vout))
            return false;

        portNums = std::make_pair(vin.size(), vout.size());
    }

    return true;
}

bool obj_impl_declaration::get_interfaces(const nb_id_t& ins, nb_id_vector& vin, nb_id_vector& vout)
{
    if(!ins.is_function_instruction())
        return false;

    switch(ins.get_func_type())
    {
        // 1 general
        case NB_FUNC_GENERAL_GET_NAME:
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_STRING);
            break;
        case NB_FUNC_GENERAL_IS_NULL:
        case NB_FUNC_GENERAL_IS_SINGLETON:
        case NB_FUNC_GENERAL_IS_JUSTID:
        case NB_FUNC_GENERAL_IS_BUILTIN:
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
        case NB_FUNC_GENERAL_IS_LOCAL:
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            make_iany_obool_declaration(vin, vout);
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            make_iany_oany_declaration(vin, vout);
            break;
        case NB_FUNC_GENERAL_COMPARE:
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_BOOL);//less than
            vout.push_back(NB_INTERFACE_BOOL);//equals
            vout.push_back(NB_INTERFACE_BOOL);//greater than
            break;
        case NB_FUNC_GENERAL_RUN:
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_DECLARATION);
            vin.push_back(NB_INTERFACE_NONE);//An array of input
            vout.push_back(NB_INTERFACE_NONE);//An array of output
            break;
        case NB_FUNC_GENERAL_GET_INTERFACE:
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_INTERFACE);
            break;
        case NB_FUNC_GENERAL_GET_REGISTED_ACCESSES:
            break;

        // 2 declaration & declaration_compound
        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_DECLARATION);
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_INT);
            break;
        // fake ports info just for getting declaration port num
        case NB_FUNC_DECLARATION_GET_INTERFACES:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES:
            vin.push_back(NB_INTERFACE_DECLARATION);
            vout.push_back(NB_INTERFACE_NONE);
            break;

        // 3 interface & interface_compound
        case NB_FUNC_INTERFACE_IS_SINGLETON://4
        case NB_FUNC_INTERFACE_ADD:
        case NB_FUNC_INTERFACE_REMOVE:
        case NB_FUNC_INTERFACE_GROUPS://5
        case NB_FUNC_INTERFACE_CEG_ASSIGNMENT:
        case NB_FUNC_INTERFACE_STORAGE_ASSIGNMENT:
        case NB_FUNC_INTERFACE_INTERFACE_CAST:
        case NB_FUNC_INTERFACE_SET_BUILTIN_INS:// private between objects6
        case NB_FUNC_INTERFACE_GET_BUILTIN_INS:// private between objects
            make_iany_onone_declaration(vin, vout);//TODO
            break;
        case NB_FUNC_INTERFACE_EQ:
        case NB_FUNC_INTERFACE_COVERS:
            vin.push_back(nb_id_t(NB_INTERFACE_NONE));
            vin.push_back(nb_id_t(NB_INTERFACE_INTERFACE));
            vout.push_back(nb_id_t(NB_INTERFACE_BOOL));
            break;
        case NB_FUNC_INTERFACE_CONVERT:
            vin.push_back(NB_INTERFACE_INTERFACE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_NONE);// to be determined by IS/Media
            break;
        case NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME:
        case NB_FUNC_INTERFACE_GET_DECLARATIONS://1
            vin.push_back(NB_INTERFACE_INTERFACE);
            vout.push_back(NB_INTERFACE_NONE);
            break;

        // 4 user object 
        //case NB_FUNC_USER_COMPOSE:
        //    break;
        //case NB_FUNC_USER_DECOMPOSE:
        //    break;
        case NB_FUNC_USER_GET_DESCRIPTOR: 
            break;

        case NB_FUNC_CORPSE_PRINT:
            vin.push_back(NB_INTERFACE_CORPSE);
            vout.push_back(NB_INTERFACE_STRING);
            break;
        case NB_FUNC_CORPSE_GET_NODE_INDEX:
            vin.push_back(NB_INTERFACE_CORPSE);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_CORPSE_GET_INPUT:
            vin.push_back(NB_INTERFACE_CORPSE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_CORPSE_GET_SUB_OBJ:
            vin.push_back(NB_INTERFACE_CORPSE);
            vout.push_back(NB_INTERFACE_CORPSE);
            break;
        case NB_FUNC_CORPSE_GET_REASON:
            vin.push_back(NB_INTERFACE_CORPSE);
            vout.push_back(NB_INTERFACE_NONE);
            break;

        // 5 boolean
        case NB_FUNC_BOOL_NOT:
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
        case NB_FUNC_BOOL_BREAK_TRUE:
        case NB_FUNC_BOOL_BREAK_FALSE:
            make_ibool_obool_declaration(vin, vout);
            break;
        case NB_FUNC_BOOL_AND:
        case NB_FUNC_BOOL_OR:
        case NB_FUNC_BOOL_EQ:
        case NB_FUNC_BOOL_NE:
            make_ibool_ibool_obool_declaration(vin, vout);
            break;
        case NB_FUNC_BOOL_TO_INT:
            vin.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_BOOL_TO_STRING:
            vin.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_STRING);
            break;
        case NB_FUNC_BOOL_TRUE_TO_EXCEPTION:
        case NB_FUNC_BOOL_FALSE_TO_EXCEPTION:
            vin.push_back(NB_INTERFACE_BOOL);
            vin.push_back(NB_INTERFACE_NONE);
            break;


        // 6 integer
        case NB_FUNC_INT_ADD:
        case NB_FUNC_INT_SUB:
        case NB_FUNC_INT_IMUL:
        case NB_FUNC_INT_IDIV:
            make_iint_iint_oint_declaration(vin, vout);
            break;
        case NB_FUNC_INT_IDIV_REM:
            make_iint_iint_oint_oint_declaration(vin, vout);
            break;
        case NB_FUNC_INT_EQ:
        case NB_FUNC_INT_LT:
            make_iint_iint_obool_declaration(vin, vout);
            break;
        case NB_FUNC_INT_INC:
        case NB_FUNC_INT_DEC:
            make_iint_oint_declaration(vin, vout);
            break;
        case NB_FUNC_INT_TO_STRING:
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_STRING);
            break;
        case NB_FUNC_INT_TO_FLOAT:
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_FLOAT);
            break;
        case NB_FUNC_INT_VERIFY:
            break;


        // 7 float
        case NB_FUNC_FLOAT_ADD:
        case NB_FUNC_FLOAT_SUB:
        case NB_FUNC_FLOAT_IMUL:
        case NB_FUNC_FLOAT_IDIV:
            make_ifloat_ifloat_ofloat_declaration(vin, vout);
            break;
        case NB_FUNC_FLOAT_EQ:
        case NB_FUNC_FLOAT_LT:
            make_ifloat_ifloat_obool_declaration(vin, vout);
            break;
        case NB_FUNC_FLOAT_TO_INT:
            vin.push_back(NB_INTERFACE_FLOAT);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_FLOAT_TO_STRING:
            vin.push_back(NB_INTERFACE_FLOAT);
            vout.push_back(NB_INTERFACE_STRING);
            break;

        // 8 string
        case NB_FUNC_STR_APPEND:
            make_istr_istr_ostr_declaration(vin, vout);
            break;
        case NB_FUNC_STR_FIND:
            make_istr_istr_oint_declaration(vin, vout);
            break;
        case NB_FUNC_STR_SUBSTR:
            make_istr_iint_iint_ostr_declaration(vin, vout);
            break;
        case NB_FUNC_STR_SIZE:
            make_istr_oint_declaration(vin, vout);
            break;
        case NB_FUNC_STR_SPLITAT:
            make_istr_iint_ostr_ostr_declaration(vin, vout);
            break;
        //case NB_FUNC_STR_COMPARE:
        //    make_istr_istr_obool_declaration(vin, vout);
        //    break;
        case NB_FUNC_STR_TO_INT:
            vin.push_back(NB_INTERFACE_STRING);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_STR_TO_BOOL:
            vin.push_back(NB_INTERFACE_STRING);
            vin.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_BOOL);
            break;
        case NB_FUNC_STR_TO_FLOAT:
            vin.push_back(NB_INTERFACE_STRING);
            vin.push_back(NB_INTERFACE_FLOAT);
            vout.push_back(NB_INTERFACE_FLOAT);
            break;
        case NB_FUNC_STR_TO_INTERVAL:
            vin.push_back(NB_INTERFACE_STRING);
            vin.push_back(NB_INTERFACE_INTERVAL);
            vout.push_back(NB_INTERFACE_INTERVAL);
            break;
        case NB_FUNC_STR_TO_TIME:
            vin.push_back(NB_INTERFACE_STRING);
            vin.push_back(NB_INTERFACE_TIME);
            vout.push_back(NB_INTERFACE_TIME);
            break;
        case NB_FUNC_STR_TO_BYTES:
            vin.push_back(NB_INTERFACE_STRING);
            vout.push_back(NB_INTERFACE_BYTES);
            break;


        // 9 bytes
        case NB_FUNC_BYTES_JOIN:
            make_ibyte_ibyte_obyte_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_RANGE:
            make_ibyte_iint_iint_obyte_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_SIZE:
            make_ibyte_oint_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_SPLIT:
            make_ibyte_obyte_obyte_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_SPLITAT:
            make_ibyte_iint_obyte_obyte_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_CRC:
            make_ibyte_obool_declaration(vin, vout);
            break;
        case NB_FUNC_BYTES_TO_STR:
            vin.push_back(NB_INTERFACE_BYTES);
            vout.push_back(NB_INTERFACE_STRING);
            break;

        // 10 interval
        case NB_FUNC_INTERVAL_GET:
            make_iitv_oint_oint_declaration(vin, vout);
            break;
        case NB_FUNC_INTERVAL_ADD:
        case NB_FUNC_INTERVAL_SUB:
            make_iitv_iitv_oitv_declaration(vin, vout);
            break;
        /*case NB_FUNC_INTERVAL_MUL:
            break;
        case NB_FUNC_INTERVAL_DIV:
            break;*/
        case NB_FUNC_INTERVAL_TO_STRING:
            vin.push_back(NB_INTERFACE_INTERVAL);
            vout.push_back(NB_INTERFACE_STRING);
            break;

        // 11 time
        case NB_FUNC_TIME_GET:
            vin.push_back(NB_INTERFACE_TIME);
            vout.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_TIME_SHOW:
            make_itime_o10int_declaration(vin, vout);
            break;
        case NB_FUNC_TIME_ADD:
        case NB_FUNC_TIME_SUB:
            make_itime_iitv_otime_declaration(vin, vout);
            break;
        case NB_FUNC_TIME_SUB_TIME:
            make_itime_itime_oitv_declaration(vin, vout);
            break;
        case NB_FUNC_TIME_CURRENT:
            make_itime_otime_declaration(vin, vout);
            break;
        case NB_FUNC_TIME_TO_STRING:
            vin.push_back(NB_INTERFACE_TIME);
            vout.push_back(NB_INTERFACE_STRING);
            break;

        // array & map
        // fetch from duke_media_constant_def, not here!!
        case NB_FUNC_ARRAY_GET:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_ARRAY_GETHEAD:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_ARRAY_GETTAIL:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_ARRAY_ADDHEAD:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_ADDTAIL:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_SET:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_INSERT:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_FIND:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_ARRAY_ERASE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_JOIN:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_RANGE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_SIZE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_ARRAY_REVERSE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_SPLIT:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_UNIONSET:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_INTERSECTIONSET:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_BOOL);
            break;

        case NB_FUNC_ARRAY_SETTYPE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_ARRAY_GETTYPE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_ARRAY_CONTENT_COMPARE:
            vin.push_back(NB_INTERFACE_ARRAY);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_BOOL);
            break;


        case NB_FUNC_MAP_GET:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_MAP_INSERT:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_MAP);
            break;
        case NB_FUNC_MAP_REPLACE:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_MAP);
            break;
        case NB_FUNC_MAP_UPDATE:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_MAP);
            break;
        case NB_FUNC_MAP_HAS_KEY:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_BOOL);
            break;
        case NB_FUNC_MAP_ERASE:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_MAP);
            break;
        case NB_FUNC_MAP_SIZE:
            vin.push_back(NB_INTERFACE_MAP);
            vout.push_back(NB_INTERFACE_INT);
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            vin.push_back(NB_INTERFACE_MAP);
            vout.push_back(NB_INTERFACE_ARRAY);
            break;
        case NB_FUNC_MAP_GET_OR:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_MAP_SETTYPE:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_MAP);
            break;
        case NB_FUNC_MAP_GETTYPE:
            vin.push_back(NB_INTERFACE_MAP);
            vout.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        case NB_FUNC_MAP_CONTENT_COMPARE:
            vin.push_back(NB_INTERFACE_MAP);
            vin.push_back(NB_INTERFACE_NONE);
            vout.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_BOOL);
            vout.push_back(NB_INTERFACE_BOOL);
            break;


        // 14 bridge interface
        case NB_FUNC_BRIDGE_INTERFACE_GET_DECLARATIONS:
            break;
        case NB_FUNC_BRIDGE_INTERFACE_EQ:
            break;
        case NB_FUNC_BRIDGE_INTERFACE_COVERS:
            break;
        case NB_FUNC_BRIDGE_INTERFACE_CONVERT:
            break;

        case NB_FUNC_CONTAINER_INFORM_STORE_SINGLETON_OBJECT:
            break;
        case NB_FUNC_CONTAINER_GET_ANCHOR:
            break;

        case NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION:
            break;
        case NB_FUNC_DESCRIPTOR_GET_SUBOBJ_INTERFACES:
            break;

        case NB_FUNC_ACCESS_GET_CONTAINER:
            break;
        case NB_FUNC_ACCESS_GET_ANCHOR:
            break;
        case NB_FUNC_ACCESS_IS_REGISTED:
            break;

        case NB_FUNC_ANCHOR_GET_CONTAINER:
            break;
        case NB_FUNC_ANCHOR_GENERATE_ACCESS:
            break;

        // GET_STROAGE_TYPE obsoleted
        //case NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE:
        //    break;
        case NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER:
            //make_ides_oaccess_declaration(vin, vout);
            vin.push_back(NB_INTERFACE_CONTAINER_DEF);
            vout.push_back(NB_INTERFACE_ROOT_ACCESS);
            break;
        case NB_FUNC_CONTAINER_DEF_GET_ANCHOR_INTERFACE:
            vin.push_back(NB_INTERFACE_CONTAINER_DEF);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_INTERFACE);
            break;

        // storage
        //

        //case NB_FUNC_BRIDGE_COMPOSE:
        //    break;
        //case NB_FUNC_BRIDGE_DECOMPOSE:
        //    break;
        case NB_FUNC_BRIDGE_GET_DESCRIPTOR:
            break;

        // access
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            make_ides_oaccess_declaration(vin, vout);
            break;
        case NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER:
            break;
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
        {
            vin.push_back(NB_INTERFACE_ROOT_ACCESS);
            vout.push_back(NB_INTERFACE_CONTAINER_DEF);
            break;
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            make_iint_oanc_declaration(vin, vout);
            break;
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
        {
            /* input an int as index of the anchor,
               output the coresponding access
               since we don't know the access in advance,
               the out interface is none */
            vin.push_back(NB_INTERFACE_ROOT_ACCESS);
            vin.push_back(NB_INTERFACE_INT);
            vout.push_back(NB_INTERFACE_NONE);
            break;
        }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            break;

        default:
            LOG_ERROR("obj_impl_declaration::get_interfaces() : unknown instruction type!");
            //assert(!"Unknown instruction type!");
            break;
    }

    return true;
}

void obj_impl_declaration::make_ides_oaccess_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ho(NB_INTERFACE_ROOT_ACCESS);
    out.push_back(ho);
}

void obj_impl_declaration::make_iint_oanc_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hi(NB_INTERFACE_ROOT_ACCESS);
    nb_id_t hii(NB_INTERFACE_INT);
    nb_id_t ho(NB_INTERFACE_ANCHOR);
    in.push_back(hi);
    in.push_back(hii);
    out.push_back(ho);
}

void obj_impl_declaration::make_iany_onone_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    in.push_back(hn);
}

void obj_impl_declaration::make_iany_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hn);
    out.push_back(hb);
}

void obj_impl_declaration::make_iany_idecl_iany_ibool_oany_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hn);
    in.push_back(hn);// TODO decl
    in.push_back(hn);
    in.push_back(hb);
    out.push_back(hn);
}

void obj_impl_declaration::make_iany_idecl_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    nb_id_t harr(NB_INTERFACE_ARRAY);
    in.push_back(hn);
    in.push_back(hn);// TODO decl
    out.push_back(harr);
}

void obj_impl_declaration::make_iany_idecl_oany_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    in.push_back(hn);
    in.push_back(hn);// TODO decl
    out.push_back(hn);
}

void obj_impl_declaration::make_iany_oany_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hn(NB_INTERFACE_NONE);
    in.push_back(hn);
    out.push_back(hn);
}

void obj_impl_declaration::make_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hb);
    out.push_back(hb);
}

void obj_impl_declaration::make_ibool_ibool_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hb);
    in.push_back(hb);
    out.push_back(hb);
}

void obj_impl_declaration::make_iint_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hi);
    in.push_back(hi);
    out.push_back(hi);
}
void obj_impl_declaration::make_iint_iint_oint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hi);
    in.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
}


void obj_impl_declaration::make_iint_iint_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hi(NB_INTERFACE_INT);
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hi);
    in.push_back(hi);
    out.push_back(hb);
}

void obj_impl_declaration::make_iint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hi);
    out.push_back(hi);
}

void obj_impl_declaration::make_ifloat_ifloat_ofloat_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hf(NB_INTERFACE_FLOAT);
    in.push_back(hf);
    in.push_back(hf);
    out.push_back(hf);
}

void obj_impl_declaration::make_ifloat_ifloat_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hf(NB_INTERFACE_FLOAT);
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hf);
    in.push_back(hf);
    out.push_back(hb);
}

void obj_impl_declaration::make_istr_istr_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    in.push_back(hs);
    in.push_back(hs);
    out.push_back(hs);
}

void obj_impl_declaration::make_istr_iint_iint_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hs);
    in.push_back(hi);
    in.push_back(hi);
    out.push_back(hs);
}

void obj_impl_declaration::make_istr_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hs);
    out.push_back(hi);
}

void obj_impl_declaration::make_istr_istr_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hs);
    in.push_back(hs);
    out.push_back(hi);
}
void obj_impl_declaration::make_istr_iint_ostr_ostr_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hs);
    in.push_back(hi);
    out.push_back(hs);
    out.push_back(hs);
}

void obj_impl_declaration::make_istr_istr_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hs(NB_INTERFACE_STRING);
    nb_id_t hb(NB_INTERFACE_BOOL);
    in.push_back(hs);
    in.push_back(hs);
    out.push_back(hb);
}

void obj_impl_declaration::make_ibyte_ibyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    in.push_back(hbs);
    in.push_back(hbs);
    out.push_back(hbs);
}

void obj_impl_declaration::make_ibyte_iint_iint_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hbs);
    in.push_back(hi);
    in.push_back(hi);
    out.push_back(hbs);
}

void obj_impl_declaration::make_ibyte_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hbs);
    out.push_back(hi);
}

void obj_impl_declaration::make_ibyte_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    in.push_back(hbs);
    out.push_back(hbs);
    out.push_back(hbs);
}

void obj_impl_declaration::make_ibyte_iint_obyte_obyte_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hbs);
    in.push_back(hi);
    out.push_back(hbs);
    out.push_back(hbs);
}

void obj_impl_declaration::make_ibyte_obool_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hbs(NB_INTERFACE_BYTES);
    nb_id_t hb(NB_INTERFACE_INT);
    in.push_back(hbs);
    out.push_back(hb);
}

/*void obj_impl_declaration::make_iitv_o10int_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hitv(NB_INTERFACE_INTERVAL);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(hitv);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
}*/

void obj_impl_declaration::make_iitv_oint_oint_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ht(NB_INTERFACE_INTERVAL);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(ht);
    out.push_back(hi);
    out.push_back(hi);
}

void obj_impl_declaration::make_iitv_iitv_oitv_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hitv(NB_INTERFACE_INTERVAL);
    in.push_back(hitv);
    in.push_back(hitv);
    out.push_back(hitv);
}

void obj_impl_declaration::make_itime_o10int_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ht(NB_INTERFACE_TIME);
    nb_id_t hi(NB_INTERFACE_INT);
    in.push_back(ht);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
    out.push_back(hi);
}

void obj_impl_declaration::make_itime_iitv_otime_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ht(NB_INTERFACE_TIME);
    nb_id_t hitv(NB_INTERFACE_INTERVAL);
    in.push_back(ht);
    in.push_back(hitv);
    out.push_back(ht);
}

void obj_impl_declaration::make_itime_itime_oitv_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ht(NB_INTERFACE_TIME);
    nb_id_t hi(NB_INTERFACE_INTERVAL);
    in.push_back(ht);
    in.push_back(ht);
    out.push_back(hi);
}

void obj_impl_declaration::make_itime_otime_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t ht(NB_INTERFACE_TIME);
    in.push_back(ht);
    out.push_back(ht);
}

void obj_impl_declaration::make_iuser_oarray_declaration(nb_id_vector& in, nb_id_vector& out)
{
    nb_id_t hu(NB_INTERFACE_USER);
    nb_id_t har(NB_INTERFACE_ARRAY);
    in.push_back(hu);
    out.push_back(har);
}

bool obj_impl_declaration::get_instruction_name(const nb_id_t& ins, std::string& name)
{
    assert(ins.is_function_instruction());
    if( !ins.is_function_instruction())
        return false;

    switch(ins.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
            name = "get name";
            break;
        case NB_FUNC_GENERAL_IS_NULL:
            name = "is null";
            break;
        case NB_FUNC_GENERAL_IS_SINGLETON:
            name = "is singleton";
            break;
        case NB_FUNC_GENERAL_IS_JUSTID:
            name = "is just id";
            break;
        case NB_FUNC_GENERAL_IS_BUILTIN:
            name = "is builtin";
            break;
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
            name = "is exportable";
            break;
        case NB_FUNC_GENERAL_IS_LOCAL:
            name = "is local";
            break;
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
            name = "is value compared";
            break;
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
            name = "exception if null";
            break;
        case NB_FUNC_GENERAL_COMPARE:
            name = "compare";
            break;
        case NB_FUNC_GENERAL_GET_INTERFACE:
            name = "get interface";
            break;
        case NB_FUNC_GENERAL_GET_REGISTED_ACCESSES:
            name = "get registed accesses";
            break;
        case NB_FUNC_GENERAL_RUN:
            name = "run";
            break;

        case NB_FUNC_DECLARATION_GET_INTERFACES:
            name = "get interfaces";
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
            name = "get in ports";
            break;
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:         
            name = "get out ports";
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
            name = "get in port num";
            break;
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
            name = "get out port num";
            break;
        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
            name = "get origin decl";
            break;
        case NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES:
            name = "get expanded interfaces";
            break;


        case NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME:
            name = "get decl names";
            break;
        case NB_FUNC_INTERFACE_GET_DECLARATIONS:
            name = "get decls";
            break;
        case NB_FUNC_INTERFACE_EQ:
            name = "eq";
            break;
        case NB_FUNC_INTERFACE_COVERS:
            name = "covers";
            break;
        case NB_FUNC_INTERFACE_CONVERT:
            name = "convert";
            break;
        case NB_FUNC_INTERFACE_IS_SINGLETON:
            name = "is singleton";
            break;
        case NB_FUNC_INTERFACE_ADD:
            name = "add";
            break;
        case NB_FUNC_INTERFACE_REMOVE:
            name = "remove";
            break;
        case NB_FUNC_INTERFACE_GROUPS:
            name = "groups";
            break;
        case NB_FUNC_INTERFACE_CEG_ASSIGNMENT:
            name = "get assignment";
            break;
        case NB_FUNC_INTERFACE_STORAGE_ASSIGNMENT:
            name = "storage assignment";
            break;
        case NB_FUNC_INTERFACE_INTERFACE_CAST:
            name = "interface cast";
            break;

        case NB_FUNC_USER_GET_DESCRIPTOR:
            name = "get descriptor";
            break;
        //case NB_FUNC_USER_COMPOSE:
        //    name = "compose";
        //    break;
        //case NB_FUNC_USER_DECOMPOSE:
        //    name = "decompose";
        //    break;

        case NB_FUNC_CORPSE_PRINT:
            name = "print";
            break;
        case NB_FUNC_CORPSE_GET_NODE_INDEX:
            name = "get node index";
            break;
        case NB_FUNC_CORPSE_GET_INPUT:
            name = "get inputs";
            break;
        case NB_FUNC_CORPSE_GET_SUB_OBJ:
            name = "get sub corpse";
            break;
        case NB_FUNC_CORPSE_GET_REASON:
            name = "get reason";
            break;

        case NB_FUNC_BOOL_NOT:
            name = "not";
            break;
        case NB_FUNC_BOOL_AND:
            name = "and";
            break;
        case NB_FUNC_BOOL_OR:
            name = "or";
            break;
        case NB_FUNC_BOOL_EQ:
            name = "eq";
            break;
        case NB_FUNC_BOOL_NE:
            name = "ne";
            break;
        case NB_FUNC_BOOL_EXCEPTION_TRUE:
            name = "exception true";
            break;
        case NB_FUNC_BOOL_EXCEPTION_FALSE:
            name = "exception false";
            break;
        case NB_FUNC_BOOL_BREAK_TRUE:
            name = "break true";
            break;
        case NB_FUNC_BOOL_BREAK_FALSE:
            name = "break false";
            break;
        case NB_FUNC_BOOL_TO_INT:
            name = "to int";
            break;
        case NB_FUNC_BOOL_TO_STRING:
            name = "to string";
            break;
        case NB_FUNC_BOOL_TRUE_TO_EXCEPTION:
            name = "true to exception";
            break;
        case NB_FUNC_BOOL_FALSE_TO_EXCEPTION:
            name = "false to exception";
            break;

        case NB_FUNC_INT_ADD:
            name = "add";
            break;
        case NB_FUNC_INT_SUB:
            name = "sub";
            break;
        case NB_FUNC_INT_IMUL:
            name = "imul";
            break;
        case NB_FUNC_INT_IDIV:
            name = "idiv";
            break;
        case NB_FUNC_INT_IDIV_REM:
            name = "idiv_rem";
            break;
        case NB_FUNC_INT_EQ:
            name = "eq";
            break;
        case NB_FUNC_INT_LT:
            name = "lt";
            break;
        case NB_FUNC_INT_INC:
            name = "inc";
            break;
        case NB_FUNC_INT_DEC:
            name = "dec";
            break;
        case NB_FUNC_INT_VERIFY:
            name = "verify";
            break;
        case NB_FUNC_INT_TO_STRING:
            name = "to string";
            break;
        case NB_FUNC_INT_TO_FLOAT:
            name = "to float";
            break;


        case NB_FUNC_FLOAT_ADD:
            name = "add";
            break;
        case NB_FUNC_FLOAT_SUB:
            name = "sub";
            break;
        case NB_FUNC_FLOAT_IMUL:
            name = "mul";
            break;
        case NB_FUNC_FLOAT_IDIV:
            name = "div";
            break;
        case NB_FUNC_FLOAT_EQ:
            name = "eq";
            break;
        case NB_FUNC_FLOAT_LT:
            name = "lt";
            break;
        case NB_FUNC_FLOAT_TO_INT:
            name = "to int";
            break;
        case NB_FUNC_FLOAT_TO_STRING:
            name = "to string";
            break;


        case NB_FUNC_STR_APPEND:
            name = "append";
            break;
        case NB_FUNC_STR_FIND:
            name = "find";
            break;
        case NB_FUNC_STR_SUBSTR:
            name = "substr";
            break;
        case NB_FUNC_STR_SIZE:
            name = "size";
            break;
        case NB_FUNC_STR_SPLITAT:
            name = "split at";
            break;
        //case NB_FUNC_STR_COMPARE:
        //    name = "compare";
        //    break;
        case NB_FUNC_STR_TO_INT:
            name = "to int";
            break;
        case NB_FUNC_STR_TO_BOOL:
            name = "to bool";
            break;
        case NB_FUNC_STR_TO_FLOAT:
            name = "to float";
            break;
        case NB_FUNC_STR_TO_INTERVAL:
            name = "to interval";
            break;
        case NB_FUNC_STR_TO_TIME:
            name = "to time";
            break;
        case NB_FUNC_STR_TO_BYTES:
            name = "to bytes";
            break;


        case NB_FUNC_BYTES_JOIN:
            name = "join";
            break;
        case NB_FUNC_BYTES_RANGE:
            name = "range";
            break;
        case NB_FUNC_BYTES_SIZE:
            name = "size";
            break;
        case NB_FUNC_BYTES_SPLIT:
            name = "split";
            break;
        case NB_FUNC_BYTES_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_BYTES_CRC:
            name = "crc";
            break;
        case NB_FUNC_BYTES_TO_STR:
            name = "to string";
            break;

        case NB_FUNC_INTERVAL_GET:
            name = "get";
            break;
        case NB_FUNC_INTERVAL_ADD:
            name = "add";
            break;
        case NB_FUNC_INTERVAL_SUB:
            name = "sub";
            break;
        /*case NB_FUNC_INTERVAL_MUL:
            name = "mul";
            break;
        case NB_FUNC_INTERVAL_DIV:
            name = "div";
            break;*/
        case NB_FUNC_INTERVAL_TO_STRING:
            name = "to_string";
            break;


        case NB_FUNC_TIME_GET:
            name = "get";
            break;
        case NB_FUNC_TIME_SHOW:
            name = "show";
            break;
        case NB_FUNC_TIME_CURRENT:
            name = "current";
            break;
        case NB_FUNC_TIME_ADD:
            name = "add";
            break;
        case NB_FUNC_TIME_SUB:
            name = "sub";
            break;
        case NB_FUNC_TIME_SUB_TIME:
            name = "sub_time";
            break;
        case NB_FUNC_TIME_TO_STRING:
            name = "to string";
            break;


        case NB_FUNC_ARRAY_SETTYPE:
            name = "set type";
            break;
        case NB_FUNC_ARRAY_GETTYPE:
            name = "get type";
            break;
        case NB_FUNC_ARRAY_GET:
            name = "get";
            break;
        case NB_FUNC_ARRAY_GETHEAD:
            name = "get head";
            break;
        case NB_FUNC_ARRAY_GETTAIL:
            name = "get tail";
            break;
        case NB_FUNC_ARRAY_ADDHEAD:
            name = "add head";
            break;
        case NB_FUNC_ARRAY_ADDTAIL:
            name = "add tail";
            break;
        case NB_FUNC_ARRAY_SET:
            name = "set";
            break;
        case NB_FUNC_ARRAY_FIND:
            name = "find";
            break;
        case NB_FUNC_ARRAY_ERASE:
            name = "erase";
            break;
        case NB_FUNC_ARRAY_REVERSE:
            name = "reverse";
            break;
        case NB_FUNC_ARRAY_INSERT:
            name = "insert";
            break;
        case NB_FUNC_ARRAY_JOIN:
            name = "join";
            break;
        case NB_FUNC_ARRAY_RANGE:
            name = "range";
            break;
        case NB_FUNC_ARRAY_SIZE:
            name = "size";
            break;
        case NB_FUNC_ARRAY_SPLIT:
            name = "split";
            break;
        case NB_FUNC_ARRAY_SPLITAT:
            name = "split at";
            break;
        case NB_FUNC_ARRAY_UNIONSET:
            name = "union set";
            break;
        case NB_FUNC_ARRAY_INTERSECTIONSET:
            name = "intersection set";
            break;
        case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            name = "complementary set";
            break;
        case NB_FUNC_ARRAY_INCLUSION:
            name = "inclusion";
            break;
        case NB_FUNC_ARRAY_CONTENT_COMPARE:
            name = "content compare";
            break;

        case NB_FUNC_MAP_SETTYPE:
            name = "set type";
            break;
        case NB_FUNC_MAP_GETTYPE:
            name = "get type";
            break;
        case NB_FUNC_MAP_GET:
            name = "get";
            break;
        case NB_FUNC_MAP_GET_OR:
            name = "get_or";
            break;
        case NB_FUNC_MAP_INSERT:
            name = "insert";
            break;
        case NB_FUNC_MAP_REPLACE:
            name = "replace";
            break;
        case NB_FUNC_MAP_UPDATE:
            name = "update";
            break;
        case NB_FUNC_MAP_ERASE:
            name = "erase";
            break;
        case NB_FUNC_MAP_HAS_KEY:
            name = "has key";
            break;
        case NB_FUNC_MAP_SIZE:
            name = "size";
            break;
        case NB_FUNC_MAP_GETALLKEYS:
            name = "get all keys";
            break;
        case NB_FUNC_MAP_CONTENT_COMPARE:
            name = "content compare";
            break;

        case NB_FUNC_STORAGE_GET_SINGLE:
            name = "get single";
            break;
        case NB_FUNC_STORAGE_GET_MORE:
            name = "get more";
            break;
        case NB_FUNC_STORAGE_HAS_KEY:
            name = "has key";
            break;
        case NB_FUNC_STORAGE_REPLACE_ONE:
            name = "replace one";
            break;
        case NB_FUNC_STORAGE_DELETE_ONE:
            name = "delete one";
            break;
        case NB_FUNC_STORAGE_SET_ONE:
            name = "set one";
            break;
        case NB_FUNC_STORAGE_UPDATE:
            name = "update";
            break;
        case NB_FUNC_STORAGE_SIZE:
            name = "size";
            break;
        case NB_FUNC_STORAGE_GET_RANGE:
            name = "get range";
            break;


        case NB_FUNC_BRIDGE_INTERFACE_GET_DECLARATIONS:
            name = "get declarations";
            break;
        case NB_FUNC_BRIDGE_INTERFACE_EQ:
            name = "eq";
            break;
        case NB_FUNC_BRIDGE_INTERFACE_COVERS:
            name = "covers";
            break;
        case NB_FUNC_BRIDGE_INTERFACE_CONVERT:
            name = "convert";
            break;

        case NB_FUNC_CONTAINER_INFORM_STORE_SINGLETON_OBJECT:
            name = "inform store singleton object";
            break;
        case NB_FUNC_CONTAINER_GET_ANCHOR:
            name = "get anchor";
            break;

        case NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION:
            name = "get implementation";
            break;
        case NB_FUNC_DESCRIPTOR_GET_SUBOBJ_INTERFACES:
            name = "get subobj interfaces";
            break;

        case NB_FUNC_ACCESS_GET_CONTAINER:
            name = "get container";
            break;
        case NB_FUNC_ACCESS_GET_ANCHOR:
            name = "get anchor";
            break;
        case NB_FUNC_ACCESS_IS_REGISTED:
            name = "is registed";
            break;

        case NB_FUNC_ANCHOR_GET_CONTAINER:
            name = "get container";
            break;
        case NB_FUNC_ANCHOR_GENERATE_ACCESS:
            name = "generate access";
            break;

        // container def
        case NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER:
            name = "create container";
            break;
        // obsoleted
        //case NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE:
        //    name = "get storage type";
        //    break;
        case NB_FUNC_CONTAINER_DEF_GET_ANCHOR_INTERFACE:
            name = "get anchor interface";
            break;
            
        //storage
        //

        //case NB_FUNC_BRIDGE_COMPOSE:
        //    name = "compose";
        //    break;
        //case NB_FUNC_BRIDGE_DECOMPOSE:
        //    name = "decompose";
        //    break;
        case NB_FUNC_BRIDGE_GET_DESCRIPTOR:
            name = "get descriptor";
            break;

        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            name = "create container";
            break;
        case NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER:
            name = "destroy container";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
            name = "get container def";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
            name = "get storage";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
            name = "get storage type";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            name = "get anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
            name = "generate access from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            name = "get access interface from anchor";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST:
            name = "get anchor list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST:
            name = "get storage list";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS:
            name = "get access";
            break;
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT:
            name = "get storage content";
            break;
        default:
            name = "";
            LOG_ERROR("obj_impl_declaration::get_instruction_name : unknown instruction type");
            break;
    }

    return true;
}

bool obj_impl_declaration::get_name(nb_id_t& out)
{
    //std::string name;
    //if(get_instruction_name(m_obj_id, name))
    //    return request_string_object(name, out);
    
    return false;
}

bool obj_impl_declaration::get_interfaces(nb_id_vector& vout)
{
    // two array objects
    //array_data_t iport;
    //iport.type = nb_id_t(NB_INTERFACE_NONE); 
    //iport.objs = m_viif;

    //nb_id_t in_array_id;
    //request_nb_id_info in_array_info;
    //in_array_info.committer_id = m_param.host_committer_id;
    //in_array_info.type = NBID_TYPE_OBJECT_ARRAY;
    //obj_impl_array::pack(iport, nb_id_t(), in_array_info.raw_data);
    //if (!request_nb_id(m_param.host_committer_id, in_array_info, in_array_id))
    //    return false;

    //vout.push_back(in_array_id);

    //array_data_t oport;
    //oport.type = nb_id_t(NB_INTERFACE_NONE); 
    //oport.objs = m_voif;

    //nb_id_t out_array_id;
    //request_nb_id_info out_array_info;
    //out_array_info.committer_id = m_param.host_committer_id;
    //out_array_info.type = NBID_TYPE_OBJECT_ARRAY;
    //obj_impl_array::pack(iport, nb_id_t(), out_array_info.raw_data);
    //if (!request_nb_id(m_param.host_committer_id, out_array_info, out_array_id))
    //    return false;

    //vout.push_back(out_array_id);

    return true;
}

bool obj_impl_declaration::get_general_interfaces(nb_id_vector& vifs)
{
    return true;
}

bool obj_impl_declaration::get_in_ports(nb_id_vector& viif)
{
    viif = m_viif;
    return true;
}

bool obj_impl_declaration::get_out_ports(nb_id_vector& voif)
{
    voif = m_voif;
    return true;
}

bool obj_impl_declaration::get_iport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);

    int value = m_viif.size();
    num.set_value(value);
    return true;
}

bool obj_impl_declaration::get_oport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);

    int value = m_voif.size();
    num.set_value(value);
    return true;
}

bool obj_impl_declaration::get_property(const nb_id_t& input, object_ids& output)
{ 
    LOG_DEBUG("*** obj_impl_declaration::get_property()");

    switch (input.get_func_type())
    {
        case NB_FUNC_DECLARATION_GET_INTERFACES:
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
            get_in_ports(output.ids);
            break;
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
            get_out_ports(output.ids);
            break;
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
        {
            nb_id_t result;
            get_iport_number(result);
            output.ids.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
        {
            nb_id_t result;
            get_oport_number(result);
            output.ids.push_back(result);
            break;
        }
        default:
            break;
    }

    return true;    

}

// vim:set tabstop=4 shiftwidth=4 expandtab:
