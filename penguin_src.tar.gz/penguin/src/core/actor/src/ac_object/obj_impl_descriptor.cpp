/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_object/obj_impl_descriptor.h"

// stdx header files
#include "stdx_json.h"

#include "ac_message_type.h"

obj_impl_descriptor::obj_impl_descriptor(const nb_id_t& obj_id, 
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_descriptor());
    set_value(raw_data);
} 

obj_impl_descriptor::~obj_impl_descriptor()
{
} 

bool obj_impl_descriptor::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_descriptor::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_descriptor::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_descriptor::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);

    return true;
}

bool obj_impl_descriptor::pack(const descriptor_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer  packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.visualInformation);
    
    int funcs_size = logic_data.funcs.size();
    nb_id_t nb_funcs( NBID_TYPE_OBJECT_INT ); 
    nb_funcs.set_value(funcs_size);
    packer.pack(nb_funcs);
    for(int j=0; j < funcs_size; ++j)
    {
        packer.pack(logic_data.funcs[j].declaration_id);
        packer.pack(logic_data.funcs[j].implementation_id);
    }

    nb_id_t nb_interface( NBID_TYPE_OBJECT_INT ); 
    int if_size = logic_data.subobj_interfaces.size();
    nb_interface.set_value(if_size);
    packer.pack(nb_interface);
    packer.pack(logic_data.subobj_interfaces);

    //raw_data.id_value = packer.get_pack_data();
    raw_data= packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_descriptor::unpack(const content& raw_data, nb_id_t& id, descriptor_data_t& logic_data)
{
    id = raw_data.object_id; 
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int nb_index = -1;

    logic_data.name = unpack.unpack_string(0);
    logic_data.visualInformation = unpack.unpack_id(++nb_index);

    int funcs_size = 0;
    unpack.unpack_id(++nb_index).get_value(funcs_size);
    for(int j=0; j < funcs_size; ++j)
    {
       func_pair_t func_data; 
       func_data.declaration_id = unpack.unpack_id(++nb_index);
       func_data.implementation_id = unpack.unpack_id(++nb_index);
       logic_data.funcs.push_back(func_data);
    }

    int interface_size = 0; 
    unpack.unpack_id(++nb_index).get_value(interface_size);
    for(int j=0; j < interface_size; ++j)
    {
       logic_data.subobj_interfaces.push_back(unpack.unpack_id(++nb_index));
    }

    return true; 
}
bool obj_impl_descriptor::json_pack(const descriptor_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    // pack nb_id_pair_vector funcs
    stdx::json_array* pArr = new(std::nothrow) stdx::json_array();
    assert(pArr);
    for(std::vector<func_pair_t>::const_iterator it = logic_data.funcs.begin(); 
        it != logic_data.funcs.end(); 
        ++it)
    {
        stdx::json_object* obj2 = new stdx::json_object();
        assert(obj2);
        obj2->insert("declaration_id", new stdx::json_string(it->declaration_id.str()));
        obj2->insert("implementation_id", new stdx::json_string(it->implementation_id.str()));
        pArr->push_back(obj2);
    }
    pObj->insert("funcs", pArr);
    // end funcs

    // pack nb_id_vector subobj_interfaces
    pArr = new(std::nothrow) stdx::json_array();
    assert(pArr);
    std::vector<nb_id_t>::const_iterator itx = logic_data.subobj_interfaces.begin();
    while(itx != logic_data.subobj_interfaces.end())
    {
        pArr->push_back(new stdx::json_string(itx->str()));
        ++itx;
    }
    pObj->insert("subobj_interfaces", pArr);
    // end subobj_interfaces

    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
    // save all internal ids
    raw_data.id_value.ids.clear();
    raw_data.id_value.ids.assign(logic_data.subobj_interfaces.begin(), logic_data.subobj_interfaces.end());
    func_vector::const_iterator itFuncs = logic_data.funcs.begin();
    while( itFuncs != logic_data.funcs.end())
    {
        raw_data.id_value.ids.push_back(itFuncs->declaration_id);
        raw_data.id_value.ids.push_back(itFuncs->implementation_id);
        ++itFuncs;
    }
    // save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);  
    return true;    
}

bool obj_impl_descriptor::json_unpack(const content& raw_data, 
        nb_id_t& id,
        descriptor_data_t& logic_data)
{
    id = raw_data.object_id;

    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    logic_data.name = pObj->find("name")->get_string();

    // unpack nb_id_pair_vector funcs
    logic_data.funcs.clear();
    stdx::json_array* pArr = dynamic_cast<stdx::json_array*>(pObj->find("funcs"));
    assert(pArr);
    for(int i=0; i < pArr->size(); ++i)
    {
        stdx::json_object* pSubObj = dynamic_cast<stdx::json_object*>(pArr->at(i));
        assert(pSubObj);
        func_pair_t funcpair;
        funcpair.declaration_id.str((pSubObj->find("declaration_id"))->get_string());
        funcpair.implementation_id.str((pSubObj->find("implementation_id"))->get_string());
        logic_data.funcs.push_back(funcpair);
    }
    // end funcs

    // unpack nb_id_vector subobj_interfaces
    logic_data.subobj_interfaces.clear();
    pArr = dynamic_cast<stdx::json_array*>(pObj->find("subobj_interfaces"));
    assert(pArr);
    for(int i=0; i < pArr->size(); ++i)
    {
        stdx::json_node* pNode = pArr->at(i);
        logic_data.subobj_interfaces.push_back(nb_id_t(pNode->get_string()));
    }
    // end subobj_interfaces

    return true;
}

bool obj_impl_descriptor::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_descriptor::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
