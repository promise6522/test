/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/obj_impl_decl_compound.h"
#include"stdx_json.h"
#include<boost/shared_ptr.hpp>

obj_impl_bridge::obj_impl_bridge(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{ 
    assert(obj_id.is_bridge_object());
    set_value(raw_data);
    //set_builtin_instructions();
} 

obj_impl_bridge::~obj_impl_bridge()
{
}

bool obj_impl_bridge::set_builtin_instructions()
{
    LOG_DEBUG("*** obj_impl_bridge::set_builtin_instructions()");

    time_t tm;    
    time(&tm);
    req_num_t req_num = req_num_t(tm, true);
    object_get_value_async(m_cData.interface, req_num);

    return true; 
}

bool obj_impl_bridge::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_bridge::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_bridge::pack(content& data)
{
    pack(this->m_cData, m_obj_id, data);
    return true;
}

bool obj_impl_bridge::unpack(const content& data)
{
    nb_id_t id;    
    unpack(data, id, this->m_cData);
    assert(m_obj_id == id);    
    return true;
}

bool obj_impl_bridge::pack(const bridge_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.descriptor);
    packer.pack(logic_data.interface);
    packer.pack(logic_data.subobjs);

    packer.pack(logic_data.name);
    int name_size = logic_data.sub_names.size();
    for (int i = 0; i < name_size; ++i)
        packer.pack(logic_data.sub_names[i]);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;

    return true;
}

bool obj_impl_bridge::unpack(const content& raw_data, nb_id_t& id, bridge_data_t& logic_data)
{
    id = raw_data.object_id;

    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data.descriptor = unpack.unpack_id(0);
    logic_data.interface = unpack.unpack_id(1);
    int obj_size = raw_data.id_value.ids.size() - 2;
    for (int i = 0; i < obj_size; ++i)
        logic_data.subobjs.push_back(unpack.unpack_id(i+2));

    logic_data.name = unpack.unpack_string(0);
    int value_size = raw_data.id_value.values.size() - 1;
    for (int i = 0; i < value_size; ++i)
        logic_data.sub_names.push_back(unpack.unpack_string(i+1));

    return true;
}

bool obj_impl_bridge::json_pack(const bridge_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    //stdx::json_object* pObj = new stdx::json_object();
    //assert(pObj);
    boost::shared_ptr<stdx::json_object> pObj(new (std::nothrow) stdx::json_object);
    
    //insert the member of name in the logic_data(bridge_data_t)
    stdx::json_string* pStr = NULL;    
    pStr = new stdx::json_string(logic_data.name);
    assert(pStr);
    pObj->insert("name", pStr);
    
    //insert the member of descriptor in the logic_data(bridge_data_t)
    pStr = NULL;
    pStr = new stdx::json_string(logic_data.descriptor.str());
    assert(pStr);
    pObj->insert("descriptor", pStr);
    
    //insert the member of interface in the logic_data(bridge_data_t)*
    pStr = NULL;
    pStr = new stdx::json_string(logic_data.interface.str());
    assert(pStr);
    pObj->insert("interface", pStr);
    
    //insert the member of subobjs in the logic_data(bridge_data_t)
    stdx::json_array* pArray = new stdx::json_array();
    assert(pArray);
    nb_id_vector::const_iterator it = logic_data.subobjs.begin();
    while(it!=logic_data.subobjs.end())
    {
        pStr = new stdx::json_string(it->str());
        assert(pStr);
        pArray->push_back(pStr);
        ++it;
    }
    pObj->insert("subobjs", pArray);
    
    //insert the member of sub_names in the logic_data(bridge_data_t)
    pArray = new stdx::json_array();
    assert(pArray);
    std::vector<std::string>::const_iterator itStr = logic_data.sub_names.begin();
    while(itStr!=logic_data.sub_names.end())
    {
        pStr = new stdx::json_string(*itStr);
        assert(pStr);
        pArray->push_back(pStr);
        ++itStr;
    }
    pObj->insert("sub_names", pArray);
    
    std::string strval = pObj->to_json_string();
    //delete pObj;
    //save the logic_data(bridge_data_t) to raw_data(content)
    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();

    raw_data.object_id = id;    
    raw_data.id_value.ids.push_back(logic_data.descriptor);
    raw_data.id_value.ids.push_back(logic_data.interface);
    nb_id_vector::const_iterator itSub = logic_data.subobjs.begin();
    while(itSub != logic_data.subobjs.end())
    {
        raw_data.id_value.ids.push_back(*itSub);
        ++itSub;
    }
    std::vector<char> vec(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vec);
    
    return true;
}

bool obj_impl_bridge::json_unpack(const content& raw_data, nb_id_t& id, bridge_data_t& logic_data)
{
    id = raw_data.object_id;
    std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    boost::shared_ptr<stdx::json_object> pObj(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    
    stdx::json_string* pStr = dynamic_cast<stdx::json_string*>(pObj->find("name"));
    assert(pStr);
    logic_data.name = pStr->get_string();
    
    pStr = dynamic_cast<stdx::json_string*>(pObj->find("descriptor"));
    assert(pStr);
    logic_data.descriptor.str(pStr->get_string());
    
    pStr = dynamic_cast<stdx::json_string*>(pObj->find("interface"));
    assert(pStr);
    logic_data.interface.str(pStr->get_string());
    
    stdx::json_array* pArray = dynamic_cast<stdx::json_array*>(pObj->find("subobjs"));
    assert(pArray);
    for(int i=0; i<pArray->size(); ++i)
    {
        nb_id_t idTem(pArray->at(i)->get_string());
        logic_data.subobjs.push_back(idTem);
    }
    
    stdx::json_array* pVec = dynamic_cast<stdx::json_array*>(pObj->find("sub_names"));
    assert(pVec);
    for(int i=0; i<pVec->size(); ++i)
    {
        logic_data.sub_names.push_back(pVec->at(i)->get_string());
    }
    
    //delete pObj;
    return true;
}

bool obj_impl_bridge::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_bridge::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

bool obj_impl_bridge::get_value_response(req_num_t req_num, 
        content& output)
{
    LOG_DEBUG("*** obj_impl_bridge::get_value_response");

    node_invocation_response response;

    //response.child_transaction = m_param.transaction_id;


    //host_committer_id_t hc_id;
    //m_obj_id.get_hostcommitterid(hc_id);

    //bridge_interface_data_t if_data;
    //nb_id_t id;
    //obj_impl_bridge_interface::unpack(output, id, if_data);
    //assert(id == m_cData.interface);

    //nb_id_t comp_id, dcomp_id;

    ////compose
    //decl_compound_data_t comp_data;
    //comp_data.name = "bridge_compose";

    //////in ports
    //iport_t cip_data;
    //cip_data.interface = m_cData.interface;
    //comp_data.iports.push_back(cip_data);
    //for (size_t i = 0; i < if_data.sub_interfaces.size(); ++i)
    //{
	//iport_t ip_data;
	//ip_data.interface = if_data.sub_interfaces[i];
	//comp_data.iports.push_back(ip_data);
    //}

    //////output ports
    //oport_t cop_data;
    //cop_data.interface = m_cData.interface;
    //comp_data.oports.push_back(cop_data);

    //request_nb_id_info comp_info;
    //comp_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    //comp_info.committer_id = hc_id;
    //obj_impl_decl_compound::pack(comp_data, nb_id_t(), comp_info.raw_data);
    //request_nb_id(hc_id, comp_info, comp_id);

    ////decompose
    //decl_compound_data_t dcomp_data;
    //dcomp_data.name = "bridge_decompose";

    //////in ports
    //iport_t dip_data;
    //dip_data.interface = m_cData.interface;
    //dcomp_data.iports.push_back(dip_data);

    //////output ports
    //for (size_t i = 0; i < if_data.sub_interfaces.size(); ++i)
    //{
	//oport_t op_data;
	//op_data.interface = if_data.sub_interfaces[i];
	//dcomp_data.oports.push_back(op_data);
    //}

    //request_nb_id_info dcomp_info;
    //dcomp_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    //dcomp_info.committer_id = hc_id;
    //obj_impl_decl_compound::pack(dcomp_data, nb_id_t(), dcomp_info.raw_data);
    //request_nb_id(hc_id, dcomp_info, dcomp_id);

    //// add decls: compose, decompose
    //property_info pinfo;
    //
    //pinfo.declaration = nb_id_t(NB_FUNC_INTERFACE_SET_BUILTIN_INS);
    //pinfo.objects.push_back(comp_id);
    //pinfo.objects.push_back(dcomp_id);

    //object_set_property(m_cData.interface, pinfo);

    //initialization_respond();

    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
