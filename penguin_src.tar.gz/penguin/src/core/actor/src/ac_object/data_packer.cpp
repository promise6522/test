#include "ac_object/data_packer.h"

//std::string data_packer::pack_to_stream(const db_id_value& data)
std::string data_packer::pack_to_stream(const content& data)
{
	std::string stream;
    //m_data = data;

    // 1. pack total_size and id size
    size_type id_size = data.id_value.ids.size();
    size_type value_size = data.id_value.values.size();
    stream.assign(data_packer::size_to_str(id_size + value_size));
	stream.append(data_packer::size_to_str(id_size));
    stream.resize(2*SIZE_LENGTH);

    // 2. pack ids
    size_type    i;
    //for (i = 0; i < m_data.id_value.ids.size(); ++i)
    for (i = 0; i < id_size; ++i)
        //m_stream.append(m_data.id_value.ids[i].str());
        stream.append(data.id_value.ids[i].str());

	size_type len = 0;
    // 4. pack values
    for (i = 0; i < value_size; ++i)
    {
        len = stream.length();
        uint size = data.id_value.values[i].size();
        stream.append(data_packer::size_to_str(size));
        stream.resize(len + SIZE_LENGTH);

        std::string strval(data.id_value.values[i].begin(), data.id_value.values[i].end());
        stream.append(strval);
    }

	stream.append(data.object_id.str());
    //m_stream = stream;
    return stream;
}

std::string data_packer::packer_to_stream()
{
	
	return data_packer::pack_to_stream(this->get_pack_data());
}

void data_packer::pack(const std::vector<nb_id_t>& ids,
                  const std::vector< std::vector<char> >& values)
{
    pack(ids);
    pack(values);
}

void data_packer::pack(const std::vector<nb_id_t>& ids)
{
    m_pData->id_value.ids.insert(m_pData->id_value.ids.end(), ids.begin(), ids.end());
}

void data_packer::pack(const nb_id_t& id)
{
    m_pData->id_value.ids.push_back(id);
}

void data_packer::pack(const std::vector< std::vector<char> >& values)
{
    m_pData->id_value.values.insert(m_pData->id_value.values.end(), values.begin(), values.end());
}

void data_packer::pack(const std::vector<char>& value)
{
    m_pData->id_value.values.push_back(value);
}

void data_packer::pack(const std::string& value)
{
    m_pData->id_value.values.push_back(std::vector<char>(value.begin(), value.end()));
}

void data_packer::pack( const std::vector<std::string>& value)
{
	int value_size = value.size();
	for( int i=0; i<value_size; ++i)
	{
		this->pack( value[i] );
	}	
}

void data_packer::pack(int value)
{
    //memset(m_buf, 0, sizeof(m_buf));
    sprintf(m_buf, "%d", value);

    std::string strs(m_buf);
    m_pData->id_value.values.push_back(std::vector<char>(strs.begin(), strs.end()));
}

void data_packer::pack(bool value)
{
    std::string strs((value ? "true": "false"));

    m_pData->id_value.values.push_back(std::vector<char>(strs.begin(), strs.end()));
}

std::string data_packer::size_to_str(size_type sz)
{
    //std::ostringstream oss;
    //oss << std::setw(SIZE_LENGTH) << std::setfill('0') << std::hex << value;
    //return oss.str();
    return std::string(reinterpret_cast<char*>(&sz), SIZE_LENGTH);
}
