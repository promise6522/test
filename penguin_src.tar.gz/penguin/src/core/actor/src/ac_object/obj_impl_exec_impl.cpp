/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_object/obj_impl_exec_impl.h"

// stdx header files
#include "stdx_json.h"

#include "ac_message_type.h"

obj_impl_exec_impl::obj_impl_exec_impl(const nb_id_t& obj_id, 
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_exec_implementation());
    unpack(raw_data);
} 

obj_impl_exec_impl::~obj_impl_exec_impl()
{
} 

bool obj_impl_exec_impl::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_exec_impl::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_exec_impl::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_exec_impl::pack(const exec_impl_graph_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer(raw_data);

    //##################pack nb_id_t#############################//
    packer.pack(logic_data.visualInformation);
    packer.pack(logic_data.master);
    packer.pack(logic_data.external_decl);

    nb_id_t nb_constant(NBID_TYPE_OBJECT_INT);
    int con_size = logic_data.constants.size();
    nb_constant.set_value(con_size);
    packer.pack(nb_constant);
    packer.pack(logic_data.constants);

    nb_id_t nb_node(NBID_TYPE_OBJECT_INT);
    int node_size = logic_data.nodes.size();
    nb_node.set_value(node_size);
    packer.pack(nb_node);
    packer.pack(logic_data.nodes);

    nb_id_t nb_cut(NBID_TYPE_OBJECT_INT);
    int cut_size = logic_data.cut_info.size();
    nb_cut.set_value(cut_size);
    packer.pack(nb_cut);
    std::map<int, nb_id_t>::const_iterator it = logic_data.cut_info.begin();
    while (it != logic_data.cut_info.end())
    {
        // index
        nb_id_t nb_index(NBID_TYPE_OBJECT_INT);
        nb_index.set_value(it->first);
        packer.pack(nb_index);
        packer.pack(it->second);
        ++it;
    }

    //##################pack string#############################//
    packer.pack(logic_data.name);
    packer.pack(logic_data.out_port_size);
    packer.pack(logic_data.handlesException);

    int port_size = logic_data.inNodeTimeNum.size();
    packer.pack(port_size);
    for (int i=0; i< port_size; ++i)
        packer.pack(logic_data.inNodeTimeNum[i]);

    int path_size = logic_data.paths.size();
    packer.pack(path_size);
    for (int i = 0; i < path_size; ++i)
    {
        packer.pack(logic_data.paths[i].in_node);
        packer.pack(logic_data.paths[i].in_port);
        packer.pack(logic_data.paths[i].out_node);
        packer.pack(logic_data.paths[i].out_port);
    }

    int out_size = logic_data.out_paths.size();
    packer.pack(out_size);
    for (int i = 0; i < out_size; ++i)
    {
        int idx_size = logic_data.out_paths[i].path_idxs.size();
        packer.pack(idx_size);
        for (int j = 0; j < idx_size; ++j)
            packer.pack(logic_data.out_paths[i].path_idxs[j]);
    }

    // pack parsing result
    packer.pack(logic_data.m_ss_length);
    for (int i = 0; i < logic_data.m_ss_length; ++i)
    {
        packer.pack(logic_data.mp_start_size[i].m_start_position);
        packer.pack(logic_data.mp_start_size[i].m_size);
        packer.pack(logic_data.mp_start_size[i].m_confirm_size);
    }
    packer.pack(logic_data.m_total_size);
    packer.pack(logic_data.m_io_obj_lenth);

    //raw_data.id_value = packer.get_pack_data();
    //raw_data= packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_exec_impl::unpack(const content& raw_data, nb_id_t& id, exec_impl_graph_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int str_index = -1;
    int nb_index = -1;

    //################# unpack nb_id_t #####################################//
    logic_data.visualInformation = unpack.unpack_id(++nb_index);
    logic_data.master = unpack.unpack_id(++nb_index);
    logic_data.external_decl = unpack.unpack_id(++nb_index);

    int constant_size = 0;
    unpack.unpack_id(++nb_index).get_value(constant_size);
    for (int i = 0; i < constant_size; ++i)
        logic_data.constants.push_back(unpack.unpack_id(++nb_index));

    int node_size = 0;
    unpack.unpack_id(++nb_index).get_value(node_size);
    for (int i = 0; i < node_size; ++i)
        logic_data.nodes.push_back(unpack.unpack_id(++nb_index));

    int cut_size = 0;
    unpack.unpack_id(++nb_index).get_value(cut_size);
    for (int i = 0; i < cut_size; ++i)
    {
        // index
        int index = 0;
        unpack.unpack_id(++nb_index).get_value(index);
        nb_id_t cut = unpack.unpack_id(++nb_index);
        // make cut info
        logic_data.cut_info.insert(std::make_pair(index, cut));
    }

    //################# unpack other type #####################################//
    logic_data.name = unpack.unpack_string(++str_index);
    logic_data.out_port_size = unpack.unpack_int(++str_index);
    logic_data.handlesException = static_cast<nb_exception_type_t>(unpack.unpack_int(++str_index));    

    int port_size = unpack.unpack_int(++str_index);
    for(int i=0; i < port_size; ++i)
    {
        logic_data.inNodeTimeNum.push_back(unpack.unpack_int(++str_index));
    }

    int path_size = unpack.unpack_int(++str_index);
    for(int i = 0; i < path_size; ++i)
    {
        node_path_t node_data;
        node_data.in_node = unpack.unpack_int(++str_index);
        node_data.in_port = unpack.unpack_int(++str_index);
        node_data.out_node = unpack.unpack_int(++str_index);
        node_data.out_port = unpack.unpack_int(++str_index);
        logic_data.paths.push_back(node_data);
    }

    int out_size = unpack.unpack_int(++str_index);
    for (int i = 0; i < out_size; ++i)
    {
        out_port_path_idx_t out_data;
        int idx_size = unpack.unpack_int(++str_index);
        for (int j=0; j < idx_size; ++j)
            out_data.path_idxs.push_back(unpack.unpack_int(++str_index));
        logic_data.out_paths.push_back(out_data);
    }

    // unpack parsing result
    logic_data.m_ss_length = unpack.unpack_int(++str_index);
    logic_data.mp_start_size = new exe_impl_node_t[logic_data.m_ss_length];
    for (int i = 0; i < logic_data.m_ss_length; ++i)
    {
        logic_data.mp_start_size[i].m_start_position = unpack.unpack_int(++str_index);
        logic_data.mp_start_size[i].m_size = unpack.unpack_int(++str_index);
        logic_data.mp_start_size[i].m_confirm_size = unpack.unpack_int(++str_index);
    }
    logic_data.m_total_size = unpack.unpack_int(++str_index);
    logic_data.m_io_obj_lenth = unpack.unpack_int(++str_index);

    return true;
}

bool obj_impl_exec_impl::json_pack(const exec_impl_graph_t& logic_data, 
    const nb_id_t& id,
    content& raw_data)
{ 
    /*struct exec_impl_graph_t
    {
        std::string name;
        int out_port_size;
        nb_id_t master;
        nb_id_t external_decl;
        nb_exception_type_t handlesException;
        nb_id_vector constants;
        nb_id_vector nodes;
        std::vector<node_path_t> paths; { int in_node; int in_port; int out_node; int out_port }
        std::vector<out_port_path_idx_t> out_paths; { int out_port; std::vector<int> path_idx }
    };*/

    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    pObj->insert("out_port_size", new stdx::json_int(logic_data.out_port_size));
    pObj->insert("master", new stdx::json_string(logic_data.master.str()));
    pObj->insert("external_decl", new stdx::json_string(logic_data.external_decl.str()));
    pObj->insert("handlesException", new stdx::json_int(logic_data.handlesException));

    // pack vector<nb_id_t> constants
    stdx::json_array* jarr = new stdx::json_array();
    for(nb_id_vector_const_it it = logic_data.constants.begin(); it != logic_data.constants.end(); ++it )
        jarr->push_back(new stdx::json_string(it->str()));
    pObj->insert("constants", jarr);
    // end constants

    // pack vector<nb_id_t> nodes
    jarr = new stdx::json_array();
    for(nb_id_vector_const_it it = logic_data.nodes.begin(); it != logic_data.nodes.end(); ++it )
        jarr->push_back(new stdx::json_string(it->str()));
    pObj->insert("nodes", jarr);
    // end nodes

    // pack vector<node_path_t> paths
    jarr = new stdx::json_array();
    for(std::vector<node_path_t>::const_iterator it = logic_data.paths.begin(); it != logic_data.paths.end(); ++it )
    {
        stdx::json_object* subobj = new stdx::json_object();
        subobj->insert("in_node", new stdx::json_int(it->in_node));
        subobj->insert("in_port", new stdx::json_int(it->in_port));
        subobj->insert("out_node", new stdx::json_int(it->out_node));
        subobj->insert("out_port", new stdx::json_int(it->out_port));
        jarr->push_back(subobj);
    }
    pObj->insert("paths", jarr);
    // end paths

    // pack  vector<out_port_path_idx_t> out_paths
    jarr = new stdx::json_array();
    for(std::vector<out_port_path_idx_t>::const_iterator it = logic_data.out_paths.begin(); it != logic_data.out_paths.end(); ++it )
    {
        stdx::json_object* subobj = new stdx::json_object();

        // pack vector<int> path_idxs
        stdx::json_array* jarr2 = new stdx::json_array();
        for(std::vector<int>::const_iterator itx = it->path_idxs.begin(); itx != it->path_idxs.end(); ++itx )
            jarr2->push_back(new stdx::json_int(*itx));
        subobj->insert("path_idxs", jarr2);
        // end idx
        
        jarr->push_back(subobj);
    }
    pObj->insert("out_paths", jarr);
    // end out_paths

    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
    // save all internal ids
    raw_data.id_value.ids.clear();
    raw_data.id_value.ids.push_back(logic_data.master);
    raw_data.id_value.ids.push_back(logic_data.external_decl);
    raw_data.id_value.ids.insert(raw_data.id_value.ids.end(),
            logic_data.constants.begin(), logic_data.constants.end());
    raw_data.id_value.ids.insert(raw_data.id_value.ids.end(),
            logic_data.nodes.begin(), logic_data.nodes.end());
    // save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);

    return true;
}

bool obj_impl_exec_impl::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);
    return true;
}

bool obj_impl_exec_impl::json_unpack(const content& raw_data, 
    nb_id_t& id,
    exec_impl_graph_t& logic_data)
{
    id = raw_data.object_id;

    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    logic_data.name = pObj->find("name")->get_string();
    logic_data.out_port_size = pObj->find("out_port_size")->get_int();
    logic_data.master.str(pObj->find("master")->get_string());
    logic_data.external_decl.str(pObj->find("external_decl")->get_string());
    logic_data.handlesException = static_cast<nb_exception_type_t>(pObj->find("handlesException")->get_int());
    // unpack nb_id_vector constants
    logic_data.constants.clear();
    stdx::json_array* jarr = dynamic_cast<stdx::json_array*>(pObj->find("constants"));
    assert(jarr);
    for(int i = 0; i < jarr->size(); ++i )
    {
        nb_id_t nb_id;
        nb_id.str(jarr->at(i)->get_string());
        logic_data.constants.push_back(nb_id);
    }
    // end constants
    
    // unpack nb_id_vector nodes
    logic_data.nodes.clear();
    jarr = dynamic_cast<stdx::json_array*>(pObj->find("nodes"));
    assert(jarr);
    for(int i = 0; i < jarr->size(); ++i )
    {
        nb_id_t nb_id;
        nb_id.str(jarr->at(i)->get_string());
        logic_data.nodes.push_back(nb_id);
    }
    // end nodes

    // unpack vector<node_path_t> paths
    logic_data.paths.clear();
    jarr = dynamic_cast<stdx::json_array*>(pObj->find("paths"));
    assert(jarr);
    for(int i = 0; i < jarr->size(); ++i )
    {
        stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
        node_path_t node_path;
        node_path.in_node = subobj->find("in_node")->get_int();
        node_path.in_port = subobj->find("in_port")->get_int();
        node_path.out_node = subobj->find("out_node")->get_int();
        node_path.out_port = subobj->find("out_port")->get_int();
        logic_data.paths.push_back(node_path);
    }
    // end paths
    
    // unpack vector<out_port_path_idx_t> out_paths
    logic_data.out_paths.clear();
    jarr = dynamic_cast<stdx::json_array*>(pObj->find("out_paths"));
    assert(jarr);
    for(int i = 0; i < jarr->size(); ++i )
    {
        stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
        out_port_path_idx_t out_port_path_idx;
        // unpack vector<int> path_idxs
        out_port_path_idx.path_idxs.clear();
        stdx::json_array* jarr2 = dynamic_cast<stdx::json_array*>(subobj->find("path_idxs"));
        for(int j = 0; j < jarr2->size(); ++j )
            out_port_path_idx.path_idxs.push_back(jarr2->at(j)->get_int());
        // end path_idxs
        logic_data.out_paths.push_back(out_port_path_idx);
    }
    // end out_paths

    return true;
}

bool obj_impl_exec_impl::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_exec_impl::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
