/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_base.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object_helper.h"

object_implementation_base::object_implementation_base()
{
    m_pHelper = NULL;

    time_t tm;    
    time(&tm);
    m_top_req_num = tm;
} 

object_implementation_base::object_implementation_base(const nb_id_t& obj_id,
        ac_object_helper * pHelper)
    : m_obj_id(obj_id) 
{
    m_pHelper = pHelper;

    time_t tm;    
    time(&tm);
    m_top_req_num = tm;
} 

object_implementation_base::~object_implementation_base()
{
} 

//bool object_implementation_base::request_string_object(const std::string& name, nb_id_t& out)
//{
//    request_nb_id_info str_info;
//    str_info.committer_id = m_param.host_committer_id;
//    str_info.type = NBID_TYPE_OBJECT_STRING;
//    obj_impl_string::pack(name, nb_id_t(), str_info.raw_data);
//
//    return m_pHelper->ac_host_committer_request_nb_id(m_param.host_committer_id, 
//                str_info,
//                out);
//}

bool object_implementation_base::run_prepare(node_invocation_request& req)            
{
    // save params to internal states
    trans_comm_pair_t tc_pair;
    tc_pair.m_host_committer_id = req.host_committer_id;
    tc_pair.m_transaction_id = req.transaction_id;

    bool is_local = true;
    if (!machine_is_local(tc_pair, is_local))
        return false;

    //request host committer actor
    transaction_id_t transaction_id;
    host_committer_id_t host_committer_id;

    if (is_local)
        host_committer_id = req.host_committer_id;
    else if (!request_host_committer_id(host_committer_id))
        return false;

    if (!request_transaction_id(host_committer_id, transaction_id))
        return false;

    //set parent transaction 
    if (!transaction_begin(transaction_id, tc_pair))
        return false;

    //set execution parameter 
    req.transaction_id = transaction_id;
    req.host_committer_id = host_committer_id;

    return true;
}

req_num_t object_implementation_base::generate_req_num()
{
    return m_top_req_num++;
}

void object_implementation_base::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void object_implementation_base::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool object_implementation_base::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    req_info_t req_info;
    bool ret = m_msg.get_req_info(req_num, req_info);
    call_id = req_info.call_id;
    return ret;

#if 0
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if (it == m_req_info_map.end())
        return false;

    call_id = it->second;
    return true;
#endif
}

// These funcs are for concrete impls of ac_object
// simply delegate to ac_object_helper: m_pHelper
bool object_implementation_base::initialization_respond()
{
    return m_pHelper->initialization_respond();
}

bool object_implementation_base::exception_respond(call_id_t call_id, std::string& output)
{
    return m_pHelper->exception_respond(call_id, output);
}

bool object_implementation_base::run_respond(call_id_t call_id, node_invocation_response& output)
{
    return m_pHelper->ac_object_run_respond(call_id, output);
}

bool object_implementation_base::run_exception_respond(call_id_t call_id, const transaction_id_t& tr_id)
{
    LOG_DEBUG("ac_object::run_exception_respond()");

    node_invocation_response response; 

    response.child_transaction = tr_id; 
    response.success = false; 
    return run_respond(call_id, response);
}

bool object_implementation_base::machine_is_local(const trans_comm_pair_t& input, bool& output)
{
    return m_pHelper->ac_machine_is_local(input, output);
}

bool object_implementation_base::request_nb_id(host_committer_id_t id, 
    const request_nb_id_info& input,
    nb_id_t& output)
{
    assert(!id.is_value_null());

    return m_pHelper->ac_host_committer_request_nb_id(id, input, output);
}

bool object_implementation_base::request_execution_id(const request_execution_id_info exec_info, 
    execution_id_t& output)
{
    return m_pHelper->ac_id_dispenser_request_execution_id(exec_info, output);
}

bool object_implementation_base::request_host_committer_id(host_committer_id_t& output)
{
    return m_pHelper->ac_id_dispenser_request_host_committer_id(output);
}

bool object_implementation_base::request_transaction_id(const host_committer_id_t& input, 
    transaction_id_t& output)
{
    return m_pHelper->ac_id_dispenser_request_transaction_id(input, output);
}

bool object_implementation_base::execution_start(call_id_t call_id, const request_execution_id_info& exec_info, 
        const node_invocation_request& req)
{

    execution_id_t id;
    if (!request_execution_id(exec_info, id))
        return run_exception_respond(call_id, req.transaction_id);

    //set parent for implementation for execution 
    execution_set_parent(id, req.execution_id);

    node_invocation_request new_req = req;
    new_req.execution_id = id;

    req_num_t req_num = generate_req_num();    
    begin_incoming_call_info(req_num, call_id, new_req);

    if (!m_pHelper->ac_execution_start(id, req_num, new_req))
        return throw_exeception(req_num, "Asyn call failed : execution_start().");

    return true;
}

bool object_implementation_base::execution_set_parent(execution_id_t id, 
    const execution_id_t& input)
{
    return m_pHelper->ac_execution_set_parent(id, input);
}

bool object_implementation_base::db_read(req_num_t req_num, const object_ids& input)
{
    if (!m_pHelper->ac_object_db_read(req_num, input))
        return throw_exeception(req_num, "Asyn call failed : ac_object_db_read().");

    return true;
}

bool object_implementation_base::transaction_begin(transaction_id_t id, const trans_comm_pair_t& input)
{
    return m_pHelper->ac_transaction_begin(id, 0, input);
}

bool object_implementation_base::transaction_get_host_committer(transaction_id_t id)
{
    return m_pHelper->ac_transaction_get_host_committer(id, 0);
}

bool object_implementation_base::throw_exeception(req_num_t req_num, std::string exception_string)
{
    call_id_t call_id;

    if(!get_call_id(req_num, call_id))
    {
        LOG_ERROR("Logic failed : could not get call_id.");
        return false;        
    }    

    end_incoming_call(req_num); 

    //just return exception string if there is exeception;
    return m_pHelper->exception_respond(call_id, exception_string);
}

bool object_implementation_base::object_set_value(nb_id_t id, content& output)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_set_value(id, output);
}

bool object_implementation_base::object_get_value(nb_id_t id, content& output)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_get_value_sync(id, output);
}

bool object_implementation_base::object_get_value_async(nb_id_t id, req_num_t req_num)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_get_value_async(id, req_num);
}

bool object_implementation_base::object_set_property(nb_id_t id, const property_info& input)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_set_property(id, input);
}

bool object_implementation_base::object_get_property(nb_id_t id, const nb_id_t& input, object_ids& output)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_get_property(id, input, output);
}

void object_implementation_base::begin_incoming_call_info(req_num_t req_num,
        call_id_t call_id,
        const node_invocation_request& input)
{
    req_info_t req_info;
    req_info.call_id = call_id;
    req_info.input = input;
    m_msg.begin_incoming_req_info(req_num, req_info);
}

bool object_implementation_base::get_call_info(req_num_t req_num,
        req_info_t& req_info)
{
    return m_msg.get_req_info(req_num, req_info);
}

bool object_implementation_base::pop_call_info(req_num_t req_num,
        req_info_t& req_info)
{
    // do get & remove
    if(get_call_info(req_num, req_info))
    {
        end_incoming_call_info(req_num);
        return true;
    }
    return false;
}

void object_implementation_base::end_incoming_call_info(req_num_t req_num)
{
    m_msg.end_incoming_req_info(req_num);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
