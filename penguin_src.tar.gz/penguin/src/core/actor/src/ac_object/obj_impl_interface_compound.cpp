/**************************************************************************
 **
 ** 	Copyright 2010 Duke Inc.
 **
 **************************************************************************/
#include "ac_object/obj_impl_interface_compound.h"

// stdx header files
#include "stdx_json.h"

#include "ac_message_type.h"
#include "ac_object/obj_impl_decl_compound.h"

obj_impl_interface_compound::obj_impl_interface_compound() 
{
} 

obj_impl_interface_compound::obj_impl_interface_compound(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_interface_compound());
    set_value(raw_data);
/*
    switch (m_cData.type.get_compound_interface_type())
    {
	case NB_INTERFACE_ARRAY_TYPE:
	    set_array_type();
	    break;
	case NB_INTERFACE_MAP_TYPE:
	    set_map_type();
	    break;
	default:
	    break;
    }
*/
    nb_id_vector vins;
    set_builtin_instructions(vins);
} 

obj_impl_interface_compound::~obj_impl_interface_compound()
{
} 

bool obj_impl_interface_compound::set_builtin_instructions(const nb_id_vector& vins)
{
    m_builtin_ins = vins;

/*    
    switch (m_cData.type.get_compound_interface_type())
    {
	case NB_INTERFACE_ARRAY_TYPE:
	case NB_INTERFACE_MAP_TYPE:
        m_builtin_ins = m_cData.decls;
	    break;
	default:
	    break;
    }
*/
    return true;
}

bool obj_impl_interface_compound::set_array_type()
{
    host_committer_id_t hc_id;
    decl_compound_data_t decl_data;
    request_nb_id_info decl_info;

    nb_id_t g_id, gh_id, gt_id, ah_id, at_id, is_id, jn_id, un_id, inters_id, comp_id, sp_id, spt_id, rg_id, inc_id, sz_id, rv_id;

    iport_t ip0, ip1, ip2;
    oport_t op0, op1;

    m_obj_id.get_hostcommitterid(hc_id);

    nb_id_t type = m_cData.groups[0].min_if;

    assert(1 == m_cData.groups.size());

    // get 
    ip0.interface = m_obj_id;
    ip1.interface = nb_id_t(NB_INTERFACE_INT);
    op0.interface = type;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "get";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, g_id);

    // get head 
    ip0.interface = m_obj_id;
    op0.interface = type;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "get head";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, gh_id);

    // get tail 
    ip0.interface = m_obj_id;
    op0.interface = type;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "get tail";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, gt_id);

    //add head
    ip0.interface = m_obj_id;
    ip1.interface = type;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "add head";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, ah_id);

    //add tail
    ip0.interface = m_obj_id;
    ip1.interface = type;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "add tail";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, at_id);

    //reverse
    ip0.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "reverse";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, rv_id);

    // size
    ip0.interface = m_obj_id;
    op0.interface = nb_id_t(NB_INTERFACE_INT);
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "size";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, sz_id);

    // insert
    ip0.interface = m_obj_id;
    ip1.interface = nb_id_t(NB_INTERFACE_INT);
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "insert";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, is_id);

    // join 
    ip0.interface = m_obj_id;
    ip1.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "join";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, jn_id);

    // union 
    ip0.interface = m_obj_id;
    ip1.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "union";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, un_id);

    // intersection 
    ip0.interface = m_obj_id;
    ip1.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "intersection";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, inters_id);

    // complementary 
    ip0.interface = m_obj_id;
    ip1.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "complementary";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, comp_id);

    // inclusion 
    ip0.interface = m_obj_id;
    ip1.interface = m_obj_id;
    op0.interface = nb_id_t(NB_INTERFACE_BOOL);
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "inclusion";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, inc_id);

    // split 
    ip0.interface = m_obj_id;
    op0.interface = m_obj_id;
    op1.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.push_back(op0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op1);

    decl_data.name = "split";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, sp_id);

    // split at 
    ip0.interface = m_obj_id;
    ip1.interface = nb_id_t(NB_INTERFACE_INT);
    ip2.interface = nb_id_t(NB_INTERFACE_INT);
    op0.interface = m_obj_id;
    op1.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.iports.push_back(ip2);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);
    decl_data.oports.push_back(op1);

    decl_data.name = "split at";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, spt_id);

    // range 
    ip0.interface = m_obj_id;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "range";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, rg_id);

    // set declaration ids
    m_cData.decls.push_back(g_id); // GET
    m_cData.decls.push_back(gh_id); // GETHEAD
    m_cData.decls.push_back(gt_id); // GETTAIL
    m_cData.decls.push_back(ah_id); // ADDHEAD
    m_cData.decls.push_back(at_id); // ADDTAIL
    m_cData.decls.push_back(rv_id); // REVERSE
    m_cData.decls.push_back(is_id); // INSERT
    m_cData.decls.push_back(jn_id); // JOIN
    m_cData.decls.push_back(rg_id); // RANGE
    m_cData.decls.push_back(sz_id); // SIZE
    m_cData.decls.push_back(sp_id); // SPLIT
    m_cData.decls.push_back(spt_id); // SPLITAT
    m_cData.decls.push_back(un_id); // UNIONSET
    m_cData.decls.push_back(inters_id); // INTERSECTIONSET
    m_cData.decls.push_back(comp_id); // COMPLEMENTARYSET
    m_cData.decls.push_back(inc_id); // INCLUSION

    return true;

}

bool obj_impl_interface_compound::set_map_type()
{
    host_committer_id_t hc_id;
    decl_compound_data_t decl_data;
    request_nb_id_info decl_info;

    nb_id_t g_id, is_id, sz_id, ga_id;

    iport_t ip0, ip1, ip2;
    oport_t op0, op1;

    m_obj_id.get_hostcommitterid(hc_id);

    // get 
    ip0.interface = m_obj_id;
    ip1.interface = m_cData.groups[0].min_if;
    op0.interface = m_cData.groups[1].min_if;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "get";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, g_id);

    // insert
    ip0.interface = m_obj_id;
    ip1.interface = m_cData.groups[0].min_if;
    ip2.interface = m_cData.groups[1].min_if;
    op0.interface = m_obj_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.iports.push_back(ip1);
    decl_data.iports.push_back(ip2);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "insert";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, is_id);

    // size
    ip0.interface = m_obj_id;
    op0.interface = nb_id_t(NB_INTERFACE_INT);
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "size";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, sz_id);

    // get all keys 
    ip0.interface = m_obj_id;

    nb_id_t op_id;
    request_nb_id_info if_info;
    if_compound_data_t if_data;
    if_exp_group group;

    if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    if_info.committer_id = hc_id;

    group.min_if = m_cData.groups[0].min_if;
    if_data.groups.push_back(group);

    obj_impl_interface_compound::pack(if_data, nb_id_t(), if_info.raw_data);
    request_nb_id(hc_id, if_info, op_id);

    op0.interface = op_id;
    decl_data.iports.clear();
    decl_data.iports.push_back(ip0);
    decl_data.oports.clear();
    decl_data.oports.push_back(op0);

    decl_data.name = "get all keys";

    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
    request_nb_id(hc_id, decl_info, ga_id);

    // set declaration ids
    m_cData.decls.push_back(g_id); // GET
    m_cData.decls.push_back(is_id); // INSERT
    m_cData.decls.push_back(sz_id); // SIZE 
    m_cData.decls.push_back(ga_id); // GET_ALL_KEYS 

    return true;

}

bool obj_impl_interface_compound::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_interface_compound::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_interface_compound::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_interface_compound::pack(const if_compound_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.visualInformation);
    packer.pack(logic_data.is_singleton);

    nb_id_t nb_decls(NBID_TYPE_OBJECT_INT);
    int del_size = logic_data.decls.size();
    nb_decls.set_value(del_size);
    packer.pack(nb_decls);
    packer.pack(logic_data.decls);

    int group_size = logic_data.groups.size();
    packer.pack(group_size);
    for (int i=0; i < group_size; ++i)
    {
        packer.pack(logic_data.groups[i].name);
        packer.pack(logic_data.groups[i].min_if);

        int member_size = logic_data.groups[i].members.size();
        packer.pack(member_size);
        for(int j=0; j < member_size; ++j)
        {
            packer.pack(logic_data.groups[i].members[j].decl_idx);      
            packer.pack(logic_data.groups[i].members[j].group_idx);      
        }
        packer.pack(logic_data.groups[i].expanded);
    }

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_interface_compound::unpack(const content& raw_data, nb_id_t& id, if_compound_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int nb_index = -1;
    int str_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);
    logic_data.is_singleton = unpack.unpack_bool(++str_index);
    logic_data.visualInformation = unpack.unpack_id(++nb_index);

    int decls_size =  0;
    unpack.unpack_id(++nb_index).get_value(decls_size);
    for(int i=0; i < decls_size; ++i)
    {
        logic_data.decls.push_back(unpack.unpack_id(++nb_index));
    }

    int group_size = unpack.unpack_int(++str_index);
    for(int i=0; i < group_size; ++i)
    {
        if_exp_group if_data;

        if_data.name = unpack.unpack_string(++str_index);
        if_data.min_if = unpack.unpack_id(++nb_index);

        int member_size = unpack.unpack_int(++str_index);
        for(int j=0; j < member_size; ++j)
        {
            if_exp_idx exp_data;
            exp_data.decl_idx = unpack.unpack_int(++str_index);
            exp_data.group_idx = unpack.unpack_int(++str_index);
            if_data.members.push_back(exp_data);
        }
        if_data.expanded = unpack.unpack_bool(++str_index);
        logic_data.groups.push_back(if_data);
    }
    return true;
}

bool obj_impl_interface_compound::json_pack(const if_compound_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    pObj->insert("is_singleton", new stdx::json_boolean(logic_data.is_singleton));

    // pack nb_id_vector decls
    stdx::json_array* pArr = new(std::nothrow) stdx::json_array();
    assert(pArr);
    std::vector<nb_id_t>::const_iterator nb_it = logic_data.decls.begin();
    while(nb_it != logic_data.decls.end())
    {
	pArr->push_back(new stdx::json_string(nb_it->str()));
	++nb_it;
    }
    pObj->insert("decls", pArr);
    // end decls

    // pack vector<if_exp_group> groups
    pArr = new(std::nothrow) stdx::json_array();
    assert(pArr);
    std::vector<if_exp_group>::const_iterator it = logic_data.groups.begin();
    while(it != logic_data.groups.end())
    {
    	stdx::json_object* pSubObj = new(std::nothrow) stdx::json_object();
    	assert(pSubObj);
    	pSubObj->insert("name", new stdx::json_string(it->name));
    	pSubObj->insert("min_if", new stdx::json_string(it->min_if.str()));
    	pSubObj->insert("expanded", new stdx::json_boolean(it->expanded));
    	// pack vector<if_exp_idx> members
    	stdx::json_array* pSubArr = new(std::nothrow) stdx::json_array();
    	assert(pSubArr);
    	std::vector<if_exp_idx>::const_iterator itx = it->members.begin();
    	while(itx != it->members.end())
    	{
    	    stdx::json_object* pSubObjx = new(std::nothrow) stdx::json_object();
    	    assert(pSubObjx);
    	    pSubObjx->insert("decl_idx", new stdx::json_int(itx->decl_idx));
    	    pSubObjx->insert("group_idx", new stdx::json_int(itx->group_idx));
    	    pSubArr->push_back(pSubObjx);
    	    ++itx;
    	}
    	pSubObj->insert("members", pSubArr);
    	// end members
    
    	pArr->push_back(pSubObj);
    	++it;
    }
    pObj->insert("groups", pArr);
    // end groups

    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
	// save all internal ids
    raw_data.id_value.ids.clear();
	raw_data.id_value.ids.assign(logic_data.decls.begin(), logic_data.decls.end());
	std::vector<if_exp_group>::const_iterator itExpGroups = logic_data.groups.begin();
	while( itExpGroups != logic_data.groups.end())
	{
		raw_data.id_value.ids.push_back(itExpGroups->min_if);
		++itExpGroups;
	}
	// save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);

    return true;
}

bool obj_impl_interface_compound::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, m_cData);
    assert(id == m_obj_id);

    return true;
}

bool obj_impl_interface_compound::json_unpack(const content& raw_data, 
	nb_id_t& id,
	if_compound_data_t& logic_data)
{
    id = raw_data.object_id;

    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    logic_data.name = pObj->find("name")->get_string();
    logic_data.is_singleton = pObj->find("is_singleton")->get_boolean();

    // unpack nb_id_vector decls
    logic_data.decls.clear();
    stdx::json_array* pArr = dynamic_cast<stdx::json_array*>(pObj->find("decls"));
    assert(pArr);
    for(int i=0; i < pArr->size(); ++i)
    {
	stdx::json_node* pNode = pArr->at(i);
	logic_data.decls.push_back(nb_id_t(pNode->get_string()));
    }
    // end decls

    // unpack vector<if_exp_group> groups
    logic_data.groups.clear();
    pArr = dynamic_cast<stdx::json_array*>(pObj->find("groups"));
    assert(pArr);
    for(int i=0; i < pArr->size(); ++i)
    {
	stdx::json_object* pSubObj = dynamic_cast<stdx::json_object*>(pArr->at(i));
	assert(pSubObj);
	if_exp_group exp_group;
	exp_group.name = pSubObj->find("name")->get_string();
	exp_group.min_if.str(pSubObj->find("min_if")->get_string());
	exp_group.expanded = pSubObj->find("expanded")->get_boolean();
	// unpack vector<if_exp_idx> members
	exp_group.members.clear();
	stdx::json_array* pSubArr = dynamic_cast<stdx::json_array*>(pSubObj->find("members"));
	assert(pSubArr);
	for(int j=0; j < pSubArr->size(); ++j)
	{
	    stdx::json_object* pSubObjx = dynamic_cast<stdx::json_object*>(pSubArr->at(j));
	    assert(pSubObjx);
	    if_exp_idx exp_idx;
	    exp_idx.decl_idx = pSubObjx->find("decl_idx")->get_int();
	    exp_idx.group_idx = pSubObjx->find("group_idx")->get_int();
	    exp_group.members.push_back(exp_idx);
	}
	// end members
	logic_data.groups.push_back(exp_group);
    }
    // end groups

    return true;
}

bool obj_impl_interface_compound::set_property(const property_info& input)
{
    LOG_DEBUG("*** obj_impl_interface_compound::set_property()");

    switch(input.declaration.get_func_type())
    {
	case NB_FUNC_INTERFACE_SET_BUILTIN_INS:
	set_builtin_instructions(input.objects);
	    break;
	default:
	    break;
    }

    return true;

}

bool obj_impl_interface_compound::get_property(const nb_id_t& declaration, object_ids& objects)
{
    LOG_DEBUG("*** obj_impl_interface_compound::get_property()");

    switch(declaration.get_func_type())
    {
	case NB_FUNC_INTERFACE_GET_BUILTIN_INS:
	    objects.ids = m_builtin_ins;
	    break;
	default:
	    break;
    }

    return true;

}

bool obj_impl_interface_compound::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_interface_compound::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
