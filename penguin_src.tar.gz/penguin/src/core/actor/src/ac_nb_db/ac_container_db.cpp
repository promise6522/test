/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_container_db.h"

bool ac_container_db::initialization()
{
    return true;
}

bool ac_container_db::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_container_db::read(call_id_t call_id, const container_ids& input)
{
    std::vector<container_id_t>::const_iterator const_it;
    con_content con;
    con_value value;
    for (const_it = input.ids.begin(); const_it != input.ids.end(); ++const_it)
    {
        std::string strval;
        NbDbResult ret = ac_container_db_impl::instance().read(const_it->str(), strval);
        if (ret == NB_DB_RESULT_SUCCESS)
            unpack_container(strval, con);
        else
            LOG_ERROR(const_it->str() + " : DON'T TO READ FROM CONTAINER DB");
        value.all_containers.push_back(con);
    }
    return m_ptrHelper->ac_container_db_read_respond(call_id, value);
}

bool ac_container_db::write(call_id_t call_id, const con_value& input)
{
    bool result = false;

    DbTxn* txn = NULL;
    bool bret = ac_container_db_impl::instance().begin_txn(txn);
    assert(bret);
    for (unsigned int i = 0; i < input.all_containers.size(); ++i)
    { 
        NbDbResult ret = ac_container_db_impl::instance().write(input.all_containers[i].container_id.str(), pack_container(input.all_containers[i]), txn);
        if (ret != NB_DB_RESULT_SUCCESS)
        {
            LOG_ERROR("ac_container_db::write "<< (ret == NB_DB_RESULT_SUCCESS ? "true" : "false"));
            result = false;
            return m_ptrHelper->ac_container_db_write_respond(call_id, result);
        }
    }
    result = true;
    return m_ptrHelper->ac_container_db_write_respond(call_id, result);
}

bool ac_container_db::commit(call_id_t call_id, const con_value& input)
{
    NbDbResult ret = ac_container_db_impl::instance().commit();
    if (ret == NB_DB_RESULT_SUCCESS)
    {
        bool result = true;
        return m_ptrHelper->ac_container_db_commit_respond(call_id, result);
    }
    else
        return false;
}

bool ac_container_db::rollback(call_id_t call_id)
{
    NbDbResult ret = ac_container_db_impl::instance().rollback();
    if (ret == NB_DB_RESULT_SUCCESS)
    {
        bool result = true;
        return m_ptrHelper->ac_container_db_rollback_respond(call_id, result);
    }
    else
        return false;
}

bool ac_container_db::has_impl_ptr() const
{
    return (NULL != m_condb_impl);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
