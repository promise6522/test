/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

// nb file
#include "ac_db/ac_container_db_impl.h"
#include "stdx_log.h"

ac_container_db_impl::ac_container_db_impl()
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string& db_name = "test";
        const std::string dbhome = "dbcontainer";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idvalue";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);

        m_txn = NULL;
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool ac_container_db_impl::begin_txn(DbTxn*& txn)
{
     boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    int ret = pdb->txn_begin(txn);
    if (ret == 0)
        return true;
    else 
        return false;
}

int ac_container_db_impl::write(const std::string& strkey, const std::string& value, DbTxn* txn)
{
    assert(pdb != NULL);

    if (m_txn == NULL)
    {
        boost::lock_guard<boost::mutex> guard(m_mtx_txn);
        if (m_txn == NULL)
            m_txn = txn;
    }

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, m_txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
    {
        LOG_ERROR(strkey + ": WRITE FAILED");
        ret = NB_DB_RESULT_FAILED;
    }
    return ret;
}

int ac_container_db_impl::write(const std::string& strkey, const std::string& value)
{
    assert(pdb != NULL);


    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, NULL);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
    {
        LOG_ERROR(strkey + ": WRITE FAILED");
        ret = NB_DB_RESULT_FAILED;
    }
    return ret;
}

int ac_container_db_impl::read(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);
    int ret = pdb->read(strkey, value);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
    {
        LOG_ERROR(strkey + ": READ NOT FOUND");
        ret = NB_DB_RESULT_NOTFOUND;
    }
    else
    {
        LOG_ERROR(strkey + ": READ FAILED");
        ret = NB_DB_RESULT_FAILED;
    }
    return ret;
}

bool ac_container_db_impl::read_handle(std::string& strval)
{
    assert(pdb != NULL);

    strval.clear();
    nbdbc dbc(pdb->get_db());
    std::string strkey, str_val;
    int ret;
    while ((ret = dbc.read(strkey, str_val)) == 0)
    {
        strval += "(" + strkey + ")";
    }
    return true; 
}

int ac_container_db_impl::del(const std::string& strkey)
{
    assert(pdb != NULL);
    int ret = pdb->del(strkey);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;
    return ret;
}

ac_container_db_impl::~ac_container_db_impl(void) 
{
    if (m_txn != NULL)
        pdb->rollback(m_txn);

    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

int ac_container_db_impl::commit()
{
    assert(pdb != NULL);

    if (m_txn != NULL)
    {
        boost::lock_guard<boost::mutex> guard(m_mtx_txn);
        DbTxn* txn = m_txn;
        m_txn = NULL; 
        int ret = pdb->commit(txn);
        if (ret == 0)
            ret = NB_DB_RESULT_SUCCESS;
        else
            ret = NB_DB_RESULT_FAILED;
        return ret;
    }
    return NB_DB_RESULT_FAILED;
}

int ac_container_db_impl::rollback()
{
    assert(pdb != NULL);

    if (m_txn != NULL)
    {
        boost::lock_guard<boost::mutex> guard(m_mtx_txn);
        DbTxn* txn = m_txn;
        m_txn = NULL;
        int ret = pdb->rollback(txn);
        if (ret == 0)
            ret = NB_DB_RESULT_SUCCESS;
        else
            ret = NB_DB_RESULT_FAILED;
    }
    return NB_DB_RESULT_FAILED;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
