/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

// nb file
#include "ac_db/ac_id_db.h"

ac_id_db::ac_id_db()
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string& db_name = "idhandle";
        const std::string dbhome = "dbid";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idhandle";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);

    }
    catch (DbException& e)
    {
        //DUKELOG_ERROR(log, "Unexpected exception : " << e.what());
    }
}

int ac_id_db::write(const std::string& strkey, const std::string& value, DbTxn* txn)
{
    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

int ac_id_db::read(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);
    int ret = pdb->read(strkey, value);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

ac_id_db::~ac_id_db(void) 
{
    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
