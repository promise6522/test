/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#include "ac_db/ac_storage_db_impl.h"
#include "stdx_log.h"

nbnv* 
ac_storage_env_impl::get_env() const 
{
    assert(penv != NULL);
    return penv;
}

ac_storage_env_impl::ac_storage_env_impl()
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string dbhome = "dbstorage";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);

    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

ac_storage_env_impl::~ac_storage_env_impl(void) 
{
    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

ac_storage_db_impl::ac_storage_db_impl()
{
    pdb = NULL;
}

int ac_storage_db_impl::write(const std::string& strkey, const std::string& value, DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn);

    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
    {
        LOG_ERROR(strkey + ": WRITE FAILED");
        ret = NB_DB_RESULT_FAILED;
    }
    return ret;
}

int ac_storage_db_impl::read(const std::string& strkey, std::string& value, DbTxn* txn)
{
    assert(pdb != NULL);

    int ret = pdb->read(strkey, value, txn);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
    {
        LOG_ERROR(strkey + ": read NOT FOUND");
        ret = NB_DB_RESULT_NOTFOUND;
    }
    else
    {
        LOG_ERROR(strkey + ": write FAILED");
        ret = NB_DB_RESULT_FAILED;
    }

    return ret;
}

bool ac_storage_db_impl::read_handle(std::string& strval, DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn);

    strval.clear();
    nbdbc dbc(pdb->get_db(), txn);
    std::string strkey, str_val;
    int ret;
    while ((ret = dbc.read(strkey, str_val)) == 0)
    {
        strval += "(" + strkey + ")";
    }
    return true; 
}

int ac_storage_db_impl::del(const std::string& strkey, DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn);

    int ret = pdb->del(strkey, txn);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

void ac_storage_db_impl::run(nbnv* penv, const std::string& storage_id)
{
    assert(penv != NULL);
    try
    {
        const std::string& dbfile = storage_id + ".db";
        const std::string& dbname = "idvalue";

        // create database environment
        pdb = new nbdb(dbfile, dbname, *penv);

    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }

    assert(pdb);
}

int ac_storage_db_impl::size(DbTxn* txn)
{
    assert(pdb);
    return pdb->size(txn);
}

int ac_storage_db_impl::truncate(DbTxn* txn)
{
    assert(pdb);
    assert(txn);

    return pdb->truncate(txn);
}

bool ac_storage_db_impl::read(pair_vid& output, DbTxn* txn)
{
    assert(pdb != NULL);
    //assert(txn);

    nbdbc dbc(pdb->get_db(), txn);

    std::string strkey, strval;
    int ret;
    while ((ret = dbc.read(strkey, strval)) == 0)
    {
        nb_id_t idkey(NBID_TYPE_NULL);
        nb_id_t idobj(NBID_TYPE_NULL);

        idkey.str(strkey);
        idobj.str(strval);
        output.push_back(std::make_pair(idkey, idobj));
    }
    return true;
}


bool ac_storage_db_impl::get_range(int start, int end, pair_vid& output, DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn);

    if ((start < 0) || (start > end))
        assert(false);
    nbdbc dbc(pdb->get_db(), txn);
    for (int i = 1; i <= end; ++i)
    {
        std::string strkey, strval;
        int ret = dbc.read(strkey, strval);
        if (ret != 0)
            return false;

        if ((i >= start) && (i <= end))
        {
            nb_id_t idkey, idobj;
            idkey.str(strkey);
            idobj.str(strval);
            output.push_back(std::make_pair(idkey, idobj));
        }
    }
    return true; 
}

bool ac_storage_db_impl::get_all(key_vid& output, DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn);

    nbdbc dbc(pdb->get_db(), txn);
    std::string strkey, strval;
    while ((dbc.read(strkey, strval)) == 0)
    {
        nb_id_t idobj;
        idobj.str(strval);
        output.push_back(idobj);
    }
    return true; 
}

bool ac_storage_db_impl::commit(DbTxn* txn)
{
    assert(pdb != NULL);
    //assert(txn != NULL);
    int ret = pdb->commit(txn);
    if (ret == 0)
        return true;
    else
        return false;
}

bool ac_storage_db_impl::rollback(DbTxn* txn)
{
    assert(pdb != NULL);
    assert(txn != NULL);

    int ret = pdb->rollback(txn);
    if (ret == 0)
        return true;
    else
        return false;
}

ac_storage_db_impl::~ac_storage_db_impl(void) 
{
    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }
}

nbdb* ac_storage_db_impl::get() const 
{
    return pdb;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
