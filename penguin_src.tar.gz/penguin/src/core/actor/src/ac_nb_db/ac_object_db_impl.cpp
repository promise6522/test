/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/
#include "ac_db/ac_object_db_impl.h"

#include <stdio.h>

#include "nb_profiler.h"
#include "stdx_log.h"

ac_object_db_impl::ac_object_db_impl() : nWrites_(0), keylens_(0), vallens_(0)
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string& db_name = "objectd";
        const std::string dbhome = "dbobject";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idvalue";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool ac_object_db_impl::begin_txn(DbTxn*& txn)
{
    int ret = pdb->txn_begin(txn);

    // begin_txn failure is a fatal error
    assert(ret == 0);

    return true;
}


bool ac_object_db_impl::exist(const std::string& strval, DbTxn* txn/* = NULL*/)
{
    assert(pdb != NULL);

    return pdb->exists(strval, txn);
}


int ac_object_db_impl::write(const std::string& strkey, const std::string& value, DbTxn* txn/* = NULL*/)
{   
    assert(pdb != NULL);

    return checked_write_(strkey, value, txn);
}


// inner implementation of write()
int ac_object_db_impl::checked_write_(const std::string& key, const std::string& value, DbTxn* txn)
{
#ifndef NDEBUG
    /* for performance evaluation */
    NEW_SCOPE_TIMER("ac_object_db_impl::write_", false);
    nWrites_++;
    keylens_ += key.size();
    vallens_ += value.size();
#endif

    int ret = 0;
    try
    {
        // ##for object_db, we don't allow overwrite
        uint32_t flags = 0;//DB_NOOVERWRITE;// = 0;
        ret = pdb->write(key, value, txn, flags);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (0 != ret)
    // On db write failed
    {
        LOG_ERROR(key +  ": WRITE FAILED");

        if (ret == DB_KEYEXIST)
        {
            // Overwrite detected, write to a persist log

            // read the previous value for reference
            std::string old_val;
            pdb->read(key, old_val, txn);

            // get current time
            time_t tm;
            time(&tm);

            FILE* pFile = fopen("obj_db_overwrite.log", "a");//append only
            if (pFile)
            {
                fprintf(pFile, "Overwrite detected at %s Key = %s\n OldVal = %s\n NewVal = %s\n", 
                        ctime(&tm), key.c_str(), old_val.c_str(), value.c_str());
                fclose(pFile);
            } 
        }

        return NB_DB_RESULT_FAILED;
    }

    return NB_DB_RESULT_SUCCESS;
}


int ac_object_db_impl::read(const std::string& strkey, std::string& value, DbTxn* txn/* =NULL */)
{
    assert(pdb != NULL);

    int ret = pdb->read(strkey, value, txn);

    if (ret == 0)
        return NB_DB_RESULT_SUCCESS;

    else if (ret == DB_NOTFOUND)
    {
        LOG_ERROR("ac_object_db_impl::read() : " << strkey << ": NOT FOUND");
        return NB_DB_RESULT_NOTFOUND;
    }

    else
    {
        LOG_ERROR("ac_object_db_impl::read() : " << strkey << ": READ FAILED");
        return NB_DB_RESULT_FAILED;
    }
}


bool ac_object_db_impl::read_all_handles(std::string& strval)
{
    assert(pdb != NULL);

    strval.clear();
    nbdbc dbc(pdb->get_db());
    std::string strkey, str_val;
    int ret;
    while ((ret = dbc.read(strkey, str_val)) == 0)
    {
        strval += "(" + strkey + ")";
    }

    return true; 
}

int ac_object_db_impl::del(const std::string& strkey, DbTxn* txn/* = NULL*/)
{
    assert(pdb != NULL);

    int ret = pdb->del(strkey, txn);

    if (ret == 0)
        return NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        return NB_DB_RESULT_NOTFOUND;
    else
        return NB_DB_RESULT_FAILED;

}


bool ac_object_db_impl::commit(DbTxn* txn)
{
    assert(pdb != NULL);

    if (txn == NULL)
    {
        LOG_ERROR("ac_object_db_impl::commit() : txn to commit is NULL!");
        return false;
    }

    int ret = pdb->commit(txn);

    return (ret == 0 ? true : false);
}


bool ac_object_db_impl::rollback(DbTxn* txn)
{
    assert(pdb != NULL);

    if (txn == NULL)
    {
        LOG_ERROR("ac_object_db_impl::rollback() : txn to rollback is NULL!");
        return false;
    }

    int ret = pdb->rollback(txn);

    return (ret == 0 ? true : false);
}


ac_object_db_impl::~ac_object_db_impl() 
{
    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }

#ifndef NDEBUG
    if(nWrites_)
    {
        LOG_DEBUG(" ");
        LOG_DEBUG("========== ac_object_db ==========");
        LOG_DEBUG("total writes : "<< nWrites_/* << "    transactional : "<< nTxnWrites_*/);
        LOG_DEBUG("KEY-SIZE  avg : "<< keylens_/nWrites_ << "    total : "<< keylens_);
        LOG_DEBUG("VAL-SIZE  avg : "<< vallens_/nWrites_ << "    total : "<< vallens_);
        LOG_DEBUG(" ");
    }
#endif
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
