/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object_db.h"

bool ac_object_db::initialization()
{
    m_top_seq_num = 0;    
    return true;
}

int ac_object_db::generate_seq_num()
{
    return ++m_top_seq_num;  
}

bool ac_object_db::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_object_db::read(call_id_t call_id, const object_ids& input)
{
    std::vector<nb_id_t>::const_iterator const_it;
    db_value value;
    for (const_it = input.ids.begin(); const_it != input.ids.end(); ++const_it)
    {
        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(const_it->str(), strval);
        if (ret == NB_DB_RESULT_SUCCESS)
        {
            content con;
            unpack_object(strval, con);
            //std::cout<<"ac_object_db::read "<< con.object_id.str() <<std::endl;
            std::string strvalue =  pack_object(con);
            //strvalue.append(con.id_value.values[0].begin(), con.id_value.values[0].end());
            //std::cout<<"ac_object_db::read value:"<< strvalue <<std::endl;
            value.all_objects.push_back(con);
        }
        else
            LOG_ERROR(const_it->str() + " : NOT READ FROM OBJECT DB");
    }
    return m_ptrHelper->ac_object_db_read_respond(call_id, value);
}
    
bool ac_object_db::read_anchors(call_id_t call_id, const anchor_ids& input)
{
    std::vector<anchor_id_t>::const_iterator const_it;
    db_value value;
    for (const_it = input.ids.begin(); const_it != input.ids.end(); ++const_it)
    {
        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(const_it->str(), strval);
        if (ret == NB_DB_RESULT_SUCCESS)
        {
            content con;
            unpack_object(strval, con);
            //std::cout<<"ac_object_db::read "<< con.object_id.str() <<std::endl;
            //std::string strvalue;
            //strvalue.append(con.id_value.values[0].begin(), con.id_value.values[0].end());
            //std::cout<<"ac_object_db::read value:"<< strvalue <<std::endl;
            value.all_objects.push_back(con);
        }
        else
            LOG_ERROR(const_it->str() + " : NOT READ FROM OBJECT DB");
    }
    return m_ptrHelper->ac_object_db_read_anchors_respond(call_id, value);
}
    
bool ac_object_db::read_storages(call_id_t call_id, const storage_ids& input)
{
    std::vector<storage_id_t>::const_iterator const_it;
    db_value value;
    for (const_it = input.ids.begin(); const_it != input.ids.end(); ++const_it)
    {
        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(const_it->str(), strval);
        if (ret == NB_DB_RESULT_SUCCESS)
        {
            content con;
            unpack_object(strval, con);
            //std::cout<<"ac_object_db::read "<< con.object_id.str() <<std::endl;
            //std::string strvalue;
            //strvalue.append(con.id_value.values[0].begin(), con.id_value.values[0].end());
            //std::cout<<"ac_object_db::read value:"<< strvalue <<std::endl;
            value.all_objects.push_back(con);
        }
        else
            LOG_ERROR(const_it->str() + " : NOT READ FROM OBJECT DB");
    }
    return m_ptrHelper->ac_object_db_read_storages_respond(call_id, value);
}
    
bool ac_object_db::write(call_id_t call_id, const db_value& input)
{
    int seq_num = generate_seq_num();
    m_seq_value_map.insert(std::make_pair(seq_num, input));    

    return m_ptrHelper->ac_object_db_write_respond(call_id, seq_num);
}

bool ac_object_db::commit(call_id_t call_id, const int& seq_num)
{
    bool ret = true;    
    std::map<int, db_value>::iterator it = m_seq_value_map.find(seq_num);
    if(it == m_seq_value_map.end())
    {
        ret = false;        
        return m_ptrHelper->ac_object_db_commit_respond(call_id, ret);
    }

    const db_value& input = it->second;

    DbTxn* txn = NULL;            
    bool bret = ac_object_db_impl::instance().begin_txn(txn);
    assert(bret);

    for (unsigned int i = 0; i < input.all_objects.size(); ++i)
    {
        NbDbResult _ret = ac_object_db_impl::instance().write(input.all_objects[i].object_id.str(),
                pack_object(input.all_objects[i]),
                txn);

        if (_ret != NB_DB_RESULT_SUCCESS)
        {
            LOG_ERROR("ac_object_db::write failed");
            ac_object_db_impl::instance().rollback(txn);
            ret = false;
            return m_ptrHelper->ac_object_db_commit_respond(call_id, ret);
        }
    }

    m_seq_value_map.erase(it);
    ret = ac_object_db_impl::instance().commit(txn);    
    return m_ptrHelper->ac_object_db_commit_respond(call_id, ret);
}

bool ac_object_db::rollback(call_id_t call_id, const int& seq_num)
{
    bool ret = true;    
    std::map<int, db_value>::iterator it = m_seq_value_map.find(seq_num);
    if(it == m_seq_value_map.end())
    {
        ret = false;        
        return m_ptrHelper->ac_object_db_rollback_respond(call_id, ret);
    }
    m_seq_value_map.erase(it); 
    return m_ptrHelper->ac_object_db_rollback_respond(call_id, ret);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
