/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

// nb file
#include "ac_db/ac_user_content_db_impl.h"
#include "stdx_log.h"


ac_user_content_db_impl::ac_user_content_db_impl()
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string& db_name = "bridge";
        const std::string dbhome = "dbbridge";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "keyvalue";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

int ac_user_content_db_impl::write(const std::string& strkey, const std::string& value)
{   
    assert(pdb != NULL);

    DbTxn* txn = NULL;
    int ret = 0;
    try
    {
        ret = pdb->write(strkey, value, txn);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

int ac_user_content_db_impl::read(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);

    int ret = pdb->read(strkey, value);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}


ac_user_content_db_impl::~ac_user_content_db_impl(void) 
{

    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
