#include "ac_container/container_data_packer.h"

//std::string container_data_packer::pack_to_stream(const con_id_value& data)
std::string container_data_packer::pack_to_stream(const con_content& data)
{
    std::string stream;

    //m_data = data.id_value;

    // 1. pack total size and id size
    size_type id_size = data.id_value.ids.size();
    size_type value_size = data.id_value.values.size();
    stream.assign(container_data_packer::size_to_str(id_size+value_size));
    stream.append(container_data_packer::size_to_str(id_size));
    stream.resize(2*SIZE_LENGTH);

    // 2. pack ids
    //for (uint i = 0; i < data.ids.size(); ++i)
    for (size_type i = 0; i < id_size; ++i)
        stream.append(data.id_value.ids[i].str());

    // 4. pack values
	size_type len = 0;
    for (size_type i = 0; i < value_size; ++i)
    {
        len = stream.length();
        size_type size = data.id_value.values[i].size();
        stream.append(container_data_packer::size_to_str(size));
        stream.resize(len + SIZE_LENGTH);

		stream.append(data.id_value.values[i].begin(), data.id_value.values[i].end());	
    }

	stream.append(data.container_id.str());
    //m_stream = stream;
    return stream;
}

std::string container_data_packer::packer_to_stream()
{
	return container_data_packer::pack_to_stream(this->get_pack_data());
}

//con_id_value container_data_packer::get_pack_data()
con_content container_data_packer::get_pack_data()
{
    return m_data;
}

bool container_data_packer::set_con_id(const container_id_t& id)
{
	this->m_data.container_id = id;
	return true;
}

void container_data_packer::pack(const std::vector<container_id_t>& ids,
                  const std::vector< std::vector<char> >& values)
{
    pack(ids);
    pack(values);
}

void container_data_packer::pack(const std::vector<container_id_t>& ids)
{
    m_data.id_value.ids.insert(m_data.id_value.ids.end(), ids.begin(), ids.end());
}

void container_data_packer::pack(const container_id_t& id)
{
    m_data.id_value.ids.push_back(id);
}

void container_data_packer::pack(const std::vector< std::vector<char> >& values)
{
    m_data.id_value.values.insert(m_data.id_value.values.end(), values.begin(), values.end());
}

void container_data_packer::pack(const std::vector<char>& value)
{
    m_data.id_value.values.push_back(value);
}

void container_data_packer::pack(const std::string& value)
{
    m_data.id_value.values.push_back(std::vector<char>(value.begin(), value.end()));
}


void container_data_packer::pack(int value)
{
    std::stringstream ss;
    std::string strs;
    ss << value;
    ss >> strs;
    m_data.id_value.values.push_back(std::vector<char>(strs.begin(), strs.end()));
}

void container_data_packer::pack(bool value)
{
    std::stringstream ss;
    std::string strs;
    ss << (value!=0 ? "true" : "false");
    ss >> strs;
    m_data.id_value.values.push_back(std::vector<char>(strs.begin(), strs.end()));
}

std::string container_data_packer::size_to_str(size_type sz)
{
    //std::ostringstream oss;
    //oss << std::setw(SIZE_LENGTH) << std::setfill('0') << std::hex << value;
    //return oss.str();
    return std::string(reinterpret_cast<char*>(&sz), SIZE_LENGTH);
}
