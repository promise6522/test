/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_container.h"

//#define TEMP_CONT 

bool ac_container::initialization()
{
    assert(m_ptrHelper);

    time_t tm;    
    time(&tm);
    req_num_t req_num = req_num_t(tm, true);

    container_ids input;
    input.ids.push_back(m_id);

    m_ptrHelper->ac_container_db_read(req_num, input);

    return true;
}

bool ac_container::initialization(const con_content& data)
{
    assert(m_ptrHelper);

    //set data by impl
    m_ptrImpl.reset(new(std::nothrow) container_implementation(m_id, data));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_container::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_container::get_definition(nb_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_definition(output);
}

bool ac_container::get_anchor(const int& input, anchor_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_anchor(input, output);
}

bool ac_container::get_storage(const int& input, storage_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_storage(input, output);
}

bool ac_container::get_storage_type(const int& input, nb_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_storage_type(input, output);
}

bool ac_container::inform_store_singleton_object(call_id_t call_id, 
  const inform_singleton_object_t& input)
{ 
    assert(m_ptrImpl);
    //return m_ptrImpl->info_store_singleton_object(call_id, input);
    return true;
}

bool ac_container::ac_container_db_read_response(req_num_t req_num, con_value& output)
{

    assert(m_ptrHelper);

    if(0 == output.all_containers.size())
    {
        LOG_ERROR("ac_container intialization failed");
        m_ptrHelper->initialization_respond_fail();
        return false;
    }

    m_ptrImpl.reset(new(std::nothrow) container_implementation(m_id, output.all_containers[0]));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_container::get_value_sync(con_content& output)
{    
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(output);    
}

bool ac_container::get_value_async(call_id_t call_id)
{    
    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_container initializaton failed");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    con_content value;
    if(!m_ptrImpl->get_value(value))
	return false;

    return m_ptrHelper->ac_container_get_value_async_respond(call_id,
	    value); 
}

bool ac_container::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
