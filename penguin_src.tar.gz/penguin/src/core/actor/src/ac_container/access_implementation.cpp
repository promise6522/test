/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
// stdx header files
#include "stdx_json.h"

#include "ac_container/access_implementation.h"
#include "ac_container/container_implementation.h"
#include "ac_container/anchor_implementation.h"
#include "ac_object/obj_impl_container_def.h"

access_implementation::access_implementation()
{
    time_t tm;
    time(&tm);
    m_top_req_num = tm;
}

access_implementation::access_implementation(const access_id_t& access_id, 
	const content& data)
{
    time_t tm;
    time(&tm); 
    m_top_req_num = tm;
    m_id = access_id;
    unpack(data);
}

access_implementation::~access_implementation()
{
}

bool access_implementation::get_value(content& data)
{
    pack(data);
    return true;
}

bool access_implementation::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool access_implementation::pack(const access_data_t& logic_data, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.anchor_idx);
    packer.pack(logic_data.parent_container.str());
    packer.pack(logic_data.is_registed);
    packer.pack(logic_data.is_outgoing);

    packer.pack(logic_data.interface);

    raw_data = packer.get_pack_data();
    return true;
}

bool access_implementation::unpack(const content& raw_data, access_data_t& logic_data)
{
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data.name = unpack.unpack_string(0);
    logic_data.anchor_idx = unpack.unpack_int(1);
    logic_data.parent_container.str(unpack.unpack_string(2));
    logic_data.is_registed = unpack.unpack_bool(3);
    logic_data.is_outgoing = unpack.unpack_bool(4);
    logic_data.interface = unpack.unpack_id(0);
    return true;
}

bool access_implementation::unpack(const content& raw_data)
{
    unpack(raw_data, m_cData);
    return true;
}

bool access_implementation::pack(content& raw_data)
{
    pack(m_cData, raw_data);
    return true;
}

bool access_implementation::json_pack(const access_data_t& logic_data, content& raw_data)
{
	/*struct access_data_t
	{
    	std::string name;
    	int anchor_idx; 
    	container_id_t parent_container;
    	nb_id_t interface;
   		bool is_registed; 
	};*/ 
	boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
	pObj->insert("name", new stdx::json_string(logic_data.name));
	pObj->insert("anchor_idx", new stdx::json_int(logic_data.anchor_idx));
	pObj->insert("parent_container", new stdx::json_string(logic_data.parent_container.str()));
	pObj->insert("interface", new stdx::json_string(logic_data.interface.str()));
	pObj->insert("is_registed", new stdx::json_boolean(logic_data.is_registed));
	
	std::string strval = pObj->to_json_string();

	raw_data.id_value.ids.clear();
	raw_data.id_value.values.clear();
	std::vector<char> vchar(strval.begin(), strval.end());
	raw_data.id_value.values.push_back(vchar);

    return true;
}

bool access_implementation::json_unpack(const content& raw_data, access_data_t& logic_data)
{
	if (raw_data.id_value.values.empty())
		return true;
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

	boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    stdx::json_node* item;
    item = pObj->find("name");
    logic_data.name = item->get_string();
    item = pObj->find("anchor_idx");
    logic_data.anchor_idx = item->get_int();
    item = pObj->find("parent_container");
    logic_data.parent_container.str(item->get_string());
    item = pObj->find("interface");
    logic_data.interface.str(item->get_string());
    item = pObj->find("is_registed");
    logic_data.is_registed = item->get_boolean();

    return true;
}

// run handle
bool access_implementation::run(call_id_t call_id, 
	const node_invocation_request& input,
	ac_access_helper * pHelper)
{ 
    LOG_DEBUG("*** access_implementation::run() ");

    assert(pHelper);

    m_pHelper = pHelper;

//    transaction_id_t transaction_id;
//    host_committer_id_t host_committer_id;

    trans_comm_pair_t tc_pair;
    tc_pair.m_host_committer_id = input.host_committer_id;
    tc_pair.m_transaction_id = input.transaction_id;

    bool is_local;
    if (!pHelper->ac_machine_is_local(tc_pair, is_local))
        return false;

    transaction_id_t transaction_id;
    host_committer_id_t host_committer_id;

    if (is_local)
        host_committer_id = input.host_committer_id;
    else if (!pHelper->ac_id_dispenser_request_host_committer_id(host_committer_id))
        return false;

    if (!pHelper->ac_id_dispenser_request_transaction_id(host_committer_id, transaction_id))
        return false;

    //set parent transaction 
    req_num_t req_num = generate_req_num();    

    req_info_t req_info;
    req_info.call_id = call_id;
    req_info.input = input;
    req_info.input.host_committer_id = host_committer_id;
    req_info.input.transaction_id = transaction_id;

    begin_call_info(req_num, req_info);

    if (!pHelper->ac_transaction_begin(transaction_id, req_num, tc_pair))
        return false;

    return true;
}

bool access_implementation::ac_transaction_begin_response(req_num_t req_num)
{
    //request new execution actor
    req_info_t req_info;
    m_msg.get_req_info(req_num, req_info);

    request_execution_id_info exe_info;
    exe_info.committer_id = req_info.input.host_committer_id;
    exe_info.exec_info.obj_info.object_id = static_cast<nb_id_t>(m_id);
    exe_info.exec_info.obj_info.object_id.set_type(NBID_TYPE_OBJECT_ACCESS);
    pack(m_cData, exe_info.exec_info.obj_info.obj_raw_data);
    execution_id_t execution_id;
    if (!m_pHelper->ac_id_dispenser_request_execution_id(exe_info, execution_id))
        return false;

    //set parent for implementation for execution 
    if (!m_pHelper->ac_execution_set_parent(execution_id, req_info.input.execution_id))
        return false;

    //set execution requesteter 
    node_invocation_request request = req_info.input;
    request.execution_id = execution_id;

    if (!m_pHelper->ac_execution_start(request.execution_id, req_num, request))
        return false;

    return true;
}

// request number handles
req_num_t access_implementation::generate_req_num()
{
    return m_top_req_num++;    
}

void access_implementation::begin_incoming_instruction(req_num_t req_num, 
            nb_builtin_instruction_t instruction)
{
    m_instruction_map.insert(std::make_pair(req_num, instruction));    
}

void access_implementation::end_incoming_instruction(req_num_t req_num)
{
    m_instruction_map.erase(req_num);
}

bool access_implementation::get_instruction(req_num_t req_num, 
            nb_builtin_instruction_t& instruction)
{
    builtin_instruction_map_it it = m_instruction_map.find(req_num);

    if(it == m_instruction_map.end())
    {
  return false;
    }

    instruction = it->second;
    return true;
}

void access_implementation::begin_call_info(req_num_t req_num, req_info_t& req_info)
{
    m_msg.begin_incoming_req_info(req_num, req_info);
}

void access_implementation::end_call_info(req_num_t req_num)
{
    m_msg.end_incoming_req_info(req_num);
}

bool access_implementation::get_call_info(req_num_t req_num, req_info_t& req_info)
{
    return m_msg.get_req_info(req_num, req_info);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
