/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
// stdx header files
#include "stdx_json.h"

#include "ac_container/storage_implementation.h"
#include "ac_object/obj_impl_interface_compound.h"

storage_implementation::storage_implementation()
{
    time_t tm;
    time(&tm);
    m_top_req_num = tm;
}

storage_implementation::storage_implementation(const storage_id_t& storage_id)
{
    time_t tm;
    time(&tm);
    m_top_req_num = tm;
    m_id = storage_id;
}

storage_implementation::storage_implementation(const storage_id_t& storage_id,
	const content& data,
    ac_storage_helper * pHelper)
{
    m_id = storage_id;
    m_pHelper = pHelper;
    time_t tm;    
    time(&tm);  
    m_top_req_num = tm;
    unpack(data);
}

storage_implementation::~storage_implementation()
{
}

bool storage_implementation::get_value(content& data)
{
    pack(data);
    return true;
}

bool storage_implementation::set_value(const content& data)
{
    return true;
}

bool storage_implementation::pack(const storage_data_t& logic_data, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.interface);

    raw_data = packer.get_pack_data();
    return true;
}

bool storage_implementation::unpack(const content& raw_data, storage_data_t& logic_data)
{
    data_unpacker unpack(raw_data);

    int str_index = -1;
    int nb_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);
    logic_data.interface = unpack.unpack_id(++nb_index);
    return true;
}

bool storage_implementation::pack(content& raw_data)
{
    pack(m_cData, raw_data);
    return true;
}

bool storage_implementation::unpack(const content& raw_data)
{
    unpack(raw_data, m_cData);
    return true;
}

bool storage_implementation::json_pack(const storage_data_t& logic_data, content& raw_data)
{
	/*struct storage_data_t
	{
    	std::string name;
    	nb_id_t interface;
    	container_id_t parent_container;
	};*/

	boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
	pObj->insert("name", new stdx::json_string(logic_data.name));
	pObj->insert("interface", new stdx::json_string(logic_data.interface.str()));

	std::string strval = pObj->to_json_string();

	raw_data.id_value.ids.clear();
	raw_data.id_value.values.clear();
	std::vector<char> vchar(strval.begin(), strval.end());
	raw_data.id_value.values.push_back(vchar);

    return true;
}

bool storage_implementation::json_unpack(const content& raw_data, storage_data_t& logic_data)
{
	if (raw_data.id_value.values.empty())
		return true;

	std::vector<char> vchar = raw_data.id_value.values[0];
	std::string strval(vchar.begin(), vchar.end());

	boost::shared_ptr<stdx::json_object> pObj;
	pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
	assert(pObj); 

	stdx::json_node* item;
	item = pObj->find("name");
	logic_data.name = item->get_string();
	item = pObj->find("interface");
	logic_data.interface.str(item->get_string());

	return true;
}

bool storage_implementation::get_interface(nb_id_t& result)
{
    result = m_cData.interface;
    return true;
}


req_num_t storage_implementation::generate_req_num()
{
    return m_top_req_num++;  
}

void storage_implementation::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void storage_implementation::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool storage_implementation::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if(it == m_req_info_map.end())
    {
        return false;
    }

    call_id = it->second;
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
