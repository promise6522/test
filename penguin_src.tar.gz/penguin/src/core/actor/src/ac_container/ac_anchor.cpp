/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_anchor.h"

bool ac_anchor::initialization()
{
	assert(m_ptrHelper);
    time_t tm;    
    time(&tm);
    req_num_t req_num = req_num_t(tm, true);

    anchor_ids input;
    input.ids.push_back(m_id);

    m_ptrHelper->ac_object_db_read_anchors(++req_num, input);

	return true;
}

bool ac_anchor::initialization(const content& data)
{
    assert(m_ptrHelper);

    //set data by impl
    m_ptrImpl.reset(new(std::nothrow) anchor_implementation(m_id, 
		data, 
		m_ptrHelper.get()));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_anchor::get_value_sync(content& output)
{
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(output);    
}

bool ac_anchor::get_value_async(call_id_t call_id)
{    
    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_anchor implement pointer initialization failed");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    content value;
    if(!m_ptrImpl->get_value(value))
	return false;

    return m_ptrHelper->ac_anchor_get_value_async_respond(call_id,
	    value); 
}

bool ac_anchor::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_anchor::get_interface(nb_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_interface(output);
}

bool ac_anchor::generate_access(const node_invocation_request& input, access_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->generate_access(input, output);
}

bool ac_anchor::find_declaration(const nb_id_t& input, bool& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->find_declaration(input, output);
}

bool ac_anchor::get_implementation(const nb_id_t& input, nb_id_t& output)
{ 
    assert(m_ptrImpl);
    return m_ptrImpl->get_implementation(input, output);
}

//bool ac_anchor::run(call_id_t call_id, 
//	const node_invocation_request& input)
//{ 
//
//    return true; 
//}

bool ac_anchor::ac_object_db_read_anchors_response(req_num_t req_num, db_value& output)
{
    assert(m_ptrHelper);

    if(0 == output.all_objects.size())
    {
        LOG_ERROR("ac_anchor intialization failed");
        m_ptrHelper->initialization_respond_fail();
        return false;
    }

    m_ptrImpl.reset(new(std::nothrow) anchor_implementation(m_id, output.all_objects[0], m_ptrHelper.get()));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_anchor::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
