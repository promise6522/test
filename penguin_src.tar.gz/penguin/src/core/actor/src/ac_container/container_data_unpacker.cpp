#include "ac_container/container_data_unpacker.h"

bool container_data_unpacker::unpack_from_stream(const std::string& stream, con_content& data)
{
	//con_content raw_data;
    //m_stream = stream;

    std::string strval = stream;

    // 1. unpack value size and id size
	size_type total_size = container_data_unpacker::str_to_size( strval.substr( 0, SIZE_LENGTH ) );
    strval = strval.substr( SIZE_LENGTH );

	size_type id_size = container_data_unpacker::str_to_size( strval.substr( 0, SIZE_LENGTH ) );
	strval = strval.substr( SIZE_LENGTH );

    // 2. unpack ids
    for (size_type i = 0; i < id_size; ++i)
    {
        //container_id_t id;
        //id.str(strval.substr(0, ID_LENGTH));
        //data.ids.push_back(id);
		data.id_value.ids.push_back(container_id_t(strval.substr(0, ID_LENGTH)));
        strval = strval.substr(ID_LENGTH);
    }


    // 3. unpack values
    size_type value_size = total_size - id_size;
    for (size_type i = 0; i < value_size; ++i)
    {
        // 4.1. get each value size
        size_type size = str_to_size(strval.substr(0, SIZE_LENGTH));
        strval = strval.substr(SIZE_LENGTH);

        // 4.2. get value
        std::string s = strval.substr(0, size);
        data.id_value.values.push_back(std::vector<char>(s.begin(), s.end()));
        strval = strval.substr(size);
    }

	//raw_data.id_value = m_data;
	data.container_id.str(strval.substr(0));
	
    return true;
}

void container_data_unpacker::set_data(const con_content& data)
{
    m_data = const_cast<con_content*>(&data);
}

con_content container_data_unpacker::get_unpack_data()
{
	if(m_data!=NULL)
	{
		return *m_data;
	}
    return con_content();
}

std::vector<container_id_t> container_data_unpacker::unpack_ids()
{
    return m_data->id_value.ids;
}

container_id_t container_data_unpacker::unpack_id(int index)
{
    return m_data->id_value.ids[index];
}

std::vector< std::vector<char> > container_data_unpacker::unpack_values()
{
    return m_data->id_value.values;
}

std::vector<char> container_data_unpacker::unpack_chars(int index)
{
    return m_data->id_value.values[index];
}

std::string container_data_unpacker::unpack_string(int index)
{
    return std::string(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
}

int container_data_unpacker::unpack_int(int index)
{
    std::string strval(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
    return atoi(strval.c_str());
}

bool container_data_unpacker::unpack_bool(int index)
{
    std::string strval(m_data->id_value.values[index].begin(), m_data->id_value.values[index].end());
    bool ret = (strval == "true") ? true : false;
    return ret;
}

container_data_unpacker::size_type container_data_unpacker::str_to_size(const std::string& str)
{
    assert(str.size() == SIZE_LENGTH);

    size_type sz;
    memcpy(&sz, str.c_str(), SIZE_LENGTH);

    return sz;
}
