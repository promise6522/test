/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
// stdx header files
#include "stdx_json.h"

#include "ac_container/anchor_implementation.h"
#include "ac_container/access_implementation.h"
#include "ac_object/obj_impl_interface_compound.h"

//#define DEBUG_ACCESS 

anchor_implementation::anchor_implementation()
{
    time_t tm;
    time(&tm);
    m_top_req_num = tm;
}

anchor_implementation::anchor_implementation(const anchor_id_t& anchor_id)
{
    time_t tm;
    time(&tm);
    m_top_req_num = tm;
    m_id = anchor_id;
}

anchor_implementation::anchor_implementation(const anchor_id_t& anchor_id,
	const content& data,
    ac_anchor_helper * pHelper)
{
    m_id = anchor_id;
    m_pHelper = pHelper;
    time_t tm;    
    time(&tm);  
    m_top_req_num = tm;
    unpack(data);
}

anchor_implementation::~anchor_implementation()
{
}

bool anchor_implementation::get_value(content& data)
{
    pack(data);
    return true;
}

bool anchor_implementation::set_value(const content& data)
{
    return true;
}

bool anchor_implementation::pack(const anchor_data_t& logic_data, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.registed);

    int funcs_size = logic_data.funcs.size();
    nb_id_t nb_funcs( NBID_TYPE_OBJECT_INT ); 
    nb_funcs.set_value(funcs_size);
    packer.pack(nb_funcs);
    for(int j=0; j < funcs_size; ++j)
    {
        packer.pack(logic_data.funcs[j].declaration_id);
        packer.pack(logic_data.funcs[j].implementation_id);
    }
    packer.pack(logic_data.interface);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    return true;
}

bool anchor_implementation::unpack(const content& raw_data, anchor_data_t& logic_data)
{
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int str_index = -1;
    int nb_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);
    logic_data.registed = unpack.unpack_bool(++str_index);

    int funcs_size = 0;
    unpack.unpack_id(++nb_index).get_value(funcs_size);
    for(int j=0; j < funcs_size; ++j)
    {
       func_pair_t func_data; 
       func_data.declaration_id = unpack.unpack_id(++nb_index);
       func_data.implementation_id = unpack.unpack_id(++nb_index);
       logic_data.funcs.push_back(func_data);
    }
    logic_data.interface = unpack.unpack_id(++nb_index);
    return true;
}

bool anchor_implementation::pack(content& raw_data)
{
    pack(m_cData, raw_data);
    return true;
}

bool anchor_implementation::unpack(const content& raw_data)
{
    unpack(raw_data, m_cData);
    return true;
}

bool anchor_implementation::json_pack(const anchor_data_t& logic_data, content& raw_data)
{
	/*struct anchor_data_t
	{
    	std::string name;
    	func_pair_vector funcs;
    	bool registed;
    	nb_id_t interface;
    	container_id_t parent_container;
	};*/

	boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
	pObj->insert("name", new stdx::json_string(logic_data.name));
	pObj->insert("registed", new stdx::json_boolean(logic_data.registed));
	pObj->insert("interface", new stdx::json_string(logic_data.interface.str()));
	// pack func_pair_vector funcs
	stdx::json_array* jarr = new stdx::json_array();
	for(std::vector<func_pair_t>::const_iterator it = logic_data.funcs.begin(); 
		it != logic_data.funcs.end(); 
		++it)
	{
		stdx::json_object* obj2 = new stdx::json_object();
		obj2->insert("declaration_id", new stdx::json_string(it->declaration_id.str()));
		obj2->insert("implementation_id", new stdx::json_string(it->implementation_id.str()));
		jarr->push_back(obj2);
	}
	pObj->insert("funcs", jarr);

	std::string strval = pObj->to_json_string();

	raw_data.id_value.ids.clear();
	raw_data.id_value.values.clear();
	std::vector<char> vchar(strval.begin(), strval.end());
	raw_data.id_value.values.push_back(vchar);

    return true;
}

bool anchor_implementation::json_unpack(const content& raw_data, anchor_data_t& logic_data)
{
	if (raw_data.id_value.values.empty())
		return true;

	std::vector<char> vchar = raw_data.id_value.values[0];
	std::string strval(vchar.begin(), vchar.end());

	boost::shared_ptr<stdx::json_object> pObj;
	pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
	assert(pObj); 

	stdx::json_node* item;
	item = pObj->find("name");
	logic_data.name = item->get_string();
	item = pObj->find("registed");
	logic_data.registed = item->get_boolean();
	item = pObj->find("interface");
	logic_data.interface.str(item->get_string());

	// unpack func_pair_vector funcs
	item = pObj->find("funcs");
	stdx::json_array* jarr = dynamic_cast<stdx::json_array*>(item);
	assert(jarr);
	for(int i = 0; i < jarr->size(); ++i )
	{
		stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
		assert(subobj);
		func_pair_t funcpair;
		funcpair.declaration_id.str((subobj->find("declaration_id"))->get_string());
		funcpair.implementation_id.str((subobj->find("implementation_id"))->get_string());
		logic_data.funcs.push_back(funcpair);
	}

	return true;
}


bool anchor_implementation::get_implementation(const nb_id_t& decl_id, nb_id_t& impl_id)
{
    for (func_vector_const_it it = m_cData.funcs.begin();
            it != m_cData.funcs.end();
            ++it)
    {
        if (it->declaration_id == decl_id)
        {
            impl_id = it->implementation_id;
            return true; 
        }
    }

    return false; 
}

bool anchor_implementation::get_interface(nb_id_t& result)
{
    result = m_cData.interface;
    return true;
}

bool anchor_implementation::is_registed(nb_id_t& result)
{
    result = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    result.set_value(m_cData.registed);

    return true;
}

bool anchor_implementation::generate_access(const node_invocation_request& request, access_id_t& result)
{
    LOG_DEBUG("*** anchor_implementation::generate_access()");

    assert(NULL != m_pHelper);
    assert(1 == request.input.size());
    assert(request.input[0].is_object_integer());

    // create access
    request_access_id_info access_info;
    access_info.committer_id = request.host_committer_id; 

    access_data_t access_data;
    access_data.interface = m_cData.interface;
    access_data.is_registed = m_cData.registed;

    int an_idx;
    request.input[0].get_value(an_idx);
    access_data.anchor_idx = an_idx;

    access_implementation::pack(access_data, access_info.raw_data);

    access_id_t access_id;
    if (!m_pHelper->ac_host_committer_request_access_id(request.host_committer_id,
		access_info, 
		access_id))
	return false;

#ifdef DEBUG_ACCESS
    ac_id_t dest_id;
    if(!ac_manager::instance().request_actor(access_id))
        return false;

    if(!ac_manager::instance().get_ac_id(access_id, dest_id))
        return false;

    node_invocation_request* pParam = ac_memory_alloctor<node_invocation_request>::instance().allocate();
    pParam->host_committer_id = request.host_committer_id;
    pParam->transaction_id = transaction_id_t();
    pParam->declaration_id = m_cData.funcs[0].declaration_id; 
    pParam->object_id = static_cast<nb_id_t>(access_id);
    return ac_manager::instance().send_asyn_message(dest_id, 0, 1, e_ac_access_run, pParam);
#endif
    return true;
}

bool anchor_implementation::destroy_access(access_id_t& result)
{
    return true;
}

bool anchor_implementation::get_functions(func_vector& output)
{
    return true;
}

bool anchor_implementation::find_declaration(const nb_id_t& decl_id, 
	bool& result)
{
    result = false;

    for (func_vector_const_it it = m_cData.funcs.begin();
            it != m_cData.funcs.end();
            ++it)
    {
        if (it->declaration_id == decl_id)
        {
	    result = true;
	    break;
        }
    }

    return true; 
}

req_num_t anchor_implementation::generate_req_num()
{
    return m_top_req_num++;  
}

void anchor_implementation::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void anchor_implementation::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool anchor_implementation::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if(it == m_req_info_map.end())
    {
        return false;
    }

    call_id = it->second;
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
