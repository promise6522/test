/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_access.h"
#include "ac_time_observer.h"
#include "ac_object/obj_impl_string.h"
#include "run_error_type_t.h"

bool ac_access::initialization()
{
    assert(m_ptrHelper);

    time_t tm;    
    time(&tm);
    req_num_t req_num = req_num_t(tm, true);

    object_ids input;
    input.ids.push_back(static_cast<nb_id_t>(m_id));

    m_ptrHelper->ac_object_db_read(++req_num, input);

    return true;
}

bool ac_access::initialization(const content& data)
{
    assert(m_ptrHelper);

    //set data by impl
    m_ptrImpl.reset(new(std::nothrow) access_implementation(m_id, data));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_access::get_value_async(call_id_t call_id)
{    
    std::string val("ac_access implement pointer initialization failed");
    //assert(m_ptrImpl && m_ptrHelper);
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    content value;
    if (!m_ptrImpl->get_value(value))
        return false;

    return m_ptrHelper->ac_access_get_value_async_respond(call_id, value); 
}

bool ac_access::get_value_sync(content& output)
{
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(output);
}

bool ac_access::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_access::run(call_id_t call_id, const node_invocation_request& input)
{ 
    //assert(m_ptrImpl);

    std::string val("ac_access implement pointer initialization failed");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    return m_ptrImpl->run(call_id, input, m_ptrHelper.get());
}

bool ac_access::ac_transaction_begin_response(req_num_t req_num)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_access initialization failed");

    return m_ptrImpl->ac_transaction_begin_response(req_num);
}

bool ac_access::ac_execution_start_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("*** ac_access::ac_execution_start_response, req_num="<<req_num<<", success="<<output.success);

    req_info_t req_info;

    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_access initialization failed");

    if (!m_ptrImpl->get_call_info(req_num, req_info))
    {
        LOG_ERROR("Logic failed : could not get call infomation");
        return false;
    }

    if(!output.output.storages.empty() || !output.output.anchors.empty())
    {
        output.corpse_type = CORPSE_INVALID_OUTPUT;
        return m_ptrHelper->ac_access_run_respond(req_info.call_id, output);
    }

    LOG_CRIT("@@@@@@@@@@ access run end : " << ac_time_observer::Instance()->print_current_time());

    if (!output.success)
    {
        m_result = output;

        node_invocation_request request;
        request.transaction_id = req_info.input.transaction_id;
        request.host_committer_id = req_info.input.host_committer_id;
        request.execution_id = req_info.input.execution_id;
        request.declaration_id = nb_id_t(NB_FUNC_CORPSE_PRINT);

        return m_ptrHelper->ac_object_run(output.output.corpse, req_num, request);
    }
    else
    {
        m_ptrImpl->end_call_info(req_num);
        assert(m_ptrHelper);
        return m_ptrHelper->ac_access_run_respond(req_info.call_id, output);
    }
}

bool ac_access::ac_object_run_response(req_num_t req_num, node_invocation_response& output)
{
    if (output.success)
        return m_ptrHelper->ac_object_get_value_async(output.output.objects[0], req_num);

    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_access initialization failed");

    req_info_t req_info;
    if (!m_ptrImpl->get_call_info(req_num, req_info))
    {
        LOG_ERROR("Logic failed : could not get call_id");
        return false;
    }
    m_ptrImpl->end_call_info(req_num);
    return m_ptrHelper->ac_access_run_respond(req_info.call_id, m_result);
}

bool ac_access::ac_object_get_value_async_response(req_num_t req_num, content& output)
{
    // print the corpse
    std::string strval;
    nb_id_t strid;
    obj_impl_string::unpack(output, strid, strval);
    LOG_WARNING("\n===================== corpse output =====================");
    LOG_WARNING(strval);
    LOG_WARNING("=========================================================\n");

    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_access initialization failed");

    req_info_t req_info;
    if (!m_ptrImpl->get_call_info(req_num, req_info))
    {
        LOG_ERROR("Logic failed : could not get call infomation");
        return false;
    }
    m_ptrImpl->end_call_info(req_num);
    return m_ptrHelper->ac_access_run_respond(req_info.call_id, m_result);
}

bool ac_access::ac_object_db_read_response(req_num_t req_num, db_value& output)
{
    assert(m_ptrHelper);

    //set data by impl
    if(0 == output.all_objects.size())
    {
        LOG_ERROR("ac_access::  ac_actor initializaiton failed");
        m_ptrHelper->initialization_respond_fail();
        return false;
    }
    m_ptrImpl.reset(new(std::nothrow) access_implementation(m_id, output.all_objects[0]));    

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_access::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
