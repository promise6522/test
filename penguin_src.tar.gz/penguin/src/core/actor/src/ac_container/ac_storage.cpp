/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_storage.h"
#include "ac_facade/storage_db_base.h"

bool ac_storage::initialization()
{
	assert(m_ptrHelper);
	time_t tm;    
	time(&tm);
	req_num_t req_num = req_num_t(tm, true);

	storage_ids input;
	input.ids.push_back(m_id);

    // reopen the storage db
    m_ptrDb.reset(new(std::nothrow) storage_db_base(ac_storage_env_impl::instance().get_env(), m_id.str()));
	m_ptrHelper->ac_object_db_read_storages(++req_num, input);

	return true;
}

bool ac_storage::initialization(const content& data)
{
    assert(m_ptrHelper);

    // create the storage db by roger
    m_ptrDb.reset(new(std::nothrow) storage_db_base(ac_storage_env_impl::instance().get_env(), m_id.str()));
   
    m_is_wrote = false; 
    m_version = 0; 
    //set data by impl
    m_ptrImpl.reset(new(std::nothrow) storage_implementation(m_id, data, m_ptrHelper.get()));
    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_storage::get_value_sync(content& output)
{
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(output);    
}

bool ac_storage::get_value_async(call_id_t call_id)
{    
    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_storage initialization");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    content value;
    if(!m_ptrImpl->get_value(value))
	    assert(true);

    return m_ptrHelper->ac_storage_get_value_async_respond(call_id, value); 
}

bool ac_storage::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_storage::ac_object_db_read_storages_response(req_num_t req_num, db_value& output)
{
    assert(m_ptrHelper);
    //assert (0 < output.all_objects.size());
    if(0 == output.all_objects.size())
    {
        LOG_ERROR("ac_storage intialization failed");
        m_ptrHelper->initialization_respond_fail();
        return false;
    }

    m_is_wrote = false; 
    m_version = 0; 
    m_ptrImpl.reset(new(std::nothrow) storage_implementation(m_id, output.all_objects[0], m_ptrHelper.get()));
    m_ptrHelper->initialization_respond();
    return true;
}

bool ac_storage::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}

// ========== add by roger
bool ac_storage::get_range(call_id_t call_id, const key_pair_version& input)
{
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;
 
    key_pair iparam;
    iparam.start_num = input.start_num;
    iparam.end_num = input.end_num;

    DbTxn* txn = NULL;
    get_facade_txn(input.fid, txn);
    m_ptrDb->get_range(iparam, id_pair, txn);

    key_pair_no_version1 output;
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        key_obj_id tmp;
        tmp.key_id.str(const_iter->first.str());
        tmp.obj_id.str(const_iter->second.str());
        output.key_obj_ids.push_back(tmp);
    }

    return m_ptrHelper->ac_storage_get_range_respond(call_id, output);
}
    
bool ac_storage::commit(call_id_t call_id, const storage_version& input)
{
    DbTxn* txn = NULL;
    bool ret = false;
    get_facade_txn(input.fid, txn);
    
    if (txn != NULL)
    {
        //update
        std::vector<nb_id_t> d_o_keys, s_o_keys;    
        std::vector<std::pair<nb_id_t, nb_id_t> > r_o_map;
        ret = m_ptrDb->update(m_d_i_key, m_s_map, m_r_map, d_o_keys, s_o_keys, r_o_map, input.version, txn);
        if (ret)
        {
            //commit
            ret = m_ptrDb->commit(txn);
            if (ret)
            {
                LOG_NOTICE("ac_storage("<< m_id.str() <<")::commit success. version:" << input.version);
                m_version++;
            }
            else
            {
                LOG_ERROR("ac_storage("<< m_id.str() <<")::commit failed. version:" << input.version);
            }
        }
        else
        {
            LOG_ERROR("ac_storage("<< m_id.str() <<")::update failed. version:" << input.version);
        }

        end_incoming_txn(input.fid);
    }
    else
    {
        LOG_ERROR("ac_storage("<< m_id.str() <<")::commit failed without txn. version:" << input.version);
    }

    //clear the mem
    m_s_map.clear();
    m_r_map.clear();
    m_d_i_key.clear();
    m_is_wrote = false;
    return m_ptrHelper->ac_storage_commit_respond(call_id, ret);
}

bool ac_storage::size(call_id_t call_id, const storage_version& input)
{
    DbTxn* txn = NULL;
    get_facade_txn(input.fid, txn);

    int count(0);
    count = m_ptrDb->size(txn);
    duke_integer output;
    output.integer = count;
    return m_ptrHelper->ac_storage_size_respond(call_id, output); 
}
    
bool ac_storage::rollback(call_id_t call_id, const storage_version& input)
{
    DbTxn* txn = NULL;
    bool ret = false;
    get_facade_txn(input.fid, txn);
    if(txn != NULL)
    {
        ret = m_ptrDb->rollback(txn);
        if (!ret)
        {
            LOG_NOTICE("ac_storage::rollback fail. version:" << input.version);
        }

        end_incoming_txn(input.fid);
    }
    else
    {
        LOG_ERROR("ac_storage("<< m_id.str() <<")::rollback failed without txn. version:" << input.version);
    }
    
    m_s_map.clear();
    m_r_map.clear();
    m_d_i_key.clear();
    m_is_wrote = false;
    return m_ptrHelper->ac_storage_rollback_respond(call_id, ret);
}
    
bool ac_storage::has_key(call_id_t call_id, const key_array_version& input)
{
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;

    DbTxn* txn = NULL;
    get_facade_txn(input.fid, txn);
    m_ptrDb->has_key(input.keys, id_pair, txn);

    key_array output;
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        output.keys.push_back(const_iter->first);
    }
    return m_ptrHelper->ac_storage_has_key_respond(call_id, output);
}
    
bool ac_storage::update(call_id_t call_id, const sv_update_input_version& input)
{ 
    struct sv_update_output output;
    if (input.version < 0)
        return m_ptrHelper->ac_storage_update_respond(call_id, output);

    if ((m_version != input.version) || m_is_wrote)
        return m_ptrHelper->ac_storage_update_respond(call_id, output);

    DbTxn* txn = NULL;
    get_facade_txn(input.fid, txn);
    if(!txn)
    {
        return m_ptrHelper->ac_storage_update_respond(call_id, output);
    }

    //set write flag, olny give one facade write permition.
    m_is_wrote = true;
    
    //clear the mem
    m_s_map.clear();
    m_r_map.clear();
    m_d_i_key.clear();
    
    std::vector<key_obj_id>::const_iterator const_it;
    std::vector<nb_id_t>::const_iterator const_iter;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator r_it;

    //for replace key: input = (key, value)), output = (key, old_value)
    nb_id_vector r_keys;
    for (const_it = input.sv_r_update_input.begin(); const_it != input.sv_r_update_input.end(); ++const_it)
    {
        m_r_map.push_back(std::make_pair(const_it->key_id, const_it->obj_id));
        r_keys.push_back(const_it->key_id);
    }
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    bool ret = m_ptrDb->get(r_keys, id_pair, txn);
    if(!ret)
    {
        LOG_ERROR("ac_storage("<< m_id.str() <<")::get_replace_keys failed. version:" << input.version);
        return m_ptrHelper->ac_storage_update_respond(call_id, output);
    }
    for (r_it = id_pair.begin(); r_it != id_pair.end(); ++r_it)
    {
        struct key_obj_id keyobj;
        keyobj.key_id = r_it->first;
        keyobj.obj_id = r_it->second;
        output.sv_r_update_output.push_back(keyobj);
    }

    //for delete key: input = key, output = key
    for (const_iter = input.sv_d_update_input.keys.begin(); const_iter != input.sv_d_update_input.keys.end(); ++const_iter)
    {
        m_d_i_key.push_back(*const_iter);
    }
    output.sv_d_update_output.keys = m_d_i_key;

    //for set key: input = (key, value), output = key
    for (const_it = input.sv_s_update_input.begin(); const_it != input.sv_s_update_input.end(); ++const_it)
    {
        LOG_NOTICE("################storage key:" << const_it->key_id.str() << ":" << const_it->obj_id.str());
        m_s_map.push_back(std::make_pair(const_it->key_id, const_it->obj_id));
        output.sv_s_update_output.keys.push_back(const_it->key_id);
    }

    
    
    return m_ptrHelper->ac_storage_update_respond(call_id, output);
}

bool ac_storage::get_version(call_id_t call_id, const facade_id_t& fid)
{
    unsigned int version = this->m_version;

    DbTxn* txn;
    m_ptrDb->get()->txn_snapshot_begin(txn);
    
    this->begin_incoming_txn(fid, txn);
    return m_ptrHelper->ac_storage_get_version_respond(call_id, version);
}

bool ac_storage::read(call_id_t call_id, const key_array_version& input)
{
    key_pair_no_version1 output;
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;

    DbTxn* txn = NULL;
    get_facade_txn(input.fid, txn);
    bool ret = m_ptrDb->get(input.keys, id_pair, txn);
    
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        struct key_obj_id keyobj;
        keyobj.key_id = const_iter->first;
        keyobj.obj_id = const_iter->second;
        output.key_obj_ids.push_back(keyobj);
        LOG_DEBUG("facade key-id:" << const_iter->first.str() << " obj-id:" << const_iter->second.str());
    }
    if (ret)
        return m_ptrHelper->ac_storage_read_respond(call_id, output);
    else
    {
        key_pair_no_version1 output;
        return m_ptrHelper->ac_storage_read_respond(call_id, output);
    }
}

// -============= control version funcs ================-
//
void ac_storage::begin_incoming_txn(const facade_id_t& fid, DbTxn* txn)
{
    if (m_facade_txn_map.find(fid) != m_facade_txn_map.end())
    {
        LOG_ERROR("facade has already exist in map.");
        assert(true);
    }
    m_facade_txn_map.insert(std::make_pair(fid, txn));

    for (facade_txn_map_const_it it = m_facade_txn_map.begin(); it != m_facade_txn_map.end(); ++it)
    {
        LOG_NOTICE("Storage id = " << m_id.str() << "########:first:" << it->first.str() << " ######:second:" << it->second);
    }
}

void ac_storage::end_incoming_txn(const facade_id_t& fid)
{
    LOG_NOTICE("Storage id = " << m_id.str() << "Erase ########:first:" << fid.str());
    m_facade_txn_map.erase(fid);
}

bool ac_storage::get_facade_txn(const facade_id_t& fid, DbTxn*& txn)
{
    facade_txn_map_const_it it = m_facade_txn_map.find(fid);
    if (it == m_facade_txn_map.end())
        return false;

    txn = it->second;
    return true;
}

bool ac_storage::destruction()
{
    for (facade_txn_map_it it = m_facade_txn_map.begin(); it != m_facade_txn_map.end(); ++it)
    {
        m_ptrDb->rollback(it->second);
    }
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
