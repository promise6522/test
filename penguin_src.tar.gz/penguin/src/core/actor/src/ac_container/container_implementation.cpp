/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "stdx_json.h"
#include "ac_container/container_implementation.h"

container_implementation::container_implementation()
{
    time_t tm;    
    time(&tm);    
    m_top_req_num = tm;
}

container_implementation::container_implementation(const container_id_t& cont_id, const con_content& data)
{
    time_t tm;
    time(&tm); 
    m_top_req_num = tm;
    unpack(data);
}

container_implementation::~container_implementation()
{
}

bool container_implementation::get_value(con_content& data)
{ 
    pack(data);
    return true; 
}

bool container_implementation::set_value(const con_content& data)
{ 
    return true; 
}

bool container_implementation::pack(con_content& raw_data)
{ 
    pack(m_cData, m_id, raw_data);
    return true; 
}

bool container_implementation::pack(const container_data_t& logic_data, const container_id_t& id, con_content& raw_data)
{
    container_data_packer packer;

    packer.pack(logic_data.name);
    int anchor_size = logic_data.anchors.size();
    packer.pack(anchor_size);
    for(int i=0; i < anchor_size; ++i)
    {
        packer.pack(logic_data.anchors[i].str());
    }
    int storages_size = logic_data.storages.size();
    packer.pack(storages_size);
    for(int i=0; i < storages_size; ++ i)
    {
        packer.pack(logic_data.storages[i].str());
    }
    packer.pack(logic_data.definition.str());

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.container_id = id;
    return true;
}

bool container_implementation::unpack(const con_content& raw_data, container_id_t& id, container_data_t& logic_data)
{
    id = raw_data.container_id;
    //assert(raw_data.id_value.values.size());
    container_data_unpacker unpack(raw_data);
    //container_data_unpacker unpack(raw_data.id_value);

    int str_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);
    int anchor_size = unpack.unpack_int(++str_index);
    for(int i=0; i < anchor_size; ++i)
    {
        logic_data.anchors.push_back( anchor_id_t( unpack.unpack_string(++str_index) ) );
    }
    int storages_size = unpack.unpack_int(++str_index);
    for(int i=0; i < storages_size; ++i)
    {
        logic_data.storages.push_back( storage_id_t( unpack.unpack_string(++str_index) ) );
    }
    logic_data.definition.str(unpack.unpack_string(++str_index));
    return true;
}

bool container_implementation::unpack(const con_content& raw_data)
{ 
    unpack(raw_data, m_id, m_cData);
    return true; 
}

bool container_implementation::json_pack(const container_data_t& logic_data, const container_id_t& id, con_content& raw_data)
{ 
    /*struct container_data_t
    {
        std::string name;
        std::vector<anchor_id_t> anchors;
        std::vector<storage_id_t> storages;
        nb_id_t definition;
    };*/    
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());

    pObj->insert("name", new stdx::json_string(logic_data.name));
    pObj->insert("definition", new stdx::json_string(logic_data.definition.str()));

    // pack vector<anchor_id_t> anchors
    stdx::json_array* jarr_anchor = new stdx::json_array();
    for(std::vector<anchor_id_t>::const_iterator it = logic_data.anchors.begin(); 
        it != logic_data.anchors.end(); 
        ++it)
    {
        stdx::json_string* item = new stdx::json_string(it->str());
        jarr_anchor->push_back(item);
    }
    pObj->insert("anchors", jarr_anchor);

    // pack vector<storage_id_t> storages
    stdx::json_array* jarr_storage = new stdx::json_array();
    for(std::vector<storage_id_t>::const_iterator it = logic_data.storages.begin(); 
        it != logic_data.storages.end(); 
        ++it)
    {
        stdx::json_string* item = new stdx::json_string(it->str());
        jarr_storage->push_back(item);
    }
    pObj->insert("storages", jarr_storage);

    std::string strval = pObj->to_json_string();

    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);
    raw_data.container_id = id;

    return true; 
}

bool container_implementation::json_unpack(const con_content& raw_data, container_id_t& id, container_data_t& logic_data)
{ 
    id = raw_data.container_id;

    if (raw_data.id_value.values.empty())
        return true; 

    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    stdx::json_node* item;
    item = pObj->find("name");
    logic_data.name = item->get_string();
    item = pObj->find("definition");
    logic_data.definition.str(item->get_string());

    // unpack anchors 
    item = pObj->find("anchors");
    stdx::json_array* jarr_anchor = dynamic_cast<stdx::json_array*>(item);
    assert(jarr_anchor);
    for(int i = 0; i < jarr_anchor->size(); ++i )
    {
        anchor_id_t sub_item;
        sub_item.str(jarr_anchor->at(i)->get_string());
        logic_data.anchors.push_back(sub_item);
    }

    // unpack storages 
    item = pObj->find("storages");
    stdx::json_array* jarr_storage = dynamic_cast<stdx::json_array*>(item);
    assert(jarr_storage);
    for(int i = 0; i < jarr_storage->size(); ++i )
    {
        storage_id_t sub_item;
        sub_item.str(jarr_storage->at(i)->get_string());
        logic_data.storages.push_back(sub_item);
    }

    return true; 
}

bool container_implementation::get_definition(nb_id_t& output)
{
    output = m_cData.definition;
    return false; 
}

bool container_implementation::get_anchors(anchor_ids& output)
{
    output.ids = m_cData.anchors;
    return false; 
}

bool container_implementation::get_storages(storage_ids& output)
{
    output.ids = m_cData.storages;
    return false; 
}

bool container_implementation::get_anchor(const int& input, anchor_id_t& output)
{
    LOG_DEBUG("*** container_implementation::get_anchor()");

    size_t uint_idx = input;

    if (m_cData.anchors.size() > uint_idx && 0 <= uint_idx)
    {
        output = m_cData.anchors[uint_idx];
        return true;
    }

    return false; 
}

bool container_implementation::get_storage(const int& input, storage_id_t& output)
{
    LOG_DEBUG("*** container_implementation::get_storage()");

    size_t uint_idx = input;

    if (m_cData.storages.size() > uint_idx && 0 <= uint_idx)
    {
        output = m_cData.storages[uint_idx];
        return true;
    }

    return false; 
}

bool container_implementation::get_storage_type(const int& input, nb_id_t& output)
{
    size_t uint_idx = input;

    if (m_cData.storages.size() > uint_idx && 0 <= uint_idx)
    {
        output = m_cData.storages[uint_idx].get_type();
        return true;
    }

    return false; 
}

bool container_implementation::info_store_singleton_object(const nb_id_t& obj_id)
{
    return true; 
}

req_num_t container_implementation::generate_req_num()
{
    return m_top_req_num++;  
}

void container_implementation::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void container_implementation::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool container_implementation::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if (it == m_req_info_map.end())
        return false;

    call_id = it->second;
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
