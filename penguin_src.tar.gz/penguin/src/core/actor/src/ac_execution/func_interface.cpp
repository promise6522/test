/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution/func_interface.h"

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_object/obj_impl_interface.h"

func_interface::func_interface(nb_id_t& obj_id, 
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{
} 

func_interface::~func_interface()
{
} 

bool func_interface::get_name(nb_id_t& out)
{
    nb_builtin_interface_t if_type = m_obj_id.get_interface_type();
    switch (if_type)
    {
        case NB_INTERFACE_NONE:
            return request_string_object("none interface", out);
        case NB_INTERFACE_BOOL:
            return request_string_object("bool interface", out);
        case NB_INTERFACE_INT:
            return request_string_object("int interface", out);
        case NB_INTERFACE_FLOAT:
            return request_string_object("float interface", out);
        case NB_INTERFACE_STRING:
            return request_string_object("string interface", out);
        case NB_INTERFACE_BYTES:
            return request_string_object("bytes interface", out);
        case NB_INTERFACE_INTERVAL:
            return request_string_object("interval interface", out);
        case NB_INTERFACE_TIME:
            return request_string_object("time interface", out);
        case NB_INTERFACE_ARRAY:
            return request_string_object("array interface", out);
        case NB_INTERFACE_MAP:
            return request_string_object("map interface", out);
        case NB_INTERFACE_CONTAINER_DEF:
            return request_string_object("container definition interface", out);
        case NB_INTERFACE_DESCRIPTOR:
            return request_string_object("descriptor interface", out);
        case NB_INTERFACE_EXEC_IMPLEMENTATION:
            return request_string_object("implement interface", out);
        case NB_INTERFACE_EXEC_CONDITION:
            return request_string_object("condition interface", out);
        case NB_INTERFACE_EXEC_ITERATOR:
            return request_string_object("iterator interface", out);
        case NB_INTERFACE_BRIDGE:
            return request_string_object("bridge interface", out);
        case NB_INTERFACE_CORPSE:
            return request_string_object("corpse interface", out);
        case NB_INTERFACE_DECLARATION:
            return request_string_object("declaration interface", out);
        case NB_INTERFACE_STORAGE_SIMPLE:
            return request_string_object("storage interface", out);
        case NB_INTERFACE_CONTAINER:
            return request_string_object("container interface", out);
        case NB_INTERFACE_ROOT_ACCESS:
            return request_string_object("root access interface", out);
        case NB_INTERFACE_TIME_LINE:
            return request_string_object("time line interface", out);

        case NB_INTERFACE_INTERFACE:
        case NB_INTERFACE_INTERFACE_BRIDGE:
        default:
            return request_string_object("interface", out);
    }

    return false;
}


bool func_interface::do_get_declarations(nb_id_t& decls_array_id)
{
    nb_id_vector vdecls;
    obj_impl_interface::get_builtin_instructions(m_obj_id, true, vdecls);

    return generate_array(vdecls, NB_INTERFACE_DECLARATION, decls_array_id);
}

bool func_interface::do_get_declarations_name(nb_id_t& names_array_id)
{
    // get string vector
    std::vector<std::string> names;
    obj_impl_interface::get_interface_declarations_name(m_obj_id, names);

    // convert string vector to id vector
    nb_id_vector vnames;
    std::vector<std::string>::const_iterator it;
    for( it = names.begin(); it != names.end(); ++it)
    {
        nb_id_t name_id;
        request_string_object(*it, name_id);
        vnames.push_back(name_id);
    }

    return generate_array(vnames, NB_INTERFACE_STRING, names_array_id);
}

bool func_interface::do_equal(const nb_id_t& obj_if, nb_id_vector& out)
{
    //assert(obj_if.is_interface());
    if(!obj_if.is_interface())
        return false;

    bool eq = (m_obj_id == obj_if || m_obj_id.is_interface_none() || obj_if.is_interface_none()) ? true : false;
    
    out.push_back(eq);
    LOG_NOTICE("*** func_interface::eq = "<<std::boolalpha<<eq);

    return true;
}

bool func_interface::do_cover(const nb_id_t& obj_if, nb_id_vector& out)
{
    //assert(obj_if.is_interface());
    if(!obj_if.is_interface())
        return false;

    bool cover = false;
    if (obj_if.is_interface_none() || m_obj_id.is_interface_none())
        cover = true;
    else
        cover = (m_obj_id == obj_if);
    
    out.push_back(cover);
    LOG_NOTICE("*** func_interface::cover = "<<std::boolalpha<<cover);

    return true;
}

bool func_interface::do_convert(const nb_id_t& obj, nb_id_t& out)
{
    nb_id_t objIf;
    bool success = false;

    /* only when obj is builtin-obj 
       and can get builtin-interface */
    if(obj.get_builtin_interface(objIf))
    {
        if(m_obj_id == objIf)
            success = true;
    }

    /* if can convert, we pass the obj out
       otherwise we return a none-obj */
    out = success ? obj : NBID_TYPE_OBJECT_NONE;

    LOG_NOTICE("*** func_interface::convert() = "<<std::boolalpha<<success);    

    return true;
}

bool func_interface::run()
{ 
    LOG_DEBUG("*** func_interface::run()");

    bool ret = true;
    node_invocation_response response;
    response.success = false;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INTERFACE_GET_DECLARATIONS:
        {
            nb_id_t decls_array_id;
            ret = do_get_declarations(decls_array_id);
            response.output.objects.push_back(decls_array_id);
            break;
        }
        case NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME:
        {
            nb_id_t names_array_id;
            ret = do_get_declarations_name(names_array_id);
            response.output.objects.push_back(names_array_id);
            break;
        }
        case NB_FUNC_INTERFACE_EQ:
        {
            //assert(m_param.input.size() == 1);
            if(m_param.input.size() != 1)
            {
                 return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }

            ret = do_equal(m_param.input[0], response.output.objects);
            break;
        }
        case NB_FUNC_INTERFACE_COVERS:
        {
            //assert(m_param.input.size() == 1);
            if(m_param.input.size() != 1)
            {
                 return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = do_cover(m_param.input[0], response.output.objects);
            break;
        }
        case NB_FUNC_INTERFACE_CONVERT:
        {
            //assert(m_param.input.size() == 1);
            if(m_param.input.size() != 1)
            {
                 return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            //assert(m_param.input[0].is_object());
            if(!m_param.input[0].is_object())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
            }

            nb_id_t out;
            ret = do_convert(m_param.input[0], out);

            response.output.objects.push_back(out);
            break;
        }
        default:
        {
            return execution_base::run();
            break;
        }
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
