/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include<boost/regex.hpp>
#include "ac_execution_helper.h"
#include "ac_execution/func_string.h"
#include<string.h>
#include "boost/crc.hpp"

const uint64_t duker_time = 946684800;

func_string::func_string(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_object_string());
    nb_id_t id;   
	obj_impl_string::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

func_string::~func_string()
{
}

bool func_string::get_name(nb_id_t& out)
{
	return request_string_object("string", out); 
}

bool func_string::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_string::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_string::compare(const nb_id_t& in)
{
    LOG_DEBUG("*** func_string::compare()");

    //assert(in.is_object_string());
    if (!in.is_object_string())
        return false;
	
    // get string content 
    req_num_t req = generate_req_num();
    begin_incoming_ins_call(req, NB_FUNC_GENERAL_COMPARE);
    return object_get_value_async(in, req); 
}

bool func_string::find(const nb_id_t& in)
{
    LOG_DEBUG("*** func_string::find()");
    //assert(in.is_object_string());
    if(!in.is_object_string())
        return false;
    
    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_STR_FIND);
    return object_get_value_async(in, req_num);
}

bool func_string::append(const nb_id_t& in)
{   
    LOG_DEBUG("*** func_string::append()");

    //assert(in.is_object_string());
    if (!in.is_object_string())
        return false;
	
    // get string content 
    req_num_t req = generate_req_num();
    begin_incoming_ins_call(req, NB_FUNC_STR_APPEND);
    return object_get_value_async(in, req);
}

// in1: first index of the substr
// in2: *last index of the substr:
bool func_string::substr(const nb_id_t& in1, const nb_id_t& in2, nb_id_t& out)
{
    LOG_DEBUG("*** func_string::substr()");

	int nFirst,nLast,nLength;
	std::string strOut;

    if(!in1.is_object_integer()
            || !in2.is_object_integer())
        return false;

	in1.get_value(nFirst);
	in2.get_value(nLast);
	nLength = nLast - nFirst;//may it should be (nLast-nFirst+1)
	strOut = m_cData.substr(nFirst, nLength);
        
	LOG_NOTICE("########## The result of string substr: " << strOut); 

	request_nb_id_info nb_info;
	nb_info.committer_id = m_param.host_committer_id;
	nb_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(strOut, nb_id_t(), nb_info.raw_data);

	if (!request_nb_id(m_param.host_committer_id, 
		    nb_info,
		    out))
	    return false;

	return true;
}


bool func_string::size(nb_id_t& out)
{
    LOG_DEBUG("*** func_string::size()");

	int nLength = m_cData.length();

	LOG_NOTICE("########## The result of string size: " << nLength);
	
	out.set_type(NBID_TYPE_OBJECT_INT);
	out.set_value(nLength);

	return true;
}

// in: pos
// char at the pos is divided to the 2nd string 
bool func_string::split_at(const nb_id_t& in, nb_id_vector& vout)
{
    LOG_DEBUG("*** func_string::split_at()");

	int nPos;
	std::string strOut1,strOut2;

    if (!in.is_object_integer())
        return false;

	in.get_value(nPos);
	strOut1 = m_cData.substr(0, nPos);
	strOut2 = m_cData.substr(nPos);
	
	LOG_NOTICE("########## The result of string split_at: first: " << strOut1 << " second: " << strOut2);

    nb_id_t out1;
    request_nb_id_info nb_info1;
    nb_info1.committer_id = m_param.host_committer_id;
    nb_info1.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(strOut1, nb_id_t(), nb_info1.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info1,
                out1))
	    return false;
	vout.push_back(out1);

    nb_id_t out2;
    request_nb_id_info nb_info2;
    nb_info2.committer_id = m_param.host_committer_id;
    nb_info2.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(strOut2, nb_id_t(), nb_info2.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info2,
                out2))
        return false;

	vout.push_back(out2);

	return true;
}
bool func_string::IsDigit(std::string& strval)
{
    int count = 0;
    for(size_t i = 0; i < strval.size(); i++)
    {
        if(strval.at(0) == '.')
            return false;
        else if(strval.at(i) == '.')
        {
            count++;
            if(count > 1)
                return false;
        }
    }
    for(size_t j = 0; j < strval.size(); j++)
    {
        if(strval.at(0) == 0x2D)
            continue;
        else if(strval.at(j) == '.')
            continue;
        else if((strval.at(j) > '9') || (strval.at(j) < '0'))
           return false;
    }
    return true;
}
bool func_string::to_int(nb_id_t& in, nb_id_t& out)
{
    bool ret = false;
    ret = IsDigit(m_cData);
    if(ret)
    { 
        try
        {
            int value = boost::lexical_cast<int>(m_cData);

            out = nb_id_t(NBID_TYPE_OBJECT_INT);
            out.set_value(value);
            ret = true;
        }
        catch(boost::bad_lexical_cast& e)
        {
            ret = false;
        }
    }
    return ret;
}

bool func_string::to_float(nb_id_t& in, nb_id_t& out)
{
    bool ret = false;
    ret = IsDigit(m_cData);
    if(ret)
    {
        try
        {
            float f1 = boost::lexical_cast<float>(m_cData);

            out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
            out.set_value(f1);
            ret = true;
        }
        catch (boost::bad_lexical_cast& e)
        {
            ret = false;
        }
    }
    return ret;
}

bool func_string::to_bool(nb_id_t& in, nb_id_t& out)
{
    std::transform(m_cData.begin(), m_cData.end(),
            m_cData.begin(), tolower);

    bool value = false;
    if (m_cData == "yes" || m_cData == "y" || m_cData == "true" || m_cData == "t")
        value = true;

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value);
    return true;
}

bool func_string::convert(std::string& strval, time_data_t& time_data)
{
    try
    {
        struct tm tm1;
        std::string str1;
        int pos = 0;
        if(strval.at(0) == 0x2D || strval.at(0) == 0x2B)
        {
            ++pos;
        }
        /*else if(strval.at(0) == 0x2B)
        {
            ++pos;
        }*/

        str1 = strval.substr(0, 4 + pos);
        tm1.tm_year = boost::lexical_cast<int>(str1); 
        str1 = strval.substr(pos + 4, 2);
        tm1.tm_mon = boost::lexical_cast<int>(str1);
        str1 = strval.substr(pos + 6, 2);
        tm1.tm_mday = boost::lexical_cast<int>(str1);
        str1 = strval.substr(pos + 8, 2);
        tm1.tm_hour = boost::lexical_cast<int>(str1);
        str1 = strval.substr(pos + 10, 2);
        tm1.tm_min = boost::lexical_cast<int>(str1);
        str1 = strval.substr(pos + 12, 2);
        tm1.tm_sec = boost::lexical_cast<int>(str1);

        if(tm1.tm_mon < 1 || tm1.tm_mon > 12 || tm1.tm_mday < 1 || tm1.tm_mday > 31 ||
               tm1.tm_hour < 0 || tm1.tm_hour > 23 || tm1.tm_min < 0 || tm1.tm_min > 59 || 
               tm1.tm_sec < 0 || tm1.tm_sec > 59)
           return false; 

        
        tm1.tm_year -= 1900;
        tm1.tm_mon -= 1;
        tm1.tm_hour += 8;

        str1 = strval.substr(pos + 15, strval.size() - pos - 15);

        time_t ts = mktime(&tm1);
        LOG_DEBUG("covert second: "<<ts);
        time_data.second_cnt = ts;

        time_data.second_cnt -= duker_time;

        time_data.pico_second_cnt = boost::lexical_cast<uint64_t>(str1);
    }
    catch(boost::bad_lexical_cast& e)
    {
        return false;
    }
    return true;
}

bool func_string::to_time(nb_id_t& in, nb_id_t& out)
{
    //assert(in.is_object_time());
    if(!in.is_object_time())
        return false;

    time_data_t time_data;
    
    
    convert(m_cData, time_data);

    out = nb_id_t(NBID_TYPE_OBJECT_TIME);
    out.set_value(time_data.second_cnt, time_data.pico_second_cnt);
    return true;
}

bool func_string::to_interval(nb_id_t& in, nb_id_t& out)
{
    //assert(in.is_object_interval());
    if(!in.is_object_interval())
        return false;

    try
    {
        time_data_t time_data;
        std::string str1;
        std::string::iterator it = m_cData.begin();
        int pos = 0;
        for(; it != m_cData.end(); ++it)
        {
            if(*it == '.')
                break;
            ++pos;
        }
        str1 = m_cData.substr(0, pos);
        time_data.second_cnt = boost::lexical_cast<uint64_t>(str1);
        str1 = m_cData.substr(pos + 1, m_cData.size() - pos -1);
        time_data.pico_second_cnt = boost::lexical_cast<uint64_t>(str1);

        out = nb_id_t(NBID_TYPE_OBJECT_INTERVAL);
        out.set_value(time_data.second_cnt, time_data.pico_second_cnt);
    }
    catch(boost::bad_lexical_cast& e)
    {
        return false;
    }
    return true;
}

bool func_string::to_bytes(nb_id_t& out)
{
    LOG_DEBUG("*** func_string::to_bytes");

    bytes_data_t data;
    data.value = m_cData;
    data.length = m_cData.size();

    boost::crc_optimal<16, 0x1021, 0xFFFF, 0, false, false>  crc_ccitt;
    crc_ccitt = std::for_each(m_cData.begin(), m_cData.end(), crc_ccitt);
    data.crc = crc_ccitt();

    request_nb_id_info  nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(data, nb_id_t(), nb_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, nb_info, out))
        return false;

    return true;
}

bool func_string::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_string::get_value_response");

    // retrieve the std::string value
    std::string strval;
    nb_id_t strid;
    obj_impl_string::unpack(output, strid, strval);

    node_invocation_response response;
    response.child_transaction = m_param.transaction_id;

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_string::get_value_response() failed");

        response.success = false; 
        return run_respond(response);
    }

    if (NB_FUNC_GENERAL_RUN == builtin_ins)
            return execution_base::get_value_response(req_num, output);

    end_incoming_ins_call(req_num) ;

    switch (builtin_ins)
    {
        case NB_FUNC_GENERAL_COMPARE:
            return compare_response(strval);
            break;
        case NB_FUNC_STR_APPEND:
            return append_response(strval);
            break;
        case NB_FUNC_STR_FIND:
            return find_response(strval);
        default:
            return false;
    }

    return false; 
}


bool func_string::compare_response(std::string& strval)
{	
    LOG_DEBUG("*** func_string::compare_response()");

    node_invocation_response response;
    nb_id_t out;
	out.set_type(NBID_TYPE_OBJECT_BOOL);
    std::size_t cResult =  m_cData.compare(strval);
	if( cResult > 0)
    {
	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(true);
        response.output.objects.push_back(out);
    }
    else if(cResult < 0 )
    {
	    out.set_value(true);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);
    }
    else
    {
	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(true);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);
    }


    response.success = true;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_string::append_response(std::string& strval)
{    
    LOG_DEBUG("*** func_string::append_response()");

	std::string strOut = m_cData + strval;
    LOG_NOTICE("##########  The result of string append: " << strOut);
        
	request_nb_id_info nb_info;
	nb_info.committer_id = m_param.host_committer_id;
	nb_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(strOut, nb_id_t(), nb_info.raw_data);

    nb_id_t out;
	request_nb_id(m_param.host_committer_id, nb_info, out);

    node_invocation_response response;
    response.output.objects.push_back(out);
    response.success = true;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_string::find_response(std::string& strval)
{
    LOG_DEBUG("*** func_string::find_response()");

    size_t pos;
    pos = m_cData.find(strval);

    nb_id_t out;
    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(pos);

    node_invocation_response response;
    response.output.objects.push_back(out);
    response.success = true;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_string::generate_compare(const nb_id_t& input)
{
    if(input.is_object_string())
    {
        return compare(input);//async
    }
    return execution_base::run();
}
//TODO
//bool func_string::verify

bool func_string::run()
{
    LOG_DEBUG("*** func_string::run() ");

	bool ret = true;
	node_invocation_response response;
    nb_id_t result;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_GENERAL_COMPARE:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            return generate_compare(m_param.input[0]);
        }
        case NB_FUNC_STR_APPEND:
        {
            //assert(1 == m_param.input.size());
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            return append(m_param.input[0]);//async
        }
        //case NB_FUNC_STR_COMPARE:
        //{
        //    //assert(1 == m_param.input.size());
        //    if(m_param.input.size() != 1)
        //    {
        //        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
        //    }
        //    return compare(m_param.input[0]);//async
        //}
        case NB_FUNC_STR_SUBSTR:
        {
            //assert(2 == m_param.input.size());
            if(m_param.input.size() != 2)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            nb_id_t result;
            ret = substr(m_param.input[0], m_param.input[1], result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_STR_FIND:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            return find(m_param.input[0]);
        }
        case NB_FUNC_STR_SIZE:
        {
            nb_id_t result;
            ret = size(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_STR_SPLITAT:
        {
            //assert(1 == m_param.input.size());
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = split_at(m_param.input[0], response.output.objects);
            break;
        }
        case NB_FUNC_STR_TO_INT:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }

            if (to_int(m_param.input[0], result))
            {
                response.output.objects.push_back(result);
            }
            else
            {
                response.output.objects.push_back(m_param.input[0]);
            }
            break;
        }
        case NB_FUNC_STR_TO_FLOAT:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            if(to_float(m_param.input[0], result))
            {
                response.output.objects.push_back(result);
            }
            else
            {
                response.output.objects.push_back(m_param.input[0]);
            }
            break;
        }
        case NB_FUNC_STR_TO_BOOL:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = to_bool(m_param.input[0], result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_STR_TO_INTERVAL:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = to_interval(m_param.input[0], result);
            if(!ret)
            {
                response.output.objects.push_back(m_param.input[0]);
            }
            else
            {
                response.output.objects.push_back(result);
            }
            break;
        }
        case NB_FUNC_STR_TO_TIME:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = to_time(m_param.input[0], result);
            if(!ret)
            {
                response.output.objects.push_back(m_param.input[0]);
            }
            else
            {
                response.output.objects.push_back(result);
            }
            break;
        }
        case NB_FUNC_STR_TO_BYTES:
        {
            ret = to_bytes(result);

            if (ret)
                response.output.objects.push_back(result);
            else
                return run_exception_respond(m_param.transaction_id);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    response.success = ret;
	response.child_transaction = m_param.transaction_id;
	return run_respond(response);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
