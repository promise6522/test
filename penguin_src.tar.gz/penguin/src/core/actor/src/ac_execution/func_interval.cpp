/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_interval.h"

bool func_interval::get_name(nb_id_t& out)
{
	return request_string_object("interval", out); 
}

bool func_interval::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_interval::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_interval::get(nb_id_t& out1, nb_id_t& out2)
{
    //assert(out.empty());

    time_data_t        my_time;
    func_time::get_general_time(m_obj_id, my_time);
    //func_time::get_detail_time(my_time, out);

    out1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out1.set_value(my_time.second_cnt, 0);
    out2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out2.set_value(my_time.pico_second_cnt, 0);

    return true;
}

bool func_interval::add(const nb_id_t& in1, nb_id_t& out)
{
    //assert(in1.is_object_interval());
    if(!in1.is_object_interval())
        return false;

    time_data_t  value1, value2, result;

    func_time::get_general_time(m_obj_id, value1);
    func_time::get_general_time(in1, value2);
    func_time::time_add(value1, value2, result);

    out = nb_id_t(NBID_TYPE_OBJECT_INTERVAL);
    func_time::set_general_time(out, result);

    return true;
}

bool func_interval::sub(const nb_id_t& in1, nb_id_t& out)
{
    //assert(in1.is_object_interval());
    if(!in1.is_object_interval())
        return false;

    time_data_t  value1, value2, result;

    func_time::get_general_time(m_obj_id, value1);
    func_time::get_general_time(in1, value2);
    func_time::time_sub(value1, value2, result);

    out = nb_id_t(NBID_TYPE_OBJECT_INTERVAL);
    func_time::set_general_time(out, result);

    return true;
}

/*bool func_interval::mul(const nb_id_t& in1, nb_id_t& out)
{
    return true;
}

bool func_interval::div(const nb_id_t& in1, nb_id_t& out)
{
    return true;
}*/

bool func_interval::to_string(nb_id_t& out)
{
    time_data_t time_data;
    func_time::get_general_time(m_obj_id, time_data);

    std::string strval, str1;
    str1 = boost::lexical_cast<std::string>(time_data.second_cnt);
    strval.append(str1);
    strval.append(".");
    str1 = boost::lexical_cast<std::string>(time_data.pico_second_cnt);
    strval.append(str1);

    return request_string_object(strval, out);
}

bool func_interval::run()
{
    LOG_DEBUG("*** func_interval::run() ");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INTERVAL_GET:
        {
            nb_id_t result1, result2;
            ret = get(result1, result2);
            //assert(10 == result.size());
            response.output.objects.push_back(result1);
            response.output.objects.push_back(result2);

            /* For Debug */
            /*std::vector<int> result_value;
            int tmp_value;
            std::vector<nb_id_t>::iterator it = result.begin();
            for (; it != result.end(); ++it)
            {
                (*it).get_value(tmp_value);
                result_value.push_back(tmp_value);
            }*/
            int value1, value2;
            result1.get_value(value1);
            result2.get_value(value2);

            LOG_NOTICE("######## The result of interval get: ");
            LOG_NOTICE("pico_second_cnt  :  " << value1);
            LOG_NOTICE("second_cnt       :  " << value2);
            /*LOG_NOTICE("Year    :  " << result_value[0]);
            LOG_NOTICE("Month   :  " << result_value[1]);
            LOG_NOTICE("Day     :  " << result_value[2]);
            LOG_NOTICE("Hour    :  " << result_value[3]);
            LOG_NOTICE("Minute  :  " << result_value[4]);
            LOG_NOTICE("Second  :  " << result_value[5]);
            LOG_NOTICE("ms      :  " << result_value[6]);
            LOG_NOTICE("us      :  " << result_value[7]);
            LOG_NOTICE("ns      :  " << result_value[8]);
            LOG_NOTICE("ps      :  " << result_value[9]);*/

            break;
        }
        case NB_FUNC_INTERVAL_ADD:
        {
            nb_id_t result;
            ret = add(m_param.input[0], result);
            response.output.objects.push_back(result);

            /* For Debug */
            time_data_t value;
            func_time::get_general_time(result, value);
            LOG_NOTICE("######## The result of interval add: ");
            LOG_NOTICE("pico_second_cnt  :  " << value.pico_second_cnt);
            LOG_NOTICE("second_cnt       :  " << value.second_cnt);

            break;
        }
        case NB_FUNC_INTERVAL_SUB:
        {
            nb_id_t result;
            ret = sub(m_param.input[0], result);
            response.output.objects.push_back(result);

            /* For Debug */
            time_data_t value;
            func_time::get_general_time(result, value);
            LOG_NOTICE("######## The result of interval sub: ");
            LOG_NOTICE("pico_second_cnt  :  " << value.pico_second_cnt);
            LOG_NOTICE("second_cnt       :  " << value.second_cnt);

            break;
        }
        /*case NB_FUNC_INTERVAL_MUL:
        {
            nb_id_t result;
            ret = mul(m_param.input[0], result);
            response.output.objects.push_back(result);

            break;
        }
        case NB_FUNC_INTERVAL_DIV:
        {
            nb_id_t result;
            ret = div(m_param.input[0], result);
            response.output.objects.push_back(result);

            break;
        }*/
        case NB_FUNC_INTERVAL_TO_STRING:
        {
            nb_id_t result;
            ret = to_string(result);
            response.output.objects.push_back(result);
            break;
        }
        default:
            return execution_base::run();
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
