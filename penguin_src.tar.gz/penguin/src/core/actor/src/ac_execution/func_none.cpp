/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_none.h"

bool func_none::get_name(nb_id_t& out)
{
	return request_string_object("none", out); 
}

bool func_none::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_none::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_none::run()
{
    LOG_DEBUG("*** func_none::run()"); 

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
    	default:
    	    return execution_base::run();
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
