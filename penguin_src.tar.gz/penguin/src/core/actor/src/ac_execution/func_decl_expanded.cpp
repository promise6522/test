/**************************************************************************
**
**  Copyright 2011 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_decl_expanded.h"

#include "ac_object/obj_constant_def.h"
#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface_compound.h"

func_decl_expanded::func_decl_expanded(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_decl_expanded());

    nb_id_t id;
    obj_impl_decl_expanded::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
}

func_decl_expanded::~func_decl_expanded()
{
}

bool func_decl_expanded::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool func_decl_expanded::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_decl_expanded::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_DECLARATION);
    return true;
}

bool func_decl_expanded::get_decl_id(nb_id_t& id)
{
    id = m_cData.origin_decl_id;
    return true;
}

bool func_decl_expanded::get_all_ports_async()
{
    /* currently this func is implemented sync */
    LOG_DEBUG("**func_decl_expanded::get_interfaces");

    /*
    node_invocation_request request = m_param;
    request.input.clear();
    request.declaration_id = NB_FUNC_DECLARATION_GET_IN_PORTS;

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_GET_IN_PORTS);
    return object_run(m_cData.origin_decl_id, req_num, request);
    */
    nb_id_vector viifs, voifs;
    get_expanded_decl_interfaces(m_cData, viifs, voifs);

    // return two arrays
    nb_id_t arr1, arr2;
    generate_array(viifs, NB_INTERFACE_INTERFACE, arr1);
    generate_array(voifs, NB_INTERFACE_INTERFACE, arr2);

    node_invocation_response response;
    response.success = true;
    response.child_transaction = m_param.transaction_id;
    response.output.objects.push_back(arr1);
    response.output.objects.push_back(arr2);
    return run_respond(response);
}

bool func_decl_expanded::get_in_ports_async()
{
    /* currently this func is implemented sync */
    LOG_DEBUG("**func_decl_expanded::get_in_ports");

    /*
    node_invocation_request request = m_param;
    request.input.clear();
    request.declaration_id = NB_FUNC_DECLARATION_GET_IN_PORTS;

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_GET_IN_PORTS);
    return object_run(m_cData.origin_decl_id, req_num, request);
    */
    nb_id_vector viifs, voifs;
    get_expanded_decl_interfaces(m_cData, viifs, voifs);

    // return an array of interfaces
    nb_id_t out;
    generate_array(viifs, NB_INTERFACE_INTERFACE, out);

    node_invocation_response response;
    response.success = true;
    response.child_transaction = m_param.transaction_id;
    response.output.objects.push_back(out);
    return run_respond(response);
}

bool func_decl_expanded::get_out_ports_async()
{
    /* currently this func is implemented sync */
    LOG_DEBUG("**func_decl_expanded::get_out_ports");

    /*
    node_invocation_request request = m_param;
    request.input.clear();
    request.declaration_id = NB_FUNC_DECLARATION_GET_OUT_PORTS;

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_GET_OUT_PORTS);
    return object_run(m_cData.origin_decl_id, req_num, request);
    */
    nb_id_vector viifs, voifs;
    get_expanded_decl_interfaces(m_cData, viifs, voifs);

    // return an array of interfaces
    nb_id_t out;
    generate_array(voifs, NB_INTERFACE_INTERFACE, out);

    node_invocation_response response;
    response.success = true;
    response.child_transaction = m_param.transaction_id;
    response.output.objects.push_back(out);
    return run_respond(response);
}

bool func_decl_expanded::get_expanded_ifs(nb_id_t& out)
{
    LOG_DEBUG("**func_decl_expanded::get_expanded_ifs");
    // return an  array id
    return generate_array(m_cData.expanded_ifs, NB_INTERFACE_INTERFACE, out);
}

bool func_decl_expanded::get_port_number(bool input)
{
    LOG_DEBUG("**func_decl_expanded::get_port_number");

    if (m_cData.origin_decl_id.is_function_declare())
    {
        //built-in decl, get the port num SYNC
        decl_compound_data_t decl_data;
        nb_const::get_builtin_decl_compound(m_cData.origin_decl_id, decl_data);

        nb_id_t port_num(NBID_TYPE_OBJECT_INT);
        if (input) 
        {
            port_num.set_value(decl_data.iports.size());
            LOG_NOTICE("**func_decl_expanded::get_iport_num = "<<port_num.str());
        }
        else 
        {
            port_num.set_value(decl_data.oports.size());
            LOG_NOTICE("**func_decl_expanded::get_oport_num = "<<port_num.str());
        }

        node_invocation_response response;
        response.success = true;
        response.child_transaction = m_param.transaction_id;
        response.output.objects.push_back(port_num);
        return run_respond(response);
    }

    // origin decl is compound, try to get the port num async 
    nb_builtin_instruction_t ins;
    if (input)
        ins = NB_FUNC_DECLARATION_GET_IN_PORT_NUM;
    else
        ins = NB_FUNC_DECLARATION_GET_OUT_PORT_NUM;

    node_invocation_request request = m_param;
    request.input.clear();
    request.declaration_id = ins;

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, ins);
    return object_run(m_cData.origin_decl_id, req_num, request);
}

bool func_decl_expanded::run()
{ 
    LOG_DEBUG("$$$$$$$$$$$$$$$$ expanded declaration run() ="<< m_cData.name);

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_INTERFACES:
            return get_all_ports_async();
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
            return get_in_ports_async();
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
            return get_out_ports_async();

        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
            return get_port_number(true);
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
            return get_port_number(false);

        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_ORIGIN_DECL");

            nb_id_t result;
            ret = get_decl_id(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES");
            nb_id_t result;
            ret = get_expanded_ifs(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_GENERAL_COMPARE://decl_expanded is VALUE_COMPARED!
        {
            LOG_DEBUG("NB_FUNC_GENERAL_COMPARE");

            // if input not type of decl_expanded, 
            // using the default id-compare logic
            if (!m_param.input[0].is_object_decl_expanded())
                return execution_base::run();
                
            req_num_t req_num = generate_req_num();
            return object_get_value_async(m_param.input[0], req_num);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_decl_expanded::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_decl_expanded::get_value_response()");

    // check result for general run
    nb_builtin_instruction_t builtin_ins;
    if (get_ins_call(req_num, builtin_ins))
    {
        end_incoming_ins_call(req_num);
        switch (builtin_ins)
        {
            case NB_FUNC_GENERAL_RUN:
                return execution_base::get_value_response(req_num, output);
            default:
                break;
        }
    }

    //LOG_ERROR("func_interface_compound::get_value_response() failed"); 
    //return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

    nb_id_t id;
    decl_expanded_data_t in_decl_data;
    obj_impl_decl_expanded::unpack(output, id, in_decl_data);

    if (m_cData.origin_decl_id < in_decl_data.origin_decl_id)
        return compare_respond(-1);
    if (m_cData.origin_decl_id > in_decl_data.origin_decl_id)
        return compare_respond(1);

    // origin_decl_id equals, check the expanded_ifs

    // check the size first
    if (m_cData.expanded_ifs.size() < in_decl_data.expanded_ifs.size())
        return compare_respond(-1);
    if (m_cData.expanded_ifs.size() > in_decl_data.expanded_ifs.size())
        return compare_respond(1);

    // size equals, check the un_expanded ifs
    for (std::size_t i = 0; i < m_cData.expanded_ifs.size(); ++i)
    {
        bool self_expanded = !m_cData.expanded_ifs[i].is_type_null();
        bool in_expanded = !in_decl_data.expanded_ifs[i].is_type_null();
        // both not expanded
        if ((!self_expanded) && (!in_expanded))
            continue;

        // only one expanded
        if (self_expanded && !in_expanded)
            return compare_respond(1);
        if (in_expanded && !self_expanded)
            return compare_respond(-1);

        // both expanded
        m_expanded_ifs.push_back(m_cData.expanded_ifs[i]);
        m_in_expanded_ifs.push_back(in_decl_data.expanded_ifs[i]);
    }

    // both are unexpanded (all of the expanded_ifs are type_null)
    // compare result is equal
    if (m_expanded_ifs.size() == 0)
        return compare_respond(0);

    // check if the remain interfaces match each other
    m_expanded_if_idx = 0;
    node_invocation_request request = m_param;
    request.input.clear();
    request.input.push_back(m_in_expanded_ifs[0]);
    request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_EQ);

    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_EQ);
    object_run(m_expanded_ifs[0], req_num, request);

    return true; 
}

bool func_decl_expanded::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("*** func_decl_expanded::obj_run_response()");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_decl_expanded::obj_run_response() failed"); 
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    end_incoming_ins_call(req_num);

    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            return execution_base::obj_run_response(req_num, output);
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
        {
            //TODO
            return run_respond(output);
        }
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
        {
            //assert(output.output.objects.size() == 1);
            if(output.output.objects.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }
            //assert(output.output.objects[0].is_object_integer());
            if(!output.output.objects[0].is_object_integer())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            LOG_NOTICE("**func_decl_expanded::get_iport_num = "<<output.output.objects[0].str());
            return run_respond(output);
        } 
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
        {
            //assert(output.output.objects.size() == 1);
            if(output.output.objects.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }
            //assert(output.output.objects[0].is_object_integer());
            if(!output.output.objects[0].is_object_integer())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }
            LOG_NOTICE("**func_decl_expanded::get_oport_num = "<<output.output.objects[0].str());
            return run_respond(output);
        } 
        case NB_FUNC_INTERFACE_EQ:
        {
            // NB_FUNC_INTERFACE_EQ must return a bool as result
            if (1 != output.output.objects.size() || !output.output.objects[0].is_object_bool())
                return run_exception_respond(m_param.transaction_id);

            bool match;
            output.output.objects[0].get_value(match);

            if (!match)
            {
                //not matched, we compare the ids instead
                if (m_expanded_ifs[m_expanded_if_idx] < m_in_expanded_ifs[m_expanded_if_idx])
                    return compare_respond(-1);
                if (m_expanded_ifs[m_expanded_if_idx] > m_in_expanded_ifs[m_expanded_if_idx])
                    return compare_respond(1);
                if (m_expanded_ifs[m_expanded_if_idx] == m_in_expanded_ifs[m_expanded_if_idx])
                    //they shouldn't equals with each other
                    assert(!"The result of FUNC_INTERFACE_EQ is wrong!");

            }

            // current two ifs match, check the remaining
            m_expanded_if_idx++;
            if (m_expanded_if_idx == m_expanded_ifs.size())
                //all match, compare returns equal
                return compare_respond(0);

            node_invocation_request request = m_param;
            request.input.clear();
            request.input.push_back(m_in_expanded_ifs[m_expanded_if_idx]);
            request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_EQ);

            begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_EQ);
            return object_run(m_expanded_ifs[m_expanded_if_idx], req_num, request);
            break;
        }
        default:
            LOG_ERROR("func_decl_expanded::invalid async flow");
    }

    return true;
}

bool func_decl_expanded::compare_respond(int result)
{
    bool less_than = (result < 0);
    bool equals = (result == 0);
    bool greater_than = (result > 0);

    node_invocation_response response;
    response.success = true;
    response.output.objects.push_back(less_than);
    response.output.objects.push_back(equals);
    response.output.objects.push_back(greater_than);
    response.child_transaction = m_param.transaction_id;

    return run_respond(response);
}

bool func_decl_expanded::generate_expanded_if(const nb_id_t& origin_if, 
    const nb_id_vector& expanded_ifs, 
    nb_id_t& new_if_id)
{
    // this SYNC method only supports expansion of builtin interface
    //assert(origin_if.is_builtin_interface());
    if(!origin_if.is_builtin_interface())
    {
        return run_exception_respond(m_param.transaction_id, CORPSE_DECL_EXPANDED_GENERATE_INTERFACE_FAILED);
    }

    if_compound_data_t if_comp_data;
    obj_impl_interface::get_interface_name(origin_if, if_comp_data.name);//SYNC

    for(size_t i=0; i < expanded_ifs.size(); ++i)
    {
        if_exp_group g;
        if (expanded_ifs[i].is_type_null())
            g.expanded = false;
        else {
            g.min_if = expanded_ifs[i];
            g.expanded = true;
        }

        if_comp_data.groups.push_back(g);
    }
    LOG_DEBUG("**generate_expanded_if::group size = "<<if_comp_data.groups.size());


    /* 2.2 if_compound.expanded_decls */
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
    decl_info.committer_id = m_param.host_committer_id;

    decl_expanded_data_t decl_data;
    decl_data.expanded_ifs = expanded_ifs;

    // get origin decls
    nb_id_vector origin_decls;
    obj_impl_interface::get_builtin_instructions(origin_if, false, origin_decls);//SYNC

    // request ids for expanded_decls 
    for (size_t i = 0; i < origin_decls.size(); ++i)
    {
        nb_id_t decl_id;
        obj_impl_declaration::get_instruction_name(origin_decls[i], decl_data.name);//SYNC
        decl_data.origin_decl_id = origin_decls[i];
        obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
        request_nb_id(m_param.host_committer_id, decl_info, decl_id);

        if_comp_data.decls.push_back(decl_id);
    }
    // fill in general decls
    obj_impl_interface::get_general_instructions(if_comp_data.decls);

    // request id for if_compund
    request_nb_id_info ifc_info;
    ifc_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    ifc_info.committer_id = m_param.host_committer_id;
    obj_impl_interface_compound::pack(if_comp_data, nb_id_t(), ifc_info.raw_data);
    
    return request_nb_id(m_param.host_committer_id, ifc_info, new_if_id);
}


bool func_decl_expanded::get_expanded_decl_interfaces(const decl_expanded_data_t& decl_expanded_data, 
        nb_id_vector& viifs, nb_id_vector& voifs)
{
    // TODO(xlj)
    // just now, we assume the origin_decl_id is built-in
    // so we can process it SYNC
    nb_id_t origin_decl_id = decl_expanded_data.origin_decl_id;
    nb_id_vector expanded_ifs = decl_expanded_data.expanded_ifs;

    //assert(origin_decl_id.is_function_declare());
    if(!origin_decl_id.is_function_declare())
    {
        return run_exception_respond(m_param.transaction_id, CORPSE_DECL_EXPANDED_GET_EXPANDED_DECL_INTERFACE_FAILED);
    }

    //1. get decl_compoud data structure 
    decl_compound_data_t data;
    nb_const::get_builtin_decl_compound(origin_decl_id, data);


    //2. update group[i].min_if fields 
    //assert(expanded_ifs.size() == data.groups.size());

    for(std::size_t i  = 0; i < data.groups.size(); ++i)
    {
        //#maybe type null, no assert here
        //assert(expanded_ifs[i].is_interface());
        data.groups[i].min_if = expanded_ifs[i];
    }

    //3. analyze the ports groups info
    // generate the { port <-----> [min_ifs] } mapping
    typedef std::pair<bool,int> PortIndex;
    typedef std::map< PortIndex, nb_id_vector > PortGroupInfo;
    PortGroupInfo port_info;

    for(std::size_t i = 0; i < data.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < data.groups[i].members.size(); ++j)
        {
            bool is_input = data.groups[i].members[j].is_input;
            int port_idx = data.groups[i].members[j].port_idx;
            int relay_idx = data.groups[i].members[j].relay_idx;

            if(relay_idx >= 0)
            {
                PortIndex port = std::make_pair(is_input, port_idx);
                PortGroupInfo::iterator it = port_info.find(port);

                if(it != port_info.end())
                {
                    // relay_idx is from 0 to N
                    if (it->second.size() < (size_t)relay_idx+1)
                    {
                        it->second.resize(relay_idx+1, NBID_TYPE_NULL);
                    }
                    it->second[relay_idx] = data.groups[i].min_if;
                }
                else
                {
                    nb_id_vector vifs;
                    vifs.resize(relay_idx+1, NBID_TYPE_NULL);
                    vifs[relay_idx] = data.groups[i].min_if;
                    port_info.insert(std::make_pair(port, vifs));
                }
            }
        }
    }

    //4. fill the input & output ports
    // { origin_if_id, [exp_ifs] } <====> expanded_if_id mapping
    typedef std::pair<nb_id_t, nb_id_vector> ExpandedIfPrototype;
    typedef std::map<ExpandedIfPrototype, nb_id_t> ExpandedIfTable;
    typedef ExpandedIfTable::iterator ExpandedIfTableIt;
    typedef std::map<PortIndex, bool> PortIfTable;//is the port expanded yet?
    PortIfTable port_table;
    ExpandedIfTable if_table;

    for( std::size_t i = 0; i < data.groups.size(); ++i)
    {
        for(std::size_t j = 0; j < data.groups[i].members.size(); ++j)
        {
            bool is_input = data.groups[i].members[j].is_input;
            int port_idx = data.groups[i].members[j].port_idx;
            int relay_idx = data.groups[i].members[j].relay_idx;

            if (port_table.find(std::make_pair(is_input, port_idx)) != port_table.end())
                //already expanded, ignore
                continue;

            if( -1 == relay_idx) 
            {
                // expand the port itself
                if(is_input)
                    data.iports[port_idx].interface = data.groups[i].min_if;
                else
                    data.oports[port_idx].interface = data.groups[i].min_if;
            }
            else//realy_idx > 0
            {
                ExpandedIfPrototype exp_if_info;
                nb_id_vector port_exp_ifs = port_info[std::make_pair(is_input, port_idx)];

                nb_id_t origin_if_id;// unexpanded interface id
                nb_id_t new_if_id;// expanded interface id 
                if (is_input)
                    origin_if_id = data.iports[port_idx].interface;
                else
                    origin_if_id = data.oports[port_idx].interface;

                exp_if_info = std::make_pair(origin_if_id, port_exp_ifs);

                ExpandedIfTableIt it;
                it = if_table.find(exp_if_info);
                if (it != if_table.end())
                {
                    //already expanded, using it directly! 
                    new_if_id = it->second;
                }
                else
                {
                    // generate the expanded interface id
                    generate_expanded_if(origin_if_id, expanded_ifs, new_if_id);
                    // TODO DB persistence?
                    // insert to the table for later use
                    if_table.insert(std::make_pair(exp_if_info, new_if_id));
                }
                
                // replace the interface id on ports
                if (is_input)
                    data.iports[port_idx].interface = new_if_id;
                else
                    data.oports[port_idx].interface = new_if_id;
            }

            // mark the port expanded
            port_table[std::make_pair(is_input, port_idx)] = true;
        }
    }

    LOG_DEBUG("##func_decl_expanded::get_in_ports");
    for(size_t i=0; i < data.iports.size(); ++i)
    {
        LOG_DEBUG("iport["<<i<<"] = "<<data.iports[i].interface.str());
        viifs.push_back(data.iports[i].interface);
    }

    LOG_DEBUG("##func_decl_expanded::get_out_ports");
    for(size_t i=0; i < data.oports.size(); ++i)
    {
        LOG_DEBUG("oport["<<i<<"] = "<<data.oports[i].interface.str());
        voifs.push_back(data.oports[i].interface);
    }

    return true;
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
