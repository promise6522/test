/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_container_def.h"
#include "ac_container/container_implementation.h"
#include "ac_container/access_implementation.h"
#include "ac_container/anchor_implementation.h"
#include "ac_container/storage_implementation.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_array.h"
#include "ac_execution/func_array.h"


func_container_def::func_container_def()
{
}

func_container_def::func_container_def(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_container_defination());
    nb_id_t id;
    obj_impl_container_def::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
}

func_container_def::~func_container_def()
{
}

bool func_container_def::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out);
}

bool func_container_def::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_container_def::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_CONTAINER_DEF);
    return true;
}

bool func_container_def::get_cont_information(cont_def_data_t& cont_info)
{
    return true;
}

bool func_container_def::get_storage_type(const nb_id_t idx, nb_id_t storage_type)
{
    //int index;
    //idx.get_value(index);
    //size_t uint_idx = index;

    //if (m_cData.storages.size() <= uint_idx || 0 > uint_idx)
    //    return false;  
   
    //request_nb_id_info nb_info;
    //nb_info.committer_id = m_param.host_committer_id;
    //nb_info.type = NBID_TYPE_OBJECT_INT;
    //if (request_nb_id(m_param.host_committer_id, nb_info, storage_type))
    //    storage_type.set_value(m_cData.storages[uint_idx]);

    return true;
}

bool func_container_def::create_container()
{
    LOG_DEBUG("func_container_def::create_container()");

    container_data_t container_data;
    if_compound_data_t raccess_if;

    container_data.name = m_cData.name;

    // create anchors
    for (std::vector<anchor_info_t>::iterator it = m_cData.anchors.begin();
        it != m_cData.anchors.end();
        ++it)
    {
        request_anchor_id_info anchor_info;

        // package
        anchor_data_t anchor_data;
        anchor_data.funcs = it->funcs;
        anchor_data.interface = it->interface;
        anchor_data.name = it->name;
        anchor_data.registed = it->registed;

        // create anchor 
        anchor_implementation::pack(anchor_data, anchor_info.raw_data);

        // req anchor id
        anchor_id_t anchor_id;
        if (!m_pHelper->ac_host_committer_request_anchor_id(m_param.host_committer_id, 
                    anchor_info,
                    anchor_id))
            return run_exception_respond(m_param.transaction_id);

        // save
        container_data.anchors.push_back(anchor_id);
    }

    // create storages
    for (std::vector<storage_info_t>::iterator it = m_cData.storages.begin();
        it != m_cData.storages.end();
        ++it)
    {
        request_storage_id_info st_info;

        // req anchor id
        storage_id_t storage_id;
        storage_data_t st_data;
        st_data.name = it->name; 
        st_data.interface = it->interface;

        // create storage 
        storage_implementation::pack(st_data, st_info.raw_data);
        st_info.type = it->type; 
        if (!m_pHelper->ac_host_committer_request_storage_id(m_param.host_committer_id, 
                    st_info, 
                    storage_id))
            return run_exception_respond(m_param.transaction_id);

        // save
        container_data.storages.push_back(storage_id);
    }

    container_data.definition = m_obj_id;

    // create container 
    request_container_id_info container_info;
    container_implementation container_impl;

    container_impl.pack(container_data, container_id_t(), container_info.raw_data);
    container_info.committer_id = m_param.host_committer_id;
    container_id_t container_id;
    if (!m_pHelper->ac_host_committer_request_container_id(m_param.host_committer_id, 
                container_info,
                container_id))
        return run_exception_respond(m_param.transaction_id);

    // create root access interface
    //raccess_if.name = "root access interface";
    //request_nb_id_info ra_if_info;
    //nb_id_t if_id;
    //ra_if_info.committer_id = m_param.host_committer_id;
    //ra_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    //obj_impl_interface_compound::pack(raccess_if, nb_id_t(), ra_if_info.raw_data);

    //if (!m_pHelper->ac_host_committer_request_nb_id(m_param.host_committer_id, 
    //            ra_if_info,
    //            if_id))
    //    return run_exception_respond(m_param.transaction_id);

    // create root access
    access_data_t access_data;
    access_data.interface = nb_id_t(NB_INTERFACE_ROOT_ACCESS);
    access_data.parent_container = container_id;
    access_data.anchor_idx = 0;
    // root access is registed for ever 
    access_data.is_registed = true;
    access_data.is_outgoing = false;

    request_access_id_info access_info;
    access_info.committer_id = m_param.host_committer_id;
    access_info.type = NBID_TYPE_OBJECT_ACCESS;
    access_implementation::pack(access_data, access_info.raw_data);

    access_id_t root_access;

    if (!m_pHelper->ac_host_committer_request_access_id(m_param.host_committer_id, 
                access_info,
                root_access))
        return run_exception_respond(m_param.transaction_id);

    node_invocation_response response;
    nb_id_t raccess(root_access.str());
    response.output.objects.push_back(raccess);
    response.success = true; 
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_container_def::run()
{
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ container defination run() = "<< m_cData.name);

    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            response.success = get_name(result);
            response.output.objects.push_back(result);
        	response.child_transaction = m_param.transaction_id;
        	return run_respond(response);
        }
        case NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER:
            {
                //assert(1 == m_param.input.size());
                return create_container();

                break;
            }
        case NB_FUNC_CONTAINER_DEF_GET_ANCHOR_INTERFACE:
            {
                //assert( 1 == m_param.input.size());
                if(1 != m_param.input.size())
                {
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }

                int index;
                m_param.input[0].get_value(index);
                response.success = true;
                response.child_transaction = m_param.transaction_id;
                response.output.objects.push_back(m_cData.anchors[index].interface);
                return run_respond(response);
                break;
            }
        default:
            {
                // for builtin ins
                if (m_param.declaration_id.is_instruction_general())
                    return execution_base::run();
            }
    }
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
