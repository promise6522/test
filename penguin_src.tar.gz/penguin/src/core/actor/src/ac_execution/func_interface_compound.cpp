/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <algorithm>
#include <functional>

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/func_interface_compound.h"
#include "ac_object/obj_algorithm.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_declaration.h"

#define EQ_FLAG 2 

#define UNEXPANDED_FLAG 1 
#define PORT_EXPANDED_FLAG 2 
#define ALL_EXPANDED_FLAG 3 

func_interface_compound::func_interface_compound() 
{
} 

func_interface_compound::func_interface_compound(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_interface_compound());
    
    nb_id_t id;
    obj_impl_interface_compound::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

func_interface_compound::~func_interface_compound()
{
} 

bool func_interface_compound::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_interface_compound::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_interface_compound::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool func_interface_compound::set_builtin_instructions(const nb_id_vector& vins)
{
    m_builtin_ins = vins;
    return true;
}

bool func_interface_compound::get_general_instructions(nb_id_vector& vins)
{
    vins.push_back(NB_FUNC_GENERAL_GET_NAME);//newly-added
    vins.push_back(NB_FUNC_GENERAL_IS_NULL);
    vins.push_back(NB_FUNC_GENERAL_IS_SINGLETON);
    vins.push_back(NB_FUNC_GENERAL_IS_JUSTID);
    vins.push_back(NB_FUNC_GENERAL_IS_BUILTIN);
    vins.push_back(NB_FUNC_GENERAL_IS_EXPORTABLE);
    vins.push_back(NB_FUNC_GENERAL_IS_LOCAL);
    vins.push_back(NB_FUNC_GENERAL_IS_VALUECOMPARED);
    vins.push_back(NB_FUNC_GENERAL_EXCEPTION_IF_NULL);
    vins.push_back(NB_FUNC_GENERAL_COMPARE);
    vins.push_back(NB_FUNC_GENERAL_GET_INTERFACE);//newly-added
    vins.push_back(NB_FUNC_GENERAL_GET_REGISTED_ACCESSES);
    vins.push_back(NB_FUNC_GENERAL_RUN);

    return true;
}

bool func_interface_compound::get_access_instructions(nb_id_vector& vins)
{
    vins.push_back(nb_id_t(NB_FUNC_ACCESS_GET_CONTAINER));
    vins.push_back(nb_id_t(NB_FUNC_ACCESS_GET_ANCHOR));
    vins.push_back(nb_id_t(NB_FUNC_ACCESS_IS_REGISTED));

    return true;
}

bool func_interface_compound::get_user_instructions(nb_id_vector& vins)
{
    vins.push_back(nb_id_t(NB_FUNC_USER_GET_DESCRIPTOR));

    for (size_t i = 0; i < m_builtin_ins.size();++i)
    {
        vins.push_back(m_builtin_ins[i]); 
    }

    return true;
}

bool func_interface_compound::get_builtin_instructions(nb_id_vector& vdecl)
{
    /*
    switch (m_cData.type.get_compound_interface_type())
    {
        case NB_INTERFACE_ACCESS:
            get_access_instructions(vdecl);
            get_general_instructions(vdecl);
            break;
        case NB_INTERFACE_USER:
            get_user_instructions(vdecl);
            get_general_instructions(vdecl);
            break;
        default:
            break;
    }
    */

    return true;
}

bool func_interface_compound::get_general_instructions_name(nb_id_vector& vnames)
{
    nb_id_t func_name;

    request_string_object("get name", func_name);
    vnames.push_back(func_name);
    request_string_object("is null", func_name);
    vnames.push_back(func_name);
    request_string_object("is singleton", func_name);
    vnames.push_back(func_name);
    request_string_object("is just id", func_name);
    vnames.push_back(func_name);
    request_string_object("is builtin", func_name);
    vnames.push_back(func_name);
    request_string_object("is exportable", func_name);
    vnames.push_back(func_name);
    request_string_object("is local", func_name);
    vnames.push_back(func_name);
    request_string_object("is value compared", func_name);
    vnames.push_back(func_name);
    request_string_object("exception if null", func_name);
    vnames.push_back(func_name);
    request_string_object("compare", func_name);
    vnames.push_back(func_name);
    request_string_object("get interface", func_name);
    vnames.push_back(func_name);
    request_string_object("get registed accesses", func_name);
    vnames.push_back(func_name);
    request_string_object("run", func_name);
    vnames.push_back(func_name);

    return true;
}

bool func_interface_compound::get_access_instructions_name(nb_id_vector& vnames)
{
    nb_id_t func_name;
    request_string_object("get container", func_name);
    vnames.push_back(func_name);
    request_string_object("get anchor", func_name);
    vnames.push_back(func_name);
    request_string_object("is registed", func_name);
    vnames.push_back(func_name);

    return true;
}

bool func_interface_compound::get_user_instructions_name(nb_id_vector& vnames)
{
    nb_id_t func_name;
    request_string_object("get descriptor", func_name);
    vnames.push_back(func_name);

    return true;
}

bool func_interface_compound::get_builtin_instruction_names(nb_id_vector& vnames)
{
    switch (m_obj_id.get_interface_type())
    {
        case NB_INTERFACE_ACCESS:
            get_access_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        case NB_INTERFACE_USER:
            get_user_instructions_name(vnames);
            get_general_instructions_name(vnames);
            break;
        default:
            break;
    }
    return true;
}

bool func_interface_compound::is_singleton(nb_id_t& result)
{
    request_nb_id_info nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_BOOL;
    request_nb_id(m_param.host_committer_id, nb_info, result);

    result.set_value(m_cData.is_singleton);
    return true;
}

bool func_interface_compound::get_min_ifs(nb_id_vector& vif)
{
    int size = m_cData.groups.size();

    for (int i = 0; i < size;++i)
    {
        vif.push_back(m_cData.groups[i].min_if);
    }

    return true;
}

bool func_interface_compound::get_declarations(nb_id_t& decls_array_id)
{
    LOG_DEBUG("func_interface_compound::get declarations");
    
    return generate_array(m_cData.decls, NB_INTERFACE_DECLARATION, decls_array_id);
}

bool func_interface_compound::get_declarations_name()
{
    LOG_DEBUG("func_interface_compound::get declarations name");

    for (m_decls_count = 0; m_decls_count < m_cData.decls.size(); ++m_decls_count)
    {
        switch (m_cData.decls[m_decls_count].get_type())
        {
            case NBID_TYPE_OBJECT_DECLARATION:
                {
                    std::string name;
                    obj_impl_declaration::get_instruction_name(m_cData.decls[m_decls_count], name);
                    m_decl_names.push_back(name);
                    continue;
                }
            case NBID_TYPE_FUNCTION_COMPOSE:
            case NBID_TYPE_FUNCTION_DECOMPOSE:
            case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
                {
                    req_num_t req_num = generate_req_num();
                    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_INSTRUCTION);
                    return object_get_value_async(m_cData.decls[m_decls_count], req_num);
                }
            case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
                {
                    req_num_t req_num = generate_req_num();
                    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_INSTRUCTION_END);
                    return object_get_value_async(m_cData.decls[m_decls_count], req_num);
                }
            default:
                {
                    LOG_ERROR("func_interface_compound::object_id is not a decl_id");
                    return run_exception_respond(m_param.transaction_id);
                }
        }
    }

    // convert string vector to id vector
    nb_id_vector vnames;
    std::vector<std::string>::const_iterator it;
    for( it = m_decl_names.begin(); it != m_decl_names.end(); ++it)
    {
        nb_id_t name_id;
        request_string_object(*it, name_id);
        vnames.push_back(name_id);
    }

    nb_id_t names_array_id;
    if (!generate_array(vnames, NB_INTERFACE_STRING, names_array_id))
    {
        LOG_ERROR("request array_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    node_invocation_response output;
    output.success = true;
    output.output.objects.push_back(names_array_id);
    output.child_transaction = m_param.transaction_id;
    return run_respond(output);
}

bool func_interface_compound::get_decls_custom(const nb_id_vector& src, nb_id_vector& dest)
{
    LOG_DEBUG("func_interface_compound::get_decls_custom()");

    for (nb_id_vector_const_it it = src.begin();
            it != src.end();
            ++it)
    {
        if (it->is_object_declaration()
                || it->is_function_compose()
                || it->is_function_decompose()) 
            continue;

        dest.push_back(*it);
    }

    return true;
}

bool func_interface_compound::check_expanded(const std::vector<if_exp_group>& groups, int expanded_flag)
{
    LOG_DEBUG("func_interface_compound::check_expanded()");

    std::size_t expanded_count = 0;

    for (std::vector<if_exp_group>::const_iterator it = groups.begin();
            it != groups.end();
            ++it) 
    {
        if (it->expanded)
        {
            expanded_count++;
        }
    }

    if (expanded_count == 0)
        expanded_flag = UNEXPANDED_FLAG;
    else
    {
        if (expanded_count == groups.size()) 
            expanded_flag = ALL_EXPANDED_FLAG; 
        else
            expanded_flag = PORT_EXPANDED_FLAG;
    }

    return true;
}

bool func_interface_compound::run()
{ 
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ compound interface run() = "<< m_cData.name);

    bool ret = true;
    node_invocation_response output;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            output.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INTERFACE_GET_DECLARATIONS:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_GET_DECLARATIONS");

                nb_id_t decls_array_id;
                ret = get_declarations(decls_array_id);
                output.output.objects.push_back(decls_array_id);
                break;
            }
        case NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME");

                return get_declarations_name();
            }
        case NB_FUNC_INTERFACE_EQ:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_EQ");

                //return return_bool_result(true, m_param.transaction_id);

                if (1 != m_param.input.size())
                    return run_exception_respond(m_param.transaction_id);

                if (m_obj_id == m_param.input[0])
                {
                    return return_bool_result(true, m_param.transaction_id);
                }
                else if (m_param.input[0].is_object_interface_compound())
                {
                    m_eq_count = 0;
                    
                    req_num_t req_num = generate_req_num();    
                    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_COVERS);

                    node_invocation_request cover_req = m_param;
                    cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
                    cover_req.input.clear();
                    cover_req.input.push_back(m_param.input[0]);

                    return object_run(m_obj_id, req_num, cover_req);
                
                }
                else
                {
                    LOG_ERROR("func_interface_compound::run():eq failed:in object invalid");
                    return run_exception_respond(m_param.transaction_id);
                }
                break;
            }
        case NB_FUNC_INTERFACE_COVERS:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_COVERS");

                //return return_bool_result(true, m_param.transaction_id);

                if (1 != m_param.input.size())
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                if (!m_param.input[0].is_interface())
                {
                    LOG_ERROR("func_interface_compound::run(): covers failed : input not interface");
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
                }


                if (m_obj_id == m_param.input[0] || m_param.input[0].is_interface_none())
                {
                    return return_bool_result(true, m_param.transaction_id);
                }
                else if (m_param.input[0].is_object_interface_compound())
                {
                    req_num_t req_num = generate_req_num();    
                    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_COVERS);

                    return object_get_value_async(m_param.input[0], req_num);
                }
                else//m_param.input[0].is_builtin_interface || is_bridge_interface
                {
                    return return_bool_result(false, m_param.transaction_id);
                }

                break;
            }
        case NB_FUNC_INTERFACE_CONVERT:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_CONVERT");
                LOG_NOTICE("input object before convert:"<< m_param.input[0].str());

                if (1 != m_param.input.size())
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

                // convert[step 1]: get input obj's interface async
                req_num_t req_num = generate_req_num();    

                begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_INTERFACE);

                node_invocation_request request = m_param;
                request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);
                return object_run(m_param.input[0], req_num, request);

                break;
            }
        case NB_FUNC_INTERFACE_IS_SINGLETON:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_IS_SINGLETON");

                nb_id_t result;
                ret = is_singleton(result);
                output.output.objects.push_back(result);

                break;
            }
        case NB_FUNC_INTERFACE_GROUPS:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_GROUPS");

                ret = get_min_ifs(output.output.objects);
                break;
            }
        case NB_FUNC_INTERFACE_SET_BUILTIN_INS:
            {
                LOG_DEBUG("decl:NB_FUNC_INTERFACE_SET_BUILTIN_INS");

                ret = set_builtin_instructions(m_param.input);
                break;
            }
        default:
            return execution_base::run();
            break;
    }

    output.success = ret;
    output.child_transaction = m_param.transaction_id;
    return run_respond(output);
}

bool func_interface_compound::eq(const nb_id_vector& decls, const nb_id_vector& in_decls)
{
    LOG_DEBUG("func_interface_compound::eq()");
    bool ret = false;

    if ((0 == decls.size()) && (0 == in_decls.size()))
        ret = true;
    else
        ret = nb_obj::unordered_match(decls.begin(), 
                decls.end(),
                in_decls.begin(), 
                in_decls.end());

    return ret;
}

bool func_interface_compound::cover(const nb_id_vector& decls, const nb_id_vector& in_decls)
{
    LOG_DEBUG("func_interface_compound::cover()");
    bool ret = false;

    if (0 == in_decls.size())
        ret = true;
    else
        ret = nb_obj::unordered_includes(decls.begin(), 
            decls.end(),
            in_decls.begin(), 
            in_decls.end());

    return ret;
}

bool func_interface_compound::convert(const nb_id_vector& decls, const nb_id_vector& in_decls)
{
    LOG_DEBUG("func_interface_compound::convert()");

    node_invocation_response response;
    bool ret = false;

    if (0 == decls.size())
        ret = true;
    else
        ret = nb_obj::unordered_includes(in_decls.begin(), 
                in_decls.end(),
                decls.begin(), 
                decls.end());

    return ret;
}

bool func_interface_compound::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_interface_compound::get_value_response");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {

        LOG_ERROR("func_interface_compound::get_value_response() failed"); 
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    if (NB_FUNC_GENERAL_RUN == builtin_ins)
            return execution_base::get_value_response(req_num, output);
    end_incoming_ins_call(req_num);

    switch (builtin_ins)
    {
        case NB_FUNC_INTERFACE_COVERS:
            {
                LOG_DEBUG("NB_FUNC_INTERFACE_COVERS"); 

                if_compound_data_t data;
                nb_id_t id;
                obj_impl_interface_compound::unpack(output, id, data);

                if (data.decls.size() == 0)
                {
                    LOG_ERROR("func_interface_compound::get_value_response():in decls size = 0"); 
                    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
                }

                m_covered_if.decls.clear();
                for (std::size_t i = 0; i != data.decls.size(); ++i)
                {
                    if (data.decls[i].is_function_compose()
                            || data.decls[i].is_function_decompose())
                        continue;
                    m_covered_if.decls.push_back(data.decls[i]);
                }

                m_covered_if.groups.clear();
                for (std::size_t i = 0; i != data.groups.size(); ++i)
                {
                    if (data.groups[i].min_if.is_type_null())
                        continue;
                    m_covered_if.groups.push_back(data.groups[i]);
                }

                m_covered_idx = 0;
                m_cover_idx = 0;

                node_invocation_request compare_req = m_param;
                compare_req.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
                compare_req.input.clear();
                compare_req.input.push_back(m_cData.decls[0]);

                begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_COMPARE);
                
                return object_run(m_covered_if.decls[0], req_num, compare_req);

                break;
            } 
        case NB_FUNC_INTERFACE_CONVERT:
            {
                LOG_DEBUG("NB_FUNC_INTERFACE_CONVERT"); 

                if_compound_data_t data;
                nb_id_t id;
                obj_impl_interface_compound::unpack(output, id, data);

                nb_id_vector decls_custom;
                nb_id_vector in_decls_custom;

                get_decls_custom(m_cData.decls, decls_custom);
                get_decls_custom(data.decls, in_decls_custom);

                bool ret = convert(decls_custom, in_decls_custom);

                node_invocation_response response;
                if (ret)
                {
                    response.output.objects.push_back(m_param.input[0]);
                }
                else
                {
                    nb_id_t result = nb_id_t(NBID_TYPE_OBJECT_NONE);
                    response.output.objects.push_back(result);
                }

                LOG_NOTICE("input object after convert:"<< response.output.objects[0].str());

                return run_respond(response);
                break;
            }
        case NB_FUNC_DECLARATION_INSTRUCTION:
        case NB_FUNC_DECLARATION_INSTRUCTION_END:
            {
                if (builtin_ins == NB_FUNC_DECLARATION_INSTRUCTION)
                {
                    decl_compound_data_t  data;
                    nb_id_t               id;
                    obj_impl_decl_compound::unpack(output, id, data);
                    m_decl_names.push_back(data.name);
                }
                else
                {
                    decl_expanded_data_t  data;
                    nb_id_t               id;
                    obj_impl_decl_expanded::unpack(output, id, data);
                    m_decl_names.push_back(data.name);
                }

                while (++m_decls_count < m_cData.decls.size())
                {
                    switch (m_cData.decls[m_decls_count].get_type())
                    {
                        case NBID_TYPE_OBJECT_DECLARATION:
                            {
                                std::string name;
                                obj_impl_declaration::get_instruction_name(m_cData.decls[m_decls_count], name);
                                m_decl_names.push_back(name);
                                continue;
                            }
                        case NBID_TYPE_FUNCTION_COMPOSE:
                        case NBID_TYPE_FUNCTION_DECOMPOSE:
                        case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
                            {
                                begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_INSTRUCTION);
                                return object_get_value_async(m_cData.decls[m_decls_count], req_num);
                            }
                        case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
                            {
                                begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_INSTRUCTION_END);
                                return object_get_value_async(m_cData.decls[m_decls_count], req_num);
                            }
                        default:
                            {
                                LOG_ERROR("func_interface_compound::object_id is not a decl_id");
                                return run_exception_respond(m_param.transaction_id);
                            }
                    }
                }
                
                // convert string vector to id vector
                nb_id_vector vnames;
                std::vector<std::string>::const_iterator it;
                for( it = m_decl_names.begin(); it != m_decl_names.end(); ++it)
                {
                    nb_id_t name_id;
                    request_string_object(*it, name_id);
                    vnames.push_back(name_id);
                }

                nb_id_t names_array_id;
                if (!generate_array(vnames, NB_INTERFACE_STRING, names_array_id))
                {
                    LOG_ERROR("request array_id failed");
                    return run_exception_respond(m_param.transaction_id);
                }

                node_invocation_response output;
                output.success = true;
                output.output.objects.push_back(names_array_id);
                output.child_transaction = m_param.transaction_id;
                return run_respond(output);
            }
        default:
            break;
    }

    return true;
}

bool func_interface_compound::obj_run_response(req_num_t req_num, 
    node_invocation_response& output)
{
    LOG_DEBUG("*** func_interface_compound::obj_run_response()");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {

        LOG_ERROR("func_interface_compound::obj_run_response() failed"); 
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    end_incoming_ins_call(req_num);

    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            return execution_base::obj_run_response(req_num, output);
        case NB_FUNC_INTERFACE_CONVERT:
            {
                //convert[step 3]: return none on false, otherwise return the input obj
                LOG_DEBUG("NB_FUNC_INTERFACE_CONVERT");

                if ((1 != output.output.objects.size()) 
                        || !output.output.objects[0].is_object_bool())
                {
                    return run_exception_respond(m_param.transaction_id);
                }

                node_invocation_response response;
                response.success = true;
                response.child_transaction = m_param.transaction_id;

                bool ret;  
                output.output.objects[0].get_value(ret);

                if (ret)
                {
                    response.output.objects.push_back(m_param.input[0]);
                }
                else
                {
                    nb_id_t result = nb_id_t(NBID_TYPE_OBJECT_NONE);
                    response.output.objects.push_back(result);
                }

                return run_respond(response);

            }
        case NB_FUNC_GENERAL_GET_INTERFACE:
            {
                LOG_DEBUG("NB_FUNC_GENERAL_GET_INTERFACE");

                if ((1 != output.output.objects.size()) 
                        || !output.output.objects[0].is_interface())
                {
                    LOG_ERROR("NB_FUNC_GENERAL_GET_INTERFACE returns an invalid result");
                    return run_exception_respond(m_param.transaction_id);
                }

                //convert[step 2]: check if the returned interface covers the master
                begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_CONVERT);

                node_invocation_request cover_req = m_param;
                cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
                cover_req.input.clear();
                cover_req.input.push_back(m_obj_id);

                return object_run(output.output.objects[0], req_num, cover_req);
            }
        case NB_FUNC_GENERAL_COMPARE:
            {
		    if ((3 != output.output.objects.size()) 
				    || !output.output.objects[0].is_object_bool()
				    || !output.output.objects[1].is_object_bool()
				    || !output.output.objects[2].is_object_bool())
                {
                    LOG_ERROR("func_interface_compound::obj_run_response():compare:invalid response");
                    return run_exception_respond(m_param.transaction_id);
                }

                bool ret;
                output.output.objects[1].get_value(ret);

                // if decl compare succeeded, update the covered decl
                if (ret)
                {
                    m_covered_idx++;
                    m_cover_idx = 0;

                    // all of covered decls found in cover decls
                    if (m_covered_idx == m_covered_if.decls.size())
                    {
                        return return_bool_result(true, m_param.transaction_id);

                        //if (m_covered_if.groups.size() == 0) 
                        //    return return_bool_result(true, m_param.transaction_id);

                        //// if groups exists
                        //m_covered_idx = 0;

                        //begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_EQ);

                        //node_invocation_request cover_req = m_param;
                        //cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_EQ);
                        //cover_req.input.clear();
                        //cover_req.input.push_back(m_cData.groups[m_cover_idx].min_if);

                        //return object_run(m_covered_if.groups[m_covered_idx].min_if, req_num, cover_req);
                    }

                }
                // if decl compare failed, update the cover decl
                else
                {
                    m_cover_idx++;
                    
                    // covered decl not compared in cover decls
                    if (m_cover_idx == m_cData.decls.size())
                        return return_bool_result(false, m_param.transaction_id);
                }

                begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_COMPARE);

                node_invocation_request cover_req = m_param;
                cover_req.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
                cover_req.input.clear();
                cover_req.input.push_back(m_cData.decls[m_cover_idx]);

                return object_run(m_covered_if.decls[m_covered_idx], req_num, cover_req);

                break;
            }
        //case NB_FUNC_INTERFACE_EQ:
        //    {
        //        if ((1 != output.output.objects.size()) 
        //                || !output.output.objects[0].is_object_bool())
        //        {
        //            LOG_ERROR("func_interface_compound::obj_run_response():eq:invalid response");
        //            return run_exception_respond(m_param.transaction_id);
        //        }

        //        bool ret;
        //        output.output.objects[0].get_value(ret);

        //        // if interface eq succeeded, update the covered interface 
        //        if (ret)
        //        {
        //            m_covered_idx++;
        //            m_cover_idx = 0;
        //            
        //            // all of covered interfaces success 
        //            if (m_covered_idx == m_covered_if.groups.size())
        //                return return_bool_result(true, m_param.transaction_id);

        //        }
        //        // if interface eq failed, update the cover interface 
        //        else
        //        {
        //            m_cover_idx++;

        //            // covered interface doesn't cover in cover interfaces
        //            if (m_cover_idx == m_cData.groups.size())
        //                return return_bool_result(false, m_param.transaction_id);

        //        }

        //        begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_EQ);

        //        node_invocation_request cover_req = m_param;
        //        cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_EQ);
        //        cover_req.input.clear();
        //        cover_req.input.push_back(m_cData.groups[m_cover_idx].min_if);

        //        return object_run(m_covered_if.groups[m_covered_idx].min_if, req_num, cover_req);

        //        break;
        //    }
        case NB_FUNC_INTERFACE_COVERS:
            {
                LOG_DEBUG("NB_FUNC_INTERFACE_COVERS");

                if ((1 != output.output.objects.size()) 
                        || !output.output.objects[0].is_object_bool())
                {
                    LOG_ERROR("NB_FUNC_INTERFACE_COVERS returns an invalid result");
                    return run_exception_respond(m_param.transaction_id);
                }

                bool ret;
                output.output.objects[0].get_value(ret);

                if(ret)
                {
                    m_eq_count++;
                    
                    if (m_eq_count == EQ_FLAG)
                        return return_bool_result(true, m_param.transaction_id);

                    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_COVERS);

                    node_invocation_request cover_req = m_param;
                    cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
                    cover_req.input.clear();
                    cover_req.input.push_back(m_obj_id);

                    return object_run(m_param.input[0], req_num, cover_req);

                }

                return return_bool_result(false, m_param.transaction_id);

                break;
            }
        default:
            LOG_ERROR("func_interface_compound::obj_run_response():invalid calling instruction");
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            break;
    
    }

    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_interface_compound::access_run_response(req_num_t req_num, 
        node_invocation_response& output)
{
    return obj_run_response(req_num, output); 
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
