/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_decl_compound.h"

func_decl_compound::func_decl_compound(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_decl_compound());

    nb_id_t id;
    obj_impl_decl_compound::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

func_decl_compound::~func_decl_compound()
{
} 

bool func_decl_compound::get_name(nb_id_t& out)
{
	return request_string_object(m_cData.name, out); 
}

bool func_decl_compound::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_decl_compound::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_DECLARATION);
    return true;
}

bool func_decl_compound::get_ports(bool input, bool output, nb_id_vector& vout)
{

    if (input)
    {
        // get inport interfaces
        nb_id_vector viif;
        for (std::vector<iport_t>::iterator it = m_cData.iports.begin();
                it != m_cData.iports.end();
                ++it)
            viif.push_back(it->interface);

        // return an array id
        nb_id_t out;
        generate_array(viif, NB_INTERFACE_INTERFACE, out);
        vout.push_back(out);
    }

    // get outport interfaces
    if (output)
    {
        nb_id_vector voif;
        for (std::vector<oport_t>::iterator it = m_cData.oports.begin();
            it != m_cData.oports.end();
            ++it)
        voif.push_back(it->interface);

        // return an array id
        nb_id_t out;
        generate_array(voif, NB_INTERFACE_INTERFACE, out);
        vout.push_back(out);
    }

    return true;
}

bool func_decl_compound::get_interfaces(nb_id_vector& vout)
{
    LOG_DEBUG("*** func_decl_compound::get_interfaces");
    return this->get_ports(true, true, vout);
}


bool func_decl_compound::get_in_ports(nb_id_vector& vout)
{
    LOG_DEBUG("*** func_decl_compound::get_in_ports");
    return this->get_ports(true, false, vout);
}

bool func_decl_compound::get_out_ports(nb_id_vector& vout)
{
    LOG_DEBUG("*** func_decl_compound::get_in_ports");
    return this->get_ports(false, true, vout);
}

bool func_decl_compound::get_expanded_ifs(nb_id_t& out)
{
    LOG_NOTICE("*** func_decl_compound::get_expanded_ifs");
    // return an empty array
    nb_id_vector vif;
    return generate_array(vif, NB_INTERFACE_INTERFACE, out);
}

bool func_decl_compound::get_iport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);
    int sz = m_cData.iports.size();
    num.set_value(sz);
    return true;
}

bool func_decl_compound::get_oport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);
    int sz = m_cData.oports.size();
    num.set_value(sz);
    return true;
}

bool func_decl_compound::run()
{ 
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ compound declaration run() = "<< m_cData.name);

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_INTERFACES:
        {
            get_interfaces(response.output.objects);
            break;
        }
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
        {
            get_in_ports(response.output.objects);
            break;
        }
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
        {
            get_out_ports(response.output.objects);
            break;
        }
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
        {
            nb_id_t result;
            ret = get_iport_number(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
        {
            nb_id_t result;
            ret = get_oport_number(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_ORIGIN_DECL");
            // just return self id
            ret = true;
            response.output.objects.push_back(m_obj_id);
            break;
        }
        case NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES");
            nb_id_t out;
            ret = get_expanded_ifs(out);
            response.output.objects.push_back(out);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    response.success = ret;
	response.child_transaction = m_param.transaction_id;
	ret = run_respond(response);
    return ret;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:

