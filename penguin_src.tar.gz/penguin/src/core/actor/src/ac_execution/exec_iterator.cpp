/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/exec_iterator.h"
#include "ac_object/obj_impl_exec_obj_func.h"

exec_iterator::exec_iterator(const nb_id_t& obj_id,
        const content& raw_data,
        const execution_id_t& exe_id,
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_exec_iterator());

    nb_id_t id;
    obj_impl_exec_iterator::unpack(raw_data, id, m_cData);
    //assert(id == m_obj_id);
}

exec_iterator::~exec_iterator()
{
}

bool exec_iterator::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out);
}

bool exec_iterator::run()
{
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ iterative run() = "<< m_cData.name);

    //assert(m_param.declaration_id == m_cData.external_decl);
//    if (m_param.declaration_id != m_cData.external_decl)
//        return run_exception_respond(m_param.transaction_id, CORPSE_ITERATOR_DECLARATION_WRONG);

    //assert(m_cData.repeated_exec.is_object_exec_implementation());
    if (!m_cData.repeated_exec.is_object_exec_implementation())
        return run_exception_respond(m_param.transaction_id, CORPSE_ITERATOR_ISNOT_IMPLEMENT);

    req_num_t req_num = generate_req_num();
    return object_run(m_cData.repeated_exec, req_num, m_param);
}

bool exec_iterator::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_iterator::get_value_response");
    return true;
}

bool exec_iterator::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    if (!output.output.corpse.is_object_corpse())
    {
        LOG_NOTICE(std::endl<<"++++++++++ exec_iterator::obj_run_response, object_id="<<output.output.objects[0].str());
    }
    else
    {
        LOG_NOTICE(std::endl<<"++++++++++ exec_iterator::obj_run_response, corpse_object_id="<<output.output.corpse.str());
        return run_respond(output);
    }

    if (output.output.objects[0].is_exception())
    {
        nb_exception_type_t exception_type = output.output.objects[0].get_exception_type();
        switch (exception_type) 
        {
            case NB_EXCEPTION_ZERO:
                output.success = true;
                // use the last input as the final result
                output.output.objects.clear();
                output.output.objects.push_back(m_object);
                output.output.objects.insert(output.output.objects.end(), m_param.input.begin(), m_param.input.end());
                break;

            case NB_EXCEPTION_NORMAL:
                output.success = false;
                output.is_refusal = true;
                break;

            default:
                break;
        }

        return run_respond(output);
    }
    else
    {
        // no exception,use the output as next input
        m_param.object_id = output.output.objects[0];
        m_param.input.clear();
        m_param.input.insert(m_param.input.begin(), output.output.objects.begin()+1, output.output.objects.end());

        req_num_t req_num = generate_req_num();
        return object_run(m_cData.repeated_exec, req_num, m_param);
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
