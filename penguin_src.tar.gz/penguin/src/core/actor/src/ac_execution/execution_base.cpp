/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution/execution_base.h"
#include "ac_execution_helper.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_string.h"
#include "ac_container/access_implementation.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_map.h"
#include "ac_message_type.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"
#include "ac_time_observer.h"

execution_base::execution_base()
{
    m_pHelper = NULL;

    time_t tm;    
    time(&tm);
    m_top_req_num = tm;
} 

execution_base::execution_base(const nb_id_t& obj_id, 
        const execution_id_t& exe_id,
        ac_execution_helper * pHelper)
    : m_obj_id(obj_id), m_id(exe_id)
{
    m_pHelper = pHelper;

    time_t tm;    
    time(&tm);
    m_top_req_num = tm;
}

execution_base::~execution_base()
{
}

void execution_base::set_id(const execution_id_t& id)
{
    m_id = id;
}

bool execution_base::get_id(execution_id_t& id)
{
    id = m_id;
    return true;
}

void execution_base::set_object_id(const nb_id_t& id)
{
    m_obj_id = id;
}

bool execution_base::get_object_id(nb_id_t& id)
{
    id = m_obj_id;
    return true;
}

bool execution_base::get_transaction_id(transaction_id_t& id)
{
    id = m_param.transaction_id;
    return true;
}

bool execution_base::request_string_object(const std::string& name, nb_id_t& out)
{
    request_nb_id_info str_info;
    str_info.committer_id = m_param.host_committer_id;
    str_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(name, nb_id_t(), str_info.raw_data);

    return request_nb_id(m_param.host_committer_id, str_info, out);
}

bool execution_base::return_bool_result(const bool result, const transaction_id_t& tr_id)
{
    node_invocation_response response;
    nb_id_t ret(NBID_TYPE_OBJECT_BOOL);
    ret.set_value(result);
    response.success = true;
    response.child_transaction = tr_id;
    response.output.objects.push_back(ret);

    return run_respond(response);
}

bool execution_base::is_null(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_null()");

    bool value = m_obj_id.is_object_none(); 

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_null = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_singleton(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_singleton()");

    bool value = m_obj_id.is_singleton(); 

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_singleton = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_justid(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_justid()");

    bool value = m_obj_id.is_justid_type(); 

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    
    out.set_value(value);
    LOG_NOTICE("execution_base::is_justid = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_builtin(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_builtin()");

    bool value = m_obj_id.is_builtin_object();  

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_builtin = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_exportable(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_exportable()");

    bool value = m_obj_id.is_exportable();  

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_exportable = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_local(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_local()");

    bool value = m_obj_id.is_local(); 

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_local = " << std::boolalpha << value);

    return true;
}

bool execution_base::is_valuecompared(nb_id_t& out)
{
    LOG_DEBUG("execution_base::is_valuecompared()");

    bool value = m_obj_id.is_value_compare(); 

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);

    out.set_value(value);
    LOG_NOTICE("execution_base::is_valuecompared = " << std::boolalpha << value);

    return true;
}


bool execution_base::exception_if_null(nb_id_t& out)
{
    if (m_obj_id.is_object_none()) 
    {
        request_nb_id_info  info;
        info.type = NBID_TYPE_OBJECT_EXCEPTION;
        info.committer_id = m_param.host_committer_id;
        if (!request_nb_id(m_param.host_committer_id, info, out), false)
            return false;
        out.set_exception_type(NB_EXCEPTION_USER);
    }
    else
    {
        out = m_obj_id;
    }
    return true;
}

bool execution_base::is_independ(nb_id_t& out)
{
    return true;
}

bool execution_base::compare(const nb_id_t& in, nb_id_vector& vout)
{
    LOG_DEBUG("execution_base::compare()");

    nb_id_t out(NBID_TYPE_OBJECT_BOOL);

    out.set_value(m_obj_id < in);
    vout.push_back(out);
//    LOG_NOTICE("execution_base::compare(<) " << std::boolalpha << (m_obj_id < in));

    out.set_value(m_obj_id == in);
    vout.push_back(out);
//    LOG_NOTICE("execution_base::compare(=) " << std::boolalpha << (m_obj_id == in));

    out.set_value(m_obj_id > in);
    vout.push_back(out);
//    LOG_NOTICE("execution_base::compare(>) " << std::boolalpha << (m_obj_id > in));

    //assert(vout.size() == 3);
    if(vout.size() != 3)
        return false;
    return true;
}

bool execution_base::get_registed_accesses()
{
    if (!m_obj_id.is_singleton())
    {
        node_invocation_response response; 
        response.success = true;
        response.child_transaction = m_param.transaction_id;
        return run_respond(response);
    }

    m_get_ac_req = 0;
    m_get_ac_res = 0;
    m_reg_ac_res = 0;

    req_num_t req_num = generate_req_num();   
    begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_REGISTED_ACCESSES);

    return object_get_value_async(m_obj_id, req_num);
}

bool execution_base::general_run()
{
    req_num_t req_num = generate_req_num();   
    begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_RUN);

    return object_get_value_async(m_param.input[1], req_num);
}

bool execution_base::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    array_data_t        logic_data;
    logic_data.type = m_array_key;
    logic_data.objs = output.output.objects;

    nb_id_t             array_id;
    request_nb_id_info  nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_ARRAY;
    obj_impl_array::pack(logic_data, nb_id_t(), nb_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, nb_info, array_id))
    {
        LOG_ERROR("func_array::generate_array():request array id failed.");
        return run_exception_respond(m_param.transaction_id);
    }


    m_result.output.objects.push_back(array_id);
    m_result.child_transaction = m_param.transaction_id;
    m_result.success = true;
    m_result.is_refusal = false;
    return run_respond(m_result);
}

bool execution_base::run_prepare(call_id_t call_id, const node_invocation_request& input)            
{
    // save params to internal states
    m_call_id = call_id;
    m_param = input;
    return true;
}

bool execution_base::run()
{
    node_invocation_response response;

    bool ret = false;

    switch (m_param.declaration_id.get_func_type())   
    {
        case NB_FUNC_GENERAL_IS_NULL:
        {
            nb_id_t out;
            ret = is_null(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_SINGLETON:
        {
            nb_id_t out;
            ret = is_singleton(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_JUSTID:
        {
            nb_id_t out;
            ret = is_justid(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_BUILTIN:
        {
            nb_id_t out;
            ret = is_builtin(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_EXPORTABLE:
        {
            nb_id_t out;
            ret = is_exportable(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_LOCAL:
        {
            nb_id_t out;
            ret = is_local(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_IS_VALUECOMPARED:
        {
            nb_id_t out;
            ret = is_valuecompared(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_GENERAL_EXCEPTION_IF_NULL:
        {
            nb_id_t out;
            ret = exception_if_null(out);
            response.output.objects.push_back(out);
            nb_id_t nb(NBID_TYPE_OBJECT_NONE);
            response.output.objects.push_back(nb);
            break;
        }
        case NB_FUNC_GENERAL_COMPARE:
        {
            //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            ret = compare(m_param.input[0], response.output.objects);
            break;
        }
        case NB_FUNC_GENERAL_RUN:
        {
            //assert(2 == m_param.input.size());
            if(2 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            return general_run();
            break;
        }
        case NB_FUNC_GENERAL_GET_REGISTED_ACCESSES:
        {
            LOG_DEBUG("*** execution_base::get_registed_accesses");
            return get_registed_accesses(); 
            break;
        }
        case NB_FUNC_GENERAL_GET_INTERFACE:
        {
            nb_id_t out;
            ret = m_obj_id.get_builtin_interface(out);
            
            if (!ret)
            {
                LOG_ERROR("*** execution_base:: get_builtin_interface::failed");
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }

            LOG_NOTICE("*** execution_base::get_interface = "<<out.str());
            response.output.objects.push_back(out);
            break;
        }
        default:
            break;
    }

    response.success = ret;
    return run_respond(response);
}

bool execution_base::run_instruction(const nb_id_t& principal, 
        const node_invocation_request& input,
        const nb_builtin_instruction_t ins_call,
        const nb_builtin_instruction_t ins_call_out)
{
    req_num_t req_num = generate_req_num();    

    instruction_pair_t call_pair;
    call_pair.first = ins_call;
    call_pair.second = ins_call_out;

    insert_num_ins_pair(req_num, call_pair);

    object_run(principal, req_num, input);

    return true;
}

bool execution_base::access_run_instruction(const access_id_t& principal, 
        const node_invocation_request& input,
        const nb_builtin_instruction_t ins_call,
        const nb_builtin_instruction_t ins_call_out)
{
    req_num_t req_num = generate_req_num();    

    instruction_pair_t call_pair;
    call_pair.first = ins_call;
    call_pair.second = ins_call_out;

    insert_num_ins_pair(req_num, call_pair);

    access_run(principal, req_num, input);

    return true;
}

bool execution_base::run_exception_respond(const transaction_id_t& tr_id, int corpse_type)
{
    LOG_ERROR("execution_base::run_exception_respond()");

    node_invocation_response response;
    response.child_transaction = tr_id;
    response.success = false;
    response.corpse_type = corpse_type;

    return run_respond(response);
}

bool execution_base::run_respond(node_invocation_response& output)
{
    LOG_DEBUG("execution_base::run_respond():output size:" << output.output.objects.size());

    m_result = output;

    // inform the parent execution
    if (m_parent_execution.is_value_null())
    {
        // get root committer if execution is root
        center_committer_id_t center_commit;
        m_pHelper->ac_host_committer_get_center_committer(m_param.host_committer_id, center_commit);
        m_pHelper->ac_center_committer_get_root_committer(center_commit, m_root_commit);
        m_pHelper->ac_root_committer_pre_commit(m_root_commit, 0, !m_result.success);
    }
    else
    {
        run_execution_respond(output.success);
    }

    return true;
}

bool execution_base::exception_respond(std::string& output)
{
    return m_pHelper->exception_respond(m_call_id, output);
}

bool execution_base::request_nb_id(host_committer_id_t id, const request_nb_id_info& input, nb_id_t& output, bool is_corpse)
{
    //assert(!id.is_value_null());
    if(id.is_value_null())
    {
        return run_exception_respond(m_param.transaction_id, CORPSE_EXEC_REQUEST_ID_FAILED);
    }

    switch (input.type)
    {
        case NBID_TYPE_OBJECT_NONE:
            output = nb_id_t(NBID_TYPE_OBJECT_NONE);
            break;
        case NBID_TYPE_OBJECT_BOOL:
            output = nb_id_t(NBID_TYPE_OBJECT_BOOL);
            break;
        case NBID_TYPE_OBJECT_INT:
            output = nb_id_t(NBID_TYPE_OBJECT_INT);
            break;
        case NBID_TYPE_OBJECT_FLOAT:
            output = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
            break;
        case NBID_TYPE_OBJECT_INTERVAL:
            output = nb_id_t(NBID_TYPE_OBJECT_INTERVAL);
            break;
        case NBID_TYPE_OBJECT_TIME:
            output = nb_id_t(NBID_TYPE_OBJECT_TIME);
            break;
        case NBID_TYPE_OBJECT_DECLARATION:
            output = nb_id_t(NBID_TYPE_OBJECT_DECLARATION);
            break;
        case NBID_TYPE_OBJECT_INTERFACE:
            output = nb_id_t(NBID_TYPE_OBJECT_INTERFACE);
            break;
        default:
            if (is_corpse)
                return m_pHelper->ac_host_committer_request_corpse_id(id, input, output);
            else
                return m_pHelper->ac_host_committer_request_nb_id(id, input, output);
            break;
    }

    return true;
}

bool execution_base::request_facade_id(host_committer_id_t id, 
        const request_facade_id_info& input,
        facade_id_t& output)
{
    return m_pHelper->ac_host_committer_request_facade_id(id, input, output);
}

bool execution_base::create_object(host_committer_id_t id, const content& input)
{
    return m_pHelper->ac_host_committer_create_object(id, input);
}

bool execution_base::load_object(host_committer_id_t id, const nb_id_t& input, content& output)
{
    return m_pHelper->ac_host_committer_load_object(id, input, output);
}

bool execution_base::object_run(nb_id_t id, req_num_t req_num, const node_invocation_request& input)
{
    if (id.is_object_access())
    {
        access_id_t ac_id(id.str());
        if(!m_pHelper->ac_access_run(ac_id, req_num, input))
            return throw_exeception(req_num, "Asyn call failed : ac_access_run().");
    }
    else
    {
        if(!m_pHelper->ac_object_run(id, req_num, input))
            return throw_exeception(req_num, "Asyn call failed : ac_object_run().");
    }

    return true;
}

bool execution_base::object_get_value(nb_id_t id, content& output)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_get_value_sync(id, output);
}

bool execution_base::object_get_value_async(nb_id_t id, req_num_t req_num)
{
    assert(m_pHelper);
    return m_pHelper->ac_object_get_value_async(id, req_num);
}

bool execution_base::get_value_async(const nb_id_t& id, const nb_builtin_instruction_t& ins)
{
    LOG_DEBUG("execution_base::get_value_async()");

    assert(m_pHelper);

    req_num_t req_num = generate_req_num();    
    begin_incoming_ins_call(req_num, ins);

    return m_pHelper->ac_object_get_value_async(id, req_num);
}

bool execution_base::access_run(access_id_t id, 
        req_num_t req_num, 
        const node_invocation_request& input)
{
    if (!m_pHelper->ac_access_run(id, req_num, input))
        return throw_exeception(req_num, "Asyn call failed : ac_access_run().");

    return true;
}

bool execution_base::throw_exeception(req_num_t req_num, std::string exception_string)
{
    call_id_t call_id;

    if (!get_call_id(req_num, call_id))
    {
        LOG_ERROR("Logic failed : could not get call_id.");
        return false;        
    }    

    //just return exception string if there is exeception;
    if (!m_pHelper->exception_respond(call_id, exception_string))
    {
        //remove the info in m_impl
        end_incoming_call(req_num); 
        return false;
    }

    //remove the info in m_impl
    end_incoming_call(req_num);
    return true;
}

/**************************** request number ****************************/
req_num_t execution_base::generate_req_num()
{
    return ++m_top_req_num;    
}

void execution_base::begin_incoming_call(req_num_t req_num, call_id_t call_id)
{
    m_req_info_map.insert(std::make_pair(req_num, call_id));    
}

void execution_base::end_incoming_call(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool execution_base::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, call_id_t>::iterator it = m_req_info_map.find(req_num);

    if (it == m_req_info_map.end())
        return false;

    call_id = it->second;
    return true;
}

void execution_base::begin_incoming_ins_call(req_num_t req_num, nb_builtin_instruction_t instruction)
{
    m_ins_call_map.insert(std::make_pair(req_num, instruction));    
}

void execution_base::end_incoming_ins_call(req_num_t req_num)
{
    m_ins_call_map.erase(req_num);
}

bool execution_base::get_ins_call(req_num_t req_num, nb_builtin_instruction_t& instruction)
{
    builtin_instruction_map_it it = m_ins_call_map.find(req_num);

    if (it == m_ins_call_map.end())
        return false;

    instruction = it->second;
    return true;
}

void execution_base::begin_incoming_ins_call_out(req_num_t req_num, nb_builtin_instruction_t instruction)
{
    m_ins_call_out_map.insert(std::make_pair(req_num, instruction));    
}

void execution_base::end_incoming_ins_call_out(req_num_t req_num)
{
    m_ins_call_out_map.erase(req_num);
}

bool execution_base::get_ins_call_out(req_num_t req_num, nb_builtin_instruction_t& instruction)
{
    builtin_instruction_map_it it = m_ins_call_out_map.find(req_num);

    if (it == m_ins_call_out_map.end())
        return false;

    instruction = it->second;
    return true;
}

void execution_base::insert_num_ins_pair(const req_num_t req_num, const instruction_pair_t ins_pair)
{
    m_num_ins_pair_map.insert(std::make_pair(req_num, ins_pair));    
}

void execution_base::erase_num_ins_pair(const req_num_t req_num)
{
    m_num_ins_pair_map.erase(req_num);
}

bool execution_base::get_ins_pair(const req_num_t req_num, instruction_pair_t& ins_pair)
{
    num_ins_pair_map_it it = m_num_ins_pair_map.find(req_num);

    if (it == m_num_ins_pair_map.end())
        return false;

    ins_pair = it->second;
    return true;
}

void execution_base::insert_num_param_pair(req_num_t req_num, const node_invocation_request& param)
{
    m_param_info_map.insert(std::make_pair(req_num, param));    
}

void execution_base::erase_num_param_pair(req_num_t req_num)
{
    m_param_info_map.erase(req_num);
}

bool execution_base::get_param(req_num_t req_num, node_invocation_request& param)
{
    std::map<req_num_t, node_invocation_request>::iterator it = m_param_info_map.find(req_num);

    if (it == m_param_info_map.end())
        return false;

    param = it->second;
    return true;
}

bool execution_base::set_parent(const execution_id_t& input)
{
    m_parent_execution = input;
    return true;
}

bool execution_base::set_root_commit(const root_committer_id_t& input)
{
    m_root_commit = input;
    return true;
}

/**************************** response ****************************/
bool execution_base::access_run_response(req_num_t req_num, node_invocation_response& output)
{
    return true;
}

bool execution_base::get_value_response(req_num_t req_num, content& output)
{
    node_invocation_response response;

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("execution_base::get_value_response() failed");
        return run_exception_respond(m_param.transaction_id);
    }

    content value;

    switch (builtin_ins)
    {
        case NB_FUNC_ACCESS_IS_REGISTED:
        {
            ++m_reg_ac_res;

            int ac_st = m_accesses.size();
            if (m_reg_ac_res == ac_st)
            {
                node_invocation_response response;
                response.child_transaction = m_param.transaction_id;
                response.success = true;
                response.output.accesses = m_reg_accesses;
                return run_respond(response);
            }
            else
            {
                access_data_t ac_data;
                access_implementation::unpack(value, ac_data);

                for (size_t i = 0; i != m_reqs.size(); ++i)
                {
                    if ((req_num == m_reqs[i]) && (ac_data.is_registed))
                    {
                        access_id_t access_id;
                        m_accesses[i].to_access_id(access_id);
                        m_reg_accesses.push_back(access_id);
                        break;
                    }
                }

                return run_exception_respond(m_param.transaction_id);
            }
            break;
        }
        case NB_FUNC_GENERAL_GET_REGISTED_ACCESSES:
        {
            user_data_t parent_user;
            nb_id_t user_id;
            obj_impl_user::unpack(value, user_id, parent_user);

            ++m_get_ac_res;

            // get accesses
            for (nb_id_vector_const_it it = parent_user.subobjs.begin(); it != parent_user.subobjs.end(); ++it)
            {
                if (it->is_object_access())
                {
                    m_accesses.push_back(*it);
                    continue;
                }

                if (it->is_user_object() && it->is_singleton())
                {
                    ++m_get_ac_req;

                    req_num_t req_num = generate_req_num();   
                    begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_REGISTED_ACCESSES);

                    object_get_value_async(*it, req_num);
                }
            }

            if (m_get_ac_res == m_get_ac_req)
            {
                for (nb_id_vector_const_it it = m_accesses.begin(); it != m_accesses.end(); ++it)
                {
                    req_num_t req_num = generate_req_num();   
                    m_reqs.push_back(req_num);
                    begin_incoming_ins_call(req_num, NB_FUNC_ACCESS_IS_REGISTED);

                    object_get_value_async(*it, req_num);
                }
            }

            break;
        }
        case NB_FUNC_GENERAL_RUN:
        {
            LOG_INFO("general run declaration id: " << m_param.input[0].str());

            nb_id_t id;
            array_data_t in_array;
            obj_impl_array::unpack(output, id, in_array);
            
            node_invocation_request  run_in = m_param;
            run_in.declaration_id = m_param.input[0];
            run_in.input = in_array.objs;
            m_array_key = in_array.type;

            req_num_t req_num = generate_req_num();
            begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_RUN);

            if (m_param.object_id.is_object_access())
            {
                access_id_t ac_id;
                m_param.object_id.to_access_id(ac_id);
                return m_pHelper->ac_access_run(ac_id, req_num, run_in);
            }
            else
            {
                return m_pHelper->ac_object_run(m_param.object_id, req_num, run_in);
            }
            break;
        }
        default:
            return run_exception_respond(m_param.transaction_id);
            break;
    }

    return true;
}

bool execution_base::pre_commit_response(req_num_t req_num, bool& output)
{
    LOG_DEBUG("*** execution_base::pre_commit_response, output="<<output);

    if (output)
    {
        m_pHelper->ac_root_committer_commit(m_root_commit, 0);
    }
    else
    {
        m_result.success = output;
        run_execution_respond(output);
    }

    return true;
}

bool execution_base::run_execution_respond(bool output)
{
    if (m_parent_execution.is_value_null())
    {
        LOG_ALERT("@@@@@@@@@@ bridge run end : " << ac_time_observer::Instance()->print_current_time());
        m_pHelper->ac_execution_trigger_end_respond(m_call_id, output);
    }
    else
    {
        m_pHelper->ac_execution_start_respond(m_call_id, m_result);
    }
    return true;
}

bool execution_base::commit_response(req_num_t req_num, bool& output)
{
    LOG_DEBUG("*** execution_base::commit_response, output="<<output);

    if (!output)
        m_result.success = output;

    run_execution_respond(output);

    return true;
}

/******************  generate array and map with expanded decls ******************/

bool execution_base::generate_map(const std::vector< key_obj_id >& key_obj_ids, const nb_id_t& key_min_if,
                                  const nb_id_t& val_min_if, nb_id_t& map_id)
{
    LOG_DEBUG("*** execution_base::generate_map_with_expanded_decls ***");

    map_data_t map_data;

    // 1. objects ==> map_data.data
    for (size_t i = 0; i < key_obj_ids.size(); ++i)
        map_data.data.insert(std::make_pair(key_obj_ids[i].key_id, key_obj_ids[i].obj_id));

    // 2. if_compound ==> map_data.type
    if_exp_group key_type, val_type;
    key_type.min_if = key_min_if;
    val_type.min_if = val_min_if;

    if_compound_data_t map_ifc;
    map_ifc.name = "map type";

    /* 2.1. if_comound.groups */
    map_ifc.groups.push_back(key_type);
    map_ifc.groups.push_back(val_type);

    /* 2.2. if_compound.expanded_decls */
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
    decl_info.committer_id = m_param.host_committer_id;

    decl_expanded_data_t decl_data;
    decl_data.expanded_ifs.push_back(key_min_if);
    decl_data.expanded_ifs.push_back(val_min_if);

    /* 2.2.1. get decls of map */
    nb_id_vector decl_ids_map;
    obj_impl_interface::get_builtin_instructions(nb_id_t(NB_INTERFACE_MAP), false, decl_ids_map);
    
    /* 2.2.2. get_decl_names of map and request decl_expanded_id */
    for (uint32_t i = 0; i < decl_ids_map.size(); ++i)
    {
        nb_id_t decl_id;
        obj_impl_declaration::get_instruction_name(decl_ids_map[i], decl_data.name);
        decl_data.origin_decl_id = decl_ids_map[i];
        obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
        request_nb_id(m_param.host_committer_id, decl_info, decl_id);
        map_ifc.decls.push_back(decl_id);
    }
    
    nb_id_vector builtin_decls;
    obj_impl_interface::get_general_instructions(builtin_decls);

    for (uint32_t i = 0; i < builtin_decls.size(); ++i)
        map_ifc.decls.push_back(builtin_decls[i]);

    /* 2.3. request id for map_data.type */
    request_nb_id_info ifc_info;
    ifc_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    ifc_info.committer_id = m_param.host_committer_id;
    obj_impl_interface_compound::pack(map_ifc, nb_id_t(), ifc_info.raw_data);
    request_nb_id(m_param.host_committer_id, ifc_info, map_data.type);

    // 3. info
    request_nb_id_info map_info;
    map_info.type = NBID_TYPE_OBJECT_MAP;
    map_info.committer_id = m_param.host_committer_id;
    obj_impl_map::pack(map_data, nb_id_t(), map_info.raw_data);

    // 4. id
    return request_nb_id(m_param.host_committer_id, map_info, map_id);
}

bool execution_base::generate_array(const nb_id_vector& keys, const nb_id_t& key_min_if, nb_id_t& array_id)
{
    LOG_DEBUG("*** execution_base::generate_array_with_expanded_decls ***");

    array_data_t array_data;

    // 1. objects ==> array_data.data
    for (size_t i = 0; i < keys.size(); ++i)
        array_data.objs.push_back(keys[i]);

    // 2. if_compound ==> array_data.type
    if_exp_group key_type;
    key_type.min_if = key_min_if;

    if_compound_data_t array_ifc;
    array_ifc.name = "array type";

    /* 2.1 if_compound.groups */
    array_ifc.groups.push_back(key_type);

    /* 2.2 if_compound.expanded_decls */
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
    decl_info.committer_id = m_param.host_committer_id;

    decl_expanded_data_t decl_data;
    decl_data.expanded_ifs.push_back(key_min_if);

    /* 2.2.1. get decls of array */
    nb_id_vector decl_ids_array;
    obj_impl_interface::get_builtin_instructions(nb_id_t(NB_INTERFACE_ARRAY), false, decl_ids_array);

    /* 2.2.2. get_decl_names of array and request decl_expanded_id */
    for (uint32_t i = 0; i < decl_ids_array.size(); ++i)
    {
        nb_id_t decl_id;
        obj_impl_declaration::get_instruction_name(decl_ids_array[i], decl_data.name);
        decl_data.origin_decl_id = decl_ids_array[i];
        obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
        request_nb_id(m_param.host_committer_id, decl_info, decl_id);
        array_ifc.decls.push_back(decl_id);
    }

    nb_id_vector builtin_decls;
    obj_impl_interface::get_general_instructions(builtin_decls);

    for (uint32_t i = 0; i < builtin_decls.size(); ++i)
        array_ifc.decls.push_back(builtin_decls[i]);

    /* 2.3. request id for array_data.type */
    request_nb_id_info ifc_info;
    ifc_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    ifc_info.committer_id = m_param.host_committer_id;
    obj_impl_interface_compound::pack(array_ifc, nb_id_t(), ifc_info.raw_data);
    request_nb_id(m_param.host_committer_id, ifc_info, array_data.type);

    // 3. info
    request_nb_id_info array_info;
    array_info.type = NBID_TYPE_OBJECT_ARRAY;
    array_info.committer_id = m_param.host_committer_id;
    obj_impl_array::pack(array_data, nb_id_t(), array_info.raw_data);

    // 4. id
    return request_nb_id(m_param.host_committer_id, array_info, array_id);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
