/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_execution_helper.h"
#include "ac_execution/func_access.h"
#include "ac_container/container_implementation.h"
#include "ac_container/anchor_implementation.h"
#include "ac_object/obj_impl_container_def.h"
// test
#include "ac_object/data_unpacker.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_time_observer.h"
#include "ac_db/ac_object_db_impl.h"

//#define DEBUG_CONTAINER
#include<time.h>
#include<stdio.h>
#include <sys/time.h>

func_access::func_access()
{
}

func_access::func_access(const nb_id_t& access_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(access_id, exe_id, pHelper)
{
    access_id.to_access_id(m_access_id);
    access_implementation::unpack(raw_data, m_cData);
}

func_access::~func_access()
{
}

/**************************** public ****************************/

bool func_access::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out);
}

/**************************** normal access ****************************/

bool func_access::is_registed(nb_id_t& result)
{ 
    request_nb_id_info nb_info;

    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_BOOL;

    if (!request_nb_id(m_param.host_committer_id, 
        nb_info, result))
        return run_exception_respond(m_param.transaction_id);

    result.set_value(m_cData.is_registed);

    return true;
}

/**************************** root access ****************************/
bool func_access::destroy_container(const container_id_t& cont_id)
{ 
    return true; 
}

bool func_access::generate_access_from_anchor(const anchor_data_t& an_data,
        const int an_idx,
        access_id_t& access_id)
{ 
    // create access
    request_access_id_info access_info;
    access_info.committer_id = m_param.host_committer_id; 

    access_data_t access_data;
    access_data.interface = an_data.interface;
    access_data.parent_container = m_cData.parent_container;
    access_data.is_registed = an_data.registed;
    access_data.anchor_idx = an_idx;
    access_data.is_outgoing = false;

    access_implementation::pack(access_data, access_info.raw_data);

    if (!m_pHelper->ac_host_committer_request_access_id(m_param.host_committer_id,
                access_info, 
                access_id))
        return run_exception_respond(m_param.transaction_id);

    return true;

}

/**************************** run ****************************/
bool func_access::run()
{
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ access run() = "<< m_cData.name);

    LOG_CRIT("@@@@@@@@@@ access run start : " << ac_time_observer::Instance()->print_current_time());

    node_invocation_response response;

    // if access comes from bridge
    if(m_param.declaration_id.is_function_get_anchors())
    {
        assert(m_pHelper);

        req_num_t req_num = generate_req_num();    
        begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ANCHORS);

        return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                req_num);
    }

    if(m_param.declaration_id.is_function_get_storages())
    {
        assert(m_pHelper);

        req_num_t req_num = generate_req_num();    
        begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_STORAGES);

        return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                req_num);
    }

    if (!m_param.declaration_id.is_function_instruction())
    {
        if (m_cData.is_outgoing)
        {
            assert(m_pHelper);

            if (1 != m_param.input.size())
                return run_exception_respond(m_param.transaction_id);

            bridge_id_t bridge_id;
            m_cData.parent_container.get_bridge_id(bridge_id);

            req_num_t req_num = generate_req_num();
            send_out_info info = { m_param.host_committer_id, m_param.input[0], m_param.declaration_id};
            return m_pHelper->ac_bridge_send_out(bridge_id, req_num, info);
        }
        else 
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_START);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
    }

    switch(m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_GENERAL_GET_INTERFACE:
        {
            response.output.objects.push_back(m_cData.interface);
            break;
        }
        case NB_FUNC_ACCESS_GET_CONTAINER:
        {
            response.output.container = m_cData.parent_container;
            break;
        }
        case NB_FUNC_ACCESS_GET_ANCHOR:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ACCESS_GET_ANCHOR);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ACCESS_IS_REGISTED:
        {
            nb_id_t out;
            is_registed(out);

            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
        {
            //assert(1 == m_param.input.size());
            //assert(m_param.input[0].is_object_container_defination());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            if(!m_param.input[0].is_object_container_defination())
            {
               return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
            }

            // get container defination 
            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER);

            return object_get_value_async(m_param.input[0], 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER:
            break;
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_CONT_DEF);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_STORAGE);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ANCHOR);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);

        }
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ACCESS);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST:
        {
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST:
        { 
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT:
        { 
            assert(m_pHelper);

            req_num_t req_num = generate_req_num();    
            begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT);

            return m_pHelper->ac_container_get_value_async(m_cData.parent_container, 
                    req_num);
        }
        default:
        {
            // for builtin ins
            if (m_param.declaration_id.is_instruction_general())
                return execution_base::run();
            // for user-defined decls
            else
                response.success = false;
        }
    }

    response.success = true;
    response.child_transaction = m_param.transaction_id;

    return run_respond(response);
}

/**************************** run ****************************/
bool func_access::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    nb_builtin_instruction_t builtin_ins;
    if (get_ins_call(req_num, builtin_ins))
    {
        switch (builtin_ins)
        {
            case NB_FUNC_GENERAL_RUN:
                end_incoming_ins_call(req_num);
                return execution_base::obj_run_response(req_num, output);
            default:
                break;
        }
    }

    return run_respond(output);
}

bool func_access::create_container_get_value_response(const content& output)
{
    LOG_DEBUG("func_access::create_container()");

    nb_id_t def_id;
    cont_def_data_t cont_def;
    container_data_t container_data;
    if_compound_data_t ra_if;


    obj_impl_container_def::unpack(output, def_id, cont_def);

    // create anchors
    for (std::vector<anchor_info_t>::iterator it = cont_def.anchors.begin();
        it != cont_def.anchors.end();
        ++it)
    {
        request_anchor_id_info anchor_info;

        // package
        anchor_data_t anchor_data;
        anchor_data.funcs = it->funcs;
        anchor_data.interface = it->interface;
        anchor_data.name = it->name;
        anchor_data.registed = it->registed;

        // add declaration  for root access interface
        for (func_vector_const_it fit = it->funcs.begin();
                fit != it->funcs.end();
                ++fit)
        {
            if (find(ra_if.decls.begin(), ra_if.decls.end(), fit->declaration_id) == ra_if.decls.end())
                ra_if.decls.push_back(fit->declaration_id);
        }

        // create anchor 
        anchor_implementation::pack(anchor_data, anchor_info.raw_data);

        // req anchor id
        anchor_id_t anchor_id;
        if (!m_pHelper->ac_host_committer_request_anchor_id(m_param.host_committer_id, 
                    anchor_info,
                    anchor_id))
            return run_exception_respond(m_param.transaction_id);

        // save
        container_data.anchors.push_back(anchor_id);
    }

    // create storages
    //for (std::vector<nb_type_t>::iterator it = cont_def.storages.begin();
    //    it != cont_def.storages.end();
    //    ++it)
    //{
    //    // req anchor id
    //    storage_id_t storage_id;
    //    if (!m_pHelper->ac_host_committer_request_storage_id(m_param.host_committer_id, 
    //                //*it, //storage type
    //                storage_id))
    //        return run_exception_respond(m_param.transaction_id);

    //    // save
    //    container_data.storages.push_back(storage_id);
    //}

    container_data.definition = def_id;

    // create container 
    request_container_id_info container_info;
    container_implementation container_impl;
    container_impl.pack(container_data, container_id_t(), container_info.raw_data);
    container_id_t container_id;
    if (!m_pHelper->ac_host_committer_request_container_id(m_param.host_committer_id, 
                container_info,
                container_id))
        return run_exception_respond(m_param.transaction_id);

    // create root access interface
    ra_if.name = "root access interface";
    // TODO
    // expansion
    request_nb_id_info ra_if_info;
    nb_id_t if_id;
    ra_if_info.committer_id = m_param.host_committer_id;
    ra_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    obj_impl_interface_compound::pack(ra_if, nb_id_t(), ra_if_info.raw_data);

    if (!m_pHelper->ac_host_committer_request_nb_id(m_param.host_committer_id, 
                ra_if_info,
                if_id))
        return run_exception_respond(m_param.transaction_id);

    // create root access
    access_data_t access_data;
    access_data.interface = if_id;
    access_data.parent_container = container_id;
    // root access is registed for ever 
    access_data.is_registed = true;

    request_access_id_info access_info;
    access_id_t root_access;
    access_info.committer_id = m_param.host_committer_id;
    access_implementation::pack(access_data, access_info.raw_data);

    if (!m_pHelper->ac_host_committer_request_access_id(m_param.host_committer_id, 
                access_info,
                root_access))
        return run_exception_respond(m_param.transaction_id);

    node_invocation_response response;
    nb_id_t raccess(root_access.str());
    response.output.objects.push_back(raccess);
    response.success = true; 
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_access::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_access::get_value_async_response()");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_access::get_value_response() failed");

        return run_exception_respond(m_param.transaction_id);
    }

    switch(builtin_ins)
    {
        case NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER:
            return create_container_get_value_response(output);
        default:
            return execution_base::get_value_response(req_num, output);
    }

    return true; 
}

bool func_access::get_container_value_response(req_num_t req_num, con_content& output)
{
    LOG_DEBUG("*** func_access::get_container_value_async_response()");

    node_invocation_response response;
    node_invocation_request request;
    request = m_param;
    nb_builtin_instruction_t builtin_ins;

    response.child_transaction = request.transaction_id;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_access::get_container_value_response() failed");

        return run_exception_respond(request.transaction_id);
    }

    container_id_t id;
    container_implementation::unpack(output, id, m_parent_cont_data);
    //assert(id  == m_cData.parent_container);

    switch(builtin_ins)
    {
        case NB_FUNC_ACCESS_GET_ANCHOR:
            {
                int sz = m_parent_cont_data.anchors.size();
                //assert(m_cData.anchor_idx < sz && m_cData.anchor_idx > -1);
                if(m_cData.anchor_idx >= sz || m_cData.anchor_idx <= -1)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_ANCHOR_INDEX_INVALID);
                }

                nb_id_t anch(m_parent_cont_data.anchors[m_cData.anchor_idx].str());
                response.output.objects.push_back(anch);
                //response.output.anchors.push_back(m_parent_cont_data.anchors[m_cData.anchor_idx]);
                break;
            }
        case NB_FUNC_GENERAL_START:
            {
                assert(m_pHelper);

                begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_START);

                return m_pHelper->ac_anchor_get_value_async(m_parent_cont_data.anchors[m_cData.anchor_idx], 
                        req_num);
            }
        case NB_FUNC_ROOT_ACCESS_GET_CONT_DEF:
            {
                response.output.objects.push_back(m_parent_cont_data.definition);
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE:
            {
                //assert(1 == request.input.size());
                //assert(request.input[0].is_object_integer());
                if(1 != request.input.size())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
                if(!request.input[0].is_object_integer())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_INVALID);
                }
                
                int idx; 
                request.input[0].get_value(idx);
                
                int sz = m_parent_cont_data.storages.size();
                //assert(idx >= 0 && idx < sz);
                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_STORAGE_INDEX_INVALID);
                }

                nb_id_t nb_st;
                storage_id_t st = m_parent_cont_data.storages[idx];
                st.to_nb_id(nb_st);
                response.output.objects.push_back(nb_st);
                //response.output.storages.push_back(m_parent_cont_data.storages[idx]);
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE:
            {
                //assert(1 == request.input.size());
                //assert(request.input[0].is_object_integer());
                if(1 != request.input.size())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
                if(!request.input[0].is_object_integer())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_INVALID);
                }

                int idx; 
                request.input[0].get_value(idx);
                
                int sz = m_parent_cont_data.storages.size();
                //assert(idx >= 0 && idx < sz);
                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_STORAGE_INDEX_INVALID);
                }

                nb_id_t type = nb_id_t(NBID_TYPE_OBJECT_INT);
                int tp = m_parent_cont_data.storages[idx].get_type();
                type.set_value(tp);

                response.output.objects.push_back(type);
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR:
            {
                //assert(1 == request.input.size());
                //assert(request.input[0].is_object_integer());
                if(1 != request.input.size())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
                if(!request.input[0].is_object_integer())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_INVALID);
                }
                
                int idx; 
                request.input[0].get_value(idx);
                
                int sz = m_parent_cont_data.anchors.size();
                //assert(idx >= 0 && idx < sz);
                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_ANCHOR_INDEX_INVALID);
                }

                nb_id_t nb_anch;
                anchor_id_t anch = m_parent_cont_data.anchors[idx];
                anch.to_nb_id(nb_anch);
                response.output.objects.push_back(nb_anch);
                //response.output.anchors.push_back(m_parent_cont_data.anchors[idx]);
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
            {
                assert(m_pHelper);

                if(1 != request.input.size())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
                if(!request.input[0].is_object_integer())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_INVALID);
                }
                
                int idx; 
                request.input[0].get_value(idx);
                
                int sz = m_parent_cont_data.anchors.size();

                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_ANCHOR_INDEX_INVALID);
                }

                req_num_t req_num = generate_req_num();    
                begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR);

                return m_pHelper->ac_anchor_get_value_async(m_parent_cont_data.anchors[idx], 
                        req_num);
            }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            {
                assert(m_pHelper);

                if(1 != request.input.size())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
                if(!request.input[0].is_object_integer())
                {
                    return run_exception_respond(request.transaction_id, CORPSE_INPUT_INVALID);
                }
                
                int idx; 
                request.input[0].get_value(idx);
                
                int sz = m_parent_cont_data.anchors.size();

                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(request.transaction_id, CORPSE_ANCHOR_INDEX_INVALID);
                }

                req_num_t req_num = generate_req_num();    
                begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR);
                insert_num_param_pair(req_num, request);

                return m_pHelper->ac_anchor_get_value_async(m_parent_cont_data.anchors[idx], 
                        req_num);
            }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS:
            {
                // TODO:
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST:
            {
                response.output.anchors = m_parent_cont_data.anchors;
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST:
            { 
                response.output.storages = m_parent_cont_data.storages;
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT:
        { 
            //TODO
            break;
        }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHORS:
        {
            m_anchor_num = 0;
            m_accesses.clear();
            m_accesses.resize(m_parent_cont_data.anchors.size());

            for(size_t i = 0; i < m_parent_cont_data.anchors.size(); ++i)
            {
                req_num_t req_num = generate_req_num();    
                begin_incoming_ins_call(req_num, NB_FUNC_ROOT_ACCESS_GET_ANCHORS);
                m_req_anchor_map.begin_incoming_req_info(req_num, i);

                m_pHelper->ac_anchor_get_value_async(m_parent_cont_data.anchors[i], 
                        req_num);
            }
            return true; 
        }
        case NB_FUNC_ROOT_ACCESS_GET_STORAGES:
        {
            for(uint32_t index = 0; index < m_parent_cont_data.storages.size(); ++index)
            {
                nb_id_t nb_st;
                storage_id_t st = m_parent_cont_data.storages[index];
                st.to_nb_id(nb_st);
                response.output.objects.push_back(nb_st);
            }
            break;
        }
        default:
           break;
    }

    response.success = true;
    return run_respond(response);
}

bool func_access::get_anchor_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_access::get_anchor_value_async_response()");

    node_invocation_response response;
    nb_builtin_instruction_t builtin_ins;

    response.child_transaction = m_param.transaction_id;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_access::get_anchor_value_response() failed");

        return run_exception_respond(m_param.transaction_id);
    }

    anchor_data_t an_data;
    anchor_implementation::unpack(output, an_data);

    switch(builtin_ins)
    {
        case NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR:
            {
                int idx; 

                m_param.input[0].get_value(idx);
                int sz = m_parent_cont_data.anchors.size();
                //assert(idx >= 0 && idx < sz);
                if(idx < 0 || idx >= sz)
                {
                    return run_exception_respond(m_param.transaction_id, CORPSE_ANCHOR_INDEX_INVALID);
                }

                access_id_t access_id;
                generate_access_from_anchor(an_data, idx, access_id);

                response.output.objects.push_back(access_id);
                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_ANCHORS:
            {
                int an_idx;
                if (!m_req_anchor_map.get_req_info(req_num, an_idx))
                    return run_exception_respond(m_param.transaction_id);

                access_id_t access_id;
                generate_access_from_anchor(an_data, an_idx, access_id);
                m_accesses[an_idx] = access_id;
                m_anchor_num++;

                if (m_anchor_num == m_parent_cont_data.anchors.size())
                {
                    response.output.objects = m_accesses;
                }
                else
                    return true;

                break;
            }
        case NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR:
            {
                response.output.objects.push_back(an_data.interface);
                break;
            }
        case NB_FUNC_GENERAL_START:
            {
                LOG_NOTICE("$$$$$$$$$$$$$$$$$ parent container name:"<< m_parent_cont_data.name);
                LOG_NOTICE("$$$$$$$$$$$$$$$$$ anchor name:"<< an_data.name);
                LOG_NOTICE("$$$$$$$$$$$$$$$$$ access id:"<< m_obj_id.str());
                LOG_NOTICE("$$$$$$$$$$$$$$$$$ declaration id:"<< m_param.declaration_id.str());

                for (func_vector_const_it it = an_data.funcs.begin();
                        it != an_data.funcs.end();
                        ++it)
                {
                    if ((it->declaration_id == m_param.declaration_id) 
                            && (it->implementation_id.is_object_exec_implementation()))
                    {
                        node_invocation_request req = m_param;
                        req.container_id = m_cData.parent_container;
                        req.object_id = m_obj_id;
                        return object_run(it->implementation_id, req_num, req);
                    }
                }

                std::string strval;
                ac_object_db_impl::instance().read(m_param.declaration_id.str(), strval);
                if (!strval.empty())
                {
                    content tmp_content;
                    decl_compound_data_t decl_data;
                    nb_id_t id;

                    data_unpacker::unpack_from_stream(strval, tmp_content);
                    obj_impl_decl_compound::unpack(tmp_content, id, decl_data);

                    LOG_ERROR("$$$$$$$$$$$$$$$$$ parent container name:"<< m_parent_cont_data.name);
                    LOG_ERROR("$$$$$$$$$$$$$$$$$ anchor name:"<< an_data.name);
                    LOG_ERROR("func_access::get_anchor_value_response():not find the relative impl with in decl="<<decl_data.name);
                }
                
                
                break; 
            }
        default:
           break;
    }
    response.success = true;
    return run_respond(response);
}

bool func_access::bridge_send_out_response(req_num_t req_num, nb_id_t& output)
{
    LOG_DEBUG("*** func_access::bridge_send_out_response()");

    node_invocation_response response;

    response.child_transaction = m_param.transaction_id;
    response.success = true;
    response.output.objects.push_back(output);
    return run_respond(response);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
