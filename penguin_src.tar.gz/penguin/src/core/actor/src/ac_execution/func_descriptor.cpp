/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/func_descriptor.h"
#include "ac_object/obj_impl_decl_compound.h"

func_descriptor::func_descriptor(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_descriptor());

    nb_id_t id;
    obj_impl_descriptor::unpack(raw_data, id, m_cData);
    //assert(m_obj_id == id);
} 

func_descriptor::~func_descriptor()
{
} 

bool func_descriptor::get_name(nb_id_t& out)
{
	return request_string_object(m_cData.name, out); 
}

bool func_descriptor::get_function(const nb_id_t& decl_id, nb_id_t& impl_id)
{
    LOG_DEBUG("func_descriptor::get implementation:" << decl_id.str());

    for (func_vector_const_it it = m_cData.funcs.begin(); it != m_cData.funcs.end(); ++it)
    {
        if (it->declaration_id == decl_id)
        {
            impl_id = it->implementation_id;
            return true; 
        }
    }

    return false; 
}

bool func_descriptor::get_subobj_ifs(nb_id_vector& interfaces)
{
    interfaces = m_cData.subobj_interfaces;
    return true; 
}

bool func_descriptor::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_descriptor::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_DESCRIPTOR);
    return true;
}

bool func_descriptor::run()
{ 
    LOG_DEBUG("*** func_descriptor::run()");

    bool ret = false;
    node_invocation_response output;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            output.output.objects.push_back(result);
            break;
        }
    	case NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION:
    	{
    	    //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    
    	    nb_id_t impl_id;
    	    ret = get_function(m_param.input[0], impl_id);
    	    output.output.objects.push_back(impl_id);
    	    break;
    	}
    	case NB_FUNC_DESCRIPTOR_GET_SUBOBJ_INTERFACES:
    	    ret = get_subobj_ifs(output.output.objects);
    	    break;
    	default:
    	    break;
    }

    output.success = ret;
	output.child_transaction = m_param.transaction_id;
	return run_respond(output);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
