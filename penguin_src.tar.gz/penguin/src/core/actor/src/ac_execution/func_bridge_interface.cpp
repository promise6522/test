/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/func_bridge_interface.h"

func_bridge_interface::func_bridge_interface() 
{
} 

func_bridge_interface::func_bridge_interface(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_interface_bridge());
    
    nb_id_t id;
    obj_impl_bridge_interface::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

func_bridge_interface::~func_bridge_interface()
{
} 

bool func_bridge_interface::get_name(nb_id_t& out)
{
	return request_string_object(m_cData.external_name, out); 
}

bool func_bridge_interface::eq(const nb_id_t& if_id)
{
    LOG_DEBUG("func_bridge_interface::eq");

    req_num_t req_num = generate_req_num();    
    begin_incoming_ins_call(req_num, NB_FUNC_BRIDGE_INTERFACE_EQ);

    return m_pHelper->ac_object_get_value_async(if_id, req_num);
}

bool func_bridge_interface::cover(const nb_id_t& if_id)
{
    req_num_t req_num = generate_req_num();    
    begin_incoming_ins_call(req_num, NB_FUNC_BRIDGE_INTERFACE_COVERS);

    return m_pHelper->ac_object_get_value_async(if_id, req_num);
}

bool func_bridge_interface::run()
{ 
    bool ret = true;
    node_invocation_response output;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            output.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INTERFACE_EQ:
        case NB_FUNC_BRIDGE_INTERFACE_EQ:
        {
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }

            if (!m_param.input[0].is_object_bridge_interface())
                output.output.objects.push_back(false);
            else if (m_obj_id == m_param.input[0])
                output.output.objects.push_back(true);
            else
                return eq(m_param.input[0]);

            break;
        }

        case NB_FUNC_INTERFACE_COVERS:
        case NB_FUNC_BRIDGE_INTERFACE_COVERS:
        {
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }

            if (m_param.input[0].is_interface_none())
                output.output.objects.push_back(true);
            else if (!m_param.input[0].is_object_bridge_interface())
                output.output.objects.push_back(false);
            else if (m_obj_id == m_param.input[0])
                output.output.objects.push_back(true);
            else
                return cover(m_param.input[0]);

            break;
        }
        case NB_FUNC_INTERFACE_CONVERT:
        {
            if (1 != m_param.input.size() 
                    || !m_param.input[0].is_bridge_object())
                return run_exception_respond(m_param.transaction_id);

            req_num_t req_num = generate_req_num();    

            begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_INTERFACE);

            node_invocation_request request = m_param;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);
            return object_run(m_param.input[0], req_num, request);
        }
        case NB_FUNC_INTERFACE_GET_DECLARATIONS:
        {
            nb_id_t decls_array_id;
            generate_array(m_cData.decls, NB_INTERFACE_DECLARATION, decls_array_id);
            output.output.objects.push_back(decls_array_id);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    output.success = ret;
    output.child_transaction = m_param.transaction_id;
    return run_respond(output);
}

// response
bool func_bridge_interface::cover_response(const bridge_interface_data_t& in, nb_id_t& result)
{
    LOG_DEBUG("func_bridge_interface::cover_response");

    bool ret = true;
    if(m_cData.external_name != "TAbstractVisible" && in.external_name != "TAbstractVisible" &&
       m_cData.external_name != "TNone"            && in.external_name != "TNone")
    {        
        if(m_cData.external_name != in.external_name)
            ret = false;
        else if(m_cData.sub_names.size() != in.sub_names.size())
            ret = false;
        else
        {
            for (size_t i = 0; i < m_cData.sub_names.size(); ++i)
            {
                if(m_cData.sub_names[i] != in.sub_names[i])
                {
                    ret = false;
                    break;
                }
            }
        }
    }    

    result = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    result.set_value(ret);

    return true; 
}

bool func_bridge_interface::eq_response(const bridge_interface_data_t& in, nb_id_t& result)
{
    LOG_DEBUG("func_bridge_interface::eq_response");

    bool ret = true;
    
    if(m_cData.external_name != in.external_name)
        ret = false;
    else if(m_cData.sub_names.size() != in.sub_names.size())
        ret = false;
    else
    {
        for (size_t i = 0; i < m_cData.sub_names.size(); ++i)
        {
            if(m_cData.sub_names[i] != in.sub_names[i])
            {
                ret = false;
                break;
            }
        }
    }

    result = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    result.set_value(ret);

    return true; 
}

bool func_bridge_interface::get_value_response(req_num_t req_num, 
        content& output)
{
    LOG_DEBUG("*** func_bridge_interface::get_value_response");

    node_invocation_response response;
    nb_builtin_instruction_t builtin_ins;

    response.child_transaction = m_param.transaction_id;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_bridge_interface::get_value_response() failed");
        return run_exception_respond(m_param.transaction_id);
    }

    bridge_interface_data_t data;
    nb_id_t id;
    obj_impl_bridge_interface::unpack(output, id, data);

    switch (builtin_ins)
    {

        case NB_FUNC_BRIDGE_INTERFACE_EQ:
            {
                nb_id_t result;
                eq_response(data, result);
                response.output.objects.push_back(result);

                break;
            } 
        case NB_FUNC_BRIDGE_INTERFACE_COVERS:
            {
                nb_id_t result;
                cover_response(data, result);
                response.output.objects.push_back(result);

                break;
            } 
        case NB_FUNC_GENERAL_RUN:
            return execution_base::get_value_response(req_num, output);

        default:
            break;
    }

    response.success = true;
    return run_respond(response);
}

bool func_bridge_interface::obj_run_response(req_num_t req_num, 
        node_invocation_response& output)
{
    LOG_DEBUG("*** func_bridge_interface::obj_run_response()");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {

        LOG_ERROR("func_bridge_interface::obj_run_response() failed"); 
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    end_incoming_ins_call(req_num);

    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_GET_INTERFACE:
            {
                LOG_DEBUG("NB_FUNC_GENERAL_GET_INTERFACE");

                if ((1 != output.output.objects.size()) 
                        || !output.output.objects[0].is_interface_bridge())
                {
                    return run_exception_respond(m_param.transaction_id);
                }

                begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_CONVERT);

                node_invocation_request cover_req = m_param;
                cover_req.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
                cover_req.input.clear();
                cover_req.input.push_back(m_obj_id);

                return object_run(output.output.objects[0], req_num, cover_req);
            }
        case NB_FUNC_INTERFACE_CONVERT:
            {
                LOG_DEBUG("NB_FUNC_INTERFACE_CONVERT");

                if ((1 != output.output.objects.size()) 
                        || !output.output.objects[0].is_object_bool())
                {
                    return run_exception_respond(m_param.transaction_id);
                }

                node_invocation_response response;
                response.success = true;
                response.child_transaction = m_param.transaction_id;

                bool ret;  
                output.output.objects[0].get_value(ret);

                if (ret)
                {
                    response.output.objects.push_back(m_param.input[0]);
                }
                else
                {
                    nb_id_t result = nb_id_t(NBID_TYPE_OBJECT_NONE);
                    response.output.objects.push_back(result);
                }

                return run_respond(response);

            }
        default:
            LOG_ERROR("func_bridge_interface::obj_run_response():invalid calling instruction");
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            break;
    }

}

// vim:set tabstop=4 shiftwidth=4 expandtab:
