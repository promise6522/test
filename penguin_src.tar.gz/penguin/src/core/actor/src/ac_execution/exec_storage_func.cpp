/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/exec_storage_func.h"
#include "ac_container/container_implementation.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_map.h"
#include "ac_container/storage_implementation.h"
#include "ac_object/obj_impl_decl_expanded.h"

exec_storage_func::exec_storage_func(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_object_exec_storage_func());
    nb_id_t id;
    obj_impl_exec_storage_func::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

exec_storage_func::~exec_storage_func()
{
}

bool exec_storage_func::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool exec_storage_func::get_declaration(nb_id_t& decl_id)
{
    return true;
}

bool exec_storage_func::set_type(const nb_id_t& type_id)
{
    return true;
}

bool exec_storage_func::get_type(nb_id_t& type_id)
{
    return true;
}

// new functions
bool exec_storage_func::get_single()
{
    LOG_DEBUG(" ***** exec_storage_func::get_single() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    storage_key  key_id;
    key_id.key = m_param.input[0];

    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_get_single(m_facade, req_num, key_id);
}

bool exec_storage_func::get_more()
{
    LOG_DEBUG(" ***** exec_storage_func::get_more() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_GET_MORE);

    return object_get_value_async(m_param.input[0], req_num);
}

bool exec_storage_func::has_key()
{
    LOG_DEBUG(" ***** exec_storage_func::has_key() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
 
    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_HAS_KEY);
   
    return object_get_value_async(m_param.input[0], req_num);
}

bool exec_storage_func::replace_one()
{
    LOG_DEBUG(" ***** exec_storage_func::replace_one() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
  
    key_obj_id  key_obj;
    key_obj.key_id = m_param.input[0];
    key_obj.obj_id = m_param.input[1];

    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_replace_one(m_facade, req_num, key_obj);
}

bool exec_storage_func::delete_one()
{
    LOG_DEBUG(" ***** exec_storage_func::delete_one() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
   
    storage_key  key_id;
    key_id.key = m_param.input[0];

    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_delete_one(m_facade, req_num, key_id);
}

bool exec_storage_func::set_one()
{
    LOG_DEBUG(" ***** exec_storage_func::set_one() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
  
    key_obj_id  key_obj;
    key_obj.key_id = m_param.input[0];
    key_obj.obj_id = m_param.input[1];

    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_set_one(m_facade, req_num, key_obj);
}

bool exec_storage_func::update()
{
    LOG_DEBUG(" ***** exec_storage_func::update() ***** ");

    assert(NULL != m_pHelper);

    if(m_param.input.size() != 3)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
 
    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_DELETE_ONE);

    return object_get_value_async(m_param.input[0], req_num);
}

bool exec_storage_func::size()
{
    LOG_DEBUG(" ***** exec_storage_func::size() ***** "); 
    
    assert(NULL != m_pHelper); 
    
    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_size(m_facade, req_num);
}

bool exec_storage_func::get_range()
{
    LOG_DEBUG(" ***** exec_storage_func::get_range() ***** "); 
    
    assert(NULL != m_pHelper); 
   
    if (m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
    
    int input0, input1;
    m_param.input[0].get_value(input0);
    m_param.input[1].get_value(input1);

    if (input0 > input1 || input0 < 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    key_pair input;
    input.start_num = input0;
    input.end_num   = input1;

    req_num_t req_num = generate_req_num();
    return m_pHelper->ac_storage_facade_get_range(m_facade, req_num, input);
}

bool exec_storage_func::run()
{ 
    LOG_DEBUG("*** exec_storage_func::run()");

    if (m_cData.selected_decl != m_param.declaration_id)
        return run_exception_respond(m_param.transaction_id, CORPSE_STORAGE_RUN_FAILED);

    req_num_t req_num = generate_req_num();
    
    // get storage from parent container 
    assert(m_pHelper);
    return m_pHelper->ac_container_get_value_async(m_param.container_id, req_num);
}

bool exec_storage_func::get_container_value_response(req_num_t req_num, con_content& output)
{
    LOG_DEBUG("*** exec_storage_func::get_container_value_async_response()");

    container_id_t id;
    container_data_t cont_data;
    container_implementation::unpack(output, id, cont_data);

    int st =  cont_data.storages.size();
    if ((m_cData.storage_idx < 0) || (m_cData.storage_idx >= st))
    {
        LOG_NOTICE("exec_storage_func::storage index invalid"<<m_cData.storage_idx);
        return run_exception_respond(m_param.transaction_id);
    }

    request_facade_id_info facade_info;

    facade_info.container_id = m_param.container_id;
    facade_info.storage_id = cont_data.storages[m_cData.storage_idx];
    facade_info.committer_id = m_param.host_committer_id;

    // record the storage_id and facade_id
    m_storage = facade_info.storage_id;

    assert(m_pHelper);
    m_pHelper->ac_host_committer_request_or_get_facade_id(m_param.host_committer_id, facade_info, m_facade);

    // get the storage's data_value
    return m_pHelper->ac_storage_get_value_async(m_storage, req_num);
}

bool exec_storage_func::get_storage_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_storage_func::get_storage_value_async_response()");

    storage_data_t st_data;
    storage_implementation::unpack(output, st_data);

    begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_INTERFACE);
    return object_get_value_async(st_data.interface, req_num);
}

bool exec_storage_func::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_storage_func::get_value_response");

    nb_builtin_instruction_t  builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("exec_storage_func::instruction doesn't exist.");
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    end_incoming_ins_call(req_num);

    if (builtin_ins == NB_FUNC_GENERAL_GET_DECLARATION)
    {
        decl_expanded_data_t  data;
        nb_id_t               id;
        obj_impl_decl_expanded::unpack(output, id, data);

        if(!data.origin_decl_id.is_object_declaration())
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

        switch (data.origin_decl_id.get_func_type())
        {
            case NB_FUNC_STORAGE_GET_SINGLE:
                return get_single();
            case NB_FUNC_STORAGE_GET_MORE:
                return get_more();
            case NB_FUNC_STORAGE_HAS_KEY:
                return has_key();
            case NB_FUNC_STORAGE_REPLACE_ONE:
                return replace_one();
            case NB_FUNC_STORAGE_DELETE_ONE:
                return delete_one();
            case NB_FUNC_STORAGE_SET_ONE:
                return set_one();
            case NB_FUNC_STORAGE_UPDATE:
                return update();
            case NB_FUNC_STORAGE_SIZE:
                return size();
            case NB_FUNC_STORAGE_GET_RANGE:
                return get_range();
            default:
                {
                    LOG_ERROR("exec_storage_func::invalid instruction");
                    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
                }
        }

    }
    else if (builtin_ins == NB_FUNC_GENERAL_GET_INTERFACE)
    {
        if_compound_data_t   data;
        nb_id_t              id;
        obj_impl_interface_compound::unpack(output, id, data);
        
        if(data.groups.size() != 2)
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

        m_key_if = data.groups[0].min_if;
        m_val_if = data.groups[1].min_if;

        // get name of declaration
        begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_DECLARATION);

        return object_get_value_async(m_param.declaration_id, req_num);
    }
    else if (builtin_ins == NB_FUNC_STORAGE_HAS_KEY || builtin_ins == NB_FUNC_STORAGE_GET_MORE)
    {
        array_data_t  array_data;
        nb_id_t       array_id;
        obj_impl_array::unpack(output, array_id, array_data);

        key_array     key_ids;
        for (nb_id_vector_it it = array_data.objs.begin(); it != array_data.objs.end(); ++it)
            key_ids.keys.push_back(*it);

        if (builtin_ins == NB_FUNC_STORAGE_GET_MORE)
            return m_pHelper->ac_storage_facade_get_more(m_facade, req_num, key_ids);
        else if (builtin_ins == NB_FUNC_STORAGE_HAS_KEY)
            return m_pHelper->ac_storage_facade_has_key(m_facade, req_num, key_ids);
    }
    else if (builtin_ins == NB_FUNC_STORAGE_DELETE_ONE)
    {
        array_data_t  array_data;
        nb_id_t       array_id;
        obj_impl_array::unpack(output, array_id, array_data);

        sv_update_input update_input;

        for (nb_id_vector_it it = array_data.objs.begin(); it != array_data.objs.end(); ++it)
            update_input.sv_d_update_input.keys.push_back(*it);

        m_update_map.begin_incoming_req_info(req_num, update_input);
        begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_SET_ONE);

        return object_get_value_async(m_param.input[1], req_num);
    }
    else if (builtin_ins == NB_FUNC_STORAGE_SET_ONE)
    {
        map_data_t    map_data;
        nb_id_t       map_id;
        obj_impl_map::unpack(output, map_id, map_data);

        sv_update_input update_input;

        m_update_map.get_req_info(req_num, update_input);
        m_update_map.end_incoming_req_info(req_num);

        key_obj_id  key_obj;
        for (nb_id_map_it it = map_data.data.begin(); it != map_data.data.end(); ++it)
        {
            key_obj.key_id = it->first;
            key_obj.obj_id = it->second;
            update_input.sv_s_update_input.push_back(key_obj);
        }

        begin_incoming_ins_call(req_num, NB_FUNC_STORAGE_REPLACE_ONE);
        m_update_map.begin_incoming_req_info(req_num, update_input);

        return object_get_value_async(m_param.input[2], req_num); 
    }
    else if (builtin_ins == NB_FUNC_STORAGE_REPLACE_ONE)
    {
        map_data_t    map_data;
        nb_id_t       map_id;
        obj_impl_map::unpack(output, map_id, map_data);

        sv_update_input update_input;

        m_update_map.get_req_info(req_num, update_input);
        m_update_map.end_incoming_req_info(req_num);

        key_obj_id  key_obj;
        for (nb_id_map_it it = map_data.data.begin(); it != map_data.data.end(); ++it)
        {
            key_obj.key_id = it->first;
            key_obj.obj_id = it->second;
            update_input.sv_r_update_input.push_back(key_obj);
        }

        return m_pHelper->ac_storage_facade_update(m_facade, req_num, update_input);
    }

    LOG_ERROR("exec_storage_func::get_value_response() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
}

// new function_responses
bool exec_storage_func::storage_facade_get_single_response(req_num_t req_num, const object_id& output)
{
    if (output.id.get_type() == NBID_TYPE_NULL)
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

    node_invocation_response response;

    response.output.objects.push_back(output.id);
    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_get_more_response(req_num_t req_num, const key_pair_no_version1& output)
{
    nb_id_t map_id;
    node_invocation_response response;

    if (generate_map(output.key_obj_ids, m_key_if, m_val_if, map_id))
        response.output.objects.push_back(map_id);
    else
    {
        LOG_ERROR("request map_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_has_key_response(req_num_t req_num, const key_array& output)
{
    nb_id_t array_id;
    node_invocation_response response;
    
    if (generate_array(output.keys, m_key_if, array_id))
        response.output.objects.push_back(array_id);
    else
    {
        LOG_ERROR("request array_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_replace_one_response(req_num_t req_num, const object_id& output)
{
    if (output.id.get_type() == NBID_TYPE_NULL)
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

    node_invocation_response response;

    response.output.objects.push_back(output.id);
    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_delete_one_response(req_num_t req_num, const object_id& output)
{
    if (output.id.get_type() == NBID_TYPE_NULL)
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

    node_invocation_response response;

    response.output.objects.push_back(output.id);
    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_set_one_response(req_num_t req_num, const bool& output)
{
    node_invocation_response response;

    nb_id_t out(NBID_TYPE_OBJECT_BOOL);
    out.set_value(output);
    
    response.output.objects.push_back(out);
    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_update_response(req_num_t req_num, const sv_update_output& output)
{
    nb_id_t                  obj_id;
    node_invocation_response response;
 
    if (generate_array(output.sv_d_update_output.keys, m_val_if, obj_id))
        response.output.objects.push_back(obj_id);
    else
    {
        LOG_ERROR("request array_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    if (generate_array(output.sv_s_update_output.keys, m_key_if, obj_id))
        response.output.objects.push_back(obj_id);
    else
    {
        LOG_ERROR("request array_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    if (generate_map(output.sv_r_update_output, m_key_if, m_val_if, obj_id))
        response.output.objects.push_back(obj_id);
    else
    {
        LOG_ERROR("request map_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_size_response(req_num_t req_num, const int& output)
{
    node_invocation_response response;

    nb_id_t out(NBID_TYPE_OBJECT_INT);
    out.set_value(output);

    response.output.objects.push_back(out);
    return storage_facade_respond(response);
}

bool exec_storage_func::storage_facade_get_range_response(req_num_t req_num, const key_pair_no_version1& output)
{
    nb_id_t map_id;
    node_invocation_response response;

    if (generate_map(output.key_obj_ids, m_key_if, m_val_if, map_id))
        response.output.objects.push_back(map_id);
    else
    {
        LOG_ERROR("request map_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return storage_facade_respond(response);
}

// helper func, called by other concrete response funcs
bool exec_storage_func::storage_facade_respond(node_invocation_response& response)
{
    LOG_DEBUG("*** exec_storage_func::storage_facade_respond()");

    response.success = true;
    response.child_transaction = m_param.transaction_id;

    /* get m_call_id for run_respond() to respond */
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
