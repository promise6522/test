/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_integer.h"
#include "ac_object/obj_algorithm.h"

bool func_integer::get_name(nb_id_t& out)
{
#if 0
    int value;
    m_obj_id.get_value(value);

    char    sbuf[30];
    memset(sbuf, 0, sizeof(sbuf));
    sprintf(sbuf, "int_%d", value);

    std::string strs(sbuf);
    return request_string_object(strs, out); 
#endif
	return request_string_object("integer", out); 
}

bool func_integer::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_integer::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_integer::add(const nb_id_t& in, nb_id_t& out)
{
    int value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 + value2);

    return true;
}

bool func_integer::sub(const nb_id_t& in, nb_id_t& out)
{
    int value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 - value2);
    return true;
}

bool func_integer::imul(const nb_id_t& in, nb_id_t& out)
{
    int value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 * value2);

    return true;
}

bool func_integer::idiv(const nb_id_t& in, nb_id_t& out)
{
    int value2;
    in.get_value(value2);

    if (0 == value2)
        return false;

    int value1;
    m_obj_id.get_value(value1);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 / value2);

    return true;
}

bool func_integer::idiv_remainder(const nb_id_t& in, nb_id_t& out1, nb_id_t& out2)
{
    int value1;
    m_obj_id.get_value(value1);

    int value2;
    in.get_value(value2);

    out1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out1.set_value(value1 / value2);

    out2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out2.set_value(value1 % value2);

    return true;
}

bool func_integer::eq(const nb_id_t& in, nb_id_t& out)
{
    int value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 == value2);

    return true;
}

bool func_integer::lt(const nb_id_t& in, nb_id_t& out)
{
    int value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 < value2);

    return true;
}

bool func_integer::inc(nb_id_t& out)
{
    int value1;
    m_obj_id.get_value(value1);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 + 1);

    return true;
}

bool func_integer::dec(nb_id_t& out)
{
    int value1;
    m_obj_id.get_value(value1);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value1 - 1);

    return true;
}

bool func_integer::to_string(nb_id_t& out)
{
    std::string str1;
    int value;
    m_obj_id.get_value(value);
    str1 = boost::lexical_cast<std::string>(value);
    return request_string_object(str1, out);
}

bool func_integer::to_float(nb_id_t& out)
{
    int value;
    m_obj_id.get_value(value);

    float f1;
    f1 = static_cast<float>(value);
    out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    out.set_value(f1);
    return true;
}

bool func_integer::run()
{
    LOG_DEBUG("*** func_integer::run() ");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INT_ADD:
        {
            nb_id_t result; 
            ret = add(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer add: " << value);
    
            break;
        }
        case NB_FUNC_INT_SUB:
        {
            nb_id_t result; 
            ret = sub(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer sub: " << value);
    
            break;
        }
        case NB_FUNC_INT_IMUL:
        {
            nb_id_t result; 
            ret = imul(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer mul: " << value);
    
            break;
        }
        case NB_FUNC_INT_IDIV:
        {
            nb_id_t result; 
            ret = idiv(m_param.input[0], result);
            if (!ret)
                return run_exception_respond(m_param.transaction_id, CORPSE_IDIV_INPUT_IS_ZERO);
    
            response.output.objects.push_back(result);
    
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer div: " << value);
    
            break;
        }
        case NB_FUNC_INT_IDIV_REM:
        {
            nb_id_t result1, result2;
            ret = idiv_remainder(m_param.input[0], result1, result2);
            if(!ret)
                return run_exception_respond(m_param.transaction_id, CORPSE_IDIV_INPUT_IS_ZERO);
            response.output.objects.push_back(result1);
            response.output.objects.push_back(result2);
    
            int value1, value2;
            result1.get_value(value1);
            result2.get_value(value2);
            LOG_NOTICE("######### The result of interger div: " << value1 << "remainder: " << value2);
            
            break;
        }
        case NB_FUNC_INT_EQ:
        {
            nb_id_t result; 
            ret = eq(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* Debug */
            bool value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer eq: " << std::boolalpha << value);
    
            break;
        }
        case NB_FUNC_INT_LT:
        {
            nb_id_t result; 
            ret = lt(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* Debug */
            bool value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer lt: " << std::boolalpha << value);
    
            break;
        }
        case NB_FUNC_INT_INC:
        {
            nb_id_t result; 
            ret = inc(result);
            response.output.objects.push_back(result);
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer inc: " << value);
    
            break;
        }
        case NB_FUNC_INT_DEC:
        {
            nb_id_t result; 
            ret = dec(result);
            response.output.objects.push_back(result);
            /* Debug */
            int value;
            result.get_value(value);
            LOG_NOTICE("########## The result of integer dec: " << value);
    
            break;
        }
        case NB_FUNC_INT_TO_STRING:
        {
            nb_id_t result;
            ret = to_string(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_INT_TO_FLOAT:
        {
            nb_id_t result;
            ret = to_float(result);
            response.output.objects.push_back(result);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
