/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/exec_obj_func.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_db/ac_object_db_impl.h"

exec_obj_func::exec_obj_func(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_object_exec_obj_func());
    nb_id_t id;    
    obj_impl_exec_obj_func::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);    
} 

exec_obj_func::~exec_obj_func()
{
}

bool exec_obj_func::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool exec_obj_func::get_declaration(nb_id_t& decl_id)
{
    return true;
}

bool exec_obj_func::set_type(const nb_id_t& type_id)
{
    return true;
}

bool exec_obj_func::get_type(nb_id_t& type_id)
{
    return true;
}


bool exec_obj_func::run()
{ 
    LOG_DEBUG("*** exec_obj_func::run()");

    LOG_NOTICE("owner id:"<<m_param.object_id.str());
    LOG_NOTICE("selected decl id:"<<m_cData.selected_decl.str());
    LOG_NOTICE("param decl id:"<<m_param.declaration_id.str());

    if (!m_param.object_id.is_object() || m_cData.selected_decl != m_param.declaration_id)
    {
        LOG_INFO("exec_obj_func::run() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    req_num_t req_num = generate_req_num();    
    if (m_param.object_id.is_object_access())
    {
        begin_incoming_ins_call_out(req_num, NB_FUNC_GENERAL_START);
        begin_incoming_call(req_num, m_call_id);

        access_id_t access_id; 
        m_param.object_id.to_access_id(access_id);

        return access_run(access_id, req_num, m_param);
    }
    else// other type of objects
    {
        nb_id_t obj_id = m_param.object_id;
        return object_run(obj_id, req_num, m_param);
    }

    return false;
}

bool exec_obj_func::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("exec_obj_func::obj_run_response()");

    if (!output.success)
    {
        LOG_ERROR("exec_obj_func::obj_run_response() failed");
        if (output.corpse_type >= CORPSE_GENERAL_ERROR_TYPE && output.corpse_type < CORPSE_TYPE_MAX)
            return run_respond(output);
        else
//        m_result = output;
            return run_exception_respond(output.child_transaction, CORPSE_OBJ_RUN_FAILED);
    }

    return run_respond(output);
}

bool exec_obj_func::access_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("exec_obj_func::access_run_response()");

    if (!output.success)
    {
        LOG_ERROR("exec_obj_func::access_run_response() failed");
        if (output.corpse_type >= CORPSE_GENERAL_ERROR_TYPE && output.corpse_type < CORPSE_TYPE_MAX)
            return run_respond(output);
        else
            return run_exception_respond(output.child_transaction, CORPSE_OBJ_RUN_FAILED);
//            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    return run_respond(output);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
