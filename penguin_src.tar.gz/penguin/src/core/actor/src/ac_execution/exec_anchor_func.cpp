/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/exec_anchor_func.h"
#include "ac_container/container_implementation.h"
#include "ac_container/anchor_implementation.h"

exec_anchor_func::exec_anchor_func(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_object_exec_anchor_func());

    nb_id_t id;    
    obj_impl_exec_anchor_func::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
}

exec_anchor_func::~exec_anchor_func()
{
}

bool exec_anchor_func::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool exec_anchor_func::get_declaration(nb_id_t& decl_id)
{
    return true;
}

bool exec_anchor_func::set_type(const nb_id_t& type_id)
{
    return true;
}

bool exec_anchor_func::get_type(nb_id_t& type_id)
{
    return true;
}

bool exec_anchor_func::run()
{ 
    LOG_DEBUG("*** exec_anchor_func::run()");

    LOG_NOTICE("owner id:"<<m_param.object_id.str());
    LOG_NOTICE("selected decl id:"<<m_cData.selected_decl.str());
    LOG_NOTICE("param decl id:"<<m_param.declaration_id.str());

    if (m_cData.selected_decl != m_param.declaration_id)
    {
        LOG_INFO("exec_anchor_func::run() failed");
        return run_exception_respond(m_param.transaction_id);
    }

    // get anchor from parent container
    assert(m_pHelper);

    m_req = generate_req_num();    
    return m_pHelper->ac_container_get_value_async(m_param.container_id, m_req);
}

bool exec_anchor_func::get_container_value_response(req_num_t req_num, con_content& output)
{
    LOG_DEBUG("*** exec_anchor_func::get_container_value_response()");

    if (m_req != req_num)
    {
        LOG_ERROR("exec_anchor_func::get_container_value_response() failed");
        return run_exception_respond(m_param.transaction_id);
    }

    container_id_t id;
    container_data_t cont_data;
    container_implementation::unpack(output, id, cont_data);
    //assert(id  == m_param.container_id);

    assert(m_pHelper);

    m_req = generate_req_num();    
    return m_pHelper->ac_anchor_get_value_async(cont_data.anchors[m_cData.anchor_idx], m_req);
}

bool exec_anchor_func::get_anchor_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_anchor_func::get_anchor_value_response()");

    node_invocation_response response;
    response.child_transaction = m_param.transaction_id;

    if (m_req != req_num)
    {
        LOG_ERROR("exec_anchor_func::get_anchor_value_response() failed");
        return run_exception_respond(m_param.transaction_id);
    }

    anchor_data_t an_data;
    anchor_implementation::unpack(output, an_data);

    for (func_vector_const_it it = an_data.funcs.begin(); it != an_data.funcs.end(); ++it)
    {
        if ((it->declaration_id == m_cData.selected_decl) 
                && (it->implementation_id.is_object_exec_implementation()))
        {
            // implementation object run
            req_num_t req_num = generate_req_num();    

            node_invocation_request request = m_param;
            request.container_id = m_param.container_id;
            return object_run(it->implementation_id, req_num, request);
        }
    }

    LOG_ERROR("exec_anchor_func::no implementation matched declaration");
    return run_exception_respond(m_param.transaction_id);
}

bool exec_anchor_func::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("exec_anchor_func::obj_run_response()");
    return run_respond(output);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
