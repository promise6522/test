/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_execution/exe_bridge.h"

exe_bridge::exe_bridge(const nb_id_t& obj_id,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(nb_id_t(NBID_TYPE_OBJECT_NONE), exe_id, pHelper)
{ 
} 

exe_bridge::~exe_bridge()
{
}

bool exe_bridge::trigger_end(call_id_t call_id, bridge_end_response response)
{ 
    LOG_DEBUG("*** exe_bridge::run()");
    m_call_id = call_id;
    m_param.host_committer_id = response.hc_id;

    return run_respond(response.node_response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
