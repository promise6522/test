/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_id_stand_in.h"

bool func_id_stand_in::get_name(nb_id_t& out)
{
    return request_string_object("id_stand_in", out);
}

bool func_id_stand_in::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_id_stand_in::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_id_stand_in::run()
{ 
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
