/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_user.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_decl_expanded.h"
// test
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_db/ac_object_db_impl.h"

func_user::func_user(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_user_object());

    nb_id_t user_id;
    obj_impl_user::unpack(raw_data, user_id, m_cData);
    //assert(user_id == obj_id);

    //set inital state
    m_covered_ifs = 0;
    m_exception_responded = false;
} 


func_user::~func_user()
{
}

bool func_user::get_name(nb_id_t& out)
{
	return request_string_object(m_cData.name, out); 
}

bool func_user::set_interface(const nb_id_t& if_id)
{
    return true;
}

bool func_user::get_interface(nb_id_t& if_id)
{
    if_id = m_cData.interface;
    return true;
}

bool func_user::get_descriptor(nb_id_t& descriptor_id)
{
    descriptor_id = m_cData.descriptor;
    return true;
}

bool func_user::pre_compose()
{
    LOG_DEBUG("*** func_user::pre_compose()");

//    node_invocation_request& input = m_param;
//    if(input.input.size() <= 0)
//    {
//        return run_exception_respond(input.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
//    }

    if (!_TYPE_CHECKING || (m_param.input.size() == 0))
        return do_compose();
    else
    {
        // DO TYPE-CHECKING
        // get descriptor content
        req_num_t req_num = generate_req_num();
        begin_incoming_ins_call(req_num, NB_FUNC_USER_GET_DESCRIPTOR);

        return object_get_value_async(m_cData.descriptor, req_num);
    }
}

bool func_user::do_compose()
{
    LOG_DEBUG("*** func_user::do_compose()");

    user_data_t new_user;

    bool is_singleton = false;

    int in_size = m_param.input.size();
    for (int i = 0; i < in_size; ++i)
    {
        new_user.subobjs.push_back(m_param.input[i]);
        if (m_param.input[i].is_user_object()
                && m_param.input[i].is_singleton())
            is_singleton = true;
    }

    new_user.name = m_cData.name;
    new_user.descriptor = m_cData.descriptor;
    new_user.interface = m_cData.interface;
    //new_user.water_mark = TODO

    // create new object
    request_nb_id_info user_info;
    obj_impl_user::pack(new_user, nb_id_t(), user_info.raw_data);
    user_info.committer_id = m_param.host_committer_id;
    user_info.type = NBID_TYPE_OBJECT_USER;

    nb_id_t user_id;
    if (!request_nb_id(m_param.host_committer_id, 
                user_info,
                user_id))
    {
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id);
    }

    LOG_NOTICE("new object interface after compose:" << new_user.interface.str());
    LOG_NOTICE("new object after compose:" << user_id.str());

    // set singleton
    //if (sing || m_obj_id.is_singleton())
    //    user_id.set_singleton();
    //else
    //    user_id.set_indepence();

    node_invocation_response response;
    response.child_transaction = m_param.transaction_id;
    response.success = true;
    response.output.objects.push_back(user_id);

    return run_respond(response);
}


bool func_user::do_decompose()
{
    LOG_NOTICE("*** func_user::decompose()");

    node_invocation_response output;
    output.output.objects = m_cData.subobjs;//return sub objs
    output.success = true;
    output.child_transaction = m_param.transaction_id;

    return run_respond(output);
}

bool func_user::do_user_defined_decl(const nb_id_t& decl_id)
{
    // get corresponding impl from descriptor
    node_invocation_request request = m_param;
    request.declaration_id = NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION;
    request.input.clear();
    request.input.push_back(decl_id);

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION);
    return object_run(m_cData.descriptor, req_num, request);
}

bool func_user::do_expanded_decl(const nb_id_t& decl_id)
{
    // get expanded_decl's origin declaration
    node_invocation_request request = m_param;
    request.declaration_id = NB_FUNC_DECLARATION_GET_ORIGIN_DECL;
    request.input.clear();

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DECLARATION_GET_ORIGIN_DECL);
    return object_run(decl_id, req_num, request);
}

bool func_user::run()
{ 
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ user run() = "<< m_cData.name);

    bool ret = true;
    node_invocation_response output;

    /* built-in instruction eg. GET_INTERFACE, GET_DESCRIPTOR */
    nb_id_t decl_id = m_param.declaration_id;
    if(decl_id.is_function_instruction())
    {
        switch(decl_id.get_func_type())
        {
            case NB_FUNC_GENERAL_GET_NAME:
            {
                nb_id_t result;
                ret = get_name(result);
                output.output.objects.push_back(result);
                break;
            }
            case NB_FUNC_GENERAL_GET_INTERFACE:
            {
                nb_id_t result;
                ret = get_interface(result);
                LOG_NOTICE("** func_user::get_interface = "<<result.str());

                output.output.objects.push_back(result);
                break;
            } 
            case NB_FUNC_USER_GET_DESCRIPTOR:
            {
                nb_id_t result;
                ret = get_descriptor(result);
                LOG_NOTICE("** func_user::get_descriptor = "<<result.str());

                output.output.objects.push_back(result);
                break;
            }
            default:
                return execution_base::run();
                break;
        }
        output.success = ret;
        output.child_transaction = m_param.transaction_id;
        return run_respond(output);
    }

    /* Compose/Decompose */
    else if(decl_id.is_function_compose())
    {
        return pre_compose();
    }
    else if(decl_id.is_function_decompose())
    {
        return do_decompose();
    }
    /* decl compound */
    else if(decl_id.is_object_decl_compound())
    {
        return do_user_defined_decl(decl_id);
    }
    /* decl expanded */
    else if(decl_id.is_object_decl_expanded())
    {
        return do_expanded_decl(decl_id);
    }

    return true;
}

bool func_user::get_value_response(req_num_t req_num, content& output)
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_user::get_value_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    end_incoming_ins_call(req_num);
    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            return execution_base::get_value_response(req_num, output);
        
        case NB_FUNC_USER_GET_DESCRIPTOR:
        {
            // unpack descriptor data
            descriptor_data_t dp_data;

            nb_id_t id;
            obj_impl_descriptor::unpack(output, id, dp_data);
            m_sub_ifs = dp_data.subobj_interfaces;

            // do type checking
            // get inputs interfaces
            int port_idx = 0;
            for (nb_id_vector_it it = m_param.input.begin(); it != m_param.input.end(); ++it)
            {
                node_invocation_request request = m_param;
                request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);

                req_num_t req_num2 = generate_req_num();
                begin_incoming_ins_call(req_num2, NB_FUNC_GENERAL_GET_INTERFACE);
                set_reqnum_port(req_num2, port_idx);

                if (it->is_object_access()) 
                {
                    access_id_t access_id;
                    it->to_access_id(access_id);
                    access_run(access_id, req_num2, request);
                }
                else if (it->is_object())
                {
                    object_run(*it, req_num2, request);
                }
                else
                {
                    LOG_ERROR("func_user::compose input["<<port_idx<<"] is not a valid object");
                    m_exception_responded = true;
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
                }

                port_idx++;
            }

            break;
        }
        default:
            break;
    }

    return true;
}

bool func_user::get_interface_do(int port_idx, const nb_id_t& obj_if)
{
    node_invocation_request request = m_param;
    request.declaration_id = NB_FUNC_INTERFACE_COVERS;
    request.input.clear();
    request.input.push_back(m_sub_ifs[port_idx]);
    
    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_COVERS);

    return object_run(obj_if, req_num, request);
}

bool func_user::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_user::obj_run_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    end_incoming_ins_call(req_num);
    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            end_incoming_ins_call(req_num);
            return execution_base::obj_run_response(req_num, output);

        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
        {
        
            // result must be a declaration
            if (output.output.objects.size() != 1)
            {
                LOG_ERROR("func_user::GET_ORIGIN_DECL wrong result num.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }

            if (!output.output.objects[0].is_object_declaration()
                && !output.output.objects[0].is_object_decl_compound())
            {
                LOG_ERROR("func_user::GET_ORIGIN_DECL result is not a declaration.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }
            //

            nb_id_t origin = output.output.objects[0];

            if (origin.is_object_decl_compound()) 
            {
                return do_user_defined_decl(origin); 
            }
            else if(origin.is_function_compose()) 
            {
                pre_compose();
            }
            else if(origin.is_function_decompose()) 
            {
                do_decompose();
            }
            break;
        }

        case NB_FUNC_GENERAL_GET_INTERFACE:
        {

            // result must be an interface
            if (output.output.objects.size() != 1
                || !output.output.objects[0].is_interface())
            {
                LOG_ERROR("func_user::GET_INTERFACE result is invalid.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }

            nb_id_t obj_if = output.output.objects[0];

            // get coresponding port index for this if
            int port_idx = get_reqnum_port(req_num);
            //assert(port_idx >= 0);
            if(port_idx < 0)
            {
                LOG_ERROR("func_user::cant get the port_idx for the interface");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_USER_GET_INTERFACE_INDEX_WRONG);
            }

            return get_interface_do(port_idx, obj_if);
            break;
        }
        case NB_FUNC_INTERFACE_COVERS:
        {

            // result must be a bool
            if (output.output.objects.size() != 1
                || !output.output.objects[0].is_object_bool())
            {
                LOG_ERROR("func_user::INTERFACE_COVERS result is invalid.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }

            bool covers;
            output.output.objects[0].get_value(covers);
            if(!covers)
            {
                LOG_ERROR("func_user::compose type checking failed");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }
            else
            {
                m_covered_ifs++;
                LOG_DEBUG("func_user::num of covered interface = "<<m_covered_ifs);
                if (m_covered_ifs == m_sub_ifs.size())
                {
                    LOG_NOTICE("func_user::compose type checking ok!");
                    //do the actual compose work
                    return do_compose();
                }
            }
            break;
        } 
        case NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION:
        {
            // result must be a implementation
            if (output.output.objects.size() != 1
                || !output.output.objects[0].is_object_exec_implementation())
            {
                std::string strval;
                ac_object_db_impl::instance().read(m_param.declaration_id.str(), strval);
                if (!strval.empty())
                {
                    content tmp_content;
                    decl_compound_data_t decl_data;
                    nb_id_t id;

                    data_unpacker::unpack_from_stream(strval, tmp_content);
                    obj_impl_decl_compound::unpack(tmp_content, id, decl_data);
                    LOG_ERROR("func_user::user name ="<<m_cData.name);
                    LOG_ERROR("func_user::not find the relative impl with in decl="<<decl_data.name);
                }
                
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }

            nb_id_t impl_id = output.output.objects[0];
            
            node_invocation_request request = m_param;
            request.declaration_id = NB_FUNC_GENERAL_START;
            
            req_num_t req_num2 = generate_req_num();
            begin_incoming_ins_call(req_num2, NB_FUNC_GENERAL_START);
            return object_run(impl_id, req_num2, request);
            break;
        } 
        case NB_FUNC_GENERAL_START:
        {

            LOG_NOTICE("**func_user::implementation run respond");
            return run_respond(output);
            break;
        }
        default:
        {
            LOG_ERROR("func_user::invalid instruction flow!"); 
            m_exception_responded = true;
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            break;
        }
    }

    return true;
}

bool func_user::access_run_response(req_num_t req_num, node_invocation_response& output)
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_user::access_run_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    end_incoming_ins_call(req_num);
    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_GET_INTERFACE:
        {
            // result must be an interface
            if (output.output.objects.size() != 1
                || !output.output.objects[0].is_interface())
            {
                LOG_ERROR("func_user::GET_INTERFACE result is invalid.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            nb_id_t obj_if = output.output.objects[0];

            // get coresponding port index 
            int port_idx = get_reqnum_port(req_num);
            if(port_idx < 0)
            {
                LOG_ERROR("func_user::cant get port_idx for interface");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_USER_GET_INTERFACE_INDEX_WRONG);
            }

            return get_interface_do(port_idx, obj_if);
        }

        default:
        {
            LOG_ERROR("func_user::invalid instruction flow!"); 
            m_exception_responded = true;
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
        }
    }

    return true; 
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
