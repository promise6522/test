/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_time.h"
#include "ac_execution/func_string.h"

//const uint64_t mask = 1 << 63;
const uint64_t duker_time = 946684800;
const uint64_t linux_time = duker_time - 28800;

bool func_time::get_name(nb_id_t& out)
{
	return request_string_object("time", out); 
}

bool func_time::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_time::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_time::get_general_time(const nb_id_t& id, time_data_t& my_time)
{
    uint64_t low = 0, high = 0;
    id.get_value(low, high);
        
    my_time.pico_second_cnt = high;
    my_time.second_cnt      = low;

    return true;
}

bool func_time::set_general_time(nb_id_t& id, const time_data_t& my_time)
{
    uint64_t low, high;
    high  = my_time.pico_second_cnt;
    low = my_time.second_cnt;
    id.set_value(low, high);

    return true;
}

bool func_time::get_detail_time(const time_data_t& my_time, nb_id_vector& out)
{
    time_t ts;
    ts = my_time.second_cnt;

    struct tm* tm1;
    tm1 = gmtime(&ts);

    nb_id_t       tmp(NBID_TYPE_OBJECT_INT);
    nb_id_vector  tmpv;

    tmp.set_value(tm1->tm_year + 1900);
    out.push_back(tmp);

    tmp.set_value(tm1->tm_mon + 1);
    out.push_back(tmp);

    tmp.set_value(tm1->tm_mday);
    out.push_back(tmp);

    tmp.set_value(tm1->tm_hour);
    out.push_back(tmp);

    tmp.set_value(tm1->tm_min);
    out.push_back(tmp);

    tmp.set_value(tm1->tm_sec);
    out.push_back(tmp);

    uint64_t tt = my_time.pico_second_cnt;

    tmp.set_value(tt % 1000);
    tmpv.push_back(tmp);

    tt = tt / 1000;
    tmp.set_value(tt % 1000);
    tmpv.push_back(tmp);

    tt = tt / 1000;
    tmp.set_value(tt % 1000);
    tmpv.push_back(tmp);

    tt = tt / 1000;
    tmp.set_value(tt % 1000);
    tmpv.push_back(tmp);

    while(!tmpv.empty())
    {
        out.push_back(tmpv.back());
        tmpv.pop_back();
    }

    return true;
}

bool func_time::time_add(const time_data_t& value1, const time_data_t& value2, time_data_t& result)
{
    result.second_cnt       = value1.second_cnt      +  value2.second_cnt;
    result.pico_second_cnt  = value1.pico_second_cnt +  value2.pico_second_cnt;

    uint64_t cc = 0xE8D4 << 24;
    cc += 0xA51000;
    if (result.pico_second_cnt > cc)
    {
        result.pico_second_cnt -= cc;
        result.second_cnt++;
    }

    return true;
}

bool func_time::time_sub(const time_data_t& value1, const time_data_t& value2, time_data_t& result)
{
    result.second_cnt = value1.second_cnt - value2.second_cnt;

    uint64_t cc = 0xE8D4 << 24;
    cc += 0xA51000;
    if (value1.pico_second_cnt >= value2.pico_second_cnt)
        result.pico_second_cnt = value1.pico_second_cnt - value2.pico_second_cnt;
    else
    {
        result.pico_second_cnt = cc - value2.pico_second_cnt + value1.pico_second_cnt;
        result.second_cnt--;
    }

    return true;
}

bool func_time::get(nb_id_t& out1, nb_id_t& out2)
{
    uint64_t value1, value2;
    m_obj_id.get_value(value1, value2);

    out1 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out1.set_value(value1, 0);
    out2 = nb_id_t(NBID_TYPE_OBJECT_INT);
    out2.set_value(value2, 0);

    return true;
}

bool func_time::show(nb_id_vector& out)
{
    time_data_t        my_time;
   
    get_general_time(m_obj_id, my_time);
    my_time.second_cnt += duker_time;
    get_detail_time(my_time, out);

    return true;
}

bool func_time::current(nb_id_t& out)
{
    struct timeval current;
    gettimeofday(&current, NULL);

    time_data_t        my_time;

    my_time.second_cnt      = current.tv_sec - linux_time;
    my_time.pico_second_cnt = current.tv_usec * 1000;
    my_time.pico_second_cnt = my_time.pico_second_cnt * 1000;
    
    out = nb_id_t(NBID_TYPE_OBJECT_TIME);
    out.set_value(my_time.second_cnt, my_time.pico_second_cnt);

    return true;
}

bool func_time::add(const nb_id_t& in1, nb_id_t& out)
{
    if(!in1.is_object_interval())
        return false;

    time_data_t  value1, value2, result;

    get_general_time(m_obj_id, value1);
    get_general_time(in1, value2);
    time_add(value1, value2, result);

    out = nb_id_t(NBID_TYPE_OBJECT_TIME);
    set_general_time(out, result);

    return true;
}

bool func_time::sub(const nb_id_t& in1, nb_id_t& out)
{
    if(!in1.is_object_interval())
        return false;

    time_data_t  value1, value2, result;

    get_general_time(m_obj_id, value1);
    get_general_time(in1, value2);
    time_sub(value1, value2, result);

    out = nb_id_t(NBID_TYPE_OBJECT_TIME);
    set_general_time(out, result);

    return true;
}

bool func_time::sub_time(const nb_id_t& in1, nb_id_t& out)
{
    if(!in1.is_object_time())
        return false;

    time_data_t  value1, value2, result;

    get_general_time(m_obj_id, value1);
    get_general_time(in1, value2);
    time_sub(value1, value2, result);

    out = nb_id_t(NBID_TYPE_OBJECT_INTERVAL);
    set_general_time(out, result);

    return true;
}

bool func_time::convert(std::string& strval, struct tm* tm1, uint64_t pico_value, bool is_before)
{
    try
    {
        std::string str1;
        std::stringstream s1, s2, s3, s4, s5;
        int value;
        if(is_before)
        {
            tm1->tm_year *= -1;
        }
        str1 = boost::lexical_cast<std::string>(tm1->tm_year + 1900);
        strval.append(str1);

        value = tm1->tm_mon + 1;
        s1 << std::setw(2) << std::setfill('0') << value;
        str1 = s1.str();
        strval.append(str1);

        value = tm1->tm_mday;
        s2 << std::setw(2) << std::setfill('0') << value;
        str1 = s2.str();
        strval.append(str1);

        value = tm1->tm_hour;
        s3 << std::setw(2) << std::setfill('0') << value;
        str1 = s3.str();
        strval.append(str1);

        value = tm1->tm_min;
        s4 << std::setw(2) << std::setfill('0') << value;
        str1 = s4.str();
        strval.append(str1);

        value = tm1->tm_sec;
        s5 << std::setw(2) << std::setfill('0') << value;
        str1 = s5.str();
        strval.append(str1);
        
        strval.append(".");
        str1 = boost::lexical_cast<std::string>(pico_value);
        strval.append(str1);
    }
    catch(boost::bad_lexical_cast& e)
    {
        return false;
    }
    return true;
}

bool func_time::to_string(nb_id_t& out)
{
    bool ret = false;
    time_data_t time_data;
    get_general_time(m_obj_id, time_data);

    time_data.second_cnt += duker_time;
    uint64_t value = time_data.second_cnt;
    uint64_t mask = 0x80000000;
    mask <<= 32;
    if(value & mask)
    {
        time_data.second_cnt *= -1;
        ret = true;
    } 

    time_t ts;
    ts= time_data.second_cnt;
    struct tm* tm1 = gmtime(&ts);

    std::string strval;
    convert(strval, tm1, time_data.pico_second_cnt, ret);
    return request_string_object(strval, out);
}

bool func_time::run()
{
    LOG_DEBUG("*** func_time::run() ");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_TIME_GET:
        {
            nb_id_t result1, result2;
            ret = get(result1, result2);
            response.output.objects.push_back(result1);
            response.output.objects.push_back(result2);
            break;
        }
        case NB_FUNC_TIME_SHOW:
        {
            nb_id_vector result;
            ret = show(result);
            //assert(10 == result.size());
            if(10 != result.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }
            response.output.objects = result;

            /* For Debug */
            std::vector<int> result_value;
            int tmp_value;
            std::vector<nb_id_t>::iterator it = result.begin();
            for (; it != result.end(); ++it)
            {
                (*it).get_value(tmp_value);
                result_value.push_back(tmp_value);
            }
            LOG_NOTICE("######## The result of time show: ");
            LOG_NOTICE("Year    :  " << result_value[0]);
            LOG_NOTICE("Month   :  " << result_value[1]);
            LOG_NOTICE("Day     :  " << result_value[2]);
            LOG_NOTICE("Hour    :  " << result_value[3]);
            LOG_NOTICE("Minute  :  " << result_value[4]);
            LOG_NOTICE("Second  :  " << result_value[5]);
            LOG_NOTICE("ms      :  " << result_value[6]);
            LOG_NOTICE("us      :  " << result_value[7]);
            LOG_NOTICE("ns      :  " << result_value[8]);
            LOG_NOTICE("ps      :  " << result_value[9]);

            break;
        }
        case NB_FUNC_TIME_CURRENT:
        {
            nb_id_t result;
            ret = current(result);
            response.output.objects.push_back(result);

            break;
        }
        case NB_FUNC_TIME_ADD:
        {
            nb_id_t result;
            ret = add(m_param.input[0], result);
            response.output.objects.push_back(result);

            /* For Debug */
            time_data_t value;
            get_general_time(result, value);
            LOG_NOTICE("######## The result of time add: ");
            LOG_NOTICE("pico_second_cnt  :  " << value.pico_second_cnt);
            LOG_NOTICE("second_cnt       :  " << value.second_cnt);

            break;
        }
        case NB_FUNC_TIME_SUB:
        {
            nb_id_t result;
            ret = sub(m_param.input[0], result);
            response.output.objects.push_back(result);

            /* For Debug */
            time_data_t value;
            get_general_time(result, value);
            LOG_NOTICE("######## The result of time sub: ");
            LOG_NOTICE("pico_second_cnt  :  " << value.pico_second_cnt);
            LOG_NOTICE("second_cnt       :  " << value.second_cnt);

            break;
        }
        case NB_FUNC_TIME_SUB_TIME:
        {
            nb_id_t result;
            ret = sub_time(m_param.input[0], result);
            response.output.objects.push_back(result);

            /* For Debug */
            time_data_t value;
            get_general_time(result, value);
            LOG_NOTICE("######## The result of time sub_interval: ");
            LOG_NOTICE("pico_second_cnt  :  " << value.pico_second_cnt);
            LOG_NOTICE("second_cnt       :  " << value.second_cnt);

            break;
        }
        case NB_FUNC_TIME_TO_STRING:
        {
            nb_id_t result;
            ret = to_string(result);
            response.output.objects.push_back(result);
            break;
        }
        default:
            return execution_base::run();
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
