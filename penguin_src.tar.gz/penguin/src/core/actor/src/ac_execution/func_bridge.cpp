/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_bridge.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_descriptor.h"

func_bridge::func_bridge(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{ 
    //assert(obj_id.is_bridge_object());
    nb_id_t id;    
    obj_impl_bridge::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);    

    //set inital state
    m_covered_ifs = 0;
    m_exception_responded = false;
} 

func_bridge::~func_bridge()
{
}

bool func_bridge::get_name(nb_id_t& out)
{
	return request_string_object(m_cData.name, out); 
}

bool func_bridge::set_interface(const nb_id_t& if_id)
{
    return true;
}

bool func_bridge::get_interface(nb_id_t& if_id)
{
    if_id = m_cData.interface;
    return true;
}

bool func_bridge::get_descriptor(nb_id_t& descriptor_id)
{
    descriptor_id = m_cData.descriptor;
    return true;
}



bool func_bridge::do_compose()
{
    bridge_data_t new_bridge;
    new_bridge.name = m_cData.name;
    new_bridge.descriptor = m_cData.descriptor;
    new_bridge.interface = m_cData.interface;
    new_bridge.subobjs = m_param.input;
    new_bridge.sub_names = m_cData.sub_names;

    // create new object
    request_nb_id_info bridge_info;
    obj_impl_bridge::pack(new_bridge, nb_id_t(), bridge_info.raw_data);
    bridge_info.committer_id = m_param.host_committer_id;
    bridge_info.type = NBID_TYPE_OBJECT_BRIDGE;

    nb_id_t bridge_id;
    if (!request_nb_id(m_param.host_committer_id, 
                bridge_info,
                bridge_id))
    {
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id);
    }
    
    node_invocation_response response;
    response.child_transaction = m_param.transaction_id;
    response.success = true;
    response.output.objects.push_back(bridge_id);

    LOG_NOTICE("func_bridge::compose = "<<bridge_id.str());

    return run_respond(response);
}


bool func_bridge::do_decompose()
{
    LOG_DEBUG("*** func_bridge::decompose()");

    node_invocation_response output;
    output.output.objects = m_cData.subobjs;//return sub objs
    output.success = true;
    output.child_transaction = m_param.transaction_id;

    return run_respond(output);
}


bool func_bridge::pre_compose()
{
    LOG_DEBUG("*** func_bridge::pre_compose()");

    if(m_param.input.size() <= 0)
    {
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
    }

    if (!_TYPE_CHECKING)
        return do_compose();
    else
    {
        // DO TYPE-CHECKING
        // get descriptor content
        req_num_t req_num = generate_req_num();
        begin_incoming_ins_call(req_num, NB_FUNC_BRIDGE_GET_DESCRIPTOR);

        return object_get_value_async(m_cData.descriptor, req_num);
    }
}


bool func_bridge::run()
{ 
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ bridge run() = "<< m_cData.name);

    bool ret = true;
    node_invocation_response output;
    
    nb_id_t decl_id = m_param.declaration_id;

    // Compose
    if(decl_id.is_function_bridge_compose())
    {
        return pre_compose();
    }

    // Decompose
    else if(decl_id.is_function_bridge_decompose())
    {
        return do_decompose();
    }    

    // Built-in instruction
    else if(decl_id.is_function_instruction())
    { 
        switch(decl_id.get_func_type())
        {
            case NB_FUNC_GENERAL_GET_NAME:
            {
                nb_id_t result;
                ret = get_name(result);
                output.output.objects.push_back(result);
                break;
            }
            case NB_FUNC_BRIDGE_GET_DESCRIPTOR:
            {
                LOG_DEBUG("*** func_bridge::run=>get_descriptor()");
                nb_id_t result;
                ret = get_descriptor(result);
                output.output.objects.push_back(result);
                break;
            }
            case NB_FUNC_GENERAL_GET_INTERFACE:
            {
                LOG_DEBUG("*** func_bridge::run=>get_interface()");
                nb_id_t result;
                ret = get_interface(result);
                output.output.objects.push_back(result);
                break;
            }
            default:
                return execution_base::run();
#if 0
                LOG_ERROR("func_bridge::run() failed:invalid instruction");

                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id);
#endif
                break;
        }
    }

    else if(decl_id.is_object_decl_compound())
    {
        return do_decl_compound(decl_id); 
    }

    output.child_transaction = m_param.transaction_id;
    output.success = ret; 

    return run_respond(output);
}


bool func_bridge::do_decl_compound(const nb_id_t& decl_id)
{
    // get corresponding impl from descriptor
    node_invocation_request request = m_param;
    request.declaration_id = NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION;
    request.input.clear();
    request.input.push_back(decl_id);

    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION);
    return object_run(m_cData.descriptor, req_num, request);
}


bool func_bridge::get_value_response(req_num_t req_num, 
        content& output)
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;

    LOG_DEBUG("*** func_bridge::get_value_response");

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_bridge::get_value_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            return execution_base::get_value_response(req_num, output);

        case NB_FUNC_BRIDGE_GET_DESCRIPTOR:
        {
            // unpack descriptor data
            descriptor_data_t dp_data;

            nb_id_t id;
            obj_impl_descriptor::unpack(output, id, dp_data);
            m_sub_ifs = dp_data.subobj_interfaces;

            // do type checking
            // get inputs interfaces
            int port_idx = 0;
            for (nb_id_vector_it it = m_param.input.begin(); it != m_param.input.end(); ++it)
            {
                node_invocation_request request = m_param;
                request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);

                req_num_t req_num2 = generate_req_num();
                begin_incoming_ins_call(req_num2, NB_FUNC_GENERAL_GET_INTERFACE);
                set_reqnum_port(req_num2, port_idx);

                if (it->is_object_access()) 
                {
                    access_id_t access_id;
                    it->to_access_id(access_id);
                    access_run(access_id, req_num2, request);
                }
                else if (it->is_object())
                {
                    object_run(*it, req_num2, request);
                }
                else
                {
                    LOG_ERROR("func_bridge::compose input["<<port_idx<<"] is not a valid object");
                    m_exception_responded = true;
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
                }

                port_idx++;
            }
            break;
        }

        default:
        {
            LOG_ERROR("func_bridge::invalid instruction flow!"); 
            m_exception_responded = true;
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            break;
        }

    }// end of switch

    return true;
}


bool func_bridge::get_interface_do(int port_idx, const nb_id_t& obj_if)
{
    node_invocation_request request = m_param;
    request.declaration_id = NB_FUNC_INTERFACE_COVERS;
    request.input.clear();
    request.input.push_back(m_sub_ifs[port_idx]);
    
    req_num_t req_num = generate_req_num();
    begin_incoming_ins_call(req_num, NB_FUNC_INTERFACE_COVERS);

    return object_run(obj_if, req_num, request);
}


bool func_bridge::obj_run_response(req_num_t req_num, 
        node_invocation_response& output)
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;


    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_bridge::obj_run_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }


    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_RUN:
            end_incoming_ins_call(req_num);
            return execution_base::obj_run_response(req_num, output);

        case NB_FUNC_GENERAL_GET_INTERFACE:
        {
            // check get interface result
            if(output.output.objects.size() != 1)
            {
                LOG_ERROR("func_bridge::GET_INTERFACE result num is wrong");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }

            nb_id_t obj_if = output.output.objects[0];
            if(!obj_if.is_interface())
            {
                LOG_ERROR("func_bridge::GET_INTERFACE result is invalid");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            // get coresponding port index for this if
            int port_idx = get_reqnum_port(req_num);
            if(port_idx < 0)
            {
                LOG_ERROR("func_bridge::cant get the port_idx for the interface");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_USER_GET_INTERFACE_INDEX_WRONG);
            }

            return get_interface_do(port_idx, obj_if);
            break;
        }

        case NB_FUNC_INTERFACE_COVERS:
        {
            if(output.output.objects.size() != 1)
            {
                LOG_ERROR("func_bridge::INTERFACE_COVERS result num is wrong.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }

            nb_id_t result = output.output.objects[0];
            if(!result.is_object_bool())
            {
                LOG_ERROR("func_bridge::INTERFACE_COVERS result is not a bool.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            bool covers;
            result.get_value(covers);
            if(!covers)
            {
                LOG_ERROR("func_bridge::compose type checking failed");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            }
            else
            {
                m_covered_ifs++;
                LOG_DEBUG("func_bridge::num of covered interface = "<<m_covered_ifs);
                if (m_covered_ifs == m_sub_ifs.size())
                {
                    LOG_NOTICE("func_bridge::compose type checking ok!");
                    //do the actual compose work
                    return do_compose();
                }
            }

            break;
        }

        case NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION:
        {
            if (output.output.objects.size() != 1)
            {
                LOG_ERROR("func_bridge::GET_IMPLEMENTATION result num is wrong.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
            }

            nb_id_t impl_id = output.output.objects[0];
            if (!impl_id.is_object_exec_implementation())
            {
                LOG_ERROR("func_bridge::GET_IMPLEMENTATION result is not a impl.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            node_invocation_request request = m_param;
            request.declaration_id = NB_FUNC_GENERAL_START;
            
            req_num_t req_num2 = generate_req_num();
            begin_incoming_ins_call(req_num2, NB_FUNC_GENERAL_START);
            return object_run(impl_id, req_num2, request);

            break;
        }

        case NB_FUNC_GENERAL_START:
        {
            LOG_NOTICE("**func_bridge::implementation run respond");
            return run_respond(output);
        }

        default:
        {
            LOG_ERROR("func_bridge::invalid instruction flow!"); 
            m_exception_responded = true;
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
            break;
        }

    }// end of switch

    return true;
}

bool func_bridge::access_run_response(req_num_t req_num, node_invocation_response& output) 
{
    // if already responded, no further operations
    if(m_exception_responded)
        return true;

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_bridge::access_run_response() failed"); 
        m_exception_responded = true;
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    switch(builtin_ins)
    {
        case NB_FUNC_GENERAL_GET_INTERFACE:
        {
            // result must be an interface
            if (output.output.objects.size() != 1
                || !output.output.objects[0].is_interface())
            {
                LOG_ERROR("func_bridge::GET_INTERFACE result is invalid.");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_INVALID);
            }

            nb_id_t obj_if = output.output.objects[0];

            // get coresponding port index 
            int port_idx = get_reqnum_port(req_num);
            if(port_idx < 0)
            {
                LOG_ERROR("func_bridge::cant get port_idx for interface");
                m_exception_responded = true;
                return run_exception_respond(m_param.transaction_id, CORPSE_USER_GET_INTERFACE_INDEX_WRONG);
            }

            return get_interface_do(port_idx, obj_if);
        }

        default:
        {
            LOG_ERROR("func_bridge::invalid instruction flow!"); 
            m_exception_responded = true;
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
        }
    }

    return true; 
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
