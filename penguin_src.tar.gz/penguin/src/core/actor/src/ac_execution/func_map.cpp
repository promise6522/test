/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_execution_helper.h"
#include "ac_execution/func_array.h"
#include "ac_execution/func_map.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"

#define KEY_FLAG 100 
#define VALUE_FLAG 200 

func_map::func_map(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{ 
    nb_id_t id;
	obj_impl_map::unpack(raw_data, id, m_cData);
} 

func_map::~func_map()
{
}

bool func_map::get_name(nb_id_t& out)
{
	return request_string_object("map", out); 
}

bool func_map::get_interface(nb_id_t& if_id)
{
    if_id = nb_id_t(NB_INTERFACE_MAP);
    return true;
}

bool func_map::generate_map(const map_data_t& logic_data)
{
    LOG_DEBUG("func_array::generate_map()");

    request_nb_id_info nb_info;
    nb_id_t map_id;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_MAP;
    obj_impl_map::pack(logic_data, nb_id_t(), nb_info.raw_data);
    
    if (!request_nb_id(m_param.host_committer_id, nb_info, map_id))
    {
        LOG_ERROR("func_map::generate_map():request map id failed.");
        return run_exception_respond(m_param.transaction_id);
    }

    node_invocation_response response;
    response.output.objects.push_back(map_id);
    return func_map_respond(response);
}

bool func_map::set_type()
{
    LOG_DEBUG("func_map::set_type()");
    
    if (m_param.input.size() != 2 || m_cData.data.size() != 0 || !m_param.input[0].is_interface() || !m_param.input[1].is_interface())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    nb_id_t map_id;
    node_invocation_response response;

    std::vector<key_obj_id> key_objs;
    for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
    {
        key_obj_id key_obj;
        key_obj.key_id = it->first;
        key_obj.obj_id = it->second;
        key_objs.push_back(key_obj);
    }

    if (execution_base::generate_map(key_objs, m_param.input[0], m_param.input[1], map_id))
        response.output.objects.push_back(map_id);
    else
    {
        LOG_ERROR("request map_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return func_map_respond(response);
}

bool func_map::get_type()
{
    LOG_DEBUG("func_map::get_type()");

    node_invocation_response response;
    response.output.objects.push_back(m_key_if);
    response.output.objects.push_back(m_value_if);
    return func_map_respond(response);
}

bool func_map::get()
{	
    LOG_DEBUG("func_map::get()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            LOG_ERROR("func_map::get():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_GET);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }
    
    // id-compare
    else
    {
        nb_id_map_it it = m_cData.data.find(m_param.input[0]);

        if (it == m_cData.data.end())
        {
            LOG_ERROR("func_map::get():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        node_invocation_response response;
        response.output.objects.push_back(it->second);
        return func_map_respond(response);
    }
}

bool func_map::get_or()
{
    LOG_DEBUG("func_map::get_or()");

    if (m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            node_invocation_response response;
            response.output.objects.push_back(m_param.input[1]);

            return func_map_respond(response);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_GET_OR);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        nb_id_map_it it = m_cData.data.find(m_param.input[0]);
        node_invocation_response response;

        if (it != m_cData.data.end())
            response.output.objects.push_back(it->second);
        else
            response.output.objects.push_back(m_param.input[1]);

        return func_map_respond(response);
    }
}

bool func_map::erase()
{
    LOG_DEBUG("func_map::erase()");
    
    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            LOG_ERROR("func_map::erase():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_ERASE);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        map_data_t map_data = m_cData;
        nb_id_map_it it = map_data.data.find(m_param.input[0]);

        if (it == map_data.data.end())
        {
            LOG_ERROR("func_map::erase():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        map_data.data.erase(it);

        return generate_map(map_data);
    }
}

bool func_map::has_key()
{
    LOG_DEBUG("func_map::has_key()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            nb_id_t res_id(NBID_TYPE_OBJECT_BOOL);
            res_id.set_value(false);

            node_invocation_response response;
            response.output.objects.push_back(res_id);

            return func_map_respond(response);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_HAS_KEY);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        nb_id_t  res_id(NBID_TYPE_OBJECT_BOOL);
        nb_id_map_it it = m_cData.data.find(m_param.input[0]);

        bool res = (it != m_cData.data.end());
        res_id.set_value(res);

        node_invocation_response response;
        response.output.objects.push_back(res_id);
        return func_map_respond(response);
    }
}

bool func_map::insert()
{
    LOG_DEBUG("func_map::insert()");

    if (m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            map_data_t map_data = m_cData;
            map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));

            return generate_map(map_data);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_INSERT);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        nb_id_map_it it = m_cData.data.find(m_param.input[0]);
        if (it != m_cData.data.end())
            return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

        map_data_t map_data = m_cData;
        map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));

        return generate_map(map_data);
    }
}

bool func_map::replace()
{
    LOG_DEBUG("func_map::replace");

    if (m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            LOG_ERROR("func_map::replace():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_REPLACE);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        map_data_t map_data = m_cData;
        nb_id_map_it it = map_data.data.find(m_param.input[0]);

        if (it == map_data.data.end())
        {
            LOG_ERROR("func_map::replace():failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
        }

        it->second = m_param.input[1];

        return generate_map(map_data);
    }
}

bool func_map::update()
{
    LOG_DEBUG("func_map::update");

    if (m_param.input.size() != 2)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    // value-compare
    if (m_key_if.is_interface_none() || m_param.input[0].is_value_compare())
    {
        if (m_cData.data.size() == 0)
        {
            map_data_t map_data = m_cData;
            map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));

            return generate_map(map_data);
        }

        m_cnt = 0;

        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
        {
            req_num_t req_num = generate_req_num();
            m_req_key_map.insert(std::make_pair(req_num, it->first));
            begin_incoming_ins_call(req_num, NB_FUNC_MAP_UPDATE);

            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
            request.input.push_back(it->first);

            object_run(m_param.input[0], req_num, request);
        }

        return true;
    }

    // id-compare
    else
    {
        map_data_t map_data = m_cData;
        nb_id_map_it it = map_data.data.find(m_param.input[0]);

        if (it == map_data.data.end())
            map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));
        else
            it->second = m_param.input[1];

        return generate_map(map_data);
    }
}

bool func_map::size()
{
    LOG_DEBUG("func_map::size()");

	int map_size = m_cData.data.size();

    nb_id_t  size_id(NBID_TYPE_OBJECT_INT);
    size_id.set_value(map_size);

    node_invocation_response response;
    response.output.objects.push_back(size_id);
    return func_map_respond(response);
}

bool func_map::get_all_keys()
{
    LOG_DEBUG("func_map::get_all_keys()");

    nb_id_vector key_vec;

    // 1 if-none
    if (m_key_if.is_interface_none())
    {
        for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
            key_vec.push_back(it->first);
    }
    else if (m_cData.data.size() > 0)
    {
        nb_id_map_it it = m_cData.data.begin();

        // 2 id-compare
        if (!it->first.is_value_compare())
        {
            for (nb_id_map_it it = m_cData.data.begin(); it != m_cData.data.end(); ++it)
                key_vec.push_back(it->first);

            std::sort(key_vec.begin(), key_vec.end());
        }

        // 3 value-compare
        else
        {
            if (m_cData.data.size() == 1)
                key_vec.push_back(it->first);
            else
            {
                for (; it != m_cData.data.end(); ++it)
                    m_data_vec.push_back(it->first);

                m_key_vec.push_back(m_data_vec[0]);
                m_data_idx = 1;
                m_key_idx  = 0;

                req_num_t req_num = generate_req_num();
                begin_incoming_ins_call(req_num, NB_FUNC_MAP_GETALLKEYS);

                node_invocation_request request;
                request.transaction_id = m_param.transaction_id;
                request.host_committer_id = m_param.host_committer_id;
                request.execution_id = m_param.execution_id;
                request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
                request.input.push_back(m_data_vec[m_data_idx]);

                return object_run(m_key_vec[m_key_idx], req_num, request);
            }
        }
    }

    nb_id_t array_id;
    if (!generate_array(key_vec, m_key_if, array_id))
    {
        LOG_ERROR("func_array::get_all_keys():request array id failed.");
        return run_exception_respond(m_param.transaction_id);
    }

    node_invocation_response response;
    response.output.objects.push_back(array_id);
    return func_map_respond(response);
}

bool func_map::run()
{
    LOG_DEBUG("func_map::run()");

    node_invocation_response response;

    if (m_param.declaration_id.is_object_decl_expanded())
    {
        req_num_t req_num = generate_req_num();    
        begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_INIT);

        return object_get_value_async(m_cData.type, req_num);
    }
    else
    {
        switch (m_param.declaration_id.get_func_type())
        {
            case NB_FUNC_GENERAL_GET_NAME:
            {
                nb_id_t result;
                get_name(result);
                response.output.objects.push_back(result);
                break;
            }
            case NB_FUNC_GENERAL_GET_INTERFACE:
                {
                    response.output.objects.push_back(m_cData.type);
                    break;
                }
            default:
                return execution_base::run();
        }
    }

    response.success = true;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_map::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_map::get_value_response");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_map::get_value_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    if (NB_FUNC_GENERAL_RUN == builtin_ins)
    {
        return execution_base::get_value_response(req_num, output);
    }

    end_incoming_ins_call(req_num);

    if (builtin_ins == NB_FUNC_GENERAL_GET_DECLARATION)
    {
        decl_expanded_data_t data;
        nb_id_t id;
        obj_impl_decl_expanded::unpack(output, id, data);

        if (!data.origin_decl_id.is_object_declaration())
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

        switch (data.origin_decl_id.get_func_type())
        {
            case NB_FUNC_MAP_SETTYPE:
                return set_type();
            case NB_FUNC_MAP_GETTYPE:
                return get_type();
            case NB_FUNC_MAP_GET:
                return get();
            case NB_FUNC_MAP_GET_OR:
                return get_or();
            case NB_FUNC_MAP_INSERT:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(NB_FUNC_MAP_INSERT);
                    else
                        return insert();
                }
            case NB_FUNC_MAP_REPLACE:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(NB_FUNC_MAP_REPLACE);
                    else
                        return replace();
                }
            case NB_FUNC_MAP_UPDATE:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(NB_FUNC_MAP_UPDATE);
                    else
                        return update();
                }
            case NB_FUNC_MAP_ERASE:
                return erase();
            case NB_FUNC_MAP_HAS_KEY:
                return has_key();
            case NB_FUNC_MAP_SIZE:
                return size();
            case NB_FUNC_MAP_GETALLKEYS:
                return get_all_keys();
            default:
                {
                    LOG_ERROR("func_map:invalid instruction");
                    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
                }
        }
    }
    else if (builtin_ins == NB_FUNC_GENERAL_INIT)
    {
        LOG_NOTICE("func_map:initialize");

        nb_id_t id;
        if_compound_data_t if_data;
        obj_impl_interface_compound::unpack(output, id, if_data);

        if (if_data.groups.size() != 2)
        {
            LOG_ERROR("func_map:get invalid interface_compound");
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
        }

        m_key_if = if_data.groups[0].min_if;
        m_value_if = if_data.groups[1].min_if;

        req_num_t req_num_tmp = generate_req_num();
        begin_incoming_ins_call(req_num_tmp, NB_FUNC_GENERAL_GET_DECLARATION);
        return object_get_value_async(m_param.declaration_id, req_num_tmp);
    }

    LOG_ERROR("func_map::get_value_response() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
}

bool func_map::prepare_add_element(const nb_builtin_instruction_t& call)
{
    LOG_DEBUG("func_map::prepare_add_element()");

    if (m_key_if.is_builtin_interface())
    {
        // key match
        nb_id_t in_kif;
        m_param.input[0].get_builtin_interface(in_kif);

        if (m_key_if != in_kif && !m_key_if.is_interface_none())
        {
            LOG_ERROR("func_map::prepare_add_element=> key builtin type match failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_INVALID_KEY);
        }

        // value match
        if (m_value_if.is_builtin_interface())
        {
            nb_id_t in_vif;
            m_param.input[1].get_builtin_interface(in_vif);

            if (m_value_if != in_vif && !m_value_if.is_interface_none())
            {
                LOG_ERROR("func_map::prepare_add_element=> value builtin type match failed");
                return run_exception_respond(m_param.transaction_id, CORPSE_MAP_INVALID_VALUE);
            }

            // add element
            if (call == NB_FUNC_MAP_INSERT)
                return insert();
            else if (call == NB_FUNC_MAP_REPLACE)
                return replace();
            else if (call == NB_FUNC_MAP_UPDATE)
                return update();
            else
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
        }
        else
            return get_compound_interface(call, VALUE_FLAG, m_param.input[1]);
    }
    else
        return get_compound_interface(call, KEY_FLAG, m_param.input[0]);
}

bool func_map::get_compound_interface(const nb_builtin_instruction_t& call, const int& flag, const nb_id_t& in)
{
    node_invocation_request request;
    request.transaction_id = m_param.transaction_id;
    request.host_committer_id = m_param.host_committer_id;
    request.execution_id = m_param.execution_id;
    request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);

    req_num_t req_num_tmp = generate_req_num();
    m_req_flag.insert(std::make_pair(req_num_tmp, flag));
    
    instruction_pair_t call_pair;
    call_pair.first = call;
    call_pair.second = NB_FUNC_GENERAL_GET_INTERFACE;

    insert_num_ins_pair(req_num_tmp, call_pair);

    if (in.is_object_access())
    {
        access_id_t access_id; 
        in.to_access_id(access_id);
        return access_run(access_id, req_num_tmp, request);
    }
    else
        return object_run(in, req_num_tmp, request);
}

bool func_map::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("func_map::obj_run_response()");

    nb_builtin_instruction_t builtin_ins;
    if (get_ins_call(req_num, builtin_ins))
    {
        switch(builtin_ins)
        {
            case NB_FUNC_GENERAL_RUN:
                {
                    end_incoming_ins_call(req_num);
                    return execution_base::obj_run_response(req_num, output);
                }
            case NB_FUNC_MAP_GETALLKEYS:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[0].get_value(ret);

                    if (ret)  // <
                    {
                        m_key_vec.insert(m_key_vec.begin() + m_key_idx, m_data_vec[m_data_idx]);

                        m_key_idx = 0;

                        if (++m_data_idx == m_data_vec.size())
                        {
                            nb_id_t array_id;
                            if (!generate_array(m_key_vec, m_key_if, array_id))
                            {
                                LOG_ERROR("func_array::get_all_keys():request array id failed");
                                return run_exception_respond(m_param.transaction_id);
                            }

                            node_invocation_response response;
                            response.output.objects.push_back(array_id);
                            return func_map_respond(response);
                        }
                    }
                    else  // >=
                    {
                        if (++m_key_idx == m_key_vec.size())
                        {
                            m_key_vec.push_back(m_data_vec[m_data_idx]);

                            m_key_idx = 0;

                            if (++m_data_idx == m_data_vec.size())
                            {
                                nb_id_t array_id;
                                if (!generate_array(m_key_vec, m_key_if, array_id))
                                {
                                    LOG_ERROR("func_array::get_all_keys():request array id failed");
                                    return run_exception_respond(m_param.transaction_id);
                                }

                                node_invocation_response response;
                                response.output.objects.push_back(array_id);
                                return func_map_respond(response);
                            }
                        }

                    }

                    req_num_t req_num_tmp = generate_req_num();
                    begin_incoming_ins_call(req_num_tmp, NB_FUNC_MAP_GETALLKEYS);

                    node_invocation_request request;
                    request.transaction_id = m_param.transaction_id;
                    request.host_committer_id = m_param.host_committer_id;
                    request.execution_id = m_param.execution_id;
                    request.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
                    request.input.push_back(m_data_vec[m_data_idx]);

                    return object_run(m_key_vec[m_key_idx], req_num_tmp, request);
                }
            case NB_FUNC_MAP_GET:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        std::map<req_num_t, nb_id_t>::iterator key_map_it = m_req_key_map.find(req_num);

                        if (key_map_it == m_req_key_map.end())
                        {
                            LOG_ERROR("func_map::req_key_map: get_value failed");
                            return run_exception_respond(m_param.transaction_id);
                        }

                        nb_id_map_it it = m_cData.data.find(key_map_it->second);

                        node_invocation_response response;
                        response.output.objects.push_back(it->second);
                        return func_map_respond(response);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            LOG_ERROR("func_map::func_map::get():failed");
                            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_GET_OR:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        std::map<req_num_t, nb_id_t>::iterator key_map_it = m_req_key_map.find(req_num);

                        if (key_map_it == m_req_key_map.end())
                        {
                            LOG_ERROR("func_map::req_key_map: get_value failed");
                            return run_exception_respond(m_param.transaction_id);
                        }

                        nb_id_map_it it = m_cData.data.find(key_map_it->second);

                        node_invocation_response response;
                        response.output.objects.push_back(it->second);
                        return func_map_respond(response);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            node_invocation_response response;
                            response.output.objects.push_back(m_param.input[1]);
                            return func_map_respond(response);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_ERASE:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        std::map<req_num_t, nb_id_t>::iterator key_map_it = m_req_key_map.find(req_num);

                        if (key_map_it == m_req_key_map.end())
                        {
                            LOG_ERROR("func_map::req_key_map: get_value failed");
                            return run_exception_respond(m_param.transaction_id);
                        }

                        map_data_t map_data = m_cData;
                        nb_id_map_it it = map_data.data.find(key_map_it->second);
                        map_data.data.erase(it);

                        return generate_map(map_data);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            LOG_ERROR("func_map::func_map::erase():failed");
                            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_HAS_KEY:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        node_invocation_response response;
                        response.output.objects.push_back(output.output.objects[1]);
                        return func_map_respond(response);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            nb_id_t res_id(NBID_TYPE_OBJECT_BOOL);
                            res_id.set_value(ret);

                            node_invocation_response response;
                            response.output.objects.push_back(output.output.objects[1]);
                            return func_map_respond(response);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_INSERT:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            map_data_t map_data = m_cData;
                            map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));

                            return generate_map(map_data);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_REPLACE:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        std::map<req_num_t, nb_id_t>::iterator key_map_it = m_req_key_map.find(req_num);

                        if (key_map_it == m_req_key_map.end())
                        {
                            LOG_ERROR("func_map::req_key_map: get_value failed");
                            return run_exception_respond(m_param.transaction_id);
                        }

                        map_data_t map_data = m_cData;
                        nb_id_map_it it = map_data.data.find(key_map_it->second);
                        it->second = m_param.input[1];

                        return generate_map(map_data);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            LOG_ERROR("func_map::func_map::replace():failed");
                            return run_exception_respond(m_param.transaction_id, CORPSE_MAP_KEY_NOT_EXIST);
                        }

                        return true;
                    }
                }
            case NB_FUNC_MAP_UPDATE:
                {
                    if (output.output.objects.size() != 3 || !output.output.objects[0].is_object_bool() ||
                        !output.output.objects[1].is_object_bool() || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_map::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                    end_incoming_ins_call(req_num);

                    bool ret;
                    output.output.objects[1].get_value(ret);

                    if (ret)
                    {
                        std::map<req_num_t, nb_id_t>::iterator key_map_it = m_req_key_map.find(req_num);

                        if (key_map_it == m_req_key_map.end())
                        {
                            LOG_ERROR("func_map::req_key_map: get_value failed");
                            return run_exception_respond(m_param.transaction_id);
                        }

                        map_data_t map_data = m_cData;
                        nb_id_map_it it = map_data.data.find(key_map_it->second);
                        it->second = m_param.input[1];

                        return generate_map(map_data);
                    }
                    else
                    {
                        if (++m_cnt == m_cData.data.size())
                        {
                            map_data_t map_data = m_cData;
                            map_data.data.insert(std::make_pair(m_param.input[0], m_param.input[1]));

                            return generate_map(map_data);
                        }

                        return true;
                    }
                }
            default:
                {
                    LOG_ERROR("func_map::obj_run_response():invalid instruction");
                    return run_exception_respond(m_param.transaction_id);
                }
        }
    }

    instruction_pair_t call_pair;

    std::map<req_num_t, int>::iterator it = m_req_flag.find(req_num); 

    if (!output.success || it == m_req_flag.end() || !get_ins_pair(req_num, call_pair))
    {
        LOG_ERROR("func_map::obj_run_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    erase_num_ins_pair(req_num);

    if (NB_FUNC_GENERAL_GET_INTERFACE == call_pair.second)
    {
        if (KEY_FLAG == it->second)
            return run_response_for_key(call_pair, output.output.objects); 
        else
            return run_response_for_value(call_pair, output.output.objects); 
    }
    else if (NB_FUNC_BRIDGE_INTERFACE_EQ == call_pair.second || NB_FUNC_INTERFACE_COVERS == call_pair.second)
    {
        //assert(1 == output.output.objects.size());
        if(1 != output.output.objects.size())
        {
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        }

        bool result;
        output.output.objects[0].get_value(result);

        if (!result)
        {
            LOG_ERROR("func_map::run_response_for_key(): object type match failed");
            return run_exception_respond(m_param.transaction_id);
        }

        if (KEY_FLAG == it->second)
        {
            m_req_flag.erase(req_num);
            
            if (m_value_if.is_builtin_interface())
            {
                // value match
                nb_id_t in_valif;
                m_param.input[1].get_builtin_interface(in_valif);

                if (m_value_if != in_valif && !m_value_if.is_interface_none())
                {
                    LOG_ERROR("func_map::prepare_add_element=> value builtin type match failed");
                    return run_exception_respond(m_param.transaction_id, CORPSE_MAP_INVALID_VALUE);
                }

                switch (call_pair.first)
                {
                    case NB_FUNC_MAP_INSERT:
                        return insert();
                    case NB_FUNC_MAP_REPLACE:
                        return replace();
                    case NB_FUNC_MAP_UPDATE:
                        return update();
                    default:
                        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
                }
            }
            else
                return get_compound_interface(call_pair.first, VALUE_FLAG, m_param.input[1]);
        }
        else
        {
            m_req_flag.erase(req_num);

            switch (call_pair.first)
            {
                case NB_FUNC_MAP_INSERT:
                    return insert();
                case NB_FUNC_MAP_REPLACE:
                    return replace();
                case NB_FUNC_MAP_UPDATE:
                    return update();
                default:
                    return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
        }
    }

    LOG_ERROR("func_array::run_response_for_value() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_map::access_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("func_map::access_run_response()");

    instruction_pair_t call_pair;

    std::map<req_num_t, int>::iterator it = m_req_flag.find(req_num); 

    if (!output.success || it == m_req_flag.end() || !get_ins_pair(req_num, call_pair))
    {
        LOG_ERROR("func_map::obj_run_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    erase_num_ins_pair(req_num);
    
    if (KEY_FLAG == it->second)
        return run_response_for_key(call_pair, output.output.objects); 
    else
        return run_response_for_value(call_pair, output.output.objects); 
}

bool func_map::run_response_for_key(instruction_pair_t& call_pair, const nb_id_vector& vid)
{
    LOG_DEBUG("func_map::run_response_for_key()");

    if (NB_FUNC_GENERAL_GET_INTERFACE == call_pair.second)
    {
        //assert(1 == vid.size());
        if(1 != vid.size())
        {
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        } 

        node_invocation_request request;
        request.transaction_id = m_param.transaction_id;
        request.host_committer_id = m_param.host_committer_id;
        request.execution_id = m_param.execution_id;
        request.input.push_back(m_key_if);

        req_num_t req_num_tmp = generate_req_num();

        if (m_key_if.is_interface_bridge())
        {
            call_pair.second = NB_FUNC_BRIDGE_INTERFACE_EQ;
            insert_num_ins_pair(req_num_tmp, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_BRIDGE_INTERFACE_EQ);
        }
        else if (m_key_if.is_compound_interface()) 
        {
            call_pair.second = NB_FUNC_INTERFACE_COVERS;
            insert_num_ins_pair(req_num_tmp, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
        }

        return object_run(vid[0], req_num_tmp, request);
    }

    LOG_ERROR("func_array::run_response_for_key() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_map::run_response_for_value(instruction_pair_t& call_pair, const nb_id_vector& vid)
{
    LOG_DEBUG("func_map::run_response_for_value()");

    if (NB_FUNC_GENERAL_GET_INTERFACE == call_pair.second)
    {
        //assert(1 == vid.size());
        if(1 != vid.size())
        {
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        } 

        node_invocation_request request;
        request.transaction_id = m_param.transaction_id;
        request.host_committer_id = m_param.host_committer_id;
        request.execution_id = m_param.execution_id;
        request.input.push_back(m_value_if);

        req_num_t req_num_tmp = generate_req_num();

        if (m_value_if.is_interface_bridge())
        {
            call_pair.second = NB_FUNC_BRIDGE_INTERFACE_EQ;
            insert_num_ins_pair(req_num_tmp, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_BRIDGE_INTERFACE_EQ);
        }
        else if (m_value_if.is_compound_interface()) 
        {
            call_pair.second = NB_FUNC_INTERFACE_COVERS;
            insert_num_ins_pair(req_num_tmp, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
        }

        return object_run(vid[0], req_num_tmp, request);
    }

    LOG_ERROR("func_array::run_response_for_value() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_map::func_map_respond(node_invocation_response& response)
{
    LOG_DEBUG("*** func_map::func_map_respond()");

    response.success = true;
    response.child_transaction = m_param.transaction_id;

    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:

