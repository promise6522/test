/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution/func_declaration.h"

#include "ac_execution_helper.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_declaration.h"

func_declaration::func_declaration(nb_id_t& obj_id, 
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    obj_impl_declaration::get_interfaces(m_obj_id, m_viif, m_voif);
} 

func_declaration::~func_declaration()
{
} 

bool func_declaration::get_name(nb_id_t& out)
{
    std::string name;
    obj_impl_declaration::get_instruction_name(m_obj_id, name);

    return request_string_object(name, out);
}

bool func_declaration::get_interfaces(nb_id_vector& vout)
{
    LOG_NOTICE("**func_declaration::get_interfaces");
    // return two arrays
    nb_id_t out;
    generate_array(m_viif, NB_INTERFACE_INTERFACE, out);
    vout.push_back(out);

    generate_array(m_voif, NB_INTERFACE_INTERFACE, out);
    vout.push_back(out);

    return true;
}

bool func_declaration::get_in_ports(nb_id_t& out)
{
    LOG_NOTICE("**func_declaration::get_in_ports");
    // return an array id
    return generate_array(m_viif, NB_INTERFACE_INTERFACE, out);
}

bool func_declaration::get_out_ports(nb_id_t& out)
{
    LOG_NOTICE("**func_declaration::get_out_ports");
    // return an array id
    return generate_array(m_voif, NB_INTERFACE_INTERFACE, out);
}

bool func_declaration::get_expanded_ifs(nb_id_t& out)
{
    LOG_NOTICE("**func_declaration::get_expanded_ifs");
    // return an empty array
    nb_id_vector vif;
    return generate_array(vif, NB_INTERFACE_INTERFACE, out);
}

bool func_declaration::get_iport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);

    int value = m_viif.size();
    num.set_value(value);

    LOG_NOTICE("**func_declaration::get iport number = "<<value);
    return true;
}

bool func_declaration::get_oport_number(nb_id_t& num)
{
    num = nb_id_t(NBID_TYPE_OBJECT_INT);

    int value = m_voif.size();
    num.set_value(value);

    LOG_NOTICE("**func_declaration::get oport number = "<<value);
    return true;
}

bool func_declaration::run()
{ 
    LOG_DEBUG("$$$$$$$$$$$$$$$$$ built-in declaration run().");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_INTERFACES:
        {
            ret = get_interfaces(response.output.objects);
            break;
        }
        case NB_FUNC_DECLARATION_GET_IN_PORTS:
        {
            nb_id_t out;
            ret = get_in_ports(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_DECLARATION_GET_OUT_PORTS:
        {
            nb_id_t out;
            ret = get_out_ports(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_DECLARATION_GET_IN_PORT_NUM:
        {
            nb_id_t result;
            ret = get_iport_number(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_OUT_PORT_NUM:
        {
            nb_id_t result;
            ret = get_oport_number(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_DECLARATION_GET_ORIGIN_DECL:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_ORIGIN_DECL");
            // just return self id
            ret = true;
            response.output.objects.push_back(m_obj_id);
            break;
        }
        case NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES:
        {
            LOG_DEBUG("NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES");
            nb_id_t out;
            ret = get_expanded_ifs(out);
            response.output.objects.push_back(out);
            break;
        }
        default:
            return execution_base::run();
            break;
    }
    
    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
