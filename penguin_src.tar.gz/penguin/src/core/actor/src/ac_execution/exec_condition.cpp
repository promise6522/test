/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/exec_condition.h"
#include "ac_execution/exec_obj_func.h"

exec_condition::exec_condition(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper), 
      m_cond_num(0)
{
    //assert(obj_id.is_object_exec_condition());

    nb_id_t id;
    obj_impl_exec_condition::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);
} 

exec_condition::~exec_condition()
{
} 

bool exec_condition::get_name(nb_id_t& out)
{
    return request_string_object(m_cData.name, out); 
}

bool exec_condition::set_type(const nb_id_t& type_id)
{
    return true;
}

bool exec_condition::get_type(nb_id_t& type_id)
{
    return true;
}

bool exec_condition::run()
{
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ condition run() = "<< m_cData.name);

    //assert(m_param.declaration_id == m_cData.external_decl);
//    if (m_param.declaration_id != m_cData.external_decl)
//        return run_exception_respond(m_param.transaction_id, CORPSE_CONDITION_DECLARATION_WRONG);

    //assert(m_cData.alternate_execs.size() > 0);
    if (m_cData.alternate_execs.size() <= 0)
        return run_exception_respond(m_param.transaction_id, CORPSE_CONDITION_NO_ALTERNATE_EXECUTION);

    m_cond_num = 0;

    //assert(m_cData.alternate_execs[m_cond_num].is_object_exec_implementation());
    if (!m_cData.alternate_execs[m_cond_num].is_object_exec_implementation())
        return run_exception_respond(m_param.transaction_id, CORPSE_CONDITION_ISNOT_IMPLEMENT);

    return object_run(m_cData.alternate_execs[m_cond_num], m_cond_num, m_param);
}

bool exec_condition::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    if(output.output.corpse.is_object_corpse())
    {
        return run_respond(output);
    }
    else
    {
        LOG_NOTICE("exec_condition::obj_run_response(), object_id="<<output.output.objects[0].str());
    }

    if (!output.output.objects[0].is_exception())
        return run_respond(output);

    nb_exception_type_t exception_type = output.output.objects[0].get_exception_type();
    switch (exception_type)
    {
        case NB_EXCEPTION_ZERO:
            // if this is the last condition exec, we pass the exception out
            if (m_cond_num == m_cData.alternate_execs.size()-1)
                return run_respond(output);

            m_cond_num++;
            //assert(m_cData.alternate_execs[m_cond_num].is_object_exec_implementation());
            if (!m_cData.alternate_execs[m_cond_num].is_object_exec_implementation())
                return run_exception_respond(m_param.transaction_id, CORPSE_CONDITION_ISNOT_IMPLEMENT);

            return object_run(m_cData.alternate_execs[m_cond_num], m_req, m_param);
            break;

        case NB_EXCEPTION_NORMAL:
            output.success = false;
            output.is_refusal = true;
            return run_respond(output);
            break;

        default:
            break;
    }

    return true;
}

bool exec_condition::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_condition::get_value_response");
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
