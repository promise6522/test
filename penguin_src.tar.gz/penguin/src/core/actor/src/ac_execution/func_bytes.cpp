/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <string>
#include <vector>

#include "boost/crc.hpp"
#include "ac_execution_helper.h"
#include "ac_execution/func_bytes.h"
#include "ac_object/obj_impl_string.h"

func_bytes::func_bytes(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_bytes());
    nb_id_t id;    
    obj_impl_bytes::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);    
}; 

func_bytes::~func_bytes()
{
}; 

bool func_bytes::get_name(nb_id_t& out)
{
    return request_string_object("bytes", out); 
}

bool func_bytes::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_bytes::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_BYTES);
    return true;
}

bool func_bytes::make_bytes(bytes_data_t& data)
{
    boost::crc_optimal<16, 0x1021, 0xFFFF, 0, false, false>  crc_ccitt;
    crc_ccitt = std::for_each(data.value.begin(), data.value.end(), crc_ccitt);
    data.crc = crc_ccitt();data.length = data.value.size();
    return true;
}

bool func_bytes::compare(const nb_id_t& input)
{
    LOG_DEBUG("*** func_bytes::compare()");

    //assert(input.is_object_bytes());
    if (!input.is_object_bytes())
        return false;
	
    // get string content 
    req_num_t req = generate_req_num();
    begin_incoming_ins_call(req, NB_FUNC_GENERAL_COMPARE);
    return object_get_value_async(input, req); 
}

bool func_bytes::join()
{
    // get string content 
    req_num_t req = generate_req_num();
    begin_incoming_ins_call(req, NB_FUNC_BYTES_JOIN);
    return object_get_value_async(m_param.input[0], req);
}

bool func_bytes::range(const nb_id_t& start_pos, const nb_id_t& end_pos,
                         nb_id_t& out)
{
    int start_pos_value, end_pos_value;

    start_pos.get_value(start_pos_value);
    end_pos.get_value(end_pos_value);

    bytes_data_t new_bytes;
    new_bytes.value = m_cData.value.substr(start_pos_value, 
        end_pos_value - start_pos_value);
    make_bytes(new_bytes);

    request_nb_id_info nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(new_bytes, nb_id_t(), nb_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info,
                out))
        return run_exception_respond(m_param.transaction_id);

    return true;
}

bool func_bytes::size(nb_id_t& out)
{
    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(m_cData.length);
    return true;
}

bool func_bytes::split(nb_id_t& out0, nb_id_t& out1)
{
    bytes_data_t result0, result1;
    obj_impl_bytes bytes_impl;

    int half_len = m_cData.length/2;

    result0.value = m_cData.value.substr(0, half_len);
    result1.value = m_cData.value.substr(half_len);
    make_bytes(result0);
    make_bytes(result1);

    request_nb_id_info nb_info0;
    nb_info0.committer_id = m_param.host_committer_id;
    nb_info0.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(result0, nb_id_t(), nb_info0.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info0,
                out0))
        return run_exception_respond(m_param.transaction_id);

    request_nb_id_info nb_info1;
    nb_info1.committer_id = m_param.host_committer_id;
    nb_info1.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(result1, nb_id_t(), nb_info1.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info1,
                out1))
        return run_exception_respond(m_param.transaction_id);

    return true;
}

bool func_bytes::split_at(const nb_id_t& start_pos,
    nb_id_t& out0,
    nb_id_t& out1)
{
    bytes_data_t result0, result1;
    int start_pos_value;

    start_pos.get_value(start_pos_value);

    result0.value = m_cData.value.substr(0, start_pos_value);
    result1.value = m_cData.value.substr(start_pos_value);
    make_bytes(result0);
    make_bytes(result1);

    request_nb_id_info nb_info0;
    nb_info0.committer_id = m_param.host_committer_id;
    nb_info0.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(result0, nb_id_t(), nb_info0.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info0,
                out0))
        return run_exception_respond(m_param.transaction_id);

    request_nb_id_info nb_info1;
    nb_info1.committer_id = m_param.host_committer_id;
    nb_info1.type = NBID_TYPE_OBJECT_BYTES;
    obj_impl_bytes::pack(result1, nb_id_t(), nb_info1.raw_data);

    if (!request_nb_id(m_param.host_committer_id, 
                nb_info1,
                out1))
        return run_exception_respond(m_param.transaction_id);

    return true;
}

bool func_bytes::crc(nb_id_t& out)
{
    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(m_cData.crc);
    return true;
}

bool func_bytes::to_string(nb_id_t& out)
{
    LOG_DEBUG("*** func_bytes::to_string");

    request_nb_id_info  nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(m_cData.value, nb_id_t(), nb_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, nb_info, out))
        return false;

    return true;
}

bool func_bytes::generate_compare(const nb_id_t& input)
{
    if(input.is_object_bytes())
    {
        return compare(input);//async
    }
    return execution_base::run();
}

bool func_bytes::run()
{
    bool ret = true;
    nb_id_vector vout;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            vout.push_back(result);
            break;
        }
        case NB_FUNC_GENERAL_COMPARE:
        {
            if(m_param.input.size() != 1)
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            return generate_compare(m_param.input[0]);
        }
        //case NB_FUNC_BYTES_COMPARE:
        //    if (m_param.input.size() != 1)
        //        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
        //    assert(m_param.input[0].is_object_bytes());
        //    return compare(m_param.input[0]);
        //    break;
        case NB_FUNC_BYTES_JOIN:
            //assert(1 == m_param.input.size());
            if (m_param.input.size() != 1)
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            //assert(m_param.input[0].is_object_bytes());
            if(!m_param.input[0].is_object_bytes())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);
            }

            return join();
            break;

        case NB_FUNC_BYTES_RANGE:
        {
            //assert(2 == m_param.input.size());
            if (m_param.input.size() != 2)
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            nb_id_t result;
            ret = range(m_param.input[0], m_param.input[1], result);
            vout.push_back(result);
            break;
        }
        case NB_FUNC_BYTES_SIZE:
        {
            nb_id_t result;
            ret = size(result);
            vout.push_back(result);
            break;
        }
        case NB_FUNC_BYTES_SPLIT:
        {
            nb_id_t result0, result1;
            ret = split(result0, result1);
            vout.push_back(result0);
            vout.push_back(result1);
            break;
        }
        case NB_FUNC_BYTES_SPLITAT:
        {
            //assert(1 == m_param.input.size());
            if (m_param.input.size() != 1)
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

            nb_id_t result0, result1;
            ret = split_at(m_param.input[0], result0, result1);
            vout.push_back(result0);
            vout.push_back(result1);
            break;
        }
        case NB_FUNC_BYTES_CRC:
        {
            nb_id_t result;
            ret = crc(result);
            vout.push_back(result);
            break;
        }
        case NB_FUNC_BYTES_TO_STR:
        {
            nb_id_t result;
            ret = to_string(result);
            if (ret)
                vout.push_back(result);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    node_invocation_response response;
    response.output.objects = vout;
    response.child_transaction = m_param.transaction_id;
    response.success = ret;

    return run_respond(response);
}

bool func_bytes::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_bytes::get_value_response");

    nb_builtin_instruction_t builtin_ins;
    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_bytes::get_value_response() failed");

        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    if (NB_FUNC_GENERAL_RUN == builtin_ins)
    {
        return execution_base::get_value_response(req_num, output);
    }

    end_incoming_ins_call(req_num);

    // load raw data for in
    bytes_data_t in_bytes;
    nb_id_t in_id;
    obj_impl_bytes::unpack(output, in_id, in_bytes);

    switch (builtin_ins)
    {
        case NB_FUNC_GENERAL_COMPARE:
            return compare_result(in_bytes);
            break;
        case NB_FUNC_BYTES_JOIN:
            {
                //// load raw data for in
                //bytes_data_t in_bytes;
                //nb_id_t in_id;
                //obj_impl_bytes::unpack(output, in_id, in_bytes);

                bytes_data_t new_bytes = m_cData;
                new_bytes.value.append(in_bytes.value);
                make_bytes(new_bytes);

                // create new bytes object
                request_nb_id_info nb_info;
                nb_info.committer_id = m_param.host_committer_id;
                nb_info.type = NBID_TYPE_OBJECT_BYTES;
                obj_impl_bytes::pack(new_bytes, nb_id_t(), nb_info.raw_data);

                nb_id_t result;
                bool ret = request_nb_id(m_param.host_committer_id, 
                            nb_info,
                            result);

                node_invocation_response response;

                response.output.objects.push_back(result);
                response.child_transaction = m_param.transaction_id;
                response.success = ret;

                return run_respond(response);
            }
            break;
        default:
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
            break;
    }

    return false; 
}

bool func_bytes::compare_result(const bytes_data_t& val)
{
    LOG_DEBUG("*** func_bytes::compare_result");
    nb_id_t out;
    out.set_type(NBID_TYPE_OBJECT_BOOL);
    node_invocation_response response;

    std::size_t cResult =  m_cData.value.compare(val.value);
	if( cResult > 0)
    {
	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(true);
        response.output.objects.push_back(out);
    }
    else if(cResult < 0 )
    {
	    out.set_value(true);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);
    }
    else
    {
	    out.set_value(false);
        response.output.objects.push_back(out);

	    out.set_value(true);
        response.output.objects.push_back(out);

	    out.set_value(false);
        response.output.objects.push_back(out);
    }
    
    response.child_transaction = m_param.transaction_id;
    response.success = true;
    
    return run_respond(response);
}

bool func_bytes::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    return execution_base::obj_run_response(req_num, output);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
