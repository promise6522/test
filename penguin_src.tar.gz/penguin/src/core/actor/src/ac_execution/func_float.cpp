/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_float.h"
#include "ac_object/obj_algorithm.h"

bool func_float::get_name(nb_id_t& out)
{
#if 0
    float value;
    m_obj_id.get_value(value);

    char    sbuf[100];
    memset(sbuf, 0, sizeof(sbuf));
    sprintf(sbuf, "float_%f", value);

    std::string strs(sbuf);
    return request_string_object(strs, out); 
#endif
	return request_string_object("float", out); 
}

bool func_float::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_float::get_type(nb_id_t& type_id)
{
    return true;
}

bool func_float::add(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::add()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    out.set_value(value1 + value2);

    return true;
}

bool func_float::sub(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::sub()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    out.set_value(value1 - value2);

    return true;
}

bool func_float::mul(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::mul()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    out.set_value(value1 * value2);

    return true;
}

bool func_float::div(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::div()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);
    if (value2 == 0)
        return false;

    out = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
    //assert(1e-5);
    out.set_value(value1 / value2);

    return true;
}

bool func_float::eq(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::eq()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 == value2);

    return true;

}

bool func_float::lt(const nb_id_t& in, nb_id_t& out)
{
    LOG_DEBUG("func_float::lt()");

    float value1, value2;

    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 < value2);

    return true;

}

bool func_float::to_int(nb_id_t& out)
{
    float value1;
    m_obj_id.get_value(value1);

    int value2;
    value2 = static_cast<int>(value1);
    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    out.set_value(value2);
    
    return true;
}

bool func_float::to_string(nb_id_t& out)
{
    std::string str1;
    float value;
    m_obj_id.get_value(value);

    str1 = boost::lexical_cast<std::string>(value);
    return request_string_object(str1, out);
}


bool func_float::run()
{
    LOG_DEBUG("func_float::run()");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_FLOAT_ADD:
        {
            nb_id_t result; 
            ret = add(m_param.input[0], result);
            response.output.objects.push_back(result);
    
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float add is : "<<value);
            break;
        }
        case NB_FUNC_FLOAT_SUB:
        {
            nb_id_t result; 
            ret = sub(m_param.input[0], result);
            response.output.objects.push_back(result);
    
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float sub is : "<<value);
            break;
        }
        case NB_FUNC_FLOAT_IMUL:
        {
            nb_id_t result; 
            ret = mul(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float mul is : "<<value);
    
            break;
        }
        case NB_FUNC_FLOAT_IDIV:
        {
            nb_id_t result; 
            ret = div(m_param.input[0], result);
            response.output.objects.push_back(result);
            if (!ret)
                return run_exception_respond(m_param.transaction_id, CORPSE_IDIV_INPUT_IS_ZERO);
    
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float div is : "<<value);
    
            break;
        }
        case NB_FUNC_FLOAT_EQ:
        {
            nb_id_t result; 
            ret = eq(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float eq is : "<<value);
    
            break;
        }
        case NB_FUNC_FLOAT_LT:
        {
            nb_id_t result; 
            ret = lt(m_param.input[0], result);
            response.output.objects.push_back(result);
            /* debug */
            float value;
            result.get_value(value);
            LOG_NOTICE(" The result of float lt is : "<<value);
    
            break;
        }
        case NB_FUNC_FLOAT_TO_INT:
        {
            nb_id_t result;
            ret = to_int(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_FLOAT_TO_STRING:
        {
            nb_id_t result;
            ret = to_string(result);
            response.output.objects.push_back(result);
            break;
        }
        default:
            return execution_base::run();
            break;
    }

    response.success = ret;

    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
