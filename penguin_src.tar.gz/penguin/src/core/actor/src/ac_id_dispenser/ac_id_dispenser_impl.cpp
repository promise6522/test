/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_id_dispenser/ac_id_dispenser_impl.h"
#include "nb_net_tool.h"
#include "ac_global_db.h"

ac_id_dispenser_impl::ac_id_dispenser_impl()
{
    //set host id
    std::vector<in_addr_t> hosts;
    nb_getifaddrs_v4(hosts);
    if(!hosts.empty())
    {
        m_host_id = hosts[0];
    }
    else
    {
        LOG_ERROR("ac_id_dispense initialization: Could not get host ip address.");
        assert(!"Could not get host ip address.");
    }

    root_committer_id_t rc_start_id;
    if(!read_root_committer_id(rc_start_id))
    {
        //if there is not root committer information, just alloc first valid host committer id
        LOG_NOTICE("ac_id_dispenser_impl() : read_root_committer_id failed, just alloc new.");
        rc_start_id = rc_start_id + 1;
    }
    m_rc_id_block.first = rc_start_id;
    m_rc_id_block.second = 0;

    center_committer_id_t cc_start_id;
    if(!read_center_committer_id(cc_start_id))
    {
        //if there is not center committer information, just alloc first valid host committer id
        LOG_NOTICE("ac_id_dispenser_impl() : read_center_committer_id failed, just alloc new.");
        cc_start_id = cc_start_id + 1;
    }
    m_cc_id_block.first = cc_start_id;
    m_cc_id_block.second = 0;

    host_committer_id_t hc_start_id;
    if(!read_host_committer_id(hc_start_id))
    {
        //if there is not host committer information, just alloc first valid host committer id
        LOG_NOTICE("ac_id_dispenser_impl() : read_host_committer_id failed, just alloc new.");
        hc_start_id = hc_start_id + 1;
    }
    m_hc_id_block.first = hc_start_id;
    m_hc_id_block.second = 0;

    storage_id_t storage_start_id;
    if(!read_storage_id(storage_start_id))
    {
        //if there is not storage information, just alloc first valid storage id
        LOG_NOTICE("ac_id_dispenser_impl() : read_storage_id failed, just alloc new.");
        storage_start_id += 1;
    }
    m_storage_id_block.first = storage_start_id;
    m_storage_id_block.second = 0;

    anchor_id_t anchor_start_id;
    if(!read_anchor_id(anchor_start_id))
    {
        //if there is not anchor information, just alloc first valid anchor id
        LOG_NOTICE("ac_id_dispenser_impl() : read_anchor_id failed, just alloc new.");
        anchor_start_id += 1;
    }
    m_anchor_id_block.first = anchor_start_id;
    m_anchor_id_block.second = 0;

    bridge_id_t bridge_start_id;
    if(!read_bridge_id(bridge_start_id))
    {
        //if there is not bridge information, just alloc first valid bridge id
        LOG_NOTICE("ac_id_dispenser_impl() : read_bridge_id failed, just alloc new.");
        anchor_start_id += 1;
    }
    m_bridge_id_block.first = bridge_start_id;
    m_bridge_id_block.second = 0;
}

ac_id_dispenser_impl::~ac_id_dispenser_impl()
{
}

void ac_id_dispenser_impl::initialize()
{
    LOG_DEBUG("ac_id_dispenser_impl->initialize.");
    alloc_rc_id_block();
    alloc_cc_id_block();
    alloc_hc_id_block();

    alloc_anchor_id_block();
    alloc_storage_id_block();
    alloc_bridge_id_block();
}

root_committer_id_t ac_id_dispenser_impl::get_first_free_rcid()
{
    return m_rc_id_block.first;
}

center_committer_id_t ac_id_dispenser_impl::get_first_free_ccid()
{
    return m_cc_id_block.first;
}

host_committer_id_t ac_id_dispenser_impl::get_first_free_hcid()
{
    return m_hc_id_block.first;
}

storage_id_t ac_id_dispenser_impl::get_first_free_storageid()
{
    return m_storage_id_block.first;
}

anchor_id_t ac_id_dispenser_impl::get_first_free_anchorid()
{
    return m_anchor_id_block.first;
}

bridge_id_t ac_id_dispenser_impl::get_first_free_bridgeid()
{
    return m_bridge_id_block.first;
}

void ac_id_dispenser_impl::alloc_rc_id_block()
{
    if(!write_root_committer_id(m_rc_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_rc_id_block: write_root_committer_id failed.");
    }
    
    m_rc_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New root committer id block: from %s with %lu",
               m_rc_id_block.first.str().c_str(), m_rc_id_block.second);
#else
    LOG_FORMAT("New root committer id block: from %s with %d",
               m_rc_id_block.first.str().c_str(), m_rc_id_block.second);
#endif
}

void ac_id_dispenser_impl::alloc_cc_id_block()
{
    if(!write_center_committer_id(m_cc_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_hc_id_block: write_hostcommitter_id failed.");
    }
    
    m_cc_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New center committer id block: from %s with %lu",
               m_cc_id_block.first.str().c_str(), m_cc_id_block.second);
#else
    LOG_FORMAT("New center committer id block: from %s with %d",
               m_cc_id_block.first.str().c_str(), m_cc_id_block.second);
#endif
}

void ac_id_dispenser_impl::alloc_hc_id_block()
{
    if(!write_host_committer_id(m_hc_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_hc_id_block: write_hostcommitter_id failed.");
    }
    
    m_hc_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New host committer id block: from %s with %lu",
               m_hc_id_block.first.str().c_str(), m_hc_id_block.second);
#else
    LOG_FORMAT("New host committer id block: from %s with %d",
               m_hc_id_block.first.str().c_str(), m_hc_id_block.second);
#endif
}

void ac_id_dispenser_impl::alloc_storage_id_block()
{
    if(!write_storage_id(m_storage_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_storgae_id_block: write db failed.");
    }
    
    m_storage_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New storage id block: from %s with %lu",
               m_storage_id_block.first.str().c_str(), m_storage_id_block.second);
#else
    LOG_FORMAT("New storage id block: from %s with %d",
               m_storage_id_block.first.str().c_str(), m_storage_id_block.second);
#endif
}

void ac_id_dispenser_impl::alloc_anchor_id_block()
{
    if(!write_anchor_id(m_anchor_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_anchor_id_block: write db failed.");
    }
    
    m_anchor_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New anchor id block: from %s with %lu",
               m_anchor_id_block.first.str().c_str(), m_anchor_id_block.second);
#else
    LOG_FORMAT("New anchor id block: from %s with %d",
               m_anchor_id_block.first.str().c_str(), m_anchor_id_block.second);
#endif
}

void ac_id_dispenser_impl::alloc_bridge_id_block()
{
    if(!write_bridge_id(m_bridge_id_block.first + Default_Id_Block_Size))
    {
        LOG_ERROR("ac_id_dispenser_impl->alloc_bridge_id_block: write db failed.");
    }
    
    m_bridge_id_block.second += 2 * Default_Id_Block_Size;
#ifdef _NB_64_PLATFORM_
    LOG_FORMAT("New bridge id block: from %s with %lu",
               m_bridge_id_block.first.str().c_str(), m_bridge_id_block.second);
#else
    LOG_FORMAT("New bridge id block: from %s with %d",
               m_bridge_id_block.first.str().c_str(), m_bridge_id_block.second);
#endif
}

root_committer_id_t ac_id_dispenser_impl::request_root_committer_id()
{
    //if current id block size is less than Default_Id_Block_Size
    if(m_rc_id_block.second < Default_Id_Block_Size)
    {
        alloc_rc_id_block();
    }

    assert(m_rc_id_block.second > 0);

    --m_rc_id_block.second;    
    root_committer_id_t rc_id = m_rc_id_block.first;
    m_rc_id_block.first += 1;

    //rc_id.set_center_id(m_center_id);
    //rc_id.set_host_id(m_host_id);

    return rc_id;
}

center_committer_id_t ac_id_dispenser_impl::request_center_committer_id()
{
    //if current id block size is less than Default_Id_Block_Size
    if(m_cc_id_block.second < Default_Id_Block_Size)
    {
        alloc_cc_id_block();
    }    

    --m_cc_id_block.second;    
    center_committer_id_t cc_id = m_cc_id_block.first;
    m_cc_id_block.first += 1;

    //cc_id.set_center_id(m_center_id);
    //cc_id.set_host_id(m_host_id);
    return cc_id;
}

host_committer_id_t ac_id_dispenser_impl::request_host_committer_id()
{
    //if current id block size is less than Default_Id_Block_Size
    if(m_hc_id_block.second < Default_Id_Block_Size)
    {
        alloc_hc_id_block();
    }    

    --m_hc_id_block.second;    
    host_committer_id_t hc_id = m_hc_id_block.first;
    m_hc_id_block.first += 1;
    
    hc_id.set_host_id(m_host_id);
    return hc_id;
}

void ac_id_dispenser_impl::set_host_id(host_id_t host_id)
{
    m_host_id = host_id;
}

host_id_t ac_id_dispenser_impl::get_host_id()
{
    return m_host_id;
}

void ac_id_dispenser_impl::set_center_id(center_id_t center_id)
{
    m_center_id = center_id;    
}

center_id_t ac_id_dispenser_impl::get_center_id()
{
    return m_center_id;    
}

nb_id_t ac_id_dispenser_impl::request_nb_id(const host_committer_id_t& hc_id, std::size_t type)
{
    //add the empty host_committer_id for protected using empty hc_id to request id;
    static host_committer_id_t backup_hc_id = request_host_committer_id();

    host_committer_id_t cur_hc_id = hc_id;
    if(cur_hc_id == host_committer_id_t())
    {
        //need to request new host committer id?
        std::map<host_committer_id_t, nb_id_t>::iterator it = m_hcid_nbid_map.find(backup_hc_id);
        if(it != m_hcid_nbid_map.end())
        {
            std::size_t dyn_num = it->second.get_dynamic_num();
            //if current dynamic number almost be used, alloc new host committer id
            if(dyn_num > 0xFFFF00)
            {
                backup_hc_id = request_host_committer_id();
            }
        }
        
        cur_hc_id = backup_hc_id;
    }
    
    nb_id_t nb_id;
    std::map<host_committer_id_t, nb_id_t>::iterator it = m_hcid_nbid_map.find(cur_hc_id);

    //already contain the host_committer_id
    if(it != m_hcid_nbid_map.end())
    {
        m_hcid_nbid_map[cur_hc_id] += 1;
        nb_id = m_hcid_nbid_map[cur_hc_id];
        nb_id.set_type(type);
        return nb_id;
    }

    //no host committer id, just insert one
    nb_id.set_hostcommitterid(cur_hc_id);
    nb_id += 1;    
    nb_id.set_type(type);
    m_hcid_nbid_map[cur_hc_id] = nb_id;
    return nb_id;
}

anchor_id_t ac_id_dispenser_impl::request_anchor_id()
{
    //if current id block size is less than Default_Id_Block_Size
    if(m_anchor_id_block.second < Default_Id_Block_Size)
    {
        alloc_anchor_id_block();
    }

    assert(m_anchor_id_block.second > 0);

    --m_anchor_id_block.second;    
    anchor_id_t anchor_id = m_anchor_id_block.first;
    m_anchor_id_block.first += 1;

    return anchor_id;    
}

transaction_id_t ac_id_dispenser_impl::request_transaction_id(const host_committer_id_t& host_comm_id)
{
    transaction_id_t trans_id;
    std::map<host_committer_id_t, transaction_id_t>::iterator it = m_hcid_trid_map.find(host_comm_id);

    //already contain the host_committer_id
    if(it != m_hcid_trid_map.end())
    {
        m_hcid_trid_map[host_comm_id] += 1;
        trans_id = m_hcid_trid_map[host_comm_id];        
        //trans_id.set_type(type);
        return trans_id;
    }

    //no host committer id, just insert one
    trans_id.set_hostcommitterid(host_comm_id);
    //nb_id.set_type(type);
    trans_id += 1;    
    m_hcid_trid_map[host_comm_id] = trans_id;
    return trans_id;
}

storage_id_t ac_id_dispenser_impl::request_storage_id(std::size_t type)
{
    //if current id block size is less than Default_Id_Block_Size
    if(m_storage_id_block.second < Default_Id_Block_Size)
    {
        alloc_storage_id_block();
    }

    assert(m_storage_id_block.second > 0);

    --m_storage_id_block.second;    
    storage_id_t storage_id = m_storage_id_block.first;
    storage_id.set_type(static_cast<nbid_type_t>(type));
    m_storage_id_block.first += 1;

    return storage_id;
}

bridge_id_t ac_id_dispenser_impl::request_bridge_id()
{
     //if current id block size is less than Default_Id_Block_Size
    if(m_bridge_id_block.second < Default_Id_Block_Size)
    {
        alloc_bridge_id_block();
    }

    assert(m_bridge_id_block.second > 0);

    --m_bridge_id_block.second;    
    bridge_id_t bridge_id = m_bridge_id_block.first;
    m_bridge_id_block.first += 1;
    bridge_id.set_host_id(m_host_id);
    
    return bridge_id;    
}

facade_id_t ac_id_dispenser_impl::request_facade_id(const host_committer_id_t& host_comm_id)
{
    facade_id_t facade_id;
    std::map<host_committer_id_t, facade_id_t>::iterator it = m_hcid_fdid_map.find(host_comm_id);

    //already contain the host_committer_id
    if(it != m_hcid_fdid_map.end())
    {
        m_hcid_fdid_map[host_comm_id] += 1;
        facade_id = m_hcid_fdid_map[host_comm_id];
        return facade_id;
    }

    //no host committer id, just insert one
    facade_id.set_hostcommitterid(host_comm_id);
    facade_id += 1;
    m_hcid_fdid_map[host_comm_id] = facade_id;
    return facade_id;
}

container_id_t ac_id_dispenser_impl::request_container_id(const host_committer_id_t& host_comm_id)
{
    container_id_t container_id;
    std::map<host_committer_id_t, container_id_t>::iterator it = m_hcid_contid_map.find(host_comm_id);

    //already contain the host_committer_id
    if(it != m_hcid_contid_map.end())
    {
        m_hcid_contid_map[host_comm_id] += 1;
        container_id = m_hcid_contid_map[host_comm_id];
        return container_id;
    }

    //no host committer id, just insert one
    container_id.set_hostcommitterid(host_comm_id);
    container_id += 1;
    m_hcid_contid_map[host_comm_id] = container_id;
    return container_id;
}

access_id_t ac_id_dispenser_impl::request_access_id(const host_committer_id_t& host_comm_id,
                                                    std::size_t type)
{
    access_id_t access_id;
    std::map<host_committer_id_t, access_id_t>::iterator it = m_hcid_acid_map.find(host_comm_id);

    //already contain the host_committer_id
    if(it != m_hcid_acid_map.end())
    {
        m_hcid_acid_map[host_comm_id] += 1;
        access_id = m_hcid_acid_map[host_comm_id];
        //nb_id.set_type(type);
        return access_id;
    }

    //no host committer id, just insert one
    access_id.set_hostcommitterid(host_comm_id);
    access_id += 1;
    //access_id.set_type(type);
    m_hcid_acid_map[host_comm_id] = access_id;
    return access_id;
}

execution_id_t ac_id_dispenser_impl::request_execution_id(const host_committer_id_t& host_comm_id)
{
    execution_id_t exe_id;
    std::map<host_committer_id_t, execution_id_t>::iterator it = m_hcid_exeid_map.find(host_comm_id);

    //already contain the host_committer_id
    if(it != m_hcid_exeid_map.end())
    {
        m_hcid_exeid_map[host_comm_id] += 1;
        exe_id = m_hcid_exeid_map[host_comm_id];
        //nb_id.set_type(type);        
        return exe_id;
    }

    //no host committer id, just insert one
    exe_id.set_hostcommitterid(host_comm_id);
    exe_id += 1;
    //nb_id.set_type(type);
    m_hcid_exeid_map[host_comm_id] = exe_id;
    return exe_id;
}

