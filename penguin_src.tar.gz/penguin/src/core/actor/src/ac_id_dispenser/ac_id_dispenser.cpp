/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_id_dispenser.h"
#include "ac_global_db.h"

const req_num_t hc_req_num(1, true);

bool ac_id_dispenser::initialization()
{
    LOG_DEBUG("ac_id_dispense->initialization: initializing...");    
   
    //call implement to get id_block
    m_impl.initialize();
    return true;
}

bool ac_id_dispenser::destruction()
{
    LOG_INFO("ac_id_dispense destruction: destrying....");

    if(!write_root_committer_id(m_impl.get_first_free_rcid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_root_committer_id failed.");
        return false;
    }

    if(!write_center_committer_id(m_impl.get_first_free_ccid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_center_committer_id failed.");
        return false;
    }
    
    if(!write_host_committer_id(m_impl.get_first_free_hcid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_host_committer_id failed.");
        return false;
    }

    if(!write_storage_id(m_impl.get_first_free_storageid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_storage_id failed.");
        return false;
    }
    
    if(!write_anchor_id(m_impl.get_first_free_anchorid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_anchor_id failed.");
        return false;
    }

    if(!write_bridge_id(m_impl.get_first_free_bridgeid()))
    {
        LOG_ERROR("ac_id_dispenser->destruction: write_bridge_id failed.");
        return false;
    }

    return true;
}

bool ac_id_dispenser::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_id_dispenser::request_id(const dispenser_request_type& input, dispenser_result& output)
{
    return true;
}

bool ac_id_dispenser::request_anchor_id(const request_anchor_id_info& input, anchor_id_t& output)
{
    output = m_impl.request_anchor_id();
    return ac_manager::instance().request_actor_with_data(output, input.raw_data);;
}

bool ac_id_dispenser::request_alone_anchor_id(anchor_id_t& output)
{
    output = m_impl.request_anchor_id();
    return true;
}

bool ac_id_dispenser::get_center_id(center_id_t& output)
{
    output = m_impl.get_center_id();
    return true;
}

bool ac_id_dispenser::get_host_id(host_id_t& output)
{
    output = m_impl.get_host_id();
    return true;
}

bool ac_id_dispenser::request_access_id(const request_access_id_info& input, access_id_t& output)
{
    output = m_impl.request_access_id(input.committer_id, input.type);
    return ac_manager::instance().request_actor_with_data(output, input.raw_data);
}

bool ac_id_dispenser::request_alone_access_id(const request_alone_access_id_info& input, access_id_t& output)
{
    output = m_impl.request_access_id(input.committer_id, input.type);
    return true;    
}

bool ac_id_dispenser::request_nb_id(const request_nb_id_info& input, nb_id_t& output)
{
    output = m_impl.request_nb_id(input.committer_id, input.type);
    content raw_data = {input.raw_data.id_value, output};
    return ac_manager::instance().request_actor_with_data(output, raw_data);
}

bool ac_id_dispenser::request_alone_nb_id(const request_alone_nb_id_info& input, nb_id_t& output)
{
    output = m_impl.request_nb_id(input.committer_id, input.type);
    return true;
}

bool ac_id_dispenser::request_transaction_id(const host_committer_id_t& input, transaction_id_t& output)
{
    output = m_impl.request_transaction_id(input);
    return ac_manager::instance().request_actor(output);
}

bool ac_id_dispenser::request_center_committer_id(center_committer_id_t& output)
{
    output = m_impl.request_center_committer_id();    
    return ac_manager::instance().request_actor(output);
}

bool ac_id_dispenser::request_storage_id(const request_storage_id_info& input, storage_id_t& output)
{
    output = m_impl.request_storage_id(input.type);
    content raw_data = {input.raw_data.id_value, nb_id_t()};
    return ac_manager::instance().request_actor_with_data(output, raw_data);
}

bool ac_id_dispenser::request_alone_storage_id(const request_alone_storage_id_info& input, storage_id_t& output)
{
    output = m_impl.request_storage_id(input.type);
    return true;
}

bool ac_id_dispenser::request_bridge_id(const bridge_content& input, bridge_id_t& output)
{
    output = m_impl.request_bridge_id();
    return ac_manager::instance().request_actor_with_data(output, input);
}

bool ac_id_dispenser::request_exe_bridge_id(const bridge_execute_impl_flag& input, bridge_id_t& output)
{
    output = m_impl.request_bridge_id();
    return ac_manager::instance().request_actor_with_data(output, input);
}

bool ac_id_dispenser::request_facade_id(const request_facade_id_info& input, facade_id_t& output)
{
    output = m_impl.request_facade_id(input.committer_id);
    return ac_manager::instance().request_actor_with_data(output, input.storage_id);
}

bool ac_id_dispenser::request_host_committer_id(host_committer_id_t& output)
{
    output = m_impl.request_host_committer_id();
    return ac_manager::instance().request_actor(output);
}

bool ac_id_dispenser::request_container_id(const request_container_id_info& input, container_id_t& output)
{
    output = m_impl.request_container_id(input.committer_id);
    return ac_manager::instance().request_actor_with_data(output, input.raw_data);
}

bool ac_id_dispenser::request_alone_container_id(const request_alone_container_id_info& input, container_id_t& output)
{
    output = m_impl.request_container_id(input.committer_id);
    return true;
}

bool ac_id_dispenser::request_execution_id(const request_execution_id_info& input, execution_id_t& output)
{
    output = m_impl.request_execution_id(input.committer_id);
    return ac_manager::instance().request_actor_with_data(output, input.exec_info);
}

bool ac_id_dispenser::request_root_committer_id(root_committer_id_t& output)
{
    output = m_impl.request_root_committer_id();
    return ac_manager::instance().request_actor(output);
}
