/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _NB_SEMI_INFO_MANAGER_H_
#define _NB_SEMI_INFO_MANAGER_H_

#include "stdx_json.h"
#include "nb_typedef.h"

#define CREATE_SEMI_OBJECTS

struct nb_semi_info
{
    nb_id_vector semi_obj;
    nb_id_vector semi_if;
    nb_id_vector semi_decl;
    nb_id_vector semi_impl;
    nb_id_vector semi_access;
    std::vector<container_id_t> semi_cont;    
};

inline bool nb_pack_semi_info(const nb_semi_info& info, std::string& str_value)
{
    //add the root 
    stdx::json_object root;

    //pack semi object
    stdx::json_array* semi_obj = new stdx::json_array();
    root.insert("semi_obj", semi_obj);    
    for(nb_id_vector_const_it it = info.semi_obj.begin(); it != info.semi_obj.end(); ++it)
    {
        semi_obj->push_back(new stdx::json_string(it->str()));
    }

    //pack semi interface
    stdx::json_array* semi_if = new stdx::json_array();
    root.insert("semi_if", semi_if);    
    for(nb_id_vector_const_it it = info.semi_if.begin(); it != info.semi_if.end(); ++it)
    {
        semi_if->push_back(new stdx::json_string(it->str()));
    }

    //pack semi declaration
    stdx::json_array* semi_decl = new stdx::json_array();
    root.insert("semi_decl", semi_decl);    
    for(nb_id_vector_const_it it = info.semi_decl.begin(); it != info.semi_decl.end(); ++it)
    {
        semi_decl->push_back(new stdx::json_string(it->str()));
    }

    //pack semi implementation
    stdx::json_array* semi_impl = new stdx::json_array();
    root.insert("semi_impl", semi_impl);    
    for(nb_id_vector_const_it it = info.semi_impl.begin(); it != info.semi_impl.end(); ++it)
    {
        semi_impl->push_back(new stdx::json_string(it->str()));
    }

    //pack semi access
    stdx::json_array* semi_access = new stdx::json_array();
    root.insert("semi_access", semi_access);    
    for(nb_id_vector_const_it it = info.semi_access.begin(); it != info.semi_access.end(); ++it)
    {
        semi_access->push_back(new stdx::json_string(it->str()));
    }

    //pack semi container
    stdx::json_array* semi_cont = new stdx::json_array();
    root.insert("semi_cont", semi_cont);    
    for(std::vector<container_id_t>::const_iterator it = info.semi_cont.begin();
        it != info.semi_cont.end(); ++it)
    {
        semi_cont->push_back(new stdx::json_string(it->str()));
    }

    str_value = root.to_json_string();    
    return true;
}

inline bool nb_unpack_semi_info(const std::string& str_value, nb_semi_info& info)
{
    if(str_value.empty())
        return false;    
    
    //clear
    info = nb_semi_info();
    
    //start parse root
    boost::scoped_ptr<stdx::json_object> root(dynamic_cast<stdx::json_object*>
                                              (stdx::json_tokener_parse(str_value)));
    assert(root);

    //unpack object
    stdx::json_array *semi_obj = dynamic_cast<stdx::json_array*>(root->find("semi_obj"));
    assert(semi_obj);
    for(int i = 0; i < semi_obj->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_obj->at(i));
        info.semi_obj.push_back(nb_id_t(id_str->get_string()));        
    }

    //unpack interface
    stdx::json_array *semi_if = dynamic_cast<stdx::json_array*>(root->find("semi_if"));
    assert(semi_if);
    for(int i = 0; i < semi_if->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_if->at(i));
        info.semi_if.push_back(nb_id_t(id_str->get_string()));        
    }

    //unpack declaration
    stdx::json_array *semi_decl = dynamic_cast<stdx::json_array*>(root->find("semi_decl"));
    assert(semi_decl);
    for(int i = 0; i < semi_decl->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_decl->at(i));
        info.semi_decl.push_back(nb_id_t(id_str->get_string()));        
    }

    //unpack implemetaion
    stdx::json_array *semi_impl = dynamic_cast<stdx::json_array*>(root->find("semi_impl"));
    assert(semi_impl);
    for(int i = 0; i < semi_impl->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_impl->at(i));
        info.semi_impl.push_back(nb_id_t(id_str->get_string()));        
    }

    //unpack access
    stdx::json_array *semi_access = dynamic_cast<stdx::json_array*>(root->find("semi_access"));
    assert(semi_access);
    for(int i = 0; i < semi_access->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_access->at(i));
        info.semi_access.push_back(nb_id_t(id_str->get_string()));        
    }

    //unpack container
    stdx::json_array *semi_cont = dynamic_cast<stdx::json_array*>(root->find("semi_cont"));
    assert(semi_cont);
    for(int i = 0; i < semi_cont->size(); ++i)
    {
        stdx::json_string* id_str = dynamic_cast<stdx::json_string*>(semi_cont->at(i));
        info.semi_cont.push_back(container_id_t(id_str->get_string()));
    }

    return true;
}

class nb_semi_info_manager
{
private:
	nb_semi_info_manager(void)
    {
    }    
	~nb_semi_info_manager(void)
    {
    }
    nb_semi_info_manager(const nb_semi_info_manager&);
	nb_semi_info_manager& operator=(const nb_semi_info_manager&);

public:
	static nb_semi_info_manager& instance()
    {
        static nb_semi_info_manager manager;
        return manager;        
    }
    bool create_semi_info(nb_semi_info& info);
    bool load_semi_info(nb_semi_info& info);

private:
    nb_id_t create_watermark(const host_committer_id_t& hc_id);    
    bool request_nb_id(const request_nb_id_info& nb_info, nb_id_t& id);
    bool request_host_committer_id(host_committer_id_t& hc_id);
};

#endif /* _NB_SEMI_OBJECT_H_ */
