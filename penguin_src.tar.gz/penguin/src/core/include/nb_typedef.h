#ifndef __NB_TYPEDEF_H
#define __NB_TYPEDEF_H

#include <vector>
#include <string>
#include <map>

#include "nb_id.h"
#include "ac_message_type.h"
#include "ac_req_num.h"
#include "ac_global.h"

typedef std::pair<nb_id_t, nb_id_t>  nb_id_pair;
typedef std::pair<nb_builtin_instruction_t, nb_builtin_instruction_t>  instruction_pair_t;

typedef std::vector<nb_id_t>   nb_id_vector;
typedef nb_id_vector::iterator   nb_id_vector_it;
typedef nb_id_vector::const_iterator   nb_id_vector_const_it;
typedef nb_id_vector::size_type   nb_id_vector_size_t;

typedef std::vector<func_pair_t>   func_vector;
typedef func_vector::iterator   func_vector_it;
typedef func_vector::const_iterator   func_vector_const_it;

typedef std::vector<unsigned int>   fileid_vector;
typedef fileid_vector::iterator   fileid_vector_it;
typedef fileid_vector::const_iterator   fileid_vector_const_it;

typedef std::vector<std::string>   nb_str_vector;
typedef nb_str_vector::iterator   nb_str_vector_it;
typedef nb_str_vector::const_iterator   nb_str_vector_const_it;

typedef std::map<nb_id_t, nb_id_t> nb_id_map;
typedef nb_id_map::iterator nb_id_map_it;
typedef nb_id_map::const_iterator nb_id_map_const_it;

typedef std::multimap<nb_id_t, nb_id_t> nb_id_multimap;
typedef nb_id_multimap::iterator nb_id_multimap_it;
typedef nb_id_multimap::const_iterator nb_id_multimap_const_it;
typedef std::pair<nb_id_multimap_const_it, nb_id_multimap_const_it> nb_id_multimap_pair;

typedef std::vector<std::pair<nb_id_t, nb_id_t> > nb_id_pair_vector;
typedef nb_id_pair_vector::iterator    nb_id_pair_vector_it;
typedef nb_id_pair_vector::const_iterator    nb_id_pair_vector_const_it;

typedef std::vector<std::pair<nb_id_t, std::string> > nb_idstr_pair_vector;
typedef nb_idstr_pair_vector::iterator    nb_idstr_pair_vector_it;
typedef nb_idstr_pair_vector::const_iterator    nb_idstr_pair_vector_const_it;


typedef std::map<req_num_t, call_id_t> req_map;
typedef req_map::iterator req_map_it;
typedef req_map::const_iterator req_map_const_it;

typedef std::map<req_num_t, nb_builtin_instruction_t> builtin_instruction_map;
typedef builtin_instruction_map::iterator builtin_instruction_map_it;
typedef builtin_instruction_map::const_iterator builtin_instruction_map_const_it;

typedef std::map<req_num_t, instruction_pair_t> num_ins_pair_map;
typedef num_ins_pair_map::iterator num_ins_pair_map_it;
typedef num_ins_pair_map::const_iterator num_ins_pair_map_const_it;

typedef std::map<req_num_t, nb_id_t> num_obj_map;
typedef num_obj_map::iterator num_obj_map_it;
typedef num_obj_map::const_iterator num_obj_map_const_it;

#endif // __NB_TYPEDEF_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
