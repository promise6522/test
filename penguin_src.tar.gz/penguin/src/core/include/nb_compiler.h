#ifndef _NB_COMPILER_H_
#define _NB_COMPILER_H_

#include <string>
#include <map>

#include "nb_id.h"
#include "nb_compiler_type.h"


typedef std::map<int, editor_base_ptr>      index_editor_map;
typedef index_editor_map::iterator          index_editor_map_itr;
typedef index_editor_map::const_iterator    index_editor_map_const_itr;

typedef std::map<int, nb_id_t>              index_id_map;
typedef index_id_map::iterator              index_id_map_itr;
typedef index_id_map::const_iterator        index_id_map_const_itr;

typedef std::map<int, std::string>          index_string_map;
typedef index_string_map::iterator          index_string_map_itr;
typedef index_string_map::const_iterator    index_string_map_const_itr;


struct index_info_t
{
    int                 main_idx;
    index_editor_map    idx_xml_map;
    index_id_map        idx_id_map;
};


bool compile(const index_info_t& index_info, index_id_map& new_id_data, index_string_map& error_info);


#endif // _NB_COMPILER_H_

// vim:set tabstop=4 shiftwidth=4 expandtab:
