#ifndef RUN_ERROR_TYPE_T_H_
#define RUN_ERROR_TYPE_T_h_

enum run_error_type_t
{
    CORPSE_GENERAL_ERROR_TYPE = 0,


    // objects
    CORPSE_ARRAY_SIZE_ZERO,
    CORPSE_ARRAY_INVALID_INDEX,
    CORPSE_ARRAY_TYPE_NOT_MATCH,         //a bridge array can only insert special object except 2 bridge object

    CORPSE_MAP_INVALID_KEY,
    CORPSE_MAP_INVALID_VALUE,
    CORPSE_MAP_KEY_NOT_EXIST,

    CORPSE_STORAGE_RUN_FAILED,

    CORPSE_CONDITION_DECLARATION_WRONG,
    CORPSE_CONDITION_NO_ALTERNATE_EXECUTION,
    CORPSE_CONDITION_ISNOT_IMPLEMENT,

    CORPSE_ITERATOR_DECLARATION_WRONG,
    CORPSE_ITERATOR_ISNOT_IMPLEMENT,

    // run
    CORPSE_INPUT_INVALID,
    CORPSE_INPUT_NUM_IS_WRONG,

    CORPSE_GET_VALUE_FAILED,
    CORPSE_OBJ_RUN_FAILED,

    CORPSE_IDIV_INPUT_IS_ZERO,

    // db
    CORPSE_CONTAINER_DB_WRITE_FAILED,
    CORPSE_CONTAINER_DB_READ_FAILED,
    CORPSE_OBJECT_DB_WRITE_FAILED,
    CORPSE_OBJECT_DB_READ_FAILED,
    CORPSE_STORAGE_DB_WRITE_FAILED,
    CORPSE_STORAGE_DB_READ_FAILED,
    CORPSE_USER_CONTENT_DB_WRITE_FAILED,
    CORPSE_USER_CONTENT_DB_READ_FAILED,

    // memery allocate
    CORPSE_MEMORY_ALLOCATOR_FAILED,
    CORPSE_MEMORY_DEALLOCATE_FAILED,



    //run response
    CORPSE_OUTPUT_INVALID,
    CORPSE_OUTPUT_NUM_IS_WRONG,

    //storage,anchor can not be output
    CORPSE_INVALID_OUTPUT,

    //invalid anchor index
    CORPSE_ANCHOR_INDEX_INVALID,

    //invalid storage index
    CORPSE_STORAGE_INDEX_INVALID,

    //decl expanded
    CORPSE_DECL_EXPANDED_GENERATE_INTERFACE_FAILED,
    CORPSE_DECL_EXPANDED_GET_EXPANDED_DECL_INTERFACE_FAILED,

    //index wrong of get interface in func_user
    CORPSE_USER_GET_INTERFACE_INDEX_WRONG,

    //execution request id failed
    CORPSE_EXEC_REQUEST_ID_FAILED,

    CORPSE_INITIALIZE_FAILED,

    CORPSE_TYPE_MAX                         // 28
};

const std::string run_error_string[] = 
{
    "corpse_general_error_type",


    // objects
    "corpse_array_is_null",
    "corpse_array_invalid_index",
    "corpse_array_type_not_match",

    "corpse_map_invalid_key",
    "corpse_map_invalid_value",
    "corpse_map_key_not_exist",

    "corpse_storage_run_failed",

    "corpse_condition_declaration_wrong",
    "corpse_condition_no_alternate_execution",
    "corpse_condition_isnot_implement",

    "corpse_iterator_declaration_wrong",
    "corpse_iterator_isnot_implement",

    // run
    "corpse_input_invalid",
    "corpse_input_num_is_wrong",

    "corpse_get_value_failed",
    "corpse_obj_run_failed",

    "corpse_idiv_input_is_zero",

    // db
    "corpse_container_db_write_failed",
    "corpse_container_db_read_failed",
    "corpse_object_db_write_failed",
    "corpse_object_db_read_failed",
    "corpse_storage_db_write_failed",
    "corpse_storage_db_read_failed",
    "corpse_user_content_db_write_failed",
    "corpse_user_content_db_read_failed",

    // memery allocate
    "corpse_memory_allocator_failed",
    "corpse_memory_deallocate_failed",



    //run response
    "corpse_output_invalid",
    "corpse_output_num_is_wrong",

    //storage,anchor can not be output
    "corpse_invalid_output",
    
    //invalid anchor index
    "corpse_anchor_index_invalid",

    //invalid storage index
    "corpse_storage_index_invalid",

    //decl expanded 
    "corpse_decl_expanded_generate_interface_failed",
    "corpse_decl_expanded_get_expanded_decl_interface_failed",

    //index wrong of get interface in func_user
    "corpse_user_get_interface_index_wrong",

    //execution request id failed
    "corpse_exec_request_id_failed"

    "corpse_initialize_failed"

};

#endif //RUN_ERROR_TYPE_T_H_

//set tabstops=4 , set shiftwidth=4
