/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_CONFIGURATION_H_
#define _NB_CONFIGURATION_H_

#include <iostream>
#include <string>

#include <boost/program_options.hpp>
#include "nb_version.h"
//#include "stdx_log.h"

const char* const Default_Port_Number = "6666";                // in size_t, default 6666
const std::size_t Default_Socket_Thread_Pool_Size = 2;         // in size_t, default 2
const std::size_t Default_Actor_Thread_Pool_Size = 1;          // in size_t, default 1
const bool Default_Statistics_Option = false;                  // in bool, default false
const std::size_t Default_Statistics_Interval = 10;            // in second, default 10s
const std::size_t Default_Gabage_Collection_Option = false;    // in MB, default 2G
const std::size_t Default_Gabage_Collection_Mem_Size = 2000;   // in MB, default 2G
const std::size_t Default_Gabage_Collection_Mem_Rate = 1;      // in %, default 1%
const std::size_t Default_Log_Level = 2;                       // in log level, default 1
const std::size_t Default_DB_Checkpoint_Interval = 3 * 60;     // in second, default 3 mins

class nb_configuration
{
private:
    nb_configuration(void)
        : m_port(Default_Port_Number), m_socket_thread_pool(Default_Socket_Thread_Pool_Size),
          m_actor_thread_pool(Default_Actor_Thread_Pool_Size), m_is_gc(Default_Gabage_Collection_Option),
          m_gc_size(Default_Gabage_Collection_Mem_Size), m_gc_rate(Default_Gabage_Collection_Mem_Rate),
          m_is_statistics(Default_Statistics_Option), m_statistics_interval(Default_Statistics_Interval),
          m_log_level(Default_Log_Level)
    {
    }
    ~nb_configuration(void)
    {
    }
    
    nb_configuration(const nb_configuration&);
    nb_configuration& operator=(const nb_configuration&);

public:
    static nb_configuration& instance()
    {
        static nb_configuration config;
        return config;
    }

public:
    void parse_option(int ac, char* av[])
    {
        boost::program_options::options_description options("Nebutown server Daemon start options");
        boost::program_options::variables_map vm;

        try
        {            
            options.add_options()
                ("help", "print help message")
                ("version", "print version")
                ("port",
                 boost::program_options::value<std::string>(&m_port)->default_value(Default_Port_Number),
                 "set listen port number")
                ("ac_pool",
                 boost::program_options::value<std::size_t>(&m_actor_thread_pool)->default_value(Default_Actor_Thread_Pool_Size),
                 "set actor thread pool size")
                ("sock_pool",
                 boost::program_options::value<std::size_t>(&m_socket_thread_pool)->default_value(Default_Socket_Thread_Pool_Size),
                 "set socket thread pool size")
                ("gc",
                 boost::program_options::value<bool>(&m_is_gc)->default_value(Default_Gabage_Collection_Option),
                 "set gabage collection threshold in MB")

                ("gc_size",
                 boost::program_options::value<std::size_t>(&m_gc_size)->default_value(Default_Gabage_Collection_Mem_Size),
                 "set gabage collection threshold in MB")
                ("gc_rate",
                 boost::program_options::value<std::size_t>(&m_gc_rate)->default_value(Default_Gabage_Collection_Mem_Rate),
                 "set gabage collection threshold in percent")
                ("st",
                 boost::program_options::value<bool>(&m_is_statistics)->default_value(Default_Statistics_Option),
                 "enable statistics thread for ac_manager")
                ("interval",
                 boost::program_options::value<std::size_t>(&m_statistics_interval)->default_value(Default_Statistics_Interval),
                 "set statistics thread execution interval")
                ("log",
                 boost::program_options::value<std::size_t>(&m_log_level)->default_value(Default_Log_Level),
                 "set log level")
        
                ("chkpoint",
                 boost::program_options::value<std::size_t>(&m_db_chkpoint_interval)->default_value(Default_DB_Checkpoint_Interval),
                 "set database checkpoint interval");

            boost::program_options::store(boost::program_options::parse_command_line(ac, av, options), vm);
            boost::program_options::notify(vm);

            if (vm.count("help"))
            {
                std::cout << options << std::endl;
                exit(0);
            }
            else if (vm.count("version"))
            {
                std::cout <<"==============================================================="<<std::endl;
                std::cout <<"                Nebutown Server Daemon"<<std::endl
                          <<"    Copyright © 2011 Nebutown Corp."<<std::endl
                          <<"    Version: "<< nb_version_string << std::endl
                          <<"    Build  Time: "<< nb_build_time_string << std::endl
                          <<"    Change Time: "<< nb_version_time_string << std::endl;
                std::cout <<"==============================================================="<<std::endl;
                exit(0);
            }
        }
        catch(std::exception& e)
        {
            std::cerr << "error: " << e.what() << ".\n";
            std::cout << options << "\n";
            exit(0);
        }
        catch(...)
        {
            std::cerr << "Exception of unknown type.\n";
            std::cout << options << "\n";
            exit(0);
        }        
    }

    //get option
    std::string get_port_number()
    {
        return m_port;
    }

    std::size_t get_socket_thread_pool()
    {
        return m_socket_thread_pool;
    }

    std::size_t get_actor_thread_pool()
    {
        return m_actor_thread_pool;
    }

    bool get_is_statistics()
    {
        return m_is_statistics;
    }

    std::size_t get_statistics_interval()
    {
        return m_statistics_interval;
    }

    bool get_is_gc()
    {
        return m_is_gc;
    }

    std::size_t get_gc_size()
    {
        return m_gc_size;
    }

    std::size_t get_gc_rate()
    {
        return m_gc_rate;
    }

    std::size_t& get_log_level()
    {
        return m_log_level;
    }

    std::size_t get_db_chkpoint_interval()
    {
        return m_db_chkpoint_interval;
    }

    void dump_configuration()
    {
        std::cout<<"--------dump configuration---------"<<std::endl;
        std::cout<<"port = "<<m_port<<std::endl;
        std::cout<<"actor_thread_pool = "<<m_actor_thread_pool<<std::endl;
        std::cout<<"socket_thread_pool = "<<m_socket_thread_pool<<std::endl;
        std::cout<<"gabage collection option = "<<(m_is_gc  ? "true" : "false")<<std::endl;
        std::cout<<"gabage collection threshold = "<<m_gc_size<<" MB"<<std::endl;
        std::cout<<"gabage collection rate = "<<m_gc_rate<<"%"<<std::endl;
        std::cout<<"statistics_option = "<<(m_is_statistics ? "true" : "false")<<std::endl;
        std::cout<<"statistics_interval = "<<m_statistics_interval<<std::endl;
        std::cout<<"log level = "<<m_log_level<<std::endl;
        std::cout<<"db checkpoint interval = "<<m_db_chkpoint_interval<<std::endl;
        std::cout<<"-----------------------------------"<<std::endl;        
    }
    
private:
    std::string m_port;
    std::size_t m_socket_thread_pool;
    std::size_t m_actor_thread_pool;
    bool m_is_gc;
    std::size_t m_gc_size;
    std::size_t m_gc_rate;
    bool m_is_statistics;
    std::size_t m_statistics_interval;
    std::size_t m_log_level;
    std::size_t m_db_chkpoint_interval;
};

#endif /* _NB_CONFIGURATION_H_ */
