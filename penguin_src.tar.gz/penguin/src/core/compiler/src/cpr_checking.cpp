/********************************************************************************************************************
**
**                                       Copyleft 2011 YunCheng Inc.
**
*********************************************************************************************************************/

#include "cpr_checking.h"
#include "ac_object/data_unpacker.h"
#include "ac_object/obj_impl_declaration.h"

checking_datas::checking_datas(const index_editor_map& idx_editor_map, const index_id_map& idx_id_map)
{
    m_idx_editor_map = idx_editor_map;
    m_idx_id_map     = idx_id_map;
}

checking_datas::~checking_datas()
{
}

// ======================================= read data from db by nb_id and unpack_data ================================

bool checking_datas::unpack_to_ifc_data(const content& data, if_compound_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_interface_compound::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_decl_expanded_data(const content& data, decl_expanded_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_decl_expanded::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_decl_compound_data(const content& data, decl_compound_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_decl_compound::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_exec_cond_data(const content& data, exec_cond_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_exec_condition::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_exec_iterator_data(const content& data, exec_iterator_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_exec_iterator::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_exec_obj_func_data(const content& data, exec_obj_func_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_exec_obj_func::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_array_data(const content& data, array_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_array::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_map_data(const content& data, map_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_map::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_bridge_data(const content& data, bridge_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_bridge::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_user_data(const content& data, user_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_user::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_access_data(const content& data, access_data_t& logic_data)
{
    access_implementation::unpack(data, logic_data);
    return true;
}

bool checking_datas::unpack_to_bridge_if_data(const content& data, bridge_interface_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_bridge_interface::unpack(data, id, logic_data);
    return true;
}

bool checking_datas::unpack_to_exec_storage_data(const content& data, exec_storage_func_data_t& logic_data)
{
    nb_id_t id;
    obj_impl_exec_storage_func::unpack(data, id, logic_data);
    return true;
}

// ======================================= functions for assistance =================================================

bool checking_datas::get_portNums_by_nodeIdx(const int& idx_of_node, int& port_nums, const bool& is_iport)
{
    index_editor_map_itr editor_it = m_idx_editor_map.find(idx_of_node);
    index_id_map_itr     id_it     = m_idx_id_map.find(idx_of_node);

    if (editor_it != m_idx_editor_map.end())
    {
        int index_decl;

        switch (editor_it->second->get_editor_type())
        {
            case e_ObjectFunctionExecutable_editor:
                {
                    ObjectFunctionExecutable_editor_ptr obj_ptr = std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(editor_it->second);

                    if (obj_ptr == NULL)
                        return false;

                    index_decl = obj_ptr->get_selectedDeclaration();

                    break;
                }
            case e_ConditionalExcutable_editor:
                {
                    ConditionalExcutable_editor_ptr cond_ptr = std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(editor_it->second);

                    if (cond_ptr == NULL)
                        return false;

                    port_nums = is_iport ? static_cast<int>(cond_ptr->get_Inputports().size()) : static_cast<int>(cond_ptr->get_Outputports().size());
                    return true;
                }
            case e_IterativeExcutable_editor:
                {
                    IterativeExcutable_editor_ptr iter_ptr = std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(editor_it->second);

                    if (iter_ptr == NULL)
                        return false;

                    port_nums = is_iport ? static_cast<int>(iter_ptr->get_Inputports().size()) : static_cast<int>(iter_ptr->get_Outputports().size());
                    return true;
                }
            case e_StorageFunctionExecutable_editor:
                {
                    StorageFunctionExecutable_editor_ptr sto_ptr = std::tr1::dynamic_pointer_cast<StorageFunctionExecutable_editor>(editor_it->second);

                    if (sto_ptr == NULL)
                        return false;

                    index_decl = sto_ptr->get_selectedDeclaration();

                    break;
                }
            default:
                return false;
        }

        index_editor_map_itr decl_edit_it = m_idx_editor_map.find(index_decl);
        index_id_map_itr     decl_id_it   = m_idx_id_map.find(index_decl);

        if (decl_edit_it != m_idx_editor_map.end())
        {
            switch (decl_edit_it->second->get_editor_type())
            {
                case e_Declaration_editor:
                    {
                        Declaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<Declaration_editor>(decl_edit_it->second);

                        if (decl_ptr == NULL)
                            return false;

                        port_nums = is_iport ? static_cast<int>(decl_ptr->get_inputPorts().size()) : static_cast<int>(decl_ptr->get_outputPort().size());
                        return true;
                    }
                case e_ExpandedDeclaration_editor:
                    {
                        ExpandedDeclaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(decl_edit_it->second);

                        if (decl_ptr == NULL)
                            return false;

                        int index_parent_decl = decl_ptr->get_parentDeclaration();

                        // now we assume that parent_decl is builtin_decl
                        index_id_map_itr origin_decl_id_it = m_idx_id_map.find(index_parent_decl);

                        if (origin_decl_id_it != m_idx_id_map.end())
                        {
                            std::pair<int, int> portNums;
                            obj_impl_declaration::get_portNums_by_decl(origin_decl_id_it->second, portNums);

                            port_nums = is_iport ? portNums.first : portNums.second;
                            return true;
                        }
                        else
                            return false;
                    }
                default:
                    return false;
            }
        }
        else if (decl_id_it != m_idx_id_map.end())
        {
            if (decl_id_it->second.is_object_decl_compound())
            {
                content decl_data;
                read_from_db(decl_id_it->second, decl_data);

                decl_compound_data_t decl_logic_data;
                unpack_to_decl_compound_data(decl_data, decl_logic_data);

                port_nums = is_iport ? static_cast<int>(decl_logic_data.iports.size()) : static_cast<int>(decl_logic_data.oports.size());
                return true;
            }
            else if (decl_id_it->second.is_object_decl_expanded())
            {
                content decl_data;
                read_from_db(decl_id_it->second, decl_data);

                decl_expanded_data_t decl_logic_data;
                unpack_to_decl_expanded_data(decl_data, decl_logic_data);

                std::pair<int, int> portNums;
                obj_impl_declaration::get_portNums_by_decl(decl_logic_data.origin_decl_id, portNums);

                port_nums = is_iport ? portNums.first : portNums.second;
                return true;
            }
            else if (decl_id_it->second.is_object_declaration())
            {
                std::pair<int, int> portNums;
                obj_impl_declaration::get_portNums_by_decl(decl_id_it->second, portNums);

                port_nums = is_iport ? portNums.first : portNums.second;
                return true;
            }

            return false;
        }

        return false;
    }
    else if (id_it != m_idx_id_map.end())
    {
        switch (id_it->second.get_type())
        {
            case NBID_TYPE_OBJECT_EXEC_CONDITION:
                {
                    content data;
                    read_from_db(id_it->second, data);

                    exec_cond_data_t logic_data;
                    unpack_to_exec_cond_data(data, logic_data);

                    // now assume that expanded_decl is only in array and map
                    if (logic_data.external_decl.is_object_declaration())
                    {
                        std::pair<int, int> portNums;
                        obj_impl_declaration::get_portNums_by_decl(logic_data.external_decl, portNums);

                        port_nums = is_iport ? portNums.first : portNums.second;
                        return true;
                    }
                    else if (logic_data.external_decl.is_object_decl_compound())
                    {
                        content decl_data;
                        read_from_db(logic_data.external_decl, decl_data);

                        decl_compound_data_t decl_logic_data;
                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                        port_nums = is_iport ? static_cast<int>(decl_logic_data.iports.size()) : static_cast<int>(decl_logic_data.oports.size());
                        return true;
                    }

                    return false;
                }
            case NBID_TYPE_OBJECT_EXEC_ITERATOR:
                {
                    content data;
                    read_from_db(id_it->second, data);

                    exec_iterator_data_t logic_data;
                    unpack_to_exec_iterator_data(data, logic_data);

                    // now assume that expanded_decl is only in array and map
                    if (logic_data.external_decl.is_object_declaration())
                    {
                        std::pair<int, int> portNums;
                        obj_impl_declaration::get_portNums_by_decl(logic_data.external_decl, portNums);

                        port_nums = is_iport ? portNums.first : portNums.second;
                        return true;
                    }
                    else if (logic_data.external_decl.is_object_decl_compound())
                    {
                        content decl_data;
                        read_from_db(logic_data.external_decl, decl_data);

                        decl_compound_data_t decl_logic_data;
                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                        port_nums = is_iport ? static_cast<int>(decl_logic_data.iports.size()) : static_cast<int>(decl_logic_data.oports.size());
                        return true;
                    }

                    return false;
                }
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
                {
                    content data;
                    read_from_db(id_it->second, data);

                    exec_obj_func_data_t logic_data;
                    unpack_to_exec_obj_func_data(data, logic_data);

                    if (logic_data.selected_decl.is_object_declaration())
                    {
                        std::pair<int, int> portNums;
                        obj_impl_declaration::get_portNums_by_decl(logic_data.selected_decl, portNums);

                        port_nums = is_iport ? portNums.first : portNums.second;
                        return true;
                    }
                    else if (logic_data.selected_decl.is_object_decl_compound())
                    {
                        content decl_data;
                        read_from_db(logic_data.selected_decl, decl_data);

                        decl_compound_data_t decl_logic_data;
                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                        port_nums = is_iport ? static_cast<int>(decl_logic_data.iports.size()) : static_cast<int>(decl_logic_data.oports.size());
                        return true;
                    }
                    else if (logic_data.selected_decl.is_object_decl_expanded())
                    {
                        content decl_data;
                        read_from_db(logic_data.selected_decl, decl_data);

                        decl_expanded_data_t decl_logic_data;
                        unpack_to_decl_expanded_data(decl_data, decl_logic_data);

                        // assume that origin_decl is builtin_decl
                        std::pair<int, int> portNums;
                        obj_impl_declaration::get_portNums_by_decl(decl_logic_data.origin_decl_id, portNums);

                        port_nums = is_iport ? portNums.first : portNums.second;
                        return true;
                    }

                    return false;
                }
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
                {
                    content data;
                    read_from_db(id_it->second, data);

                    exec_storage_func_data_t logic_data;
                    unpack_to_exec_storage_data(data, logic_data);

                    if (logic_data.selected_decl.is_object_decl_expanded())
                    {
                        content decl_data;
                        read_from_db(logic_data.selected_decl, decl_data);

                        decl_expanded_data_t decl_logic_data;
                        unpack_to_decl_expanded_data(decl_data, decl_logic_data);

                        // assume that origin_decl is builtin_decl
                        std::pair<int, int> portNums;
                        obj_impl_declaration::get_portNums_by_decl(decl_logic_data.origin_decl_id, portNums);

                        port_nums = is_iport ? portNums.first : portNums.second;
                        return true;
                    }

                    return false;
                }
            default:
                return false;
        }
    }

    return false;
}

bool checking_datas::get_interface_by_nb_id(const nb_id_t& obj_id, nb_id_t& if_id)
{
    if (obj_id.get_type() == NBID_TYPE_OBJECT_ARRAY)
    {
        content data;
        read_from_db(obj_id, data);

        array_data_t logic_data;
        unpack_to_array_data(data, logic_data);

        if_id = logic_data.type;
        return true;
    }
    else if (obj_id.get_type() == NBID_TYPE_OBJECT_MAP)
    {
        content data;
        read_from_db(obj_id, data);

        map_data_t logic_data;
        unpack_to_map_data(data, logic_data);

        if_id = logic_data.type;
        return true;
    }
    else if (obj_id.get_type() == NBID_TYPE_OBJECT_BRIDGE)
    {
        content data;
        read_from_db(obj_id, data);

        bridge_data_t logic_data;
        unpack_to_bridge_data(data, logic_data);

        if_id = logic_data.interface;
        return true;
    }
    else if (obj_id.get_type() == NBID_TYPE_OBJECT_USER)
    {
        content data;
        read_from_db(obj_id, data);

        user_data_t logic_data;
        unpack_to_user_data(data, logic_data);

        if_id = logic_data.interface;
        return true;
    }
    else if (obj_id.get_type() == NBID_TYPE_OBJECT_ACCESS)
    {
        content data;
        read_from_db(obj_id, data);

        access_data_t logic_data;
        unpack_to_access_data(data, logic_data);

        if_id = logic_data.interface;
        return true;
    }
    else
        return obj_id.get_builtin_interface(if_id);
}

// ======================================= interface cover interface ================================================

bool checking_datas::decls_id_match_decls_id(nb_id_vector& start_decls, nb_id_vector& stop_decls)
{
    while (stop_decls.size())
    {
        if (stop_decls[0].is_function_compose() || stop_decls[0].is_function_decompose())
        {
            stop_decls.erase(stop_decls.begin());
            continue;
        }

        else if (stop_decls[0].is_function_instruction() || stop_decls[0].is_object_decl_compound())
        {
            size_t start_decls_size = start_decls.size();

            for (size_t i = 0; i < start_decls.size(); ++i)
            {
                if (stop_decls[0] == start_decls[i])
                {
                    start_decls.erase(start_decls.begin() + i);
                    stop_decls.erase(stop_decls.begin());
                    break;
                }
            }

            if (start_decls_size != start_decls.size() + 1)
                return false;
            continue;
        }

        else
        {
            content stop_decl_ex_data;
            read_from_db(stop_decls[0], stop_decl_ex_data);

            decl_expanded_data_t stop_decl_ex_logic_data;
            unpack_to_decl_expanded_data(stop_decl_ex_data, stop_decl_ex_logic_data);

            nb_id_t       stop_origin_decl = stop_decl_ex_logic_data.origin_decl_id;
            nb_id_vector  stop_exp_ifs     = stop_decl_ex_logic_data.expanded_ifs;

            size_t start_decls_size = start_decls.size();

            for (size_t i = 0; i < start_decls.size(); ++i)
            {
                if (start_decls[i].is_object_decl_expanded())
                {
                    content start_decl_ex_data;
                    read_from_db(start_decls[i], start_decl_ex_data);

                    decl_expanded_data_t start_decl_ex_logic_data;
                    unpack_to_decl_expanded_data(start_decl_ex_data, start_decl_ex_logic_data);

                    nb_id_t       start_origin_decl = start_decl_ex_logic_data.origin_decl_id;
                    nb_id_vector  start_exp_ifs     = start_decl_ex_logic_data.expanded_ifs;

                    if (start_origin_decl == stop_origin_decl)
                    {
                        if (start_exp_ifs.size() != stop_exp_ifs.size())
                            return false;

                        for (size_t j = 0; j < start_exp_ifs.size(); ++j)
                        {
                            if (!interface_id_cover_interface_id(start_exp_ifs[j], stop_exp_ifs[j]) ||
                                !interface_id_cover_interface_id(stop_exp_ifs[j], start_exp_ifs[j]))
                                return false;
                        }

                        start_decls.erase(start_decls.begin() + i);
                        stop_decls.erase(stop_decls.begin());
                        break;
                    }
                }
            }

            if (start_decls_size != start_decls.size() + 1)
                return false;
            continue;
        }
    }

    return true;
}

bool checking_datas::interface_id_cover_interface_id(const nb_id_t& start_id, const nb_id_t& stop_id)
{
    LOG_DEBUG("*** BEGIN interface id cover interface id ***");

    if (!start_id.is_interface() || !stop_id.is_interface())
        return false;

    if (start_id.is_interface_none() || stop_id.is_interface_none())
        return true;
    else if (start_id == stop_id)
        return true;
    else if (start_id.is_compound_interface() && stop_id.is_compound_interface())
    {
        content start_data, stop_data;
        read_from_db(start_id, start_data);
        read_from_db(stop_id, stop_data);

        if_compound_data_t start_logic_data, stop_logic_data;
        unpack_to_ifc_data(start_data, start_logic_data);
        unpack_to_ifc_data(stop_data, stop_logic_data);

        return decls_id_match_decls_id(start_logic_data.decls, stop_logic_data.decls);
    }
    else if (start_id.is_interface_bridge() && stop_id.is_interface_bridge())
    {
        content start_data, stop_data;
        read_from_db(start_id, start_data);
        read_from_db(stop_id, stop_data);

        bridge_interface_data_t start_logic_data, stop_logic_data;
        unpack_to_bridge_if_data(start_data, start_logic_data);
        unpack_to_bridge_if_data(stop_data, stop_logic_data);

        if (start_logic_data.external_name == "TAbstractVisible" ||
            stop_logic_data.external_name  == "TAbstractVisible" ||
            start_logic_data.external_name == "TNone"            ||
            stop_logic_data.external_name  == "TNone")
            return true;

        if (start_logic_data.external_name != start_logic_data.external_name ||
            start_logic_data.sub_names.size() != stop_logic_data.sub_names.size())
            return false;

        for (size_t i = 0; i < start_logic_data.sub_names.size(); ++i)
        {
            if (start_logic_data.sub_names[i] != stop_logic_data.sub_names[i])
                return false;
        }

        return true;
    }

    return false;
}

bool checking_datas::interface_id_cover_interface_ptr(const nb_id_t& start_id, const UserInterface_editor_ptr& stop_ptr)
{
    LOG_DEBUG("*** BEGIN interface id cover interface ptr ***");
    return true;
}

bool checking_datas::interface_ptr_cover_interface_id(const UserInterface_editor_ptr& start_ptr, const nb_id_t& stop_id)
{
    LOG_DEBUG("*** BEGIN interface ptr cover interface id ***");
    return true;
}

bool checking_datas::interface_ptr_cover_interface_ptr(const UserInterface_editor_ptr& start_ptr, const UserInterface_editor_ptr& stop_ptr)
{
    LOG_DEBUG("*** BEGIN interface ptr cover interface ptr ***");
    return true;
}

// ======================================= running checking and cover ===============================================

bool checking_datas::running_checking(index_string_map& error_info)
{
    for (index_editor_map_itr it = m_idx_editor_map.begin(); it != m_idx_editor_map.end(); ++it)
    {
        if (it->second->get_editor_type() == e_Implementation_editor)
        {
            if (!checking_graph_paths(it->first, error_info) ||
                !checking_graph_nodes(it->first, error_info)) 
            return false;
        }
    }

    // check generated_id is in db
    bool ret = true;
    for (index_id_map_itr it = m_idx_id_map.begin(); it != m_idx_id_map.end(); ++it)
    {
        if (!ac_object_db_impl::instance().exist(it->second.str()))
        {
            if (it->second.is_justid_type())// && !it->second.is_type_null())
                continue;
            std::string err_str("check id exist not in db:");
            err_str.append(it->second.str());
            error_info.insert(std::make_pair(it->first, err_str));
            ret = false;
        }
    }

    return ret;
}

bool checking_datas::checking_graph_paths(const int& idx_of_graph, index_string_map& error_info)
{
    index_editor_map_itr it = m_idx_editor_map.find(idx_of_graph);

    if (it != m_idx_editor_map.end())
    {
        Implementation_editor_ptr impl_ptr = std::tr1::dynamic_pointer_cast<Implementation_editor>(it->second);
        if (impl_ptr == NULL)
        {
            error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an editing graph")));
            return false;
        }

        std::vector<Path> Path_vec = impl_ptr->get_paths();
        std::vector<int>  Node_vec = impl_ptr->get_nodes();
        std::vector< std::pair<int,int> > stopNode_stopPort_pair;

        LOG_DEBUG("================================");
        LOG_DEBUG("=    Graph Name     : " << impl_ptr->get_name());
        LOG_DEBUG("=    Graph Index    : " << idx_of_graph);
        LOG_DEBUG("=    Path Numbers   : " << Path_vec.size());
        LOG_DEBUG("=    Node Numbers   : " << Node_vec.size());
        LOG_DEBUG("=    Input Numbers  : " << impl_ptr->get_Inputports().size());
        LOG_DEBUG("=    Output Numbers : " << impl_ptr->get_Outputports().size());
        LOG_DEBUG("================================");

        for (Path_vec_it path_it = Path_vec.begin(); path_it != Path_vec.end(); ++path_it)
        {
//            LOG_DEBUG("");
//            LOG_DEBUG("== Start checking Path ==");
//            LOG_DEBUG("== StartNode Number : " << path_it->startNode);
//            LOG_DEBUG("== StartPort Number : " << path_it->startPort);
//            LOG_DEBUG("== StopNode  Number : " << path_it->stopNode);
//            LOG_DEBUG("== StopPort  Number : " << path_it->stopPort);

            // checking stopNode
            if (0 <= path_it->stopNode && path_it->stopNode < static_cast<int>(Node_vec.size()))
            {
                // checking if the repeated stopPort of repeated stopNode
                std::vector< std::pair<int, int> >::iterator pair_it;
                std::pair<int, int> stopNode_stopPort = std::make_pair(path_it->stopNode, path_it->stopPort);
                pair_it = std::find(stopNode_stopPort_pair.begin(), stopNode_stopPort_pair.end(), stopNode_stopPort);
                if (pair_it != stopNode_stopPort_pair.end())
                {
                    error_info.insert(std::make_pair(Node_vec[path_it->stopNode], std::string("several lines connected to the same in_port of same node")));
                    return false;
                }

                if (path_it->stopPort != -4)
                {
                    int iport_nums;
                    if (!get_portNums_by_nodeIdx(Node_vec[path_it->stopNode], iport_nums, true))
                    {
                        error_info.insert(std::make_pair(Node_vec[path_it->stopNode], std::string("node index is error")));
                        return false;
                    }

                    if (iport_nums <= path_it->stopPort)
                    {
                        error_info.insert(std::make_pair(Node_vec[path_it->stopNode], std::string("stopPort is outside portNums")));
                        return false;
                    }
                }

                // just record the <stopNode, stopNode> for checking repeated stopPort of repeated stopNode
                stopNode_stopPort_pair.push_back(stopNode_stopPort);
            }
            else if (path_it->stopNode == -3)
            {
                // checking if the repeated stopPort of repeated stopNode
                std::vector< std::pair<int, int> >::iterator pair_it;
                std::pair<int, int> stopNode_stopPort = std::make_pair(path_it->stopNode, path_it->stopPort);
                pair_it = std::find(stopNode_stopPort_pair.begin(), stopNode_stopPort_pair.end(), stopNode_stopPort);
                if (pair_it != stopNode_stopPort_pair.end())
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("several lines connected to the same in_port of same node")));
                    return false;
                }

                if (static_cast<int>(impl_ptr->get_Outputports().size()) <= path_it->stopPort)
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("stopPort is outside outportNums of graph")));
                    return false;
                }

                // just record the <stopNode, stopNode> for checking repeated stopPort of repeated stopNode
                stopNode_stopPort_pair.push_back(stopNode_stopPort);
            }
            else
            {
                error_info.insert(std::make_pair(idx_of_graph, std::string("stopNode is not a true node")));
                return false;
            }

//            LOG_DEBUG("== Check StopNode OK   ==");

            // checking startNode
            if (0 <= path_it->startNode && path_it->startNode < static_cast<int>(Node_vec.size()))
            {
                if (path_it->startPort != -4)
                {
                    int oport_nums;
                    if (!get_portNums_by_nodeIdx(Node_vec[path_it->startNode], oport_nums, false))
                    {
                        error_info.insert(std::make_pair(Node_vec[path_it->startNode], std::string("node index is error")));
                        return false;
                    }

                    if (oport_nums <= path_it->startPort)
                    {
                        error_info.insert(std::make_pair(Node_vec[path_it->startNode], std::string("startPort is outside portNums")));
                        return false;
                    }
                }

            }
            else if (path_it->startNode == -2)
            {
                if (static_cast<int>(impl_ptr->get_constants().size()) <= path_it->startPort)
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("startPort of constant node is wrong")));
                    return false;
                }
            }
            else if (path_it->startNode == -1)
            {
                if (static_cast<int>(impl_ptr->get_Inputports().size()) <= path_it->startPort)
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("startPort is outside inputNums of graph")));
                    return false;
                }
            }
            else
            {
                error_info.insert(std::make_pair(idx_of_graph, std::string("startNode is not a true node")));
                return false;
            }

            LOG_DEBUG("== Check StartNode OK  ==");
            LOG_DEBUG("== End checking Path OK==");
        }
    }
    else
    {
        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an editing graph")));
        return false;
    }
    return true;
}

bool checking_datas::checking_graph_nodes(const int& idx_of_graph, index_string_map& error_info)
{
    index_editor_map_itr it = m_idx_editor_map.find(idx_of_graph);

    if (it != m_idx_editor_map.end())
    {
        Implementation_editor_ptr impl_ptr = std::tr1::dynamic_pointer_cast<Implementation_editor>(it->second);
        if (impl_ptr == NULL)
        {
            error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a editing graph")));
            return false;
        }

        std::vector<Path> Path_vec = impl_ptr->get_paths();
        std::vector<int>  Node_vec = impl_ptr->get_nodes();

        LOG_DEBUG("================================");
        LOG_DEBUG("=    Graph Name     : " << impl_ptr->get_name());
        LOG_DEBUG("=    Graph Index    : " << idx_of_graph);
        LOG_DEBUG("=    Node  Numbers  : " << Node_vec.size());
        LOG_DEBUG("================================");

        // checking normal nodes'input ports
        for (int node_dx = 0; node_dx < static_cast<int>(Node_vec.size()); ++node_dx)
        {
//            LOG_DEBUG("");
//            LOG_DEBUG("== Start checking Normal Node ==");
//            LOG_DEBUG("== Node Index    : " << Node_vec[node_dx]);

            int iportNums;
            if (!get_portNums_by_nodeIdx(Node_vec[node_dx], iportNums, true))
            {
                error_info.insert(std::make_pair(Node_vec[node_dx], std::string("node index is error")));
                return false;
            }

//            LOG_DEBUG("== iPort Numbers : " << iportNums);

            std::vector<int> judge_iports;

            for (Path_vec_it path_it = Path_vec.begin(); path_it != Path_vec.end(); ++path_it)
            {
                if (path_it->stopNode == node_dx && path_it->stopPort != -4)
                {
                    std::vector<int>::iterator port_it = std::find(judge_iports.begin(), judge_iports.end(), path_it->stopPort);

                    if (port_it == judge_iports.end())
                        judge_iports.push_back(path_it->stopPort);
                }
            }

//            LOG_DEBUG("== iPort Numbers having connected : " << judge_iports.size());

            if (static_cast<int>(judge_iports.size()) != iportNums)
            {
                error_info.insert(std::make_pair(Node_vec[node_dx], std::string("There are iports of node without line connected")));
                return false;
            }

//            LOG_DEBUG("== iPorts of Node Index " << Node_vec[node_dx] << " having all connected");
        }

        // checking outputPort of graph

        LOG_DEBUG("");
        LOG_DEBUG("== Start checking Output Node ==");

        size_t outputNum = impl_ptr->get_Outputports().size();

        LOG_DEBUG("== iPort Numbers of Output Node : " << outputNum);

        std::vector<int> judge_iports;

        for (Path_vec_it path_it = Path_vec.begin(); path_it != Path_vec.end(); ++path_it)
        {
            if (path_it->stopNode == -3)
            {
                std::vector<int>::iterator port_it = std::find(judge_iports.begin(), judge_iports.end(), path_it->stopPort);

                if (port_it == judge_iports.end())
                    judge_iports.push_back(path_it->stopPort);
            }
        }

        LOG_DEBUG("== iPort Numbers of Output Node having connected : " << judge_iports.size());

        if (judge_iports.size() != outputNum)
        {
            error_info.insert(std::make_pair(idx_of_graph, std::string("There are outputPorts of graph without line connected")));
            return false;
        }

        LOG_DEBUG("== iPorts of Output Node having all connected");
    }
    else
    {
        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a editing graph")));
        return false;
    }
    return true;
}

bool checking_datas::checking_if_cover(const int& idx_of_graph, index_string_map& error_info)
{
    index_editor_map_itr it = m_idx_editor_map.find(idx_of_graph);

    if (it != m_idx_editor_map.end())
    {
        Implementation_editor_ptr impl_ptr = std::tr1::dynamic_pointer_cast<Implementation_editor>(it->second);
        if (impl_ptr == NULL)
        {
            error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a editing graph")));
            return false;
        }

        std::vector<Path> Path_vec = impl_ptr->get_paths();
        std::vector<int>  Node_vec = impl_ptr->get_nodes();

        for (Path_vec_it path_it = Path_vec.begin(); path_it != Path_vec.end(); ++path_it)
        {
            if (path_it->stopPort != -4 && path_it->startPort != -4)
            {
                nb_id_t                   start_if_id,       stop_if_id;
                UserInterface_editor_ptr  start_if_edit_ptr, stop_if_edit_ptr;
                bool                      is_start_id,       is_stop_id;

                // 1. get startNode'startPort'interface
                if (0 <= path_it->startNode && path_it->startNode < static_cast<int>(Node_vec.size()))
                {
                    index_editor_map_itr editor_it = m_idx_editor_map.find(Node_vec[path_it->startNode]);
                    index_id_map_itr     id_it     = m_idx_id_map.find(Node_vec[path_it->startNode]);

                    if (editor_it != m_idx_editor_map.end())
                    {
                        int index_decl;

                        switch (editor_it->second->get_editor_type())
                        {
                            case e_ObjectFunctionExecutable_editor:
                                {
                                    ObjectFunctionExecutable_editor_ptr obj_ptr = 
                                        std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(editor_it->second);

                                    if (obj_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an object_function_node")));
                                        return false;
                                    }

                                    index_decl = obj_ptr->get_selectedDeclaration();

                                    break;
                                }
                            case e_ConditionalExcutable_editor:
                                {
                                    ConditionalExcutable_editor_ptr cond_ptr = 
                                        std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(editor_it->second);

                                    if (cond_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a condition_function_node")));
                                        return false;
                                    }

                                    //TODO
                                    //index_decl = cond_ptr->get_externalDeclaration();

                                    break;
                                }
                            case e_IterativeExcutable_editor:
                                {
                                    IterativeExcutable_editor_ptr iter_ptr = 
                                        std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(editor_it->second);

                                    if (iter_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an iterative_function_node")));
                                        return false;
                                    }

                                    //TODO
                                    //index_decl = iter_ptr->get_externalDeclaration();

                                    break;
                                }
                            default:
                                {
                                    error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a true editing node")));
                                    return false;
                                }
                        }

                        index_editor_map_itr decl_edit_it = m_idx_editor_map.find(index_decl);
                        index_id_map_itr     decl_id_it   = m_idx_id_map.find(index_decl);

                        if (decl_edit_it != m_idx_editor_map.end())
                        {
                            switch (decl_edit_it->second->get_editor_type())
                            {
                                case e_Declaration_editor:
                                    {
                                        Declaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<Declaration_editor>(decl_edit_it->second);

                                        if (decl_ptr == NULL)
                                        {
                                            error_info.insert(std::make_pair(index_decl, std::string("This is not a declaration_compound")));
                                            return false;
                                        }

                                        int index_interface = decl_ptr->get_outputPort()[path_it->startPort].interface;

                                        index_editor_map_itr if_edit_it = m_idx_editor_map.find(index_interface);
                                        index_id_map_itr     if_id_it   = m_idx_id_map.find(index_interface);

                                        if (if_edit_it != m_idx_editor_map.end())
                                        {
                                            UserInterface_editor_ptr if_ptr = std::tr1::dynamic_pointer_cast<UserInterface_editor>(if_edit_it->second);

                                            if (if_ptr == NULL)
                                            {
                                                error_info.insert(std::make_pair(index_interface, std::string("This is not an editing interface")));
                                                return false;
                                            }

                                            start_if_edit_ptr = if_ptr;
                                            is_start_id = false;

                                            break;
                                        }
                                        else if (if_id_it != m_idx_id_map.end())
                                        {
                                            start_if_id = if_id_it->second;
                                            is_start_id = true;

                                            break;
                                        }
                                        else
                                        {
                                            error_info.insert(std::make_pair(idx_of_graph, std::string("This index is not an interface")));
                                            return false;
                                        }
                                    }
                                case e_ExpandedDeclaration_editor:
                                    {
                                        ExpandedDeclaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(decl_edit_it->second);

                                        if (decl_ptr == NULL)
                                        {
                                            error_info.insert(std::make_pair(index_decl, std::string("This is not an expanded_declaration")));
                                            return false;
                                        }

                                        //TODO
                                        continue;
                                    }
                                default:
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a declaration")));
                                        return false;
                                    }
                            }
                        }
                        else if (decl_id_it != m_idx_id_map.end())
                        {
                            switch (decl_id_it->second.get_type())
                            {
                                case NBID_TYPE_OBJECT_DECLARATION:
                                    {
                                       nb_id_vector vin, vout;
                                       obj_impl_declaration::get_interfaces(decl_id_it->second, vin, vout);

                                       start_if_id = vout[path_it->startPort];
                                       is_start_id = true;

                                       break;
                                    }
                                case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
                                    {
                                        content decl_data;
                                        read_from_db(decl_id_it->second, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        start_if_id = decl_logic_data.oports[path_it->startPort].interface;
                                        is_start_id = true;

                                        break;
                                    }
                                case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
                                    {
                                        //TODO
                                        continue;
                                    }
                                default:
                                    {
                                        error_info.insert(std::make_pair(index_decl, std::string("This is not a declaration id")));
                                        return false;
                                    }
                            }
                        }
                        else
                        {
                            error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a declaration")));
                            return false;
                        }
                    }
                    else if (id_it != m_idx_id_map.end())
                    {
                        switch (id_it->second.get_type())
                        {
                            case NBID_TYPE_OBJECT_EXEC_CONDITION:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_cond_data_t logic_data;
                                    unpack_to_exec_cond_data(data, logic_data);

                                    // now assume that expanded_decl is only in array and map
                                    if (logic_data.external_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.external_decl, vin, vout);

                                        start_if_id = vout[path_it->startPort];
                                        is_start_id = true;
                                        
                                        break;
                                    }
                                    else if (logic_data.external_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.external_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        start_if_id = decl_logic_data.oports[path_it->startPort].interface;
                                        is_start_id = true;

                                        break;
                                    }
                                    else
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This condition's decl is error")));
                                        return false;
                                    }
                                }
                            case NBID_TYPE_OBJECT_EXEC_ITERATOR:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_iterator_data_t logic_data;
                                    unpack_to_exec_iterator_data(data, logic_data);

                                    // now assume that expanded_decl is only in array and map
                                    if (logic_data.external_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.external_decl, vin, vout);

                                        start_if_id = vout[path_it->startPort];
                                        is_start_id = true;
                                        
                                        break;
                                    }
                                    else if (logic_data.external_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.external_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        start_if_id = decl_logic_data.oports[path_it->startPort].interface;
                                        is_start_id = true;

                                        break;
                                    }
                                    else
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This condition's decl is error")));
                                        return false;
                                    }

                                }
                            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_obj_func_data_t logic_data;
                                    unpack_to_exec_obj_func_data(data, logic_data);

                                    if (logic_data.selected_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.selected_decl, vin, vout);

                                        start_if_id = vout[path_it->startPort];
                                        is_start_id = true;

                                        break;
                                    }
                                    else if (logic_data.selected_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.selected_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        start_if_id = decl_logic_data.oports[path_it->startPort].interface;
                                        is_start_id = true;

                                        break;
                                    }
                                    else if (logic_data.selected_decl.is_object_decl_expanded())
                                    {
                                        //TODO
                                        continue;
                                    }

                                }
                            default:
                                {
                                    error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a node id")));
                                    return false;
                                }
                        }
                    }
                    else
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an editing graph")));
                        return false;
                    }
                }
                else if (path_it->startNode == -2)
                {
                    if (static_cast<int>(impl_ptr->get_constants().size()) <= path_it->startPort)
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is a wrong constant")));
                        return false;
                    }

                    int startConstant = impl_ptr->get_constants()[path_it->startPort];

                    index_editor_map_itr editor_it = m_idx_editor_map.find(startConstant);
                    index_id_map_itr     id_it     = m_idx_id_map.find(startConstant);

                    if (editor_it != m_idx_editor_map.end())
                    {
                        switch (editor_it->second->get_editor_type())
                        {
                            case e_UserObject_editor:
                                {
                                    UserObject_editor_ptr obj_ptr = std::tr1::dynamic_pointer_cast<UserObject_editor>(editor_it->second);
                                    if (obj_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an editing UserObject")));
                                        return false;
                                    }

                                    int userInterface = obj_ptr->get_interface();

                                    index_editor_map_itr if_edit_it = m_idx_editor_map.find(userInterface);

                                    if (if_edit_it != m_idx_editor_map.end())
                                    {
                                        UserInterface_editor_ptr if_ptr = std::tr1::dynamic_pointer_cast<UserInterface_editor>(if_edit_it->second);

                                        if (if_ptr == NULL)
                                        {
                                            error_info.insert(std::make_pair(userInterface, std::string("This is not an editing interface")));
                                            return false;
                                        }

                                        start_if_edit_ptr = if_ptr;
                                        is_start_id = false;

                                        break;
                                    }
                                    else
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("Can not find the editing userInterface")));
                                        return false;
                                    }
                                }
                            case e_MapValue_editor:
                                {
                                    //TODO
                                    continue;
                                }
                            case e_ArrayValue_editor:
                                {
                                    //TODO
                                    continue;
                                }
                            default:
                                {
                                    error_info.insert(std::make_pair(startConstant, std::string("This is a wrong editing constant")));
                                    return false;
                                }
                        }
                    }
                    else if (id_it != m_idx_id_map.end())
                    {
                        if (!get_interface_by_nb_id(id_it->second, start_if_id))
                        {
                            error_info.insert(std::make_pair(idx_of_graph, std::string("Can not get interface by nb_id")));
                            return false;
                        }

                        is_start_id = true;
                    }
                    else
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("Can not find the startConstant")));
                        return false;
                    }
                }
                else if (path_it->startNode == -1)
                {
                    int start_port = impl_ptr->get_Inputports()[path_it->startPort];

                    index_editor_map_itr editor_it = m_idx_editor_map.find(start_port);
                    index_id_map_itr     id_it     = m_idx_id_map.find(start_port);

                    if (editor_it != m_idx_editor_map.end())
                    {
                        UserInterface_editor_ptr if_ptr = std::tr1::dynamic_pointer_cast<UserInterface_editor>(editor_it->second);

                        if (if_ptr == NULL)
                        {
                            error_info.insert(std::make_pair(start_port, std::string("This is not an editing interface")));
                            return false;
                        }

                        start_if_edit_ptr = if_ptr;
                        is_start_id = false;
                    }
                    else if (id_it != m_idx_id_map.end())
                    {
                        start_if_id = id_it->second;
                        is_start_id = true;
                    }
                    else
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("This start_port is not of the inputs of the graph")));
                        return false;
                    }
                }
                else
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("The startNode is error")));
                    return false;
                }
                // 2. get stopNode'stopPort'interface
// =========== for test
                if (0 <= path_it->stopNode && path_it->stopNode < static_cast<int>(Node_vec.size()))
                {
                    index_editor_map_itr editor_it = m_idx_editor_map.find(Node_vec[path_it->stopNode]);
                    index_id_map_itr     id_it     = m_idx_id_map.find(Node_vec[path_it->stopNode]);

                    if (editor_it != m_idx_editor_map.end())
                    {
                        int index_decl;

                        switch (editor_it->second->get_editor_type())
                        {
                            case e_ObjectFunctionExecutable_editor:
                                {
                                    ObjectFunctionExecutable_editor_ptr obj_ptr = 
                                        std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(editor_it->second);

                                    if (obj_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an object_function_node")));
                                        return false;
                                    }

                                    index_decl = obj_ptr->get_selectedDeclaration();

                                    break;
                                }
                            case e_ConditionalExcutable_editor:
                                {
                                    ConditionalExcutable_editor_ptr cond_ptr = 
                                        std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(editor_it->second);

                                    if (cond_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a condition_function_node")));
                                        return false;
                                    }

                                    //TODO
                                    //index_decl = cond_ptr->get_externalDeclaration();

                                    break;
                                }
                            case e_IterativeExcutable_editor:
                                {
                                    IterativeExcutable_editor_ptr iter_ptr = 
                                        std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(editor_it->second);

                                    if (iter_ptr == NULL)
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an iterative_function_node")));
                                        return false;
                                    }

                                    //TODO
                                    //index_decl = iter_ptr->get_externalDeclaration();

                                    break;
                                }
                            default:
                                {
                                    error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a true editing node")));
                                    return false;
                                }
                        }

                        index_editor_map_itr decl_edit_it = m_idx_editor_map.find(index_decl);
                        index_id_map_itr     decl_id_it   = m_idx_id_map.find(index_decl);

                        if (decl_edit_it != m_idx_editor_map.end())
                        {
                            switch (decl_edit_it->second->get_editor_type())
                            {
                                case e_Declaration_editor:
                                    {
                                        Declaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<Declaration_editor>(decl_edit_it->second);

                                        if (decl_ptr == NULL)
                                        {
                                            error_info.insert(std::make_pair(index_decl, std::string("This is not a declaration_compound")));
                                            return false;
                                        }

                                        int index_interface = decl_ptr->get_inputPorts()[path_it->stopPort].interface;

                                        index_editor_map_itr if_edit_it = m_idx_editor_map.find(index_interface);
                                        index_id_map_itr     if_id_it   = m_idx_id_map.find(index_interface);

                                        if (if_edit_it != m_idx_editor_map.end())
                                        {
                                            UserInterface_editor_ptr if_ptr = std::tr1::dynamic_pointer_cast<UserInterface_editor>(if_edit_it->second);

                                            if (if_ptr == NULL)
                                            {
                                                error_info.insert(std::make_pair(index_interface, std::string("This is not an editing interface")));
                                                return false;
                                            }

                                            stop_if_edit_ptr = if_ptr;
                                            is_stop_id = false;

                                            break;
                                        }
                                        else if (if_id_it != m_idx_id_map.end())
                                        {
                                            stop_if_id = if_id_it->second;
                                            is_stop_id = true;

                                            break;
                                        }
                                        else
                                        {
                                            error_info.insert(std::make_pair(idx_of_graph, std::string("This index is not an interface")));
                                            return false;
                                        }
                                    }
                                case e_ExpandedDeclaration_editor:
                                    {
                                        ExpandedDeclaration_editor_ptr decl_ptr = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(decl_edit_it->second);

                                        if (decl_ptr == NULL)
                                        {
                                            error_info.insert(std::make_pair(index_decl, std::string("This is not an expanded_declaration")));
                                            return false;
                                        }

                                        //TODO
                                        continue;
                                    }
                                default:
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a declaration")));
                                        return false;
                                    }
                            }
                        }
                        else if (decl_id_it != m_idx_id_map.end())
                        {
                            switch (decl_id_it->second.get_type())
                            {
                                case NBID_TYPE_OBJECT_DECLARATION:
                                    {
                                       nb_id_vector vin, vout;
                                       obj_impl_declaration::get_interfaces(decl_id_it->second, vin, vout);

                                       stop_if_id = vin[path_it->stopPort];
                                       is_stop_id = true;

                                       break;
                                    }
                                case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
                                    {
                                        content decl_data;
                                        read_from_db(decl_id_it->second, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        stop_if_id = decl_logic_data.iports[path_it->stopPort].interface;
                                        is_stop_id = true;

                                        break;
                                    }
                                case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
                                    {
                                        //TODO
                                        continue;
                                    }
                                default:
                                    {
                                        error_info.insert(std::make_pair(index_decl, std::string("This is not a declaration id")));
                                        return false;
                                    }
                            }
                        }
                        else
                        {
                            error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a declaration")));
                            return false;
                        }
                    }
                    else if (id_it != m_idx_id_map.end())
                    {
                        switch (id_it->second.get_type())
                        {
                            case NBID_TYPE_OBJECT_EXEC_CONDITION:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_cond_data_t logic_data;
                                    unpack_to_exec_cond_data(data, logic_data);

                                    // now assume that expanded_decl is only in array and map
                                    if (logic_data.external_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.external_decl, vin, vout);

                                        stop_if_id = vin[path_it->stopPort];
                                        is_stop_id = true;
                                        
                                        break;
                                    }
                                    else if (logic_data.external_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.external_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        stop_if_id = decl_logic_data.iports[path_it->stopPort].interface;
                                        is_stop_id = true;

                                        break;
                                    }
                                    else
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This condition's decl is error")));
                                        return false;
                                    }
                                }
                            case NBID_TYPE_OBJECT_EXEC_ITERATOR:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_iterator_data_t logic_data;
                                    unpack_to_exec_iterator_data(data, logic_data);

                                    // now assume that expanded_decl is only in array and map
                                    if (logic_data.external_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.external_decl, vin, vout);

                                        stop_if_id = vin[path_it->stopPort];
                                        is_stop_id = true;
                                        
                                        break;
                                    }
                                    else if (logic_data.external_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.external_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        stop_if_id = decl_logic_data.iports[path_it->stopPort].interface;
                                        is_stop_id = true;

                                        break;
                                    }
                                    else
                                    {
                                        error_info.insert(std::make_pair(idx_of_graph, std::string("This condition's decl is error")));
                                        return false;
                                    }

                                }
                            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
                                {
                                    content data;
                                    read_from_db(id_it->second, data);

                                    exec_obj_func_data_t logic_data;
                                    unpack_to_exec_obj_func_data(data, logic_data);

                                    if (logic_data.selected_decl.is_object_declaration())
                                    {
                                        nb_id_vector vin, vout;
                                        obj_impl_declaration::get_interfaces(logic_data.selected_decl, vin, vout);

                                        stop_if_id = vin[path_it->stopPort];
                                        is_stop_id = true;

                                        break;
                                    }
                                    else if (logic_data.selected_decl.is_object_decl_compound())
                                    {
                                        content decl_data;
                                        read_from_db(logic_data.selected_decl, decl_data);

                                        decl_compound_data_t decl_logic_data;
                                        unpack_to_decl_compound_data(decl_data, decl_logic_data);

                                        stop_if_id = decl_logic_data.iports[path_it->stopPort].interface;
                                        is_stop_id = true;

                                        break;
                                    }
                                    else if (logic_data.selected_decl.is_object_decl_expanded())
                                    {
                                        //TODO
                                        continue;
                                    }

                                }
                            default:
                                {
                                    error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a node id")));
                                    return false;
                                }
                        }
                    }
                    else
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not an editing graph")));
                        return false;
                    }
                }
                else if (path_it->stopNode == -3)
                {
                    int stop_port = impl_ptr->get_Outputports()[path_it->stopPort];

                    index_editor_map_itr editor_it = m_idx_editor_map.find(stop_port);
                    index_id_map_itr     id_it     = m_idx_id_map.find(stop_port);

                    if (editor_it != m_idx_editor_map.end())
                    {
                        UserInterface_editor_ptr if_ptr = std::tr1::dynamic_pointer_cast<UserInterface_editor>(editor_it->second);

                        if (if_ptr == NULL)
                        {
                            error_info.insert(std::make_pair(stop_port, std::string("This is not an editing interface")));
                            return false;
                        }

                        stop_if_edit_ptr = if_ptr;
                        is_stop_id = false;
                    }
                    else if (id_it != m_idx_id_map.end())
                    {
                        stop_if_id = id_it->second;
                        is_stop_id = true;
                    }
                    else
                    {
                        error_info.insert(std::make_pair(idx_of_graph, std::string("This stop_port is not of the outputs of the graph")));
                        return false;
                    }
                }
                else
                {
                    error_info.insert(std::make_pair(idx_of_graph, std::string("The stopNode is error")));
                    return false;
                }
// =========== for test
                // 3. interface cover interface
                if (is_start_id == true && is_stop_id == true && interface_id_cover_interface_id(start_if_id, stop_if_id))
                    continue;
                else if (is_start_id == true && is_stop_id == false && interface_id_cover_interface_ptr(start_if_id, stop_if_edit_ptr))
                    continue;
                else if (is_start_id == false && is_stop_id == true && interface_ptr_cover_interface_id(start_if_edit_ptr, stop_if_id))
                    continue;
                else if (is_start_id == false && is_stop_id == false && interface_ptr_cover_interface_ptr(start_if_edit_ptr, stop_if_edit_ptr))
                    continue;

                error_info.insert(std::make_pair(idx_of_graph, std::string("interface cover is error")));
                return false;
            }
            else if (path_it->stopPort == -4 && path_it->startPort == -4)
                continue;
            else
            {
                error_info.insert(std::make_pair(idx_of_graph, std::string("time_line is connected between a time_port and a non_time_port")));
                return false;
            }
        }
    }
    else
    {
        error_info.insert(std::make_pair(idx_of_graph, std::string("This is not a editing graph")));
        return false;
    }
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
