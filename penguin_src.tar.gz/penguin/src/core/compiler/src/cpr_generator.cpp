#include "cpr_generator.h"

#include "boost/crc.hpp"

#include "ac_container/access_implementation.h"
#include "ac_execution/exec_implement.h"
#include "ac_object/obj_impl_bytes.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_container_def.h"
#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_impl.h"
#include "ac_object/obj_impl_descriptor.h"



compiler_generator::compiler_generator(
        host_committer_id_t& hc_id,
        const index_editor_map& idx_editor_map,
        const index_id_map& idx_id_map,
        index_id_map& new_obj_data)
{
    m_editor_map = idx_editor_map;
    m_id_map = idx_id_map;
    m_new_id_map = new_obj_data;
    m_hc_id = hc_id;
}

compiler_generator::~compiler_generator()
{
}

bool compiler_generator::generate_object(index_string_map& error_info)
{
    for (index_editor_map_itr it = m_editor_map.begin(); it != m_editor_map.end(); ++it)
    {
        bool ret = false;
        content cData;
        nb_id_t idx;
        int index = it->first;
        switch (it->second->get_editor_type())
        {
            case e_BytesValue_editor:
            {
                BytesValue_editor_ptr p1 = std::tr1::dynamic_pointer_cast<BytesValue_editor>(it->second); 
                ret = generate_bytes_object(index, p1, idx, cData);
                break;
            }
            case e_StringValue_editor:
            {
                StringValue_editor_ptr p1 = std::tr1::dynamic_pointer_cast<StringValue_editor>(it->second); 
                ret = generate_string_object(index, p1, idx, cData);
                break;
            }
            case e_ArrayValue_editor:
            {
                ArrayValue_editor_ptr p1 = std::tr1::dynamic_pointer_cast<ArrayValue_editor>(it->second); 
                ret = generate_array_object(index, p1, idx, cData);
                break;
            }
            case e_MapValue_editor:
            {
                MapValue_editor_ptr p1 = std::tr1::dynamic_pointer_cast<MapValue_editor>(it->second); 
                ret = generate_map_object(index, p1, idx, cData);
                break;
            }
            case e_UserObject_editor:
            {
                UserObject_editor_ptr p1 = std::tr1::dynamic_pointer_cast<UserObject_editor>(it->second); 
                ret = generate_user_object(index, p1, idx, cData);
                break;
            }
            case e_UserContainerDefinition_editor:
            {
                UserContainerDefinition_editor_ptr p1 = std::tr1::dynamic_pointer_cast<UserContainerDefinition_editor>(it->second); 
                ret = generate_container_def_object(index, p1, idx, cData);
                break;
            }
            case e_Implementation_editor:
            {
                Implementation_editor_ptr p1 = std::tr1::dynamic_pointer_cast<Implementation_editor>(it->second); 
                ret = generate_implementation_object(index, p1, idx, cData);
                break;
            }
            case e_Declaration_editor:
            {
                Declaration_editor_ptr p1 = std::tr1::dynamic_pointer_cast<Declaration_editor>(it->second); 
                ret = generate_declaration_compound_object(index, p1, idx, cData);
                break;
            }
            case e_ExpandedDeclaration_editor:
            {
                ExpandedDeclaration_editor_ptr p1 = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(it->second); 
                ret = generate_declaration_expanded_object(index, p1, idx, cData);
                break;
            }
            case e_UserInterface_editor:
            {
                UserInterface_editor_ptr p1 = std::tr1::dynamic_pointer_cast<UserInterface_editor>(it->second); 
                ret = generate_interface_compound_object(index, p1, idx, cData);
                break;
            }
            case e_ExpandedInterface_editor:
            {
                ExpandedInterface_editor_ptr p1 = std::tr1::dynamic_pointer_cast<ExpandedInterface_editor>(it->second); 
                ret = generate_interface_expanded_object(index, p1, idx, cData);
                break;
            }
            case e_ObjectFunctionExecutable_editor:
            {
                ObjectFunctionExecutable_editor_ptr p1 = std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(it->second); 
                ret = generate_exec_obj_object(index, p1, idx, cData);
                break;
            }
            case e_ConditionalExcutable_editor:
            {
                ConditionalExcutable_editor_ptr p1 = std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(it->second); 
                ret = generate_exec_condition_object(index, p1, idx, cData);
                break;
            }
            case e_IterativeExcutable_editor:
            {
                IterativeExcutable_editor_ptr p1 = std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(it->second); 
                ret = generate_exec_iterator_object(index, p1, idx, cData);
                break;
            }
            case e_StorageFunctionExecutable_editor:
            {
                StorageFunctionExecutable_editor_ptr p1 = std::tr1::dynamic_pointer_cast<StorageFunctionExecutable_editor>(it->second);
                ret = generate_exec_storage_func_object(index, p1, idx, cData);
                break;
            }
            default:
            {
                std::ostringstream oss;
                oss << "    complier: generate failed, not found the type! index = " << it->first << " , id = " << idx.str();
                std::string err_str = oss.str();
                LOG_ERROR(err_str);
                error_info.insert(std::make_pair(it->first, err_str));
                return false;
            }
        }

        if (!ret)
        {
            std::ostringstream oss;
            oss << "    complier: generate failed, index = " << it->first << " , type = " << it->second->get_editor_type();
            std::string err_str = oss.str();
            LOG_ERROR(err_str);
            error_info.insert(std::make_pair(it->first, err_str));
            return false;
        }

        if (!write_to_db(idx, cData))
        {
            std::ostringstream oss;
            oss << "    complier: write DB failed, index = " << it->first << " , id = " << idx.str();
            std::string err_str = oss.str();
            LOG_ERROR(err_str);
            error_info.insert(std::make_pair(it->first, err_str));
            return false;
        }
    }

    return true;
}

//==================================================================================================

bool compiler_generator::generate_bytes_object(int index, BytesValue_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    bytes_data_t bytes_data;

    std::vector<char> value;
    value = in_value->get_value();
    for (std::vector<char>::const_iterator it = value.begin(); it != value.end(); ++it)
        bytes_data.value.push_back(*it);
    bytes_data.length = bytes_data.value.size();
    boost::crc_optimal<16, 0x1021, 0xFFFF, 0, false, false> crc_ccitt;
    crc_ccitt = std::for_each(bytes_data.value.begin(), bytes_data.value.end(), crc_ccitt);
    bytes_data.crc = crc_ccitt();

    index_id_map_itr it = m_new_id_map.find(index);
    if (it == m_new_id_map.end())
        return false;
    out = it->second;
    obj_impl_bytes::pack(bytes_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_string_object(int index, StringValue_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    std::string strval = in_value->get_value();

    index_id_map_itr it = m_new_id_map.find(index);
    if (it == m_new_id_map.end())
        return false;
    out = it->second;
    obj_impl_string::pack(strval, out, raw_data);

    return true;
}

bool compiler_generator::generate_array_object(int index, ArrayValue_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    array_data_t array_data;
    index_id_map_itr itd;

    if_compound_data_t array_ifc;
    if_exp_group exp_group;
    array_ifc.name = "array type";

    int type = in_value->get_expansionInterface();

    //set array type
    itd = m_new_id_map.find(type);
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(type);
        if (itd == m_id_map.end())
            return false;
    }
    exp_group.min_if = itd->second;
    array_ifc.groups.push_back(exp_group);

    nb_id_vector ifc_ids;
    ifc_ids.push_back(itd->second);
    if (!generate_interface_decls(array_ifc, NB_INTERFACE_ARRAY, ifc_ids, array_data.type))
        return false;

    //find array objs
    std::vector<int> objs = in_value->get_value();
    for (std::vector<int>::iterator it = objs.begin(); it != objs.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        array_data.objs.push_back(itd->second);
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;
    obj_impl_array::pack(array_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_map_object(int index, MapValue_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    map_data_t map_data;

    index_id_map_itr itd;
    if_exp_group key_type, val_type;
    if_compound_data_t map_ifc;
    map_ifc.name = "map type";

    // keyInterface
    itd = m_new_id_map.find(in_value->get_expansionKeyInterface());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_expansionKeyInterface());
        if (itd == m_id_map.end())
            return false;
    }
    nb_id_t key_min_if = itd->second;

    // valueInterface
    itd = m_new_id_map.find(in_value->get_expansionValueInterface());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_expansionValueInterface());
        if (itd == m_id_map.end())
            return false;
    }
    nb_id_t val_min_if = itd->second;

    //set map type
    key_type.min_if = key_min_if;
    val_type.min_if = val_min_if;
    map_ifc.groups.push_back(key_type);
    map_ifc.groups.push_back(val_type);

    nb_id_vector ifc_ids;
    ifc_ids.push_back(key_min_if);
    ifc_ids.push_back(val_min_if);

    if (!generate_interface_decls(map_ifc, NB_INTERFACE_MAP, ifc_ids, map_data.type))
        return false;

    //set value
    std::vector<MapElement> values = in_value->get_value();
    for (std::vector<MapElement>::iterator it = values.begin(); it != values.end(); ++it)
    {
        itd = m_new_id_map.find(it->key);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it->key);
            if (itd == m_id_map.end())
                return false;
        }
        nb_id_t key_id = itd->second;

        itd = m_new_id_map.find(it->value);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it->value);
            if (itd == m_id_map.end())
                return false;
        }
        nb_id_t value_id = itd->second;

        map_data.data.insert(std::pair<nb_id_t, nb_id_t>(key_id, value_id));
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_map::pack(map_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_user_object(int index, UserObject_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    user_data_t user_data;
    descriptor_data_t desc_data;

    user_data.name = in_value->get_name();

    index_id_map_itr itd;
    if_compound_data_t if_comp_data;
    func_pair_t pairs;

    //find subobjs
    std::vector<int> subobjs = in_value->get_subobjects();
    for (std::vector<int>::iterator it = subobjs.begin(); it != subobjs.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        user_data.subobjs.push_back(itd->second);
    }

    //interface
    itd = m_new_id_map.find(in_value->get_interface());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_interface());
        if (itd == m_id_map.end())
            return false;
    }
    user_data.interface = itd->second;

    //decriptor
    std::vector<int> subobj_interface = in_value->get_subobjectInterfaces();
    for (std::vector<int>::iterator it1 = subobj_interface.begin(); it1 != subobj_interface.end(); ++it1)
    {
        itd = m_new_id_map.find(*it1);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it1);
            if (itd == m_id_map.end())
                return false;
        }
        desc_data.subobj_interfaces.push_back(itd->second);
    }
    desc_data.name = in_value->get_name();
    desc_data.name.append("_descriptor");
    std::vector<Binding> bings = in_value->get_bindings();
    for (std::vector<Binding>::iterator it2 = bings.begin(); it2 != bings.end(); ++it2)
    {
        itd = m_new_id_map.find(it2->declaration);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it2->declaration);
            if (itd == m_id_map.end())
                return false;
        }
        pairs.declaration_id = itd->second;

        itd = m_new_id_map.find(it2->implementation);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it2->implementation);
            if (itd == m_id_map.end())
                return false;
        }
        pairs.implementation_id = itd->second;

        desc_data.funcs.push_back(pairs);
    }

    //request_nb_id for descriptor
    nb_id_t     desc_id;
    int         type = NBID_TYPE_OBJECT_DESCRIPTOR;
    if (!request_alone_id_by_type(type, desc_id))
        return false;
    content     desc_raw_data;
    obj_impl_descriptor::pack(desc_data, desc_id, desc_raw_data);
    write_to_db(desc_id, desc_raw_data);

    user_data.descriptor = desc_id;
    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_user::pack(user_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_container_def_object(int index, UserContainerDefinition_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    cont_def_data_t cont_def_data;

    cont_def_data.name = in_value->get_name();

    index_id_map_itr itd;

    storage_info_t storage_info;
    anchor_info_t anchor_info;
    // storages
    std::vector<Storage> storages = in_value->get_storages();
    for (std::vector<Storage>::iterator it = storages.begin(); it != storages.end(); ++it)
    {
        if_exp_group key_type, val_type;
        if_compound_data_t storage_ifc;
        storage_ifc.name = "storage interface";
        storage_info.name = it->name;
        storage_info.type = NBID_TYPE_STORAGE_SINGLEVALUE;//static_cast<nb_type_t>(it->type);
        //storage interface
        itd = m_new_id_map.find(it->key);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it->key);
            if(itd == m_id_map.end())
                return false;
        }
        nb_id_t key_min_if = itd->second;

        itd = m_new_id_map.find(it->value);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it->value);
            if (itd == m_id_map.end())
                return false;
        }
        nb_id_t val_min_if = itd->second;

        key_type.min_if = key_min_if;
        val_type.min_if = val_min_if;
        storage_ifc.groups.push_back(key_type);
        storage_ifc.groups.push_back(val_type);

        nb_id_vector ifc_ids;
        ifc_ids.push_back(key_min_if);
        ifc_ids.push_back(val_min_if);

        if (!generate_interface_decls(storage_ifc, NB_INTERFACE_STORAGE_SIMPLE, ifc_ids, storage_info.interface))
            return false;
        cont_def_data.storages.push_back(storage_info);
    }

    // anchors
    nb_id_vector decls;
    obj_impl_interface::get_general_instructions(decls);
    std::vector<Anchor> anchors = in_value->get_anchors();
    for (std::vector<Anchor>::iterator it1 = anchors.begin(); it1 != anchors.end(); ++it1)
    {
        if_compound_data_t anchor_ifc;
        anchor_ifc.decls = decls; 
        anchor_ifc.name = "anchor interface";
        anchor_info.name = it1->name;
        anchor_info.registed = it1->registered;
        std::vector<Binding> bindings = it1->bindings;
        for (std::vector<Binding>::iterator it2 = bindings.begin(); it2 != bindings.end(); ++it2)
        {
            func_pair_t func_pair;
            itd = m_new_id_map.find(it2->declaration);
            if (itd == m_new_id_map.end())
            {
                itd = m_id_map.find(it2->declaration);
                if (itd == m_id_map.end())
                    return false;
            }
            func_pair.declaration_id = itd->second;
            anchor_ifc.decls.push_back(itd->second);

            itd = m_new_id_map.find(it2->implementation);
            if (itd == m_new_id_map.end())
            {
                itd = m_id_map.find(it2->implementation);
                if (itd == m_id_map.end())
                    return false;
            }
            func_pair.implementation_id = itd->second;

            anchor_info.funcs.push_back(func_pair);

        }

        nb_id_t anchor_ifc_id;
        int type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        content anchor_raw;
        if (!request_alone_id_by_type(type, anchor_ifc_id))
            return false;
        obj_impl_interface_compound::pack(anchor_ifc, anchor_ifc_id, anchor_raw);
        write_to_db(anchor_ifc_id, anchor_raw);

        anchor_info.interface = anchor_ifc_id;
        cont_def_data.anchors.push_back(anchor_info);
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;
    obj_impl_container_def::pack(cont_def_data, out, raw_data);
    return true;
}

bool compiler_generator::generate_implementation_object(int index, Implementation_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    exec_impl_graph_t impl_data;

    impl_data.name = in_value->get_name();
    impl_data.handlesException = static_cast<nb_exception_type_t>(in_value->get_handlesException()); 
    impl_data.inNodeTimeNum = in_value->get_timelines();

    index_id_map_itr itd;

    // master
    itd = m_new_id_map.find(in_value->get_master());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_master());
        if (itd == m_id_map.end())
            return false;
    }
    impl_data.master = itd->second;

    // external_decl
    std::vector<int> inports = in_value->get_Inputports();
    std::vector<int> outports = in_value->get_Outputports();
    std::string str1 = in_value->get_name();
    if (!generate_external_decl(str1, inports, outports, impl_data.external_decl))
        return false;

    //find constants
    std::vector<int> constants = in_value->get_constants();
    for (std::vector<int>::iterator it = constants.begin(); it != constants.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        impl_data.constants.push_back(itd->second);
    }

    //find nodes
    std::vector<int> nodes = in_value->get_nodes();
    for (std::vector<int>::iterator it1 = nodes.begin(); it1 != nodes.end(); ++it1)
    {
        itd = m_new_id_map.find(*it1);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it1);
            if (itd == m_id_map.end())
                return false;
        }
        impl_data.nodes.push_back(itd->second);
    }

    // find paths
    node_path_t node_path;
    std::vector<Path> paths = in_value->get_paths();
    for (std::vector<Path>::iterator it2 = paths.begin(); it2 != paths.end(); ++it2)
    {
        node_path.in_node = it2->startNode;
        node_path.in_port = it2->startPort;
        node_path.out_node = it2->stopNode;
        node_path.out_port = it2->stopPort;

        impl_data.paths.push_back(node_path);
    }

    // out paths
    int inode_size = nodes.size();
    for (int i = 0; i < inode_size; ++i)
    {
        out_port_path_idx_t idxs;
        for (std::vector<Path>::size_type j = 0; j < paths.size(); ++j)
        {
            if (paths[j].startNode == i)
                idxs.path_idxs.push_back(j);
        }
        impl_data.out_paths.push_back(idxs);
    }

    // out port size
    impl_data.out_port_size = in_value->get_Outputports().size();

    // visualInformation
    std::string strval;
    std::vector<Coordinate> coordinates = in_value->get_coordinates();
    for (std::vector<Coordinate>::iterator it3 = coordinates.begin(); it3 != coordinates.end(); ++it3)
    {
        std::string st1 = boost::lexical_cast<std::string>(it3->x);
        strval.append(st1);
        strval.append(",");
        st1 = boost::lexical_cast<std::string>(it3->y);
        strval.append(st1);
        strval.append(",");
        st1 = boost::lexical_cast<std::string>(it3->height);
        strval.append(st1);
        strval.append(",");
        st1 = boost::lexical_cast<std::string>(it3->width);
        strval.append(st1);
        strval.append(",");
    }

    // request id
    nb_id_t string_id;
    content string_raw;
    int type = NBID_TYPE_OBJECT_STRING;
    if (!request_alone_id_by_type(type, string_id))
        return false;
    obj_impl_string::pack(strval, string_id, string_raw);
    write_to_db(string_id, string_raw);

    impl_data.visualInformation = string_id;

    //================================ ss table ====================================================
    // set the start_size length
    impl_data.m_total_size = 0;
    impl_data.m_ss_length = impl_data.nodes.size() + 1;
    impl_data.mp_start_size = new exe_impl_node_t[impl_data.m_ss_length];

    for (int i = 0; i < inode_size; ++i)
    {
        int in_num = 0;
        if (!get_inport_nums(nodes[i], in_num))
            return false;
        impl_data.m_total_size = impl_data.m_total_size + in_num;
        exe_impl_node_t exe_node;
        exe_node.m_start_position = i;
        exe_node.m_size = in_num + impl_data.inNodeTimeNum[i];
        exe_node.m_confirm_size = in_num;
        impl_data.mp_start_size[exe_node.m_start_position] = exe_node;
    }

    exe_impl_node_t   impl_node;
    impl_node.m_start_position = impl_data.nodes.size();
    impl_node.m_size = impl_data.out_port_size;
    impl_node.m_confirm_size = impl_data.out_port_size;
    impl_data.mp_start_size[impl_data.nodes.size()] = impl_node;
    for (int i = 1; i < impl_data.m_ss_length; ++i)
        impl_data.mp_start_size[i].m_start_position = impl_data.mp_start_size[i-1].m_start_position + impl_data.mp_start_size[i-1].m_confirm_size;

    impl_data.m_io_obj_lenth = impl_data.m_total_size + impl_data.out_port_size;    
    //==============================================================================================

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;
    obj_impl_exec_impl::pack(impl_data, out, raw_data);

    // print the implementation
    //exec_implement::print_implement(impl_data);

    return true;
}

bool compiler_generator::generate_declaration_compound_object(int index, Declaration_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    decl_compound_data_t decl_data;

    decl_data.name = in_value->get_name();
    decl_data.visualInformation = nb_id_t();

    index_id_map_itr itd;
    iport_t iport;
    oport_t oport;
    decl_exp_idx exp_idx;
    decl_exp_group exp_group;

    // find decl_exp_groups
    std::vector<DeclarationExpansionGroup> expansionGroup = in_value->get_expansionGroups();
    std::vector<DeclarationExpansionIndex> members;
    for (std::vector<DeclarationExpansionGroup>::iterator it = expansionGroup.begin(); it != expansionGroup.end(); ++it)
    {
        exp_group.name = it->name;
        exp_group.expanded = it->expanded;
        itd = m_new_id_map.find(it->minimumInterface);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it->minimumInterface);
            if (itd == m_id_map.end())
                return false;
        }

        exp_group.min_if = itd->second;
        members = it->members;
        for (std::vector<DeclarationExpansionIndex>::iterator it1 = members.begin(); it1 != members.end(); ++it1)
        {
            exp_idx.is_input = it1->isInput;
            exp_idx.port_idx = it1->portNumber;
            exp_idx.relay_idx = it1->relayIndex;

            exp_group.members.push_back(exp_idx);
        }
        decl_data.groups.push_back(exp_group);
    }

    // find oport
    std::vector<OutputPort> outports = in_value->get_outputPort();
    for (std::vector<OutputPort>::iterator it2 = outports.begin(); it2 != outports.end(); ++it2)
    {
        oport.name = it2->name;
        itd = m_new_id_map.find(it2->interface);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it2->interface);
            if (itd == m_id_map.end())
                return false;
        }
        oport.interface = itd->second;

        decl_data.oports.push_back(oport);
    }

    //find iport
    std::vector<InputPort> inports = in_value->get_inputPorts();
    for (std::vector<InputPort>::iterator it3 = inports.begin(); it3 != inports.end(); ++it3)
    {
        iport.name = it3->name;
        itd = m_new_id_map.find(it3->interface);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it3->interface);
            if (itd == m_id_map.end())
                return false;
        }
        iport.interface = itd->second;

        itd = m_new_id_map.find(it3->defaultValue);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it3->defaultValue);
            if (itd == m_id_map.end())
                return false;
        }
        iport.default_value = itd->second;

        decl_data.iports.push_back(iport);
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_decl_compound::pack(decl_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_declaration_expanded_object(int index, ExpandedDeclaration_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    decl_expanded_data_t decl_expanded_data;

    decl_expanded_data.name = in_value->get_name();

    index_id_map_itr itd;
    itd = m_new_id_map.find(in_value->get_parentDeclaration());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_parentDeclaration());
        if (itd == m_id_map.end())
            return false;
    }
    decl_expanded_data.origin_decl_id = itd->second;

    // find expanded_ifs
    std::vector<int> interfaces = in_value->get_expandedInterfaces();
    for (std::vector<int>::iterator it = interfaces.begin(); it != interfaces.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        decl_expanded_data.expanded_ifs.push_back(itd->second);
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_decl_expanded::pack(decl_expanded_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_interface_compound_object(int index, UserInterface_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    if_compound_data_t if_data;
    index_id_map_itr itd;

    if_data.name = in_value->get_name();
    if_data.is_singleton = in_value->get_isSingleton();
    if_data.visualInformation = nb_id_t();

    std::vector<int> decls = in_value->get_declarations();
    std::vector<InterfaceExpansionGroup> groups = in_value->get_groups();
    std::vector<InterfaceExpansionIndex> if_index;
    if_exp_idx exp_idx;
    if_exp_group exp_group;

    // find decls
    for (std::vector<int>::iterator it = decls.begin(); it != decls.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        if_data.decls.push_back(itd->second);
    }

    // find exp_groups
    for (std::vector<InterfaceExpansionGroup>::iterator it1 = groups.begin(); it1 != groups.end(); ++it1)
    {
        exp_group.name = it1->name;
        itd = m_new_id_map.find(it1->minimumInterface);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(it1->minimumInterface);
            if (itd == m_id_map.end())
                return false;
        }
        exp_group.min_if = itd->second;

        if_index = it1->members;
        for (std::vector<InterfaceExpansionIndex>::iterator it2 = if_index.begin(); it2 != if_index.end(); ++it2)
        {
            exp_idx.decl_idx = it2->declarationIndex;
            exp_idx.group_idx = it2->groupIndex;

            exp_group.members.push_back(exp_idx);
        }
        if_data.groups.push_back(exp_group);
    }
    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_interface_compound::pack(if_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_interface_expanded_object(int index, ExpandedInterface_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    return true;
}

bool compiler_generator::generate_exec_obj_object(int index, ObjectFunctionExecutable_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    exec_obj_func_data_t exec_obj_data;

    exec_obj_data.name = in_value->get_name();
    exec_obj_data.postcut = in_value->get_postCut();

    index_id_map_itr itd;
    // find recover
    itd = m_new_id_map.find(in_value->get_recoverer());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_recoverer());
        if (itd == m_id_map.end())
            return false;
    }
    exec_obj_data.recoverer = itd->second;
    // find selected_decl
    itd = m_new_id_map.find(in_value->get_selectedDeclaration());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_selectedDeclaration());
        if (itd == m_id_map.end())
            return false;
    }
    exec_obj_data.selected_decl = itd->second;

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_exec_obj_func::pack(exec_obj_data, out, raw_data); 

    return true;
}

bool compiler_generator::generate_exec_condition_object(int index, ConditionalExcutable_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    exec_cond_data_t cond_data;

    cond_data.name = in_value->get_name();
    cond_data.visualInformation = nb_id_t();

    index_id_map_itr itd;

    // find external_decl
    std::vector<int> inports = in_value->get_Inputports();
    std::vector<int> outports = in_value->get_Outputports();
    std::string strval = in_value->get_name();
    if (!generate_external_decl(strval, inports, outports, cond_data.external_decl))
        return false;

    // find alternate_exec
    std::vector<int> alternate_execs = in_value->get_alternateExecutables();
    for (std::vector<int>::iterator it = alternate_execs.begin(); it != alternate_execs.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        cond_data.alternate_execs.push_back(itd->second);
    }

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_exec_condition::pack(cond_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_exec_iterator_object(int index, IterativeExcutable_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    exec_iterator_data_t iterator_data;

    iterator_data.name = in_value->get_name();
    iterator_data.visualInformation = nb_id_t();

    index_id_map_itr itd;

    // find external_decl
    std::vector<int> inports = in_value->get_Inputports();
    std::vector<int> outports = in_value->get_Outputports();
    std::string strval = in_value->get_name();
    if (!generate_external_decl(strval, inports, outports, iterator_data.external_decl))
        return false;

    // find repeated_exec
    itd = m_new_id_map.find(in_value->get_repeatedExecutable());
    if (itd == m_new_id_map.end())
    {
        itd = m_id_map.find(in_value->get_repeatedExecutable());
        if (itd == m_id_map.end())
            return false;
    }
    iterator_data.repeated_exec = itd->second;

    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;
    obj_impl_exec_iterator::pack(iterator_data, out, raw_data);

    return true;
}

bool compiler_generator::generate_exec_storage_func_object(int index, StorageFunctionExecutable_editor_ptr in_value, nb_id_t& out, content& raw_data)
{
    exec_storage_func_data_t storage_data;
    index_id_map_itr itd;

    storage_data.name = in_value->get_name();
    storage_data.storage_idx = in_value->get_storageIdx();

    // selected_decl
    itd = m_id_map.find(in_value->get_selectedDeclaration());
    if (itd == m_id_map.end())
    {
        itd = m_new_id_map.find(in_value->get_selectedDeclaration());
        if (itd == m_new_id_map.end())
            return false;
    }
    storage_data.selected_decl = itd->second;

    // storage id
    itd = m_new_id_map.find(index);
    if (itd == m_new_id_map.end())
        return false;
    out = itd->second;

    obj_impl_exec_storage_func::pack(storage_data, out, raw_data);

    return true;
}

//==================================================================================================

bool compiler_generator::generate_interface_decls(
        if_compound_data_t& if_data, nb_builtin_interface_t if_type, nb_id_vector& if_ids, nb_id_t& out_id)
{
    int type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;

    decl_expanded_data_t decl_data;
    for (nb_id_vector_it it = if_ids.begin(); it != if_ids.end(); ++it)
        decl_data.expanded_ifs.push_back(*it);

    nb_id_vector decl_ids;
    obj_impl_interface::get_builtin_instructions(nb_id_t(if_type), false, decl_ids);
    for (uint32_t i = 0; i < decl_ids.size(); ++i)
    {
        nb_id_t decl_id;
        content decl_raw;
        obj_impl_declaration::get_instruction_name(decl_ids[i], decl_data.name);
        decl_data.origin_decl_id = decl_ids[i];
        if (!request_alone_id_by_type(type, decl_id))
            return false;
        obj_impl_decl_expanded::pack(decl_data, decl_id, decl_raw);
        write_to_db(decl_id, decl_raw);
        if_data.decls.push_back(decl_id);
    }
    nb_id_vector builtin_decls;
    obj_impl_interface::get_general_instructions(builtin_decls);

    for (uint32_t i = 0; i < builtin_decls.size(); ++i)
        if_data.decls.push_back(builtin_decls[i]);

    type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
    content ifc_raw;
    if (!request_alone_id_by_type(type, out_id))
        return false;
    obj_impl_interface_compound::pack(if_data, out_id, ifc_raw);
    write_to_db(out_id, ifc_raw);

    return true;
}

bool compiler_generator::generate_external_decl(std::string& strval, std::vector<int>& iports, std::vector<int>& oports, nb_id_t& out)
{
    decl_compound_data_t decl_data;
    iport_t iport;
    oport_t oport;
    index_id_map_itr itd;
    decl_data.name = strval;
    decl_data.name.append("_external_decl");
    decl_data.visualInformation = nb_id_t();

    std::vector<int>::iterator it;
    for (it = iports.begin(); it != iports.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if(itd == m_id_map.end())
                return false;
        }
        iport.interface = itd->second;
        decl_data.iports.push_back(iport);
    }

    for (it = oports.begin(); it != oports.end(); ++it)
    {
        itd = m_new_id_map.find(*it);
        if (itd == m_new_id_map.end())
        {
            itd = m_id_map.find(*it);
            if (itd == m_id_map.end())
                return false;
        }
        oport.interface = itd->second;
        decl_data.oports.push_back(oport);
    }

    // request_nb_id_info decl_info;
    int type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    content decl_raw;
    if (!request_alone_id_by_type(type, out))
        return false;
    obj_impl_decl_compound::pack(decl_data, out, decl_raw);

    write_to_db(out, decl_raw);

    return true;
}

bool compiler_generator::request_alone_id_by_type(int type, nb_id_t& nid)
{
    request_alone_nb_id_info    input;
    input.committer_id = m_hc_id;
    input.type = type;
    return request_alone_nb_id(input, nid);
}

bool compiler_generator::get_inport_nums(int index, int& in_num)
{
    // 1. get node from db
    index_id_map_itr it1 = m_id_map.find(index);
    if (it1 != m_id_map.end())
    {
        content raw_data;
        read_from_db(it1->second, raw_data);

        nb_id_t decl_id;
        switch (it1->second.get_type())
        {
            case NBID_TYPE_OBJECT_EXEC_CONDITION:
            {
                exec_cond_data_t cond_data;
                nb_id_t cond_id;
                obj_impl_exec_condition::unpack(raw_data, cond_id, cond_data);
                decl_id = cond_data.external_decl;
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_ITERATOR:
            {
                exec_iterator_data_t iterator_data;
                nb_id_t iter_id;
                obj_impl_exec_iterator::unpack(raw_data, iter_id, iterator_data);
                decl_id = iterator_data.external_decl;
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
            {
                exec_storage_func_data_t storage_data;
                nb_id_t storage_id;
                obj_impl_exec_storage_func::unpack(raw_data, storage_id, storage_data);
                decl_id = storage_data.selected_decl;
                break;
            }
            case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
            {
                exec_obj_func_data_t exec_obj_data;
                nb_id_t exec_obj_id;
                obj_impl_exec_obj_func::unpack(raw_data, exec_obj_id, exec_obj_data);
                decl_id = exec_obj_data.selected_decl;
                break;
            }
            default:
                return false;
        }

        content raw_data1;
        read_from_db(decl_id, raw_data1);
        nb_id_t idr;
        decl_compound_data_t decl_data;
        obj_impl_decl_compound::unpack(raw_data1, idr, decl_data);
        in_num = decl_data.iports.size();
    }
    else
    {
        // 2. get node from editor map
        index_editor_map_itr it2 = m_editor_map.find(index);
        if (it2 != m_editor_map.end())
        {
            // 2.1 get the declaration index
            int index_decl = 0;
            switch (it2->second->get_editor_type())
            {
                case e_ObjectFunctionExecutable_editor:
                {
                    ObjectFunctionExecutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(it2->second);
                    index_decl = peditor->get_selectedDeclaration();
                    break;
                }
                case e_StorageFunctionExecutable_editor:
                {
                    StorageFunctionExecutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<StorageFunctionExecutable_editor>(it2->second);
                    index_decl = peditor->get_selectedDeclaration();
                    break;
                }
                case e_ConditionalExcutable_editor:
                {
                    ConditionalExcutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(it2->second);
                    in_num = peditor->get_Inputports().size();
                    return true;
                }
                case e_IterativeExcutable_editor:
                {
                    IterativeExcutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(it2->second);
                    in_num = peditor->get_Inputports().size();
                    return true;
                }
                default:
                    return false;
            }

            index_editor_map_itr itdecl = m_editor_map.find(index_decl);
            if (itdecl != m_editor_map.end())
            {
                // 2.2 get the declaration from editor
                if (itdecl->second->get_editor_type() == e_ExpandedDeclaration_editor)
                {
                    ExpandedDeclaration_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(itdecl->second);
                    index_decl = peditor->get_parentDeclaration();
                    itdecl = m_editor_map.find(index_decl);
                    if (itdecl == m_editor_map.end())
                        return get_inport_nums_from_decl(index_decl, in_num);
                }

                Declaration_editor_ptr peditor = std::tr1::dynamic_pointer_cast<Declaration_editor>(itdecl->second);
                std::vector<InputPort> ins = peditor->get_inputPorts();
                in_num = ins.size();
            }
            else
            {
                // 2.3 get the declaration from id map
                return get_inport_nums_from_decl(index_decl, in_num);
            }
        }
    }

    return true;
}

bool compiler_generator::get_inport_nums_from_decl(int index, int& in_num)
{
    index_id_map_itr itid = m_id_map.find(index);
    if (itid != m_id_map.end())
    {
        nb_id_t decl_id = itid->second;

        if (decl_id.is_object_decl_expanded())
        {
            // expanded declaration id
            content raw_data;
            read_from_db(decl_id, raw_data);
            nb_id_t idr;
            decl_expanded_data_t decl_data;
            obj_impl_decl_expanded::unpack(raw_data, idr, decl_data);
            decl_id = decl_data.origin_decl_id;
        }

        if (decl_id.is_instruction_array() || decl_id.is_instruction_map() || decl_id.is_instruction_storage())
        {
            // 2.3.1 expaneded declaration id
            decl_compound_data_t data;
            if (!nb_const::get_builtin_decl_compound(decl_id, data))
                return false;

            in_num = data.iports.size();
        }
        else if (decl_id.is_object_declaration())
        {
            // 2.3.2 builtin declaration id
            std::vector<nb_id_t> vin, vout;
            obj_impl_declaration::get_interfaces(decl_id, vin, vout);
            in_num = vin.size();
        }
        else
        {
            // 2.3.3 compound declaration id
            content raw_data;
            read_from_db(decl_id, raw_data);
            nb_id_t idr;
            decl_compound_data_t decl_data;
            obj_impl_decl_compound::unpack(raw_data, idr, decl_data);
            in_num = decl_data.iports.size();
        }
    }

    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
