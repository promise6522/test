#include <vector>

#include "cpr_pre_compiler.h"


pre_compiler::pre_compiler(const index_info_t& index_info)
{
    m_index_info = index_info;
}

pre_compiler::~pre_compiler()
{
}

bool pre_compiler::run(int index)
{
    if (m_editor_result.find(index) != m_editor_result.end())
        return true;

    if (m_id_result.find(index) != m_id_result.end())
        return true;

    index_id_map_itr it1 = m_index_info.idx_id_map.find(index);
    if (it1 != m_index_info.idx_id_map.end())
    {
        m_id_result.insert(std::make_pair(index, it1->second));
        return true;
    }

    index_editor_map_itr it2 = m_index_info.idx_xml_map.find(index);
    if (it2 != m_index_info.idx_xml_map.end())
    {
        m_editor_result.insert(std::make_pair(index, it2->second));
        return check_sub_item(it2->second);
    }

    return false;
}

bool pre_compiler::get_run_result(index_editor_map& editor_data, index_id_map& id_data)
{
    editor_data = m_editor_result;
    id_data = m_id_result;
    return true;
}

bool pre_compiler::check_sub_item(const editor_base_ptr& editor_ptr)
{
    bool ret = false;

    switch (editor_ptr->get_editor_type())
    {
        case e_UserObject_editor:
        {
            UserObject_editor_ptr peditor = std::tr1::dynamic_pointer_cast<UserObject_editor>(editor_ptr);
            ret = pre_compile_user(peditor);
            break;
        }

        case e_UserContainerDefinition_editor:
        {
            UserContainerDefinition_editor_ptr peditor = std::tr1::dynamic_pointer_cast<UserContainerDefinition_editor>(editor_ptr);
            ret = pre_compile_container_definition(peditor);
            break;
        }

        case e_UserAccess_editor:
        {
            UserAccess_editor_ptr peditor = std::tr1::dynamic_pointer_cast<UserAccess_editor>(editor_ptr);
            ret = pre_compile_access(peditor);
            break;
        }

        case e_Declaration_editor:
        {
            Declaration_editor_ptr peditor = std::tr1::dynamic_pointer_cast<Declaration_editor>(editor_ptr);
            ret = pre_compile_declaration(peditor);
            break;
        }

        case e_ExpandedDeclaration_editor:
        {
            ExpandedDeclaration_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ExpandedDeclaration_editor>(editor_ptr);
            ret = pre_compile_expanded_declaration(peditor);
            break;
        }

        case e_UserInterface_editor:
        {
            UserInterface_editor_ptr peditor = std::tr1::dynamic_pointer_cast<UserInterface_editor>(editor_ptr);
            ret = pre_compile_interface(peditor);
            break;
        }

        case e_ExpandedInterface_editor:
        {
            ExpandedInterface_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ExpandedInterface_editor>(editor_ptr);
            ret = pre_compile_expanded_interface(peditor);
            break;
        }

        case e_Implementation_editor:
        {
            Implementation_editor_ptr peditor = std::tr1::dynamic_pointer_cast<Implementation_editor>(editor_ptr);
            ret = pre_compile_implement(peditor);
            break;
        }

        case e_ObjectFunctionExecutable_editor:
        {
            ObjectFunctionExecutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ObjectFunctionExecutable_editor>(editor_ptr);
            ret = pre_compile_obj_func(peditor);
            break;
        }

        case e_StorageFunctionExecutable_editor:
        {
            StorageFunctionExecutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<StorageFunctionExecutable_editor>(editor_ptr);
            ret = pre_compile_storage_func(peditor);
            break;
        }

        case e_ConditionalExcutable_editor:
        {
            ConditionalExcutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ConditionalExcutable_editor>(editor_ptr);
            ret = pre_compile_condition(peditor);
            break;
        }

        case e_IterativeExcutable_editor:
        {
            IterativeExcutable_editor_ptr peditor = std::tr1::dynamic_pointer_cast<IterativeExcutable_editor>(editor_ptr);
            ret = pre_compile_iterative(peditor);
            break;
        }

        case e_StringValue_editor:
        case e_BytesValue_editor:
            ret = true;
            break;

        case e_ArrayValue_editor:
        {
            ArrayValue_editor_ptr peditor = std::tr1::dynamic_pointer_cast<ArrayValue_editor>(editor_ptr);
            ret = pre_compile_array(peditor);
            break;
        }

        case e_MapValue_editor:
        {
            MapValue_editor_ptr peditor = std::tr1::dynamic_pointer_cast<MapValue_editor>(editor_ptr);
            ret = pre_compile_map(peditor);
            break;
        }

        default:
            break;
    }

    return ret;
}

bool pre_compiler::pre_compile_user(UserObject_editor_ptr peditor)
{
    if (!run(peditor->get_interface()))
        return false;

    std::vector<int> sub_obj = peditor->get_subobjects();
    for (std::vector<int>::size_type i = 0; i < sub_obj.size(); ++i)
    {
        if (!run(sub_obj[i]))
            return false;
    }

    std::vector<Binding> bind = peditor->get_bindings();
    for (std::vector<Binding>::size_type i = 0; i < bind.size(); ++i)
    {
        if (!run(bind[i].declaration))
            return false;
        if (!run(bind[i].implementation))
            return false;
    }

    std::vector<int> sub_objif = peditor->get_subobjectInterfaces();
    for (std::vector<int>::size_type i = 0; i < sub_obj.size(); ++i)
    {
        if (!run(sub_objif[i]))
            return false;
    }

    return true;
}

bool pre_compiler::pre_compile_container_definition(UserContainerDefinition_editor_ptr peditor)
{
    std::vector<Storage> st = peditor->get_storages();
    for (std::vector<Storage>::size_type i = 0; i < st.size(); ++i)
    {
        if (!run(st[i].key))
            return false;
        if (!run(st[i].value))
            return false;
    }

    std::vector<Anchor> an = peditor->get_anchors();
    for (std::vector<Anchor>::size_type i = 0; i < an.size(); ++i)
    {
        for (std::vector<Binding>::size_type j = 0; j < an[i].bindings.size(); ++j)
        {
            if (!run(an[i].bindings[j].declaration))
                return false;
            if (!run(an[i].bindings[j].implementation))
                return false;
        }
    }

    return true;
}

bool pre_compiler::pre_compile_access(UserAccess_editor_ptr peditor)
{
    // TODO

    return true;
}

bool pre_compiler::pre_compile_declaration(Declaration_editor_ptr peditor)
{
    std::vector<InputPort> ins = peditor->get_inputPorts();
    for (std::vector<InputPort>::size_type i = 0; i < ins.size(); ++i)
    {
        if (!run(ins[i].interface))
            return false;
        if (!run(ins[i].defaultValue))
            return false;
    }

    std::vector<OutputPort> outs = peditor->get_outputPort();
    for (std::vector<OutputPort>::size_type i = 0; i < outs.size(); ++i)
    {
        if (!run(outs[i].interface))
            return false;
    }

    std::vector<DeclarationExpansionGroup> gourps = peditor->get_expansionGroups();
    for (std::vector<DeclarationExpansionGroup>::size_type i = 0; i < gourps.size(); ++i)
    {
        if (!run(gourps[i].minimumInterface))
            return false;

        for (std::vector<DeclarationExpansionIndex>::size_type j = 0; j < gourps[i].members.size(); ++j)
        {
            if (!run(gourps[i].members[j].relayIndex))
                return false;
        }
    }

    return true;
}

bool pre_compiler::pre_compile_expanded_declaration(ExpandedDeclaration_editor_ptr peditor)
{
    if (!run(peditor->get_parentDeclaration()))
        return false;

    std::vector<int> exif = peditor->get_expandedInterfaces();
    for (std::vector<int>::size_type i = 0; i < exif.size(); ++i)
    {
        if (!run(exif[i]))
            return false;
    }

    return true;
}

bool pre_compiler::pre_compile_interface(UserInterface_editor_ptr peditor)
{
    std::vector<int> decls = peditor->get_declarations();
    for (std::vector<int>::size_type i = 0; i < decls.size(); ++i)
    {
        if (!run(decls[i]))
            return false;
    }

    std::vector<InterfaceExpansionGroup> gourps = peditor->get_groups();
    for (std::vector<InterfaceExpansionGroup>::size_type i = 0; i < gourps.size(); ++i)
    {
        if (!run(gourps[i].minimumInterface))
            return false;

        for (std::vector<InterfaceExpansionIndex>::size_type j = 0; j < gourps[i].members.size(); ++j)
        {
            if (!run(gourps[i].members[j].declarationIndex))
                return false;
            if (!run(gourps[i].members[j].groupIndex))
                return false;
        }
    }

    return true;
}

bool pre_compiler::pre_compile_expanded_interface(ExpandedInterface_editor_ptr peditor)
{
    // TODO

    return true;
}

bool pre_compiler::pre_compile_implement(Implementation_editor_ptr peditor)
{
    if (!run(peditor->get_master()))
        return false;

    std::vector<int> ins = peditor->get_Inputports();
    for (std::vector<int>::size_type i = 0; i < ins.size(); ++i)
    {
        if (!run(ins[i]))
            return false;
    }

    std::vector<int> outs = peditor->get_Outputports();
    for (std::vector<int>::size_type i = 0; i < outs.size(); ++i)
    {
        if (!run(outs[i]))
            return false;
    }

    std::vector<int> cons = peditor->get_constants();
    for (std::vector<int>::size_type i = 0; i < cons.size(); ++i)
    {
        if (!run(cons[i]))
            return false;
    }

    std::vector<int> nodes = peditor->get_nodes();
    for (std::vector<int>::size_type i = 0; i < nodes.size(); ++i)
    {
        if (!run(nodes[i]))
            return false;
    }

    return true;
}

bool pre_compiler::pre_compile_obj_func(ObjectFunctionExecutable_editor_ptr peditor)
{
    if (!run(peditor->get_selectedDeclaration()))
        return false;

    if (!run(peditor->get_recoverer()))
        return false;

    return true;
}

bool pre_compiler::pre_compile_storage_func(StorageFunctionExecutable_editor_ptr peditor)
{
    if (!run(peditor->get_selectedDeclaration()))
        return false;

    return true;
}

bool pre_compiler::pre_compile_condition(ConditionalExcutable_editor_ptr peditor)
{
    std::vector<int> ins = peditor->get_Inputports();
    for (std::vector<int>::size_type i = 0; i < ins.size(); ++i)
    {
        if (!run(ins[i]))
            return false;
    }

    std::vector<int> outs = peditor->get_Outputports();
    for (std::vector<int>::size_type i = 0; i < outs.size(); ++i)
    {
        if (!run(outs[i]))
            return false;
    }

    std::vector<int> decls = peditor->get_alternateExecutables();
    for (std::vector<int>::size_type i = 0; i < decls.size(); ++i)
    {
        if (!run(decls[i]))
            return false;
    }

    return true;
}

bool pre_compiler::pre_compile_iterative(IterativeExcutable_editor_ptr peditor)
{
    std::vector<int> inputPorts = peditor->get_Inputports();
    for (std::vector<int>::size_type i = 0; i < inputPorts.size(); ++i)
    {
        if (!run(inputPorts[i]))
            return false;
    }

    std::vector<int> outputPorts = peditor->get_Outputports();
    for (std::vector<int>::size_type i = 0; i < outputPorts.size(); ++i)
    {
        if (!run(outputPorts[i]))
            return false;
    }

    if (!run(peditor->get_repeatedExecutable()))
        return false;

    return true;
}

bool pre_compiler::pre_compile_array(ArrayValue_editor_ptr peditor)
{
    if (!run(peditor->get_expansionInterface()))
        return false;

    std::vector<int> values = peditor->get_value();
    for (std::vector<int>::size_type i = 0; i < values.size(); ++i)
    {
        if (!run(values[i]))
            return false;
    }

    return true;
}

bool pre_compiler::pre_compile_map(MapValue_editor_ptr peditor)
{
    if (!run(peditor->get_expansionKeyInterface()))
        return false;

    if (!run(peditor->get_expansionValueInterface()))
        return false;

    std::vector<MapElement> values = peditor->get_value();
    for (std::vector<MapElement>::size_type i = 0; i < values.size(); ++i)
    {
        if (!run(values[i].key))
            return false;
        if (!run(values[i].value))
            return false;
    }

    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
