/**************************************************************************
**
**  Copyleft 2011 YunCheng Inc.
**
**************************************************************************/

#ifndef _CPR_CHECKING_H_
#define _CPR_CHECKING_H_

#include <vector>

#include "nb_compiler.h"
#include "cpr_compiler.h"

#include "ac_message_type.h"
#include "nb_typedef.h"

#include "ac_db/ac_object_db_impl.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_user.h"
#include "ac_container/access_implementation.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/obj_impl_exec_storage_func.h"

typedef std::vector<Path>::iterator Path_vec_it;
typedef std::vector<int>::iterator Node_vec_it;

class checking_datas
{
protected:
    index_editor_map    m_idx_editor_map;
    index_id_map        m_idx_id_map;

public:
    checking_datas(const index_editor_map& idx_editor_map, const index_id_map& idx_id_map);
    virtual ~checking_datas();

private:
    bool get_portNums_by_nodeIdx(const int& idx_of_node, int& port_nums, const bool& is_iport);
    bool get_interface_by_nb_id(const nb_id_t& obj_id, nb_id_t& if_id);

public:
    bool running_checking(index_string_map& error_info);
    bool checking_graph_paths(const int& idx_of_graph, index_string_map& error_info);
    bool checking_graph_nodes(const int& idx_of_graph, index_string_map& error_info);
    bool checking_if_cover(const int& idx_of_graph, index_string_map& error_info);

    bool decls_id_match_decls_id(nb_id_vector& start_decls, nb_id_vector& stop_decls);

    bool interface_id_cover_interface_id(const nb_id_t& start_id, const nb_id_t& stop_id);
    bool interface_id_cover_interface_ptr(const nb_id_t& start_id, const UserInterface_editor_ptr& stop_ptr);
    bool interface_ptr_cover_interface_id(const UserInterface_editor_ptr& start_ptr, const nb_id_t& stop_id);
    bool interface_ptr_cover_interface_ptr(const UserInterface_editor_ptr& start_ptr, const UserInterface_editor_ptr& stop_ptr);

    bool unpack_to_ifc_data(const content& data, if_compound_data_t& logic_data);
    bool unpack_to_decl_expanded_data(const content& data, decl_expanded_data_t& logic_data);
    bool unpack_to_decl_compound_data(const content& data, decl_compound_data_t& logic_data);
    bool unpack_to_exec_cond_data(const content& data, exec_cond_data_t& logic_data);
    bool unpack_to_exec_iterator_data(const content& data, exec_iterator_data_t& logic_data);
    bool unpack_to_exec_obj_func_data(const content& data, exec_obj_func_data_t& logic_data);
    bool unpack_to_array_data(const content& data, array_data_t& logic_data);
    bool unpack_to_map_data(const content& data, map_data_t& logic_data);
    bool unpack_to_bridge_data(const content& data, bridge_data_t& logic_data);
    bool unpack_to_user_data(const content& data, user_data_t& logic_data);
    bool unpack_to_access_data(const content& data, access_data_t& logic_data);
    bool unpack_to_bridge_if_data(const content& data, bridge_interface_data_t& logic_data);
    bool unpack_to_exec_storage_data(const content& data, exec_storage_func_data_t& logic_data);
};

#endif // _CPR_CHECKING_H_

// vim:set tabstop=4 shiftwidth=4 expandtab:
