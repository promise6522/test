#ifndef _CPR_GENERATOR_H_
#define _CPR_GENERATOR_H_

#include "nb_compiler_type.h"
#include "nb_typedef.h"
#include "nb_compiler.h"
#include "cpr_compiler.h"
#include "nb_id.h"
#include "ac_object/obj_impl_interface_compound.h"


typedef std::vector<content>        content_vector;
typedef content_vector::iterator    contetn_vector_itr;


class compiler_generator
{
protected:
    index_editor_map        m_editor_map;
    index_id_map            m_id_map;
    index_id_map            m_new_id_map;
    host_committer_id_t     m_hc_id;

public:
    bool generate_bytes_object(int index, BytesValue_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_string_object(int  index, StringValue_editor_ptr in_vlaue, nb_id_t& out, content& raw_data);
    bool generate_array_object(int index, ArrayValue_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_map_object(int index, MapValue_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_user_object(int index, UserObject_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_container_def_object(int index, UserContainerDefinition_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_implementation_object(int index, Implementation_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_declaration_compound_object(int index, Declaration_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_declaration_expanded_object(int index, ExpandedDeclaration_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_interface_compound_object(int index, UserInterface_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_interface_expanded_object(int index, ExpandedInterface_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_exec_obj_object(int index, ObjectFunctionExecutable_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_exec_condition_object(int index, ConditionalExcutable_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_exec_iterator_object(int index, IterativeExcutable_editor_ptr in_value, nb_id_t& out, content& raw_data);
    bool generate_exec_storage_func_object(int index, StorageFunctionExecutable_editor_ptr in_value, nb_id_t& out, content& raw_data);

    bool generate_object(index_string_map& error_info);

    compiler_generator(host_committer_id_t& hc_id,
                       const index_editor_map& idx_editor_map,
                       const index_id_map& idx_id_map,
                       index_id_map& new_obj_data);
    virtual ~compiler_generator();

private:
    bool generate_interface_decls(if_compound_data_t& if_data, nb_builtin_interface_t if_type, nb_id_vector& if_ids, nb_id_t& out_id);
    bool get_inport_nums(int index, int& in_num);
    bool get_inport_nums_from_decl(int index, int& in_num);
    bool request_alone_id_by_type(int type, nb_id_t& nid);
    bool generate_external_decl(std::string& strval, std::vector<int>& iports, std::vector<int>& oports, nb_id_t& out);

};


#endif // _CPR_GENERATOR_H_

// vim:set tabstop=4 shiftwidth=4 expandtab:
