#ifndef _CPR_PRE_COMPILER_H_
#define _CPR_PRE_COMPILER_H_

#include "nb_compiler.h"


class pre_compiler
{
protected:
    index_info_t        m_index_info;

    index_editor_map    m_editor_result;
    index_id_map        m_id_result;

public:
    pre_compiler(const index_info_t& index_info);
    virtual ~pre_compiler();

public:
    bool run(int index);
    bool get_run_result(index_editor_map& editor_data, index_id_map& id_data);

private:
    bool check_sub_item(const editor_base_ptr& editor_ptr);

    bool pre_compile_user(UserObject_editor_ptr peditor);
    bool pre_compile_container_definition(UserContainerDefinition_editor_ptr peditor);
    bool pre_compile_access(UserAccess_editor_ptr peditor);
    bool pre_compile_declaration(Declaration_editor_ptr peditor);
    bool pre_compile_expanded_declaration(ExpandedDeclaration_editor_ptr peditor);
    bool pre_compile_interface(UserInterface_editor_ptr peditor);
    bool pre_compile_expanded_interface(ExpandedInterface_editor_ptr peditor);
    bool pre_compile_implement(Implementation_editor_ptr peditor);
    bool pre_compile_obj_func(ObjectFunctionExecutable_editor_ptr peditor);
    bool pre_compile_storage_func(StorageFunctionExecutable_editor_ptr peditor);
    bool pre_compile_condition(ConditionalExcutable_editor_ptr peditor);
    bool pre_compile_iterative(IterativeExcutable_editor_ptr peditor);
    bool pre_compile_array(ArrayValue_editor_ptr peditor);
    bool pre_compile_map(MapValue_editor_ptr peditor);

};


#endif // _CPR_PRE_COMPILER_H_

// vim:set tabstop=4 shiftwidth=4 expandtab:
