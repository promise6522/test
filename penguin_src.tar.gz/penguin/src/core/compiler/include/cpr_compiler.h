#ifndef _CPR_COMPILER_H_
#define _CPR_COMPILER_H_

#include "nb_compiler.h"

#include "ac_id_dispenser.h"


bool read_from_db(const nb_id_t& obj_id, content& data);
bool write_to_db(const nb_id_t& obj_id, content& data);

bool request_host_committer_id(host_committer_id_t& hc_id);
bool request_nb_id(const request_nb_id_info& input, nb_id_t& nid);
bool request_alone_nb_id(const request_alone_nb_id_info& input, nb_id_t& nid);


class cpr_compiler
{
protected:
    index_info_t    m_index_info;

public:
    cpr_compiler(const index_info_t& index_info);
    virtual ~cpr_compiler();

    bool run(index_id_map& new_id_data, index_string_map& error_info);

private:
    bool request_ids(const host_committer_id_t& hc_id,
                     const index_editor_map& editor_data, index_id_map& new_id_data);
    bool print_generate_data();

};


#endif // _CPR_COMPILER_H_

// vim:set tabstop=4 shiftwidth=4 expandtab:
