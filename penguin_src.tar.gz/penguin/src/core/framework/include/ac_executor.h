/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_EXECUTOR_H_
#define _AC_EXECUTOR_H_

#include "ac_manager.h"

class ac_executor
{
public:
    ac_executor();
    ~ac_executor();
    
    void operator()();
    void stop();

private:
    bool m_is_stop;
};

typedef boost::shared_ptr<ac_executor> ac_executor_ptr;

#endif /* _AC_EXECUTOR_H_ */
