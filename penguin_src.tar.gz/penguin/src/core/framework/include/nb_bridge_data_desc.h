/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _NB_BRIDGE_DATA_DESC_H_
#define _NB_BRIDGE_DATA_DESC_H_

#include <stdint.h>

struct nb_bridge_field_desc
{
    int32_t field_number;
    std::string field_name;
    std::string field_type_name; // boolean, float, integer, byteArray, string,
                                 // nb_id_t, or one of the struct_name in the file
    bool is_array;
    std::string default_value;    
};

struct nb_bridge_struct_desc
{
    int32_t struct_number;
    std::string struct_name;
    std::vector<nb_bridge_field_desc*> fields;
};

inline void nb_clean_bridge_factory_info(std::vector<nb_bridge_struct_desc*>& data)
{
    std::vector<nb_bridge_struct_desc*>::size_type i, j;
    for(i = 0; i < data.size(); ++ i)
    {
        std::vector<nb_bridge_field_desc*>& fields = data[i]->fields;
        for(j = 0; j < fields.size(); ++j)
        {
            delete fields[j];
        }
        delete data[i];
    }
}

#endif /* _NB_BRIDGE_DATA_DESC_H_ */

// vim:set tabstop=4 shiftwidth=4 expandtab:
