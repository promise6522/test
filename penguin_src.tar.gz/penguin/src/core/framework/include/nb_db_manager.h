/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_DB_MANAGER_H_
#define _NB_DB_MANAGER_H_

#include <vector>
#include <boost/thread/mutex.hpp>
#include <boost/thread/shared_mutex.hpp>

#include <db_cxx.h>// for DbEnv handle

#include "ac_tool/nb_stdx_singleton.h"

class nb_db_manager : public boost_singleton<nb_db_manager>
{    
public:
    void run();

    void stop();

    bool add_env(DbEnv* penv);

    bool remove_env(DbEnv* penv);

private:
    nb_db_manager() : m_stop(false) {}
    friend struct boost_singleton<nb_db_manager>;//for singleton

    void init_db_manager();    
    static void* do_checkpoint(void* arg);

private:
    bool m_stop;
    pthread_t m_chkpoint_pid;
    std::vector< DbEnv* > m_envs_list;
    boost::shared_mutex m_envs_mutex;
};


#endif /* _NB_DB_MANAGER_H_ */
