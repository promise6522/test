/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_STATISTICS_H_
#define _AC_STATISTICS_H_

#include "ac_manager.h"

struct actor_status_statistics
{
    std::size_t total_size;
    std::size_t initializing_size;
    std::size_t initialized_size;
    
    std::size_t waiting_size;
    std::size_t queuing_size;
    std::size_t executing_size;
    std::size_t exiting_size;
    std::size_t total_queue;
};

class ac_statistics
{
public:
    ac_statistics(std::size_t interval);
    ~ac_statistics();

    void operator()();
    void stop();

    void generate_statistics();
    void clear_statistics();

    //get actor statistics
    std::size_t get_actor_list_size();
    std::size_t get_initializing_actor_size();
    std::size_t get_initialized_actor_size();
    std::size_t get_waiting_actor_size();
    std::size_t get_queuing_actor_size();
    std::size_t get_executing_actor_size();
    std::size_t get_exiting_actor_size();

    std::size_t get_empty_queue_actor_size();
    
    void dump_actors();
    void dump_actor_queue();

private:
    bool m_is_stop;
    std::size_t m_interval;
    std::size_t m_total_time;

    std::size_t m_total_actor_size;
    std::size_t m_initializing_actor_size;
    std::size_t m_initialized_actor_size;

    std::size_t m_waiting_actor_size;
    std::size_t m_queuing_actor_size;
    std::size_t m_executing_actor_size;
    std::size_t m_exiting_actor_size;

    std::size_t m_total_actor_queue;

    std::size_t m_dispatch_queue_size;
    std::map<std::string, actor_status_statistics> m_actor_statistics_map;
};

typedef boost::shared_ptr<ac_statistics> ac_statistics_ptr;

const std::size_t Default_Sleep_Time = 1;
    
#endif /* _AC_STATISTICS_H_ */
