/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_REQ_NUM_H_
#define _AC_REQ_NUM_H_

#include <iostream>
#include <iomanip>

//typedef uint32_t req_num_t;

class req_num_t
{
public:
    req_num_t() 
    {
        data = 0;
    }

    req_num_t(uint32_t num)
    {
        data = num;
    }

    req_num_t(uint32_t num, bool isInit)
    {
        data = isInit ? num | 0x80000000 : num & 0x7FFFFFF;
    }

    bool get_init_flag() const
    {
        return data & 0x80000000;
    }

    void set_init_flag(bool isInit)
    {
        data = isInit ? data | 0x80000000 : data & 0x7FFFFFF;
    }

    void print() const
    {
        LOG_DEBUG( "req_num : data = " << std::setw(4) << std::setfill('0') << std::hex << data 
                   << ( get_init_flag() ? "(init flag)" : "(general flag)"));
    }

    /*
    operator int() const
    {
        return static_cast<int>(data);
    }
    */

    operator uint32_t() const 
    {
        return data;
    }

    req_num_t& operator+=(uint32_t val) 
    {
        bool init_flag = get_init_flag();
        //remove init_flag
        data = (data & 0x7FFFFFFF) + val;
        set_init_flag(init_flag);        
        return *this;
    }

    req_num_t operator+(uint32_t val) 
    {
        req_num_t tmp = *this;
        return tmp += val;
    }

    req_num_t& operator++() 
    {
        *this += 1;
        return *this;
    }
    
    req_num_t operator++(int) 
    {
        req_num_t tmp = *this;
        ++*this;
        return tmp;
    }

    friend bool operator<(const req_num_t& v1, const req_num_t& v2);
    friend bool operator==(const req_num_t& v1, const req_num_t& v2);
    friend bool operator!=(const req_num_t& v1, const req_num_t& v2);
    friend bool operator>(const req_num_t& v1, const req_num_t& v2);
    friend bool operator>=(const req_num_t& v1, const req_num_t& v2);
    friend bool operator<=(const req_num_t& v1, const req_num_t& v2);
    friend std::ostream& operator<<(std::ostream& os, const req_num_t& req);

private:
    uint32_t data;
};

inline bool operator<(const req_num_t& v1, const req_num_t& v2)
{
    return (v1.data < v2.data);
}

inline bool operator==(const req_num_t& v1, const req_num_t& v2) 
{
    return (v1.data == v2.data);
}

inline bool operator!=(const req_num_t& v1, const req_num_t& v2) 
{
    return !(v1.data == v2.data);
}

inline bool operator>(const req_num_t& v1, const req_num_t& v2) 
{
    return (v2.data < v1.data);
}

inline bool operator<=(const req_num_t& v1, const req_num_t& v2) 
{
    return !(v2.data < v1.data);
}

inline bool operator>=(const req_num_t& v1, const req_num_t& v2) 
{
    return !(v1.data < v2.data);
}

inline std::ostream& operator<<(std::ostream& os, const req_num_t& req)
{
    os<<"req_num : data = "<<std::setw(4)<<std::setfill('0')<<std::hex<<req.data;
    if(req.get_init_flag())
    {
        os<<"(init flag)"<<std::endl;
    }
    else
    {
        os<<"(general flag)"<<std::endl;
    }

    return os;
}

/*
  test case

  void test()
  {
      req_num_t req;
      req.print();

      req = 0xf340505;
      req.print();

      req.set_init_flag(true);
      req.print();

      req = 0xffffffff;
      req.print();

      req = 0x0;
      req.print();

      req = 0x7fffffff;
      req.print();

      req = 0x80000000;
      req.print();    
    }
*/

#endif /* _AC_REQ_NUM_H_ */

