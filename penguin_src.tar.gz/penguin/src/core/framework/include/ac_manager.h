/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_MANAGER_H_
#define _AC_MANAGER_H_

#include <vector>
#include <queue>
#include <map>

#include <boost/function.hpp>
#include <boost/thread.hpp>
#include <boost/thread/shared_mutex.hpp>
#include <boost/unordered_set.hpp>
#include <boost/unordered_map.hpp>

#include "ac_actor_type.h"
#include "ac_message.h"
#include "ac_gc_threshold.h"

class ac_actor;
class nb_request_handler;

typedef boost::function<void (const std::vector<char>&)> nb_response_callback;

class ac_manager
{
private:
	ac_manager(void);
	~ac_manager(void);
	ac_manager(const ac_manager&);
	ac_manager& operator=(const ac_manager&);

public:
    typedef boost::unordered_map< host_committer_id_t, boost::unordered_set<ac_actor *> > host_committer_actors_map;

public:
	static ac_manager& instance();
    friend class ac_statistics;

    //send message by actor id
    bool send_asyn_message(ac_id_t dest_id, ac_message_t* message);
    bool send_asyn_message(ac_id_t dest_id, ac_id_t src_id, req_num_t req_num, 
                           ac_method_t type, void *pData, bool is_respond = false);

    template <typename Tid>
    bool request_actor(const Tid& id)
    {   
        ac_actor * pActor = actor_factory(id);
        if(pActor)
        {
            host_committer_id_t hc_id;
            if(id.get_hostcommitterid(hc_id))
            {
                boost::upgrade_lock<boost::shared_mutex> lock(m_hc_acs_map_mutex);
                boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
                m_hc_acs_map[hc_id].insert(pActor);
            }
            return true;
        }

        //return true if the actor is exist
        return true;
    }

    template <typename Tid, typename Tdata>
    bool request_actor_with_data(const Tid& id, const Tdata& data)
    {
        ac_actor *pActor = actor_factory(id, data);
        if(pActor)
        {   
            host_committer_id_t hc_id;
            if(id.get_hostcommitterid(hc_id))
            {
                boost::upgrade_lock<boost::shared_mutex> lock(m_hc_acs_map_mutex);
                boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
                m_hc_acs_map[hc_id].insert(pActor);
            }
            return true;
        }
        return true;
    }

    template <typename Tid>
    void remove_actor(const Tid& id)
    {
        ac_id_t ac_id;
        if(get_ac_id(id, ac_id))
        {
            set_actor_exiting_status(ac_id);
            remove_id_map(id);
        }
    }

    void remove_id_map_by_actor(ac_actor* pActor);
    void remove_associated_actors(const host_committer_id_t& hc_id);
    void remove_committer_actors(const host_committer_id_t& hc_id);

    void clear();
    
    req_num_t generate_req_num();
    void register_outside_response(const req_num_t& req_num, const bridge_id_t& bridge_id, nb_response_callback call_back);
    void unregister_outside_response(const req_num_t& req_num, const bridge_id_t& bridge_id);
    bool get_outgoing_req_num(const bridge_id_t& bridge_id, req_num_t& req_num);
    bool message_handle(const ac_message_t& message);

    ac_actor* acid_to_actor(ac_id_t ac_id);
    ac_id_t actor_to_acid(ac_actor* ac_actor);
    void set_actor_exiting_status(ac_id_t ac_id);
    bool is_actor_exist(ac_actor* pActor);

    //execution methods
    void init_manager(bool is_gc, std::size_t mem_size, std::size_t mem_rate);
    void dest_manager();
    ac_actor* get_waiting_actor();
    void put_idle_actor(ac_actor* pActor);
    void add_actor_to_dispatch_queue(ac_actor* pActor);
    bool is_dispatch_queue_empty();
    void remove_actor_in_manager(ac_actor * pActor);

    //for different id
    bool get_ac_id(const root_committer_id_t& rc_id, ac_id_t& ac_id);
    bool get_ac_id(const center_committer_id_t& cc_id, ac_id_t& ac_id);
    bool get_ac_id(const host_committer_id_t& hc_id, ac_id_t& ac_id);
    bool get_ac_id(const transaction_id_t& trans_id, ac_id_t& ac_id);
    bool get_ac_id(const nb_id_t& nb_id, ac_id_t& ac_id);
    bool get_ac_id(const execution_id_t& exe_id, ac_id_t& ac_id);
    bool get_ac_id(const bridge_id_t& bridge_id, ac_id_t& ac_id);
    bool get_ac_id(const bridge_factory_id_t& bf_id, ac_id_t& ac_id);
    bool get_ac_id(const facade_id_t& facade_id, ac_id_t& ac_id);
    bool get_ac_id(const container_id_t& cont_id, ac_id_t& ac_id);
    bool get_ac_id(const anchor_id_t& an_id, ac_id_t& ac_id);
    bool get_ac_id(const access_id_t& as_id, ac_id_t& ac_id);
    bool get_ac_id(const storage_id_t& st_id, ac_id_t& ac_id);
    
    void remove_id_map(const root_committer_id_t& rc_id);
    void remove_id_map(const center_committer_id_t& cc_id);
    void remove_id_map(const host_committer_id_t& hc_id);
    void remove_id_map(const transaction_id_t& trans_id);
    void remove_id_map(const nb_id_t& nb_id);
    void remove_id_map(const execution_id_t& exe_id);
    void remove_id_map(const bridge_id_t& bridge_id);
    void remove_id_map(const bridge_factory_id_t& bf_id);
    void remove_id_map(const facade_id_t& facade_id);
    void remove_id_map(const container_id_t& cont_id);
    void remove_id_map(const anchor_id_t& an_id);
    void remove_id_map(const access_id_t& as_id);
    void remove_id_map(const storage_id_t& st_id);

    bool is_actor_exist(const root_committer_id_t& rc_id);
    bool is_actor_exist(const center_committer_id_t& cc_id);
    bool is_actor_exist(const host_committer_id_t& hc_id);
    bool is_actor_exist(const transaction_id_t& trans_id);
    bool is_actor_exist(const nb_id_t& nb_id);
    bool is_actor_exist(const execution_id_t& exe_id);
    bool is_actor_exist(const bridge_id_t& bridge_id);
    bool is_actor_exist(const bridge_factory_id_t& bf_id);
    bool is_actor_exist(const facade_id_t& facade_id);
    bool is_actor_exist(const container_id_t& cont_id);
    bool is_actor_exist(const anchor_id_t& an_id);
    bool is_actor_exist(const access_id_t& as_id);    
    bool is_actor_exist(const storage_id_t& st_id);

    //actor list methods
    void add_actor(ac_actor * pActor);
    bool create_actor(ac_root_committer*& pActor, const root_committer_id_t& rc_id);
    bool create_actor(ac_center_committer*& pActor, const center_committer_id_t& cc_id);
    bool create_actor(ac_host_committer*& pActor, const host_committer_id_t& hc_id);
    bool create_actor(ac_transaction*& pActor, const transaction_id_t& trans_id);
    bool create_actor(ac_object*& pActor, const nb_id_t& nb_id);
    bool create_actor(ac_execution*& pActor, const execution_id_t& exe_id);
    bool create_actor(ac_bridge*& pActor, const bridge_id_t& bridge_id);
    bool create_actor(ac_bridge_factory*& pActor, const bridge_factory_id_t& bf_id);
    bool create_actor(ac_storage_facade*& pActor, const facade_id_t& facade_id);    
    bool create_actor(ac_container*& pActor, const container_id_t& cont_id);
    bool create_actor(ac_anchor*& pActor, const anchor_id_t& an_id);
    bool create_actor(ac_access*& pActor, const access_id_t& access_id);
    bool create_actor(ac_storage*& pActor, const storage_id_t& st_id);

private:
    boost::shared_mutex m_queue_mutex;
    boost::shared_mutex m_pool_mutex;
    boost::shared_mutex m_req_num_mutex;
    
    bool m_is_gc;
    ac_gc_threshold_ptr m_ptr_gc_threshold;

    std::deque<ac_actor *> m_actor_queue;
    boost::unordered_set<ac_actor *> m_actor_pool;
    
    req_num_t m_top_req_num;
    boost::shared_mutex m_req_callback_mutex;
    boost::unordered_map<req_num_t, nb_response_callback> m_req_callback_map;
    boost::shared_mutex m_bridge_req_mutex;
    boost::unordered_map<bridge_id_t, req_num_t> m_bridge_req_map;

    //for id ac_id map
    boost::shared_mutex m_rc_map_mutex;
    boost::unordered_map<root_committer_id_t, ac_id_t> m_rcid_acid_map;
    
    boost::shared_mutex m_cc_map_mutex;
    boost::unordered_map<center_committer_id_t, ac_id_t> m_ccid_acid_map;

    boost::shared_mutex m_hc_map_mutex;
    boost::unordered_map<host_committer_id_t, ac_id_t> m_hcid_acid_map;

    boost::shared_mutex m_tr_map_mutex;
    boost::unordered_map<transaction_id_t, ac_id_t> m_trid_acid_map;

    boost::shared_mutex m_nb_map_mutex;
    boost::unordered_map<nb_id_t, ac_id_t> m_nbid_acid_map;

    boost::shared_mutex m_exe_map_mutex;
    boost::unordered_map<execution_id_t, ac_id_t> m_exeid_acid_map;

    boost::shared_mutex m_bg_map_mutex;
    boost::unordered_map<bridge_id_t, ac_id_t> m_bgid_acid_map;

    boost::shared_mutex m_bf_map_mutex;
    boost::unordered_map<bridge_factory_id_t, ac_id_t> m_bfid_acid_map;

    boost::shared_mutex m_fd_map_mutex;
    boost::unordered_map<facade_id_t, ac_id_t> m_fdid_acid_map;

    boost::shared_mutex m_cont_map_mutex;
    boost::unordered_map<container_id_t, ac_id_t> m_contid_acid_map;

    boost::shared_mutex m_an_map_mutex;
    boost::unordered_map<anchor_id_t, ac_id_t> m_anid_acid_map;

    boost::shared_mutex m_as_map_mutex;
    boost::unordered_map<access_id_t, ac_id_t> m_asid_acid_map;

    boost::shared_mutex m_st_map_mutex;
    boost::unordered_map<storage_id_t, ac_id_t> m_stid_acid_map;

    boost::shared_mutex m_hc_acs_map_mutex;
    host_committer_actors_map m_hc_acs_map;
};

#endif /* _AC_MANAGER_H_ */
