#ifndef __AC_GLOBAL_DB_H
#define __AC_GLOBAL_DB_H


#include <string>
#include <vector>

#include "ac_message_type.h"
#include "../actor/include/ac_db/ac_id_db.h"
#include "../actor/include/ac_object/data_packer.h"
#include "../actor/include/ac_object/data_unpacker.h"
#include "../actor/include/ac_container/container_data_packer.h"
#include "../actor/include/ac_container/container_data_unpacker.h"
#include "../actor/include/ac_db/ac_user_content_db_impl.h"
#include "stdx_json.h"

inline std::string pack_object(const content& value)
{    
    return data_packer::pack_to_stream(value);
//    std::vector<nb_id_t>::const_iterator const_id;
//    std::vector<std::vector<char> >::const_iterator const_char;
//
//    stdx::json_array* pArrobj = new(std::nothrow) stdx::json_array();
//    assert(pArrobj);
//
//    {
//        stdx::json_object* pObj = new stdx::json_object();
//        pObj->insert("objectid", new stdx::json_string(value.object_id.str()));
//        // pack subobject ids
//        stdx::json_array* psubid = new(std::nothrow) stdx::json_array();
//        assert(psubid);
//        for (const_id = value.id_value.ids.begin(); const_id != value.id_value.ids.end(); ++const_id)
//            psubid->push_back(new stdx::json_string(const_id->str()));
//        pObj->insert("subids", psubid); 
//
//        // pack subobject value
//        stdx::json_array* psubvalue = new(std::nothrow) stdx::json_array();
//        assert(psubvalue);
//        for (const_char = value.id_value.values.begin(); const_char != value.id_value.values.end(); ++const_char)
//        {
//            std::string strchar(const_char->begin(), const_char->end());
//            psubvalue->push_back(new stdx::json_string(strchar));
//        }
//        pObj->insert("subvalues", psubvalue);
//        
//        pArrobj->push_back(pObj);
//    }
//
//    return pArrobj->to_json_string();
}

inline void unpack_object(const std::string& strval, content& value)
{
    assert(!strval.empty());
    data_unpacker::unpack_from_stream(strval, value);
    //assert(!strval.empty());
//    if (!strval.empty())
//    {
//        boost::shared_ptr<stdx::json_array> pArrobj;
//        pArrobj.reset(dynamic_cast<stdx::json_array*>(stdx::json_tokener_parse(strval)));
//        assert(pArrobj);
//
//        //parse the array objects
//        for (int i = 0; i < pArrobj->size(); ++i)
//        {
//            //std::cout << "the arrobj size:" << pArrobj->size() << std::endl;
//
//            // parse the object id
//            //std::cout << pArrobj->at(i) << std::endl;
//            stdx::json_object* pObj = (dynamic_cast<stdx::json_object*>(pArrobj->at(i)));
//            assert(pObj);
//
//            value.object_id.str(pObj->find("objectid")->get_string());
//
//            // parse the sub object ids
//            stdx::json_array* psubid = dynamic_cast<stdx::json_array*>(pObj->find("subids"));
//            assert(psubid);
//            for (int j = 0; j < psubid->size(); ++j)
//            {
//                stdx::json_node* pNode = psubid->at(j);
//                value.id_value.ids.push_back(nb_id_t(pNode->get_string())); 
//            }
//
//            // parse the sub object values
//            stdx::json_array* psubvalue = dynamic_cast<stdx::json_array*>(pObj->find("subvalues"));
//            assert(psubvalue);
//            for (int j = 0; j < psubvalue->size(); ++j)
//            {
//                stdx::json_node* pNode = psubvalue->at(j);
//                std::string strvalue = pNode->get_string();
//                std::vector<char> subvalue(strvalue.begin(), strvalue.end());
//                value.id_value.values.push_back(subvalue); 
//            }
//        }
//    }
}

inline std::string pack_storage(const key_pairs& value)
{
    data_packer packer;
    //content raw_data;

    nb_id_t key_size(NBID_TYPE_OBJECT_INT);
    int id_size = value.key_ids.size();
    key_size.set_value(id_size);
    packer.pack(key_size);
    packer.pack(value.key_ids);

    nb_id_t obj_size(NBID_TYPE_OBJECT_INT);
    id_size = value.obj_ids.size();
    obj_size.set_value(id_size);
    packer.pack(obj_size);
    packer.pack(value.obj_ids);

    //raw_data.id_value = packer.get_pack_data();
    //return packer.pack_to_stream(raw_data);
    return packer.packer_to_stream();

//    std::vector<nb_id_t>::const_iterator const_id;
//
//    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
//    assert(pObj);
//
//    // pack the key ids
//    stdx::json_array* pArrkeyids = new(std::nothrow) stdx::json_array();
//    assert(pArrkeyids);
//    for (const_id = value.key_ids.begin(); const_id != value.key_ids.end(); ++const_id)
//        pArrkeyids->push_back(new stdx::json_string(const_id->str()));
//    pObj->insert("keyids", pArrkeyids);
//
//    // pack the object ids
//    stdx::json_array* pArrobjids = new(std::nothrow) stdx::json_array();
//    assert(pArrobjids);
//    for (const_id = value.obj_ids.begin(); const_id != value.obj_ids.end(); ++const_id)
//        pArrobjids->push_back(new stdx::json_string(const_id->str()));
//    pObj->insert("objids", pArrobjids);
//
//    return pObj->to_json_string();
}

inline void unpack_storage(const std::string& strval, key_pairs& value)
{
    assert(!strval.empty());

    content raw_data;
    data_unpacker::unpack_from_stream(strval, raw_data);
    data_unpacker  unpacker(raw_data);

    int key_size = 0;
    unpacker.unpack_id(0).get_value(key_size);
    for(int i=0; i < key_size; ++i)
    {
        value.key_ids.push_back( unpacker.unpack_id(i + 1) );
    }

    int obj_size = 0;
    unpacker.unpack_id(key_size + 1).get_value(obj_size);
    for(int i=0; i < obj_size; ++i)
    {
        value.obj_ids.push_back(unpacker.unpack_id(i + key_size + 2));
    }
//    value.key_ids.clear();
//    value.obj_ids.clear();
//
//    boost::shared_ptr<stdx::json_object> pObj;
//    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
//    assert(pObj);
//
//    // parse the key ids
//    stdx::json_array* pkeyid = dynamic_cast<stdx::json_array*>(pObj->find("keyids"));
//    assert(pkeyid);
//    for (int i = 0; i < pkeyid->size(); ++i)
//    {
//        stdx::json_node* pNode = pkeyid->at(i);
//        value.key_ids.push_back(nb_id_t(pNode->get_string())); 
//    }
//
//    // parse the obj ids
//    stdx::json_array* pobjid = dynamic_cast<stdx::json_array*>(pObj->find("objids"));
//    assert(pobjid);
//    for (int i = 0; i < pobjid->size(); ++i)
//    {
//        stdx::json_node* pNode = pobjid->at(i);
//        value.obj_ids.push_back(nb_id_t(pNode->get_string())); 
//    }
}

inline std::string pack_container(const con_content& value)
{
    return container_data_packer::pack_to_stream(value);
//    std::vector<container_id_t>::const_iterator const_id;
//    std::vector<std::vector<char> >::const_iterator const_char;
//
//    stdx::json_array* pArrcon = new(std::nothrow) stdx::json_array();
//    assert(pArrcon);
//
//    {
//        stdx::json_object* pObj = new stdx::json_object();
//        pObj->insert("container_id", new stdx::json_string(value.container_id.str()));
//        // pack subcontainer ids
//        stdx::json_array* psubid = new(std::nothrow) stdx::json_array();
//        assert(psubid);
//        for (const_id = value.id_value.ids.begin(); const_id != value.id_value.ids.end(); ++const_id)
//            psubid->push_back(new stdx::json_string(const_id->str()));
//        pObj->insert("sub_containerids", psubid); 
//
//        // pack subcontainer value
//        stdx::json_array* psubvalue = new(std::nothrow) stdx::json_array();
//        assert(psubvalue);
//        for (const_char = value.id_value.values.begin(); const_char != value.id_value.values.end(); ++const_char)
//        {
//            std::string strchar(const_char->begin(), const_char->end());
//            psubvalue->push_back(new stdx::json_string(strchar));
//        }
//        pObj->insert("sub_containervalues", psubvalue);
//        
//        pArrcon->push_back(pObj);
//    }
//    return pArrcon->to_json_string();
}

inline void unpack_container(const std::string& strval, con_content& value)
{
    assert(!strval.empty());
    container_data_unpacker::unpack_from_stream(strval, value);
    //container_data_unpacker unpacker;
    //value = unpacker.unpack_from_stream(strval);

//    boost::shared_ptr<stdx::json_array> pArrcon;
//    pArrcon.reset(dynamic_cast<stdx::json_array*>(stdx::json_tokener_parse(strval)));
//    assert(pArrcon);
//
//    //parse the array containers
//    for (int i = 0; i < pArrcon->size(); ++i)
//    {
//        //std::cout << "the arrobj size:" << pArrcon->size() << std::endl;
//
//        // parse the container id
//        //std::cout << pArrobj->at(i) << std::endl;
//        stdx::json_object* pObj = (dynamic_cast<stdx::json_object*>(pArrcon->at(i)));
//        assert(pObj);
//
//        value.container_id.str(pObj->find("container_id")->get_string());
//
//        // parse the sub container ids
//        stdx::json_array* psubid = dynamic_cast<stdx::json_array*>(pObj->find("sub_containerids"));
//        assert(psubid);
//        for (int j = 0; j < psubid->size(); ++j)
//        {
//            stdx::json_node* pNode = psubid->at(j);
//            value.id_value.ids.push_back(container_id_t(pNode->get_string())); 
//        }
//
//        // parse the sub container values
//        stdx::json_array* psubvalue = dynamic_cast<stdx::json_array*>(pObj->find("sub_containervalues"));
//        assert(psubvalue);
//        for (int j = 0; j < psubvalue->size(); ++j)
//        {
//            stdx::json_node* pNode = psubvalue->at(j);
//            std::string strvalue = pNode->get_string();
//           	std::vector<char> subvalue(strvalue.begin(), strvalue.end());
//            value.id_value.values.push_back(subvalue); 
//        }
//    }
}

inline bool write_root_committer_id(const root_committer_id_t& id)
{
    std::string strkey = "root_committer_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_root_committer_id(root_committer_id_t& id)
{
    std::string strkey = "root_committer_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_center_committer_id(const center_committer_id_t& id)
{
    std::string strkey = "center_committer_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_center_committer_id(center_committer_id_t& id)
{
    std::string strkey = "center_committer_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_host_committer_id(const host_committer_id_t& id)
{
    std::string strkey = "host_committer_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_host_committer_id(host_committer_id_t& id)
{
    std::string strkey = "host_committer_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_storage_id(const storage_id_t& id)
{
    std::string strkey = "storage_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_storage_id(storage_id_t& id)
{
    std::string strkey = "storage_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_container_id(const container_id_t& id)
{
    std::string strkey = "container_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_container_id(container_id_t& id)
{
    std::string strkey = "container_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_bridge_id(const bridge_id_t& id)
{
    std::string strkey = "bridge_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_bridge_id(bridge_id_t& id)
{
    std::string strkey = "bridge_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool write_anchor_id(const anchor_id_t& id)
{
    std::string strkey = "anchor_id";
    
    int ret = ac_id_db::instance().write(strkey, id.str());
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_anchor_id(anchor_id_t& id)
{
    std::string strkey = "anchor_id";
    std::string strval;

    int ret = ac_id_db::instance().read(strkey, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_NOTFOUND))
        return false;
    else
    {
        id.str(strval);
        return true;
    }
}

inline bool read_bridge_id_content(bridge_id_t& id, std::string& strval)
{
    int ret = ac_id_db::instance().read(id.str(), strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        return true;
    else
        return false;
}

inline bool write_bridge_id_content(const bridge_id_t& id, const std::string& strval)
{
    int ret = ac_id_db::instance().write(id.str(), strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_user_content(const std::string& username, std::string& user_content)
{
    int ret = ac_user_content_db_impl::instance().read(username, user_content);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
    {
        return true;
    }    
    else
        return false;
}

inline bool write_user_content(const std::string& username, const std::string& user_content)
{
    int ret = ac_user_content_db_impl::instance().write(username, user_content);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_users_info(std::string& users_info)
{
    int ret = ac_user_content_db_impl::instance().read("nb_register_users_info", users_info);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
    {
        return true;
    }    
    else
        return false;
}

inline bool write_users_info(const std::string& users_info)
{
    int ret = ac_user_content_db_impl::instance().write("nb_register_users_info", users_info);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_bridge_factory_id(const std::string& key, std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().read(key, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        return true;
    else
        return false;
}

inline bool write_bridge_factory_id(const std::string& key, const std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().write(key, strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_bridge_id(const bridge_id_t& key, std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().read(key.str(), strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        return true;
    else
        return false;
}

inline bool write_bridge_id(const bridge_id_t& key, const std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().write(key.str(), strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

inline bool read_semi_info(std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().read("nb_semi_info", strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        return true;
    else
        return false;
}

inline bool write_semi_info(const std::string& strval)
{
    int ret = ac_user_content_db_impl::instance().write("nb_semi_info", strval);
    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
       return true;
    else
       return false; 
}

#endif

// vim:set tabstop=4 shiftwidth=4 expandtab:
