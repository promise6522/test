/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_USER_CONTENT_H_
#define _NB_USER_CONTENT_H_

#include "stdx_json.h"
#include "nb_id.h"
#include "nb_typedef.h"
#include "../actor/include/ac_object/data_packer.h"
#include "../actor/include/ac_object/data_unpacker.h"

enum nb_user_right
{
    nb_none_user = 0,
    nb_user = 1,
    nb_is_user = 2,
    nb_full_user = 3,
    nb_admin_user = 4,
};

struct nb_user_content
{
    std::string name;
    std::string password;
    nb_user_right right;    
    std::string register_time;
    std::string last_logon_time;    
    
    bridge_id_t is_bridge_id;
    bridge_id_t bridge_id;

    access_id_t shared_access_id;    
    nb_id_vector shared_objs;
    std::vector<container_id_t> shared_conts;    
};

inline void pack_user_content(const nb_user_content& user_content, std::string& strval)
{
    /*
	data_packer packer;
	packer.pack(user_content.name);
	packer.pack(user_content.password);
	packer.pack(user_content.right);
	packer.pack(user_content.register_time);
	packer.pack(user_content.last_logon_time);
	packer.pack(user_content.is_bridge_id.str());
	packer.pack(user_content.bridge_id.str());
	strval = packer.packer_to_stream();    
	content raw_data;
	raw_data.id_value = packer.get_pack_data();
	strval = packer.pack_to_stream(raw_data);
    */
    stdx::json_object user_root;
    user_root.insert("name", new stdx::json_string(user_content.name));
    user_root.insert("password", new stdx::json_string(user_content.password));
    user_root.insert("right", new stdx::json_int(user_content.right));
    user_root.insert("register_time", new stdx::json_string(user_content.register_time));
    user_root.insert("last_logon_time", new stdx::json_string(user_content.last_logon_time));
    user_root.insert("is_bridge_id", new stdx::json_string(user_content.is_bridge_id.str()));
    user_root.insert("bridge_id", new stdx::json_string(user_content.bridge_id.str()));
    user_root.insert("shared_access_id", new stdx::json_string(user_content.shared_access_id.str()));

    stdx::json_array* pObjArray = new stdx::json_array();
    nb_id_vector_const_it it = user_content.shared_objs.begin();
    while(it != user_content.shared_objs.end())
    {
        pObjArray->push_back(new stdx::json_string(it->str()));
        ++it;
    }
    user_root.insert("shared_objs", pObjArray);

    stdx::json_array* pContArray = new stdx::json_array();
    std::vector<container_id_t>::const_iterator iter = user_content.shared_conts.begin();
    while(iter != user_content.shared_conts.end())
    {
        pContArray->push_back(new stdx::json_string(iter->str()));
        ++iter;
    }
    user_root.insert("shared_conts", pContArray);
    
    strval = user_root.to_json_string();
}

inline void unpack_user_content(const std::string strval, nb_user_content& user_content)
{
    assert(!strval.empty());

    /*
	content raw_data;
	data_unpacker::unpack_from_stream(strval, raw_data);
	data_unpacker unpacker(raw_data);
	
	user_content.name = unpacker.unpack_string(0);
	user_content.password = unpacker.unpack_string(1);
	user_content.right = static_cast<nb_user_right>(unpacker.unpack_int(2));
	user_content.register_time = unpacker.unpack_string(3);
	user_content.last_logon_time = unpacker.unpack_string(4);
	user_content.is_bridge_id.str(unpacker.unpack_string(5));
	user_content.bridge_id.str(unpacker.unpack_string(6));
    */
    
    boost::scoped_ptr<stdx::json_object> user_root(dynamic_cast<stdx::json_object*>
                                                   (stdx::json_tokener_parse(strval)));
    assert(user_root);    
    user_content.name = user_root->find("name")->get_string();
    user_content.password = user_root->find("password")->get_string();
    user_content.right = static_cast<nb_user_right>(user_root->find("right")->get_int());
    user_content.register_time = user_root->find("register_time")->get_string();
    user_content.last_logon_time = user_root->find("last_logon_time")->get_string();
    user_content.is_bridge_id.str(user_root->find("is_bridge_id")->get_string());
    user_content.bridge_id.str(user_root->find("bridge_id")->get_string());
    user_content.shared_access_id.str(user_root->find("shared_access_id")->get_string());

    stdx::json_array* pObjArray = dynamic_cast<stdx::json_array*>(user_root->find("shared_objs"));
    assert(pObjArray);
    for(int i = 0; i < pObjArray->size(); ++i)
    {
        user_content.shared_objs.push_back(nb_id_t(pObjArray->at(i)->get_string()));
    }
    
    stdx::json_array* pContArray = dynamic_cast<stdx::json_array*>(user_root->find("shared_conts"));
    assert(pContArray);
    for(int i = 0; i < pContArray->size(); ++i)
    {
        user_content.shared_conts.push_back(container_id_t(pContArray->at(i)->get_string()));
    }
}

struct nb_users_info
{
    std::vector<std::string> user_names;
};

inline void pack_users_info(const nb_users_info& users_info, std::string& strval)
{
    stdx::json_object users_root;
    stdx::json_array* pUserArray = new stdx::json_array();
    std::vector<std::string>::const_iterator it = users_info.user_names.begin();
    while(it != users_info.user_names.end())
    {
        pUserArray->push_back(new stdx::json_string(*it));
        ++it;
    }
    users_root.insert("users", pUserArray);
    strval = users_root.to_json_string();
}

inline void unpack_users_info(const std::string strval, nb_users_info& users_info)
{
    if(strval.empty())
        return;    
    
    boost::scoped_ptr<stdx::json_object> users_root(dynamic_cast<stdx::json_object*>
                                                    (stdx::json_tokener_parse(strval)));

    stdx::json_array* pArray = dynamic_cast<stdx::json_array*>(users_root->find("users"));
    assert(pArray);
    for(int i = 0; i < pArray->size(); ++i)
    {
        users_info.user_names.push_back(pArray->at(i)->get_string());
    }
}

#endif /* _NB_USER_CONTENT_H_ */
