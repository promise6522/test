/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_FRAMEWORK_H_
#define _AC_FRAMEWORK_H_

#include <vector>

#include "ac_manager.h"
#include "ac_executor.h"
#include "ac_statistics.h"
#include "nb_configuration.h"

class ac_framework
{    
public:
    ac_framework(std::size_t executor_pool_size, bool is_statistics = false,
                 std::size_t statistics_interval = Default_Statistics_Interval)
        : m_executor_pool_size(executor_pool_size),
          m_is_statistics(is_statistics),
          m_statistics_interval(statistics_interval)
    {
    }

    void init_framework(bool is_gc = Default_Gabage_Collection_Option,
                        std::size_t mem_size = Default_Gabage_Collection_Mem_Size,
                        std::size_t mem_rate = Default_Gabage_Collection_Mem_Rate)
    {
        ac_manager::instance().init_manager(is_gc, mem_size, mem_rate);
    }
    
    void run()
    {
        for (std::size_t i = 0; i < m_executor_pool_size; ++i)
        {
            ac_executor_ptr ptr_executor(new ac_executor());
            m_executors.push_back(ptr_executor);
            boost::shared_ptr<boost::thread> thread(new boost::thread(boost::ref(*ptr_executor.get())));
            m_threads.push_back(thread);
        }

        if(m_is_statistics)
        {
            m_statistics.reset(new ac_statistics(m_statistics_interval));
            boost::shared_ptr<boost::thread> thread(new boost::thread(boost::ref(*m_statistics.get())));
            m_threads.push_back(thread);
        }
    }

    void stop()
    {
	while (!ac_manager::instance().is_dispatch_queue_empty())
	{
	    usleep(10);        
	}

        for (std::size_t i = 0; i < m_executors.size(); ++i)
        {
            m_executors[i]->stop();            
        }

        if(m_is_statistics)
        {
            m_statistics->stop();
        }

        for (std::size_t i = 0; i < m_threads.size(); ++i)
        {            
            m_threads[i]->join();
        } 

        ac_manager::instance().dest_manager();
    }

private:
    std::size_t m_executor_pool_size;
    std::vector< boost::shared_ptr<boost::thread> > m_threads;
    std::vector< ac_executor_ptr > m_executors;
    ac_statistics_ptr m_statistics;
    bool m_is_statistics;
    std::size_t m_statistics_interval;
};


#endif /* _AC_FRAMEWORK_H_ */
