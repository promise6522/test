/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_STATUS_H_
#define _AC_STATUS_H_

#include <stdint.h>
#include <iostream>

const uint32_t ac_status_waiting = 0;         //the actor is waiting for dispatch.
const uint32_t ac_status_in_queue = 1;       //the actor is in the dispatch queue.
const uint32_t ac_status_executing = 2;      //the actor is being executed.
const uint32_t ac_status_exiting = 3;        //the actor is waiting for destorying.

typedef uint32_t ac_actor_status;

/*--------------------------------------------------------------------------------------
              ac_status_waiting ← ← ← ← ← ← ← ← ← ←  
                       ↓                            ↑
                       ↓                            ↑
                       ↓                            ↑
              ac_status_is_in_queue                 ↑
                       ↓                            ↑
                       ↓                            ↑
                       ↓                            ↑
              ac_status_executing  → → → → → → → → → 
                       ↓
                       ↓
                       ↓
             ac_status_is_exiting
 ---------------------------------------------------------------------------------------*/

#define AC_STATUS_SET_STATUS(ptr, st)                 __sync_bool_compare_and_swap(ptr, *ptr, st)
#define AC_STATUS_COMPARE_SWAP(ptr, old_val, new_val) __sync_bool_compare_and_swap(ptr, old, new_val)

#define AC_STATUS_WAITING_TO_QUEUE(ptr)              __sync_bool_compare_and_swap(ptr, ac_status_waiting, ac_status_in_queue)
#define AC_STATUS_QUEUE_TO_EXECUTING(ptr)            __sync_bool_compare_and_swap(ptr, ac_status_in_queue, ac_status_executing)
#define AC_STATUS_EXECUTING_TO_WAITING(ptr)          __sync_bool_compare_and_swap(ptr, ac_status_executing, ac_status_waiting)
#define AC_STATUS_EXECUTING_TO_EXITING(ptr)          __sync_bool_compare_and_swap(ptr, ac_status_executing, ac_status_exiting)

enum init_status
{
    ac_init_wait,
    ac_init_success,
    ac_init_fail
};

/*
inline void ac_status_print(ac_actor_status status)
{
    std::cout<<"Status Value = "<<std::setw(4)<<std::setfill('0')<<std::hex<<status<<std::endl
		<<"Starting("<<AC_STATUS_IS_STARTING(&status)<<")"
		<<", Initializing("<<AC_STATUS_IS_INITIALIZING(&status)<<")"
		<<", Initialized("<<AC_STATUS_IS_INITIALIZED(&status)<<")"
		<<", Exiting("<<AC_STATUS_IS_EXITING(&status)<<")"
		<<", Executing("<<AC_STATUS_IS_EXECUTING(&status)<<")"<<std::endl; 
	      
    LOG_DEBUG( "status Value = " << std::setw(4) << std::setfill('0') << std::hex << status << std::endl 
               <<"Initialized("<<AC_STATUS_IS_INITIALIZED(&status)<<")"
               <<", In_Queue("<<AC_STATUS_IS_IN_QUEUE(&status)<<")"
               <<", Exiting("<<AC_STATUS_IS_EXITING(&status)<<")"
               <<", Executing("<<AC_STATUS_IS_EXECUTING(&status)<<")");
}

void test()
{
    ac_actor_status status;

    AC_STATUS_SET_STARING(&status);
    ac_status_print(status);

    AC_STATUS_SET_INITIALIZING(&status);
    ac_status_print(status);

    AC_STATUS_SET_EXECUTING_FLAG(&status);
    ac_status_print(status);

    AC_STATUS_UNSET_EXECUTING_FLAG(&status);
    ac_status_print(status);

    AC_STATUS_SET_INITIALIZED(&status);
    ac_status_print(status);

    AC_STATUS_SET_EXECUTING_FLAG(&status);
    ac_status_print(status);

    AC_STATUS_UNSET_EXECUTING_FLAG(&status);
    ac_status_print(status);

    AC_STATUS_SET_EXITING(&status);
    ac_status_print(status);
}
*/

#endif /* _AC_STATUS_H_ */
