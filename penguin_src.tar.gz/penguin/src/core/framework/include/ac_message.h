/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_MESSAGE_H_
#define _AC_MESSAGE_H_

#include "ac_global.h"
#include "ac_actor_type.h"

struct ac_message_t
{
    ac_id_t ac_id;
    req_num_t req_num;
	ac_method_t type;
	void * data;
    bool is_respond;    
};

#ifdef __GXX_EXPERIMENTAL_CXX0X__
//plan to using unique_ptr and move semantic for c++0x strandard
typedef std::unique_ptr<ac_message_t> ac_message_ptr;
#else
typedef std::tr1::shared_ptr<ac_message_t> ac_message_ptr;
#endif

inline void init_message(ac_message_t &message)
{
    message.ac_id = 0;
    message.req_num = 0;
	message.type = e_ac_actor_exception;
	message.data = NULL;
    message.is_respond = false;    
}

inline void pack_message(ac_message_t &message, ac_id_t ac_id, req_num_t req_num, ac_method_t type, void *pData, bool is_respond)
{
    message.ac_id = ac_id;
    message.req_num = req_num;
	message.type = type;
	message.data = pData;
    message.is_respond = is_respond;
}

#endif /* _AC_MESSAGE_H_ */
