/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_GLOBAL_H_
#define _AC_GLOBAL_H_

#include <stdint.h>

// Boost header files
#include <boost/tr1/memory.hpp>
#include <boost/thread/once.hpp>

#include "stdx_log.h"

#include "nb_id.h"
#include "ac_status.h"
#include "ac_req_num.h"

#if defined(__amd64__) || defined(__amd64) || defined(__x86_64__) || defined(__x86_64)
#define _NB_64_PLATFORM_
#else
#define _NB_32_PLATFORM_
#endif

struct call_id_t
{
    ac_id_t      ac_id;
    req_num_t    req_num;

    friend bool operator<(const call_id_t& v1, const call_id_t& v2)
    {
        return (v1.ac_id < v2.ac_id)
            || ((v1.ac_id == v2.ac_id) && (v1.req_num < v2.req_num));
    }

    friend bool operator==(const call_id_t& v1, const call_id_t& v2)
    {
        return (v1.ac_id == v2.ac_id) && (v1.req_num == v2.req_num);
    }
};

extern boost::once_flag g_boost_once;

#endif /* _AC_GLOBAL_H_ */
