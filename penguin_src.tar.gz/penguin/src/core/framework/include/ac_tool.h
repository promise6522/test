/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_TOOL_H_
#define _AC_TOOL_H_

#include <string>

inline std::string enable_color(const std::string& clr)
{
	return "\033[01;" + clr + "m";
}

inline std::string disable_color()
{
	return "\033[0m";
}

template <typename _CountofType, size_t _SizeOfArray>
char (*__countof_helper(_CountofType (&_Array)[_SizeOfArray]))[_SizeOfArray];
#define _countof(_Array) (sizeof(*__countof_helper(_Array)) + 0)

#endif /* _AC_TOOL_H_ */
