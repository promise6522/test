/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _NB_USER_MANAGER_H_
#define _NB_USER_MANAGER_H_

#include <boost/thread/shared_mutex.hpp>

#include "nb_id.h"
#include "nb_user_content.h"

class nb_user_manager
{
private:
	nb_user_manager(void)
    {
    }    
	~nb_user_manager(void)
    {
    }
    nb_user_manager(const nb_user_manager&);
    nb_user_manager& operator=(const nb_user_manager&);

public:
	static nb_user_manager& instance()
    {
        static nb_user_manager manager;
        return manager;        
    }

    bool get_all_users(std::vector<std::string>& users);
    void create_user(const std::string user_name, const std::string password);

    bool get_bridge_by_user(const std::string user_name, bool is_mode, bridge_id_t& bridge_id);
    
    bool get_access_by_user(const std::string user_name, access_id_t& access_id);
    bool set_access_by_user(const std::string user_name, const access_id_t& access_id);
    
    bool get_shared_access_by_user(const std::string user_name, access_id_t& access_id);
    bool set_shared_access_by_user(const std::string user_name, const access_id_t& access_id);
    
    bool get_shared_user_access_map(std::map<std::string, access_id_t>& user_access_map);
    void get_user_shared_objs(const std::string user_name, std::vector<nb_id_t>& objs,
                              std::vector<container_id_t>& conts);
    void get_all_shared_objs(std::vector<nb_id_t>& objs, std::vector<container_id_t>& conts);

private:
    void dump_user_info(const nb_users_info& users_info);

private:
    boost::shared_mutex m_mutex;
};

const std::string default_user_pwd_separator(";");
const char default_is_mode_prefix = '$';

#endif /* _NB_USER_MANAGER_H_ */
