/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_ACTOR_H_
#define _AC_ACTOR_H_

#include <memory>
#include <queue>
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>

#include <boost/lexical_cast.hpp>
#include <boost/thread/shared_mutex.hpp>

#include "ac_global.h"
#include "ac_actor_type.h"
#include "ac_message.h"
#include "ac_manager.h"
#include "ac_helper.h"
#include "ac_tool.h"
#include "ac_time_observer.h"

extern uint64_t g_message_count;

class ac_actor
{
public:
    virtual ~ac_actor()
    {
    }

protected:
    ac_actor(ac_actor_t ac_type)
        : m_ac_id(reinterpret_cast<ac_id_t>(this)), m_ac_type(ac_type), 
          m_actor_name("ac_actor"), m_status(ac_status_waiting), m_init_status(ac_init_wait)
    {        
    }
    
private:    
    //disable copy constructor and operator=
    ac_actor(const ac_actor&);
    ac_actor& operator=(const ac_actor&);

public:
    //-------------- for queue operation --------------------------
    void protect_queue()
    {
        // get upgradable access
        boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);
        // get exclusive access
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    }

    void enqueue(ac_message_t* pMsg)
    {
        //TBD: Reduce the change for sending the message to exiting actor
        if(m_status == ac_status_exiting)
        {
            //Need to dealloc the memory
            ac_memory_alloctor<ac_message_t>::instance().deallocate(pMsg);
            return;
        }
        
        // get upgradable access
        boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);
        // get exclusive access
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);

        //double check for multithread
        if(m_status == ac_status_exiting)
        {
            //Need to dealloc the memory
            ac_memory_alloctor<ac_message_t>::instance().deallocate(pMsg);
            return;
        }
      
        if(pMsg->is_respond && pMsg->req_num.get_init_flag())
        {
            //push init message front
            m_asyn_message_queue.push_front(pMsg);
        }
        else
        {
            //push other message back
            m_asyn_message_queue.push_back(pMsg);
        }
    }

    ac_message_t* dequeue()
    {
        // get upgradable access
        boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);

        // get exclusive access
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);

        if(!m_asyn_message_queue.empty())
        {
            ac_message_t* pMsg = m_asyn_message_queue.front();
            m_asyn_message_queue.pop_front();
            return pMsg;
        }
        return NULL;
    }

    void clear_queue()
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_asyn_message_queue.clear();
    }

    size_t queue_size()
    {
        // get shared access
        boost::shared_lock<boost::shared_mutex> lock(m_mutex);

        return m_asyn_message_queue.size();
    }

    bool queue_empty()
    {
        // get shared access
        boost::shared_lock<boost::shared_mutex> lock(m_mutex);

        return m_asyn_message_queue.empty();
    }

    void re_dispatch_if_need()
    {
         AC_STATUS_EXECUTING_TO_WAITING(&m_status);
         boost::shared_lock<boost::shared_mutex> lock(m_mutex);
         if(!m_asyn_message_queue.empty())
         {
             ac_manager::instance().add_actor_to_dispatch_queue(this); 
         }
    }

    /*
    void dispatch_message(ac_message_t* pMsg)
    {
        // get upgradable access        
        boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);
        // get exclusive access        
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock); 
        if(pMsg->is_respond && pMsg->req_num.get_init_flag())        
        {   
            //push init message front 
            m_asyn_message_queue.push_front(pMsg);        
        }        
        else        
        {
            //push other message back            
            m_asyn_message_queue.push_back(pMsg);
        }
        
        ac_manager::instance().add_actor_to_dispatch_queue(this);
    }
    */

    bool has_init_message()
    {
        // get shared access
        boost::shared_lock<boost::shared_mutex> lock(m_mutex);
        
        if(m_asyn_message_queue.empty())
            return false;
        
        return m_asyn_message_queue.front()->is_respond
            && m_asyn_message_queue.front()->req_num.get_init_flag();
    }

    void message_loop()
    {          
        //handle message if queue is not empty
        while(!queue_empty())
        {
            //if current status is initialized
            if (m_init_status != ac_init_wait)
            {
                ac_message_t* pMsg = dequeue();
                if(pMsg != NULL)
                {
					bool ret = false;
					if(ac_time_observer::Instance()->get_run_permission())
					{
                    	message_time_enter(*pMsg);
                    	ret = message_handle(*pMsg);
                    	message_time_leave(*pMsg);
					}
					else
					{
                    	ret = message_handle(*pMsg);
					}
                    if(!ret)
                        LOG_ERROR("Handle message error");
                    ac_memory_alloctor<ac_message_t>::instance().deallocate(pMsg);
                }
            }
            else //if not, just handle init message only(always in head)
            {
                if(has_init_message())
                {
                    ac_message_t* pMsg = dequeue();
                    if(pMsg != NULL)
                    {
						bool ret = false;
                        //message_time_enter(*pMsg);
                        //bool ret = message_handle(*pMsg);
                        //message_time_leave(*pMsg);
						if(ac_time_observer::Instance()->get_run_permission())
						{
                    		message_time_enter(*pMsg);
                    		ret = message_handle(*pMsg);
                    		message_time_leave(*pMsg);
						}
						else
						{
                    		ret = message_handle(*pMsg);
						}
                        if(!ret)
                            LOG_ERROR("Handle message error");
                        ac_memory_alloctor<ac_message_t>::instance().deallocate(pMsg);
                    }
                }
                else
                {
                    return;
                }
            }
        }
    }

    virtual nb_id_alias get_nb_id_alias()
    {
        return nb_id_alias();        
    }
    
    virtual bool message_handle(const ac_message_t& message)
    {
        g_message_count++;

        if(message.ac_id != g_ac_framework_acid)
        {
            LOG_DEBUG(format_actor_str(message.ac_id)<<"\n=>"<<format_actor_str(m_ac_id)
                  <<" : "<<ac_method_string[message.type]);
        }
        return true;
    }

    void message_time_handle(const ac_message_t& message)
    {
        message_t msg;
        if (message.type % 2)
            msg.m_ac_id = m_ac_id;
        else
            msg.m_ac_id = message.ac_id;
        msg.m_req_num = message.req_num;
        msg.m_obj_id = get_nb_id_alias();
        msg.m_type = message.type;
        msg.m_name = ac_method_string[message.type];
        ac_time_observer::Instance()->message_handle(msg);
    }

    void message_time_enter(const ac_message_t& message)
    {
        message_t msg;
        msg.m_ac_id = message.ac_id;
        msg.m_req_num = message.req_num;
        msg.m_obj_id = get_nb_id_alias();
        msg.m_type = message.type;
        msg.m_name = ac_method_string[message.type];
        ac_time_observer::Instance()->enter(msg);
    }

    void message_time_leave(const ac_message_t& message)
    {
        message_t msg;
        msg.m_ac_id = message.ac_id;
        msg.m_req_num = message.req_num;
        msg.m_obj_id = get_nb_id_alias();
        msg.m_type = message.type;
        msg.m_name = ac_method_string[message.type];
        ac_time_observer::Instance()->leave(msg);
    }

    virtual bool exception_handle(req_num_t req_num, const std::string& str)
    {
        LOG_DEBUG(format_actor_str( m_ac_id ) << "get exception in req_num_t (" << req_num << ")" << str );
        return true;
    }

    bool initialization()
    {
        return true;
    }

    virtual bool destruction()
    {
        return true;
    } 

    ac_id_t get_actor_id()
    {
        return m_ac_id;
    }

    ac_actor_t get_actor_type()
    {
        return m_ac_type;
    }
    
    std::string get_actor_name()
    {
        return m_actor_name;
    }

    boost::recursive_mutex& get_sync_mutex()
    {
        return m_sync_mutex;
    }

    inline void set_status(ac_actor_status st)
    {
        AC_STATUS_SET_STATUS(&m_status, st);
    }

    ac_actor_status& get_status()
    {
        return m_status;
    }

    inline bool exit(call_id_t call_id)
    {
        return AC_STATUS_EXECUTING_TO_EXITING(&m_status);
    }

    inline void set_initializing_status()
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_init_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_init_status = ac_init_wait;
    }

    inline void set_initialized_status()
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_init_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_init_status = ac_init_success;
    }

    inline void set_initialized_fail_status()
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_init_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_init_status = ac_init_fail;
    }

    inline bool is_initialized()
    {
        boost::shared_lock<boost::shared_mutex> lock(m_init_mutex);
        return m_init_status != ac_init_wait;
    }
    
protected:
    std::string format_actor_str(ac_id_t ac_id)
    {
        std::stringstream ac_str;
        if(ac_id == g_ac_framework_acid)
        {
            ac_str<<enable_color("31")<<std::setw(4)<<std::setfill('0')<<std::hex
                  <<"ac_framework"<<disable_color();
        }
        else
        {
            ac_actor *pActor = ac_manager::instance().acid_to_actor(ac_id);
            std::string actor_name;
            std::string id_str;            
	    
            if(ac_manager::instance().is_actor_exist(pActor))
            {
                actor_name = pActor->get_actor_name();
                id_str = pActor->get_nb_id_alias().str();
                
            }
            else
            {
                actor_name = "Invalid Actor";
                id_str = "xxxxxxxxxxxxxxxx";                
            }
            ac_str<<enable_color("31")<<std::setw(4)<<std::setfill('0')<<std::hex
                  <<actor_name<<"["<<id_str<<"]"<<disable_color();
        }
        
        return ac_str.str();
    }
    
protected:
    //actor common info
    ac_id_t m_ac_id;
    ac_actor_t m_ac_type;
    std::string m_actor_name;

    //mutex for queue
    boost::shared_mutex m_mutex;
    std::list<ac_message_t *> m_asyn_message_queue;

    //mutex for sync call
    boost::recursive_mutex m_sync_mutex;

    //actor status(waiting, queue, executing, existing)
    ac_actor_status m_status;

    //mutex for init flag
    boost::shared_mutex m_init_mutex;
    init_status m_init_status;
};  

#endif /* _AC_ACTOR_H_ */
