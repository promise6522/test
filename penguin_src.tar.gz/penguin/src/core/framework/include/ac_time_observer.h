#ifndef _ac_time_observer_H_
#define _ac_time_observer_H_

#include <string>
#include <stack>
#include <vector>
#include <map>

#include "ac_global.h"
#include "ac_actor_type.h"

struct message_t
{
    ac_id_t         m_ac_id;
    nb_id_alias     m_obj_id;
    req_num_t       m_req_num;
    int             m_type;
    std::string     m_name;

    message_t& operator=(const message_t& s)
    {
        m_ac_id = s.m_ac_id;
        m_obj_id = s.m_obj_id;
        m_req_num = s.m_req_num;
        m_type = s.m_type;
        m_name = s.m_name;
        return *this;
    }

    bool operator==(const message_t& s)
    {
        return m_ac_id == s.m_ac_id
                && m_obj_id == s.m_obj_id
                && m_req_num == s.m_req_num
                && m_type == s.m_type
                && m_name == s.m_name;
    }
};

struct actor_run_time_t
{
    long        m_start;
    long        m_end;
    message_t   m_msg;

    actor_run_time_t(message_t& m) : m_start(0), m_end(0), m_msg(m) { }

    actor_run_time_t& operator=(const actor_run_time_t& s)
    {
        m_start = s.m_start;
        m_end = s.m_end;
        m_msg = s.m_msg;
        return *this;
    }
};

struct measure_t
{
    long    m_elapse;
    long    m_total;
    int     m_count;

    measure_t() : m_elapse(0), m_total(0), m_count(0) { }
};

struct tracker_t
{
    std::vector<actor_run_time_t>           m_time;
    std::multimap<message_t, measure_t>     m_result;
};

class ac_time_observer
{
private:
//    boost::mutex                        m_mtx;
    std::map<std::string, tracker_t>    m_scope;
    std::string                         m_blanks;
    long                                m_interval;
    int                                 m_print_type;
	bool 	                            m_run;

    bool is_match(const message_t& s1, const message_t& s2);
    bool is_message_match(const message_t& s1, const message_t& s2);
    bool is_message_type_match(const message_t& s1, const message_t& s2);

    std::map<std::string, tracker_t>::iterator get_tracker_pos();
    bool update_result(std::map<std::string, tracker_t>::iterator it_scope, const message_t& msg, long run_time);

    bool is_print(std::map<message_t, measure_t>::iterator it);
    std::string print(int length, std::string t);
    std::string print(int length, long l);

    long get_current_time();

protected:
    static ac_time_observer*            m_instance;

    ac_time_observer();
    virtual ~ac_time_observer();

public:
    static ac_time_observer* Instance()
    {
        if (!m_instance)
            m_instance = new ac_time_observer();
        return m_instance;
    };

    void set_interval(long itv);
    void set_print_type(int type);

    void message_handle(message_t& msg);
    void enter(message_t& msg);
    void leave(message_t& msg);
	bool time_observer_init(bool run);
	bool get_run_permission();

    void print();
    std::string print_current_time();

    friend bool operator<(const message_t& s1, const message_t& s2);
};

#endif // _ac_time_observer_H_
