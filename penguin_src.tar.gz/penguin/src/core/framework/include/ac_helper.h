/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_HELPER_H_
#define _AC_HELPER_H_

#include "ac_actor_type.h"
#include "ac_message_type.h"
#include "ac_memory_alloctor.h"

class ac_helper
{
public:
    virtual ~ac_helper()
    {
    }

    bool ac_actor_exception_respond(call_id_t call_id, std::string& exp_str)
    {
        std::string* pData = ac_memory_alloctor<std::string>::instance().allocate();

        *pData = exp_str;
        return ac_manager::instance().send_asyn_message(call_id.ac_id, m_ac_id, call_id.req_num,
                                                        e_ac_actor_exception, pData);
    }

    template <typename Tid>
    bool ac_actor_send_exit(const Tid& id)
    {
        ac_id_t ac_id;
        if(!ac_manager::instance().get_ac_id(id, ac_id))
        {
            return false;
        }
        
        req_num_t req_num(true);
        return ac_manager::instance().send_asyn_message(ac_id, m_ac_id, req_num, e_ac_actor_exit, NULL);
    }

protected:
    ac_helper(ac_id_t actor_id) : m_ac_id(actor_id)
    {
        //TBD
    }

protected:
    ac_id_t m_ac_id;

private:    
    //disable copy constructor and operator=
    ac_helper(const ac_helper&);
    ac_helper& operator=(const ac_helper&);
};

typedef std::tr1::shared_ptr<ac_helper>  ac_helper_ptr;

#endif /* _AC_HELPER_H_ */
