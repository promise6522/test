/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _AC_GC_THRESHOLD_H_
#define _AC_GC_THRESHOLD_H_

#ifdef _LINUX
    #include <proc/readproc.h>
    #include <proc/sysinfo.h>
    #include <proc/version.h>
#endif

// Boost header files
#include <boost/tr1/memory.hpp>

class ac_gc_threshold
{
public:
	ac_gc_threshold(std::size_t gc_size, std::size_t gc_rate)
        : m_gc_size(gc_size), m_gc_rate(gc_rate)
    {
    }
    
	~ac_gc_threshold(void)
    {
    }

    void set_mem_size_threshold(std::size_t mem_size)
    {
        m_gc_size = mem_size;        
    }

    void set_mem_rate_threshold(std::size_t mem_rate)
    {
        m_gc_rate = mem_rate;
    }

    bool is_exceed_threshold()
    {
        return is_exceed_mem_size_threshold() || is_exceed_mem_rate_threshold();        
    }

    bool is_exceed_mem_size_threshold()
    {
        std::size_t mem_size = get_mem_size();        
        if( mem_size > m_gc_size )
        {
            LOG_INFO("Memory Size ("<<mem_size<<"M) exceed the threshold("<<m_gc_size<<"M)");
            return true;            
        }
        return false;
    }

    bool is_exceed_mem_rate_threshold()
    {
        std::size_t mem_rate =  get_mem_rate();        
        if( mem_rate < m_gc_rate )
        {
            LOG_INFO("Memory Rate ("<<mem_rate<<"%) exceed the threshold("<<m_gc_rate<<"%)");
            return true;
        }
        return false;        
    }

    std::size_t get_mem_size()
    {
#ifdef _LINUX
        proc_t proc_info;
        get_proc_stats(getpid(), &proc_info);
        return (proc_info.size * 4) / 1024;
#else
        return 0;        
#endif        
    }

    std::size_t get_mem_rate()
    {
#ifdef _LINUX
        meminfo();
        return kb_main_free * 100 / kb_main_total;
#else
        return 100;
#endif
    }    

private:
    std::size_t m_gc_size;
    std::size_t m_gc_rate;    
};

typedef std::tr1::shared_ptr<ac_gc_threshold> ac_gc_threshold_ptr;
    
#endif /* _AC_MANAGER_H_ */
