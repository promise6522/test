/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#include "nb_user_manager.h"
#include "ac_id_dispenser.h"
#include "ac_bridge/ac_bridge_impl.h"
#include "ac_object/obj_impl_string.h"
#include "ac_global_db.h"

bool nb_user_manager::get_bridge_by_user(const std::string user_name, bool is_mode, bridge_id_t& bridge_id)
{
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
        
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    if(is_mode)
    {
        bridge_id = user_content.is_bridge_id;
    }
    else
    {
        bridge_id = user_content.bridge_id;
    }
    return true;        
}

bool nb_user_manager::get_access_by_user(const std::string user_name, access_id_t& access_id)
{
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
        
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);

    //get login bridge id
    if(!read_bridge_id_content(user_content.bridge_id, strval))
    {
        LOG_ERROR("read_bridge_id_content failed.");
        return false;
    }

    bridge_content bcont;        
    ac_bridge_impl::unpack(strval, bcont);        
    access_id = bcont.access_id;

    return true;        
}

bool nb_user_manager::set_access_by_user(const std::string user_name, const access_id_t& access_id)
{
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info from database failed.");
        return false;            
    }
        
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);

    //get login bridge conent
    if(!read_bridge_id_content(user_content.bridge_id, strval))
    {
        LOG_ERROR("read_bridge_id_content failed.");
        return false;
    }

    bridge_content bcont;        
    ac_bridge_impl::unpack(strval, bcont);
    bcont.access_id = access_id;
    ac_bridge_impl::pack(bcont, strval);

    //set new login bridge conent
    if(!write_bridge_id_content(user_content.bridge_id, strval))
    {
        LOG_ERROR("write_bridge_id_content failed.");
        return false;
    }

    return true;        
}

bool nb_user_manager::get_shared_access_by_user(const std::string user_name, access_id_t& access_id)
{
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
        
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    access_id = user_content.shared_access_id;
    return true;        
}

bool nb_user_manager::set_shared_access_by_user(const std::string user_name, const access_id_t& access_id)
{
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info from database failed.");
        return false;            
    }
        
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    user_content.shared_access_id = access_id;
    pack_user_content(user_content, strval);
    
    //set new login bridge conent
    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("write_user_content failed.");
        return false;
    }

    return true;        
}

void nb_user_manager::get_user_shared_objs(const std::string user_name,
                                           std::vector<nb_id_t>& objs,
                                           std::vector<container_id_t>& conts)
{   
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return;        
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);

    for(nb_id_vector_it it = user_content.shared_objs.begin(); it != user_content.shared_objs.end(); ++it)
    {
        objs.push_back(*it);        
    }

    for(std::vector<container_id_t>::iterator it = user_content.shared_conts.begin();
        it != user_content.shared_conts.end(); ++it)
    {
        conts.push_back(*it);        
    }    
}

void nb_user_manager::get_all_shared_objs(std::vector<nb_id_t>& objs, std::vector<container_id_t>& conts)
{
    objs.clear();
    conts.clear();

    boost::shared_lock<boost::shared_mutex> lock(m_mutex);

    std::string strval; 
    //read users info in database
    if(!read_users_info(strval))
    {
        LOG_ERROR("Read users info to database failed.");
    }

    nb_users_info users_info;    
    unpack_users_info(strval, users_info);    
    
    for(std::vector<std::string>::iterator it = users_info.user_names.begin();
        it != users_info.user_names.end(); ++it)
    {
        get_user_shared_objs(*it, objs, conts);
    }
}

bool nb_user_manager::get_shared_user_access_map(std::map<std::string, access_id_t>& user_access_map)
{
    boost::shared_lock<boost::shared_mutex> lock(m_mutex);
    
    std::string strval;        
    //read users info in database
    if(!read_users_info(strval))
    {
        LOG_ERROR("Read users info to database failed.");
        return false; 
    }

    nb_users_info users_info;    
    unpack_users_info(strval, users_info);

    for(std::vector<std::string>::iterator it = users_info.user_names.begin();
        it != users_info.user_names.end(); ++it)
    {
        access_id_t access_id;        
        get_shared_access_by_user(*it, access_id);
        if(access_id == access_id_t())
        {
            nb_id_t none_id(NBID_TYPE_OBJECT_NONE);
            none_id.to_access_id(access_id);
        }
        user_access_map.insert(std::make_pair(*it, access_id));
    }
    return true;    
}

void nb_user_manager::create_user(const std::string user_name, const std::string password)
{
    // get upgradable access
    boost::upgrade_lock<boost::shared_mutex> lock(m_mutex);
    // get exclusive access_id
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        
    nb_user_content user_content =
    {
        user_name, password, nb_full_user, "", "", bridge_id_t(), bridge_id_t(),
    };
        
    //try to create new user info
    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>
        (ac_manager::instance().acid_to_actor(g_ac_id_dispenser_acid));
    if(!pActor)
    {
        return;
    }

    host_committer_id_t hc_id;
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        pActor->request_host_committer_id(hc_id);
    } 
        
    request_nb_id_info str_info;
    str_info.committer_id = hc_id;
    str_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(user_name, nb_id_t(), str_info.raw_data);
    nb_id_t user_name_id;
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        pActor->request_nb_id(str_info, user_name_id);
    }
    
    str_info.raw_data.object_id = user_name_id;
    ac_object_db_impl::instance().write(user_name_id.str(), pack_object(str_info.raw_data)); 

    bridge_content is_bcont = {default_transit_access_id, bridge_factory_id_t(), user_name_id};
    bridge_content bcont = {access_id_t(), bridge_factory_id_t(), user_name_id};
        
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        pActor->request_bridge_id(is_bcont, user_content.is_bridge_id);
        pActor->request_bridge_id(bcont, user_content.bridge_id);
    }

    //pack user content
    std::string strval;        
    pack_user_content(user_content, strval);
    LOG_DEBUG("user "<<user_name<<" use bridge_id("<<user_content.bridge_id.str()
              <<") and is_bridge_id("<<user_content.is_bridge_id.str()<<")");
        
    //write back user content to database
    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("Write user content into database failed.");
    }

    //read users info in database
    strval.clear();    
    if(!read_users_info(strval))
    {
        LOG_ERROR("Read users info from database failed.");
    }

    nb_users_info users_info;    
    unpack_users_info(strval, users_info);
    users_info.user_names.push_back(user_name);
    pack_users_info(users_info, strval);
    
    //read users info in database
    if(!write_users_info(strval))
    {
        LOG_ERROR("Write users info into database failed.");
    }
}

void nb_user_manager::dump_user_info(const nb_users_info& users_info)
{
    std::cout<<"===================dump user info======================="<<std::endl;
    for(std::vector<std::string>::const_iterator it = users_info.user_names.begin();
        it != users_info.user_names.end(); ++it)
    {

    }
    
    std::cout<<"========================================================"<<std::endl;
}

bool nb_user_manager::get_all_users(std::vector<std::string>& users)
{
    boost::shared_lock<boost::shared_mutex> lock(m_mutex);
    
    std::string strval;        
    //read users info in database
    if(!read_users_info(strval))
    {
        LOG_ERROR("Read users info to database failed.");
        return false; 
    }

    nb_users_info users_info;    
    unpack_users_info(strval, users_info);
    users = users_info.user_names;
    return true;
}
