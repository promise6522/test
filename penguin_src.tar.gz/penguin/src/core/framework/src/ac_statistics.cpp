/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <boost/lexical_cast.hpp>

#include "ac_statistics.h"
#include "ac_actor.h"

uint64_t g_message_count = 0;

ac_statistics::ac_statistics(std::size_t interval)
    : m_is_stop(false), m_interval(interval), m_total_time(0)
{
}

ac_statistics::~ac_statistics()
{
}

std::size_t ac_statistics::get_actor_list_size()
{
    return 0;    
}

std::size_t ac_statistics::get_initializing_actor_size()
{
    return 0;    
}

std::size_t ac_statistics::get_initialized_actor_size()
{
    return 0;    
}

std::size_t ac_statistics::get_executing_actor_size()
{
    return 0;
}

std::size_t ac_statistics::get_exiting_actor_size()
{
    return 0;
}

std::size_t ac_statistics::get_empty_queue_actor_size()
{
    return 0;
}
    
void ac_statistics::dump_actors()
{
    std::cout<<"#############################################################################################"<<std::endl;
    std::cout<<"       actor statistics information  ("<<std::dec<<m_total_time<<" seconds)  ("<<g_message_count<<" msg)  Dispatch queue("<<m_dispatch_queue_size<<")"<<std::endl;
    std::cout<<"---------------------------------------------------------------------------------------------"<<std::endl;
    std::cout<<"          actor       initializing initialized waiting queuing executing exiting  total_queue"<<std::endl;
    std::cout<<"---------------------------------------------------------------------------------------------"<<std::endl;
    std::string total_str = "Total : " + boost::lexical_cast<std::string>(m_total_actor_size);
    std::cout<<std::setw(19)<<std::setfill(' ')<<total_str;
    std::cout<<std::setw(15)<<std::setfill(' ')<<m_initializing_actor_size;
    std::cout<<std::setw(12)<<std::setfill(' ')<<m_initialized_actor_size;
    std::cout<<std::setw(8)<<std::setfill(' ')<<m_waiting_actor_size;
    std::cout<<std::setw(8)<<std::setfill(' ')<<m_queuing_actor_size;
    std::cout<<std::setw(10)<<std::setfill(' ')<<m_executing_actor_size;
    std::cout<<std::setw(8)<<std::setfill(' ')<<m_exiting_actor_size;
    std::cout<<std::setw(13)<<std::setfill(' ')<<m_total_actor_queue<<std::endl;

    //dump each kinds of actor's statistics
    for(std::map<std::string, actor_status_statistics>::iterator it = m_actor_statistics_map.begin();
        it != m_actor_statistics_map.end(); ++it)
    {
        std::cout<<std::setw(19)<<std::setfill(' ')<<it->first.substr(it->first.find_first_of("ac"));
        std::cout<<std::setw(15)<<std::setfill(' ')<<it->second.initializing_size;
        std::cout<<std::setw(12)<<std::setfill(' ')<<it->second.initialized_size;
        std::cout<<std::setw(8)<<std::setfill(' ')<<it->second.waiting_size;
        std::cout<<std::setw(8)<<std::setfill(' ')<<it->second.queuing_size;
        std::cout<<std::setw(10)<<std::setfill(' ')<<it->second.executing_size;
        std::cout<<std::setw(8)<<std::setfill(' ')<<it->second.exiting_size;
        std::cout<<std::setw(13)<<std::setfill(' ')<<it->second.total_queue<<std::endl;    
    }
    std::cout<<"#############################################################################################"<<std::endl;
    std::cout<<std::hex<<std::endl;
}

void ac_statistics::dump_actor_queue()
{
    
}

void ac_statistics::clear_statistics()
{
    m_total_actor_size = 0;
    m_initializing_actor_size = 0;
    m_initialized_actor_size = 0;
    m_waiting_actor_size = 0;
    m_queuing_actor_size = 0;
    m_executing_actor_size = 0;
    m_exiting_actor_size = 0;
    m_total_actor_queue = 0;
    m_dispatch_queue_size = 0;
    m_actor_statistics_map.clear();
}

void ac_statistics::generate_statistics()
{
    clear_statistics();

    {
        boost::shared_lock<boost::shared_mutex> lock(ac_manager::instance().m_queue_mutex);
	m_dispatch_queue_size = ac_manager::instance().m_actor_queue.size();
    }

    boost::shared_lock<boost::shared_mutex> lock(ac_manager::instance().m_pool_mutex);
    for(boost::unordered_set<ac_actor *>::iterator it = ac_manager::instance().m_actor_pool.begin();
        it != ac_manager::instance().m_actor_pool.end(); ++it)
    {
        ac_actor *pActor = *it;
        std::string actor_name = typeid(*pActor).name();

        if(m_actor_statistics_map.find(actor_name) == m_actor_statistics_map.end())
        {
            actor_status_statistics ac_st = {0, 0, 0, 0, 0, 0};
            m_actor_statistics_map[actor_name] = ac_st;
        }

        if(pActor == NULL)
            continue;

        ++m_total_actor_size;
        if(!pActor->is_initialized())
        {
            ++m_initializing_actor_size;
            ++m_actor_statistics_map[actor_name].initializing_size;
        }
        else
        {
            ++m_initialized_actor_size;            
            ++m_actor_statistics_map[actor_name].initialized_size;
        }

        if(pActor->get_status() == ac_status_waiting)
        {
            ++m_waiting_actor_size;
            ++m_actor_statistics_map[actor_name].waiting_size;
        }

        if(pActor->get_status() == ac_status_in_queue)
        {
            ++m_queuing_actor_size;
            ++m_actor_statistics_map[actor_name].queuing_size;
        }

        if(pActor->get_status() == ac_status_executing)
        {
            ++m_executing_actor_size;
            ++m_actor_statistics_map[actor_name].executing_size;
        }

        if(pActor->get_status() == ac_status_exiting)
        {
            ++m_exiting_actor_size;
            ++m_actor_statistics_map[actor_name].exiting_size;
        }
        
        m_total_actor_queue += pActor->queue_size();
        m_actor_statistics_map[actor_name].total_queue += pActor->queue_size();
    }
    m_total_time += m_interval;
}

void ac_statistics::operator() ()
{
    while(!m_is_stop)
    {
        std::size_t tm;
        sleep(Default_Sleep_Time);
        tm += Default_Sleep_Time;
        if(tm > m_interval)
        {
            generate_statistics();
            dump_actors();        
            tm = 0;
        }
    }        
}

void ac_statistics::stop()
{
    m_is_stop = true;
}

