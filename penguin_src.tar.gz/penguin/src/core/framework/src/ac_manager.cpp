/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_manager.h"
#include "ac_actor.h"
#include "ac_memory_alloctor.h"
#include "nb_semi_info_manager.h"
#include "nb_request_handler.h"

#include "ac_root_committer.h"
#include "ac_center_committer.h"
#include "ac_host_committer.h"
#include "ac_object.h"
#include "ac_access.h"
#include "ac_transaction.h"
#include "ac_execution.h"
#include "ac_storage_facade.h"
#include "ac_container.h"
#include "ac_anchor.h"
#include "ac_bridge.h"
#include "ac_bridge_factory.h"
#include "ac_storage.h"

boost::once_flag g_boost_once;

ac_manager::ac_manager(void)
{
    time_t tm;    
    time(&tm);
    m_top_req_num = tm;
}

ac_manager::~ac_manager(void)
{
}

ac_manager& ac_manager::instance()
{
	static ac_manager manager;
	return manager;
}

void ac_manager::init_manager(bool is_gc, std::size_t mem_size, std::size_t mem_rate)
{
    m_is_gc = is_gc;

    if(m_is_gc)
    {
        m_ptr_gc_threshold.reset(new(std::nothrow) ac_gc_threshold(mem_size, mem_rate));
    }
    else
    {
        m_ptr_gc_threshold.reset();
    }
    
    //TBD: check init flag;
#ifndef AC_FRAMEWORK_TEST
    LOG_DEBUG("ac_manager init the singleton actor......");    
    boost::call_once(&init_singleton_actor, g_boost_once);

    //put singleton actor to list, ignor ac_framework
    for(size_t i = 1; i < _countof(g_singleton_actors); ++i)
    {
        ac_actor *pActor = acid_to_actor(*g_singleton_actors[i]);
        add_actor(pActor);
    }

    //create the ac_bridge_factory
    bridge_factory_id_t bf_id;
    request_actor(bf_id);
#endif

#ifdef CREATE_SEMI_OBJECTS
    nb_semi_info info;    
    if(!nb_semi_info_manager::instance().load_semi_info(info))
    {
        bool ret = nb_semi_info_manager::instance().create_semi_info(info);
        assert(ret);        
    }
#endif    
}

void ac_manager::dest_manager()
{
    clear();
}

void ac_manager::clear()
{
#ifndef AC_FRAMEWORK_TEST
    while(!m_actor_queue.empty())
    {
        ac_actor* pActor = m_actor_queue.front();
	m_actor_queue.pop_front();
	if(pActor)
	{
	    pActor->message_loop();
	}
        //actor_destory(m_actor_queue.front());
    }
#endif

#ifndef AC_FRAMEWORK_TEST
    for(boost::unordered_set<ac_actor *>::iterator it = m_actor_pool.begin(); it != m_actor_pool.end(); ++it)
    {
        actor_destory(*it);
    }
#endif
    m_actor_pool.clear();    
}

req_num_t ac_manager::generate_req_num()
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_req_num_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    return m_top_req_num++;    
}

void ac_manager::register_outside_response(const req_num_t& req_num, const bridge_id_t& bridge_id,
                                           nb_response_callback call_back)
{
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_req_callback_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_req_callback_map[req_num] = call_back;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_bridge_req_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_bridge_req_map[bridge_id] = req_num;
    }
}

void ac_manager::unregister_outside_response(const req_num_t& req_num, const bridge_id_t& bridge_id)
{
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_req_callback_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_req_callback_map.erase(req_num);
    }

    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_bridge_req_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_bridge_req_map.erase(bridge_id);
    }
}

bool ac_manager::get_outgoing_req_num(const bridge_id_t& bridge_id, req_num_t& req_num)
{
    boost::shared_lock<boost::shared_mutex> lock();
    boost::unordered_map<bridge_id_t, req_num_t>::iterator it = m_bridge_req_map.find(bridge_id);
    if(it != m_bridge_req_map.end())
    {
        req_num = it->second;
        return true;
    }
    return false;
}

void ac_manager::set_actor_exiting_status(ac_id_t ac_id)
{
    ac_actor * pActor = acid_to_actor(ac_id);
    if(pActor)
    {
        AC_STATUS_SET_STATUS(&pActor->get_status(), ac_status_exiting);
    }
}

bool ac_manager::message_handle(const ac_message_t& message)
{
    if(message.type == e_ac_actor_exception)
    {
        LOG_ERROR("ac_framework get exception.");
        return true;
    }

    if(message.type != e_ac_bridge_trigger_response)
    {
        LOG_ERROR("ac_framework get invalid "<<ac_method_string[message.type]<<" message.");
        return true;    
    }

    boost::unordered_map<req_num_t, nb_response_callback>::iterator it = m_req_callback_map.find(message.req_num);

    byte_stream* pData = reinterpret_cast<byte_stream*>(message.data);
    if(it != m_req_callback_map.end())
    {
        it->second(pData->data);
        ac_memory_alloctor<byte_stream>::instance().deallocate(pData);
        return true;
    }

    ac_memory_alloctor<byte_stream>::instance().deallocate(pData);
    LOG_ERROR("Could not find callback. May connection already be closed.");
    return false;
}

bool ac_manager::is_actor_exist(ac_actor* pActor)
{
    boost::unordered_set<ac_actor *>::iterator it = m_actor_pool.end();
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_pool_mutex);
        it = m_actor_pool.find(pActor);
    }

    if(it == m_actor_pool.end())
    {
        return false;
    }
    
    return true;
}

bool ac_manager::send_asyn_message(ac_id_t dest_id, ac_message_t* pMsg)
{
    if(pMsg == NULL)
        return false;

    ac_actor *pActor = acid_to_actor(dest_id);

    if(pActor)
    {        
        if(!is_actor_exist(pActor))
        {
            LOG_ERROR("Send message to valid actor("<<std::hex<<dest_id<<")");
            return false;
        }

        pActor->enqueue(pMsg);
        add_actor_to_dispatch_queue(pActor);
        return true;
    }

    //let the framework to handle this message
    bool ret = message_handle(*pMsg);
    ac_memory_alloctor<ac_message_t>::instance().deallocate(pMsg);
    return ret;    
}

bool ac_manager::send_asyn_message(ac_id_t dest_id, ac_id_t src_id, 
                                   req_num_t req_num, ac_method_t type,
                                   void *pData, bool is_respond /*= false */)
{
    ac_message_t* pMsg = ac_memory_alloctor<ac_message_t>::instance().allocate();
    if(pMsg == NULL)
        return false;

    pack_message(*pMsg, src_id, req_num, type, pData, is_respond);
    
    return send_asyn_message(dest_id, pMsg);    
}

void ac_manager::add_actor(ac_actor * pActor)
{
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_actor_pool.insert(pActor);
    }
}

bool ac_manager::create_actor(ac_root_committer*& pActor, const root_committer_id_t& rc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_rc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<root_committer_id_t, ac_id_t>::iterator it = m_rcid_acid_map.find(rc_id);
    if(it != m_rcid_acid_map.end())
    {
        pActor = static_cast<ac_root_committer *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_root_committer>::instance().allocate();
    if(!pActor)
    {
        return false;
    }
    
    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> pool_uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    
    m_rcid_acid_map[rc_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_center_committer*& pActor,  const center_committer_id_t& cc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_cc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<center_committer_id_t, ac_id_t>::iterator it = m_ccid_acid_map.find(cc_id);
    if(it != m_ccid_acid_map.end())
    {
        pActor = static_cast<ac_center_committer *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_center_committer>::instance().allocate();
    if(!pActor)
    {
        return false;
    }
    
    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> pool_uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_ccid_acid_map[cc_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_host_committer*& pActor, const host_committer_id_t& hc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_hc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<host_committer_id_t, ac_id_t>::iterator it = m_hcid_acid_map.find(hc_id);
    if(it != m_hcid_acid_map.end())
    {
        pActor = static_cast<ac_host_committer *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_host_committer>::instance().allocate();
    if(!pActor)
    {
        return false;
    }
    
    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> pool_uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_hcid_acid_map[hc_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_transaction *& pActor, const transaction_id_t& trans_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_tr_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<transaction_id_t, ac_id_t>::iterator it = m_trid_acid_map.find(trans_id);
    if(it != m_trid_acid_map.end())
    {
        pActor = static_cast<ac_transaction *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_transaction>::instance().allocate();
    if(!pActor)
    {
        return false;
    }
    
    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_trid_acid_map[trans_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_object*& pActor, const nb_id_t& nb_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_nb_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<nb_id_t, ac_id_t>::iterator it = m_nbid_acid_map.find(nb_id);
    if(it != m_nbid_acid_map.end())
    {
        pActor = static_cast<ac_object *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_object>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    m_nbid_acid_map[nb_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_execution*& pActor, const execution_id_t& exe_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_exe_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<execution_id_t, ac_id_t>::iterator it = m_exeid_acid_map.find(exe_id);
    if(it != m_exeid_acid_map.end())
    {
        pActor = static_cast<ac_execution *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_execution>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_exeid_acid_map[exe_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_bridge*& pActor, const bridge_id_t& bridge_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_bg_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<bridge_id_t, ac_id_t>::iterator it = m_bgid_acid_map.find(bridge_id);
    if(it != m_bgid_acid_map.end())
    {
        pActor = static_cast<ac_bridge *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_bridge>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    m_bgid_acid_map[bridge_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_bridge_factory*& pActor, const bridge_factory_id_t& bf_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_bf_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<bridge_factory_id_t, ac_id_t>::iterator it = m_bfid_acid_map.find(bf_id);
    if(it != m_bfid_acid_map.end())
    {
        pActor = static_cast<ac_bridge_factory *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_bridge_factory>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    m_bfid_acid_map[bf_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_storage_facade*& pActor, const facade_id_t& facade_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_fd_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<facade_id_t, ac_id_t>::iterator it = m_fdid_acid_map.find(facade_id);
    if(it != m_fdid_acid_map.end())
    {
        pActor = static_cast<ac_storage_facade *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_storage_facade>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    m_fdid_acid_map[facade_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_container*& pActor, const container_id_t& cont_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_cont_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<container_id_t, ac_id_t>::iterator it = m_contid_acid_map.find(cont_id);
    if(it != m_contid_acid_map.end())
    {
        pActor = static_cast<ac_container *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_container>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }
    m_contid_acid_map[cont_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_anchor*& pActor, const anchor_id_t& an_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_an_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<anchor_id_t, ac_id_t>::iterator it = m_anid_acid_map.find(an_id);
    if(it != m_anid_acid_map.end())
    {
        pActor = static_cast<ac_anchor *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_anchor>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_anid_acid_map[an_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_access*& pActor, const access_id_t& as_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_as_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<access_id_t, ac_id_t>::iterator it = m_asid_acid_map.find(as_id);
    if(it != m_asid_acid_map.end())
    {
        pActor = static_cast<ac_access *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_access>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_asid_acid_map[as_id] = actor_to_acid(pActor);
    return true;
}

bool ac_manager::create_actor(ac_storage*& pActor, const storage_id_t& st_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_st_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    boost::unordered_map<storage_id_t, ac_id_t>::iterator it = m_stid_acid_map.find(st_id);
    if(it != m_stid_acid_map.end())
    {
        pActor = static_cast<ac_storage *>(acid_to_actor(it->second));
        return false;
    }

    pActor = ac_memory_alloctor<ac_storage>::instance().allocate();
    if(!pActor)
    {
        return false;
    }

    {
        boost::upgrade_lock<boost::shared_mutex> pool_lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(pool_lock);
        m_actor_pool.insert(pActor);
    }

    m_stid_acid_map[st_id] = actor_to_acid(pActor);
    return true;
}

ac_actor* ac_manager::acid_to_actor(ac_id_t ac_id)
{
    return reinterpret_cast<ac_actor*>(ac_id);
}

ac_id_t ac_manager::actor_to_acid(ac_actor* ac_actor)
{
    return reinterpret_cast<ac_id_t>(ac_actor);
}

bool ac_manager::is_actor_exist(const root_committer_id_t& rc_id)
{
    //if the rc_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_rc_map_mutex);
    boost::unordered_map<root_committer_id_t, ac_id_t>::iterator it = m_rcid_acid_map.find(rc_id);
    if(it != m_rcid_acid_map.end())
    {
        return true;
    }

    return false;  
}

bool ac_manager::is_actor_exist(const center_committer_id_t& cc_id)
{
    //if the cc_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_cc_map_mutex);
    boost::unordered_map<center_committer_id_t, ac_id_t>::iterator it = m_ccid_acid_map.find(cc_id);
    if(it != m_ccid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const host_committer_id_t& hc_id)
{
    //if the hc_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_hc_map_mutex);
    boost::unordered_map<host_committer_id_t, ac_id_t>::iterator it = m_hcid_acid_map.find(hc_id);
    if(it != m_hcid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const transaction_id_t& trans_id)
{
    //if the trans_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_tr_map_mutex);
    boost::unordered_map<transaction_id_t, ac_id_t>::iterator it = m_trid_acid_map.find(trans_id);
    if(it != m_trid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const nb_id_t& nb_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_nb_map_mutex);
    boost::unordered_map<nb_id_t, ac_id_t>::iterator it = m_nbid_acid_map.find(nb_id);
    if(it != m_nbid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const execution_id_t& exe_id)
{
    //if the exe_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_exe_map_mutex);
    boost::unordered_map<execution_id_t, ac_id_t>::iterator it = m_exeid_acid_map.find(exe_id);
    if(it != m_exeid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const bridge_id_t& bridge_id)
{
    //if the bridge_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_bg_map_mutex);
    boost::unordered_map<bridge_id_t, ac_id_t>::iterator it = m_bgid_acid_map.find(bridge_id);
    if(it != m_bgid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const bridge_factory_id_t& bf_id)
{
    //if the bridge_factory_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_bf_map_mutex);
    boost::unordered_map<bridge_factory_id_t, ac_id_t>::iterator it = m_bfid_acid_map.find(bf_id);
    if(it != m_bfid_acid_map.end())
    {
        return true;
    }
    
    return false;
}

bool ac_manager::is_actor_exist(const facade_id_t& facade_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_fd_map_mutex);
    boost::unordered_map<facade_id_t, ac_id_t>::iterator it = m_fdid_acid_map.find(facade_id);
    if(it != m_fdid_acid_map.end())
    {
        return true;
    }    

    return false;
}

bool ac_manager::is_actor_exist(const container_id_t& cont_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_cont_map_mutex);
    boost::unordered_map<container_id_t, ac_id_t>::iterator it = m_contid_acid_map.find(cont_id);
    if(it != m_contid_acid_map.end())
    {
        return true;
    }    

    return false;
}

bool ac_manager::is_actor_exist(const anchor_id_t& an_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_an_map_mutex);
    boost::unordered_map<anchor_id_t, ac_id_t>::iterator it = m_anid_acid_map.find(an_id);
    if(it != m_anid_acid_map.end())
    {
        return true;
    }    

    return false;
}

bool ac_manager::is_actor_exist(const access_id_t& as_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_as_map_mutex);
    boost::unordered_map<access_id_t, ac_id_t>::iterator it = m_asid_acid_map.find(as_id);
    if(it != m_asid_acid_map.end())
    {
        return true;
    }    

    return false;
}

bool ac_manager::is_actor_exist(const storage_id_t& st_id)
{
    //if the nb_id already have ac_id(means actor already exist)
    boost::shared_lock<boost::shared_mutex> lock(m_st_map_mutex);
    boost::unordered_map<storage_id_t, ac_id_t>::iterator it = m_stid_acid_map.find(st_id);
    if(it != m_stid_acid_map.end())
    {
        return true;
    }    

    return false;
}

void ac_manager::remove_id_map(const root_committer_id_t& rc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_rc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_rcid_acid_map.erase(rc_id);
}

void ac_manager::remove_id_map(const center_committer_id_t& cc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_cc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_ccid_acid_map.erase(cc_id);
}

void ac_manager::remove_id_map(const host_committer_id_t& hc_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_hc_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_hcid_acid_map.erase(hc_id);
}
    
void ac_manager::remove_id_map(const transaction_id_t& trans_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_tr_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_trid_acid_map.erase(trans_id);
}

void ac_manager::remove_id_map(const nb_id_t& nb_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_nb_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_nbid_acid_map.erase(nb_id);
}

void ac_manager::remove_id_map(const execution_id_t& exe_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_exe_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_exeid_acid_map.erase(exe_id);
}

void ac_manager::remove_id_map(const bridge_id_t& bridge_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_bg_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_bgid_acid_map.erase(bridge_id);
}

void ac_manager::remove_id_map(const bridge_factory_id_t& bf_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_bf_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_bfid_acid_map.erase(bf_id);
}

void ac_manager::remove_id_map(const facade_id_t& facade_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_fd_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_fdid_acid_map.erase(facade_id);
}

void ac_manager::remove_id_map(const container_id_t& cont_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_cont_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_contid_acid_map.erase(cont_id);
}

void ac_manager::remove_id_map(const anchor_id_t& an_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_an_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_anid_acid_map.erase(an_id);
}

void ac_manager::remove_id_map(const access_id_t& as_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_as_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_asid_acid_map.erase(as_id);
}

void ac_manager::remove_id_map(const storage_id_t& st_id)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_st_map_mutex);
    boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
    m_stid_acid_map.erase(st_id);
}

ac_actor* ac_manager::get_waiting_actor()
{    
    //if there is no waiting executing actor, just sleep 10ms for better cup usage.
    if(m_actor_queue.empty())
    {
        usleep(10);        
        return NULL;
    }

    ac_actor *pActor = NULL;
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_queue_mutex);
        if(m_actor_queue.empty())
        {
            return NULL;
        }

        pActor = m_actor_queue.front();
        //else get first waiting actor for ac_executor
        {
            boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
            m_actor_queue.pop_front();
        }
    }
    
    if(pActor && AC_STATUS_QUEUE_TO_EXECUTING(&pActor->get_status()))
    {        
        return pActor;
    }

    return NULL;
}

void ac_manager::put_idle_actor(ac_actor* pActor)
{
    if(!pActor)
    {
        return;        
    }

    if(!pActor->queue_empty())
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_queue_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_actor_queue.push_back(pActor);        
    }
}

void ac_manager::add_actor_to_dispatch_queue(ac_actor* pActor)
{
    if(pActor && AC_STATUS_WAITING_TO_QUEUE(&pActor->get_status()))
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_queue_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_actor_queue.push_back(pActor);
    }
}

bool ac_manager::is_dispatch_queue_empty()
{
    boost::shared_lock<boost::shared_mutex> lock(m_queue_mutex);
    return m_actor_queue.empty();
}

bool ac_manager::get_ac_id(const root_committer_id_t& rc_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_rc_map_mutex);
    boost::unordered_map<root_committer_id_t, ac_id_t>::iterator it =  m_rcid_acid_map.find(rc_id);
    
    if( it != m_rcid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const center_committer_id_t& cc_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_cc_map_mutex);
    boost::unordered_map<center_committer_id_t, ac_id_t>::iterator it =  m_ccid_acid_map.find(cc_id);
    
    if( it != m_ccid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;    
}

bool ac_manager::get_ac_id(const host_committer_id_t& hc_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_hc_map_mutex);
    boost::unordered_map<host_committer_id_t, ac_id_t>::iterator it =  m_hcid_acid_map.find(hc_id);
    
    if( it != m_hcid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const transaction_id_t& trans_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_tr_map_mutex);
    boost::unordered_map<transaction_id_t, ac_id_t>::iterator it =  m_trid_acid_map.find(trans_id);
    
    if( it != m_trid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const nb_id_t& nb_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_nb_map_mutex);
    boost::unordered_map<nb_id_t, ac_id_t>::iterator it =  m_nbid_acid_map.find(nb_id);
    
    if( it != m_nbid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const execution_id_t& exe_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_exe_map_mutex);
    boost::unordered_map<execution_id_t, ac_id_t>::iterator it =  m_exeid_acid_map.find(exe_id);
    
    if( it != m_exeid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const bridge_id_t& bridge_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_bg_map_mutex);
    boost::unordered_map<bridge_id_t, ac_id_t>::iterator it = m_bgid_acid_map.find(bridge_id);
    
    if( it != m_bgid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const bridge_factory_id_t& bf_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_bf_map_mutex);
    boost::unordered_map<bridge_factory_id_t, ac_id_t>::iterator it = m_bfid_acid_map.find(bf_id);
    
    if( it != m_bfid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const facade_id_t& facade_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_fd_map_mutex);
    boost::unordered_map<facade_id_t, ac_id_t>::iterator it = m_fdid_acid_map.find(facade_id);
    
    if( it != m_fdid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const container_id_t& cont_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_cont_map_mutex);
    boost::unordered_map<container_id_t, ac_id_t>::iterator it = m_contid_acid_map.find(cont_id);
    
    if( it != m_contid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const anchor_id_t& an_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_an_map_mutex);
    boost::unordered_map<anchor_id_t, ac_id_t>::iterator it = m_anid_acid_map.find(an_id);
    
    if( it != m_anid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const access_id_t& as_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_as_map_mutex);
    boost::unordered_map<access_id_t, ac_id_t>::iterator it = m_asid_acid_map.find(as_id);
    
    if( it != m_asid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

bool ac_manager::get_ac_id(const storage_id_t& st_id, ac_id_t& ac_id)
{
    boost::shared_lock<boost::shared_mutex> lock(m_st_map_mutex);
    boost::unordered_map<storage_id_t, ac_id_t>::iterator it = m_stid_acid_map.find(st_id);
    
    if( it != m_stid_acid_map.end())
    {
        ac_id = it->second;
        return true;
    }

    return false;
}

void ac_manager::remove_id_map_by_actor(ac_actor* pActor)
{
    if(!pActor)
        return;

    ac_actor_t ac_type = pActor->get_actor_type();
    switch(ac_type)
    {
        case e_ac_root_committer :
        {
            root_committer_id_t id = static_cast<ac_root_committer*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_center_committer :
        {
            center_committer_id_t id = static_cast<ac_center_committer*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_host_committer :
        {
            host_committer_id_t id = static_cast<ac_host_committer*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_object :
        {
            nb_id_t id = static_cast<ac_object*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_access :
        {
            access_id_t id = static_cast<ac_access*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_transaction :
        {
            transaction_id_t id = static_cast<ac_transaction*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_execution : 
        {
            execution_id_t id = static_cast<ac_execution*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_storage_facade :
        {
            facade_id_t id = static_cast<ac_storage_facade*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_anchor :
        {
            anchor_id_t id = static_cast<ac_anchor*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_storage :
        {
            storage_id_t id = static_cast<ac_storage*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_bridge :
        {
            bridge_id_t id = static_cast<ac_bridge*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        case e_ac_bridge_factory :
        {
            bridge_factory_id_t id = static_cast<ac_bridge_factory*>(pActor)->get_id();
            remove_id_map(id);
            break;
        }
        default :
        {
            LOG_DEBUG("Remove Unkown Actor("<<pActor->get_nb_id_alias().str());
        }
    }
}

void ac_manager::remove_actor_in_manager(ac_actor * pActor)
{
    if(!pActor)
    {
        return;
    }
    
    //remove the actor in pool
    {
        boost::upgrade_lock<boost::shared_mutex> lock(m_pool_mutex);
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_actor_pool.erase(pActor);
    }
            
    //remove id actor map
    remove_id_map_by_actor(pActor);
    
    //protect the queue, let's the mutex could not be hold by other thread when status(exiting) -> actor destory
    pActor->protect_queue();

    //destory actor
    LOG_DEBUG("Destory Actor("<< pActor->get_nb_id_alias().str() << ").");
    actor_destory(pActor);                
}

void ac_manager::remove_associated_actors(const host_committer_id_t& hc_id)
{
    ac_id_t ac_hc_id;
    if(!get_ac_id(hc_id, ac_hc_id))
    {
        LOG_ERROR("Could not find ac_id according to host_committer id.");
    }
    ac_actor* pHActor = acid_to_actor(ac_hc_id);
    req_num_t req_num(true);
    
    boost::upgrade_lock<boost::shared_mutex> lock(m_hc_acs_map_mutex);
    host_committer_actors_map::iterator it = m_hc_acs_map.find(hc_id);    
    if( it != m_hc_acs_map.end())
    {
        req_num_t req_num;
        LOG_DEBUG("Send Exiting Message for hc_id = "<<hc_id.str()<<"("<<pHActor->get_nb_id_alias().str()<<")");
        for(boost::unordered_set<ac_actor* >::iterator iter = it->second.begin(); iter != it->second.end(); ++iter)
        {
            ac_actor * pActor = *iter;
            //do not delete ac_container 
            if((pActor == NULL) || (pActor->get_actor_name() == "ac_container")
               || (pActor->get_actor_name() == "ac_access"))
                continue;

            //////////////////////////////
            LOG_DEBUG("Send Exiting Message to "<<pActor->get_actor_name()<<"("<<pActor->get_nb_id_alias().str()<<")"
                      <<" status="<<pActor->get_status());
            ///////////////////////
           
            send_asyn_message(pActor->get_actor_id(), g_ac_framework_acid, req_num,
                                                     e_ac_actor_exit, NULL);
        }
    }
    remove_committer_actors(hc_id);
}

void ac_manager::remove_committer_actors(const host_committer_id_t& hc_id)
{
    req_num_t req_num(true);
    
    //get host_committer actor id
    ac_id_t hc_ac_id;
    if(!ac_manager::instance().get_ac_id(hc_id, hc_ac_id))
        return;

    //get center committer id
    center_committer_id_t cc_id;
    ac_host_committer* pHActor = dynamic_cast<ac_host_committer*>(ac_manager::instance().acid_to_actor(hc_ac_id));
    if(pHActor)
    {
        //no need the lock to prevent the deadlock
        //boost::recursive_mutex::scoped_lock lock(pHActor->get_sync_mutex());
        pHActor->get_center_committer(cc_id);
    }

    //get the root committer id
    root_committer_id_t rc_id;
    ac_id_t cc_ac_id;
    if(ac_manager::instance().get_ac_id(cc_id, cc_ac_id))
    {
        ac_center_committer* pCActor = dynamic_cast<ac_center_committer*>(ac_manager::instance().acid_to_actor(cc_ac_id));
        if(pCActor)
        {
            //no need the lock to prevent the deadlock
            //boost::recursive_mutex::scoped_lock lock(pCActor->get_sync_mutex());
            pCActor->get_root_committer(rc_id);
        }
    }

    //remove host committer actor
    send_asyn_message(hc_ac_id, g_ac_framework_acid, req_num, e_ac_actor_exit, NULL);
    
    //remove center committer actor
    if(ac_manager::instance().get_ac_id(cc_id, cc_ac_id))
    {
        send_asyn_message(cc_ac_id, g_ac_framework_acid, req_num, e_ac_actor_exit, NULL);
    }
    
    //remove root committer actor
    ac_id_t rc_ac_id;
    if(ac_manager::instance().get_ac_id(rc_id, rc_ac_id))
    {
        send_asyn_message(rc_ac_id, g_ac_framework_acid, req_num, e_ac_actor_exit, NULL);
    }
    
}




