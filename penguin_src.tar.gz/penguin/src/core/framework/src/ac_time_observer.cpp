#include <iostream>
#include <sstream>
#include <time.h>

#include "ac_time_observer.h"

ac_time_observer* ac_time_observer::m_instance = 0;

const static std::string TOTAL_STRING = "Total";

const static int SHOW_ALL = 1;
const static int SHOW_BY_TIME = 2;
const static int SHOW_BY_TYPE = 3;
const static int SHOW_ONLY_TOTAL = 4;


inline bool operator<(const message_t& s1, const message_t& s2)
{
    return s1.m_ac_id < s2.m_ac_id;
}

ac_time_observer::ac_time_observer()
{
    m_interval = 1000000;
    m_print_type = SHOW_BY_TYPE;
    m_blanks = "                                          ";
	m_run = false;
}

ac_time_observer::~ac_time_observer()
{
    if (m_instance)
        delete m_instance;
}

bool ac_time_observer::time_observer_init(bool run)
{
	return (m_run = run);
}

bool ac_time_observer::get_run_permission()
{
	return m_run;
}

void ac_time_observer::message_handle(message_t& msg)
{
    if (msg.m_type % 2)
        enter(msg);
    else
    {
        msg.m_type--;
        leave(msg);
    }
}

void ac_time_observer::enter(message_t& msg)
{
    std::map<std::string, tracker_t>::iterator it_scope = get_tracker_pos();

    long time = get_current_time();

//    if (0 == it_scope->second.m_time.size())
    if (msg.m_name == "ac_access_run")
    {
        message_t msg1;
        msg1.m_name = TOTAL_STRING;
        actor_run_time_t at1(msg1);
        at1.m_start = time;
        it_scope->second.m_time.insert(it_scope->second.m_time.begin(), at1);
    }

    actor_run_time_t at2(msg);
    at2.m_start = time;
    it_scope->second.m_time.insert(it_scope->second.m_time.begin(), at2);
}

void ac_time_observer::leave(message_t& msg)
{
    std::map<std::string, tracker_t>::iterator it_scope = get_tracker_pos();

    bool find = false;
    std::vector<actor_run_time_t>::iterator it = it_scope->second.m_time.begin();
    for (; it != it_scope->second.m_time.end(); ++it)
    {
        if (is_message_match(it->m_msg, msg) || it->m_msg.m_name == msg.m_name)
        {
            it->m_end = get_current_time();
            long run_time = it->m_end - it->m_start;

            bool updated_record = false;
            if (SHOW_BY_TYPE == m_print_type)
                updated_record = update_result(it_scope, msg, run_time);

            if (!updated_record)
            {
                measure_t m;
                m.m_elapse = run_time;
                m.m_total = run_time;// / 1000;
                if (msg.m_name == TOTAL_STRING)
                    m.m_count = it_scope->second.m_result.size();
                else
                    m.m_count++;

                it_scope->second.m_result.insert(it_scope->second.m_result.begin(), std::make_pair(it->m_msg, m));
            }

            find = true;
            it_scope->second.m_time.erase(it);
            break;
        }
    }

    if (!find)
        std::cout<<"Failed to match enter for: "<<msg.m_name<<std::endl;

    if (msg.m_name == "ac_access_run_response")
    {
        message_t msg;
        msg.m_name = TOTAL_STRING;
        leave(msg);

        print();
    }
}

bool ac_time_observer::update_result(std::map<std::string, tracker_t>::iterator it_scope, const message_t& msg, long run_time)
{
    bool has_updated = false;
    std::multimap<message_t, measure_t>::iterator it_result = it_scope->second.m_result.begin();
    for (; it_result != it_scope->second.m_result.end(); ++it_result)
    {
        if (it_result->first.m_type == msg.m_type && it_result->first.m_obj_id == msg.m_obj_id)
        {
            it_result->second.m_total = it_result->second.m_total + run_time;// / 1000;
            it_result->second.m_count++;
            has_updated = true;
            break;
        }
    }
    return has_updated;
}

void ac_time_observer::set_interval(long itv)
{
    m_interval = itv;
}

void ac_time_observer::set_print_type(int type)
{
    m_print_type = type;
}

void ac_time_observer::print()
{
    std::map<std::string, tracker_t>::iterator it_scope = get_tracker_pos();

    std::cout<<"========================================= Statistics (us) ========================================="<<std::endl;

    std::cout<<print(36, "actor_name")
             <<print(33, "object_id")
             <<print(6, "count")
             <<print(8, "time")
             <<print(8, "total")
             <<print(8, "average")
             <<std::endl;

    std::cout<<"---------------------------------------------------------------------------------------------------"<<std::endl;

    std::map<message_t, measure_t>::iterator it = it_scope->second.m_result.begin();
    for (; it != it_scope->second.m_result.end(); it++)
    {
        if (!is_print(it))
            continue;

        // 1 actor name
        std::cout<<print(36, it->first.m_name);
        // 2 object id
        if (it->first.m_obj_id.is_type_null())
            std::cout<<print(33, "");
        else
            std::cout<<print(33, it->first.m_obj_id.str());
//        {
//            int type = it->first.m_obj_id.get_type();
//            std::cout<<print(33, type);
//        }
        // 3 count
            std::cout<<print(6, it->second.m_count);
        // 4 time
        if (it->second.m_count == 1)
            std::cout<<print(8, it->second.m_elapse);// / 1000);
        else
            std::cout<<print(8, "X");
        // 5 total
        std::cout<<print(8, it->second.m_total);
        // 6 average
        if (it->second.m_count > 0)
            std::cout<<print(8, it->second.m_total / it->second.m_count);
        else
            std::cout<<print(8, "@");
        std::cout<<std::endl;
    }

    std::cout<<"==================================================================================================="<<std::endl;

    it_scope->second.m_result.clear();
    it_scope->second.m_time.clear();
}

bool ac_time_observer::is_print(std::map<message_t, measure_t>::iterator it)
{
    bool ret = false;
    switch (m_print_type)
    {
        case SHOW_ALL:
            ret = true;
            break;
        case SHOW_BY_TIME:
            if (it->second.m_elapse < m_interval)
                ret = true;
            break;
        case SHOW_ONLY_TOTAL:
            if (it->first.m_name == TOTAL_STRING)
                ret = true;
            break;
        case SHOW_BY_TYPE:
            ret = true;
            break;
        default:
            break;
    }
    return ret;
}

bool ac_time_observer::is_match(const message_t& s1, const message_t& s2)
{
    bool ret = false;
    switch (m_print_type)
    {
        case SHOW_ALL:
        case SHOW_BY_TIME:
        case SHOW_ONLY_TOTAL:
            if (is_message_match(s1, s2) || s1.m_name == s2.m_name)
                ret = true;
            break;
        case SHOW_BY_TYPE:
            if (is_message_type_match(s1, s2) || s1.m_name == s2.m_name)
                ret = true;
            break;
        default:
            break;
    }
    return ret;
}

bool ac_time_observer::is_message_match(const message_t& s1, const message_t& s2)
{
    if (s1.m_obj_id.is_type_null() && s2.m_obj_id.is_type_null())
        return s1.m_ac_id == s2.m_ac_id
                && s1.m_req_num == s2.m_req_num
                && s1.m_type == s2.m_type;
    else
        return s1.m_ac_id == s2.m_ac_id
                && s1.m_obj_id == s2.m_obj_id
                && s1.m_req_num == s2.m_req_num
                && s1.m_type == s2.m_type;
}

bool ac_time_observer::is_message_type_match(const message_t& s1, const message_t& s2)
{
    return s1.m_type == s2.m_type;
}

std::map<std::string, tracker_t>::iterator ac_time_observer::get_tracker_pos()
{
    std::map<std::string, tracker_t>::iterator it = m_scope.find("currentThreadName");
    if (it == m_scope.end())
    {
        tracker_t tt;
        m_scope.insert(std::make_pair("currentThreadName", tt));
        it = m_scope.find("currentThreadName");
    }
    return it;
}

std::string ac_time_observer::print(int length, std::string t)
{
    if (static_cast<int>(t.size()) >= length + 1)
        return t.substr(t.size() - length);
    else
        return m_blanks.substr(0, length - t.size()) + t;
}

std::string ac_time_observer::print(int length, long l)
{
    std::stringstream stream;
    std::string str;
    stream << l;
    stream >> str;
    return print(length, str);
}

long ac_time_observer::get_current_time()
{
    struct timeval current;
    gettimeofday(&current, NULL);
    long time = current.tv_sec;
    time = time * 1000000 + current.tv_usec;
//    std::cout<<"          !!!!!!!!!! time ==="<<time<<std::endl;
    return time;
}

std::string ac_time_observer::print_current_time()
{
    time_t timenow;
    struct timeval current;
    time(&timenow);
    gettimeofday(&current, NULL);
    struct tm* t_tm = localtime(&timenow);

    char ctm[23];
    sprintf(ctm, "%4d-%02d-%02d %02d:%02d:%02d : ", t_tm->tm_year+1900, t_tm->tm_mon+1, t_tm->tm_mday, t_tm->tm_hour, t_tm->tm_min, t_tm->tm_sec);
    std::stringstream ss, sus;
    std::string strs, strus;
    ss << current.tv_sec;
    ss >> strs;
    sus << current.tv_usec;
    sus >> strus;
    std::string st;
    st = ctm;
    st = st + strs + "." + strus;

    return st;
}
