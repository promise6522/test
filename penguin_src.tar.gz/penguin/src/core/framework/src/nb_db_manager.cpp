#include "nb_db_manager.h"

#include "stdx_log.h"
#include "nb_configuration.h"

void nb_db_manager::init_db_manager()    
{
    //TODO
}
    
void nb_db_manager::run()
{
    this->init_db_manager();

    // create one thread for doing db checkpoints
    if (0 != pthread_create(&m_chkpoint_pid, NULL, &nb_db_manager::do_checkpoint, this))
    {
        LOG_ERROR("nb_db_manager : fail to create the checkpoint thread.");
        assert(false);
        return;
    }
}

void nb_db_manager::stop()
{
    m_stop = true;

    if (0 != pthread_join(m_chkpoint_pid, NULL))
    {
        LOG_ERROR("nb_db_manager : fail to join the checkpoint thread.");
    }

    LOG_DEBUG("nb_db_manager : Stopped.");
}

bool nb_db_manager::add_env(DbEnv* penv)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_envs_mutex);
    std::vector<DbEnv*>::iterator it;
    // check duplicates
    it = std::find(m_envs_list.begin(), m_envs_list.end(), penv);
    if (it == m_envs_list.end())
    {
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_envs_list.push_back(penv);
        return true;
    }
    return false;
}


bool nb_db_manager::remove_env(DbEnv* penv)
{
    boost::upgrade_lock<boost::shared_mutex> lock(m_envs_mutex);
    std::vector<DbEnv*>::iterator it;
    it = std::find(m_envs_list.begin(), m_envs_list.end(), penv);
    if (it != m_envs_list.end())
    {
        boost::upgrade_to_unique_lock<boost::shared_mutex> uniqueLock(lock);
        m_envs_list.erase(it);
        return true;
    }
    return false;
}


void* nb_db_manager::do_checkpoint(void* arg)
{
    LOG_DEBUG("start new routine to do checkpoint");

    nb_db_manager* pMgr = static_cast<nb_db_manager*>(arg);

    // get env_home string
    
    int chkpoint_interval = nb_configuration::instance().get_db_chkpoint_interval();
    int sleep_interval = 1; 
    int cnt = 0; 
    while (!pMgr->m_stop)
    {
        cnt+= sleep_interval; 
        if (0 != cnt % chkpoint_interval)
        {
            sleep(sleep_interval);
            continue;
        }

        // loop through managed envs
        LOG_NOTICE("Start checkpoints ...");

        int total, success, failed;
        boost::upgrade_lock<boost::shared_mutex> lock(pMgr->m_envs_mutex);
        total = pMgr->m_envs_list.size();
        success = 0;
        failed = 0;
        for(int i=0; i < total; ++i)
        {
            DbEnv* penv = pMgr->m_envs_list[i];

            // get env_home string
            const char* env_home;
            penv->get_home(&env_home);
            std::string home_str(env_home);

            // do checkpoints
            if (0 == penv->txn_checkpoint(0, 0, 0))
            {
                ++success;
                LOG_DEBUG("DbEnv["<<home_str<<"] : checkpoint succeeded.");
            }
            else
            {
                ++failed;
                LOG_ERROR("DbEnv["<<home_str<<"] : checkpoint failed.");
            }
        }

        LOG_NOTICE("Start checkpoints finished ["<<success<<"/"<<total<<"].");
    }

    return 0;
}

