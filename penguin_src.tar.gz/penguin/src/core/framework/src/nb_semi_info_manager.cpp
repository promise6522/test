/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#include "nb_semi_info_manager.h"
#include "ac_global_db.h"
#include "ac_message_type.h"
#include "ac_actor_type.h"
#include "ac_manager.h"
#include "ac_id_dispenser.h"
#include "ac_object/obj_impl_decl_compound.h"

bool nb_semi_info_manager::load_semi_info(nb_semi_info& info)
{
    //Read the semi info from DB
    std::string strval;
    if(read_semi_info(strval))
    {
        LOG_DEBUG("read_semi_objects info from DB.");
        return nb_unpack_semi_info(strval, info);
    }
    return false;    
}

bool nb_semi_info_manager::create_semi_info(nb_semi_info& info)
{
    info = nb_semi_info();    
    std::string strval;

    //request host committer_id;
    host_committer_id_t hc_id;    
    request_host_committer_id(hc_id);
    //create watermark 
    info.semi_decl.push_back(create_watermark(hc_id));
    nb_pack_semi_info(info, strval);

    if(!write_semi_info(strval))
    {
        LOG_DEBUG("write_semi_objects info from DB failed.");
        return false;        
    }
    return true;    
}

nb_id_t nb_semi_info_manager::create_watermark(const host_committer_id_t& hc_id)
{

    decl_compound_data_t decl_data;
    decl_data.name = "watermark";

    ////input ports
    iport_t ip_data;
    //None object interface
    ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
    decl_data.iports.push_back(ip_data);

    ////output ports
    oport_t op_data;
    op_data.interface = nb_id_t(NB_INTERFACE_NONE);
    decl_data.oports.push_back(op_data);

    nb_id_t decl_id;        
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;        
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
    request_nb_id(decl_info, decl_id);
    decl_info.raw_data.object_id = decl_id;
    //bf_raw_datas.all_objects.push_back(decl_info.raw_data);
    std::string val = pack_object(decl_info.raw_data);
    unsigned ret = ac_object_db_impl::instance().write(decl_id.str(), val);
    assert(ret == NB_DB_RESULT_SUCCESS);

    //(no need to write to media_formobj_db anymore)
    //duke_media_write_content(decl_info.raw_data, decl_data.name);    

    return decl_id;
}

bool nb_semi_info_manager::request_nb_id(const request_nb_id_info& nb_info, nb_id_t& id)
{
    ac_id_t dest_id = g_ac_id_dispenser_acid;

    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    if(pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        return pActor->request_nb_id(nb_info, id);
    }
    return false;
}

bool nb_semi_info_manager::request_host_committer_id(host_committer_id_t& hc_id)
{
    ac_id_t dest_id = g_ac_id_dispenser_acid;

    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    if(pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        return pActor->request_host_committer_id(hc_id);
    }
    return false;    
}


