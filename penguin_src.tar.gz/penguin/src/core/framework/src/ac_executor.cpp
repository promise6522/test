/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_executor.h"
#include "ac_actor.h"

ac_executor::ac_executor() : m_is_stop(false)
{
}

ac_executor::~ac_executor()
{
}

void ac_executor::operator() ()
{
    while(!m_is_stop)
    {            
        ac_actor * pActor = ac_manager::instance().get_waiting_actor();
        if(pActor)
        {            
            pActor->message_loop();

            //unset actor execution/in_queue flag
            if(AC_STATUS_EXECUTING_TO_WAITING(&pActor->get_status()))
            {
               //double check if or not current actor has task
               if(!pActor->queue_empty())
               {
                   ac_manager::instance().add_actor_to_dispatch_queue(pActor); 
               }
            }
            else
            {
                assert(pActor->get_status() == ac_status_exiting);
                ac_manager::instance().remove_actor_in_manager(pActor);
            }
            
        }        
    }        
}

void ac_executor::stop()
{
    m_is_stop = true;
}

