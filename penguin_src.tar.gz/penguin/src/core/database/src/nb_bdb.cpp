#include "nb_bdb.h"

/**************************************************************************
**
** 	Berkeley DB Configurations
**
**************************************************************************/
/// cache size : 400MB
const uint32_t DB_CACHESIZE = 400 * 1024 * 1024;




/**************************************************************************
**
** 	nbnv : Berkeley DB - DbEnv encapsulation
**
**************************************************************************/
int nbnv::openenv(const std::string dbhome, u_int32_t flags)
{
    if (!dbhome.empty())
        nb_mkdir(dbhome);

    ///##auto deadlock detection
    m_env_.set_lk_detect(DB_LOCK_MINWRITE);

    ///##lock table allocation==
    //m_env_.set_lk_tablesize(20000);//only supported in db5.2
    m_env_.set_lk_max_lockers(20000);
    m_env_.set_lk_max_locks(20000);
    m_env_.set_lk_max_objects(20000);
    m_env_.set_lg_regionmax(1000000);
    m_env_.set_lg_bsize(5000000);

    m_env_.set_cachesize(0, DB_CACHESIZE, 0);

    ///##Max transactions
    uint32_t pagesize = nb_getpagesize();
    assert(pagesize != 0);
    if (pagesize == 0)
        pagesize = NB_PAGE_SIZE_DEFAULT;
    m_env_.set_tx_max(DB_CACHESIZE / nb_getpagesize());

    m_env_.log_set_config(DB_LOG_AUTO_REMOVE, 1);

    //m_env_.txn_checkpoint(0, 0.5, 0);

    //  flags |= DB_REGISTER;
    return m_env_.open(dbhome.c_str(), flags, 0);
}

int nbnv::closeenv()
{
    try
    {
        return m_env_.close(0);
    }
    catch (DbException& e)
    {
        return e.get_errno();
        throw e;
    }
}


/**************************************************************************
**
** 	nbdbc : Berkeley DB - Dbc encapsulation
**
**************************************************************************/
int nbdbc::write(const void* key, u_int32_t nkey, const void* data, u_int32_t ndata)
{
    Dbt dbkey(const_cast<void*>(key), nkey);
    Dbt dbdata(const_cast<void*>(data), ndata);
    return m_dbc->put(&dbkey, &dbdata, DB_CURRENT);
}

int nbdbc::read(std::string& strkey, std::string& strval)
{
    auto_buffer<char> keybuf;
    auto_buffer<char> buf;
    int ret = this->read(keybuf, buf);
    if (ret == 0)
    {
        strkey.assign(keybuf.data(), keybuf.size());
        strval.assign(buf.data(), buf.size());
    }
    return ret;
}

template <typename _DataType>
int nbdbc::read(auto_buffer<_DataType>& keybuf, auto_buffer<_DataType>& buf)
{
    Dbt dbkey;
    Dbt dbdata;
    dbkey.set_flags(DB_DBT_MALLOC);
    dbdata.set_flags(DB_DBT_MALLOC);
    int ret = m_dbc->get(&dbkey, &dbdata, DB_NEXT);
    keybuf.reset(static_cast<_DataType*>(dbkey.get_data()), dbkey.get_size());
    buf.reset(static_cast<_DataType*>(dbdata.get_data()), dbdata.get_size());
    return ret;
}


/**************************************************************************
**
** 	nbdb : Berkeley DB - DbEnv & Db encapsulation
**
**************************************************************************/
size_t nbdb::size(DbTxn* txn)
{
    //DB_BTREE_STAT* db_stat_ptr = NULL;

    // can't specify DB_FAST_STAT
    // For getting the BTREE size would require a traverse of the db
    //
 
    //m_dbp_->stat(NULL, &db_stat_ptr, /*DB_FAST_STAT*/0);
    //size_t sz = db_stat_ptr->bt_ndata;

    // free BDB allocated memory
    //free(db_stat_ptr);

    size_t sz(0);
    Dbc *pcursor;
    Dbt dbc_key, dbc_data;
    m_dbp_->cursor(txn, &pcursor, DB_TXN_SNAPSHOT);
    
    dbc_key.set_flags(DB_DBT_MALLOC);
    dbc_data.set_flags(DB_DBT_MALLOC);
    while (pcursor->get(&dbc_key, &dbc_data, DB_NEXT) == 0)
	++sz;

    if (pcursor->close() != 0)
	assert(false);
    return sz;
}

bool nbdb::exists(const std::string& strkey, DbTxn* txn, uint32_t flags)
{
    Dbt key(const_cast<char*>(strkey.data()), strkey.size());

    int ret = m_dbp_->exists(txn, &key, flags);
    
    return (DB_NOTFOUND != ret);
}

int nbdb::del(const std::string& strkey, DbTxn* txn)
{
    this->prewrite_();

    Dbt dbkey((void*)(strkey.data()), strkey.size());
    return m_dbp_->del(txn, &dbkey, 0);
}


int nbdb::truncate(DbTxn* txn)
{
    return m_dbp_->truncate(txn, 0, 0);
}


int nbdb::read(const std::string& strkey, std::string& strval, DbTxn* txn)
{
    Dbt dbt_key((void*)strkey.data(), strkey.size());
    Dbt dbt_data;
    // using BDB allocated memory
    dbt_data.set_flags(DB_DBT_MALLOC);

    int ret = m_dbp_->get(txn, &dbt_key, &dbt_data, 0);
    if (ret == 0)
        strval.assign(static_cast<char*>(dbt_data.get_data()), dbt_data.get_size());

    // free the BDB allocated memory
    if (dbt_data.get_data())
        free(dbt_data.get_data());

    return ret;
}


int nbdb::write(const std::string& key, const std::string& val, DbTxn* txn, uint32_t flags)
{
    this->prewrite_();

    Dbt dbt_key((void*)(key.data()), key.size());
    Dbt dbt_data((void*)(val.data()), val.size());
    int ret;
    try
    {
        ret = m_dbp_->put(txn, &dbt_key, &dbt_data, flags);
    }
    // We want to see if Deadlock actually happened
    catch (DbDeadlockException& e)
    {
        LOG_ERROR("DB Deadlock detected!");

        // persist to a log file
        FILE* pFile = fopen("db_deadlock_log.txt", "a");//append only
        if (pFile != NULL)
        {
            time_t tm;
            time(&tm);
            fprintf(pFile, "Deadlock detected at %s home = %s, file = %s, db = %s\n  key = %s\n val = %s\n", 
                    ctime(&tm), 
                    m_env_.get_home().c_str(), get_db_file().c_str(), get_db_name().c_str(),
                    key.c_str(), val.c_str());
            fclose(pFile);
        } 

        // rethrow the exception
        throw e;
    }

    return ret;
}


int nbdb::write_multiple(const std::map<std::string, std::string>& data, DbTxn* txn)
{
    size_t key_size = 0;
    size_t data_size = 0;
    // Calculate the total size of key & data to allocate a buffer for bdb
    for (std::map<std::string, std::string>::const_iterator it = data.begin();
            it != data.end(); 
            ++it)
    {
        key_size += it->first.size();
        data_size += it->second.size();
    }
    // BDB specifies that buffer size must be a multiple of 4
    key_size = key_size/4 * 4 + 4;
    data_size = data_size/4 * 4 + 4;
    boost::shared_ptr<void> pKeyBuf(malloc(key_size), free);
    boost::shared_ptr<void> pDataBuf(malloc(data_size), free);

    // Construct 2 DbMultipleDataBuilder upon the Dbt dbtKey & dbtData
    Dbt dbtKey(pKeyBuf.get(), key_size);
    dbtKey.set_flags(DB_DBT_USERMEM);
    DbMultipleDataBuilder keyBuilder(dbtKey);


    Dbt dbtData(pDataBuf.get(), data_size);
    dbtData.set_flags(DB_DBT_USERMEM);
    DbMultipleDataBuilder dataBuilder(dbtData);

    // Append all the key & data items to the builder
    for (std::map<std::string, std::string>::const_iterator it = data.begin();
            it != data.end(); 
            ++it)
    {
        keyBuilder.append((void*)(it->first.data()), it->first.size());
        dataBuilder.append((void*)(it->second.data()), it->second.size());
    }

    // Write to db using DB_MULTIPLE
    // DBD specifies DB_MULTIPLE can'be used together with other flags
    // TODO catch DBExceptions
    int ret = m_dbp_->put(txn, &dbtKey, &dbtData, DB_MULTIPLE);

    return ret;
}

int nbdb::open_(const std::string& dbfile, const std::string& dbname, bool dupsort, u_int32_t flags)
{
    m_dbp_ = new Db(&m_env_.get_env(), 0);

    if (dupsort)
        m_dbp_->set_flags(DB_DUPSORT | DB_RECNUM);

    const int mode = S_IRUSR | S_IWUSR | S_IRGRP;
    return m_dbp_->open(NULL, dbfile.c_str(), dbname.c_str(), DB_BTREE, flags, mode);
}

void nbdb::close_()
{
    if (m_dbp_ != 0)
    {
        try
        {
            m_dbp_->close(0/*DB_NOSYNC*/);
            delete m_dbp_;
            m_dbp_ = NULL;
        }
        catch (DbException& e)
        {
            LOG_ERROR("nbdb::close_() : " << e.what());
        }
    }
}
