/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/
#ifndef __NB_BDB_H
#define __NB_BDB_H

// Posix header files
#include <sys/stat.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <iostream>

// Boost header file
#include <boost/noncopyable.hpp>

// Berkeley DB header files
#include <db_cxx.h>

// Duke header files
#include "stdx_log.h"
#include "nb_db_manager.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_buffer.h"
#include "ac_tool/nb_stdx_memory.h"
#include "ac_tool/nb_core_base.h"


const uint32_t SNOW_ENV_TYPE_DS  = DB_CREATE | DB_INIT_MPOOL;
const uint32_t SNOW_ENV_TYPE_CDS = SNOW_ENV_TYPE_DS | DB_INIT_CDB;
const uint32_t SNOW_ENV_TYPE_TDS = SNOW_ENV_TYPE_DS | DB_INIT_TXN | DB_INIT_LOG | DB_INIT_LOCK | DB_THREAD; // DB_RECOVER
const uint32_t SNOW_ENV_TYPE_REP = SNOW_ENV_TYPE_TDS | DB_INIT_REP | DB_RECOVER;

const uint32_t SNOW_DB_TYPE_DS  = DB_CREATE;
const uint32_t SNOW_DB_TYPE_CDS = DB_CREATE;
const uint32_t SNOW_DB_TYPE_TDS = DB_CREATE | DB_THREAD | DB_AUTO_COMMIT;
const uint32_t SNOW_DB_TYPE_REP = DB_AUTO_COMMIT | DB_THREAD;
const uint32_t SNOW_DB_TYPE_VER = SNOW_DB_TYPE_TDS | DB_MULTIVERSION;


/**************************************************************************
**
** 	nbnv : Berkeley DB - DbEnv encapsulation
**
**************************************************************************/
class nbnv
{
protected:
    DbEnv m_env_;
    const std::string m_dbhome_;

public:
    static void recover(const std::string dbhome)
    {
        nbnv env(dbhome, SNOW_ENV_TYPE_TDS | DB_RECOVER);
    }

    static void catastrophic_recover(const std::string dbhome)
    {
        nbnv env(dbhome, SNOW_ENV_TYPE_TDS | DB_RECOVER_FATAL);
    }

public:
    // we can pass DB_CXX_NO_EXCEPTIONS to m_env_ to suppress exception
    nbnv(const std::string dbhome, uint32_t flags = SNOW_ENV_TYPE_TDS | DB_RECOVER)
        : m_env_(0), m_dbhome_(dbhome)
    {
        openenv(dbhome, flags);

        // add to db env manager
        nb_db_manager::instance().add_env(&m_env_);
    }

    ~nbnv()
    {
        nb_db_manager::instance().remove_env(&m_env_);

        closeenv();
    }

    DbEnv& get_env()
    {
        return m_env_;
    }

    const DbEnv& get_env() const
    {
        return m_env_;
    }

    std::string get_home() const
    {
        return m_dbhome_;
    }

    // override memthods
    int openenv(const std::string dbhome, u_int32_t flags);

    int closeenv();
};


/**************************************************************************
**
** 	nbdbc : Berkeley DB - Dbc encapsulation
**
**************************************************************************/
class nbdbc
{
private:
    Dbc* m_dbc;

public:
    nbdbc(Db* dbp, DbTxn* txn = NULL)
    {
        int ret;
        if ((ret = dbp->cursor(txn, &m_dbc, 0)) != 0)
        {
            assert(!"nbdbc : open cursor error.");
        }
    }

    ~nbdbc()
    {
        try
        {
            m_dbc->close();
        }
        catch (DbException& e)
        {
            LOG_ERROR("~nbdbc : " << e.what());
        }
    }

    Dbc* operator->() throw()
    {
        return m_dbc;
    }

    const Dbc* operator->() const throw()
    {
        return m_dbc;
    }

    int write(const void* key, u_int32_t nkey, const void* data, u_int32_t ndata);

    int read(std::string& strkey, std::string& strval);

    template <typename _DataType>
    int read(auto_buffer<_DataType>& keybuf, auto_buffer<_DataType>& buf);
};


/**************************************************************************
**
** 	nbdb : Berkeley DB - DbEnv & Db encapsulation
**
**************************************************************************/
class nbdb
{
private:
    nbnv& m_env_;
    Db* m_dbp_;
    //Db* m_sdbp_;

    //For error log
    const std::string m_dbfile_;
    const std::string m_dbname_;

public:
    nbdb(const std::string& dbfile, const std::string& dbname, nbnv& env,
        u_int32_t flags = SNOW_DB_TYPE_VER, bool dupsort = false)
        : m_env_(env),
        m_dbp_(NULL),
        m_dbfile_(dbfile), m_dbname_(dbname)
    {
        this->open_(dbfile, dbname, dupsort, flags);
    }

    ~nbdb()
    {
        this->close_();
    }

    Db* get_db() 
    {
        return m_dbp_;
    }

    const Db* get_db() const
    {
        return m_dbp_;
    }

    std::string get_db_file() const
    {
        return m_dbfile_;
    }

    std::string get_db_name() const
    {
        return m_dbname_;
    }

    size_t size(DbTxn* txn = NULL);

    bool exists(const std::string& strkey, DbTxn* txn = NULL, uint32_t flags = 0);

    int read(const std::string& strkey, std::string& strval, DbTxn* txn = NULL);

    int write(const std::string& strkey, const std::string& strval, DbTxn* txn = NULL, uint32_t flags = 0);

    int write_multiple(const std::map<std::string, std::string>& data, DbTxn* txn = NULL);

    int del(const std::string& strkey, DbTxn* txn = NULL);

    int truncate(DbTxn* txn = NULL);

    int txn_begin(DbTxn*& txn)
    {
        return m_env_.get_env().txn_begin(NULL, &txn, 0);
    }

    int txn_snapshot_begin(DbTxn*& txn)
    {
        return m_env_.get_env().txn_begin(NULL, &txn, DB_TXN_SNAPSHOT);
    }

    int commit(DbTxn*& txn)
    {
        return txn->commit(0);
    }

    int rollback(DbTxn*& txn)
    {
        return txn->abort();
    }

private:

    int open_(const std::string& dbfile, const std::string& dbname, bool dupsort, u_int32_t flags);

    void close_();

    //hook method
    void prewrite_()
    { }

};



#endif // _NB_BDB_H
 
// vim:set tabstop=4 shiftwidth=4 expandtab:
