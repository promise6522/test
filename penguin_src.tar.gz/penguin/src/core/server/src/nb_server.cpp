/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <boost/bind.hpp>
#include <iostream>

#include "nb_server.h"

nb_server::nb_server(const std::string& address, const std::string& port, std::size_t io_service_pool_size)
    : m_io_service_pool(io_service_pool_size),
      m_acceptor(m_io_service_pool.get_io_service()),
      m_ptr_new_connection(new nb_connection(m_io_service_pool.get_io_service()))
{
    // Open the acceptor with the option to reuse the address (i.e. SO_REUSEADDR).
    boost::asio::ip::tcp::resolver resolver(m_acceptor.get_io_service());
    boost::asio::ip::tcp::resolver::query query(address, port);
    boost::asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);
    m_acceptor.open(endpoint.protocol());
    m_acceptor.set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
    m_acceptor.set_option(boost::asio::ip::tcp::acceptor::keep_alive(true));
    //m_acceptor.set_option(boost::asio::ip::tcp::acceptor::send_buffer_size(56789900));
    m_acceptor.bind(endpoint);
    m_acceptor.listen();
    m_acceptor.async_accept(m_ptr_new_connection->socket(),
                            boost::bind(&nb_server::handle_accept, this,
                                        boost::asio::placeholders::error));
}

void nb_server::run()
{
    m_io_service_pool.run();
}

void nb_server::stop()
{
    m_io_service_pool.stop();
}

void nb_server::handle_accept(const boost::system::error_code& e)
{
    if (!e)
    {
        m_ptr_new_connection->start();
        m_ptr_new_connection.reset(new nb_connection(m_io_service_pool.get_io_service()));
        m_acceptor.async_accept(m_ptr_new_connection->socket(),
                                boost::bind(&nb_server::handle_accept, this,
                                            boost::asio::placeholders::error));
    }
}
