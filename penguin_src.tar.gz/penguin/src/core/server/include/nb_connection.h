/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_CONNECTION_H_
#define _NB_CONNECTION_H_

#include <boost/asio.hpp>
#include <boost/array.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/bind.hpp>
#include <string>
#include <sstream>
#include <iostream>

#include "nb_request_handler.h"
#include "stdx_log.h"

const int sharing_message_header_length = 4;

#define NB_SERVER_ASYNC_WRITE

/// Represents a single connection from a client.
class nb_connection
    : public boost::enable_shared_from_this<nb_connection>,
      private boost::noncopyable
{
public:
    /// Construct a connection with the given io_service.
    explicit nb_connection(boost::asio::io_service& io_service)
        : m_socket(io_service),
          m_ptr_request_handler(new(std::nothrow) nb_request_handler(boost::bind(&nb_connection::async_write, this, _1)))
    {
        LOG_DEBUG("nb_connection: Create new nb_connection");
    }

    ~nb_connection()
    {
        LOG_DEBUG("nb_connection: Destory nb_connection");
    }

    /// Get the socket associated with the connection.
    boost::asio::ip::tcp::socket& socket()
    {
        return m_socket;
    }
        
    /// Start the first asynchronous operation for the connection.
    void start()
    {
        m_socket.async_read_some(boost::asio::buffer(m_inbound_header),
                                 boost::bind(&nb_connection::handle_read_header, shared_from_this(),
                                             boost::asio::placeholders::error,
                                             boost::asio::placeholders::bytes_transferred));
    }
        
public:
    void handle_read_header(const boost::system::error_code& e, std::size_t bytes_transferred)
    {
        if(!e)
        {
            m_inbound_len = (m_inbound_header[3] << 24) | ((m_inbound_header[2] << 16) & 0xFF0000) 
                | ((m_inbound_header[1] << 8) & 0xFF00) | (m_inbound_header[0] & 0xFF);
            m_inbound_len = ntohl(m_inbound_len);
            //std::cout<<"inbound data size = "<<m_inbound_len<<", transferred bytes = "
            //<< bytes_transferred <<std::endl;
            // Start an asynchronous call to receive the data.
            m_inbound_data.resize(m_inbound_len);
            boost::asio::async_read(m_socket,boost::asio::buffer(m_inbound_data),
                                    boost::bind(&nb_connection::handle_read_data, shared_from_this(),
                                                boost::asio::placeholders::error,
                                                boost::asio::placeholders::bytes_transferred));
            return;
        }

        // If an error occurs then no new asynchronous operations are started. This
        // means that all shared_ptr references to the connection object will
        // disappear and the object will be destroyed automatically after this
        // handler returns. The connection class's destructor closes the socket.
        m_ptr_request_handler->handle_exception(e);
        LOG_DEBUG("nb_connection::handle_read_header socket error : "<<e.value()<<"("<<e.message()<<")");
    }    

    void handle_read_data(const boost::system::error_code& e, std::size_t bytes_transferred)
    {
        if(!e)
        {
            if(m_inbound_len > bytes_transferred)
            {
                LOG_ERROR("read size = "<<bytes_transferred<<" is not same as announce size="<<m_inbound_len);
            }
            else
            {
                m_ptr_request_handler->handle_request(m_inbound_data);
            }

            boost::asio::async_read(m_socket, boost::asio::buffer(m_inbound_header),
                                    boost::bind(&nb_connection::handle_read_header, shared_from_this(),
                                                boost::asio::placeholders::error,
                                                boost::asio::placeholders::bytes_transferred));
            return;            
        }

        // If an error occurs then no new asynchronous operations are started. This
        // means that all shared_ptr references to the connection object will
        // disappear and the object will be destroyed automatically after this
        // handler returns. The connection class's destructor closes the socket.
        m_ptr_request_handler->handle_exception(e); 
        LOG_DEBUG("nb_connection::handle_read_data socket error : "<<e.value()<<"("<<e.message()<<")");
    }
    
    void async_write(const std::vector<char>& outbound_data)
    {
        std::size_t len = outbound_data.size();
        //LOG_DEBUG("async_write data size = "<<len + 4);

#ifndef NB_SERVER_ASYNC_WRITE
        std::string outbound_header;        
        len = htonl(len);        
        outbound_header += len & 0xff;
        outbound_header += (len >> 8) & 0xff;
        outbound_header += (len >> 16) & 0xff;
        outbound_header += (len >> 24) & 0xff;

        std::vector<boost::asio::const_buffer> buffers;        
        buffers.push_back(boost::asio::buffer(outbound_header));
        buffers.push_back(boost::asio::buffer(outbound_data));
        boost::asio::write(m_socket, buffers);
#else 
        std::tr1::shared_ptr< std::vector<char> > ptrData(new std::vector<char>);        
        len = htonl(len);        
        ptrData->push_back(len & 0xff);
        ptrData->push_back((len >> 8) & 0xff);
        ptrData->push_back((len >> 16) & 0xff);
        ptrData->push_back((len >> 24) & 0xff);
        ptrData->insert(ptrData->end(), outbound_data.begin(), outbound_data.end());

        {
            boost::mutex::scoped_lock lock(m_mutex);
            bool write_in_progress = !m_outbound_buffers.empty();
            m_outbound_buffers.push_back(ptrData);

            if(!write_in_progress)
            {
                std::tr1::shared_ptr< std::vector<char> > ptrData = m_outbound_buffers.front();
                boost::asio::async_write(m_socket,
                                         boost::asio::buffer(&(*ptrData)[0], ptrData->size()),
                                         boost::bind(&nb_connection::handle_write, shared_from_this(),
                                                     boost::asio::placeholders::error,
                                                     boost::asio::placeholders::bytes_transferred));
            }            
        }
#endif
    }

    void handle_write(const boost::system::error_code& e, std::size_t bytes_transferred)
    {
#ifdef NB_SERVER_ASYNC_WRITE
        if (!e)
        {
            {
                boost::mutex::scoped_lock lock(m_mutex);
                m_outbound_buffers.pop_front();
                if(!m_outbound_buffers.empty())
                {
                    std::tr1::shared_ptr< std::vector<char> > ptrData = m_outbound_buffers.front();
                    boost::asio::async_write(m_socket,
                                             boost::asio::buffer(&(*ptrData)[0], ptrData->size()),
                                             boost::bind(&nb_connection::handle_write, shared_from_this(),
                                                         boost::asio::placeholders::error,
                                                         boost::asio::placeholders::bytes_transferred));
                }
            }
            
            return;
        }

        m_ptr_request_handler->handle_exception(e);
        LOG_DEBUG("nb_connection::handle_write socket error : "<<e.value()<<"("<<e.message()<<")");
#endif
    }

private:
    /// Holds an inbound header.
    char m_inbound_header[sharing_message_header_length];

    /// Holds the inbound data.
    std::vector<char> m_inbound_data;

    /// Holds the length of inbound data
    uint32_t m_inbound_len;

    /// Socket for the connection.
    boost::asio::ip::tcp::socket m_socket;

    /// The handler used to process the incoming request.
    nb_request_handler_ptr m_ptr_request_handler;

#ifdef NB_SERVER_ASYNC_WRITE
    //write buffers
    std::deque< std::tr1::shared_ptr<std::vector<char> > > m_outbound_buffers;

    //mutex for m_write_buffers
    boost::mutex m_mutex;
#endif
};

typedef boost::shared_ptr<nb_connection> nb_connection_ptr;
    
#endif /* _NB_CONNECTION_H_ */
