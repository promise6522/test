/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_REQUEST_HANDLER_H_
#define _NB_REQUEST_HANDLER_H_

#include <string>
#include <boost/noncopyable.hpp>
#include <boost/system/error_code.hpp>

#include "nb_id.h"
#include "ac_manager.h"

/// The common handler for all incoming requests.
class nb_request_handler
    : public boost::enable_shared_from_this<nb_request_handler>,
      private boost::noncopyable      
{
public:
    /// Construct with a directory containing files to be served.
    explicit nb_request_handler(nb_response_callback m_asyn_write);
    ~nb_request_handler();
    
    /// Handle a request and put it into core.
    void handle_request(const std::vector<char>& inbound_data);

    /// Handle a response and send it out.
    void handle_response(const std::vector<char>& outbound_data);

    /// Handle a exception
    void handle_exception(const boost::system::error_code& e);

private:
    void send_request_to_ac(const std::vector<char>& inbound_data, const req_num_t& req_num, ac_method_t method);

private:
    /// bridge_id for this connection
    bridge_id_t m_bridge_id;

    /// user_name for this connection
    std::string m_user_name;

    /// flag for the connection
    bool m_is_connected;

     /// flag for the connection
    bool m_is_exception;

    //callback functor for asyn write
    nb_response_callback m_asyn_write;

    //request number
    req_num_t m_req_num;    
};

const std::string default_is_mode_str("is_mode");
typedef boost::shared_ptr<nb_request_handler> nb_request_handler_ptr;

#endif /* _NB_REQUEST_HANDLER_H_ */
