/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _NB_SERVER_H_
#define _NB_SERVER_H_

#include <boost/asio.hpp>
#include <string>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>

#include "nb_connection.h"
#include "nb_io_service_pool.h"
#include "nb_request_handler.h"
#include "nb_connection.h"

/// The top-level class of the NB server.
class nb_server : private boost::noncopyable
{
public:
    /// Construct the server to listen on the specified TCP address and port, and
    explicit nb_server(const std::string& address, const std::string& port,
                       std::size_t io_service_pool_size);

    /// Run the server's io_service loop.
    void run();

    /// Stop the server.
    void stop();

private:
    /// Handle completion of an asynchronous accept operation.
    void handle_accept(const boost::system::error_code& e);

    /// The pool of io_service objects used to perform asynchronous operations.
    nb_io_service_pool m_io_service_pool;

    /// Acceptor used to listen for incoming connections.
    boost::asio::ip::tcp::acceptor m_acceptor;

    /// The next connection to be accepted.
    nb_connection_ptr m_ptr_new_connection;
};


#endif /* _NB_SERVER_H_ */
