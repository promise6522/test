/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#ifndef _DUC_PARSER_H_
#define _DUC_PARSER_H_

#include "ac_message_type.h"
#include "ac_bridge_factory_helper.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "ac_bridge/ac_bridge_impl.h"
#include "ac_bridge_helper.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"
#include "nb_user_manager.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"
#include "ac_message_type.h"

class duc_parser
{
public :
    duc_parser(ac_bridge_factory_helper * pHelper, const bridge_factory_info_set& bf_info_set,
               const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        generate_outgoing_access_if(pHelper, bf_info_set, hc_id, bf_raw_datas);
        generate_bridge_decls(pHelper, bf_info_set, hc_id, bf_raw_datas);	    
    }
    duc_parser(const bridge_decl_info& decls) : m_decls(decls)
    {
    }
    ~duc_parser()
    {
    }
    
    bridge_decl_info get_decls()
    {
        return m_decls;
    }

    nb_id_t get_outgoing_access_if()
    {
        return m_out_ac_if;
    }

    void parser_parameter(const host_committer_id_t& hc_id,
                          const nb_id_t& decl_id, const nb_id_vector& src_objs,
                          nb_id_vector& dest_objs, bridge_info& info, ac_bridge_helper* pHelper)
    {
        //call start decl
        for(std::vector<id_name_pair>::iterator it = m_decls.start_decls.begin();
            it != m_decls.start_decls.end(); ++it)
        {
            if(it->id == decl_id)
            {
                duc_parser_parameter_by_name(hc_id, it->id, it->name, src_objs, dest_objs, info, pHelper);
                return;                
            }
        }

        //call default decl
        for(std::vector<id_name_pair>::iterator it = m_decls.default_decls.begin();
            it != m_decls.default_decls.end(); ++it)
        {
            if(it->id == decl_id)
            {
                duc_parser_parameter_by_name(hc_id, it->id, it->name, src_objs, dest_objs, info, pHelper);
                return;                
            }
        }

        //call general decl
        if(m_decls.general_decl.id == decl_id)
        {
            duc_parser_parameter_by_name(hc_id, decl_id, m_decls.general_decl.name, src_objs, dest_objs,
                                         info, pHelper);
        }        
    }
    
    void call_fun(const access_id_t& access_id, const nb_id_t& decl_id,
                  const nb_id_vector& input, bridge_info& info, ac_bridge_helper* pHelper)
    {
        call_func_general(access_id, decl_id, input, info, pHelper);
    }

    void handle_result(const nb_id_t& decl_id, const node_invocation_response& output,
                       bridge_info& info, ac_bridge_helper* pHelper)
    {
        //call start decl
        for(std::vector<id_name_pair>::iterator it = m_decls.start_decls.begin();
            it != m_decls.start_decls.end(); ++it)
        {
            if(it->id == decl_id)
            {
                duc_handle_result_by_name(decl_id, it->name, output, info, pHelper);
                return;                
            }
        }

        //call default decl
        for(std::vector<id_name_pair>::iterator it = m_decls.default_decls.begin();
            it != m_decls.default_decls.end(); ++it)
        {
            if(it->id == decl_id)
            {
                duc_handle_result_by_name(decl_id, it->name, output, info, pHelper);                
                return;                
            }
        }

        //call general decl
        if(m_decls.general_decl.id == decl_id)
        {
            duc_handle_result_by_name(decl_id, m_decls.general_decl.name, output, info, pHelper);
        }
    }

    void duc_parser_parameter_by_name(const host_committer_id_t& hc_id,
                                      const nb_id_t& decl_id, const std::string& fun_name,
                                      const nb_id_vector& src_objs, nb_id_vector& dest_objs,
                                      bridge_info& info, ac_bridge_helper* pHelper)
    {
        if (fun_name == "bridge_entry")
        {
            parser_bridge_entry_parameter(hc_id, decl_id, src_objs, dest_objs, info, pHelper);
        }        
        else if(fun_name == "get_shared_access")
        {            
            parser_get_shared_access_parameter(hc_id, decl_id, src_objs, dest_objs, info, pHelper);
        }
        else if (fun_name == "set_user_access_map")
        {
            parser_set_user_access_map_parameter(hc_id, decl_id, src_objs, dest_objs, info, pHelper);
        }
        else if (fun_name == "set_shared_objects")
        {
            parser_set_shared_objects_parameter(hc_id, decl_id, src_objs, dest_objs, info, pHelper);
        }
	    else if (fun_name == "set_outgoing_access")
        {
            parser_set_outgoing_access_parameter(hc_id, decl_id, src_objs, dest_objs, info, pHelper);
        }
        else
        {
            assert(!"Unkown builtin function for bridge decl!");            
        }                
    }
    
    void duc_handle_result_by_name(const nb_id_t& decl_id, const std::string& fun_name,
                                   const node_invocation_response& output,
                                   bridge_info& info, ac_bridge_helper* pHelper)
    {
        if (fun_name == "bridge_entry")
        {
            handle_bridge_entry_result(decl_id, output, info, pHelper);
        }        
        else if(fun_name == "get_shared_access")
        {            
            handle_get_shared_access_result(decl_id, output, info, pHelper);
        }
        else if (fun_name == "set_user_access_map")
        {
            handle_set_user_access_map_result(decl_id, output, info, pHelper);
        }
        else if (fun_name == "set_shared_objects")
        {
            handle_set_shared_objects_result(decl_id, output, info, pHelper);
        }
	    else if (fun_name == "set_outgoing_access")
        {
            handle_set_outgoing_access_result(decl_id, output, info, pHelper);
        }
        else
        {
            assert(!"Unkown builtin function for bridge decl!");            
        }                
    }
    
private:
    //========================helper function for generate array decls=======================
    void generate_array_expanded_decls(ac_bridge_factory_helper * pHelper,
                                       const nb_id_t& if_id, const host_committer_id_t& hc_id,
                                       if_compound_data_t& ifc_data, db_value& bf_raw_datas)
    {
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
        decl_info.committer_id = hc_id;

        nb_id_t decl_id;
        ifc_data.decls.clear(); 

        decl_expanded_data_t decl_data;
        decl_data.expanded_ifs.push_back(if_id);

        nb_id_vector decl_ids_array;
        obj_impl_interface::get_builtin_instructions(nb_id_t(NB_INTERFACE_ARRAY), false, decl_ids_array);
        
        for (uint32_t i = 0; i < decl_ids_array.size(); ++i)
        {
            nb_id_t decl_id;
            obj_impl_declaration::get_instruction_name(decl_ids_array[i], decl_data.name);
            decl_data.origin_decl_id = decl_ids_array[i];
            obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
            pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
            decl_info.raw_data.object_id = decl_id;
            ifc_data.decls.push_back(decl_id);    
            bf_raw_datas.all_objects.push_back(decl_info.raw_data);
        }

        nb_id_vector builtin_decls;
        obj_impl_interface::get_general_instructions(builtin_decls);

        for (uint32_t i = 0; i < builtin_decls.size(); ++i)
            ifc_data.decls.push_back(builtin_decls[i]);
    }

    void generate_map_expanded_decls(ac_bridge_factory_helper * pHelper, const nb_id_t& key_if_id,
                                     const nb_id_t& value_if_id, const host_committer_id_t& hc_id,
				     if_compound_data_t& ifc_data, db_value& bf_raw_datas)
    {
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
        decl_info.committer_id = hc_id;

        nb_id_t decl_id;
        ifc_data.decls.clear();

        decl_expanded_data_t decl_data;
        decl_data.expanded_ifs.push_back(key_if_id);
        decl_data.expanded_ifs.push_back(value_if_id);
        
        nb_id_vector decl_ids_map;
        obj_impl_interface::get_builtin_instructions(nb_id_t(NB_INTERFACE_MAP), false, decl_ids_map);
        
        for (uint32_t i = 0; i < decl_ids_map.size(); ++i)
        {
            nb_id_t decl_id;
            obj_impl_declaration::get_instruction_name(decl_ids_map[i], decl_data.name);
            decl_data.origin_decl_id = decl_ids_map[i];
            obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
            pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
            decl_info.raw_data.object_id = decl_id;
            ifc_data.decls.push_back(decl_id);    
            bf_raw_datas.all_objects.push_back(decl_info.raw_data);
        }

        nb_id_vector builtin_decls;
        obj_impl_interface::get_general_instructions(builtin_decls);

        for (uint32_t i = 0; i < builtin_decls.size(); ++i)
            ifc_data.decls.push_back(builtin_decls[i]);
    }
    
    //=========================for generating the decls called by bridge=======================
    void generate_bridge_decls(ac_bridge_factory_helper * pHelper,
                               const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                               db_value& bf_raw_datas)
    {
        //generate_default_decls(pHelper, bf_info_set, hc_id, bf_raw_datas);
        generate_start_decls(pHelper, bf_info_set, hc_id, bf_raw_datas);
        generate_general_decls(pHelper, bf_info_set, hc_id, bf_raw_datas);
    }

    void generate_default_decls(ac_bridge_factory_helper * pHelper,
                                const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                                db_value& bf_raw_datas)
    {
        {            
            id_name_pair decl_info = {
                std::string("get_text"),
                generate_get_text(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.default_decls.push_back(decl_info);
        }

        {            
            id_name_pair decl_info = {                                         
                std::string("get_simple"),
                generate_get_simple(pHelper, bf_info_set, hc_id, bf_raw_datas),
            };
            m_decls.default_decls.push_back(decl_info);
        }

        {            
            id_name_pair decl_info = {                                         
                std::string("get_ref_size"),
                generate_get_ref_size(pHelper, bf_info_set, hc_id, bf_raw_datas),
            };
            m_decls.default_decls.push_back(decl_info);
        }
        
        {            
            id_name_pair decl_info = {
                std::string("get_all"),
                generate_get_all(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.default_decls.push_back(decl_info);
        }

        {            
            id_name_pair decl_info = {
                std::string("get_child_id_for_move"),
                generate_get_child_id_for_move(pHelper, bf_info_set, hc_id,
                                               bf_raw_datas)
            };
            m_decls.default_decls.push_back(decl_info);
        }

        {            
            id_name_pair decl_info = {
                std::string("insert_child"),
                generate_insert_child(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.default_decls.push_back(decl_info);
        }
    }

    void generate_start_decls(ac_bridge_factory_helper * pHelper,
                              const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                               db_value& bf_raw_datas)
    {
        {            
            id_name_pair decl_info = {
                std::string("get_shared_access"),
                generate_get_shared_access(pHelper, bf_info_set, hc_id,
                                               bf_raw_datas)
            };
            m_decls.start_decls.push_back(decl_info);
        }
        
        {            
            id_name_pair decl_info = {
                std::string("set_user_access_map"),
                generate_get_user_access_map(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.start_decls.push_back(decl_info);
        }

        {            
            id_name_pair decl_info = {
                std::string("set_shared_objects"),
                generate_set_shared_objects(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.start_decls.push_back(decl_info);
        }

	    {            
            id_name_pair decl_info = {
                std::string("set_outgoing_access"),
                generate_set_outgoing_access(pHelper, bf_info_set, hc_id, bf_raw_datas)
            };
            m_decls.start_decls.push_back(decl_info);
        }
    }

    void generate_general_decls(ac_bridge_factory_helper * pHelper,
                                const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                                db_value& bf_raw_datas)
    {
        id_name_pair decl_info = {
            std::string("bridge_entry"),
            generate_bridge_entry(pHelper, bf_info_set, hc_id, bf_raw_datas)
        };
        m_decls.general_decl = decl_info;
    }
    
    //1, Create declaration for "Get Text".
    nb_id_t generate_get_text(ac_bridge_factory_helper * pHelper, const bridge_factory_info_set& bf_info_set,
                              const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_text";

        ////input ports
        iport_t ip_data;
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TText");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //2, Create declaration for "Get Simple".
    nb_id_t generate_get_simple(ac_bridge_factory_helper * pHelper,
                                const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                                db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_simple";

        ////input ports
        iport_t ip_data;
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        
        ////output ports
        oport_t op_data;
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TAbstractVisible");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //3, Create declaration for "Get Ref Size".
    nb_id_t generate_get_ref_size(ac_bridge_factory_helper * pHelper,
                                  const bridge_factory_info_set& bf_info_set,
                                  const host_committer_id_t& hc_id,
                                  db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_ref_size";

        ////input ports
        iport_t ip_data;
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        
        ////output ports
        oport_t op_data;
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TSize");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //3, Create declaration for "Get All".
    nb_id_t generate_get_all(ac_bridge_factory_helper * pHelper,
                             const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                             db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_all";

        ////input ports
        //none interface
        iport_t ip_data;
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //Tsize
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TSize");
        ip_data.interface = it->if_id;        
        decl_data.iports.push_back(ip_data);
        //none object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        it = bf_info_set.get<1>().find("TAbstractVisible");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);
        //none object interface
        op_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;        
    }

    //4, Create declaration for "Bridge entry".
    nb_id_t generate_bridge_entry(ac_bridge_factory_helper * pHelper,
                                  const bridge_factory_info_set& bf_info_set, const host_committer_id_t& hc_id,
                                  db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "bridge_entry";

        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //outgoing access if
        ip_data.interface = m_out_ac_if;
        decl_data.iports.push_back(ip_data);
        //Gesture
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TGesture");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);
        //UserName
        ip_data.interface = nb_id_t(NB_INTERFACE_STRING);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //TResponseClosure
        it = bf_info_set.get<1>().find("TResponseClosure");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);
 
        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //5, Create declaration for "Get child id for move".
    nb_id_t generate_get_child_id_for_move(ac_bridge_factory_helper * pHelper,
                                           const bridge_factory_info_set& bf_info_set,
                                           const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_child_id_for_move";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TGesture
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TGesture");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);
        //TPath
        it = bf_info_set.get<1>().find("TPath");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //TResponseClosure
        it = bf_info_set.get<1>().find("TResponseClosure");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);
        //TPlacement
        it = bf_info_set.get<1>().find("TPlacement");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);
        //none object interface
        op_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.oports.push_back(op_data);
        //none object interface
        op_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //6, Create declaration for "Insert child".
    nb_id_t generate_insert_child(ac_bridge_factory_helper * pHelper,
                                  const bridge_factory_info_set& bf_info_set,
                                  const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "insert_child";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TPath
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TPath");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);
        //TPlacement
        it = bf_info_set.get<1>().find("TPlacement");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //TResponseClosure
        it = bf_info_set.get<1>().find("TResponseClosure");
        op_data.interface = it->if_id;        
        decl_data.oports.push_back(op_data);
        //none
        op_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //7, Create declaration for "Get Shared access".
    nb_id_t generate_get_shared_access(ac_bridge_factory_helper * pHelper,
                                       const bridge_factory_info_set& bf_info_set,
                                       const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "get_shared_access";

        //1. try to request access interface compound id
        nb_id_t ac_if_id;
        //1.1 fill the builtin decl for access
        if_compound_data_t ac_ifc_data;
	    ac_ifc_data.name = "access [interface]";
	    obj_impl_interface::get_general_instructions(ac_ifc_data.decls); 

        //1.2 request compound interface id
        request_nb_id_info nb_ac_if_info;
        nb_ac_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_ac_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ac_ifc_data, nb_id_t(), nb_ac_if_info.raw_data);
        pHelper->ac_id_dispenser_request_nb_id(nb_ac_if_info, ac_if_id);

        //1.3 Get compound data directly and prepare to wirte to disk
        content raw_data;
        pHelper->ac_object_get_value_sync(ac_if_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);

        ////input ports
        iport_t ip_data;
        //None object interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        op_data.interface = ac_if_id;        
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //8, Create declaration for "Get user access map".
    nb_id_t generate_get_user_access_map(ac_bridge_factory_helper * pHelper,
                                         const bridge_factory_info_set& bf_info_set,
                                         const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "set_user_access_map";

        //1. try to request access interface compound id
        nb_id_t ac_if_id;

        //1.1 fill the none decl for access
        if_compound_data_t ac_ifc_data;
	    ac_ifc_data.name = "access [interface]";
	    obj_impl_interface::get_general_instructions(ac_ifc_data.decls); 

        //1.2request compound interface id
        request_nb_id_info nb_ac_if_info;
        nb_ac_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_ac_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ac_ifc_data, nb_id_t(), nb_ac_if_info.raw_data);
        pHelper->ac_id_dispenser_request_nb_id(nb_ac_if_info, ac_if_id);

        //1.3 Get compound data directly and prepare to wirte to disk
        content raw_data;
        pHelper->ac_object_get_value_sync(ac_if_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);

        //2.1 try to request map interface compound id        
        nb_id_t if_id;
        if_compound_data_t ifc_data;
        generate_map_expanded_decls(pHelper, nb_id_t(NB_INTERFACE_STRING), ac_if_id,
                                    hc_id, ifc_data, bf_raw_datas);
        if_exp_group ife;
        ife.min_if = nb_id_t(NB_INTERFACE_STRING);
        ifc_data.groups.push_back(ife);
        ife.min_if = ac_if_id;        
        ifc_data.groups.push_back(ife);
        //2.2 request compound interface id
        request_nb_id_info nb_if_info;
        nb_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ifc_data, nb_id_t(), nb_if_info.raw_data);
        pHelper->ac_id_dispenser_request_nb_id(nb_if_info, if_id);        
        //2.3 Get compound data directly and prepare to wirte to disk
        pHelper->ac_object_get_value_sync(if_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);

        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //map
        ip_data.interface = if_id;
        decl_data.iports.push_back(ip_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //8, Create declaration for "Get shared objects".
    nb_id_t generate_set_shared_objects(ac_bridge_factory_helper * pHelper,
                                        const bridge_factory_info_set& bf_info_set,
                                        const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "set_shared_objects";

        nb_id_t if_id;        
        //fill the compound data
        if_compound_data_t ifc_data;        
        //ifc_data.type = NB_INTERFACE_ARRAY_TYPE;
        generate_array_expanded_decls(pHelper, nb_id_t(NB_INTERFACE_NONE), hc_id, ifc_data, bf_raw_datas);
        
        if_exp_group ife;
        ife.min_if = nb_id_t(NB_INTERFACE_NONE);
        ifc_data.groups.push_back(ife);

        //request compound interface id
        request_nb_id_info nb_if_info;
        nb_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ifc_data, nb_id_t(), nb_if_info.raw_data);
        pHelper->ac_id_dispenser_request_nb_id(nb_if_info, if_id);
        
        //Get compound data directly and prepare to wirte to disk
        content raw_data;
        pHelper->ac_object_get_value_sync(if_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);

        //Get compound interface decls
        nb_id_t comp_id;        
        obj_impl_interface_compound::unpack(raw_data, comp_id, ifc_data);
        for(nb_id_vector::iterator it = ifc_data.decls.begin(); it != ifc_data.decls.end(); ++it)
        {
            pHelper->ac_object_get_value_sync(*it, raw_data);
            bf_raw_datas.all_objects.push_back(raw_data);            
        }        

        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //array
        ip_data.interface = if_id;
        decl_data.iports.push_back(ip_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;        
    }

    nb_id_t generate_set_outgoing_access(ac_bridge_factory_helper * pHelper,
					 const bridge_factory_info_set& bf_info_set,
					 const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
        decl_compound_data_t decl_data;
        decl_data.name = "set_outgoing_access";

        ////input ports
        iport_t ip_data;
	    //none interface
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //access interface
        ip_data.interface = m_out_ac_if;
        decl_data.iports.push_back(ip_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = hc_id;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    //=========================for generating the decls called by bridge=======================
    nb_id_t generate_send_out_async_decl(ac_bridge_factory_helper * pHelper,
			    const bridge_factory_info_set& bf_info_set,
			    const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
	    decl_compound_data_t decl_data;
        decl_data.name = "send_out_async";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TNone
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TNone");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //None
        op_data.interface = nb_id_t(NB_INTERFACE_BOOL);
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    nb_id_t generate_send_out_sync_decl(ac_bridge_factory_helper * pHelper,
			    const bridge_factory_info_set& bf_info_set,
			    const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {
	    decl_compound_data_t decl_data;
        decl_data.name = "send_out_sync";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TNone
        bf_info_set_by_name::iterator it = bf_info_set.get<1>().find("TNone");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //TNone
        it = bf_info_set.get<1>().find("TNone");
        op_data.interface = it->if_id;
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC;
        decl_info.committer_id = hc_id;        
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;
        bf_raw_datas.all_objects.push_back(decl_info.raw_data);

        return decl_id;
    }

    void generate_outgoing_access_if(ac_bridge_factory_helper * pHelper,
				     const bridge_factory_info_set& bf_info_set,
				     const host_committer_id_t& hc_id, db_value& bf_raw_datas)
    {

        if_compound_data_t ac_ifc_data;
	    ac_ifc_data.name = "outgoing_access [interface]";
	    obj_impl_interface::get_general_instructions(ac_ifc_data.decls);
        
        {
            nb_id_t decl_id  = generate_send_out_sync_decl(pHelper, bf_info_set, hc_id, bf_raw_datas);
            id_name_pair decl_info = {std::string("send_out_sync"), decl_id};
            m_decls.default_decls.push_back(decl_info);
            ac_ifc_data.decls.push_back(decl_id);
        }

        {
            nb_id_t decl_id  = generate_send_out_async_decl(pHelper, bf_info_set, hc_id, bf_raw_datas);
            id_name_pair decl_info = {std::string("send_out_async"), decl_id};
            m_decls.default_decls.push_back(decl_info);
            ac_ifc_data.decls.push_back(decl_id);
        }

        request_nb_id_info nb_ac_if_info;
        nb_ac_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_ac_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ac_ifc_data, nb_id_t(), nb_ac_if_info.raw_data);
        pHelper->ac_id_dispenser_request_nb_id(nb_ac_if_info, m_out_ac_if);

        content raw_data;
        pHelper->ac_object_get_value_sync(m_out_ac_if, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);	
    }

    //=========================for parser the parameter before call the decl=======================
    void parser_bridge_entry_parameter(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                       const nb_id_vector& in_objs, nb_id_vector& out_objs,
                                       bridge_info& info, ac_bridge_helper* pHelper)
    {
        assert(in_objs.size() == 1);
                
        //call get_value_sync for TInformServer because the bridge object should be in 
        content raw_data;
        bool ret = pHelper->ac_object_get_value_sync(in_objs[0], raw_data);
        assert(ret);

        //Push first parameter none 
        out_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));

        //Push second parameter outgoing access
        out_objs.push_back(info.outgoing_ac);
        
        //Push third parameter TGesture 
        bridge_data_t info_data;        
        nb_id_t id;        
        obj_impl_bridge::unpack(raw_data, id, info_data);
        assert(info_data.subobjs.size() == 1);
        out_objs.push_back(info_data.subobjs[0]);

        //Push fourth parameter username
        out_objs.push_back(info.user_name_id);
    }
    
    void parser_get_shared_access_parameter(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                            const nb_id_vector& src_objs, nb_id_vector& dest_objs,
                                            bridge_info& info, ac_bridge_helper* pHelper)
    {
        dest_objs.clear();        
        dest_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));        
    }

    void parser_set_user_access_map_parameter(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                              const nb_id_vector& src_objs, nb_id_vector& dest_objs,
                                              bridge_info& info, ac_bridge_helper* pHelper)
    {
        //0. Clear the dest vector
        dest_objs.clear();        
        
        //1. Try to get set_user_access_map's declaration data
        decl_compound_data_t decl_comp_data;
        nb_id_t id;        
        obj_impl_decl_compound::unpack(info.decl_data_map[decl_id], id, decl_comp_data);
        assert(decl_comp_data.iports.size() == 2);        

        //2. start fill the data structure.
        map_data_t map_data;
        //map_data.interface = nb_id_t(NB_INTERFACE_MAP);
        map_data.type = decl_comp_data.iports[1].interface;

        //3. read the user access map from database
        std::map<std::string, access_id_t> user_access_map;
        nb_user_manager::instance().get_shared_user_access_map(user_access_map);
        for(std::map<std::string, access_id_t>::iterator it = user_access_map.begin();
            it != user_access_map.end(); ++it)
        {
            nb_id_t str_id;            
            request_nb_id_info str_info;
            str_info.committer_id = info.hc_id;
            str_info.type = NBID_TYPE_OBJECT_STRING;
            obj_impl_string::pack(it->first, nb_id_t(), str_info.raw_data);            
            pHelper->ac_host_committer_request_nb_id(hc_id, str_info, str_id);            
            map_data.data.insert(std::make_pair(str_id, it->second));            
        }        

        content map_raw_data;
        obj_impl_map::pack(map_data, nb_id_t(), map_raw_data);
    
        request_nb_id_info map_info = {map_raw_data, NBID_TYPE_OBJECT_MAP, info.hc_id};
        nb_id_t map_id;
        pHelper->ac_host_committer_request_nb_id(hc_id, map_info, map_id);

        //1. push first parameter none
        dest_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));

        //2. push second parameter map
        dest_objs.push_back(map_id);
    }
    

    void parser_set_shared_objects_parameter(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                             const nb_id_vector& src_objs, nb_id_vector& dest_objs,
                                             bridge_info& info, ac_bridge_helper* pHelper)
    {
        //0. Clear the dest vector
        dest_objs.clear();        
        
        //1. Try to get set_shared_objects's declaration data
        decl_compound_data_t decl_comp_data;
        nb_id_t id;        
        obj_impl_decl_compound::unpack(info.decl_data_map[decl_id], id, decl_comp_data);
        assert(decl_comp_data.iports.size() == 2);        

        //2. start fill the data structure.
        array_data_t array_data;
        //array_data.interface = nb_id_t(NB_INTERFACE_ARRAY);
        array_data.type = decl_comp_data.iports[1].interface;

        //3. read the user shared object from database
        nb_id_vector shared_objs;
        std::vector<container_id_t> shared_conts;
        nb_user_manager::instance().get_user_shared_objs(info.user_name, shared_objs, shared_conts);
        for(nb_id_vector_it it = shared_objs.begin(); it != shared_objs.end(); ++it)
        {
            array_data.objs.push_back(*it);            
        }

        //4. start request array object
        content array_raw_data;
        obj_impl_array::pack(array_data, nb_id_t(), array_raw_data);    
        request_nb_id_info array_info = {array_raw_data, NBID_TYPE_OBJECT_ARRAY, info.hc_id};
        nb_id_t array_id;
        pHelper->ac_host_committer_request_nb_id(hc_id, array_info, array_id);

        //1. push first parameter none
        dest_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));

        //2. push second parameter array
        dest_objs.push_back(array_id);
    }

    void parser_set_outgoing_access_parameter(const host_committer_id_t& hc_id, const nb_id_t& decl_id,
                                              const nb_id_vector& src_objs, nb_id_vector& dest_objs,
                                              bridge_info& info, ac_bridge_helper* pHelper)
    {
        dest_objs.clear();        
        dest_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));
	    dest_objs.push_back(nb_id_t(NBID_TYPE_OBJECT_NONE));      
    }

    //=========================for call the decl in access=======================
    void call_func_general(const access_id_t& access_id, const nb_id_t& decl_id,
                           const nb_id_vector& input, bridge_info& info, ac_bridge_helper* pHelper)
    {        
        nb_id_t access_nb_id;    
        access_id.to_nb_id(access_nb_id);

        //request child transaction
        transaction_id_t trans_id;
        if(!pHelper->ac_id_dispenser_request_transaction_id(info.hc_id, trans_id))
        {
            return;
        }
        trans_comm_pair_t tc_pair;
        tc_pair.m_transaction_id = info.trans_id;
        tc_pair.m_host_committer_id = info.hc_id;
        if(!pHelper->ac_transaction_begin(trans_id, info.req_num, tc_pair))
        {
            return;
        }        
       
        assert(input.size() > 0); 
        node_invocation_request execution_parameter = {
                info.exe_id,
                decl_id,
                trans_id,        
                container_id_t(),
                info.hc_id,
                input[0],
                nb_id_vector(input.begin() + 1, input.end())
            };

        //Get execution_parameter from m_impl
        pHelper->ac_access_run(access_id, info.req_num, execution_parameter);
    }
    

    //=========================for handle the result after access execution=======================
    void handle_bridge_entry_result(const nb_id_t& decl_id, const node_invocation_response& output,
                                    bridge_info& info, ac_bridge_helper* pHelper)
    {
        LOG_DEBUG("handle_bridge_entry_result....");
        info.out_objs = output.output.objects;
        bridge_end_response bridge_res = {info.hc_id, output};
        if(!pHelper->ac_execution_trigger_end(info.exe_id, info.req_num, bridge_res))
        {
            return;
        }
    }

    void handle_get_shared_access_result(const nb_id_t& decl_id, const node_invocation_response& output,
                                         bridge_info& info, ac_bridge_helper* pHelper)
    {
        LOG_DEBUG("handle_get_shared_access_result....");
        assert(output.output.objects.size() == 1);

        access_id_t ac_id;
        output.output.objects[0].to_access_id(ac_id);
        LOG_DEBUG("set_shared_access: "<<ac_id.str());
        nb_user_manager::instance().set_shared_access_by_user(info.user_name, ac_id);        
    }
    
    void handle_set_user_access_map_result(const nb_id_t& decl_id, const node_invocation_response& output,
                                           bridge_info& info, ac_bridge_helper* pHelper)
    {
        LOG_DEBUG("handle_set_user_access_map_result....");        
    }
    
    void handle_set_shared_objects_result(const nb_id_t& decl_id, const node_invocation_response& output,
                                          bridge_info& info, ac_bridge_helper* pHelper)
    {
        LOG_DEBUG("handle_set_shared_objects_result....");        
    }

    void handle_set_outgoing_access_result(const nb_id_t& decl_id, const node_invocation_response& output,
					   bridge_info& info, ac_bridge_helper* pHelper)
    {
        LOG_DEBUG("handle_set_outgoing_access_result....");        
    }
    
private:
    bridge_decl_info m_decls;
    nb_id_t m_out_ac_if;
};    

#endif /* _DUC_PARSER_H_ */
