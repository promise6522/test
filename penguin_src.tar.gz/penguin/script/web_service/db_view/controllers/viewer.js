
var config = require('../config');
var db_helper = require('../db_helper')

exports.index = function(req, res) {
    db_helper.get_all_users(function(users){
            console.log(users);
            res.render('index', {users: users.users});});
};

exports.query_id = function(req, res, next) {
    db_helper.get_value_by_id(req.params.id, function(value) {
            if(req.params.id.indexOf("80") == 0)
            {
                res.render('element/nb_object', {id: req.params.id, 
                                                 ac_db: value.ac_db, media_db: value.media_db});
            }
            else if(req.params.id.indexOf("86") == 0)
            {
                res.render('element/nb_impl', {id: req.params.id, 
                                               ac_db: value.ac_db, media_db: value.media_db});
            }
            else
            {
                res.render('element/nb_common', {id: req.params.id, 
                                                 ac_db: value.ac_db, media_db: value.media_db});
            }
        });
};

exports.search_id = function(req, res, next) {
    var title = req.query.title || '';
    title = title.trim();
    if(title.length != 16 && title.length != 32) {
        return res.render('error', {message: 'Please input 128 bit or 256 bit nb id!'});
    }
    db_helper.get_value_by_id(title, function(value) {
            res.render('element/nb_object', {id: title, 
                        ac_db: value.ac_db, media_db: value.media_db});
        });
};

exports.user = function(req, res, next) {
    var user_handles = {};
    db_helper.get_user_info(req.params.id, user_handles, function(user_handles) {
            db_helper.get_user_tmp_info(req.params.id, user_handles, function(user_handles) {
                    res.render('user/user_info', {user: req.params.id, user_handles: user_handles});})});
};

/*
exports.index = function(req, res) {
    db.query('select * from todo order by finished asc, id asc limit 50', function(err, rows) {
        if(err) return next(err);
        res.render('index', {todos: rows});
    });
};

exports.new = function(req, res, next) {
    var title = req.body.title || '';
    title = title.trim();
    if(!title) {
        return res.render('error', {message: '标题是必须的'});
    }
    db.query('insert into todo set title=?, post_date=now()', [title], function(err, result) {
        if(err) return next(err);
        res.redirect('/');
    });
};

exports.view = function(req, res, next) {
    res.redirect('/');
};

exports.edit = function(req, res, next) {
    var id = req.params.id;
    db.query('select * from todo where id=?', [id], function(err, rows) {
        if(err) return next(err);
        if(rows && rows.length > 0) {
            var row = rows[0];
            res.render('todo/edit', {todo: row});
        } else {
            next();
        }
    });
};

exports.save = function(req, res, next) {
    var id = req.params.id;
    var title = req.body.title || '';
    title = title.trim();
    if(!title) {
        return res.render('error', {message: '标题是必须的'});
    }
    db.query('update todo set title=? where id=?', [title, id], function(err, result) {
        if(err) return next(err);
        res.redirect('/');
    });
};

exports.delete = function(req, res, next) {
    var id = req.params.id;
    db.query('delete from todo where id = ?', [id], function(err) {
        if(err) return next(err);
        res.redirect('/');
    });
};

exports.finish = function(req, res, next) {
    var finished = req.query.status === 'yes' ? 1 : 0;
    var id = req.params.id;
    db.query('update todo set finished=? where id=?', [finished, id], function(err, result) {
        if(err) return next(err);
        res.redirect('/');
    });
};
*/