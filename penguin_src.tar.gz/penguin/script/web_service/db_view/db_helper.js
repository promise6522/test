var assert = require('assert');
var exec  = require('child_process').exec;
var fs = require('fs');
var BDB = require('bdb');

unpack_dukeid_vector = function(handles_str) {
    if(handles_str.length == 0)
        return [];
    handles_str = handles_str.substring(1, handles_str.length-1);
    return handles_str.split(")(");
};

media_read_handles = function(key, callback)
{
    var env_location = __dirname + "/../../../build/dbverify0";
    var env = new BDB.DbEnv();
    var flags = BDB.DB_CREATE | BDB.DB_INIT_MPOOL | BDB.DB_INIT_CDB
              | BDB.DB_INIT_TXN | BDB.DB_INIT_LOG | BDB.DB_INIT_LOCK | BDB.DB_THREAD;
    var close_flags = 0;

    var stat = env.openSync({home: env_location, flags: flags});
    assert.equal(0, stat.code, stat.message);

    var db = new BDB.Db(env);
    stat = db.openSync({env: env, file: "verifyd.db", dbname:"idvalue"});

    var key_ = new Buffer(key);

    db.get({key: key_}, function(res, data){
            var handles_str = data.toString(encoding='utf8');  
            db.closeSync();
            env.closeSync({flags: close_flags});
            callback(handles_str);})
};

media_get_handles = function(key, callback) {
    media_read_handles(key, function(handles_str){
            var handles = unpack_dukeid_vector(handles_str);
            callback(handles);});
};

ac_object_db_get = function(key_, callback) {

    var env_location = __dirname + "/../../../build/dbobject0";
    var env = new BDB.DbEnv();
    var flags = BDB.DB_CREATE | BDB.DB_INIT_MPOOL | BDB.DB_INIT_CDB
              | BDB.DB_INIT_TXN | BDB.DB_INIT_LOG | BDB.DB_INIT_LOCK | BDB.DB_THREAD;
    var close_flags = 0;
    
    var stat = env.openSync({home: env_location, flags: flags});
    assert.equal(0, stat.code, stat.message);

    var db = new BDB.Db(env);
    stat = db.openSync({env: env, file: "test.db", dbname:"idvalue"});

    var key = new Buffer(key_);
    db.get({key: key}, function(res, data){
            db.closeSync();
            env.closeSync({flags: close_flags});
            callback(data.toString(encoding='utf8'));});    
}

duke_object_db_get = function(key_, callback) {

    var env_location = __dirname + "/../../../build/dboldobject0";
    var env = new BDB.DbEnv();
    var flags = BDB.DB_CREATE | BDB.DB_INIT_MPOOL | BDB.DB_INIT_CDB
              | BDB.DB_INIT_TXN | BDB.DB_INIT_LOG | BDB.DB_INIT_LOCK | BDB.DB_THREAD;
    var close_flags = 0;
    
    var stat = env.openSync({home: env_location, flags: flags});
    assert.equal(0, stat.code, stat.message);

    var db = new BDB.Db(env);
    stat = db.openSync({env: env, file: "oldobjectd.db", dbname:"oldidvalue"});

    var key = new Buffer(key_);
    db.get({key: key}, function(res, data){
            db.closeSync();
            env.closeSync({flags: close_flags});
            callback(data.toString(encoding='utf8'));});    
}

//---------------------------------export function------------------------------------

exports.get_value_by_id = function(key, callback) {
    var value = {};
    ac_object_db_get(key, function(strval){
            value.ac_db = strval;
            duke_object_db_get(key, function(strval) {
                    value.media_db = strval
                    callback(value);});
            });
}

exports.get_all_users = function(callback)
{
    var env_location = __dirname + "/../../../build/dbbridge0";
    var env = new BDB.DbEnv();
    var flags = BDB.DB_CREATE | BDB.DB_INIT_MPOOL | BDB.DB_INIT_CDB
              | BDB.DB_INIT_TXN | BDB.DB_INIT_LOG | BDB.DB_INIT_LOCK | BDB.DB_THREAD;
    var close_flags = 0;
    
    var stat = env.openSync({home: env_location, flags: flags});
    assert.equal(0, stat.code, stat.message);

    var db = new BDB.Db(env);
    stat = db.openSync({env: env, file: "test.db", dbname:"keyvalue"});

    var key = new Buffer("nb_register_users_info");
    db.get({key: key}, function(res, data){
            assert.equal(0, res.code, res.message);
            var users;            
            eval( 'users = ' + data.toString(encoding='utf8') + ';' );
            db.closeSync();
            env.closeSync({flags: close_flags});
            callback(users);});    
};

exports.get_user_info = function(user, user_handles, callback) {
    media_get_handles(user + "-object", function(handles) {
            user_handles.User_object = handles;
            media_get_handles(user + "-interface", function(handles) {
                    user_handles.Interface = handles;
                    media_get_handles(user + "-declare", function(handles) {
                            user_handles.Declaration = handles;
                            media_get_handles(user + "-implement", function(handles) {
                                    user_handles.Implementation = handles;
                                    media_get_handles(user + "-container", function(handles) {
                                            user_handles.Container = handles;
                                            media_get_handles(user + "-anchor", function(handles) {
                                                    user_handles.Anchor = handles;
                                                    media_get_handles(user + "-access", function(handles) {
                                                            user_handles.Access = handles;
                                                            callback(user_handles);})})})})})})});
};

exports.get_user_tmp_info = function(user, user_handles, callback) {
    media_get_handles(user + "-tmp-object", function(handles) {
            user_handles.Temp_User_object = handles;
            media_get_handles(user + "-tmp-interface", function(handles) {
                    user_handles.Temp_Interface = handles;
                    media_get_handles(user + "-tmp-declare", function(handles) {
                            user_handles.Temp_Declaration = handles;
                            media_get_handles(user + "-tmp-implement", function(handles) {
                                    user_handles.Temp_Implementation = handles;
                                    media_get_handles(user + "-tmp-container", function(handles) {
                                            user_handles.Temp_Container = handles;
                                            media_get_handles(user + "-tmp_anchor", function(handles) {
                                                    user_handles.Temp_Anchor = handles;
                                                    media_get_handles(user + "-tmp_access", function(handles) {
                                                            user_handles.Temp_Access = handles;
                                                            callback(user_handles);})})})})})})});
};
    
exports.get_user_objects = function(user, callback)
{
    media_get_handles(user + "-object", function(handles) {
            callback(handles);});
};





    
