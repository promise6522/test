exports.port = 8080;
exports.email='ning.xiao@nebutown.com';
exports.site_name = 'Nebutown Database Viewer';
exports.site_desc = '';
exports.session_secret = 'tsoedsosisession_secretonsheecfrxedta';
