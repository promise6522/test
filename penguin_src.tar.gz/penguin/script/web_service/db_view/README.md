# DB View nb_id

## Description

## Install

    $ Install nodejs (following the instructions - https://github.com/joyent/node/wiki/Installation)
    $ cd node_modules/bdb/ or get it from "https://github.com/mcavage/node-bdb"(Attend: need change)
    $ change the bdb version to current version(4.7/4.8) in wscript
    $ node-waf configure --shared-bdb-includes /user/include/ --shared-bdb-libpath /user/lib/
    $ node-waf build
    
## Run
    
    $ node server.js
