require 'rexml/document'
include REXML

class XMLData
  attr_reader :errors, :element_type
  attr_accessor :name
  
  def initialize(name, type)
    @errors = []
    @name = name
    @element_type = type
    
    #puts "creating unit " + type + ": " + name
  end

  def add_error(error)
    @errors << error
  end
  
  def print_error(path)
    if @errors.length > 0
      puts "----------------------- reporting from " + @name + ", a " + @element_type
      @errors.each {
        |e|
        puts path + " ==> " + e
      }
    end
  end
  
  def print_errors(path, sub)
    sub.each {
      |s|
      s.print_error(path + "/" + s.name + "(" + s.element_type + ")")
    }
  end

  def checkup(core)
  end

  def check_them(core, collection)
    collection.each { 
      |d|
      d.checkup(core)
    }
  end
end

class Core < XMLData
  attr_reader :builtin_types, :enums, :types
    
  def initialize(dir_name)
    super("core", "core")
    @files = []
    @builtin_types = {}
    @types = {}
    @enums = {}
    
    if not File.exist?(dir_name)
      puts "file does not exist: " + dir_name
      return
    end
    
    if File.directory?(dir_name)
      Dir.foreach(dir_name) {
        |f| 
        if f.end_with?(".xml")
          @files << XMLFile.new(dir_name + "/" + f)
        end
      }
    elsif dir_name.end_with?(".xml")
      @files << XMLFile.new(dir_name)
    else
      puts "file is not xml: " + dir_name
      return
    end
    
    checkup
  end

  def checkup
    @files.each {
      |f|
      add_them("builtin_types", @builtin_types, f.builtin_types)
      add_them("types", @types, f.types)
      add_them("enums", @enums, f.enums)
    }
    check_them(self, @builtin_types.values)
    check_them(self, @types.values)
    check_them(self, @enums.values)
  end

  def add_them(label, collection, data)
    data.each { 
      |d|
      n = d.name
      if collection[n] != nil
        add_error("Repeated definition for " + label + ": " + n)
      end
      collection[n] = d
    }
  end

  def print_error(path)
    super(path)
    print_errors(path, @types.values)
  end
end
  
class XMLFile < XMLData

  attr_reader :actors, :types, :builtin_types, :enums

  def initialize(file)
    super(file, "file")
    @builtin_types = []
    @types = []
    @enums = []
     
    root = Document.new(File.new(file)).root
    ns = root.attributes["namespace"]
      
    root.elements.each {
      |e| 
      if e.expanded_name == "builtin"
        @builtin_types << Builtin.new(ns, e)
      elsif e.expanded_name == "type"
        @types << Type.new(ns, e)
      elsif e.expanded_name == "enum"
        @enums << Enum.new(ns, e)
      end
    }    
  end

end

class Builtin < XMLData
  attr_reader :namespace

  def initialize(ns, xml)
    super(xml.attribute("name").to_s, "builtin")
  end  

end  

class Enum < XMLData
  attr_reader :namespace, :members

  def initialize(ns, xml)
    super(xml.attribute("name").to_s, "enum")
    @namespace = ns
    @members = {}

    xml.elements.each {
      |e| 
      if e.expanded_name == "member"
        member_name = e.attribute("name").to_s
        if @members[member_name] != nil
          @errors << "repeated enum member name in " + name + ": " + member_name
        end
        @members[member_name] = e.get_text
      end
    }
  end  

  def checkup(core)
  end
  
  def print_error(path)
    super(path)
    print_errors(path, @members.values)
  end
end  

class Type < XMLData
  attr_reader :namespace, :entries
  attr_accessor :extends

  def initialize(ns, xml)
    super(xml.attribute("name").to_s, "type")
    @namespace = ns
    @entries = {
    }
    @extends = xml.attribute("extends").to_s
    @is_editor = false

    xml.elements.each {
      |e| 
      if e.expanded_name == "entry"
        f = Entry.new(e.expanded_name, name, e)
        name = f.name
        if @entries[name] != nil
          @errors << "repeated entry name in " + super.name + ": " + name
        end
        @entries[name] = f
      end
    }
  end  

  def checkup(core)
    if not @entries.empty?
      check_them(core, @entries.values)
    end
  end
  
  def print_error(path)
    super(path)
    if not @entries.empty?
      print_errors(path, @entries.values)
    end
  end
end  

class Entry < XMLData
  attr_reader :type_name, :is_array
  
  def initialize(tag, name, xml)
    super(xml.attribute("name").to_s, "entry")
    @is_array = xml.attribute("is_array").to_s == "true"
    @type_name = xml.attribute("type").to_s
  end
  
  def checkup(core)
    if (core.types[@type_name] == nil) and (core.builtin_types[@type_name] == nil) and (core.enums[@type_name] == nil)
      add_error("Type entry name is not found: " + @type_name)
    end
  end
end

if __FILE__ == $0
  o = Core.new("./res")
  o.print_error("core")
end
