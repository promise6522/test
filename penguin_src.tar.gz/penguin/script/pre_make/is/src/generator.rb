#!/usr/bin/env ruby

require "src/spec_data.rb"
require "src/code_writer.rb"

#=============================================================
#                    IS Type Generator
#=============================================================
class IsTypeWriter
  attr_reader :core, :actor_type
  
  def initialize(core)
    @core = core
    @type_structs = []
    @enum_structs = []
    write_is_types
    write_is_enums
  end

  def write_is_types()
    type_order = []
    type_temp_structs = {}
    editor_enum = EnumGen.new("editor_type_t")

    @core.types.values.each {
      |t|
      #if or not it is a kind of editor
      t.entries.each {
        |k, v|     
        if v.name == "index"
          t.extends = "editor_base"
          t.name = t.name + "_editor"
          editor_enum.add_type("e_" + t.name)
        end  
      }

      if not t.extends.empty?
        struct = ClassGen.new("class", "public", t.name)
        struct.add_super(t.extends)

        #count the order
        if (not type_order.include?(t.extends)) and (not type_order.include?(t.name))
          type_order << t.extends
        elsif (not type_order.include?(t.extends)) and type_order.include?(t.name)
          type_order.insert(type_order.index(t.name), t.extends)
        elsif type_order.include?(t.extends) and type_order.include?(t.name)
          type_order.delete(t.extends)
          type_order.insert(type_order.index(t.name), t.extends)
        else
        end

        #added the constructor and deconstructor
        struct.add_sectin("constructor_methods", "public")
        fun = MethodGen.new("", t.name)        
        fun.hasCode = true
        fun.add_initializer("editor_base(e_" + t.name + ")")
        struct.add_unit_to_sectin("constructor_methods", fun)
        fun = MethodGen.new("virtual", "~" + t.name)
        fun.hasCode = true
        struct.add_unit_to_sectin("constructor_methods", fun)
        
        struct.add_sectin("protected_members", "protected")
        var_section = "protected_members"
        struct.add_sectin("get_set_methods", "public")
        generate_dump_method(t, struct);
      else
        struct = ClassGen.new("struct", "public", t.name)
        struct.add_sectin("ostream_methods", "public")
        generate_osteam_method(t, struct);
      end

      t.entries.each {
        |k, v|            
        if v.type_name == "boolean"
          type_name = "bool"
        elsif v.type_name == "integer"
          type_name = "int"
        elsif v.type_name == "byteArray"
          type_name = "std::vector<char>"
        elsif v.type_name == "string"
          type_name = "std::string"
        elsif v.type_name == "unitIndex"
          type_name = "uint64_t"
        else
          type_name = v.type_name
        end

        if @core.builtin_types[v.type_name] == nil
          if (not type_order.include?(v.type_name)) and (not type_order.include?(t.name))
            type_order << v.type_name
          elsif (not type_order.include?(v.type_name)) and type_order.include?(t.name)
            type_order.insert(type_order.index(t.name), v.type_name)
          elsif type_order.include?(v.type_name) and type_order.include?(t.name)
            type_order.delete(v.type_name)
            type_order.insert(type_order.index(t.name), v.type_name)
          else
          end
        end

        #add "m_" to class member
        if not t.extends.empty?
          var = VarGen.new("", type_name, "m_" + v.name, v.is_array, "")
        else
          var = VarGen.new("", type_name, v.name, v.is_array, "")
        end

        if not var_section == nil
          if v.name != "index"
            struct.add_unit_to_sectin("protected_members", var)
            generate_get_set_method(v, struct)
          end
        else
          struct.add_unit(var)
        end
      } 
      if type_temp_structs[t.name] == nil
        type_temp_structs[t.name] = struct
      end
      if not type_order.include?(t.name)
        type_order << t.name
      end
    }

    #re-order
    type_order.each {
      |t|
      if type_temp_structs[t] != nil
        @type_structs << type_temp_structs[t]
      end
    }

    #write editor type enum
    @enum_structs << editor_enum
  end

  def generate_get_set_method(var, struct)

    if var.type_name == "boolean"
      type_name = "bool"
    elsif var.type_name == "integer"
      if var.is_array
        type_name = "std::vector<int>"
      else
        type_name = "int"
      end
    elsif var.type_name == "byteArray"
      type_name = "std::vector<char>"
    elsif var.type_name == "string"
      type_name = "std::string"
    elsif var.type_name == "unitIndex"
      type_name = "uint64_t"
    else
      if var.is_array
        type_name = "std::vector<" + var.type_name + ">"
      else
        type_name = var.type_name
      end
    end
    
    #get method
    fun = MethodGen.new(type_name, "get_" + var.name)
    fun.hasCode = true
    fun.custom_code << "    return m_" + var.name + ";"
    struct.add_unit_to_sectin("get_set_methods", fun)

    #set method
    fun = MethodGen.new("void", "set_" + var.name) 
    fun.add_parameter("const " + type_name + "& " + var.name)  
    fun.hasCode = true
    fun.custom_code << "    m_" + var.name + " = " + var.name + ";"
    struct.add_unit_to_sectin("get_set_methods", fun)
  end

  def generate_dump_method(type, struct)

    fun = MethodGen.new("virtual void", "dump_editor") 
    fun.hasCode = true
    fun.custom_code << "    editor_base::dump_editor();"
    type.entries.each {
        |k, v|

      if v.type_name == "boolean"
        type_name = "bool"
      elsif v.type_name == "integer"
        if v.is_array
          type_name = "std::vector<int>"
        else
          type_name = "int"
        end
      elsif v.type_name == "byteArray"
        type_name = "std::vector<char>"
      elsif v.type_name == "string"
        type_name = "std::string"
      elsif v.type_name == "unitIndex"
        type_name = "uint64_t"
      else
        if v.is_array
          type_name = "std::vector<" + v.type_name + ">"
        else
          type_name = v.type_name
        end
      end

      if v.is_array or type_name == "std::vector<char>"
        fun.custom_code << "    LOG_DEBUG(\"    Array : " + v.name + "\");"
        fun.custom_code << "    for(" + type_name + "::iterator it = m_" + v.name + ".begin(); it != m_" + v.name + ".end(); ++it)"
        fun.custom_code << "    {"
        fun.custom_code << "        LOG_DEBUG(\"        \"<<*it);"
        fun.custom_code << "    }"
      else
        fun.custom_code << "    LOG_DEBUG(\"    " +  v.name + " = \" << m_" + v.name + ");"
      end
    }      
    struct.add_unit_to_sectin("get_set_methods", fun)
  end

  def generate_osteam_method(type, struct)

    fun = MethodGen.new("friend std::ostream&", "operator<<") 
    fun.add_parameter("std::ostream& os") 
    fun.add_parameter("const " + type.name + "& self")
    fun.hasCode = true
    fun.custom_code << "    os << \"struct(" + type.name + ") : \";" 
    type.entries.each {
        |k, v|

      if v.type_name == "boolean"
        type_name = "bool"
      elsif v.type_name == "integer"
        if v.is_array
          type_name = "std::vector<int>"
        else
          type_name = "int"
        end
      elsif v.type_name == "byteArray"
        type_name = "std::vector<char>"
      elsif v.type_name == "string"
        type_name = "std::string"
      elsif v.type_name == "unitIndex"
        type_name = "uint64_t"
      else
        if v.is_array
          type_name = "std::vector<" + v.type_name + ">"
        else
          type_name = v.type_name
        end
      end

      if v.is_array or type_name == "std::vector<char>"
        fun.custom_code << "    os << \"Array[\";" 
        fun.custom_code << "    for(" + type_name + "::const_iterator it = self." + v.name + ".begin(); it != self." + v.name + ".end(); ++it)"
        fun.custom_code << "    {"
        fun.custom_code << "        os << *it << \", \";"
        fun.custom_code << "    }"
        fun.custom_code << "    os << \"]\";" 
      else
        fun.custom_code << "    os << self." + v.name + " << \", \" ;"
      end
    }

    fun.custom_code << "    return os;"
    struct.add_unit_to_sectin("ostream_methods", fun)
  end
  
  def write_is_enums
    @core.enums.values.each {
      |e|
      enum = EnumGen.new(e.name)
      e.members.each {
        |k, v|
        enum.add_type(k)
      }
      @enum_structs << enum
    }
  end
  
  def dumpit(w, filename)
    w.header(filename)
    w.line
    w.println(%Q{#include <vector>})
    w.println("#include <string>")
    w.println("#include <map>")
    w.println("#include <boost/tr1/memory.hpp>")
    w.println("#include \"stdx_log.h\"")
    w.line
    @enum_structs.each {
      |s|
      s.dumpit(w)
      w.line
    }
    w.line
    w.line
    w.println("class editor_base")
    w.println("{")
    w.println("public :")
    w.println("    editor_base(editor_type_t type) : m_type(type)")
    w.println("    {")
    w.println("    }")
    w.println("    virtual ~editor_base()")
    w.println("    {")
    w.println("    }")
    w.line
    w.println("    editor_type_t get_editor_type()")
    w.println("    {")
    w.println("        return m_type;")
    w.println("    }")
    w.line
    w.println("    int get_index()")
    w.println("    {")
    w.println("        return m_index;")
    w.println("    };") 
    w.line
    w.println("    void set_index(int index)")
    w.println("    {")
    w.println("        m_index = index;")
    w.println("    };")
    w.line
    w.println("    virtual void dump_editor()")
    w.println("    {")
    w.println("       LOG_DEBUG(\"============================================\");")
    w.println("       LOG_DEBUG(\"type = \" << m_type << \" index = \"<< m_index);")
    w.println("    };")
    w.line
    w.println("protected :")
    w.println("    editor_type_t m_type;")
    w.println("    int m_index;")
    w.println("};")
    w.line
    w.line
    @type_structs.each {
      |s|
      s.dumpit(w)
      w.line
    }
    w.line
    w.println("typedef std::tr1::shared_ptr<editor_base> editor_base_ptr;")
    @type_structs.each {
      |s|
      if not s.supers.empty?
        w.println("typedef std::tr1::shared_ptr<" + s.name + "> " + s.name + "_ptr;")
      end
    }
    w.line
    w.tail(filename)
  end
end

#=============================================================
#                   Main Generator
#=============================================================

if __FILE__ == $0
  o = Core.new("./res")
  o.print_error("core")

  base_dir = "../../../src/core/include/"

  if not File.exist?(base_dir)
    FileUtils.mkdir(base_dir)
  end

  fn = "nb_compiler_type"
  temp_fn = "temp_" + fn

  w = CodeWriter.into_file(base_dir + temp_fn + ".h" )
  tw = IsTypeWriter.new(o)
  tw.dumpit(w, fn)

  # replace if differs
  cmp = CodeCompare.new(base_dir + fn + ".h", 
                        base_dir + temp_fn + ".h")
  cmp.replace_if_diff()
end
