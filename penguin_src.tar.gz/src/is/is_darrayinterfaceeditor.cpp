/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/

#include "is_darrayinterfaceeditor.h"
#include "is_dmapinterfaceeditor.h"
#include "is_ddecleditor.h"
#include "is_dapplication.h"
#include "duke_media_interface.h"
////#include "media/duke_media_header.h"

DArrayInterfaceEditor::DArrayInterfaceEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    setObjectName(ArrayInterfaceEditor_ObjName);
    assert(pMainWin != NULL);    
}

DArrayInterfaceEditor::DArrayInterfaceEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    setObjectName(ArrayInterfaceEditor_ObjName);
    assert(pMainWin != NULL);
}

DArrayInterfaceEditor::~DArrayInterfaceEditor()
{
}

void DArrayInterfaceEditor::reload()
{
    LOG_DEBUG("DArrayInterfaceEditor:: reload ......");


    // get name & icon
    duke_media_interface *pArrayInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    if (NULL == pArrayInterface) {
        releaseMedia();
        return;
    }
    pArrayInterface->get_name(m_dukeName);
    pArrayInterface->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // reload media data
    initItemsInBody();
    return;
}

void DArrayInterfaceEditor::initArrayInterfaceEditor()
{
   if (NULL != m_ptr && !m_ptr->is_interface() && !m_ptr->is_interface_compound()) 
    {
        releaseMedia();
        return;
    }

    m_ptr->get_name(m_dukeName);
    m_ptr->get_icon(m_dukeIcon);
 
    initTypeFrame();
    return;
}

void DArrayInterfaceEditor::initTypeFrame()
{
    m_ptrTypeFrame.reset(new(std::nothrow) DFrame(
                            static_cast<DWidget *>(getBodyFrame())));
    m_ptrTypeFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrTypeFrame->setHideProperty(false);
    m_ptrTypeFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    m_ptrTypeFrame->setAutoFill(false);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    //m_ptrTypeFrame->registerEvent(DEvent::Drag);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Release);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Detail, true);
    m_ptrTypeFrame->registerEvent(DEvent::Select, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrTypeFrame->setGeometry(MIN_COORD, 
                                MIN_COORD, 
                                MAX_COORD, 
                                MAX_COORD);
    m_ptrTypeFrame->setEventRoutine(DEvent::DnD_Release,
                                    this,
                                    static_cast<EventRoutine>(&DArrayInterfaceEditor::onDnDReleaseTypeFrame));
    initItemsInBody();
    return;
}

void DArrayInterfaceEditor::initItemsInBody()
{
    if (NULL != m_ptr && !m_ptr->is_interface() && !m_ptr->is_interface_compound()) 
    {
        releaseMedia();
        return;
    }

    if (m_ptr->is_interface_compound())
    {
        duke_media_compound_interface *pArrayCompoundInterface = dynamic_cast<duke_media_compound_interface *>(m_ptr);
        if (NULL == pArrayCompoundInterface)
            return;

        duke_media_handle interfaceHandle = pArrayCompoundInterface->get_extension_types(0);

        DImage elementImg;
        elementImg.load(getResPath() + ArrayInterfaceEditorItemImage_FileName);
        elementImg.setRelation(DImage::KeepSmall);
        if (!interfaceHandle.is_type_null())
        {
            m_ptrInterfaceButton.reset(new(std::nothrow) 
                    DButton("", elementImg, m_ptrTypeFrame.get()));
            setElementProperty(m_ptrInterfaceButton.get());
            m_ptrInterfaceButton->setGeometry(3000, 3000, 4000,4000); 
            m_ptrInterfaceButton->setMediaByHandle(interfaceHandle);
            adjustIconForExpand(m_ptrInterfaceButton.get());
        }
    }
}

void DArrayInterfaceEditor::setReadonly()
{
    DEditor::setReadonly();
    m_ptrTypeFrame->unRegisterEvent(DEvent::DnD_Release);
    return;
}

void DArrayInterfaceEditor::onActivateBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onActivateBtn");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(m_isReadOnly)
        {
            return;
        }
        
        DArrayInterfaceEditor *pArrayInterfaceEditor = dynamic_cast<DArrayInterfaceEditor *>(pEditor);
        if ((NULL != pArrayInterfaceEditor) && pArrayInterfaceEditor->isHide())
        {
            pSrcWidget->setMediaByHandle(pArrayInterfaceEditor->getMediaHandle());
            LOG_DEBUG(pArrayInterfaceEditor->getMediaHandle().str());
        }
        
        DMapInterfaceEditor *pMapInterfaceEditor = dynamic_cast<DMapInterfaceEditor *>(pEditor);
        if ((NULL != pMapInterfaceEditor) && pMapInterfaceEditor->isHide())
        {
            pSrcWidget->setMediaByHandle(pMapInterfaceEditor->getMediaHandle());
            LOG_DEBUG(pMapInterfaceEditor->getMediaHandle().str());
        }
        adjustIconForExpand(m_ptrInterfaceButton.get());
        m_ptrInterfaceButton->updateAll();
        m_ptrInterfaceButton->repaint(event.getCon());        

        if(pEditor->isModified())
        {
            //set dirty if sub editor is modified
            m_isModified = true;
        }
        return;
    }
        
    if(pSrcWidget->getMedia()->is_interface_compound())
    {
        duke_media_compound_interface* pMediaInterface = dynamic_cast<duke_media_compound_interface*>(pSrcWidget->getMedia());
        if ((NULL != pMediaInterface) && pMediaInterface->is_interface_array())
        {
            pEditor = createArrayInterfaceEditor(pSrcWidget);
        }
        else if (((NULL != pMediaInterface) && pMediaInterface->is_interface_map()))
        {
             pEditor = createMapInterfaceEditor(pSrcWidget);
        }
        else
        {
             pEditor = createSubEditor(pSrcWidget);
        }
    }
    else 
    {
        duke_media_interface* pMediaInterface = dynamic_cast<duke_media_interface *>(pSrcWidget->getMedia());
        if ((NULL != pMediaInterface) && pMediaInterface->is_interface_array())
        {
            pEditor = createArrayInterfaceEditor(pSrcWidget);
        }
        else if (((NULL != pMediaInterface) && pMediaInterface->is_interface_map()))
        {
             pEditor = createMapInterfaceEditor(pSrcWidget);
        }
        else
        {
             pEditor = createSubEditor(pSrcWidget);
        }
    }
    
    if(pEditor)
    {
        if(m_isReadOnly)
        {
            pEditor->setReadonly();
        }
        
        pEditor->updateAll();
        pEditor->show(event.getCon());
    }    
}

DEditor * DArrayInterfaceEditor::createArrayInterfaceEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || !pSrcWidget->getMedia())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;


    // Create new IFEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    // Create new arrayEditor with BodyModel
    DArrayInterfaceEditorPtr ptrEditor(new(std::nothrow) DArrayInterfaceEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDialog();
    ptrEditor->initArrayInterfaceEditor();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_ArrayInterfaceEditor_W_InMainWin, 
            Default_ArrayInterfaceEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    return ptrEditor.get();
}

void DArrayInterfaceEditor::adjustPlacement()
{
    DEditor::adjustPlacement();

    // update declaration view gemoetry
    if (NULL != m_ptrTypeFrame.get())
        m_ptrTypeFrame->setGeometry(MIN_COORD, 
                MIN_COORD, 
                MAX_COORD, 
                MAX_COORD);
}

void DArrayInterfaceEditor::setElementProperty(DButton* pElementButton)
{
    if (NULL == pElementButton)
    {
        return;
    }
    pElementButton->setFocusAttr(true);
    pElementButton->registerEvent(DEvent::Select);
    pElementButton->registerEvent(DEvent::Hover);
    pElementButton->registerEvent(DEvent::PassingOut);
   // pElementButton->registerEvent(DEvent::Delete);
    pElementButton->registerEvent(DEvent::DnD_Start);
    pElementButton->registerEvent(DEvent::Activate);
    pElementButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DArrayInterfaceEditor::onActivateBtn));
    pElementButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DArrayInterfaceEditor::onPassingOutChild));
    pElementButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DArrayInterfaceEditor::onHoverChild));
    pElementButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DArrayInterfaceEditor::onDeleteChild));
    pElementButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DArrayInterfaceEditor::onSelectChild));
    return;
}

void DArrayInterfaceEditor::saveDukeData()
{
    duke_media_interface *pArrayInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    duke_media_compound_interface* pArrayComInterface = dynamic_cast<duke_media_compound_interface *>(m_ptr);
;
    if (NULL != pArrayInterface)
    {
        if (!pArrayInterface->is_interface_array())
        {
            return;     
        }
        if (NULL != m_ptrInterfaceButton.get())
        {
            duke_media_handle interfaceHandle = m_ptrInterfaceButton->getMediaHandle();
            duke_media_handle compoundInterfaceHandle = duke_media_set_array_interface_type(this->getApplication()->get_host_committer_id(), m_handle, interfaceHandle);
            setMediaByHandle(compoundInterfaceHandle);
        }
    }

    if (NULL != pArrayComInterface)
    {
        if (pArrayComInterface->is_interface_array())
        {
            return;     
        }
        if (NULL != m_ptrInterfaceButton.get())
        {
            duke_media_handle interfaceHandle = m_ptrInterfaceButton->getMediaHandle();
            duke_media_handle compoundInterfaceHandle = duke_media_set_array_interface_type(this->getApplication()->get_host_committer_id(), m_handle, interfaceHandle);
            setMediaByHandle(compoundInterfaceHandle);
        }
    }
    return;
}

void DArrayInterfaceEditor::onDnDReleaseTypeFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onDnDReleaseTypeFrame");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
   
    DArrayInterfaceEditor* pArrayInterfaceEditor = dynamic_cast<DArrayInterfaceEditor *>(pObject);
    if (NULL != pArrayInterfaceEditor) {
        return;
    }
    
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    
    if (NULL != m_ptrInterfaceButton.get())
        return;

    m_ptrInterfaceButton.reset(new(std::nothrow) DButton("", m_ptrTypeFrame.get()));
    DImage elementImg;
    elementImg.load(getResPath() + ArrayInterfaceEditorItemImage_FileName);
    elementImg.setRelation(DImage::KeepSmall);
    m_ptrInterfaceButton->setImage(elementImg);
    setElementProperty(m_ptrInterfaceButton.get());

    m_ptrInterfaceButton->setGeometry(3000, 3000, 4000,4000); 

    if (handle.is_object() && !handle.is_interface())
    {
        duke_media_handle dukeHandleInterface;
        duke_media_get_interface_by_object(handle, dukeHandleInterface);
        m_ptrInterfaceButton->setMediaByHandle(dukeHandleInterface);
    }
    else if (handle.is_interface())
    {
        duke_media_handle dukeHandleInterface = handle;
        m_ptrInterfaceButton->setMediaByHandle(dukeHandleInterface);
    }
    else
    {
        m_ptrInterfaceButton.reset();   
    }
    adjustIconForExpand(m_ptrInterfaceButton.get());
   
    saveDukeData();
    // Repaint
    updateAll();
    repaint(event.getCon());
    return;
}

void DArrayInterfaceEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onPassingOutChild");
    getApplication()->tip()->remove(event.getCon());
}

void DArrayInterfaceEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onHoverChild");
    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0]));
    if (NULL == pSrcWidget)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    else
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    return;
}

void DArrayInterfaceEditor::onDeleteChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onDeleteChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;
   
    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia)
        return;
   
    if (m_ptrInterfaceButton.get() == pSrcWidget)
    {
        m_ptrTypeFrame->detachChildWidget(pSrcWidget);
        m_ptrInterfaceButton.reset();
    }
    
    saveDukeData();
    updateAll();
    repaint(event.getCon());
    return;
}

void DArrayInterfaceEditor::onSelectChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayInterfaceEditor::onSelectChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;

    updateAll();
    repaint(event.getCon());
}


void DArrayInterfaceEditor::onGenerate(const DEvent &event)
{
    // save name and icon
    DEditor::onGenerate(event);

    duke_media_interface *pArrayInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    if (NULL == pArrayInterface)
        return;
    
    //add by roger
    duke_media_handle handle;
    //pArrayMedia->generate(getApplication()->username(), handle);
}

DEditor * DArrayInterfaceEditor::createMapInterfaceEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || !pSrcWidget->getMedia())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;


    // Create new IFEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    // Create new arrayEditor with BodyModel
    DMapInterfaceEditorPtr ptrEditor(new(std::nothrow) DMapInterfaceEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDialog();
    ptrEditor->initMapInterfaceEditor();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_MapInterfaceEditor_W_InMainWin, 
            Default_MapInterfaceEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    return ptrEditor.get();
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
