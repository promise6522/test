/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/

#ifndef DARRAYINTERFACEEDITOR_H
#define DARRAYINTERFACEEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dmainwin.h"
#include "duke_media_global.h"

typedef std::vector<DWidgetPtr> ArrayWidgets;
typedef ArrayWidgets::iterator ArrayWidgetsIt;
typedef ArrayWidgets::size_type ArrayWidgetsIdx;

class DArrayInterfaceEditor : public DEditor {
public:
    explicit DArrayInterfaceEditor(EditorModel model = PanelModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DArrayInterfaceEditor(const std::string& title,
            EditorModel model = PanelModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DArrayInterfaceEditor();
   
    void initArrayInterfaceEditor();
    void initTypeFrame();
    void initItemsInBody();

    // Manage widget in the editor
    void adjustPlacement();

    virtual void setReadonly();

    void reload();
    // Event handle
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDnDReleaseTypeFrame(const DEvent &event);
    void onDeleteChild(const DEvent &event);
    void onSelectChild(const DEvent &event);
    void onGenerate(const DEvent &event);
    void onActivateBtn(const DEvent &event);
private:
   DEditor* createArrayInterfaceEditor(DWidget *pSrcWidget);
   DEditor* createMapInterfaceEditor(DWidget *pSrcWidget);

   void setElementProperty(DButton* pElementButton);
   void saveDukeData();
private:
    DFramePtr m_ptrTypeFrame;
    DButtonPtr m_ptrInterfaceButton;
};

typedef std::tr1::shared_ptr<DArrayInterfaceEditor>  DArrayInterfaceEditorPtr;

const std::string ArrayInterfaceEditor_ObjName("Array_Interface_Editor");
const int ArrayInterfaceEditor_Row_Height = 2000;
const int ArrayInterfaceEditor_Col_Items = 5;

const int ArrayInterfaceEditor_Width = 336;
const int ArrayInterfaceEditor_Heigth = 448;
const int ArrayInterfaceEditor_DeclFrame_W_Pixel = 313;
const int ArrayInterfaceEditor_DeclFrame_W_InBodyFrame = ArrayInterfaceEditor_DeclFrame_W_Pixel * MAX_COORD / ArrayInterfaceEditor_Width;
const int ArrayInterfaceEditor_DeclFrame_X_Pixel = 12;
const int ArrayInterfaceEditor_DeclFrame_X_InBodyFrame = ArrayInterfaceEditor_DeclFrame_X_Pixel * MAX_COORD / ArrayInterfaceEditor_Width;
const int ArrayInterfaceEditor_SingletonBar_X_Pixel = 112;
const int ArrayInterfaceEditor_SingletonBar_X_InBodyFrame = ArrayInterfaceEditor_SingletonBar_X_Pixel * MAX_COORD / ArrayInterfaceEditor_Width;
const int ArrayInterfaceEditor_SingletonBar_W_Pixel = 112;
const int ArrayInterfaceEditor_SingletonBar_W_InBodyFrame = ArrayInterfaceEditor_SingletonBar_W_Pixel * MAX_COORD / ArrayInterfaceEditor_Width;
const int ArrayInterfaceEditor_SingletonBar_H_Pixel = 24;
const int ArrayInterfaceEditor_SingletonBar_H_InMainWin = ArrayInterfaceEditor_SingletonBar_H_Pixel * MAX_COORD / 768;

const std::string ArrayInterfaceEditorItemImage_FileName("object_origin.png");

const int Default_ArrayInterfaceEditor_W_InMainWin = ArrayInterfaceEditor_Width * MAX_COORD / 1366;
const int Default_ArrayInterfaceEditor_H_InMainWin = ArrayInterfaceEditor_Heigth * MAX_COORD / 768;

#endif // DARRAYINTERFACEEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
