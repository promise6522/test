/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DBUTTON_H
#define DBUTTON_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dimage.h"
#include "is_dtool.h"

class DButtonCell;

class DButton : public DWidget {
public:
    //ctor & dtor
    DButton(DWidget * parent = 0, WFlags f = 0);
    DButton(const std::string &text, DWidget * parent = 0, WFlags f = 0);
    DButton(const std::string &text, const DImage & img, DWidget * parent = 0, WFlags f = 0);
    DButton(const std::string &text, const DImage & img, 
            const DImage & selImg, DWidget * parent = 0, WFlags f = 0);
    virtual ~DButton();

    //Get & Set method    
    DText text() const;
    void setText(const DText &text);
    std::string content() const;
    void setContent(const std::string& text);
    DFont font() const;
    void setFont(const DFont& font);
    DColor textColor() const;
    void setTextColor(const DColor &);
    AlignmentFlag textAlign() const;
    void setTextAlign(const AlignmentFlag &);
    bool isTextWrap() const;
    void setTextWrap(bool);
    DMargin textMargin() const;
    void setTextMargin(const DMargin &);
    const DImage * image() const;
    virtual void setImage(const DImage &);
    const DImage * selImage() const;
    virtual void setSelImage(const DImage &);
    bool isSelected() const;
    void setSelected(bool isSelected = true);    
   
    void processSelectEvent(const DEvent& rEvent);

private:
    DButton(const DButton &);
    DButton &operator=(const DButton &);

private:
    DText m_text;
    bool m_isSelected;

    DImagePtr m_ptrImage;
    DImagePtr m_ptrSelImage;

    D_DECLARE_CELL(DButton)
};

const std::string Button_ObjName("Button_Object");
/***************************************************************************
 * DButton inline functions
 **************************************************************************/
inline DText DButton::text() const
{ return m_text; }

inline void DButton::setText(const DText &text)
{ m_text = text; }

inline std::string DButton ::content()const
{ return m_text.textData(); }

inline void DButton::setContent(const std::string &content)
{ m_text.setTextData(content); }

inline DFont DButton::font()const
{ return m_text.font(); }

inline void DButton::setFont(const DFont &font)
{ m_text.setFont(font); }

class DButtonCell : public DWidgetCell {
public:
    DButtonCell();
    ~DButtonCell();

    void init();
    void update();
private:
    D_DECLARE_PUBLIC(DButton)
};

typedef std::tr1::shared_ptr<DButton>  DButtonPtr;
typedef std::tr1::shared_ptr<DButtonCell>  DButtonCellPtr;

#endif /* DBUTTON_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
