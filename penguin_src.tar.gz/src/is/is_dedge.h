/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author lhj
**
****************************************************************************/

#ifndef DEDGE_H
#define DEDGE_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"

class DEdgeCell;

class DEdge : public DWidget
{
public:
    enum EdgeType
    {
         CurveQuad,
         CurveCubic,
         CurveCustom
    };
    //ctor & detor
    explicit DEdge(DWidget * parent = 0);
    virtual ~DEdge();
   
    //should call this function init the edge geometry, you cannot call widget interface
    void initGeometry(int xCoord, int yCoord, int width, int height);

    //set&get methods
    EdgeType edgeType() const;
    void setEdgeType(EdgeType edgeType);
    DPoint sourcePoint() const;
    void setSourceParentCoord(const DPoint& point);
    DPoint targetPoint() const;
    void setTargetParentCoord(const DPoint& point);
    DWidget* sourceWidget() const;
    void setSourceWidget(DWidget* pSourceWidget);
    DWidget* targetWidget() const;
    void setTargetWidget(DWidget* pTargetWidget);
    DColor color() const;
    void setColor(const DColor & color);
    //event handle
    void onDeleteEdge(const DEvent& rEvent);
    void onFocusEdge(const DEvent& rEvent);
    void onBlurEdge(const DEvent& rEvent);
private:
    void updateGeometry();
private:
    EdgeType m_edgeType;
    DPoint m_sourcePoint;
    DPoint m_targetPoint;
    DPoint m_sourceParentCoord;
    DPoint m_targetParentCoord;
    DWidget* m_pSourceWidget;
    DWidget* m_pTargetWidget;
    DColor m_edgeColor;
    D_DECLARE_CELL(DEdge)
};


class DEdgeCell : public DWidgetCell {
public:
    DEdgeCell();
    virtual ~DEdgeCell();
    
    void init();
    virtual void update();
    
private:
    
    D_DECLARE_PUBLIC(DEdge)
};
      
typedef std::tr1::shared_ptr<DEdge>  DEdgePtr;
typedef std::tr1::shared_ptr<DEdgeCell>  DEdgeCellPtr;
#endif // DCURVE_H 

// vim:set tabstop=4 shiftwidth=4 expandtab:
