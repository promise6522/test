/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DRUNEDITOR_H
#define DRUNEDITOR_H

#include <boost/tr1/memory.hpp>

#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dfunc.h"
#include "is_dobjicon.h"

class DRunEditorCell;

typedef std::vector<DWidgetPtr> RunWidgets;
typedef RunWidgets::iterator RunWidgetsIt;
typedef RunWidgets::size_type RunWidgetsIdx;

typedef std::pair<DPopupMenuPtr, DEdgePtr> MenuEdgePair;

typedef std::vector<std::pair<DWidgetPtr, duke_media_handle> > ResultWidgets;
typedef ResultWidgets::iterator ResultWidgetsIt;

class DRunEditor : public DEditor {
public:
    explicit DRunEditor(EditorModel model = DialogModel,
            DMainWin * pMainWin = NULL,
            DWidget * parent = 0);
    explicit DRunEditor(const std::string& title,
            EditorModel model = DialogModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0);
    virtual ~DRunEditor();

    // init    
    void initRunEditor();
    void initItemsInBody();
    void initCmdInTail();
    void duplicateItemsByHandle(const duke_media_handle& hrun);
    virtual void reload();

    // save
    void saveNodesInfo();
    void clearResult(const DEvent& rEvent);
    void generateResult(duke_media_handle_vector &output);
    void generateSubItems();

    // manage widget in the editor
    DWidgetPtr createWidget(const duke_media_handle &h,
                            bool bCreateFunc,//whether to create DFunc or DObjIcon for a declaration
                            const duke_media_handle& hFuncOwnerIf = NB_INTERFACE_NONE);//needed by some DFunc for its owner interface

    DWidgetPtr createResultWidget(const duke_media_handle &h);
    bool isResultWidget(DWidget* pWidget);
    int inLayer(int, int);
    int getIndexByWidget(DWidget* pWidget);
   
    // Event handle
    void onDnDStart(const DEvent &event);
    void onDnDDrag(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDeleteWidget(const DEvent &event);
    void onMenuBlur(const DEvent& rEvent);
    void onGenerate(const DEvent &event);
    void onActivateObj(const DEvent &event);
    void onActivateResultObj(const DEvent &event);
    void onActivateFunc(const DEvent &event);
    void onClear(const DEvent &event);
    void onRun(const DEvent &event);
    void onResult(const DEvent &event);
    virtual void onClose(const DEvent& rEvent);
    void deletePopMenu(const DEvent &event);

private:
    void updateEdgesPos();
    void deletePopupMenuAndEdge();
    void dialogRelease(const DEvent& rEvent);
    void portRelease(const DEvent& rEvent, DPort* pSrcPort);
    void buttonRelease(const DEvent& rEvent, DButton* pSrcButton);
    void funcRelease(const DEvent& rEvent, DFunc* pSrcFunc);
    void objRelease(const DEvent& rEvent, DObjIcon* pSrcObj);
    void onSelectDeclaration(const DEvent& rEvent);
    void addWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget);
    void pushResultWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget);
    void dumpExecuteInfo();
    bool validate();
    int getIndexByNodeName(const std::string & name);

    // generate a complete graph from a vector of nodes and paths
    bool generate_runnable_impl(nb_id_t& impl_id);
    
    // for NB_FUNC_INTERFACE_CONVERT
    bool getConvertInterface(DEdgePtr pEdge, duke_media_handle& hif);
    
    void setResultImage(DImage & img, const duke_media_handle& handle,
                                 std::string default_image);
    
    bool getValueByHandle(duke_media_handle& h, std::string& value);


private:
    RunWidgets m_runWidgets;
    RunWidgets m_resWidgets;

    ResultWidgets m_resPairs;

    int m_layer;
    int m_blank;
    int m_layerHeight;

    DButtonPtr m_ptrClear;
    DButtonPtr m_ptrRun;
    DPoint m_dragPoint;
    MenuEdgePair m_menuEdgePair;

    duke_media_handle m_storage_hif;    

    D_DECLARE_CELL(DRunEditor)
};

class DRunEditorCell : public DDialogCell
{
public:
    DRunEditorCell();
    virtual ~DRunEditorCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DRunEditor)    
};


typedef std::tr1::shared_ptr<DRunEditor>  DRunEditorPtr;
typedef std::tr1::shared_ptr<DRunEditorCell>  DRunEditorCellPtr;

const std::string RunEditor_ObjName("Run_Editor");
const std::string RunEditor_DefaultObj_FileName("object_selected.png");
const std::string RunEditor_DefaultStorage_FileName("storage.png");
const std::string RunEditor_DefaultAccess_FileName("access.png");

const int RunEditor_Layer = 1000;
const int RunEditor_Layer_Max = 20;
const int RunEditor_Total_Layer = 6000;

const int RunEditor_Width = 336;
const int RunEditor_Heigth = 448;
const int Default_RunEditor_W_InMainWin = RunEditor_Width * MAX_COORD / 1366;
const int Default_RunEditor_H_InMainWin = RunEditor_Heigth * MAX_COORD / 768;

const int RunEditor_Clear_X_Pixel = 68;
const int RunEditor_Clear_Y_Pixel = 0;
const int RunEditor_Clear_W_Pixel = 40;
const int RunEditor_Clear_H_Pixel = Editor_TailFrame_H_Pixel;
const int RunEditor_Run_X_Pixel = 234;
const int RunEditor_Run_Y_Pixel = 0;
const int RunEditor_Run_W_Pixel = 30;
const int RunEditor_Run_H_Pixel = Editor_TailFrame_H_Pixel;

const int RunEditor_Clear_X_InHead = RunEditor_Clear_X_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int RunEditor_Clear_Y_InHead = RunEditor_Clear_Y_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;
const int RunEditor_Clear_W_InHead = RunEditor_Clear_W_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int RunEditor_Clear_H_InHead = RunEditor_Clear_H_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;
const int RunEditor_Run_X_InHead = RunEditor_Run_X_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int RunEditor_Run_Y_InHead = RunEditor_Run_Y_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;
const int RunEditor_Run_W_InHead = RunEditor_Run_W_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int RunEditor_Run_H_InHead = RunEditor_Run_H_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;

const std::string Editor_ClearImg_FileName("editor_clear_ori.png");
const std::string Editor_ClearSelImg_FileName("editor_clear_sel.png");
const std::string Editor_RunImg_FileName("editor_run_ori.png");
const std::string Editor_RunSelImg_FileName("editor_run_sel.png");

const std::string RunEditor_ArrayImg_FileName("array.png");
const std::string RunEditor_ArrayExImg_FileName("array_ex.png");
const std::string RunEditor_MapImg_FileName("map.png");
const std::string RunEditor_MapExImg_FileName("map_ex.png");

const DColor RunEdiotr_Waring_Color(0, 0, 255);

#endif // DRUNEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
