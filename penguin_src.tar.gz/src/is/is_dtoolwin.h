/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DTOOLWIN_H
#define DTOOLWIN_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dbutton.h"
#include "is_dmainwin.h"
#include "is_dwarehousedlg.h"
#include "is_dsharedhousedlg.h"
#include "is_dpackagesheet.h"
#include "is_druneditor.h"

//Buttons
typedef std::vector<DButtonPtr> ToolButtons;
typedef ToolButtons::iterator ToolButtonIt;
typedef ToolButtons::size_type ToolButtonIdx;

//Relationship between Buttons in toolwin and DWidget in mainwin
typedef std::map<DButton*, DWidget*> ButtonWidgetMap;
typedef ButtonWidgetMap::iterator ButtonWidgetMapIt;
typedef std::pair<DButton*, DWidget*> ButtonWidgetpair;

class DToolWin : public DWidget
{
public:
    DToolWin(DWidget *parent = 0, DMainWin * pMainWin = NULL, WFlags f = 0);
    virtual ~DToolWin();

    //Set & Get mainframe
    DMainWin * mainWin();
    void setMainWin(DMainWin * mainWin);

    //get root widget in tool win
    DWidget * getRootWidget();

    //Warehouse related interface
    DButton * createWarehouseButton(DWidget * pWidget, WarehouseType type);

    //Insert/Destory widget and related button at same time, 
    //and add/remove them from vector and map
    void InsertWidgetAndButton(DWidgetPtr ptrWidget, DButtonPtr ptrButton,
                               const is_response_call& response_call);
    void InsertWidgetAndButton(DWidgetPtr ptrWidget, DButtonPtr ptrButton);
    void destoryWidgetAndButton(DWidget *pWidget, DButton * pButton, const is_response_call& response_call);
    void destoryWidgetAndButton(DWidget *pWidget, DButton * pButton);

    //Manage buttons in tool window
    DButton * createButtonForWidget(DWidget * pWidget);
    ToolButtonIdx insertButton(DButtonPtr button, ToolButtonIdx idx);
    void eraseButton(DButton * pButton);
    ToolButtonIdx pushBackButton(DButtonPtr button);
    DButton* findButton(const DPath& buttonPath);

    //Manage the relationship between button and widget
    void insertButtonWidgetMap(DButton * pButton, DWidget * pWidget);
    DWidget* findWidgetFromButton(DButton * pButton);
    DButton* findButtonFromWidget(DWidget * pWidget);
    void eraseButtonWidgetMap(DButton * pButton);
    void eraseButtonWidgetMap(DWidget * pWidget);

    //update function
    void update();
    
    //event handle
    void onClickButton(const DEvent & event);
    void onClickPackage(const DEvent & event);
    void onUpArrow(const DEvent & event);
    void onDownArrow(const DEvent & event);
    void onPassingInArrow(const DEvent& event);
    void onPassingOutArrow(const DEvent& event);
    void onHoverBtn(const DEvent& event);
    void onPassingOutBtn(const DEvent& event);
    void onHoverPackge(const DEvent &event);    
    
private:
    //Init
    void initToolWin();    
    void initWarehouse();

    //calculate gemoetry of buttons
    void calculateButtons();

    //fold 
    void fold(const DEvent & event);
    void unfold(const DEvent & event);
    
    //Disable
    DToolWin(const DToolWin& rToolWin);
    DToolWin& operator=(const DToolWin& rToolWin);

private:
    //the button for showing/hiding package sheet
    DButtonPtr m_ptrPackage;
    
    //the log in access setting buttons
    DButtonPtr m_ptrAccessSetting;
    
    //the warehouse buttons
    ToolButtons m_warehouseButtons;

    //the Separator Line
    DImageLabelPtr m_ptrSeparatorLine;

    //the dynamic buttons for widget(dialog & button ...)
    ToolButtons m_dynamicButtons;
    ToolButtonIdx m_beginButtonPos;

    //the image for dynamic button
    DImage m_buttonImg;
    DImage m_selButtonImg;   

    //the up/down page button
    DButtonPtr m_ptrUpArrow;
    DButtonPtr m_ptrDownArrow;

    //the map for button and widget
    ButtonWidgetMap m_buttonWidget;    

    //save the mainframe's ptr for dynamic creating dwidgets in maiframe
    DMainWin * m_pMainWin;

    //the background image in tool window
    DImageLabelPtr m_ptrBgLabel;

    //package sheet
    DPackageSheetPtr m_ptrPackageSheet;
};

typedef std::tr1::shared_ptr<DToolWin>  DToolWinPtr;

const std::string ToolWin_ObjName("Tool_Window");

//formula (toolwin width = 439)
// relatedX = (X / 1366 * 10000) / 439 * 10000 = X * 10000^2 / (1366 * 439)     
// relatedY = (Y / 768 * 10000)
const int ToolWin_Background_X = 0;
const int ToolWin_Background_Y = 0;        
const int ToolWin_Background_W = 7595;         // 60/(60+19)*10000
const int ToolWin_Background_H = MAX_COORD;

const int ToolWin_Package_Button_X = 7595;     // 60/79*10000
const int ToolWin_Package_Button_Y = 4362;     // 495+690*6-546/2
const int ToolWin_Package_Button_W = 2405;     // 19/(60+19)*10000
const int ToolWin_Package_Button_H = 546;      // 42/768*10000

const int ToolWin_PackageEx_Button_X = 9045;   // 180/199*10000
const int ToolWin_PackageEx_Button_Y = 4362;   // 495+690*6-546/2
const int ToolWin_PackageEx_Button_W = 955;    // 19/(180+19)*10000
const int ToolWin_PackageEx_Button_H = 546;    // 42/768*10000

const int ToolWin_Log_X = 834;                 // 5*10000^2/(1366*439)
const int ToolWin_Log_Y = 78;                  // 6/768*10000
const int ToolWin_Log_Width = 8337;            // 50*10000^2/(1366*439)     
const int ToolWin_Log_Height = 494;            // 38/768*10000

const int ToolWin_Button_StartY = 651;         // 50/768*10000
const int ToolWin_Button_X = 834;              // 5*10000^2/(1366*439)     
const int ToolWin_Button_Width = 8337;         // 50*10000^2/(1366*439)     
const int ToolWin_Button_Height = 651;         // 50/768*10000
const int ToolWin_Button_Spacing = 39;         // 3/768*10000

const int ToolWin_SeparatorLine_Width = 8337;  // 50*1000^2/(1366*439)   
const int ToolWin_SeparatorLine_Height = 65;   // 5/768*10000

const int ToolWin_UpArrow_X = 1001;             // 6*10000^2/(1366*439)
const int ToolWin_DownArrow_X = 5169;           // 31*10000^2/(1366*439)
const int ToolWin_Arrow_Y = 9622;               // 739/768*10000
const int ToolWin_Arrow_Width = 3835;           // 23*10000^2/(1366*439)
const int ToolWin_Arrow_Height = 286;           // 22/768*10000

///////////////////////////////////////////////////////////////////////////
//               Image file Name
//////////////////////////////////////////////////////////////////////////
//toolwin background
const std::string ToolWin_BackgroundImage_Filename("toolwin_background.png");
const DColor ToolWin_Background_Color(255, 255, 255, 0);
//toolwin nebutown log
const std::string ToolWin_Nebutown_Log_Filename("nebutown_log.png");
//toolwin package sheet button
const std::string ToolWin_PackageOutButton_Filename("toolwin_package_out.png");
const std::string ToolWin_PackageInButton_Filename("toolwin_package_in.png");
//warehouse button
const std::string ToolWin_ObjectButton_Filename("object_origin.png");
const std::string ToolWin_ObjectSelButton_Filename("object_selected.png");
const std::string ToolWin_IFButton_Filename("interface_origin.png");
const std::string ToolWin_IFSelButton_Filename("interface_selected.png");
const std::string ToolWin_DeclButton_Filename("decl_origin.png");
const std::string ToolWin_DeclSelButton_Filename("decl_selected.png");
const std::string ToolWin_ImplButton_Filename("impl_origin.png");
const std::string ToolWin_ImplSelButton_Filename("impl_selected.png");
const std::string ToolWin_ContButton_Filename("container_origin.png");
const std::string ToolWin_ContSelButton_Filename("container_selected.png");
const std::string ToolWin_AcsButton_Filename("access_origin.png");
const std::string ToolWin_AcsSelButton_Filename("access_selected.png");
const std::string ToolWin_RunButton_Filename("run_origin.png");
const std::string ToolWin_RunSelButton_Filename("run_selected.png");
const std::string ToolWin_SeparatorLine_Filename("toolwin_separator_line.png");
const std::string ToolWin_SharedButton_Filename("shared_origin.png");
const std::string ToolWin_SharedSelButton_Filename("shared_selected.png");

// up & down button
const std::string ToolWin_DownButton_Filename("toolwin_down.png");
const std::string ToolWin_DownButtonHover_Filename("toolwin_down_hover.png");
const std::string ToolWin_DownButtonNone_Filename("toolwin_down_none.png");
const std::string ToolWin_UpButton_Filename("toolwin_up.png");
const std::string ToolWin_UpButtonHover_Filename("toolwin_up_hover.png");
const std::string ToolWin_UpButtonNone_Filename("toolwin_up_none.png");

const std::string ToolWin_SelectButtonImage_Filename("smallHeighObject.png");


const size_t ToolWin_DynamicButton_Size = 6;

#endif //DTOOLFRAME_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
