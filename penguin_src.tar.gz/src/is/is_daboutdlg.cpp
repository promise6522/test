/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

// Duke header files
#include "is_daboutdlg.h"
#include "is_dmainwin.h"

DAboutDlg::DAboutDlg(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent)
{
    setObjectName(AboutDlg_ObjName);
    assert(pMainWin != NULL);    
}

DAboutDlg::DAboutDlg(const std::string &title,
                     DMainWin *pMainWin /* = NULL */,
                     DWidget * parent /* = 0 */)
    :DDialogEx(title, pMainWin, parent)
{
    setObjectName(AboutDlg_ObjName);
    assert(pMainWin != NULL);
}

DAboutDlg::~DAboutDlg()
{
}

void DAboutDlg::initDialog()
{
    DDialogEx::initDialog();    
    
    DImage buttonImg;
    buttonImg.load( getResPath() + AboutDlg_ButtonImage_FileName);    
    
    m_ptrOKButton.reset(new(std::nothrow) DButton(AboutDlg_Button_Name,
                                                  buttonImg,
                                                  static_cast<DWidget *>(getViewFrame())));
    assert(m_ptrOKButton.get() != NULL);
    m_ptrOKButton->registerEvent(DEvent::Select);
    m_ptrOKButton->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DAboutDlg::onOK));
    m_ptrOKButton->registerEvent(DEvent::Detail, true);
    m_ptrOKButton->setGeometry(2000, 4000, 6000, 6000);    
}

void DAboutDlg::onOK(const DEvent &event)
{
    LOG_DEBUG("About Dialog Close.");
    
    if(m_pMainWin == NULL)
    {
        assert(!"Could not contain main windows management information.");
        destory(event.getCon());
        return;
    }
    
    m_pMainWin->destoryWidgetAndButton(this, event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
