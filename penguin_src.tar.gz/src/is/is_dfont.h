/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author  State
** Qiaowei Create
** Yinlii  Add
**
****************************************************************************/

#ifndef DFONT_H
#define DFONT_H

// Boost header files
#include <boost/tr1/memory.hpp>

// C++ 98 header files
#include <string>

class DFont {
public:
    enum Style {
	StyleNormal,
	StyleItalic,
	StyleBold
    };

    enum StyleHint {
	Dialog,
	SansSerif,
	Serif,
	Monospaced,
	DialogInput
    };

    DFont();
    DFont(const std::string &f, int s = 12, Style style = StyleNormal);
    DFont(const DFont &);
    ~DFont() { }

    std::string family() const;
    void setFamily(const std::string &);

    int size() const;
    void setSize(int);

    bool bold() const;
    void setBold(bool);

    bool italic() const;
    void setItalic(bool);

    Style style() const;
    void setStyle(Style style);

    StyleHint styleHint() const;
    void setStyleHint(StyleHint styleHint);
    
    friend inline bool operator==(const DFont &, const DFont &);
    friend inline bool operator!=(const DFont &, const DFont &);

    void initialize() { };
    void cleanup() { };

    std::string defaultFamily() const;

private:
    Style m_style;
    int m_size;
    std::string m_family;
    StyleHint m_styleHint;
};

typedef std::tr1::shared_ptr<DFont> DFontPtr;

/***************************************************************************
 * DFont inline functions
 **************************************************************************/

//Constructs a font object that uses the default font.
inline DFont::DFont()
    : m_style(StyleNormal),
      m_size(8000)
{ }

//Constructs a font object with the specified family,size and style.
inline DFont::DFont(const std::string &f, int sz, DFont::Style st)
    : m_style(st),
      m_size(sz),
      m_family(f)
{ }

//Returns the requested font family name.
inline std::string DFont::family() const
{ return m_family; }

//Sets the family name of the font.
inline void DFont::setFamily(const std::string &f)
{ m_family = f; }

//Returns the size of the font.
inline int DFont::size() const
{ return m_size; }

//Sets the size of the font.
inline void DFont::setSize(int s)
{ m_size = s; }

//Returns the bold of the font.
inline bool DFont::bold() const
{ return m_style == StyleBold; }

//Set the bold of the font.
inline void DFont::setBold(bool b)
{ m_style = b ? StyleBold : m_style; }

//Returns the italic of the font.
inline bool DFont::italic() const
{ return m_style == StyleItalic; }

//Sets the italic of the font.
inline void DFont::setItalic(bool i)
{ m_style = i ? StyleItalic : m_style; }

//Returns the style of the font.
inline DFont::Style DFont::style() const
{ return m_style; }

//Sets the style of the font.
inline void DFont::setStyle(DFont::Style s)
{ m_style = s; }

//Returns the styleHint of the font.
inline DFont::StyleHint DFont::styleHint() const
{ return m_styleHint; }

//Sets the styleHint of the font.
inline void DFont::setStyleHint(DFont::StyleHint styleHint)
{ m_styleHint = styleHint; }

inline bool operator==(const DFont &f1, const DFont &f2)
{ 
    return f1.m_style == f2.m_style &&
           f1.m_size == f2.m_size &&
	   f1.m_family == f2.m_family;
}

inline bool operator!=(const DFont &f1, const DFont &f2)
{ 
    return f1.m_style != f2.m_style ||
           f1.m_size != f2.m_size ||
	   f1.m_family != f2.m_family;
}



#endif //DFONT_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
