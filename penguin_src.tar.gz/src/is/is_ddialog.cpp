/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

// Duke header files
#include "is_ddialog.h"
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dapplication.h"
#include "is_daboutdlg.h"

DDialog::DDialog(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */,
                 WFlags f /* = 0 */)
    :DWidget(*new DDialogCell, parent, f),
     m_pMainWin(pMainWin),
     m_titleBoxColor(Default_TitleBox_Color),
     m_titleBoxEdgeColor(Duke_Transparent_Color),
     m_titleBoxPS(Default_TitleBox_PenStroke),
     m_titleBoxHeight(Default_DlgTitleHeight_InMainWin),
     m_isHideTitle(false),
     m_dialogColor(Default_Dialog_Color),
     m_dialogEdgeColor(Duke_Transparent_Color),
     m_dialogPS(Default_Dialog_PenStroke)
{
    //set Object Name
    setObjectName(Dialog_ObjName);
    d_func()->init();
    assert(pMainWin != NULL);
}

DDialog::DDialog(DDialogCell &dd, DMainWin *pMainWin /* = NULL */,
                 DWidget * parent /* = 0 */, WFlags f /* = 0 */)
    :DWidget(dd, parent, f),
     m_pMainWin(pMainWin),
     m_titleBoxColor(Default_TitleBox_Color),
     m_titleBoxEdgeColor(Duke_Transparent_Color),
     m_titleBoxPS(Default_TitleBox_PenStroke),
     m_titleBoxHeight(Default_DlgTitleHeight_InMainWin),
     m_isHideTitle(false),
     m_dialogColor(Default_Dialog_Color),
     m_dialogEdgeColor(Duke_Transparent_Color),
     m_dialogPS(Default_Dialog_PenStroke)
{
    setObjectName(Dialog_ObjName);
    d_func()->init();
    assert(pMainWin != NULL);
}

DDialog::DDialog(const std::string &title, DMainWin *pMainWin /* = NULL */,
                 DWidget * parent /* = 0 */, WFlags f /* = 0 */)
    :DWidget(*new DDialogCell, parent, f),
     m_pMainWin(pMainWin),
     m_titleBoxColor(Default_TitleBox_Color),
     m_titleBoxEdgeColor(Duke_Transparent_Color),
     m_titleBoxPS(Default_TitleBox_PenStroke),  
     m_titleBoxHeight(Default_DlgTitleHeight_InMainWin),
     m_isHideTitle(false),
     m_dialogColor(Default_Dialog_Color),
     m_dialogEdgeColor(Duke_Transparent_Color),
     m_dialogPS(Default_Dialog_PenStroke)
{    
    //set Object Name
    setObjectName(Dialog_ObjName);
    setTitleText(title);
    d_func()->init();
    assert(pMainWin != NULL);
}

DDialog::~DDialog()
{
}

//-------------Init methods------------
void DDialog::initDialog()
{
    //set dialog title
    setTitleColor(Default_Title_Color);
    setTitleAlign(AlignCenter);
    setTitleWrap(true);

    //register the event
    registerEvent(DEvent::Enlarge);
    registerEvent(DEvent::Shrink);
    registerEvent(DEvent::Moving);
    registerEvent(DEvent::Grab);
    registerEvent(DEvent::Detail);
    //registerEvent(DEvent::Drag, true);
    registerEvent(DEvent::DnD_Release, true);

    setEventRoutine(DEvent::Enlarge,
                    this,
                    static_cast<EventRoutine>(&DDialog::processEnlargeEvent));
    setEventRoutine(DEvent::Shrink,
                    this,
                    static_cast<EventRoutine>(&DDialog::processShrinkEvent));
    setEventRoutine(DEvent::Resize_Release,
                    this, 
                    static_cast<EventRoutine>(&DDialog::processResizeReleaseEvent));
    setEventRoutine(DEvent::Detail,
                    this,
                    static_cast<EventRoutine>(&DDialog::processDetailEvent));

    //Enable focusable for dialog
    setFocusAttr(true);

    //Save geometrySize
    m_preSize = geometrySize();
    m_prePos = geometryPos();
    
    //Init the popup menu
    m_ptrPopupMenu.reset(new(std::nothrow) DPopupMenu(this));
    //TBA: must setItemHeight at first
    m_ptrPopupMenu->setObjectName(Dialog_Menu_ObjName);

    int menuCount = 0;
    /*
    m_ptrPopupMenu->insertItem("About", menuCount);
    m_ptrPopupMenu->connectItem(menuCount++, this,
                                static_cast<EventRoutine>(&DDialog::onAbout));
    */
    m_ptrPopupMenu->insertItem("Restore", menuCount);
    m_ptrPopupMenu->connectItem(menuCount++, this,
                                static_cast<EventRoutine>(&DDialog::onRestore));
    m_ptrPopupMenu->insertItem("Maximize", menuCount);
    m_ptrPopupMenu->connectItem(menuCount++, this,
                                    static_cast<EventRoutine>(&DDialog::onMaximize));
    m_ptrPopupMenu->insertItem("Minimize", menuCount);
    m_ptrPopupMenu->connectItem(menuCount++, this,
                                static_cast<EventRoutine>(&DDialog::onMinimize));
    m_ptrPopupMenu->insertItem("Close", menuCount);
    m_ptrPopupMenu->connectItem(menuCount++, this,
                                static_cast<EventRoutine>(&DDialog::onClose));
 
    m_displayOrder = Default_Dialog_DisplayOrder;
    m_ptrPopupMenu->setDisplayOrder(0);
    m_ptrPopupMenu->updateMenu();   

    //auto-adjust placement
    adjustPlacement();

    m_ptrPopupMenu->setGeometry(0, 0, 0, 0);
}

//-------------Title: Set & Get methods------------
DText DDialog::title() const
{
    return m_title;
}

void DDialog::setTitle(const DText &title)
{
    m_title = title;
}

std::string DDialog::titleText() const
{
    return m_title.textData();
}
 
void DDialog::setTitleText(const std::string & titleText)
{
    m_title.setTextData(titleText);
}

DFont DDialog::titleFont() const
{
    return m_title.font();
}

void DDialog::setTitleFont(const DFont& font)
{
    m_title.setFont(font);
}

DColor DDialog::titleColor() const
{
    return m_title.color();
}

void DDialog::setTitleColor(const DColor &color)
{
    m_title.setColor(color);
}

AlignmentFlag DDialog::titleAlign() const
{
    return m_title.align();
}

void DDialog::setTitleAlign(AlignmentFlag align)
{
    m_title.setAlign(align);
}

bool DDialog::isTitleWrap() const
{
    return m_title.wrap();
}

void DDialog::setTitleWrap(bool isWrap)
{
    m_title.setWrap(isWrap);
}

DMargin DDialog::titleMargin() const
{
    return m_title.margin();
}

void DDialog::setTitleMargin(const DMargin& margin)
{
    m_title.setMargin(margin);
}

DColor DDialog::titleBoxColor() const
{
    return m_titleBoxColor;
}

void DDialog::setTitleBoxColor(const DColor & color)
{
    m_titleBoxColor = color;
}

DColor DDialog::titleBoxEdgeColor() const
{
    return m_titleBoxEdgeColor;
}

void DDialog::setTitleBoxEdgeColor(const DColor& color)
{
    m_titleBoxEdgeColor = color;
}

DPenStroke DDialog::titleBoxPS() const
{
    return m_titleBoxPS;
}

void DDialog::setTitleBoxPS(const DPenStroke &ps)
{
    m_titleBoxPS = ps;
}

void DDialog::hideTitle(bool isHide)
{
    m_isHideTitle = isHide;
}

DColor DDialog::dialogColor() const
{
    return m_dialogColor;
}

void DDialog::setDialogColor(const DColor & color)
{
    m_dialogColor = color;
}

DColor DDialog::dialogEdgeColor() const
{
    return m_dialogEdgeColor;    
}

void DDialog::setDialogEdgeColor(const DColor& color)
{
    m_dialogEdgeColor = color;    
}

DPenStroke DDialog::dialogPS() const
{
    return m_dialogPS;
}

void DDialog::setDialogPS(const DPenStroke &ps)
{
    m_dialogPS = ps;
}

DMainWin * DDialog::mainWin()
{
    return m_pMainWin;
}

DPopupMenu * DDialog::popMenu()
{
    return m_ptrPopupMenu.get();
}

DDialogCell::DDialogCell()
{
}

DDialogCell::~DDialogCell()
{
}

void DDialogCell::saveTitle(DDialog * q, TPlacement *place)
{
    assert(place != NULL);
    TText *pText = dynamic_cast<TText *>(place->data);
    assert(pText != NULL);
    
    //Converse to TText
    DText2TText(q->m_title, *pText);

    //Update the title's placement info
    place->position.x = MIN_COORD;
    place->position.y = MIN_COORD;    
    place->size.width =  MAX_COORD;                    ;    
    place->size.height = q->m_titleBoxHeight;
    place->order = q->displayOrder();
}

void DDialogCell::saveTitleBox(DDialog * q, TPlacement *place)
{
    assert(place != NULL);
    TRectangle *pRect = dynamic_cast<TRectangle *>(place->data);
    assert(pRect != NULL);

    //Converse to TRectangle, includeing pen stroke, color
    DColor2TColor(q->m_titleBoxColor, pRect->background);
    DColor2TColor(q->m_titleBoxEdgeColor, pRect->edgeColor);
    DPS2TPS(q->m_titleBoxPS, pRect->stroke);
    
    //Update the placement info
    place->position.x = MIN_COORD;
    place->position.y = MIN_COORD;    
    place->size.width =  MAX_COORD;
    place->size.height = q->m_titleBoxHeight;
    place->order = q->displayOrder();
}

void DDialogCell::saveDialog(DDialog * q, TPlacement *place)
{
    assert(place != NULL);
    TRectangle *pRect = dynamic_cast<TRectangle *>(place->data);
    assert(pRect != NULL);

    //Converse to TRectangle, includeing pen stroke, color
    DColor2TColor(q->m_dialogColor, pRect->background);
    DColor2TColor(q->m_dialogEdgeColor, pRect->edgeColor);
    DPS2TPS(q->m_dialogPS, pRect->stroke);
    
    //Update the placement info
    place->position.x = MIN_COORD;    
    place->position.y = q->m_titleBoxHeight;
    place->size.width = MAX_COORD;
    place->size.height = MAX_COORD - q->m_titleBoxHeight;
    place->order = q->displayOrder();
}

void DDialogCell::init()
{
    DDialog *q = q_func();
    int pathCount = 0;

    //save the title box
    TPlacement tBoxPlace;
    TRectangle* pBox = new(std::nothrow) TRectangle;
    assert(pBox != NULL);
    tBoxPlace.data = pBox;
    TPath tBoxPath(m_place->path);
    tBoxPath.node.push_back(pathCount++);
    tBoxPlace.path = tBoxPath;
    tBoxPlace.position.x = tBoxPlace.position.y = MIN_COORD;
    tBoxPlace.size.width = tBoxPlace.size.height = MAX_COORD;
    
    //save title
    saveTitleBox(q, &tBoxPlace);
    subNodes.push_back(tBoxPlace);
    (q->cnum())++;

    //save the dialog
    TPlacement dialogPlace;
    TRectangle * pDialog = new(std::nothrow) TRectangle;
    assert(pDialog != NULL);
    dialogPlace.data = pDialog;
    TPath dialogPath(m_place->path);
    dialogPath.node.push_back(pathCount++);
    dialogPlace.path = dialogPath;
    dialogPlace.position.x = dialogPlace.position.y = MIN_COORD;
    dialogPlace.size.width = dialogPlace.size.height = MAX_COORD;
    saveTitleBox(q, &dialogPlace);
    subNodes.push_back(dialogPlace);
    (q->cnum())++;

    //save the title
    TPlacement titlePlace;
    TText* pTitle = new(std::nothrow) TText;
    assert(pTitle != NULL);
    titlePlace.data = pTitle;
    TPath titlePath(m_place->path);
    titlePath.node.push_back(pathCount++);
    titlePlace.path = titlePath;
    titlePlace.position.x = titlePlace.position.y = MIN_COORD;
    titlePlace.size.width = titlePlace.size.height = MAX_COORD;    
    saveTitle(q, &titlePlace);
    subNodes.push_back(titlePlace);
    (q->cnum())++;
}

void DDialogCell::update()
{
    //call base class at first
    DWidgetCell::update();

    //update itself
    int placeCount = 0;
    DDialog *q = q_func();

    //auto-adjust placement 
    q->adjustPlacement();

    //assert(subNodes.size() == 4);
    m_place->path.node = q->objectPath();
    //update title box
    TPlacement *place = &subNodes[placeCount];
    place->path.node = q->objectPath();
    place->path.node.push_back(placeCount++);    
    saveTitleBox(q, place);
    //update dialog
    place = &subNodes[placeCount];
    place->path.node = q->objectPath();
    place->path.node.push_back(placeCount++);
    saveDialog(q, place);
    //update title
    place = &subNodes[placeCount];
    place->path.node = q->objectPath();
    place->path.node.push_back(placeCount++);
    saveTitle(q, place);    
}

//-------------Event methods------------
void DDialog::processEnlargeEvent(const DEvent& rEvent)
{
    if((geometrySize().width() + enlargeFactor().width() >= 10000) || 
       (geometrySize().height() + enlargeFactor().height() >= 10000))
        return;

    m_preSize = geometrySize();
    m_prePos = geometryPos();  

    //DWidget::processEnlargeEvent(rEvent);
    m_geometrySize += m_enlargeFactor;
    adjustPlacement();
    updateAll();
    repaint(rEvent.getCon());    
}
 
void DDialog::processShrinkEvent(const DEvent& rEvent)
{
    if ((geometrySize().width() - shrinkFactor().width() < 100) || 
        (geometrySize().height() - shrinkFactor().height() < 100))
        return;

    m_preSize = geometrySize();
    m_prePos = geometryPos();  

    //DWidget::processShrinkEvent(rEvent);    
    m_geometrySize -= m_enlargeFactor;
    adjustPlacement();
    updateAll();
    repaint(rEvent.getCon());    
}

void DDialog::adjustPlacement()
{
    adjustTitle();
    adjustMenu();
}

void DDialog::adjustTitle()
{
    DSize geSize = geometrySize();
    if(geSize.width() == 0 || geSize.height() == 0)
        return;

    if(!m_isHideTitle)
    {
        m_titleBoxHeight = Default_DlgTitleHeight_InMainWin * MAX_COORD / geSize.height();    
        m_titleBoxHeight = m_titleBoxHeight > MAX_COORD ? MAX_COORD - 1: m_titleBoxHeight;
    }
    else
    {
        m_titleBoxHeight = 0;
    }
}

void DDialog::adjustMenu()
{
    DSize geSize = geometrySize();    
    if(geSize.width() == 0 || geSize.height() == 0)
        return;

    if(m_ptrPopupMenu.get() == NULL)
        return;

    DSize menuSize = m_ptrPopupMenu->geometrySize();
    if(menuSize.width() == 0 || menuSize.height() == 0)
        return;

    m_ptrPopupMenu->setGeometry(m_ptrPopupMenu->geometryX(),
                                m_ptrPopupMenu->geometryY(),                                
                                Default_MenuWidth_InMainWin * MAX_COORD / geSize.width(),
                                Default_MenuHeight_InMainWin * MAX_COORD / geSize.height());

    m_ptrPopupMenu->updateMenu();
    m_ptrPopupMenu->updateAll();
} 

void DDialog:: minimizeMenu()
{
    if(m_ptrPopupMenu.get() != NULL)
    {
        m_ptrPopupMenu->setGeometry(0, 0, 0, 0);
    }
}

void DDialog::processSelectEvent(const DEvent& rEvent)
{
    minimizeMenu();
    updateAll();
    repaint(rEvent.getCon());
}

void DDialog::processDetailEvent(const DEvent& rEvent)
{
    LOG_DEBUG("DDialog::processDetailEvent");
    DSize geSize = geometrySize();
    if(geSize.width() == 0 || geSize.height() == 0)
        return;

    m_ptrPopupMenu->setGeometry(rEvent.getEventPosition().x(), 
                                rEvent.getEventPosition().y(),
                                Default_MenuWidth_InMainWin * MAX_COORD / geSize.width(),
                                Default_MenuHeight_InMainWin * MAX_COORD / geSize.height());
    adjustMenu();
    updateAll();
    repaint(rEvent.getCon());
}

void DDialog::processResizeReleaseEvent(const DEvent& rEvent)
{
    DWidget::processResizeReleaseEvent(rEvent);
    //adjust title
    adjustPlacement();
    updateAll();
    repaint(rEvent.getCon());    
}

//-------------Menu methods------------
void DDialog::onClose(const DEvent& rEvent)
{
    LOG_DEBUG("Dialog Close.");
    
    if(m_pMainWin == NULL)
    {
        assert(!"Could not contain main windows management information.");
        destory(rEvent.getCon());
        return;
    }
    
    m_pMainWin->destoryWidgetAndButton(this, rEvent.getCon());
}
 
void DDialog::onAbout(const DEvent& rEvent)
{
    LOG_DEBUG("Dialog About.");
    m_ptrPopupMenu->setGeometry(0, 0, 0, 0);         
    m_ptrPopupMenu->repaint(rEvent.getCon());

    DImage selectedImg;
    selectedImg.load(getResPath() + ToolWin_SelectButtonImage_Filename);
    selectedImg.setRelation(DImage::Disrelated);
    selectedImg.setXScale(DImage::Center);
    selectedImg.setYScale(DImage::Center);

    //Create new about dialog in mainwin and new button in toolwin
    DButtonPtr ptrButton(new(std::nothrow) DButton(AboutDlg_Title_Name,
                                                   selectedImg,
                                                   m_pMainWin->toolWin()->getRootWidget()));
    assert(ptrButton.get() != NULL);
    ptrButton->registerEvent(DEvent::Select);
    ptrButton->setEventRoutine(DEvent::Select,
                               m_pMainWin->toolWin(),
                               static_cast<EventRoutine>(&DToolWin::onClickButton));

    DAboutDlgPtr ptrAboutDlg(new(std::nothrow) DAboutDlg(AboutDlg_Title_Name, 
                                                         m_pMainWin,
                                                         m_pMainWin->getRootWidget()));
    ptrAboutDlg->setGeometry(4000, 4000, 1000, 1000);    
    ptrAboutDlg->initDialog();

    //Insert button and widget
    m_pMainWin->toolWin()->InsertWidgetAndButton(ptrAboutDlg, ptrButton);
 
    //update children and show
    ptrButton->updateAll();
    ptrAboutDlg->updateAll();
    ptrButton->show(rEvent.getCon());
    ptrAboutDlg->show(rEvent.getCon());
}

void DDialog::onMaximize(const DEvent& rEvent)
{
    LOG_DEBUG("Dialog Maximize.");
    m_ptrPopupMenu->setGeometry(0, 0, 0, 0);         
    m_ptrPopupMenu->repaint(rEvent.getCon());

    //save the previous geometrySize
    m_preSize = geometrySize();
    m_prePos = geometryPos();

    DSize oldSize = geometrySize();
    DSize newSize(MAX_COORD - Default_ToolFrame_Width, MAX_COORD);
    
    setGeometry(Default_ToolFrame_Width, MIN_COORD,
                MAX_COORD - Default_ToolFrame_Width, MAX_COORD);
    adjustPlacement();
    updateAll();
    repaint(rEvent.getCon());
}
    
void DDialog::onMinimize(const DEvent& rEvent)
{
    LOG_DEBUG("Dialog Minimize.");
    m_ptrPopupMenu->setGeometry(0, 0, 0, 0);         
    m_ptrPopupMenu->repaint(rEvent.getCon());

    //change the button
    if(m_pMainWin != NULL)
    {
        DButton * pButton =  m_pMainWin->toolWin()->findButtonFromWidget(this);
        if(pButton != NULL)
        {
            pButton->setSelected(false);
            pButton->repaint(rEvent.getCon());
        }
    }

    hide(rEvent.getCon());
    repaint(rEvent.getCon());
}

void DDialog::onRestore(const DEvent& rEvent)
{
    LOG_DEBUG("Dialog Restore.");
    DSize oldSize = geometrySize();
    DPoint oldPos = geometryPos();
    DSize newSize = m_preSize;

    setGeometry(m_prePos.x(), m_prePos.y(),
                m_preSize.width(), m_preSize.height());
    m_ptrPopupMenu->setGeometry(0, 0, 0, 0);         
    m_ptrPopupMenu->repaint(rEvent.getCon());

    adjustPlacement();
    updateAll();
    repaint(rEvent.getCon());

    //save previous geometry
    m_prePos = oldPos;
    m_preSize = oldSize;    
}

////////////////////////////////////////////////////////////////
//     Extending DDialog for view frame
///////////////////////////////////////////////////////////////

DDialogEx::DDialogEx(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */,
                     WFlags f /* = 0 */)
    :DDialog(pMainWin, parent, f)
{
    setObjectName(DialogEx_ObjName);
}

DDialogEx::DDialogEx(DDialogCell &dd, DMainWin *pMainWin /* = NULL */,
                     DWidget * parent /* = 0 */, WFlags f /* = 0 */)
    :DDialog(dd, pMainWin, parent, f)
{
    setObjectName(DialogEx_ObjName);
}

DDialogEx::DDialogEx(const std::string &title, DMainWin *pMainWin /* = NULL */,
                 DWidget * parent /* = 0 */, WFlags f /* = 0 */)
    :DDialog(title, pMainWin, parent, f)
{    
    setObjectName(DialogEx_ObjName);
}

DDialogEx::~DDialogEx()
{
}

//Init
void DDialogEx::initDialog()
{
    DDialog::initDialog();
    
    m_ptrViewFrame.reset(new(std::nothrow) DFrame(this));
    assert(m_ptrViewFrame.get() != NULL);
    m_ptrViewFrame->setGeometry(0, m_titleBoxHeight, MAX_COORD, MAX_COORD);
    m_ptrViewFrame->setFrameStyle(DFrame::Panel);
    m_ptrViewFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrViewFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrViewFrame->setFrameBorderColor(Duke_Transparent_Color);

    m_ptrBorder.reset(new(std::nothrow) DFrame(this));
    assert(m_ptrBorder.get() != NULL);
    m_ptrBorder->setFrameStyle(DFrame::NoFrame);
    m_ptrBorder->setAutoFill(false);
    m_ptrBorder->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrBorder->setBackgroundColor(Duke_Transparent_Color);
    m_ptrBorder->setFrameBorderColor(Default_Dialog_BorderColor);

    passThroughMessages(m_ptrViewFrame.get());
}
 
//update placement
void DDialogEx::adjustPlacement()
{
    DDialog::adjustPlacement();
    if(m_ptrViewFrame.get() != NULL)
    {
        m_ptrViewFrame->setGeometry(0, m_titleBoxHeight, 
                                    MAX_COORD, MAX_COORD - m_titleBoxHeight); 
    }
}
void DDialogEx::passThroughMessages(DFrame * pFrame)
{
    pFrame->registerEvent(DEvent::DnD_Start, true);
    //pFrame->registerEvent(DEvent::Drag, true);
    pFrame->registerEvent(DEvent::DnD_Release, true);
    pFrame->registerEvent(DEvent::Detail, true);
    pFrame->registerEvent(DEvent::Select, true);
    pFrame->registerEvent(DEvent::Resize_Start, true);
    pFrame->registerEvent(DEvent::Resize_Release, true);    
}

//get view frame
DFrame * DDialogEx::getViewFrame()
{
    return m_ptrViewFrame.get();
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
