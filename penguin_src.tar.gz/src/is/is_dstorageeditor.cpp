/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_dstorageeditor.h"
#include "is_dobjeditor.h"
#include "is_darrayeditor.h"
#include "is_dbyteseditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"

DStorageEditor::DStorageEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    m_layer = 0;
    m_row = 0;
    m_layerHeight = StorageEditor_Layer;
    setObjectName(StorageEditor_ObjName);
    assert(pMainWin != NULL);    
}

DStorageEditor::DStorageEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    m_layer = 0;
    m_row = 0;
    m_layerHeight = StorageEditor_Layer;
    setObjectName(StorageEditor_ObjName);
    assert(pMainWin != NULL);
}

DStorageEditor::~DStorageEditor()
{
}

void DStorageEditor::duplicateItemsByHandle(const duke_media_handle& hstorage)
{
    if (!hstorage.is_storage()) {
        assert(!"Invalid storage handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();

    duke_media_storage* pStorageMedia = 
        new(std::nothrow) duke_media_storage(getApplication()->get_host_committer_id(), getApplication()->username());
    pStorageMedia->copy(hstorage);
    m_ptr = pStorageMedia;
    m_handle = pStorageMedia->get_handle();
    assert(m_ptr != NULL);    
}

void DStorageEditor::reload()
{
    LOG_DEBUG("DStorageEditor:: reload ......");

    //clear wideget
    for (StorageIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        // delete key
        if (it->first) {
            //delete subEditor for key if there is
            DEditor * pEditor = findSubEditorByWidget(it->first.get());
            if(pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrStorageFrame->detachChildWidget(it->first.get());

            // delete object 
            if (it->second) {
                //delete subEditor for object if there is
                DEditor * pEditor = findSubEditorByWidget(it->second.get());
                if(pEditor != NULL) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }
                m_ptrStorageFrame->detachChildWidget(it->second.get());
            } 
        }
    }
    m_storageWidgets.clear();

    // clear
    m_layer = 0;
    m_layerHeight = StorageEditor_Layer;

    setMediaByHandle(m_handle);

    duke_media_storage *pStorageMedia = dynamic_cast<duke_media_storage *>(m_ptr);
    if (NULL == pStorageMedia) {
        releaseMedia();
        return;
    }
    pStorageMedia->get_name(m_dukeName);
    pStorageMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);
 
    // reload media data
    initStorageExisted();

    // update
    updateStorageView();
}

void DStorageEditor::initStorageEditor()
{
    duke_media_storage *pStorageMedia = dynamic_cast<duke_media_storage *>(m_ptr);
    if (NULL == pStorageMedia) {
        releaseMedia();
        return;
    }
    pStorageMedia->get_name(m_dukeName);
    pStorageMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);

    dumpStorageInfo();

    initStorageFrame();
    updateStorageView();
}

void DStorageEditor::initStorageFrame()
{
    m_ptrStorageFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrStorageFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrStorageFrame.get());
    m_ptrStorageFrame->setGeometry(MIN_COORD, MIN_COORD, MAX_COORD, MAX_COORD);
    m_ptrStorageFrame->setHideProperty(false);
    m_ptrStorageFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrStorageFrame->setAutoFill(false);
    m_ptrStorageFrame->setFrameStyle(DFrame::Panel);

    // set pass though
    m_ptrStorageFrame->registerEvent(DEvent::Detail, true);
    m_ptrStorageFrame->registerEvent(DEvent::Select, true);
    m_ptrStorageFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrStorageFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrStorageFrame->registerEvent(DEvent::DnD_Start, true);
    
    //m_ptrStorageFrame->registerEvent(DEvent::Drag);
    m_ptrStorageFrame->registerEvent(DEvent::DnD_Release);
    m_ptrStorageFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DStorageEditor::onDnDReleaseStorageFrame)); 

    DImage vertiCuttingLineImg;
    vertiCuttingLineImg.load(getResPath() + StorageEditor_VertiCut_Filename);
    vertiCuttingLineImg.setXScale(DImage::Stretch);
    vertiCuttingLineImg.setYScale(DImage::Stretch);
    vertiCuttingLineImg.setRelation(DImage::Disrelated);

    m_ptrVertiCuttingLine.reset(new(std::nothrow) DImageLabel("", vertiCuttingLineImg, this->getBodyFrame()));
    m_ptrVertiCuttingLine->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrVertiCuttingLine.get());
    m_ptrVertiCuttingLine->setHideProperty(false);
    m_ptrVertiCuttingLine->registerEvent(DEvent::DnD_Start, true);
    m_ptrVertiCuttingLine->registerEvent(DEvent::DnD_Release, true);
    m_ptrVertiCuttingLine->registerEvent(DEvent::Detail, true);
    m_ptrVertiCuttingLine->registerEvent(DEvent::Select, true);
    m_ptrVertiCuttingLine->registerEvent(DEvent::Resize_Start, true);
    m_ptrVertiCuttingLine->registerEvent(DEvent::Resize_Release, true);

    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().width() != 0) && (getBodyFrame()->geometrySize().width() != 0)) {
        int widthInEditor = StorageEditor_VertiCuttingLine_W_InMainWin * MAX_COORD / geometrySize().width(); 
        int widthInView  = widthInEditor * MAX_COORD / getViewFrame()->geometrySize().width(); 
        m_vertiCuttingLineWidth = widthInView *  MAX_COORD / getBodyFrame()->geometrySize().width();         
    }     
    m_ptrVertiCuttingLine->setGeometry(StorageEditor_VertiCuttingLine_X_InBodyFrame,
                                      MIN_COORD,
                                      m_vertiCuttingLineWidth,
                                      MAX_COORD);
    initStorageExisted();
}

void DStorageEditor::initStorageExisted()
{
    if (!m_ptr || !m_ptr->is_storage()) {
        releaseMedia();
        return;
    }

    duke_media_handle_pair_vector hstorage;
    dynamic_cast<duke_media_storage *>(m_ptr)->get_storage_objects(hstorage);

    for (duke_media_handle_pair_vector_const_iterator it = hstorage.begin(); 
            it != hstorage.end(); 
            ++it) {
        // create key
        DImage keyImg;
        keyImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(keyImg, it->first,
                             StorageEditor_ObjBtn_Filename); 
        DButtonPtr ptrKeyButton(new(std::nothrow) DButton("",
                    keyImg,
                    m_ptrStorageFrame.get()));
        ptrKeyButton->setFocusAttr(true);
        ptrKeyButton->registerEvent(DEvent::Hover);
        ptrKeyButton->registerEvent(DEvent::Activate);
        ptrKeyButton->registerEvent(DEvent::PassingOut);
        ptrKeyButton->registerEvent(DEvent::Delete);
        ptrKeyButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onActivateBtn)); 
        ptrKeyButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onDeleteStorage)); 
        ptrKeyButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onHoverBtn)); 
        ptrKeyButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onPassingOutBtn)); 

        if (it->first.is_object_builtin()) {
            duke_media_handle hnew;
            duke_media_clone(this->getApplication()->get_host_committer_id(), it->first, hnew);
            ptrKeyButton->setMediaByHandle(hnew);
        } else
            ptrKeyButton->setMediaByHandle(it->first);

        // create object
        DImage objImg;
        objImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(objImg, it->second,
                             StorageEditor_ObjBtn_Filename);
        
        DButtonPtr ptrObjButton(new(std::nothrow) DButton("",
                    objImg,
                    m_ptrStorageFrame.get()));
        ptrObjButton->setFocusAttr(true);
        ptrObjButton->registerEvent(DEvent::Activate);
        ptrObjButton->registerEvent(DEvent::Hover);
        ptrObjButton->registerEvent(DEvent::PassingOut);
        ptrObjButton->registerEvent(DEvent::Delete);
        ptrObjButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onDeleteStorage)); 
        ptrObjButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onActivateBtn)); 
        ptrObjButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onHoverBtn)); 
        ptrObjButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DStorageEditor::onPassingOutBtn)); 

        if (it->second.is_object_builtin()) {
            duke_media_handle hnew;
            duke_media_clone(this->getApplication()->get_host_committer_id(), it->second, hnew);
            ptrObjButton->setMediaByHandle(hnew);
        } else
            ptrObjButton->setMediaByHandle(it->second);

        m_storageWidgets.push_back(std::make_pair(ptrKeyButton, ptrObjButton));
    }
}

void DStorageEditor::updateStorageView()
{
    m_layer = m_storageWidgets.size();
    if (StorageEditor_Layer*m_layer > MAX_COORD) 
        m_layerHeight = MAX_COORD / m_layer;

    int count = 0;
    for (StorageIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {

        if (it->first) 
            it->first->setGeometry(1500, 
                    count*m_layerHeight,
                    m_layerHeight*3/4,
                    m_layerHeight*3/4);

        if (it->second)
            it->second->setGeometry(6500, 
                    count*m_layerHeight,
                    m_layerHeight*3/4,
                    m_layerHeight*3/4);

        count++;
    }
}

DButton * DStorageEditor::createWidgetForKey(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc || pSrc->getMedia());

    DButtonPtr ptrItemButton;
    duke_media_handle hstorageif = duke_media_handle_null;
    duke_media_handle hobjectif = duke_media_handle_null;

    // return if the storage has no type.
    dynamic_cast<duke_media_storage *>(m_ptr)->get_compound_interface(hstorageif);
    if (hstorageif.is_interface_none()) 
        return NULL;

    //  ### storage key constraint #### VERSION SPECIFIED
    //  to avoid conflicts, now we only allow obj_int to be the key
    //  IS needs further configuration to support other types
    if (!pSrc->getMediaHandle().is_object_int())
    {
        LOG_INFO("current version supports int-key only.");
        return NULL;
    }       

    // key should not be a singleton object
    if (pSrc->getMediaHandle().is_object_user()) {
        duke_media_handle hkeyif = duke_media_handle_null;
        duke_media_object* pObj = dynamic_cast<duke_media_object*>(pSrc->getMedia());
        assert(pObj);
        pObj->get_interface(hkeyif);
        duke_media_compound_interface mif(hkeyif);
        if( mif.get_singleton())
            return NULL;
    }

    // check existing type
    if (m_storageWidgets.size() >= 1)
    {
       if (pSrc->getMediaHandle().get_type() != m_storageWidgets.begin()->first->getMediaHandle().get_type())
        {
            LOG_ERROR("DStorageEditor::Can't put the different handle type.");
            return NULL;
        }
    }

    // check duplicate ids
    for (StorageIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        if (pSrc->getMediaHandle() == it->first->getMediaHandle()) {
            LOG_ERROR("DStorageEditor::Current key is redefined.");
            LOG_DEBUG("current key handle : "<<pSrc->getMediaHandle()); 
            return NULL;
        }
    }

    // TODO: for strings, we must check the values, not ids 


    DImage keyImg;
    keyImg.setRelation(DImage::KeepSmall);
    setImageDataByHandle(keyImg, pSrc->getMediaHandle(),
            StorageEditor_ObjBtn_Filename); 

    // create new key 
    ptrItemButton.reset(new(std::nothrow) DButton("",
                keyImg,
                m_ptrStorageFrame.get()));
    ptrItemButton->setFocusAttr(true);
    ptrItemButton->registerEvent(DEvent::Hover);
    ptrItemButton->registerEvent(DEvent::PassingOut);
    ptrItemButton->registerEvent(DEvent::Activate);
    ptrItemButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DStorageEditor::onActivateBtn)); 
    ptrItemButton->registerEvent(DEvent::Delete);
    ptrItemButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DStorageEditor::onDeleteStorage)); 
    ptrItemButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DStorageEditor::onHoverBtn)); 
    ptrItemButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DStorageEditor::onPassingOutBtn)); 

    if (pSrc->getMediaHandle().is_object_builtin()) {
        duke_media_handle hnew;
        duke_media_clone(this->getApplication()->get_host_committer_id(), pSrc->getMediaHandle(), hnew);
        ptrItemButton->setMediaByHandle(hnew);
    } else
        ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());
    m_storageWidgets.push_back(StoragePair(ptrItemButton, DWidgetPtr()));

    m_layer++;

    // update all layers
    updateStorageView();

    return ptrItemButton.get();
}

DButton * DStorageEditor::createWidgetForObj(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc || pSrc->getMedia());

    DButtonPtr ptrItemButton;
    duke_media_handle hif = duke_media_handle_null;
    duke_media_handle hstoragetype = duke_media_handle_null;

    // get stroage type
    dynamic_cast<duke_media_storage *>(m_ptr)->get_type(hstoragetype);

    // get widget interface
    duke_media_get_interface_by_object(pSrc->getMediaHandle(), hif); 

    // the interface of object should cover the interface of storage 
    if (!duke_media_interface_cover_interface(hif, hstoragetype)) 
        return NULL;

    int layer = pt.y() / m_layerHeight;

    for (StorageIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        if (it->first
                && it->first->geometryY()/m_layerHeight == layer
                && !it->second) {

            DImage objImg;
            objImg.setRelation(DImage::KeepSmall);
            setImageDataByHandle(objImg, pSrc->getMediaHandle(),
                    StorageEditor_ObjBtn_Filename);

            // create new object
            ptrItemButton.reset(new(std::nothrow) DButton("",
                        objImg,
                        m_ptrStorageFrame.get()));
            ptrItemButton->setFocusAttr(true);
            ptrItemButton->registerEvent(DEvent::Activate);
            ptrItemButton->registerEvent(DEvent::Hover);
            ptrItemButton->registerEvent(DEvent::PassingOut);
            ptrItemButton->registerEvent(DEvent::Delete);
            ptrItemButton->setEventRoutine(DEvent::Delete,
                    this,
                    static_cast<EventRoutine>(&DStorageEditor::onDeleteStorage)); 
            ptrItemButton->setEventRoutine(DEvent::Activate,
                    this,
                    static_cast<EventRoutine>(&DStorageEditor::onActivateBtn)); 
            ptrItemButton->setEventRoutine(DEvent::Hover,
                    this,
                    static_cast<EventRoutine>(&DStorageEditor::onHoverBtn)); 
            ptrItemButton->setEventRoutine(DEvent::PassingOut,
                    this,
                    static_cast<EventRoutine>(&DStorageEditor::onPassingOutBtn)); 

            if (pSrc->getMediaHandle().is_object_builtin()) {
                duke_media_handle hnew;
                duke_media_clone(this->getApplication()->get_host_committer_id(), pSrc->getMediaHandle(), hnew);
                ptrItemButton->setMediaByHandle(hnew);
            } else
                ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());

            it->second = ptrItemButton;
            // add key and object
            dynamic_cast<duke_media_storage *>(m_ptr)->add_storage_object(it->first->getMediaHandle(), 
                    it->second->getMediaHandle());

            break;
        }
    }

    // update all layers
    updateStorageView();

    return ptrItemButton.get();
}

void DStorageEditor::onDnDReleaseStorageFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DStorageEditor::onDnDReleaseStorageFrame");

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
        
    duke_media_base* pSrcMedia = pSrcWidget->getMedia();
    if (pSrcMedia == NULL)
        return;

    DStorageEditor* pStorageEditor = dynamic_cast<DStorageEditor *>(pObject);
    if (NULL != pStorageEditor) {
        return;
    }

    // if the object's handle is temprary,return
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    if (pEditor && pEditor->isModified() && pEditor->getMedia()) 
    {
        LOG_INFO("storaged object is temprary and invalid.");
        return;
    } 
    else if (e_handle_core != get_media_handle_status(pSrcMedia->get_handle()))
    {
        LOG_INFO("storaged object is temprary and invalid.");
        return;
    }

    // storage key&value constraint
    if (pSrcMedia->is_object_bridge())          // not bridge object
        return;
    if (!pSrcMedia->is_object())               // accepts object
        return;
            
    // create widget for duke storage 
    DPoint pt = event.getEventPosition();
    if ((pt.y()/m_layerHeight >= m_layer) && pt.x() < 5000) 
    {
        // release on key frame
        createWidgetForKey(event.getEventPosition(), pSrcWidget);
    }
    else if ((pt.y()/m_layerHeight < m_layer) && (pt.x() > 5000)) 
    {
        // release on obj frame
        createWidgetForObj(event.getEventPosition(), pSrcWidget);
    } 
    
    // set dirty
    m_isModified = true;

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DStorageEditor::onDeleteStorage(const DEvent &event)
{
    LOG_DEBUG("--------------DStorageEditor::onDeleteStorage");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    // set dirty
    m_isModified = false;

    // delete object by its key
    for (StorageIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        // delete key 
        if (it->first && it->first.get() == pSrcWidget) {
            // delete object 
            if (it->second) {
                if (!dynamic_cast<duke_media_storage *>(m_ptr)->del_storage_object(
                            it->first->getMediaHandle()))
                    return;

                //delete subEditor for object and object 
                DEditor * pEditor = findSubEditorByWidget(it->second.get());
                if (pEditor) {
                    if(!pEditor->isHide()) {
                        pEditor->hideAllSubEditors(event.getCon());
                        pEditor->hide(event.getCon());
                    }
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }
                m_ptrStorageFrame->detachChildWidget(it->second.get());
            } 

            //delete subEditor for key and key 
            DEditor * pEditor = findSubEditorByWidget(it->first.get());
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrStorageFrame->detachChildWidget(it->first.get());
            m_storageWidgets.erase(it);

            m_isModified = true;
            break;
        }
        else if (it->second && it->second.get() == pSrcWidget){

            //delete subEditor for object and object 
            DEditor * pEditor = findSubEditorByWidget(it->second.get());
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrStorageFrame->detachChildWidget(it->second.get());

            it->second.reset();

            m_isModified = true;
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    updateStorageView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DStorageEditor::onActivateBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DStorageEditor::onActivateBtn");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();        
        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);

        if(pEditor->isHide()) {
            if (pInput) {
                // Set initial value
                std::string value;
                if (pSrcWidget->getMediaValue(value))
                    pInput->setInputString(value);
            }
            pEditor->updateAll();
            pEditor->display(event.getCon());
        } else {
            // Set Editor value
            if (pInput) {
                pSrcWidget->setMediaValue(pInput->getInputString());
                m_isModified = true;
            }

            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        
        if(pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        // add by roger
        saveStorageInfo();

        return;
    }

    if (pSrcWidget->getMedia()->is_object_builtin()) {
        DMainWin * pMainWin = m_pMainWin;
        // Get the postion in mainwin 
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        
        if (pSrcWidget->getMedia()->is_object_array()) {
            // Create new arrayEditor with BodyModel
            DArrayEditorPtr ptrEditor(new(std::nothrow) DArrayEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

            ptrEditor->initDialog();
            ptrEditor->initArrayEditor();
            ptrEditor->setReadonly();
            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_ArrayEditor_W_InMainWin, 
                    Default_ArrayEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            ptrEditor->updateAll();
            ptrEditor->show(event.getCon());
        }  else if (pSrcWidget->getMedia()->is_object_bytes()) {
            // Create new arrayEditor with BodyModel
            DBytesEditorPtr ptrEditor(new(std::nothrow) DBytesEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

            ptrEditor->initDialog();
            ptrEditor->initBytesEditor();
            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_BytesEditor_W_InMainWin, 
                    Default_BytesEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            ptrEditor->updateAll();
            ptrEditor->show(event.getCon());
        } else {
            // Create new InputEditor
            DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->initDialog();

            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_InputEditor_W_InMainWin, 
                    Default_InputEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            // Set initial value
            std::string value;
            if (pSrcWidget->getMediaValue(value))
                ptrEditor->setInputString(value);
            ptrEditor->updateAll();
            ptrEditor->show(event.getCon());
        }
    } 
    else if (pSrcWidget->getMedia()->is_declaration()) {

        DMainWin * pMainWin = m_pMainWin;
        DDeclEditorPtr ptrEditor(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                    DEditor::PanelModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        ptrEditor->initDialog();
        insertSubEditor(pSrcWidget, ptrEditor);

        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
        ptrEditor->initDeclEditor();
        ptrEditor->setReadonly();

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_DeclEditor_W_InMainWin, 
                Default_DeclEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
       
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    }

    else if (pSrcWidget->getMediaHandle().is_implementation())
    {
        DMainWin * pMainWin = m_pMainWin;
        DImplEditorPtr ptrEditor(new(std::nothrow) DImplEditor(ImplEditor_ObjName, 
                DEditor::PanelModel,
                pMainWin,
                pMainWin->getRootWidget()));

        // Initialize the editor after inserting widget
        duke_media_handle himpl;
        if(pSrcWidget->getMediaHandle().is_object_exec_iterator())
            duke_media_get_impl_from_iterator(pSrcWidget->getMediaHandle(),himpl);
        else if(pSrcWidget->getMediaHandle().is_object_exec_condition())
            duke_media_get_impl_from_condition(pSrcWidget->getMediaHandle(),himpl);
        else
            himpl = pSrcWidget->getMediaHandle();

        ptrEditor->setMediaByHandle(himpl);
        ptrEditor->initDialog();
        ptrEditor->setReadonly();
        insertSubEditor(pSrcWidget, ptrEditor);

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_IFEditor_W_InMainWin, 
            Default_IFEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
        
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    }   
    else if (pSrcWidget->getMedia()->is_object()) {

        DMainWin * pMainWin = m_pMainWin;
        DObjEditorPtr ptrEditor(new(std::nothrow) DObjEditor(ObjEditor_ObjName, 
                    DEditor::PanelModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        ptrEditor->initDialog();
        insertSubEditor(pSrcWidget, ptrEditor);
        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
        ptrEditor->initObjEditor();
        ptrEditor->setReadonly();

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_ObjEditor_W_InMainWin, 
                Default_ObjEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);

        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    } 

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DStorageEditor::onHoverBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DStorageEditor::onHoverBtn");

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip)) {
        if (pSrcWidget->getMedia()->is_object_builtin()) {
            if (pSrcWidget->getMedia()->is_object_bytes()) {
                strTip = "bytes";
            }
            else {
                std::string val;
                pSrcWidget->getMediaValue(val);
                strTip = strTip + " " + val; 
            }
       }
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    } else {
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    }
}

void DStorageEditor::onPassingOutBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DStorageEditor::onPassingOut");

    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DStorageEditor::setReadonly()
{
    DEditor::setReadonly();

    //m_ptrStorageFrame->unRegisterEvent(DEvent::Drag);
    for (StorageIt it = m_storageWidgets.begin(); it != m_storageWidgets.end(); ++it) {
        if (NULL != it->first.get()) {
            it->first.get()->unRegisterEvent(DEvent::Activate);
            it->first.get()->unRegisterEvent(DEvent::Delete);
        }

        if (NULL != it->second.get()) {
            it->second.get()->unRegisterEvent(DEvent::Activate);
            it->second.get()->unRegisterEvent(DEvent::Delete);
        }
    }
}

void DStorageEditor::saveStorageInfo()
{
    duke_media_storage* pStorageMedia = dynamic_cast<duke_media_storage *>(m_ptr);
    if (NULL == pStorageMedia)
        return;

    pStorageMedia->clear_storage_objects();

    // save key and object
    for (StorageIt it = m_storageWidgets.begin(); it != m_storageWidgets.end(); ++it) {
        if(!it->first || !it->first->getMedia())
            continue;
        if(!it->second || !it->second->getMedia())
            continue;

        pStorageMedia->add_storage_object(it->first->getMediaHandle(), 
                                          it->second->getMediaHandle());        
    }
}

bool DStorageEditor::isValidStorage(duke_media_storage* pStorageMedia)
{
    if (pStorageMedia == NULL)
        return false;

    LOG_DEBUG("Check Storage Completeness: ");

    duke_media_handle_pair_vector hstorage;
    pStorageMedia->get_storage_objects(hstorage);

    for (duke_media_handle_pair_vector_const_iterator it = hstorage.begin(); 
            it != hstorage.end(); 
            ++it) {
        if (it->first == duke_media_handle_null) {
            LOG_INFO("Error, the key is null");
            return false;
        }
        if (it->second == duke_media_handle_null) {
            LOG_INFO("Error, the object is null");
            return false;
        }
    }

    return true;
}

void DStorageEditor::dumpStorageInfo()
{
    LOG_DEBUG("===================================");

    duke_media_storage* pStorageMedia = dynamic_cast<duke_media_storage *>(m_ptr);
    if (NULL == pStorageMedia) {
        LOG_DEBUG("Error: No duke media.");
        LOG_DEBUG("===================================");
        return;
    }

    //dump name & icon
    std::string name;
    std::string icon;
    pStorageMedia->get_name(name);
    pStorageMedia->get_icon(icon);
    LOG_DEBUG("Storage name = "<<name<<std::endl
             <<"Storage icon = "<<toHexString(icon));

    duke_media_handle_pair_vector hstorage;
    pStorageMedia->get_storage_objects(hstorage);

    LOG_DEBUG("\nstorage size = "<<hstorage.size());
    for (duke_media_handle_pair_vector_const_iterator it = hstorage.begin(); 
            it != hstorage.end(); 
            ++it) {
        std::string itemName;

        if(!duke_media_get_name(it->first, itemName))
            continue;
        LOG_DEBUG("\t("<<itemName<<") ");

        if(!duke_media_get_name(it->second, itemName))
            continue;
        LOG_DEBUG("\t("<<itemName<<") ");
    }
}

DStorageEditorCell::DStorageEditorCell()
{
}

DStorageEditorCell::~DStorageEditorCell()
{
}

void DStorageEditorCell::init()
{
}

void DStorageEditorCell::update()
{
    // call parent class at first
    DDialogCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
