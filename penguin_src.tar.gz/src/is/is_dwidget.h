/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DWIDGET_H
#define DWIDGET_H

// Boost header files
//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wenum-compare"
#include <boost/tr1/memory.hpp>
/*
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
*/
//#pragma GCC diagnostic pop

// C++ 98 header files
#include <fstream>

// Duke header files
#include "stdx/stdx_socket.h"
#include "duc.h"
#include "duke_media_base.h"
#include "duke_media_object.h"
#include "duke_logic_object_data.h"
#include "duke_media_implement.h"
#include "duke_media_access.h"
#include "duke_media_anchor.h"
#include "duke_media_execute.h"
#include "duke_media_storage.h"
#include "duke_media_compound_interface.h"
#include "is_dglobal.h"
#include "is_dobject.h"
#include "is_dsize.h"
#include "is_drect.h"
#include "is_dfont.h"
#include "is_dcolor.h"
#include "is_devent.h"
#include "is_dmargins.h"
#include "is_dpenstroke.h"
#include "is_dcursor.h"

class DApplication;
class DWidgetCell;
class DWidget;


typedef void (DWidget::*EventRoutine)(const DEvent& rEvent);

typedef std::pair<DWidget*, EventRoutine> widgetRoutinePair;

typedef std::pair<DEvent::EventType, widgetRoutinePair> eventRoutinePair;

/*
namespace boost {
    namespace serialization {
        template<class Archive>
        void serialize(Archive & ar, duke_media_handle & dukeMediaHandle, const unsigned int version)
        {
            ar & dukeMediaHandle.id.idu_256.id256.idu_id8;
            ar & dukeMediaHandle.idtype;
        }
    }
}
*/

std::ostream& operator<<(std::ostream& os, const duke_media_handle& dukeMediaHandle);

class DWidget : public DObject {
    //friend class boost::serialization::access;
    friend std::ostream& operator<<(std::ostream& os, const DWidget& rWidget);
    public:
    DWidget(DWidget * parent = 0, WFlags f = 0);
    virtual ~DWidget();

protected:
    DWidget(DWidgetCell &d, DWidget *parent = 0, WFlags f = 0);

public:
    //behavior
    void show(const is_response_call& response_call);
    void repaint(const is_response_call& response_call, bool hasData = true);
    void destory(const is_response_call& response_call);
    void hide(const is_response_call& response_call);
    void display(const is_response_call& response_call);
    void showXML(); // for debug
    void updateAll();

    //the event process interface 
    bool event(const DEvent& rEvent);
   
    bool registerEvent(DEvent::EventType eventType, bool isPassThrongh = false);
    bool unRegisterEvent(DEvent::EventType eventType);

    void setEventRoutine(DEvent::EventType eventType, 
	    DWidget* pCallWidget, 
	    EventRoutine eventRoutine);

    //Get & Set operation
    DColor backgroundColor() const;
    void setBackgroundColor(const DColor &);
    void setBackgroundColor(int r, int g, int b, int a = 255);
    DColor highlightColor() const;
    void setHighlightColor(const DColor &);
    void setHighlightColor(int r, int g, int b, int a = 255);
    const DCursor cursor() const;
    void setCursor(const DCursor &);
    int geometryX() const;
    int geometryY() const;
    DPoint geometryPos() const;
    void move(const DPoint &);
    void move(int x, int y);
    DSize geometrySize() const;
    void resize(const DSize &);
    void resize(int w, int h);
    DRect geometry() const;
    void setGeometry(const DRect &);
    void setGeometry(int x, int y, int w, int h);
    DFont font() const;
    void setFont(DFont &);
    bool isHide();
    void setHideProperty(bool isHide);
    void setFocusAttr(bool isFocus);
    int displayOrder() const;
    void setDisplayOrder(int order);   
    void setEnlargeFactor(int widthFactor, int heightFactor);
    DSize enlargeFactor() const;
    void setShrinkFactor(int widthFactor, int heightFactor);
    DSize shrinkFactor() const;

    DApplication* getApplication();
    void setApplication(DApplication* pApplication)
    {  m_pApplication = pApplication; }

    void setParent(DWidget* pWidget);
    void detachChildWidget(DWidget* pWidget);

    DWidgetCell* getCell();
    duke_media_base* getMedia();
    duke_media_type getMediaType();
    duke_media_handle getMediaHandle();
    void releaseMedia();
    void setMediaByType(duke_media_type t);
    void setMediaByHandle(const duke_media_handle & h);
    void setMediaHandle(const duke_media_handle & h);
    void setMediaValue(const std::string value);
    bool getMediaValue(std::string &value);
    void setMediaHandleOnly(const duke_media_handle & h);
   
    //dump display order for debug
    void dumpObjectTree();    

    /*
    template <class Archive>
    void serialize(Archive& ar, const unsigned int version)
    {
        // pos
        ar & m_geometryPos;
        // size
        ar & m_geometrySize;
        //hide 
        ar & m_isHide;
        //display order
        ar & m_displayOrder;
        //handle
        ar & m_handle;
    }
    */
    
protected: 
    /*
     * process the specific gesture, most of time the derive control
     * should rewrite these virtual function. the widget only implement 
     * the defanlt action, some time it is empty.
     */
    void processPassingInEvent(const DEvent& rEvent);
    void processPassingOutEvent(const DEvent& rEvent);
    void processHoverEvent(const DEvent& rEvent);
    void processFocusEvent(const DEvent& rEvent);
    void processBlurEvent(const DEvent& rEvent);
    void processSelectEvent(const DEvent& rEvent);
    void processUnselectEvent(const DEvent& rEvent);
    void processDetailEvent(const DEvent& rEvent);
    void processActivateEvent(const DEvent& rEvent);
    void processDeactivateEvent(const DEvent& rEvent);
    void processDnDStartEvent(const DEvent& rEvent);
    void processDnDReleaseEvent(const DEvent& rEvent);
    void processDragEvent(const DEvent& rEvent);
    void processGrabEvent(const DEvent& rEvent);
    void processReleaseEvent(const DEvent& rEvent);
    void processMovingEvent(const DEvent& rEvent);
    void processInputEvent(const DEvent& rEvent);
    void processInEvent(const DEvent& rEvent);
    void processOutEvent(const DEvent& rEvent);
    void processEnlargeEvent(const DEvent& rEvent);
    void processShrinkEvent(const DEvent& rEvent);
    void processResizeStartEvent(const DEvent& rEvent);
    void processResizeReleaseEvent(const DEvent& rEvent);
    void processTG01Event(const DEvent& rEvent);
    void processTG02Event(const DEvent& rEvent);
    void processTG03Event(const DEvent& rEvent);
    void processTG04Event(const DEvent& rEvent);
    void processTG05Event(const DEvent& rEvent);
    void processTG06Event(const DEvent& rEvent);
    void processTG07Event(const DEvent& rEvent);
    void processTG08Event(const DEvent& rEvent);
    void processTG09Event(const DEvent& rEvent);
  
    void initEventMap();

    void insertEventElement(DEvent::EventType eventType, 
	    DWidget* pWidget, 
	    EventRoutine eventRoutine)
    {
    	m_mEventRoutine.insert(eventRoutinePair(eventType, widgetRoutinePair(pWidget, eventRoutine)));
    }

protected:
    std::map<DEvent::EventType, widgetRoutinePair> m_mEventRoutine;

    /*
     * Widget Gemoetry:
     *
     * m_pos(x,y)  m_frameSize.width()
     *  	 ------------------------------------
     * 		|  -------------------------------   |
     * 		| |    client width (0~10000)     |  |
     * 		| |                               |  |
     * 		|  -------------------------------   |
     *  	 ------------------------------------
     */
    DPoint m_geometryPos;      // the position of the widget within its parent widget.
    DSize m_geometrySize;      // size of the widget including any frame.
    DColor m_backgroundColor;
    DColor m_highlightColor;
    DCursor m_cursor;
    unsigned int m_wflags;
    DFont m_font;
    DSize m_enlargeFactor;
    DSize m_shrinkFactor;
    bool m_isHide;
    DPoint m_resizePoint;
    int m_displayOrder;
    DApplication* m_pApplication;
protected:
    DWidgetCell *d_ptr;
    duke_media_base *m_ptr;
    duke_media_handle m_handle;

private:
    DWidget(const DWidget &);
    DWidget &operator=(const DWidget &);

private:
    D_DECLARE_CELL(DWidget)
};

/***************************************************************************
 * DWidget inline functions
 **************************************************************************/
inline DRect DWidget::geometry() const
{ return DRect(m_geometryPos, m_geometrySize); }

inline int DWidget::geometryX() const
{ return m_geometryPos.x(); }

inline int DWidget::geometryY() const
{ return m_geometryPos.y(); }

inline DPoint DWidget::geometryPos() const
{ return m_geometryPos; }

inline DSize DWidget::geometrySize() const
{ return m_geometrySize; }

inline DColor DWidget::backgroundColor() const
{ return m_backgroundColor; }

inline DColor DWidget::highlightColor() const
{ return m_highlightColor; }

inline const DCursor DWidget::cursor() const
{ return m_cursor; }

inline DFont DWidget::font() const
{ return m_font; }

inline void DWidget::setFont(DFont &f)
{ m_font = f; }

inline void DWidget::move(const DPoint &p)
{ move(p.x(), p.y()); }

inline void DWidget::resize(const DSize &s)
{ resize(s.width(), s.height()); }

inline void DWidget::setGeometry(const DRect &r)
{
    m_geometrySize = r.size();
    m_geometryPos = r.topLeft();
}

inline void DWidget::setGeometry(int x, int y, int w, int h)
{
    m_geometryPos.setX(x);
    m_geometryPos.setY(y);
    m_geometrySize.setWidth(w);
    m_geometrySize.setHeight(h);
}

inline void DWidget::setBackgroundColor(const DColor &c)
{ m_backgroundColor = c; }

inline void DWidget::setBackgroundColor(int r, int g, int b, int a)
{
    m_backgroundColor.setRed(r); 
    m_backgroundColor.setGreen(g); 
    m_backgroundColor.setBlue(b); 
    m_backgroundColor.setAlpha(a); 
}

inline void DWidget::setHighlightColor(const DColor &c)
{ m_highlightColor = c; }

inline void DWidget::setHighlightColor(int r, int g, int b, int a)
{
    m_highlightColor.setRed(r); 
    m_highlightColor.setGreen(g); 
    m_highlightColor.setBlue(b); 
    m_highlightColor.setAlpha(a); 
}

inline void DWidget::setCursor(const DCursor &cursor)
{ m_cursor = cursor; }

inline bool DWidget::isHide()
{ return m_isHide; }

inline void DWidget::setHideProperty(bool isHide)
{ m_isHide = isHide; }

inline int DWidget::displayOrder() const
{ return m_displayOrder; }

inline void DWidget::setDisplayOrder(int order)
{ m_displayOrder = order; }

inline DApplication* DWidget::getApplication()
{ return m_pApplication; }

inline DWidgetCell* DWidget::getCell()
{ return d_ptr; }

inline duke_media_base* DWidget::getMedia()
{ return m_ptr; }

inline duke_media_type DWidget::getMediaType()
{
    if (m_ptr)
        return m_ptr->get_type();

    return DUKE_MEDIA_TYPE_NULL;
}

inline duke_media_handle DWidget::getMediaHandle()
{
    return m_handle;
}

class DWidgetCell : public TCell {
public:
    DWidgetCell();
    virtual ~DWidgetCell();

    DRect gemoetry();
    void init();
    void addNode(const is_response_call& response_call);
    void changeNode(const is_response_call& response_call);
    void changeNodePlace(const is_response_call& response_call);
    void deleteNode(const is_response_call& response_call);
    TPlacement* deleteChildNode(DWidgetCell* pWidgetCell);
    void insertChildNode(TPlacement* pPlacement);
    void insertChildNode(DWidgetCell* pWidgetCell);
    void toXML();
    virtual void update();
    TPlacement* getPlacement()
    { return m_place; }

    void setNewPlacement(TPlacement* pPlacement)
    { m_place = pPlacement; }

protected:
    DWidget *q_ptr; 
    TPlacement *m_place;

private:
    bool registerEvent(DEvent::EventType eventType, bool isPassThrough);
    bool unRegisterEvent(DEvent::EventType eventType);

private:
    D_DECLARE_PUBLIC(DWidget)
};

typedef std::tr1::shared_ptr<DWidget>  DWidgetPtr;
typedef std::tr1::shared_ptr<DWidgetCell>  DWidgetCellPtr;

#endif //DWIDGET_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
