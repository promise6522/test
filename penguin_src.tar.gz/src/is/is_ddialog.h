#ifndef DDIALOG_H
#define DDIALOG_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dsize.h"
#include "is_dwidget.h"
#include "is_dimage.h"
#include "is_dtool.h"
#include "is_dpopupmenu.h"

class DDialogCell;
class DMainWin;

class DDialog : public DWidget 
{
public:
    //ctor & dtor
    explicit DDialog(DMainWin * pMainWin = NULL, DWidget * parent = 0, WFlags f = 0);
    explicit DDialog(const std::string& title, DMainWin *pMainWin = NULL,
                     DWidget * parent = 0, WFlags f = 0);
    virtual ~DDialog();

    //Init
    virtual void initDialog();

    //Title: Set & Get methods
    DText title() const;
    void setTitle(const DText & title);
    std::string titleText() const;
    void setTitleText(const std::string & titleText);
    DFont titleFont() const;
    void setTitleFont(const DFont& font);
    DColor titleColor() const;
    void setTitleColor(const DColor & color);
    AlignmentFlag titleAlign() const;
    void setTitleAlign(AlignmentFlag alig);
    bool isTitleWrap() const;
    void setTitleWrap(bool isWrap);
    DMargin titleMargin() const;
    void setTitleMargin(const DMargin& margin);
    DColor titleBoxColor() const;
    void setTitleBoxColor(const DColor & color);
    DColor titleBoxEdgeColor() const;
    void setTitleBoxEdgeColor(const DColor& color);
    DPenStroke titleBoxPS() const;
    void setTitleBoxPS(const DPenStroke &ps);
    void hideTitle(bool isHide);

    //Dialog Box: Set & Get methods
    DColor dialogColor() const;
    void setDialogColor(const DColor & color);
    DColor dialogEdgeColor() const;
    void setDialogEdgeColor(const DColor& color);
    DPenStroke dialogPS() const;
    void setDialogPS(const DPenStroke &ps);

    //get menu
    DPopupMenu * popMenu();

    //get mainwin
    DMainWin * mainWin();

    //adjust placement
    virtual void adjustPlacement();

    //minimize the menu of dialog
    void minimizeMenu();

protected:
    DDialog(DDialogCell &dd, DMainWin * pMainWin = NULL, DWidget * parent = 0, WFlags f = 0);
    
    //event handle
    virtual void processEnlargeEvent(const DEvent& rEvent);
    virtual void processShrinkEvent(const DEvent& rEvent);
    virtual void processSelectEvent(const DEvent& rEvent);
    virtual void processDetailEvent(const DEvent& rEvent);
    virtual void processResizeReleaseEvent(const DEvent& rEvent);

    //menu handle
    virtual void onClose(const DEvent& rEvent);
    virtual void onAbout(const DEvent& rEvent);
    virtual void onMaximize(const DEvent& rEvent);
    virtual void onMinimize(const DEvent& rEvent);
    virtual void onRestore(const DEvent& rEvent);
    
private:
    void adjustTitle();
    void adjustMenu();
    
protected:    
    //pointer to manager Modle (DMainWin)
    DMainWin * m_pMainWin;
    
    //Attribution of title
    DText m_title;
    DColor m_titleBoxColor; //the color of title box
    DColor m_titleBoxEdgeColor; //the color of dialog edge
    DPenStroke m_titleBoxPS; //the Pen Stroke of title box
    int m_titleBoxHeight;
    bool m_isHideTitle;

    //Attribution of main dialog box
    DColor m_dialogColor; //the color of dialog background
    DColor m_dialogEdgeColor; //the color of dialog edge
    DPenStroke m_dialogPS; //the Pen Stroke of dialog

    //popu menu
    DPopupMenuPtr m_ptrPopupMenu;

    //DSize for resotre
    DSize m_preSize;
    DPoint m_prePos;

    D_DECLARE_CELL(DDialog)
};

class DDialogCell : public DWidgetCell
{
public:
    //ctor & detor
    DDialogCell();
    virtual ~DDialogCell();

    void init();
    virtual void update();

private:
    void saveTitle(DDialog * q, TPlacement *place);
    void saveTitleBox(DDialog * q, TPlacement *place);
    void saveDialog(DDialog * q, TPlacement *place);
    void saveTitleImg(DDialog * q, TPlacement *place);
    
    D_DECLARE_PUBLIC(DDialog)    
};

typedef std::tr1::shared_ptr<DDialog>  DDialogPtr;
typedef std::tr1::shared_ptr<DDialogCell>  DDialogCellPtr;

//Change this according to design (1366 * 768)
const int Default_DlgTitleHeight_Pixel = 24;
const int Default_DlgTitleMargin_Pixel = 6;
const int Default_DlgTitleTextHeight_Pixel = 12;

//auto-count the related postion.
const int Default_DlgTitleHeight_InMainWin = Default_DlgTitleHeight_Pixel*MAX_COORD/768;
const int Default_DlgTitleTextStartY_InMainWin = Default_DlgTitleMargin_Pixel*MAX_COORD/768;
const int Default_DlgTitleTextHeight_InMainWin = Default_DlgTitleTextHeight_Pixel*MAX_COORD/768;

const int Default_MenuWidth_InMainWin = 450;
const int Default_MenuHeight_InMainWin = 1500;

const DColor Default_Title_Color(255, 255, 255);
const DColor Default_TitleBox_Color(57, 57, 57, 228);
const DPenStroke Default_TitleBox_PenStroke(DPenStroke::None, 0);
const DColor Default_Dialog_Color(57, 57, 57, 228);
const DPenStroke Default_Dialog_PenStroke(DPenStroke::None, 0);
const DColor Default_Dialog_TextColor(255, 255, 255);

const std::string Dialog_ObjName("Dialog");
const std::string Dialog_Menu_ObjName("Dialog_Menu");

////////////////////////////////////////////////////////////////
//     Extending DDialog for view frame
///////////////////////////////////////////////////////////////

class DDialogEx : public DDialog
{
public:
    //ctor & dtor
    explicit DDialogEx(DMainWin * pMainWin = NULL, DWidget * parent = 0, WFlags f = 0);
    explicit DDialogEx(const std::string& title, DMainWin *pMainWin = NULL,
                       DWidget * parent = 0, WFlags f = 0);
    virtual ~DDialogEx();

    //Init
    virtual void initDialog();

    //update placement
    virtual void adjustPlacement();
    //get view frame
    DFrame * getViewFrame();

protected:
    DDialogEx(DDialogCell &dd, DMainWin * pMainWin = NULL, DWidget * parent = 0, WFlags f = 0);
    void passThroughMessages(DFrame * pFrame);    

protected:
    DFramePtr m_ptrViewFrame;
    DFramePtr m_ptrBorder;
};

const std::string DialogEx_ObjName("DialogEx_Object");

typedef std::tr1::shared_ptr<DDialogEx>  DDialogExPtr;

const DColor Default_Dialog_BorderColor(146, 146, 146);

const int Default_Dialog_DisplayOrder = 100;
const int Default_Dialog_DisplaySpacing = 100;

const int Default_Widget_DisplayOrder_InDlg = 10;

#endif /* DDIALOG_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
