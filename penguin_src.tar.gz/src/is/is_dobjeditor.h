#ifndef DOBJEDITOR_H
#define DOBJEDITOR_H

#include <boost/tr1/memory.hpp>

#include "is_ddialog.h"
#include "is_dfunc.h"
#include "is_deditor.h"
#include "duke_media_global.h"

class DObjEditorCell;

typedef std::pair<DWidgetPtr, DWidgetPtr> ObjWidgetPair;
typedef std::vector<ObjWidgetPair> SubWidgets;
typedef SubWidgets::iterator SubWidgetsIt;
typedef std::map<DWidgetPtr, DWidgetPtr> FuncWidgetMap;
typedef FuncWidgetMap::iterator FuncWidgetMapIt;

typedef std::vector<std::pair<DWidgetPtr, DWidgetPtr> > FuncWidgetVector;
typedef FuncWidgetVector::iterator FuncWidgetVectorIt;

class DObjEditor : public DEditor {
public:
    explicit DObjEditor(EditorModel model = DialogModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DObjEditor(const std::string& title,
            EditorModel model = DialogModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DObjEditor();

    // duplicate the object content from handle
    void duplicateItemsByHandle(const duke_media_handle& hobj);

    // Init
    void initFuncFrame();
    void initSubFrame();
    void initFuncExisted();
    void initSubExisted();
    void initObjEditor();    

    // reload and generate
    virtual void reload();
    virtual duke_media_handle generate();
    virtual void generateSubItems();

    // manage widget in the editor
    DButton * createWidgetForFunc(const DPoint &, DWidget *);
    DButton * createWidgetForSub(const DPoint &, DWidget *);
    void updateFuncView();
    void updateSubView();
    void setReadonly();

    // Event handle
    void onDnDReleaseFuncFrame(const DEvent &event);
    void onDnDReleaseSubFrame(const DEvent &event);
    void onDeleteSub(const DEvent &event);
    void onDeleteFunc(const DEvent &event);
    void onSelectBtn(const DEvent &event);
    void onActivateBtn(const DEvent &event);
    void onHoverBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);
    void onGenerate(const DEvent &event);
    void dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame);
    void onObjArrow(const DEvent &event);
    void onPassingInObjArrow(const DEvent &event);
    void onPassingOutObjArrow(const DEvent &event);
    void onFuncArrow(const DEvent &event);
    void onPassingInFuncArrow(const DEvent &event);
    void onPassingOutFuncArrow(const DEvent &event);

private:
    void saveSubObjInfo();
    void saveFuncInfo();
    void dumpObjectInfo();
    bool isValidObj(duke_media_object* pObjMedia);

private:
    DFramePtr m_ptrFuncFrame;
    DFramePtr m_ptrSubFrame;

    DButtonPtr m_ptrObjLArrow;
    DButtonPtr m_ptrObjRArrow;
    std::size_t m_curObjPage;
    
    DButtonPtr m_ptrFuncLArrow;
    DButtonPtr m_ptrFuncRArrow;
    std::size_t m_curFuncPage;

    int m_funcLayer;
    int m_subLayer;
    int m_funcLayerHeight;
    int m_subLayerHeight;

    SubWidgets m_subWidgets;
    FuncWidgetVector m_funcWidgets;

    D_DECLARE_CELL(DObjEditor)
};

class DObjEditorCell : public DDialogCell
{
public:
    DObjEditorCell();
    virtual ~DObjEditorCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DObjEditor)    
};


typedef std::tr1::shared_ptr<DObjEditor>  DObjEditorPtr;
typedef std::tr1::shared_ptr<DObjEditorCell>  DObjEditorCellPtr;

const int ObjEditor_Width = 336;
const int ObjEditor_Heigth = 448;
const int Default_ObjEditor_W_InMainWin = ObjEditor_Width * MAX_COORD / 1366;
const int Default_ObjEditor_H_InMainWin = ObjEditor_Heigth * MAX_COORD / 768;

const int ObjEditor_LArrow_X = 100;
const int ObjEditor_RArrow_X = 8600;
const int ObjEditor_Arrow_Y = 4000;
const int ObjEditor_Arrow_Width = 1300;
const int ObjEditor_Arrow_Height = 1000;

const std::string ObjEditor_ObjectButton_Filename("object_origin.png");
const std::string ObjEditor_IFButton_Filename("interface_origin.png");
const std::string ObjEditor_DeclButton_Filename("decl_origin.png");
const std::string ObjEditor_ImplButton_Filename("impl_origin.png");
const std::string ObjEditor_SelObjectButton_Filename("object_selected.png");
const std::string ObjEditor_SelIFButton_Filename("interface_selected.png");
const std::string ObjEditor_SelDeclButton_Filename("decl_selected.png");
const std::string ObjEditor_SelImplButton_Filename("impl_selected.png");

const std::string ObjEditor_ObjectButton_Unfin_Filename("object_origin_unfin.png");
const std::string ObjEditor_IFButton_Unfin_Filename("interface_origin_unfin.png");
const std::string ObjEditor_DeclButton_Unfin_Filename("decl_origin_unfin.png");
const std::string ObjEditor_ImplButton_Unfin_Filename("impl_origin_unfin.png");
const std::string ObjEditor_SelObjectButton_Unfin_Filename("object_selected_unfin.png");
const std::string ObjEditor_SelIFButton_Unfin_Filename("interface_selected_unfin.png");
const std::string ObjEditor_SelDeclButton_Unfin_Filename("decl_selected_unfin.png");
const std::string ObjEditor_SelImplButton_Unfin_Filename("impl_selected_unfin.png");

const std::string ObjEditor_RightArrowButton_Filename("right_arrow.png");
const std::string ObjEditor_RightArrowHoverButton_Filename("right_arrow_hover.png");
const std::string ObjEditor_LeftArrowButton_Filename("left_arrow.png");
const std::string ObjEditor_LeftArrowHoverButton_Filename("left_arrow_hover.png");

const std::string ObjEditor_ArrayImg_FileName("array.png");
const std::string ObjEditor_ArrayExImg_FileName("array_ex.png");
const std::string ObjEditor_MapImg_FileName("map.png");
const std::string ObjEditor_MapExImg_FileName("map_ex.png");

const std::string ObjEditor_ObjName("Obj_Editor");
const std::size_t ObjEditor_Layer = 1000;
const std::size_t ObjEditor_Total_Layer = 10;

#endif // DOBJEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
