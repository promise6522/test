/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

//boost header files, using lexical_cast for test example, remove it in future
#include "boost/lexical_cast.hpp"
#include "boost/algorithm/string.hpp"

// Duke header files

#include "nb_profiler.h"

#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dwarehousedlg.h"
#include "is_daboutdlg.h"

DWarehouseDlg::DWarehouseDlg(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent),
     m_rowNum(WarehouseDlg_Default_RowNum),
     m_columnNum(WarehouseDlg_Default_ColumnNum),
     m_curPage(0),
     m_curClassic(AllItems)
{
    setObjectName(WarehouseDlg_ObjName);
    assert(pMainWin != NULL);    
    LOG_DEBUG( "=========first=======");
    //default to create object warehouse
    m_ptrImpl.reset(new(std::nothrow) DObjhouseImpl(this));
    assert(m_ptrImpl.get() != NULL);
}

DWarehouseDlg::DWarehouseDlg(const std::string &title,
                             WarehouseType type,
                             DMainWin *pMainWin /* = NULL */,
                             DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent),
     m_wType(type),
     m_rowNum(WarehouseDlg_Default_RowNum),
     m_columnNum(WarehouseDlg_Default_ColumnNum),
     m_curPage(0),
     m_curClassic(AllItems)
{
    LOG_DEBUG("=========second=======");
    setObjectName(WarehouseDlg_ObjName);
    assert(pMainWin != NULL);
    setWarehouseType(type);
}

DWarehouseDlg::DWarehouseDlg(WarehouseType type,
                             DMainWin *pMainWin /* = NULL */,
                             DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent),
     m_wType(type),
     m_rowNum(WarehouseDlg_Default_RowNum),
     m_columnNum(WarehouseDlg_Default_ColumnNum),
     m_curPage(0),
     m_curClassic(AllItems)
{
    LOG_DEBUG("=========third=======");
    setObjectName(WarehouseDlg_ObjName);
    assert(pMainWin != NULL);
    setWarehouseType(type);
}

DWarehouseDlg::~DWarehouseDlg()
{
}

WarehouseType DWarehouseDlg::warehouseType() const
{
    return m_wType;    
}

void DWarehouseDlg::setWarehouseType(WarehouseType type)
{
    m_wType = type;

    switch(type)
    {
    case ObjWarehouse:
        setTitleText(Object_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DObjhouseImpl(this));
        break;
    case IFWarehouse:
        setTitleText(Interface_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DIFhouseImpl(this));
        break;
    case DeclWarehouse:
        setTitleText(Declaration_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DDeclhouseImpl(this));
        break;
    case ImplWarehouse:
        setTitleText(Implement_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DImplhouseImpl(this));
        break;
    case ContWarehouse:
        setTitleText(Container_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DConthouseImpl(this));
        break;
    case AcsWarehouse:
        setTitleText(Access_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DAcshouseImpl(this));
        break;
    case RunWarehouse:
        setTitleText(Run_Warehouse_Title_Name);
        m_ptrImpl.reset(new(std::nothrow) DExehouseImpl(this));
        break;
    default:
        assert(!"Error Warehouse type!");
    }
    assert(m_ptrImpl.get() != NULL);
}

int DWarehouseDlg::warehouseRowNum() const
{
    return m_rowNum;    
}

int DWarehouseDlg::warehouseColoumnNum() const
{
    return m_columnNum;    
}

int DWarehouseDlg::getCurPagePos() const
{
    return m_curPage;
}

std::string DWarehouseDlg::getSearchKeyWord() const
{
    return m_searchKey;
}

DukeItemClassic DWarehouseDlg::getCurClassic() const
{
    return m_curClassic;
}

bool DWarehouseDlg::isEditing() const
{
    if(m_curClassic == EditItems)
    {
        return true;
    }

    return false;
}

WarehouseItemsIdx DWarehouseDlg::getButtonItemIdx(DWidget * pWidget)
{
    WarehouseItemsIdx idx = 0;
    for(WarehouseItemsIt it = m_items.begin(); it != m_items.end(); ++it)
    {
        if((*it).get() == pWidget)
        {
            return idx;
        }
        ++idx;
    }    

    return idx;
}

void DWarehouseDlg::initDialog()
{
    DDialogEx::initDialog();
    
    initControlBar();
    initTabBar();
    initWarehouseView();

    updateView();
   
    setEventRoutine(DEvent::Enlarge,
                    this,
                    static_cast<EventRoutine>(&DWarehouseDlg::processEnlargeEvent));
    setEventRoutine(DEvent::Shrink,
                    this,
                    static_cast<EventRoutine>(&DWarehouseDlg::processShrinkEvent));
    setEventRoutine(DEvent::Resize_Release,
                    this, 
                    static_cast<EventRoutine>(&DWarehouseDlg::processResizeReleaseEvent));
    updateAll();
}

//control bar, see the style below
//
//  < >   [_____]  [Search]
//
void DWarehouseDlg::initControlBar()
{
    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //Previous page button
    img.load(getResPath() + Control_PrePageImg_FileName);
    selImg.load(getResPath() + Control_PrePageSelImg_FileName);
    m_ptrPrePage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrPrePage.get() != NULL);
    m_ptrPrePage->setGeometry(Warehouse_PrePageX_InView, Warehouse_PrePageY_InView, 
                              Warehouse_PrePageW_InView, Warehouse_PrePageH_InView);
    m_ptrPrePage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPrePage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrPrePage->registerEvent(DEvent::Drag, true);
    m_ptrPrePage->registerEvent(DEvent::DnD_Release, true);
    m_ptrPrePage->registerEvent(DEvent::Detail, true);
    m_ptrPrePage->registerEvent(DEvent::PassingIn);
    m_ptrPrePage->registerEvent(DEvent::PassingOut);
    m_ptrPrePage->registerEvent(DEvent::Grab);
    m_ptrPrePage->registerEvent(DEvent::Activate);
    m_ptrPrePage->setEventRoutine(DEvent::Grab,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onPrePage));
    m_ptrPrePage->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onPrePage));
    m_ptrPrePage->setEventRoutine(DEvent::Activate,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onBeginPage));
    m_ptrPrePage->setEventRoutine(DEvent::PassingIn,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onPassingInBtn)); 
    m_ptrPrePage->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onPassingOutBtn));
    m_ptrPrePage->setSelected(false);

    //Next page button
    img.load(getResPath() + Control_NextPageImg_FileName);
    selImg.load(getResPath() + Control_NextPageSelImg_FileName);
    m_ptrNextPage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrNextPage.get() != NULL);
    m_ptrNextPage->setGeometry(Warehouse_NextPageX_InView, Warehouse_NextPageY_InView, 
                               Warehouse_NextPageW_InView, Warehouse_NextPageH_InView);
    m_ptrNextPage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNextPage->registerEvent(DEvent::Detail, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrNextPage->registerEvent(DEvent::Drag, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Release, true);
    m_ptrNextPage->registerEvent(DEvent::PassingIn);
    m_ptrNextPage->registerEvent(DEvent::PassingOut);
    m_ptrNextPage->registerEvent(DEvent::Grab);
    m_ptrNextPage->registerEvent(DEvent::Activate);
    m_ptrNextPage->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onNextPage));    
    m_ptrNextPage->setEventRoutine(DEvent::Grab,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onNextPage));
    m_ptrNextPage->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onEndPage));
    m_ptrNextPage->setEventRoutine(DEvent::PassingIn,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onPassingInBtn)); 
    m_ptrNextPage->setEventRoutine(DEvent::PassingOut,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onPassingOutBtn));
    m_ptrNextPage->setSelected(false);

    //create button
    img.load(getResPath() + Control_CreateImg_FileName);
    m_ptrCreate.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 getViewFrame()));
    assert(m_ptrCreate.get() != NULL);
    m_ptrCreate->setGeometry(Warehouse_CreateX_InView, Warehouse_CreateY_InView, 
                             Warehouse_CreateW_InView, Warehouse_CreateH_InView);
    m_ptrCreate->setBackgroundColor(Duke_Transparent_Color);
    m_ptrCreate->registerEvent(DEvent::Detail, true);
    m_ptrCreate->registerEvent(DEvent::DnD_Start, true);
    //m_ptrCreate->registerEvent(DEvent::Drag, true);
    m_ptrCreate->registerEvent(DEvent::DnD_Release, true);
    m_ptrCreate->setEventRoutine(DEvent::Select,
                                 this,
                                 static_cast<EventRoutine>(&DWarehouseDlg::onCreateNew));

    //search line edit background
    img.load(getResPath() + Search_EditImg_FileName);
    m_ptrSearchEditBg.reset(new(std::nothrow) DImageLabel("", img, getViewFrame()));
    assert(m_ptrSearchEditBg.get() != NULL);
    m_ptrSearchEditBg->setGeometry(Warehouse_SearchX_InView, Warehouse_SearchY_InView,
                                   Warehouse_SearchW_InView, Warehouse_SearchH_InView);
    m_ptrSearchEditBg->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchEditBg->setFrameBorderColor(Duke_Transparent_Color);    

    //search line edit 
    m_ptrSearchKeyWord.reset(new(std::nothrow) DLineEdit(getViewFrame()));
    assert(m_ptrSearchKeyWord.get() != NULL);
    m_ptrSearchKeyWord->setGeometry(Warehouse_SearchEditX_InView, Warehouse_SearchY_InView,
                                    Warehouse_SearchEditW_InView, Warehouse_SearchH_InView);
    m_ptrSearchKeyWord->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setEventRoutine(DEvent::Input, this,
                                        (EventRoutine)(&DWarehouseDlg::onSearch));
}

//tab bar, see the style below
//
//   [All]  [Built-in]  [Edit]  [User-defined]  [Shared]
//
void DWarehouseDlg::initTabBar()
{
    DImage img;
    DImage selImg;    
    img.load(getResPath() + Tab_ButtonImg_FileName);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    selImg.load(getResPath() + Tab_ButtonSelImg_FileName);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //All button
    m_ptrAllItem.reset(new(std::nothrow) DButton("All",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrAllItem.get() != NULL);
    m_ptrAllItem->setTextColor(Default_Dialog_TextColor);
    m_ptrAllItem->setGeometry(Warehouse_Tab_AllX_InView, Warehouse_TabY_InView,
                              Warehouse_TabW_InView, Warehouse_TabH_InView);
    m_ptrAllItem->registerEvent(DEvent::Detail, true);
    m_ptrAllItem->registerEvent(DEvent::DnD_Start, true);
    //m_ptrAllItem->registerEvent(DEvent::Drag, true);
    m_ptrAllItem->registerEvent(DEvent::DnD_Release, true);
    m_ptrAllItem->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DWarehouseDlg::onAllItem));
    m_ptrAllItem->setSelected(true);

    //built-in button    
    m_ptrBuiltInItem.reset(new(std::nothrow) DButton("Builtin",
                                                     img,
                                                     selImg,
                                                     getViewFrame()));
    assert(m_ptrBuiltInItem.get() != NULL);
    m_ptrBuiltInItem->setTextColor(Default_Dialog_TextColor);
    m_ptrBuiltInItem->setGeometry(Warehouse_Tab_BuiltX_InView, Warehouse_TabY_InView,
                                  Warehouse_TabW_InView, Warehouse_TabH_InView);
    m_ptrBuiltInItem->registerEvent(DEvent::Detail, true);
    m_ptrBuiltInItem->registerEvent(DEvent::DnD_Start, true);
    //m_ptrBuiltInItem->registerEvent(DEvent::Drag, true);
    m_ptrBuiltInItem->registerEvent(DEvent::DnD_Release, true);
    m_ptrBuiltInItem->setEventRoutine(DEvent::Select,
                                      this,
                                      static_cast<EventRoutine>(&DWarehouseDlg::onBuiltInItem));
    m_ptrBuiltInItem->setSelected(false);

    //Edit button    
    m_ptrEditItem.reset(new(std::nothrow) DButton("Editing",
                                                  img,
                                                  selImg,
                                                  getViewFrame()));
    assert(m_ptrEditItem.get() != NULL);
    m_ptrEditItem->setTextColor(Default_Dialog_TextColor);
    m_ptrEditItem->setGeometry(Warehouse_Tab_EditX_InView, Warehouse_TabY_InView,
                               Warehouse_TabW_InView, Warehouse_TabH_InView);
    m_ptrEditItem->registerEvent(DEvent::Detail, true);
    m_ptrEditItem->registerEvent(DEvent::DnD_Start, true);
    //m_ptrEditItem->registerEvent(DEvent::Drag, true);
    m_ptrEditItem->registerEvent(DEvent::DnD_Release, true);
    m_ptrEditItem->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onEditItem));
    m_ptrEditItem->setSelected(false);

    //user-defined button
    m_ptrUserItem.reset(new(std::nothrow) DButton("UserDefined",
                                                  img,
                                                  selImg,
                                                  getViewFrame()));
    assert(m_ptrUserItem.get() != NULL);
    m_ptrUserItem->setTextColor(Default_Dialog_TextColor);
    m_ptrUserItem->setGeometry(Warehouse_Tab_UserX_InView, Warehouse_TabY_InView,
                               Warehouse_TabW_InView, Warehouse_TabH_InView);
    m_ptrUserItem->registerEvent(DEvent::Detail, true);
    m_ptrUserItem->registerEvent(DEvent::DnD_Start, true);
    //m_ptrUserItem->registerEvent(DEvent::Drag, true);
    m_ptrUserItem->registerEvent(DEvent::DnD_Release, true);
    m_ptrUserItem->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DWarehouseDlg::onUserItem));
    m_ptrUserItem->setSelected(false);

    //Shared button
    m_ptrSharedItem.reset(new(std::nothrow) DButton("Shared",
                                                    img,
                                                    selImg,
                                                    getViewFrame()));
    assert(m_ptrSharedItem.get() != NULL);
    m_ptrSharedItem->setTextColor(Default_Dialog_TextColor);
    m_ptrSharedItem->setGeometry(Warehouse_Tab_SharedX_InView, Warehouse_TabY_InView,
                                 Warehouse_TabW_InView, Warehouse_TabH_InView);
    m_ptrSharedItem->registerEvent(DEvent::Detail, true);
    m_ptrSharedItem->registerEvent(DEvent::DnD_Start, true);
    //m_ptrSharedItem->registerEvent(DEvent::Drag, true);
    m_ptrSharedItem->registerEvent(DEvent::DnD_Release, true);
    m_ptrSharedItem->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DWarehouseDlg::onSharedItem));
    m_ptrSharedItem->setSelected(false);

    setCurSelectedClassic(AllItems);
}

//warehouse view, see the style below
//
//   item   item   item
//   text   text   text
//-------------------------(Horizontal Line image)
//
void DWarehouseDlg::initWarehouseView()
{
    int layerHeight = Warehouse_TotalLayer_H_InView / m_rowNum;
    for(int i = 0 ; i < m_rowNum; ++i)
    {
        DFramePtr ptrViewLayer(new(std::nothrow) DFrame(getViewFrame()));
        assert(ptrViewLayer.get() != NULL);
        ptrViewLayer->setGeometry(Warehouse_Layer_X_InView, 
                                  Warehouse_Layer_StartY_InView + layerHeight * i,
                                  Warehouse_Layer_W_InView,
                                  layerHeight);
        
        ptrViewLayer->setBackgroundColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameBorderColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameStyle(DFrame::Panel);
        ptrViewLayer->setDisplayOrder(Default_Dialog_DisplayOrder);
        ptrViewLayer->registerEvent(DEvent::DnD_Start, true);
        //ptrViewLayer->registerEvent(DEvent::Drag, true);
        ptrViewLayer->registerEvent(DEvent::DnD_Release, true);
        ptrViewLayer->registerEvent(DEvent::Detail, true);
        ptrViewLayer->registerEvent(DEvent::Select, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Start, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Release, true);
        m_viewLayers.push_back(ptrViewLayer);
        fillItemsInViewLayer(ptrViewLayer.get(), i);
    }
}

void DWarehouseDlg::fillItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{
    DImage dukeItemImg;
    dukeItemImg.load(getResPath() + WarehouseItemImage_FileName);   

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                           dukeItemImg,
                                                           pViewLayer));
        int dukeIconX = Warehouse_Icon_StartX_InLayer + Warehouse_Icon_SpacingX_InLayer * i;
        ptrItemButton->setGeometry(dukeIconX,
                                   Warehouse_Icon_Y_InLayer,
                                   Warehouse_Icon_W_InLayer,
                                   Warehouse_Icon_H_InLayer);
        m_items.push_back(ptrItemButton);        

        DLabelPtr ptrItemText(new(std::nothrow) DLabel("N/A",
                                                       pViewLayer));
        int dukeTextX = Warehouse_Text_StartX_InLayer + Warehouse_Text_SpacingX_InLayer * i;
        ptrItemText->setAlignment(AlignCenter);
        ptrItemText->setGeometry(dukeTextX,
                                 Warehouse_Text_Y_InLayer,
                                 Warehouse_Text_W_InLayer,
                                 Warehouse_Text_H_InLayer);
        ptrItemText->setBackgroundColor(Duke_Transparent_Color);
        ptrItemText->setFrameBorderColor(Duke_Transparent_Color);
        ptrItemText->setTextColor(Default_Dialog_TextColor);

        //add the event (passthrough)
        ptrItemText->registerEvent(DEvent::DnD_Start, true);
        //ptrItemText->registerEvent(DEvent::Drag, true);
        ptrItemText->registerEvent(DEvent::DnD_Release, true);
        ptrItemText->registerEvent(DEvent::Detail, true);
        ptrItemText->registerEvent(DEvent::Select, true);
        //ptrItemButton->registerEvent(DEvent::Drag, true);
        ptrItemButton->registerEvent(DEvent::DnD_Release, true);
        ptrItemButton->registerEvent(DEvent::Detail, true);
        ptrItemButton->registerEvent(DEvent::Select, true);
        //add the real event
        ptrItemButton->registerEvent(DEvent::DnD_Start);
        ptrItemButton->registerEvent(DEvent::Activate);
        ptrItemButton->registerEvent(DEvent::Hover);
        ptrItemButton->registerEvent(DEvent::PassingOut);
        ptrItemButton->setEventRoutine(DEvent::Activate,
                                       this, 
                                       static_cast<EventRoutine>(&DWarehouseDlg::onActivate));
        ptrItemButton->setEventRoutine(DEvent::Hover,
                                       this,
                                       static_cast<EventRoutine>(&DWarehouseDlg::onHover)); 
        ptrItemButton->setEventRoutine(DEvent::PassingOut,
                                       this,
                                       static_cast<EventRoutine>(&DWarehouseDlg::onPassingOut));
        
        m_texts.push_back(ptrItemText);        
    }    
}

void DWarehouseDlg::updateItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{
    //In order to improve performance, just update the img and text when change dukeitem
    DImage dukeDefaultImg;
    dukeDefaultImg.load(getResPath() + WarehouseItemImage_FileName);   
    int pageNum = m_rowNum * m_columnNum;
    int curSize = m_ptrImpl->getDukeItemsSize(m_searchKey);

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButton* pItemButton = m_items[lineNum *  m_columnNum + i].get();
        DLabel* pItemText = m_texts[lineNum *  m_columnNum + i].get();
        int curPos = i + lineNum * m_columnNum + m_curPage * pageNum;
        if( curPos >= curSize)
        {
            //more than current item       
            pItemButton->setHideProperty(true);
            pItemText->setHideProperty(true);
        }
        else
        {
            pItemButton->setHideProperty(false);
            pItemText->setHideProperty(false);        

            duke_media_handle handle =
                m_ptrImpl->getDukeHandle(m_curPage*pageNum+lineNum*m_columnNum+i, m_searchKey);

            pItemButton->setMediaByHandle(handle);
            //pItemButton->setMediaHandleOnly(handle);
            if(handle.is_type_null())
            {
                pItemText->setContent(WarehouseDlg_Item_DefaultName);
                pItemButton->setImage(dukeDefaultImg);
            }
            else
            {
                std::string strname;
                if(duke_media_get_name(handle, strname) && !strname.empty())
                {
                    pItemText->setContent(strname);
                }
                else
                {
                    pItemText->setContent(WarehouseDlg_Item_DefaultName);                    
                }

                std::string stricon;
                if(duke_media_get_icon(handle, stricon) && !stricon.empty())
                {
                    DImage img;
                    img.setXScale(DImage::Stretch);
                    img.setYScale(DImage::Stretch);
                    img.setRelation(DImage::Disrelated);
                    std::vector<unsigned char> tempData(stricon.begin(), stricon.end());
                    img.setImageData(&tempData[0], tempData.size());
                    pItemButton->setImage(img);
                }
                else
                {
                    pItemButton->setImage(dukeDefaultImg);                    
                }
            }
        }
    }    
}

void DWarehouseDlg::updateView()
{    
    //Get list    
    WarehouseViewLayersIt it;
    int i = 0;
    for(it = m_viewLayers.begin(); it != m_viewLayers.end(); ++it)
    {
        DFrame* pViewLayer = (*it).get();
        assert(pViewLayer != NULL);
        updateItemsInViewLayer(pViewLayer, i);
        i++;
    }        
}

void DWarehouseDlg::setCurSelectedClassic(DukeItemClassic classic)
{
    m_ptrAllItem->setSelected(false);
    m_ptrBuiltInItem->setSelected(false);
    m_ptrEditItem->setSelected(false);
    m_ptrUserItem->setSelected(false);        
    m_ptrSharedItem->setSelected(false);

    switch(classic)
    {
    case AllItems:
        m_ptrAllItem->setSelected(true);
        break;
    case BuiltInItems:
        m_ptrBuiltInItem->setSelected(true);
        break;
    case EditItems:
        m_ptrEditItem->setSelected(true);
        break;
    case UserDefinedItems:
        m_ptrUserItem->setSelected(true);
        break;
    case SharedItems:
        m_ptrSharedItem->setSelected(true);
        break;
    case OtherItems:
    default:
        assert("!unsupport classic!");
    }

    m_ptrImpl->readDukeItems(classic);
    m_curClassic = classic;
}

/*---------------Event Handle-----------------*/
void DWarehouseDlg::processEnlargeEvent(const DEvent& rEvent)
{
    DDialog::processEnlargeEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DWarehouseDlg::processShrinkEvent(const DEvent& rEvent)
{
    DDialog::processShrinkEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DWarehouseDlg::processResizeReleaseEvent(const DEvent& rEvent)
{
    DDialog::processResizeReleaseEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DWarehouseDlg::onClose(const DEvent& rEvent)
{
    DDialog::onMinimize(rEvent);
}

void DWarehouseDlg::onSearch(const DEvent &event)
{    
    NEW_MARK_TIMER("DWarehouseDlg::onSearch");

    m_curPage = 0;
    m_ptrSearchKeyWord->onInputEvent(event);
    m_searchKey = m_ptrSearchKeyWord->content();    

    TIMER_MARK("getInput");
    //update
    updateView();

    TIMER_MARK("updateView");
    updateAll();
    TIMER_MARK("updateAll");
    repaint(event.getCon());
    TIMER_MARK("repaint");
}

void DWarehouseDlg::onAllItem(const DEvent &event)
{
    m_curPage = 0;
    setCurSelectedClassic(AllItems);
    /*
    m_ptrSearchKeyWord->setContent("");
    m_searchKey.clear();
    */

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onBuiltInItem(const DEvent &event)
{
    m_curPage = 0;
    setCurSelectedClassic(BuiltInItems);
    /*
    m_ptrSearchKeyWord->setContent("");
    m_searchKey.clear();
    */

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onEditItem(const DEvent &event)
{
    m_curPage = 0;
    setCurSelectedClassic(EditItems);
    /*
    m_ptrSearchKeyWord->setContent("");
    m_searchKey.clear();
    */

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onUserItem(const DEvent &event)
{
    m_curPage = 0;
    setCurSelectedClassic(UserDefinedItems);
    /*
    m_ptrSearchKeyWord->setContent("");
    m_searchKey.clear();
    */

    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onSharedItem(const DEvent &event)
{
    m_curPage = 0;
    setCurSelectedClassic(SharedItems);
    /*
    m_ptrSearchKeyWord->setContent("");
    m_searchKey.clear();
    */

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onBeginPage(const DEvent &event)
{    
    m_curPage = 0;

    updateView();  
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onPrePage(const DEvent &event)
{
    assert(m_curPage >= 0);
    if(m_curPage == 0)
        return;

    m_curPage--;

    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onNextPage(const DEvent &event)
{    
    //On next page, reload the new duke item and update view
    int totalPage = (m_ptrImpl->getDukeItemsSize(m_searchKey) - 1)
        / (m_rowNum * m_columnNum);

    if(m_curPage == totalPage)
        return;

    m_curPage++;
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onEndPage(const DEvent &event)
{
    //On end page, reload the last duke item and update view
    m_curPage = (m_ptrImpl->getDukeItemsSize(m_searchKey) - 1) 
        / (m_rowNum * m_columnNum);

    updateView();
    updateAll();
    repaint(event.getCon());
}

void DWarehouseDlg::onInputPage(const DEvent &event)
{
    /*
    bool isValidInput = true;
    m_ptrInputPage->onInputEvent(event);
    duke_item::DukeItemClassic classic = static_cast<duke_item::DukeItemClassic>(m_curClassic);
    int inputPage = 0;

    //if input nothing, just return.
    if(m_ptrInputPage->content().empty())
        return;

    //otherwise, get input number
    try
    {
        inputPage = boost::lexical_cast<int>(m_ptrInputPage->content()) - 1;
    }
    catch(boost::bad_lexical_cast &ex)
    {
        std::cout<<"Bad Input"<<ex.what()<<std::endl;
        isValidInput = false;
    }
    int totalPage = (m_ptrImpl->getDukeItemsSize(classic, m_searchKey) - 1)
        / (m_rowNum * m_columnNum);

    //if out of limit, only update the input number to current page number
    if( !isValidInput || inputPage < 0 || inputPage > totalPage)
    {
        //update the page number
        m_ptrInputPage->setContent(boost::lexical_cast<std::string>(m_curPage + 1));
        m_ptrInputPage->updateAll();
        m_ptrInputPage->repaint(event.getCon());
        return;
    }

    m_curPage = inputPage;

    updateView();
    //updateAll();
    //only update the warehouse view
    m_ptrWarehouseViewBg->updateAll();
    m_ptrWarehouseViewBg->repaint(event.getCon());
    */
}


void DWarehouseDlg::onDnDStart(const DEvent &event)
{
    //m_ptrImpl->onDnDStart(event);
}

void DWarehouseDlg::onActivate(const DEvent &event)
{
    m_ptrImpl->onActivate(event);
}

void DWarehouseDlg::onHover(const DEvent &event)
{
    m_ptrImpl->onHover(event);
}

void DWarehouseDlg::onPassingOut(const DEvent &event)
{
    m_ptrImpl->onPassingOut(event);
}

void DWarehouseDlg::onPassingInBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(true);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DWarehouseDlg::onPassingOutBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DWarehouseDlg::onCreateNew(const DEvent &event)
{
    //TBD
    m_ptrImpl->onCreateNew(event);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
