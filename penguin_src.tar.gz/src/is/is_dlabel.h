/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DLABEL_H
#define DLABEL_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "duc.h"
#include "is_dwidget.h"
#include "is_dframe.h"
#include "is_dimage.h"

class DLabelCell;

class DLabel : public DFrame {
public:
    DLabel(DWidget *parent = 0, WFlags f = 0);
    DLabel(const std::string &text, DWidget *parent = 0, WFlags f = 0);
    virtual ~DLabel();

    DText text() const;
    DText &rtext();
    void setText(const DText &text);

    std::string content() const;
    void setContent(const std::string& text);

    DFont font() const;
    void setFont(const DFont& font);

    AlignmentFlag alignment() const;
    void setAlignment(AlignmentFlag);
    
    int indent() const;
    void setIndent(int);

    bool wordWrap() const;
    void setWordWrap(bool);

    DColor textColor() const;
    void setTextColor(const DColor& rColor);

private:
    DLabel(const DLabel& rLabel);
    DLabel& operator=(const DLabel& rLabel);

private:
    DText m_text;
    int m_indent;
  
    D_DECLARE_CELL(DLabel)
};

typedef std::tr1::shared_ptr<DLabel> DLabelPtr;
typedef std::tr1::shared_ptr<DLabelCell> DLabelCellPtr;

/***************************************************************************
 * DLabel inline functions
 **************************************************************************/
inline DText DLabel::text() const
{ return m_text; }

inline DText &DLabel::rtext()
{ return m_text; }

inline void DLabel::setText(const DText &text)
{ m_text = text; }

inline std::string DLabel::content()const
{ return m_text.textData(); }

inline void DLabel::setContent(const std::string &content)
{ m_text.setTextData(content); }

inline DFont DLabel::font()const
{ return m_text.font(); }

inline void DLabel::setFont(const DFont &font)
{ m_text.setFont(font); }

inline AlignmentFlag DLabel::alignment() const
{ return m_text.align(); }

inline void DLabel::setAlignment(AlignmentFlag align)
{ m_text.setAlign(align); }

inline int DLabel::indent() const
{ return m_indent; }

inline void DLabel::setIndent(int indent)
{ m_text.rmargin().setLeft(indent); }

inline bool DLabel::wordWrap() const
{ return m_text.wrap(); }

inline void DLabel::setWordWrap(bool w)
{ m_text.setWrap(w); }

inline DColor DLabel::textColor() const
{ return m_text.color(); }

inline void DLabel::setTextColor(const DColor& rColor)
{ m_text.setColor(rColor); }


class DLabelCell : public DFrameCell {
public:
    DLabelCell();
    virtual ~DLabelCell();

    void init();
    void update();

private:
    D_DECLARE_PUBLIC(DLabel)
};

const std::string Label_ObjName("Label");

#endif //DLABEL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
