/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author     State     Date
** Yinlii     Add       2010-03-22
**
****************************************************************************/

#ifndef DMARGIN_H
#define DMARGIN_H

// Boost header files
#include <boost/tr1/memory.hpp>

class DMargin {
public:
    DMargin();
    DMargin(int left,int top,int right,int bottom);

    ~DMargin() { }

    bool isNull() const;

    int left() const;
    void setLeft(int left);

    int  right() const;
    void setRight(int right);

    int top() const;
    void setTop(int top);

    int bottom() const;
    void setBottom(int bottom);

private: 
    friend inline bool operator==(const DMargin &m1,const DMargin &m2);
    friend inline bool operator!=(const DMargin &m1,const DMargin &m2);
  
    int m_left;
    int m_right;
    int m_top;
    int m_bottom;
};

typedef std::tr1::shared_ptr<DMargin> DMarginPtr;

/***************************************************************************
 * DMargin inline functions
 **************************************************************************/
//Constructs a margins class
inline DMargin::DMargin()
    : m_left(0),
      m_right(0),
      m_top(0),
      m_bottom(0)
{ }

//Constructs a margins with a given left,right,top and bottom.
inline DMargin::DMargin(int left,int right,int top,int bottom)
    : m_left(left),
      m_right(right),
      m_top(top),
      m_bottom(bottom)
{ }

inline bool DMargin::isNull() const
{ return m_left == 0 && m_right == 0 && m_top == 0 && m_bottom == 0; }

//Returns the left of the margin.
inline int DMargin::left() const
{ return m_left; }

//Sets the left of the margin.
inline void DMargin::setLeft(int left)
{ m_left = left; }

//Returns the right of margin.
inline int DMargin::right() const
{ return m_right; }

//Sets the right of margin.
inline void DMargin::setRight(int right)
{ m_right = right; }

//Returns the top of the margin.
inline int DMargin::top() const
{ return m_top; }

//Sets the top of the margin.
inline void DMargin::setTop(int top)
{ m_top = top; }

//Returns the bottom of the margin.
inline int DMargin::bottom() const
{ return m_bottom; }

//Sets the bottom of the margin.
inline void DMargin::setBottom(int bottom)
{ m_bottom = bottom; }

inline bool operator==(const DMargin &m1, const DMargin &m2)
{ 
    return m1.m_left == m2.m_left &&
           m1.m_right == m2.m_right &&
           m1.m_top == m2.m_top &&
           m1.m_bottom == m2.m_bottom;
}

inline bool operator!=(const DMargin &m1, const DMargin &m2)
{ 
    return m1.m_left != m2.m_left ||
           m1.m_right != m2.m_right ||
           m1.m_top != m2.m_top ||
           m1.m_bottom != m2.m_bottom;
}

#endif //DMARGIN_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
