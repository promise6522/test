/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DLOGINDLG_H
#define DLOGINDLG_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"
#include "is_dbutton.h"

class DLogInDlg : public DDialogEx
{
public:
    explicit DLogInDlg(DMainWin * pMainWin = NULL, DWidget * parent = 0);
    explicit DLogInDlg(std::string title, DMainWin * pMainWin = NULL, DWidget * parent = 0);
    virtual ~DLogInDlg();

    //Init    
    virtual void initDialog();

protected:
    //Event handle
    void onActivate(const DEvent &event);
    void onHover(const DEvent &event);
    void onPassingOut(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onDelAccess(const DEvent &event);
    void onMenuBlur(const DEvent& event);
    void onSelAnchor(const DEvent& event);

    void deletePopupMenu();

    //menu event handle
    virtual void onClose(const DEvent& rEvent);
    
private:
    DButtonPtr m_ptrAccess;
    DLabelPtr m_ptrAccessText;    
    DPopupMenuPtr m_ptrPopupMenu;
};

typedef std::tr1::shared_ptr<DLogInDlg>  DLogInDlgPtr;

const std::string LogInDlg_ObjName("LogIn_Dialog");
const std::string LogInDlg_Title_Name("Login Access setting");
const std::string LogInDlg_AccessImg_FileName("access.png");

const int LogInX_InMainWin = 2000;
const int LogInY_InMainWin = 2000;
const int LogInW_InMainWin = 3000;
const int LogInH_InMainWin = 5000;

const size_t Popup_Anchor_Item_Size = 4;

#endif /* DLOGINDLG_H */
