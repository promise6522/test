/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#ifndef DARCEX_H
#define DARCEX_H

#include <boost/tr1/memory.hpp>
#include "is_dwidget.h"
#include "is_dtool.h"
#include "is_darc.h"

class DArcExCell;

class DArcEx : public DWidget {
public:
    DArcEx(DWidget *parent = 0, WFlags f = 0);
    virtual ~DArcEx();

    // event handle
    virtual bool event(DEvent *);
    void onHoverEvent(const DEvent& rEvent);
    void onPassingOutEvent(const DEvent& rEvent);

private:
    DArcPtr m_ptrArc;

    D_DECLARE_CELL(DArcEx)
};


class DArcExCell : public DWidgetCell {
public:
    DArcExCell();
    virtual ~DArcExCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DArcEx)
};

typedef std::tr1::shared_ptr<DArcEx>  DArcExPtr;
typedef std::tr1::shared_ptr<DArcExCell>  DArcExCellPtr;

const std::string DArcEx_ObjName("DArcEx_Object");

#endif // DART_H
// vim:set tabstop=4 shiftwidth=4 expandtab:
