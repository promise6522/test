/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DOBJECT_H
#define DOBJECT_H

// Boost header files
#include <boost/tr1/memory.hpp>

// C++ 98 header files
#include <string>
#include <vector>
#include <list>

// Duke header files
#include "duc.h"

class DObject;

typedef std::list<DObject*> DObjectList;
typedef std::list<DObject*>::iterator DObjectListIt;
typedef std::vector<int> DPath;

/*
 * The DObject class is the base class of all objects.
 *
 * It is mainly responsible for creation and maintenance of
 * object tree (or wrapper tree).
 */
class DObject {
public:
    DObject(DObject * parent=0);
    virtual ~DObject();

    std::string objectName() const { return objname; }
    void setObjectName(std::string name) { objname=name; }
    
    DPath objectPath() const { return objpath; }
    std::string strPath() const;
    void setObjectPath(DPath &path) { objpath=path; }
    DObject *parent() const { return parentObj; }

    void insertChild(DObject *);
    void removeChild(DObject *);
    DObject *findChild(const DPath &path)const;
    DObjectList *children() const { return childObjects; }
    
    void dumpObjectInfo();

    int &cnum() { return childNum; }
    
private:
    bool isTree;

    std::string objname;
    int childNum;
    DPath objpath;
    DObject *parentObj;
    DObjectList *childObjects;
};

typedef std::tr1::shared_ptr<DObject> DObjectPtr;

#endif //DOBJECT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
