/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DIMPLEDITOR_H
#define DIMPLEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_dfunc.h"
#include "is_deditor.h"
#include "is_dobjicon.h"
#include "is_ddecleditor.h"
#include "duke_media_global.h"

typedef std::vector<DWidgetPtr> ImplWidgets;
typedef ImplWidgets::iterator ImplWidgetsIt;
typedef ImplWidgets::size_type ImplWidgetsIdx;

typedef std::map<DWidget*, std::string>::const_iterator implMapIt;

typedef std::pair<DPopupMenuPtr, DEdgePtr> MenuEdgePair;

//path mode
enum mode
{
    impl_path_minus= 0,
    impl_path_plus
};

//warehouse type
enum impl_node_type
{
    impl_node_general = 0,
    impl_node_condition,
    impl_node_loop,
    impl_node_none
};

class DImplEditor : public DEditor 
{
public:
    explicit DImplEditor(int model = DEditor::DialogModel,
                         DMainWin * pMainWin = NULL, 
                         DWidget * parent = 0,
                         WFlags f = 0);
    explicit DImplEditor(const std::string& title,
                         int model = DEditor::DialogModel,
                         DMainWin *pMainWin = NULL,
                         DWidget * parent = 0,
                         WFlags f = 0);
    explicit DImplEditor(const std::string& title,
                         const duke_media_handle& handle,
                         int model = DEditor::DialogModel,
                         DMainWin *pMainWin = NULL,
                         DWidget * parent = 0,
                         WFlags f = 0);
    virtual ~DImplEditor();

    // Init    
    virtual void initDialog();   

    //init the implementation by duke_media_handle
    void duplicateItemsByHandle(const duke_media_handle& himpl);
    void initItemsByMediaBase();

    //reload
    virtual void reload();

    //generate
    virtual duke_media_handle generate();
    virtual void generateSubItems();

    //readonly
    void setInternalWidgetReadonly(DWidget* pWidget);
    virtual void setReadonly();

    // adjust
    virtual void adjustPlacement();

    // manage widget in the editor
    DWidgetPtr createWidget(const duke_media_handle &h, 
        bool bCreateFunc,//whether to create DFunc or DObjIcon for a declaration
        const duke_media_handle& hFuncOwnerIf = NB_INTERFACE_NONE,//needed by some DFunc for its owner interface
        const bool is_need_clone = false);
    //caution: only for reconversion of duke_media_declare_expanded
    DWidgetPtr createWidget(const duke_media_node& node);

    int inLayer(int height, int layer,int adjustHeight = 0);
    int getIndexByWidget(DWidget* pWidget);

    // Event handle
    void onDnDStart(const DEvent &event);
    void onDnDDrag(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDeleteWidget(const DEvent &event);
    void onMenuBlur(const DEvent& event);
    void onActivatePorts(const DEvent &event);
    void onActivateFunc(const DEvent &event);    
    void onActivateObj(const DEvent &event);
/*    void onActivateStorage(const DEvent &event);*/
    void onActivateInterface(const DEvent &event);
    void onReleaseDecl(const DEvent &event);
    void onImplType(const DEvent &event);

    void deletePopMenu(const DEvent &event);

    //save
    void saveInternalNodeInfo();

    //for func
    void switchByImplType();

    //for path 
    void deal_path(DEdgePtr ptrE, mode select, bool timeLine = false);

protected:
    virtual void onGenerate(const DEvent& rEvent);

private:
    void initEventHandle();
    void initImplTypeButtons();
    void setCurSelectedType(impl_node_type type);
    void updateEdgesPos();
    void deletePopupMenuAndEdge();
    void updateTypeButtons();
    void updateImplWidgets(int adjustHeight = 0);
    void updateInOutPorts();
    void dumpImplementInfo();
    int getIndexByNodeName(const std::string & name);
    //detach the edge related to in/out ports when change the declaration
    void detachEdgeFromPorts();
    bool isValidImpl(duke_media_implement* pImplMedia);
    void adjustEdgesForPorts(const duke_media_handle_vector& hiifs, 
            const duke_media_handle_vector& hoifs,
            const WidgetIndexs &inPortsSeq, 
            const WidgetIndexs &outPortsSeq);

    //switch implementation type
    void switchToGeneralImpl();
    void switchToConditionImpl();
    void switchToLoopImpl();

    //save
    void saveImplType();
    void saveCondImplNodeInfo();
    void saveNodeInfo();
    
    void dialogRelease(const DEvent& rEvent);
    void portRelease(const DEvent& rEvent, DPort* pSrcPort);
    void funcRelease(const DEvent& rEvent, DFunc* pSrcFunc);
    void objRelease(const DEvent& rEvent, DObjIcon* pSrcObj);
    void onSelectDeclaration(const DEvent& rEvent);
    void addWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget);
    void pushWidgetToEditor(int x, DWidgetPtr ptrWidget);

    // for NB_FUNC_INTERFACE_CONVERT
    bool getConvertInterface(DEdgePtr pEdge, duke_media_handle& hif);

    //ajust subobject's position for condition
    void ajustCondition(DWidget *pSrcWidget, int y);

    DWidget* getWidgetFromLink(const std::string& name);    
private:
    ImplWidgets m_implWidgets;
    DFuncPtr m_ptrInFunc;
    DFuncPtr m_ptrOutFunc;
    
    impl_node_type m_implType;
    int m_typeButtonHeight;
    DButtonPtr m_ptrGeneral;
    DButtonPtr m_ptrCondition;
    DButtonPtr m_ptrLoop;
    DButtonPtr m_ptrShare;

    int m_layer;
    int m_blank;
    int m_layerHeight;
    DPoint m_dragPoint;
    MenuEdgePair m_menuEdgePair;

    duke_media_handle m_storage_hif;    

    //store subobject's position for condition
    std::vector<int> m_subConPosition;
    //store the name map to DWidget
    int m_index; 
    std::map<DWidget*, std::string> m_link;

    bool m_shared;
    duke_media_handle m_master;
};

typedef std::tr1::shared_ptr<DImplEditor>  DImplEditorPtr;
const std::string ImplEditor_ObjName("Implementation_Editor");
const std::string ImplEditor_Title("Duke Implementation Editor");

const std::string Default_Implement_Icon("impl_origin.png");

const std::string ImplEditor_TypeImg_FileName("impleditor_type_ori.png");
const std::string ImplEditor_TypeSelImg_FileName("impleditor_type_sel.png");

const std::string ImplEditor_DefaultObj_FileName("object_selected.png");
const std::string ImplEditor_DefaultStorage_FileName("storage.png");
const std::string ImplEditor_DefaultAccess_FileName("access.png");
const std::string ImplEditor_DefaultRootAccess_FileName("root_access.png");

const std::string ImplEditor_ArrayImg_FileName("array.png");
const std::string ImplEditor_ArrayExImg_FileName("array_ex.png");
const std::string ImplEditor_MapImg_FileName("map.png");
const std::string ImplEditor_MapExImg_FileName("map_ex.png");

const int ImplEditor_Layer = 1000;
const int ImplEditor_Layer_Max = 20;
const int ImplEditor_Total_Layer = 4000;
const int ImplEditor_Default_Left = 4000;
const int ImplEditor_Default_Right = 6000;

const int ImplEditor_ExternalFunc_Left = 500;
const int ImplEditor_ExternalFunc_Right = 9500;

const int ImplEditor_Type_H_Pixel = 24;
const int ImplEditor_Type_H_InMainWin = ImplEditor_Type_H_Pixel * MAX_COORD / 768;

const int ImplEditor_Width = 336;
const int ImplEditor_Heigth = 448;

const int ImplEditor_Type_Heigth = ImplEditor_Type_H_Pixel * MAX_COORD / ImplEditor_Heigth ;
const int Default_ImplEditor_W_InMainWin = ImplEditor_Width * MAX_COORD / 1366;
const int Default_ImplEditor_H_InMainWin = ImplEditor_Heigth * MAX_COORD / 768;

const DColor ImplEditor_Error_Color(255, 0, 0);
const DColor ImplEditor_Warning_Color(0, 0, 255);
//add by bruce
const DColor ImplEditor_Iterator_Color(56,255,32);
const DColor ImplEditor_Condition_Color(255,255,255);

#endif // DIMPLEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
