/****************************************************************************
**
** Copyright 2011 Duke Inc.
**
** Author Bruce
**
****************************************************************************/

//boost header files, using lexical_cast for test example, remove it in future
#include "boost/lexical_cast.hpp"
#include "boost/algorithm/string.hpp"

// Duke header files
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dsharedhousedlg.h"
#include "is_daboutdlg.h"
#include "is_dapplication.h"

DSharedhouseDlg::DSharedhouseDlg(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent),
     m_rowNum(SharedhouseDlg_Default_RowNum),
     m_columnNum(SharedhouseDlg_Default_ColumnNum),
     m_curPage(0)
{
    LOG_DEBUG("=========first=======");
    setObjectName(SharedhouseDlg_ObjName);
    assert(pMainWin != NULL);    
    setTitleText(SharedhouseDlg_Title_Name);
}

DSharedhouseDlg::DSharedhouseDlg(const std::string &title,
                             DMainWin *pMainWin /* = NULL */,
                             DWidget * parent /* = 0 */)
    :DDialogEx(pMainWin, parent),
     m_rowNum(SharedhouseDlg_Default_RowNum),
     m_columnNum(SharedhouseDlg_Default_ColumnNum),
     m_curPage(0)
{
    LOG_DEBUG("=========second=======");
    setObjectName(SharedhouseDlg_ObjName);
    assert(pMainWin != NULL);
    setTitleText(SharedhouseDlg_Title_Name);
}

DSharedhouseDlg::~DSharedhouseDlg()
{
}

int DSharedhouseDlg::SharedhouseRowNum() const
{
    return m_rowNum;    
}

int DSharedhouseDlg::SharedhouseColoumnNum() const
{
    return m_columnNum;    
}

int DSharedhouseDlg::getCurPagePos() const
{
    return m_curPage;
}

std::string DSharedhouseDlg::getSearchKeyWord() const
{
    return m_searchKey;
}

SharedhouseItemsIdx DSharedhouseDlg::getButtonItemIdx(DWidget * pWidget)
{
    SharedhouseItemsIdx idx = 0;
    for(SharedhouseItemsIt it = m_items.begin(); it != m_items.end(); ++it)
    {
        if((*it).get() == pWidget)
        {
            return idx;
        }
        ++idx;
    }    

    return idx;
}

void DSharedhouseDlg::initDialog()
{
    DDialogEx::initDialog();
    
    initControlBar();

    readDukeItems();

    initSharedhouseView();

    updateView();
   
    setEventRoutine(DEvent::Enlarge,
                    this,
                    static_cast<EventRoutine>(&DSharedhouseDlg::processEnlargeEvent));
    setEventRoutine(DEvent::Shrink,
                    this,
                    static_cast<EventRoutine>(&DSharedhouseDlg::processShrinkEvent));
    setEventRoutine(DEvent::Resize_Release,
                    this, 
                    static_cast<EventRoutine>(&DSharedhouseDlg::processResizeReleaseEvent));
    //add DEvent::DnD_Release
    this->registerEvent(DEvent::DnD_Release);
    this->setEventRoutine(DEvent::DnD_Release,
                    this, 
                    static_cast<EventRoutine>(&DSharedhouseDlg::onDnDRelease));

    updateAll();
}

//control bar, see the style below
//
//  < >   [_____]  [Search]
//
void DSharedhouseDlg::initControlBar()
{
    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //Previous page button
    img.load(getResPath() + Control_PrePageImg_FileName);
    selImg.load(getResPath() + Control_PrePageSelImg_FileName);
    m_ptrPrePage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrPrePage.get() != NULL);
    m_ptrPrePage->setGeometry(Sharedhouse_PrePageX_InView, Sharedhouse_PrePageY_InView, 
                              Sharedhouse_PrePageW_InView, Sharedhouse_PrePageH_InView);
    m_ptrPrePage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPrePage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrPrePage->registerEvent(DEvent::Drag, true);
    m_ptrPrePage->registerEvent(DEvent::DnD_Release, true);
    m_ptrPrePage->registerEvent(DEvent::Detail, true);
    m_ptrPrePage->registerEvent(DEvent::PassingIn);
    m_ptrPrePage->registerEvent(DEvent::PassingOut);
    m_ptrPrePage->registerEvent(DEvent::Grab);
    m_ptrPrePage->setEventRoutine(DEvent::Grab,
                                  this,
                                  static_cast<EventRoutine>(&DSharedhouseDlg::onPrePage));
    m_ptrPrePage->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DSharedhouseDlg::onPrePage));
    m_ptrPrePage->setEventRoutine(DEvent::PassingIn,
                                  this,
                                  static_cast<EventRoutine>(&DSharedhouseDlg::onPassingInBtn)); 
    m_ptrPrePage->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DSharedhouseDlg::onPassingOutBtn));
    m_ptrPrePage->setSelected(false);

    //Next page button
    img.load(getResPath() + Control_NextPageImg_FileName);
    selImg.load(getResPath() + Control_NextPageSelImg_FileName);
    m_ptrNextPage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrNextPage.get() != NULL);
    m_ptrNextPage->setGeometry(Sharedhouse_NextPageX_InView, Sharedhouse_NextPageY_InView, 
                               Sharedhouse_NextPageW_InView, Sharedhouse_NextPageH_InView);
    m_ptrNextPage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNextPage->registerEvent(DEvent::Detail, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrNextPage->registerEvent(DEvent::Drag, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Release, true);
    m_ptrNextPage->registerEvent(DEvent::PassingIn);
    m_ptrNextPage->registerEvent(DEvent::PassingOut);
    m_ptrNextPage->registerEvent(DEvent::Grab);
    m_ptrNextPage->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DSharedhouseDlg::onNextPage));    
    m_ptrNextPage->setEventRoutine(DEvent::Grab,
                                   this,
                                   static_cast<EventRoutine>(&DSharedhouseDlg::onNextPage));    
    m_ptrNextPage->setEventRoutine(DEvent::PassingIn,
                                   this,
                                   static_cast<EventRoutine>(&DSharedhouseDlg::onPassingInBtn)); 
    m_ptrNextPage->setEventRoutine(DEvent::PassingOut,
                                   this,
                                   static_cast<EventRoutine>(&DSharedhouseDlg::onPassingOutBtn));
    m_ptrNextPage->setSelected(false);


    //search line edit background
    img.load(getResPath() + Search_EditImg_FileName);
    m_ptrSearchEditBg.reset(new(std::nothrow) DImageLabel("", img, getViewFrame()));
    assert(m_ptrSearchEditBg.get() != NULL);
    m_ptrSearchEditBg->setGeometry(Sharedhouse_SearchX_InView, Sharedhouse_SearchY_InView,
                                   Sharedhouse_SearchW_InView, Sharedhouse_SearchH_InView);
    m_ptrSearchEditBg->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchEditBg->setFrameBorderColor(Duke_Transparent_Color);    

    //search line edit 
    m_ptrSearchKeyWord.reset(new(std::nothrow) DLineEdit(getViewFrame()));
    assert(m_ptrSearchKeyWord.get() != NULL);
    m_ptrSearchKeyWord->setGeometry(Sharedhouse_SearchEditX_InView, Sharedhouse_SearchY_InView,
                                    Sharedhouse_SearchEditW_InView, Sharedhouse_SearchH_InView);
    m_ptrSearchKeyWord->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setEventRoutine(DEvent::Input, this,
                                        (EventRoutine)(&DSharedhouseDlg::onSearch));
}

//Sharedhouse view, see the style below
//
//   item   item   item
//   text   text   text
//-------------------------(Horizontal Line image)
//
void DSharedhouseDlg::initSharedhouseView()
{
    int layerHeight = Sharedhouse_TotalLayer_H_InView / m_rowNum;
    for(int i = 0 ; i < m_rowNum; ++i)
    {
        DFramePtr ptrViewLayer(new(std::nothrow) DFrame(getViewFrame()));
        assert(ptrViewLayer.get() != NULL);
        ptrViewLayer->setGeometry(Sharedhouse_Layer_X_InView, 
                                  Sharedhouse_Layer_StartY_InView + layerHeight * i,
                                  Sharedhouse_Layer_W_InView,
                                  layerHeight);
        
        ptrViewLayer->setBackgroundColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameBorderColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameStyle(DFrame::Panel);
        ptrViewLayer->setDisplayOrder(Default_Dialog_DisplayOrder);
        ptrViewLayer->registerEvent(DEvent::DnD_Start, true);
        //ptrViewLayer->registerEvent(DEvent::Drag, true);
        ptrViewLayer->registerEvent(DEvent::DnD_Release, true);
        ptrViewLayer->registerEvent(DEvent::Detail, true);
        ptrViewLayer->registerEvent(DEvent::Select, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Start, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Release, true);
        ptrViewLayer->registerEvent(DEvent::Delete, true);

        m_viewLayers.push_back(ptrViewLayer);
        fillItemsInViewLayer(ptrViewLayer.get(), i);
    }
}

void DSharedhouseDlg::fillItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{
    DImage dukeItemImg;
    dukeItemImg.load(getResPath() + SharedhouseItemImage_FileName);   

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                           dukeItemImg,
                                                           pViewLayer));
        int dukeIconX = Sharedhouse_Icon_StartX_InLayer + Sharedhouse_Icon_SpacingX_InLayer * i;
        ptrItemButton->setGeometry(dukeIconX,
                                   Sharedhouse_Icon_Y_InLayer,
                                   Sharedhouse_Icon_W_InLayer,
                                   Sharedhouse_Icon_H_InLayer);
        m_items.push_back(ptrItemButton);        

        DLabelPtr ptrItemText(new(std::nothrow) DLabel("N/A",
                                                       pViewLayer));
        int dukeTextX = Sharedhouse_Text_StartX_InLayer + Sharedhouse_Text_SpacingX_InLayer * i;
        ptrItemText->setAlignment(AlignCenter);
        ptrItemText->setGeometry(dukeTextX,
                                 Sharedhouse_Text_Y_InLayer,
                                 Sharedhouse_Text_W_InLayer,
                                 Sharedhouse_Text_H_InLayer);
        ptrItemText->setBackgroundColor(Duke_Transparent_Color);
        ptrItemText->setFrameBorderColor(Duke_Transparent_Color);
        ptrItemText->setTextColor(Default_Dialog_TextColor);

        //add the event (passthrough)
        ptrItemText->registerEvent(DEvent::DnD_Start, true);
        //ptrItemText->registerEvent(DEvent::Drag, true);
        ptrItemText->registerEvent(DEvent::DnD_Release, true);
        ptrItemText->registerEvent(DEvent::Detail, true);
        ptrItemText->registerEvent(DEvent::Select, true);
        //ptrItemButton->registerEvent(DEvent::Drag, true);
        ptrItemButton->registerEvent(DEvent::DnD_Release, true);
        ptrItemButton->registerEvent(DEvent::Detail, true);
        ptrItemButton->registerEvent(DEvent::Select, true);
        //add the real event
        ptrItemButton->registerEvent(DEvent::DnD_Start);
        ptrItemButton->registerEvent(DEvent::Hover);
        ptrItemButton->registerEvent(DEvent::PassingOut);
        ptrItemButton->setFocusAttr(true);
        ptrItemButton->registerEvent(DEvent::Delete);
        ptrItemButton->setEventRoutine(DEvent::Hover,
                                       this,
                                       static_cast<EventRoutine>(&DSharedhouseDlg::onHover)); 
        ptrItemButton->setEventRoutine(DEvent::PassingOut,
                                       this,
                                       static_cast<EventRoutine>(&DSharedhouseDlg::onPassingOut));
        ptrItemButton->setEventRoutine(DEvent::Delete,
                                       this,
                                       static_cast<EventRoutine>(&DSharedhouseDlg::onDeleteObject));

        m_texts.push_back(ptrItemText);        
    }    
}

void DSharedhouseDlg::updateItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{
    //In order to improve performance, just update the img and text when change dukeitem
    DImage dukeDefaultImg;
    dukeDefaultImg.load(getResPath() + SharedhouseItemImage_FileName);   
    int pageNum = m_rowNum * m_columnNum;
    int curSize = getDukeItemsSize(m_searchKey);

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButton* pItemButton = m_items[lineNum *  m_columnNum + i].get();
        DLabel* pItemText = m_texts[lineNum *  m_columnNum + i].get();
        int curPos = i + lineNum * m_columnNum + m_curPage * pageNum;
        if( curPos >= curSize)
        {
            //more than current item       
            pItemButton->setHideProperty(true);
            pItemText->setHideProperty(true);
        }
        else
        {
            pItemButton->setHideProperty(false);
            pItemText->setHideProperty(false);        

            duke_media_handle handle = getDukeHandle(m_curPage*pageNum+lineNum*m_columnNum+i, m_searchKey);
       
            pItemButton->setMediaByHandle(handle);
            if(handle.is_type_null())
            {
                pItemText->setContent(WarehouseDlg_Item_DefaultName);
                pItemButton->setImage(dukeDefaultImg);
            }
            else
            {
                std::string strname;
                if(duke_media_get_name(handle, strname) && !strname.empty())
                {
                    pItemText->setContent(strname);
                }
                else
                {
                    pItemText->setContent(WarehouseDlg_Item_DefaultName);                    
                }

                std::string stricon;
                if(duke_media_get_icon(handle, stricon) && !stricon.empty())
                {
                    DImage img;
                    img.setXScale(DImage::Stretch);
                    img.setYScale(DImage::Stretch);
                    img.setRelation(DImage::Disrelated);
                    std::vector<unsigned char> tempData(stricon.begin(), stricon.end());
                    img.setImageData(&tempData[0], tempData.size());
                    pItemButton->setImage(img);
                }
                else
                {
                    pItemButton->setImage(dukeDefaultImg);                    
                }
            }
        }
    }
}

void DSharedhouseDlg::updateView()
{    
    //Get list    
    SharedhouseViewLayersIt it;
    int i = 0;
    for(it = m_viewLayers.begin(); it != m_viewLayers.end(); ++it)
    {
        DFrame* pViewLayer = (*it).get();
        assert(pViewLayer != NULL);
        updateItemsInViewLayer(pViewLayer, i);
        i++;
    }        
}

/*---------------Event Handle-----------------*/
void DSharedhouseDlg::onDnDRelease(const DEvent& rEvent)
{
    LOG_DEBUG("--------------DSharedhouseDlg::onDnDRelease-----------------");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    if(pObject->parent()->parent()->parent() == this)
    {
        return;
    }
    DDialog* pDialog = dynamic_cast<DDialog *>(pObject);
    if (NULL  != pDialog) {
        DObject* pDragObject = pApp->top()->findChild(childPath[0]);
        DFrame* pFrame = static_cast<DFrame*>(pDragObject);
        dialogRelease(rEvent,pFrame);
        return;
     }
    if (pObject)
    {
        DButton* pSrcWidget = dynamic_cast<DButton *>(pObject);
        if(NULL == pSrcWidget) return;
        duke_media_handle handle = pSrcWidget->getMediaHandle();

        if (e_handle_core != get_media_handle_status(handle))
        {
            LOG_ERROR("Can't drag an editing object to share.");
            return;
        }

        for(duke_media_handle_vector::size_type index = 0; index < m_dukeItems.size();++index)
        {
            if(m_dukeItems[index] == handle)
            {
                return;
            }
        }

        m_dukeItems.push_back(handle);
        writeDukeItems();
        readDukeItems();
        reloadCache(m_searchKey);
        updateView();
        updateAll();
        repaint(rEvent.getCon());
    }

}
void DSharedhouseDlg::dialogRelease(const DEvent &event,DFrame* pFrame)
{
    assert(NULL !=m_pMainWin);
    DPoint releasePos = event.getEventPosition();
    DWidget* pWidget = pFrame;       
    DWidget *pParentWidget = dynamic_cast<DWidget *>(pWidget->parent());
    while ((pParentWidget != NULL) && (pParentWidget != m_pMainWin)) {
        DPoint pPos = pWidget->geometryPos();
        DSize pSize = pWidget->geometrySize();
        releasePos.setX(releasePos.x() * pSize.width() / MAX_COORD + pPos.x());
        releasePos.setY(releasePos.y() * pSize.height() / MAX_COORD + pPos.y());
        pWidget = pParentWidget;
        pParentWidget = dynamic_cast<DWidget *>(pParentWidget->parent());
    }
    DEvent& eventRef = const_cast<DEvent &>(event);
    eventRef.setEventPosition(releasePos);
    m_pMainWin->onDnDRelease(event);
}
void DSharedhouseDlg::onDeleteObject(const DEvent &event)
{
    LOG_DEBUG("--------------DSharedhouseDlg::onDeleteObject-----------------");
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = this->getApplication()->top()->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (pWidget == NULL)
        return;

    duke_media_handle_iterator iter = 
    std::find(m_dukeItems.begin(), m_dukeItems.end(), pWidget->getMediaHandle());
    if (iter != m_dukeItems.end())
        m_dukeItems.erase(iter);
    else return;
    writeDukeItems();
    readDukeItems();
    reloadCache(m_searchKey);
    updateView();
    updateAll();
    this->getApplication()->tip()->remove(event.getCon());
    repaint(event.getCon());
}

void DSharedhouseDlg::processEnlargeEvent(const DEvent& rEvent)
{
    DDialog::processEnlargeEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DSharedhouseDlg::processShrinkEvent(const DEvent& rEvent)
{
    DDialog::processShrinkEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DSharedhouseDlg::processResizeReleaseEvent(const DEvent& rEvent)
{
    DDialog::processResizeReleaseEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DSharedhouseDlg::onClose(const DEvent& rEvent)
{
    DDialog::onMinimize(rEvent);
}

void DSharedhouseDlg::onSearch(const DEvent &event)
{   
    LOG_DEBUG("------------DSharedhouseDlg::onSearch------------"); 
    m_curPage = 0;
    m_ptrSearchKeyWord->onInputEvent(event);
    m_searchKey = m_ptrSearchKeyWord->content();    

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DSharedhouseDlg::onBeginPage(const DEvent &event)
{    
    m_curPage = 0;

    updateView();  
    updateAll();
    repaint(event.getCon());
}

void DSharedhouseDlg::onPrePage(const DEvent &event)
{
    assert(m_curPage >= 0);
    if(m_curPage == 0)
        return;

    m_curPage--;

    updateView();
    updateAll();
    repaint(event.getCon());
}

void DSharedhouseDlg::onNextPage(const DEvent &event)
{    
    //On next page, reload the new duke item and update view
    int totalPage = (getDukeItemsSize(m_searchKey) - 1)
        / (m_rowNum * m_columnNum);

    if(m_curPage == totalPage)
        return;

    m_curPage++;
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DSharedhouseDlg::onEndPage(const DEvent &event)
{
    //On end page, reload the last duke item and update view
    m_curPage = (getDukeItemsSize(m_searchKey) - 1) 
        / (m_rowNum * m_columnNum);

    updateView();
    updateAll();
    repaint(event.getCon());
}

//void DSharedhouseDlg::onInputPage(const DEvent &event)
//{
    /*
    bool isValidInput = true;
    m_ptrInputPage->onInputEvent(event);
    duke_item::DukeItemClassic classic = static_cast<duke_item::DukeItemClassic>(m_curClassic);
    int inputPage = 0;

    //if input nothing, just return.
    if(m_ptrInputPage->content().empty())
        return;

    //otherwise, get input number
    try
    {
        inputPage = boost::lexical_cast<int>(m_ptrInputPage->content()) - 1;
    }
    catch(boost::bad_lexical_cast &ex)
    {
        std::cout<<"Bad Input"<<ex.what()<<std::endl;
        isValidInput = false;
    }
    int totalPage = (m_ptrImpl->getDukeItemsSize(classic, m_searchKey) - 1)
        / (m_rowNum * m_columnNum);

    //if out of limit, only update the input number to current page number
    if( !isValidInput || inputPage < 0 || inputPage > totalPage)
    {
        //update the page number
        m_ptrInputPage->setContent(boost::lexical_cast<std::string>(m_curPage + 1));
        m_ptrInputPage->updateAll();
        m_ptrInputPage->repaint(event.getCon());
        return;
    }

    m_curPage = inputPage;

    updateView();
    //updateAll();
    //only update the Sharedhouse view
    m_ptrSharedhouseViewBg->updateAll();
    m_ptrSharedhouseViewBg->repaint(event.getCon());
    */
//}


/*void DSharedhouseDlg::onDnDStart(const DEvent &event)
{
    //m_ptrImpl->onDnDStart(event);
}

void DSharedhouseDlg::onActivate(const DEvent &event)
{
    m_ptrImpl->onActivate(event);
}*/

void DSharedhouseDlg::onHover(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = getApplication()->top()->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (pWidget == NULL)
        return;

    size_t idx = getButtonItemIdx(pWidget);

    // open editor
    int curPos = idx + getCurPagePos() * SharedhouseRowNum() 
        * SharedhouseColoumnNum();
    std::string itemTip;
    duke_media_handle handle = getDukeHandle(curPos,getSearchKeyWord());
    if(!handle.is_type_null() && duke_media_get_name(handle, itemTip))
    {        
        this->getApplication()->tip()->add(pWidget, itemTip, event.getCon());
    }
}

void DSharedhouseDlg::onPassingOut(const DEvent &event)
{
    //close editor
    this->getApplication()->tip()->remove(event.getCon());
}

void DSharedhouseDlg::onPassingInBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(true);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DSharedhouseDlg::onPassingOutBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DSharedhouseDlg::cleanCache()
{
    //clear cache
    m_cacheItemsSize = 0;
    m_cacheKeyString.clear();
    m_cacheHandleIdxes.clear();
}

void DSharedhouseDlg::reloadCache(std::string keyWord /* = "" */)
{
    cleanCache();
    //reload cache for the new keyword
    int readNum = 0;
    std::string dukeName;
    duke_media_handle_size_type idx = 0;    
    for(duke_media_handle_iterator it = m_dukeItems.begin();it != m_dukeItems.end();++it, ++idx)
    {
        if(!duke_media_get_name(*it, dukeName))
            continue;
                                            
        if(boost::icontains(dukeName, keyWord))
        {
            readNum++;
            m_cacheHandleIdxes.push_back(idx);
        }
    }
    //ret cache
    m_cacheKeyString = keyWord;
    m_cacheItemsSize = m_cacheHandleIdxes.size();
}

duke_media_handle DSharedhouseDlg::getDukeHandle(int pos, std::string keyWord /* = "" */)
{
    boost::trim(keyWord);
            
    //optimize for empty keyword
    if(keyWord.empty())
    {
        if(pos < static_cast<int>(m_dukeItems.size()))
            return m_dukeItems[pos];

        return duke_media_handle_null;
    }
    if(m_cacheKeyString != keyWord)
        reloadCache(keyWord);
        
    if(pos < static_cast<int>(m_cacheHandleIdxes.size()))
        return m_dukeItems[m_cacheHandleIdxes[pos]];

    return duke_media_handle_null;
}
int DSharedhouseDlg::getDukeItemsSize(std::string keyWord /* = "" */)
{
    boost::trim(keyWord);

    //optimize for empty keyword
    if(keyWord.empty())
        return m_dukeItems.size();

    if(m_cacheKeyString != keyWord)
        reloadCache(keyWord);                                    
    return m_cacheItemsSize;
}

int DSharedhouseDlg::readDukeItems()
{
    m_dukeItems.clear();
    std::string user_name = getApplication()->username();
    duke_media_get_shared_objs(user_name,m_dukeItems);
    return m_dukeItems.size();
}

bool DSharedhouseDlg::writeDukeItems()
{
    std::string user_name = getApplication()->username();

    return duke_media_set_shared_objs(user_name,m_dukeItems);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
