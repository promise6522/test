#ifndef DTOOL_H
#define DTOOL_H

// C 89 header files
#include <assert.h>
#include <string>

//Linux header files
#include <limits.h>

// Duke header files
#include "duc.h"
#include "is_dcolor.h"
#include "is_dfont.h"
#include "is_dmargins.h"
#include "is_dimage.h"
#include "is_dpenstroke.h"
#include "is_dtext.h"
#include "is_dglobal.h"
#include "is_dedge.h"
#include "is_dwidget.h"
#include "duke_media_global.h"

/*
 * Utility for conversion between T*** structure and D*** structure
 */
inline void TColor2DColor(const TColor &tColor, DColor &dColor)
{
    dColor.setRed(tColor.r);
    dColor.setGreen(tColor.g);
    dColor.setBlue(tColor.b);
    dColor.setAlpha(tColor.a);    
}

inline void DColor2TColor(const DColor &dColor, TColor &tColor)
{
    tColor.r = dColor.red();
    tColor.g = dColor.green();
    tColor.b = dColor.blue();
    tColor.a = dColor.alpha();    
}

inline void DSize2TSize(const DSize &dSize, TSize &tSize)
{
    tSize.width = dSize.width();
    tSize.height = dSize.height();
}

inline void DImage2TImage(const DImage &dImage, TImage &tImage)
{
    std::vector<unsigned char> data(dImage.imageData(), 
	                            dImage.imageData() + dImage.size());
    tImage.content = data;
    
    tImage.xDirection.scaleFitType = (ScaleFitType)dImage.xScale();
    tImage.xDirection.offOneSide = dImage.margin().left();
    tImage.xDirection.offAnotherSide = dImage.margin().right();
    tImage.yDirection.scaleFitType = (ScaleFitType)dImage.yScale();
    tImage.yDirection.offOneSide = dImage.margin().top();
    tImage.yDirection.offAnotherSide = dImage.margin().bottom();

    tImage.relationship = (RelationshipType)dImage.relation();
}

inline void DCursor2TCursor(const DCursor &dCursor, TCursor &tCursor)
{
    tCursor.cursorType = (CursorType)dCursor.shape();
    DSize2TSize(dCursor.size(), tCursor.size);
    if ((tCursor.cursorType == Custom_Cursor) && (dCursor.image() != NULL))      
        DImage2TImage(*dCursor.image(), tCursor.image);
    
    tCursor.hotspot.x = 5000;
    tCursor.hotspot.y = 5000;
}

inline void TFont2DFont(const TFont &tFont, DFont &dFont)
{
    //TBD: Add conversion from TFont.name to DFont.family
    //dFont.setFamily(tFont.name);
    dFont.setSize(tFont.size);
    dFont.setStyle(static_cast<DFont::Style>(tFont.style));
}

inline void DFont2TFont(const DFont &dFont, TFont &tFont)
{
    //TBD: Add conversion from TFont.name to DFont.family
    //tFont.name = dFont.family();
    tFont.size = dFont.size();
    tFont.style = dFont.style();    
}

inline void TMargin2DMargin(const TMargin &tMargin, DMargin &dMargin)
{
    //TBC: the relationshop between off_up/off_down and top/buttom
    dMargin.setLeft(tMargin.off_left);
    dMargin.setRight(tMargin.off_right);
    dMargin.setTop(tMargin.off_up);
    dMargin.setBottom(tMargin.off_down);
}

inline void DMargin2TMargin(const DMargin &dMargin, TMargin &tMargin)
{
    //TBC: the relationshop between off_up/off_down and top/buttom
    tMargin.off_left = dMargin.left();
    tMargin.off_right = dMargin.right();
    tMargin.off_up = dMargin.top();
    tMargin.off_down = dMargin.bottom();
}

inline void TPS2DPS(const TPenStroke &tPS, DPenStroke &dPS)
{
    dPS.setWidth(tPS.width);
    //dPS.setStyle(tPS.dashPattern);
    //In order to converse saftly, use switch/case to do it.
    switch(tPS.dashPattern)
    {
    case none:
        dPS.setStyle(DPenStroke::None);
        break;
    case s_common:
        dPS.setStyle(DPenStroke::S_common);
        break;
    case m_common:
        dPS.setStyle(DPenStroke::M_common);
        break;
    case l_common:
        dPS.setStyle(DPenStroke::L_common);
        break;
    case s_dot_dash:
        dPS.setStyle(DPenStroke::S_dot_dash);
        break;
    case m_dot_dash:
        dPS.setStyle(DPenStroke::M_dot_dash);
        break;
    case l_dot_dash:
        dPS.setStyle(DPenStroke::L_dot_dash);
        break;
    default:
        assert(!"Unsupport TDashPattern type to DPenStroke::PenStyle!");
        break;
    }
}

inline void DPS2TPS(const DPenStroke &dPS, TPenStroke &tPS)
{
    tPS.width = dPS.width();
    //tPS.dashPattern = dPS.style();
    //In order to converse saftly, use switch/case to do it.
    switch(dPS.style())
    {
    case DPenStroke::None:
        tPS.dashPattern = none;
        break;
    case DPenStroke::S_common:
        tPS.dashPattern = s_common;
        break;
    case DPenStroke::M_common:
        tPS.dashPattern = m_common;
        break;
    case DPenStroke::L_common:
        tPS.dashPattern = l_common;
        break;
    case DPenStroke::S_dot_dash:
        tPS.dashPattern = s_dot_dash;
        break;
    case DPenStroke::M_dot_dash:
        tPS.dashPattern = m_dot_dash;
        break;
    case DPenStroke::L_dot_dash:
        tPS.dashPattern = l_dot_dash;
        break;
    default:
        assert(!"Unsupport DPenStroke::PenStyle to TDashPattern type!");
        break;
    }
}

inline void Align2Layout(const AlignmentFlag& align, LayoutType & layout)
{
    switch(align)
    {
    case AlignLeft:
        layout = Left;
        break;
    case AlignRight:
        layout = Right;
        break;
    case AlignCenter:
        layout = Center;
        break;
    default:
        assert(!"Unsupport AlignmentFlag type to LayoutType!");
        break;
    }    
}

inline void Layout2Align(const LayoutType & layout, AlignmentFlag& align)
{
    switch(layout)
    {
    case Left:
        align = AlignLeft;
        break;
    case Right:
        align = AlignRight;        
        break;
    case Center:
        align = AlignCenter;        
        break;
    default:
        assert(!"Unkown LayoutType!");
        break;
    }
}

inline void TText2DText(const TText &tText, DText &dText)
{
    dText.setTextData(tText.text);
    TFont2DFont(tText.font, dText.rfont());
    TColor2DColor(tText.color, dText.rcolor());
    TMargin2DMargin(tText.margin, dText.rmargin());
    Layout2Align(tText.layout, dText.ralign());
    dText.setWrap(tText.wraparound);
    dText.setLocalEditable(tText.localEditable);
}

inline void DText2TText(const DText &dText, TText &tText)
{
    tText.text = dText.textData();
    DFont2TFont(dText.font(), tText.font);
    DColor2TColor(dText.color(), tText.color);
    DMargin2TMargin(dText.margin(), tText.margin);
    Align2Layout(dText.align(), tText.layout);
    tText.wraparound = dText.wrap();
    tText.localEditable = dText.localEditable();
}

inline void DEdgeType2TCurveType(const DEdge::EdgeType& edgeType, TCurveType& curveType)
{
    switch(edgeType)
    {
    case DEdge::CurveQuad:
        curveType = Curve_QUAD;
        break;
    case DEdge::CurveCubic:
        curveType = Curve_CUBIC;        
        break;
    case DEdge::CurveCustom:
        curveType = Curve_CUSTOM;        
        break;
    default:
        assert(!"Unkown EdgeType!");
        break;
    }
}

inline void DEdge2TCurve(const DEdge &dEdge, TCurve &tCurve)
{
    DPoint sourcePoint = dEdge.sourcePoint();
    DPoint targetPoint = dEdge.targetPoint();
     
    tCurve.points.clear();
    TPoint topLeftPoint(sourcePoint.x(), sourcePoint.y());
    tCurve.points.push_back(topLeftPoint);  
    TPoint bottomLeftPoint(sourcePoint.x(), targetPoint.y());
    tCurve.points.push_back(bottomLeftPoint);
    TPoint topRightPoint(targetPoint.x(), sourcePoint.y());
    tCurve.points.push_back(topRightPoint);
    TPoint bottomRightPoint(targetPoint.x(), targetPoint.y());
    tCurve.points.push_back(bottomRightPoint);

    DEdgeType2TCurveType(dEdge.edgeType(),tCurve.curveType);
    DColor2TColor(dEdge.color(), tCurve.color);
}

inline std::string toString(const unsigned char *inputData, size_t size)  
{  
    //std::string szOutput;  

    //for (size_t i = 0 ; i < size ; i++)  
    //{  
    //    szOutput += inputData[i]; 
    //}  
    //return szOutput;  
    return std::string((const char*)inputData, size);
}

inline std::string toHexString(unsigned char *inputData, size_t size)  
{  
    char temp[4];  
    std::string szHexOutput;  

    for (size_t i = 0 ; i < size ; i++)  
    {  
        sprintf(temp, "%02X ", inputData[i]);  
        szHexOutput += std::string(temp,3);  
    }  
    return szHexOutput;  
}  

inline std::string toHexString(const std::string &inputStr)  
{  
    char temp[4];  
    std::string szHexOutput;  

    for (size_t i = 0 ; i < inputStr.length() ; i++)  
    {  
        sprintf(temp, "%02X ", (unsigned char)inputStr[i]);  
        szHexOutput += std::string(temp,3);  
    }  
    return szHexOutput;  
}

inline bool widgetGeometryCompare(DWidgetPtr ptr1, DWidgetPtr ptr2)
{    
    if( (ptr1->geometryY() < ptr2->geometryY())
        || ((ptr1->geometryY() == ptr2->geometryY())
            && (ptr1->geometryX() < ptr2->geometryX())))
    {
        return true;
    }    
    
    return false;
}

inline std::string getResPath()
{
    return get_resource_path();
}

inline void setImageDataByHandle(DImage & img, const duke_media_handle& handle,
                                 std::string default_image)
{
    std::string icon;
    if(duke_media_get_icon(handle, icon) && !icon.empty())
    {            
        std::vector<unsigned char> tempData(icon.begin(), icon.end());
        img.setImageData(&tempData[0], tempData.size());
    }
    else
    {
        img.load(getResPath() + default_image);
    }              
}

inline void setImageDataByHandle(DImage & img, std::string user_name, const duke_media_handle& handle,
                                 std::string default_image, std::string semi_image)
{
    std::string icon;
    if(duke_media_get_icon(handle, icon) && !icon.empty())
    {            
        std::vector<unsigned char> tempData(icon.begin(), icon.end());
        img.setImageData(&tempData[0], tempData.size());
    }
    else
    {
        if(get_media_handle_status(handle) != e_handle_core)
        {
            img.load(getResPath() + semi_image);
        }
        else
        {
            img.load(getResPath() + default_image);
        }
    }              
}

#endif /* DTOOL_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
/* -*- c-basic-offset: 4; indent-tabs-mode: nil -*- */
