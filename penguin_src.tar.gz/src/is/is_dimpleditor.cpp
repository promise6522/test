/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#include <boost/lexical_cast.hpp>
#include <boost/bind.hpp>

#include "nb_profiler.h"

#include "is_dimpleditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"
#include "is_ddecleditor.h"
#include "is_dobjeditor.h"
#include "is_dstorageeditor.h"
#include "is_darrayeditor.h"
#include "is_dmapeditor.h"
#include "is_dbyteseditor.h"

DImplEditor::DImplEditor(int model /*= DEditor::DialogModel*/,
                         DMainWin * pMainWin /*= NULL*/, 
                         DWidget * parent /*= 0*/,
                         WFlags f /*= 0*/)
  : DEditor(model, pMainWin, parent, f),
    //m_implType(impl_node_general),
    m_implType(impl_node_none),
    m_layer(1),
    m_blank(MAX_COORD),
    m_layerHeight(ImplEditor_Layer),
    m_storage_hif(NB_INTERFACE_NONE),
    m_shared(false),
    m_master(duke_media_handle_null)
{
    setObjectName(ImplEditor_ObjName);
    m_menuEdgePair.first.reset();
    assert(pMainWin != NULL);    
    m_index = 0;
    m_link.clear();
}

DImplEditor::DImplEditor(const std::string& title,
                         int model /*= DEditor::DialogModel*/,
                         DMainWin *pMainWin /*= NULL*/,
                         DWidget * parent /*= 0*/,
                         WFlags f /*= 0*/)
  : DEditor(title, model, pMainWin, parent, f),
//    m_implType(impl_node_general),
    m_implType(impl_node_none),
    m_layer(1),
    m_blank(MAX_COORD),
    m_layerHeight(ImplEditor_Layer),
    m_storage_hif(NB_INTERFACE_NONE),
    m_shared(false),
    m_master(duke_media_handle_null)
{
    setObjectName(ImplEditor_ObjName);
    m_menuEdgePair.first.reset();
    assert(pMainWin != NULL);
    m_index = 0;
    m_link.clear();
}

DImplEditor::DImplEditor(const std::string& title,
                         const duke_media_handle& handle,
                         int model /*= DEditor::DialogModel*/,
                         DMainWin *pMainWin /*= NULL*/,
                         DWidget * parent /*= 0*/,
                         WFlags f /*= 0*/)
    : DEditor(title, model, pMainWin, parent, f),
      //m_implType(impl_node_general),
      m_implType(impl_node_none),
      m_layer(1),
      m_blank(MAX_COORD),
      m_layerHeight(ImplEditor_Layer),
      m_storage_hif(NB_INTERFACE_NONE),
      m_shared(false),
      m_master(duke_media_handle_null)
{
    setObjectName(ImplEditor_ObjName);
    m_menuEdgePair.first.reset();    
    assert(pMainWin != NULL);
    setMediaByHandle(handle);
    m_index = 0;
    m_link.clear();
}

DImplEditor::~DImplEditor()
{
}

void DImplEditor::initImplTypeButtons()
{
    DImage img;
    DImage selImg;    
    img.load(getResPath() + ImplEditor_TypeImg_FileName);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    selImg.load(getResPath() + ImplEditor_TypeSelImg_FileName);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //General button
    m_ptrGeneral.reset(new(std::nothrow) DButton("General", img, selImg, getBodyFrame()));     
    m_ptrGeneral->registerEvent(DEvent::Select);
    m_ptrGeneral->setTextColor(Default_Dialog_TextColor);
    m_ptrGeneral->setTextAlign(AlignCenter);
    m_ptrGeneral->registerEvent(DEvent::Detail, true);
    m_ptrGeneral->registerEvent(DEvent::DnD_Start, true);
    //m_ptrGeneral->registerEvent(DEvent::Drag, true);
    m_ptrGeneral->registerEvent(DEvent::DnD_Release, true);
    m_ptrGeneral->setEventRoutine(DEvent::Select,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onImplType));

    //condition button
    m_ptrCondition.reset(new(std::nothrow) DButton("Condition", img, selImg, getBodyFrame()));
    m_ptrCondition->registerEvent(DEvent::Select);
    m_ptrCondition->setTextColor(Default_Dialog_TextColor);
    m_ptrCondition->setTextAlign(AlignCenter);
    m_ptrCondition->registerEvent(DEvent::Detail, true);
    m_ptrCondition->registerEvent(DEvent::DnD_Start, true);
    //m_ptrCondition->registerEvent(DEvent::Drag, true);
    m_ptrCondition->registerEvent(DEvent::DnD_Release, true);
    m_ptrCondition->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DImplEditor::onImplType));

    //condition button
    m_ptrLoop.reset(new(std::nothrow) DButton("Loop", img, selImg, getBodyFrame()));     
    m_ptrLoop->registerEvent(DEvent::Select);
    m_ptrLoop->setTextColor(Default_Dialog_TextColor);
    m_ptrLoop->setTextAlign(AlignCenter);
    m_ptrLoop->registerEvent(DEvent::Detail, true);
    m_ptrLoop->registerEvent(DEvent::DnD_Start, true);
    //m_ptrLoop->registerEvent(DEvent::Drag, true);
    m_ptrLoop->registerEvent(DEvent::DnD_Release, true);
    m_ptrLoop->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DImplEditor::onImplType));
    
    //share button
    m_ptrShare.reset(new(std::nothrow) DButton("Share", img, selImg, getBodyFrame()));
    m_ptrShare->registerEvent(DEvent::Select);
    m_ptrShare->setTextColor(Default_Dialog_TextColor);
    m_ptrShare->setTextAlign(AlignCenter);
    m_ptrShare->registerEvent(DEvent::Detail, true);
    m_ptrShare->registerEvent(DEvent::DnD_Start, true);
    m_ptrShare->registerEvent(DEvent::DnD_Release, true);
    m_ptrShare->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DImplEditor::onImplType));

    //TBD: read from duke_media
    setCurSelectedType(m_implType);
}

void DImplEditor::setCurSelectedType(impl_node_type type)
{
    m_ptrGeneral->setSelected(false);
    m_ptrCondition->setSelected(false);
    m_ptrLoop->setSelected(false);

    if(m_shared)
    {
        m_ptrShare->setSelected(true);
    }
    else
    {
        m_ptrShare->setSelected(false);
    }

    switch(type)
    {
    case impl_node_general:
        m_ptrGeneral->setSelected(true);
        break;
    case impl_node_condition:
        m_ptrCondition->setSelected(true);
        break;
    case impl_node_loop:
        m_ptrLoop->setSelected(true);
        break;
    case impl_node_none:
    default:
        LOG_DEBUG("none type for implementation.");        
    }
}

//readonly
void DImplEditor::setReadonly()
{
    DEditor::setReadonly();

    //init body frame
    getBodyFrame()->unRegisterEvent(DEvent::Drag);
    getBodyFrame()->unRegisterEvent(DEvent::DnD_Release);
    
    //set type button readonly
    m_ptrGeneral->unRegisterEvent(DEvent::Select);
    m_ptrCondition->unRegisterEvent(DEvent::Select);
    m_ptrLoop->unRegisterEvent(DEvent::Select);

    //set in/out ports readonly
    setInternalWidgetReadonly(m_ptrInFunc.get());
    setInternalWidgetReadonly(m_ptrOutFunc.get());

    //set interlnal widget readonly
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        setInternalWidgetReadonly(pWidget);
    }    

}
    

void DImplEditor::setInternalWidgetReadonly(DWidget* pWidget)
{   
    // if widget is a dfunc
    if(dynamic_cast<DFunc*>(pWidget)) {
        //
        pWidget->unRegisterEvent(DEvent::Activate);
        pWidget->unRegisterEvent(DEvent::Drag);
        pWidget->unRegisterEvent(DEvent::DnD_Start);
        pWidget->unRegisterEvent(DEvent::DnD_Release);

        // in ports and edges
        DFunc* ptrFunc = dynamic_cast<DFunc*>(pWidget);
        InPEItems ipes = ptrFunc->getInPorts(); 
        for(InPEItemIt it = ipes.begin(); it != ipes.end(); ++it)
        {
            DPortPtr ptrInPort = it->first;
            if(NULL != ptrInPort.get())
            {
                ptrInPort->unRegisterEvent(DEvent::DnD_Release);
            }

            for(EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt)
            {
                DEdgePtr ptrInEdge = *eIt;
                if(NULL != ptrInEdge.get())
                {
                    ptrInEdge->unRegisterEvent(DEvent::Drag);
                    ptrInEdge->unRegisterEvent(DEvent::DnD_Start);
                    ptrInEdge->unRegisterEvent(DEvent::DnD_Release);
                    ptrInEdge->unRegisterEvent(DEvent::Delete);
                    // still focusable
                    //ptrInEdge->unRegisterEvent(DEvent::Focus);
                    //ptrInEdge->unRegisterEvent(DEvent::Blur);
                }       
            }
        }

        // out ports and edges
        OutPEItems opes = ptrFunc->getOutPorts(); 
        for(OutPEItemIt it = opes.begin(); it != opes.end(); ++it)
        {
            DPortPtr ptrOutPort = it->first;
            if(NULL != ptrOutPort.get())
            {
                ptrOutPort->unRegisterEvent(DEvent::DnD_Start);
                ptrOutPort->unRegisterEvent(DEvent::DnD_Release);
            }
            EItems ptrOutEdges = it->second;
            for(EIt it = ptrOutEdges.begin(); it != ptrOutEdges.end(); ++it)
            {
                DEdgePtr ptrOutEdge = *it;
                if(NULL != ptrOutEdge.get())
                {
                    ptrOutEdge->unRegisterEvent(DEvent::Drag);
                    ptrOutEdge->unRegisterEvent(DEvent::DnD_Start);
                    ptrOutEdge->unRegisterEvent(DEvent::DnD_Release);
                    ptrOutEdge->unRegisterEvent(DEvent::Delete);
                    // still focusable
                    //ptrOutEdge->unRegisterEvent(DEvent::Focus);
                    //ptrOutEdge->unRegisterEvent(DEvent::Blur);
                }       
            }
        }
    }
    else
    {
        pWidget->unRegisterEvent(DEvent::DnD_Start);
        pWidget->unRegisterEvent(DEvent::Activate);
        pWidget->unRegisterEvent(DEvent::Delete);
    }
}

void DImplEditor::initDialog()
{
    DEditor::initDialog();
    initEventHandle();

    //init implement type selection buttons
    initImplTypeButtons();

    //init in port, one input port by default.
    //else, read the port information in duke_media_handle
    m_ptrInFunc.reset(new(std::nothrow) DFunc("", 0, 0, getBodyFrame()));
    m_ptrInFunc->registerEvent(DEvent::Hover);
    m_ptrInFunc->registerEvent(DEvent::PassingOut);
    m_ptrInFunc->registerEvent(DEvent::Activate);
    m_ptrInFunc->initFuncView();
    m_ptrInFunc->setEventRoutine(DEvent::Hover,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onHoverChild)); 
    m_ptrInFunc->setEventRoutine(DEvent::PassingOut,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onPassingOutChild));
    m_ptrInFunc->setEventRoutine(DEvent::Activate,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onActivatePorts));
    
    m_ptrInFunc->setEventRoutine(DEvent::DnD_Release,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onReleaseDecl));

    
    //init out port, one putput port by defaul
    //else, read the port information in duke_media_handle
    m_ptrOutFunc.reset(new(std::nothrow) DFunc("", 0, 0, getBodyFrame()));
    m_ptrOutFunc->registerEvent(DEvent::Hover);
    m_ptrOutFunc->registerEvent(DEvent::PassingOut);
    m_ptrOutFunc->registerEvent(DEvent::Activate);
    m_ptrOutFunc->initFuncView();
    m_ptrOutFunc->setEventRoutine(DEvent::Hover,
                                  this,
                                  static_cast<EventRoutine>(&DImplEditor::onHoverChild)); 
    m_ptrOutFunc->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DImplEditor::onPassingOutChild));
    
    m_ptrOutFunc->setEventRoutine(DEvent::Activate,
                                  this,
                                  static_cast<EventRoutine>(&DImplEditor::onActivatePorts));
    
    m_ptrOutFunc->setEventRoutine(DEvent::DnD_Release,
                                 this,
                                 static_cast<EventRoutine>(&DImplEditor::onReleaseDecl)); 
    //update the placement in implement editor
    updateImplWidgets();

    initItemsByMediaBase();
}

void DImplEditor::initItemsByMediaBase()
{
    dumpImplementInfo();
    
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
    {
        return;
    }

    //get name & icon
    pImplMedia->get_name(m_dukeName);
    pImplMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    //get implementation's type
    if(pImplMedia->cond())
    {
        m_implType = impl_node_condition;
    }
    else if(pImplMedia->loop())
    {
        m_implType = impl_node_loop;
    }
    else if(pImplMedia->general())
    {
        m_implType = impl_node_general;
    }
    else
    {
        m_implType = impl_node_none;
    }
   
    if(pImplMedia->get_share())
    {
       m_shared = true;
    }

    m_master = pImplMedia->get_master();

    setCurSelectedType(m_implType);
    
    //set impl editor's in/out ports
    updateInOutPorts(); 
    
    //set nodes
    std::vector<duke_media_node> nodes;
    pImplMedia->get_media_nodes(nodes);

    //DEBUG
    //for(size_t i=0; i < nodes.size(); ++i)
    //    LOG_DEBUG("nodes["<<i<<"] is "<<nodes[i].m_name);
    //DEBUG

    if(nodes.size() > 2)
    {
        int pos = nodes[nodes.size()-2].m_name.rfind("_");
        m_index = boost::lexical_cast<int>(nodes[nodes.size()-2].m_name.substr(pos+1));
    }
    else
    {
        m_index = 0;
    }

    m_link.insert(std::make_pair(m_ptrInFunc.get(), nodes.begin()->m_name));
    int intervalX = MAX_COORD / nodes.size();
    for (size_t i = 0; i < nodes.size() - 2; ++i ) 
    {
        if (nodes[i+1].is_object_node() && (!nodes[i+1].m_hdecl.is_object_exec_iterator()) && (!nodes[i+1].m_hdecl.is_object_exec_condition()))
        {
            if(nodes[i+1].m_hdecl.is_implementation())
            {
                duke_media_implement implMedia(nodes[i+1].m_hdecl);
                if(implMedia.loop() || implMedia.cond())
                {
                    // create DFunc
					DWidgetPtr ptrWidget(createWidget(nodes[i + 1].m_hdecl, true, nodes[i+1].m_hOwnerIf));
                    pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
					m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
                }
                else{
                    // create DObjIcon
					DWidgetPtr ptrWidget(createWidget(nodes[i + 1].m_inputs[0], false));
                    pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
					m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
                }
            }
            else{

                // create DObjIcon
				DWidgetPtr ptrWidget(createWidget(nodes[i + 1].m_inputs[0], false, dukeid_t(NB_INTERFACE_NONE), false));
                pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
				m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
            }
        }
        else
        {
            // create DFunc
            if(nodes[i+1].m_hdecl.is_object_decl_expanded())
            {
                DWidgetPtr  ptrWidget(createWidget(nodes[i+1]));
                pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
                m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
            }
            else
            {
                DWidgetPtr ptrWidget(createWidget(nodes[i+1].m_hdecl, true, nodes[i+1].m_hOwnerIf));
                pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
                m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
            }
            //pushWidgetToEditor(intervalX * (i + 1), ptrWidget);
            //m_link.insert(std::make_pair(ptrWidget.get(), nodes[i+1].m_name));
            //pushWidgetToEditor(intervalX * (i + 1),
            //                  createWidget(nodes[i + 1].m_hdecl, true, nodes[i+1].m_hOwnerIf));
        }
    }    
    m_link.insert(std::make_pair(m_ptrOutFunc.get(), (--nodes.end())->m_name));
    
    //set paths
    std::vector<duke_media_path> paths;
    pImplMedia->get_media_paths(paths);

    //DEBUG
    //for(size_t i=0; i < paths.size(); ++i)
    //    LOG_DEBUG("paths["<<i<<"] : inode =  "<<paths[i].m_inode<<" onode= "<<paths[i].m_onode);
    //DEBUG

    for (size_t i = 0; i < paths.size(); ++i ) 
    {
        int outWidgetIdx = getIndexByNodeName(paths[i].m_onode);
        int inWidgetIdx = getIndexByNodeName(paths[i].m_inode);
        if( ((outWidgetIdx < 0) && (paths[i].m_onode != "input_node"))
            || ((inWidgetIdx < 0) && (paths[i].m_inode != "output_node")) ) 
            continue;

        
        //if(outWidgetIdx > static_cast<int>(m_implWidgets.size())
        //   || inWidgetIdx > static_cast<int>(m_implWidgets.size()))
        //    continue;                
        
        DFunc * pOutFunc = NULL;

        if( paths[i].m_onode == "input_node" )
        {
            pOutFunc = m_ptrInFunc.get();
        }
        else
        {
            assert(outWidgetIdx >= 0);
            pOutFunc = dynamic_cast<DFunc*>(getWidgetFromLink(paths[i].m_onode));            
        }


        if(pOutFunc != NULL)
        {
            DFunc * pInFunc = NULL;
            if(paths[i].m_inode == "output_node")
            {
                pInFunc = m_ptrOutFunc.get();
            }
            else
            {
                assert(inWidgetIdx >= 0);
                pInFunc = dynamic_cast<DFunc*>(getWidgetFromLink(paths[i].m_inode));
                //NO ASSERT HERE for paths-saving bugs
                //assert( NULL != pInFunc);
                //pInFunc = dynamic_cast<DFunc *>(m_implWidgets[inWidgetIdx].get());
            }
            if(pInFunc != NULL)
            {
                pOutFunc->connect(paths[i].m_oport, pInFunc, paths[i].m_iport);
            }
            continue;
        }

        DObjIcon * pOutObj = dynamic_cast<DObjIcon *>(getWidgetFromLink(paths[i].m_onode));
        if(pOutObj != NULL)
        {
            DFunc * pInFunc = NULL;
            if(paths[i].m_inode == "output_node")
            {
                pInFunc = m_ptrOutFunc.get();
            }
            else
            {
                assert(inWidgetIdx >= 0);
                pInFunc = dynamic_cast<DFunc*>(getWidgetFromLink(paths[i].m_inode));
                //NO ASSERT HERE for paths-saving bugs
                //assert(NULL != pInFunc);
                //pInFunc = dynamic_cast<DFunc *>(m_implWidgets[inWidgetIdx].get());
            }
            if(pInFunc != NULL)
            {
                pOutObj->connect(pInFunc, paths[i].m_iport);
            }
            continue;
        }
    }

   //restore node pos
    duke_media_handle implMediaHandle = pImplMedia->get_handle();
    if (duke_media_handle_null != implMediaHandle)
    {   
        std::vector<node_info> vNodeInfo;
        vNodeInfo.clear();
        duke_media_get_hattr_node(implMediaHandle, vNodeInfo);

        for (ImplWidgetsIt iter = m_implWidgets.begin(); iter != m_implWidgets.end(); ++iter)
        {
            std::map<DWidget*, std::string>::iterator it = m_link.find(iter->get());
            if(it != m_link.end())
            {
                for (std::size_t index = 0; index < vNodeInfo.size(); ++index)
                {
                    if(vNodeInfo[index].name == it->second)
                    {
                        it->first->setGeometry(vNodeInfo[index].x, vNodeInfo[index].y,
                                               vNodeInfo[index].w, vNodeInfo[index].h);
                    }
                }
            }
            else
            {
                assert(!"Could not find the node name!");
            }
        }
    }
    
    updateEdgesPos();
    //switch to impl type  
    switchByImplType();
    updateAll();
}

DWidget* DImplEditor::getWidgetFromLink(const std::string& name)       
{
    implMapIt itr = m_link.begin();
    while(itr != m_link.end())
    {
        if(itr->second == name)
        {
            return itr->first;
        }
        ++itr;
    }
    //assert(!"can not find widget by name");
    LOG_ERROR("DImplEditor::getWidgetFromLink() failed, name = "<<name);

    return NULL;
}

int DImplEditor::getIndexByNodeName(const std::string & name)
{
    std::string indexStr = name.substr(name.find_last_of("_") + 1);
    try
    {
        return boost::lexical_cast<int>(indexStr);
    }
    catch(boost::bad_lexical_cast &)
    {
        return -1;
    }
}

void DImplEditor::reload()
{
    LOG_DEBUG("DImplEditor:: ...............reload ......");

    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget((*it).get());
        if(pEditor != NULL)
        {
            m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
            eraseSubEditor(pEditor);        
        }

        // Check if the widget is func
        DFunc* pSrcFunc = dynamic_cast<DFunc *>((*it).get()); 
        if (NULL != pSrcFunc) 
        {
            pSrcFunc->clearAllEdges();
            getBodyFrame()->detachChildWidget(pSrcFunc);
        } 

        // Check if the widget is object
        DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>((*it).get()); 
        if (NULL != pSrcObj) 
        {
            pSrcObj->clearAllEdges();
            pSrcObj->deleteTextLabel();
            getBodyFrame()->detachChildWidget(pSrcObj);
        }
    }
    m_implWidgets.clear();

    m_layer = 0;
    m_blank = MAX_COORD;
    m_layerHeight = ImplEditor_Layer;
    setMediaByHandle(m_handle);
    initItemsByMediaBase();
}

void DImplEditor::duplicateItemsByHandle(const duke_media_handle& himpl)
{
    if (!himpl.is_implementation()) 
    {
        assert(!"Invalid implementation handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();
        
    duke_media_implement* pImplMedia =
        new(std::nothrow) duke_media_implement(this->getApplication()->get_host_committer_id(), getApplication()->username());
    pImplMedia->copy(himpl);
    m_ptr = pImplMedia;
    m_handle = pImplMedia->get_handle();
    assert(m_ptr != NULL);    
}

void DImplEditor::updateTypeButtons()
{
    if (NULL != m_ptrGeneral.get())
    {
        m_ptrGeneral->setGeometry(MIN_COORD, MIN_COORD, 
                                 MAX_COORD * 6 / 25, m_typeButtonHeight);
    }

    if (NULL != m_ptrCondition.get())
    {
        m_ptrCondition->setGeometry(MAX_COORD *  6 / 25, MIN_COORD, 
                                    MAX_COORD  * 6 / 25, m_typeButtonHeight);
    }

    if (NULL != m_ptrLoop.get())
    {
        m_ptrLoop->setGeometry(MAX_COORD * 12 / 25, MIN_COORD, 
                               MAX_COORD * 6 / 25, m_typeButtonHeight);
    }  
    if (NULL != m_ptrShare.get())
    {
         m_ptrShare->setGeometry(MAX_COORD * 19 / 25, MIN_COORD, 
                               MAX_COORD * 6 / 25, m_typeButtonHeight);
    }
}

void DImplEditor::updateImplWidgets(int adjustHeight)
{
    if(m_ptrInFunc.get() == NULL || m_ptrOutFunc.get() == NULL)
        return;
    
    if (ImplEditor_Layer*m_layer > ImplEditor_Total_Layer) 
        m_layerHeight = ImplEditor_Total_Layer / m_layer;

    int freeSpace = MAX_COORD - m_layerHeight * 5 / 2 - m_typeButtonHeight;
    m_blank = (freeSpace - m_layer * m_layerHeight) / (m_layer + 1);

    //update the in func
    int funcWidth = m_ptrInFunc->geometrySize().width();
    DRect rect;
    rect.setLeft((MAX_COORD - funcWidth)/2);
    rect.setRight((MAX_COORD + funcWidth)/2);
    rect.setTop(m_layerHeight/4 + m_typeButtonHeight);
    rect.setBottom(m_layerHeight*5/4 + m_typeButtonHeight);
    m_ptrInFunc->setGeometry(rect);

    //update the out func
    funcWidth = m_ptrOutFunc->geometrySize().width();
    rect.setLeft((MAX_COORD - funcWidth)/2);
    rect.setRight((MAX_COORD + funcWidth)/2);
    rect.setTop(MAX_COORD - m_layerHeight*5/4);
    rect.setBottom(MAX_COORD - m_layerHeight/4);
    m_ptrOutFunc->setGeometry(rect);

    // update all layers
    LOG_DEBUG("----------------update -----------");
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DRect old = pWidget->geometry();
        int layer = inLayer(old.y()+old.height()/2, m_layer);
        old.setTop(m_blank*(layer+1) + m_layerHeight*layer
                   + m_layerHeight*5/4 + m_typeButtonHeight);
        old.setBottom((m_blank+m_layerHeight)*(layer+1)
                      + m_layerHeight*5/4 + m_typeButtonHeight);
        pWidget->setGeometry(old);
    }
}

void DImplEditor::initEventHandle()
{
    DFrame* pFrame = getBodyFrame();
    assert(NULL != pFrame);
   
    pFrame->setFocusAttr(true);
    pFrame->registerEvent(DEvent::Drag);
    pFrame->setEventRoutine(DEvent::Drag,
                                    this,
                                    static_cast<EventRoutine>(&DImplEditor::onDnDDrag));
    
    pFrame->registerEvent(DEvent::DnD_Release);
    pFrame->setEventRoutine(DEvent::DnD_Release,
                                    this,
                                    static_cast<EventRoutine>(&DImplEditor::onDnDRelease));
}

int DImplEditor::inLayer(int height, int layer, int adjustHeight)
{
    int layerHeight = ImplEditor_Layer;
    if (layerHeight*layer > ImplEditor_Total_Layer) 
        layerHeight = ImplEditor_Total_Layer / layer;
    int freeSpace = MAX_COORD - m_layerHeight * 5 / 2 - m_typeButtonHeight - adjustHeight;
    int totalBlank = freeSpace - layer * layerHeight;
    int blank = totalBlank / (layer + 1);
    height = height - m_layerHeight * 5 / 4 - m_typeButtonHeight;

    int temp = height / (layerHeight + blank); 
    return (temp >= layer) ? (layer - 1) : temp;    
}

int DImplEditor::getIndexByWidget(DWidget* pWidget)
{
    ImplWidgetsIdx idx = 0;
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {                
        if( (*it).get() == pWidget)
            return idx;
        ++idx;
    }

    return -1;
}

void DImplEditor::pushWidgetToEditor(int x, DWidgetPtr ptrWidget)
{   
    if (!ptrWidget)
        return;

    if (ptrWidget->getMedia()->is_declaration() && dynamic_cast<DFunc*>(ptrWidget.get()))
        ++m_layer; 

    if (ImplEditor_Layer*m_layer > ImplEditor_Total_Layer) 
        m_layerHeight = ImplEditor_Total_Layer / m_layer;

    int freeSpace = MAX_COORD - m_layerHeight * 5 / 2 - m_typeButtonHeight;
    m_blank = (freeSpace - m_layer * m_layerHeight) / (m_layer + 1);
    if (dynamic_cast<DFunc *>(ptrWidget.get()))
        ptrWidget->setGeometry(x,
                               m_blank * m_layer + m_layerHeight * m_layer
                               + m_layerHeight*5/4 + m_typeButtonHeight,
                               ptrWidget->geometry().width(),
                               m_layerHeight);
    if (dynamic_cast<DObjIcon *>(ptrWidget.get()))
        ptrWidget->setGeometry(x,
                               m_blank * m_layer + m_layerHeight * m_layer
                               + m_layerHeight*5/4 + m_typeButtonHeight,
                               750,
                               m_layerHeight);
    else
    {
        // update all layers
        for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
        {
            DWidget * pWidget = (*it).get();
            assert(pWidget != NULL);
            
            DRect old = pWidget->geometry();
            int layer = inLayer(old.y()+old.height()/2, m_layer - 1);
            old.setTop(m_blank*(layer+1) + m_layerHeight*layer 
                       + m_layerHeight*5/4 + m_typeButtonHeight);
            old.setBottom((m_blank+m_layerHeight) * (layer+1) 
                          + m_layerHeight*5/4 + m_typeButtonHeight);
            pWidget->setGeometry(old);
        }
    }

    m_implWidgets.push_back(ptrWidget);
}

void DImplEditor::addWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget)
{   
    if (!ptrWidget)
        return;

    int upFlag = 0;

    // increase layer when add a declaration-func
    if (ptrWidget->getMedia()->is_declaration() && dynamic_cast<DFunc*>(ptrWidget.get())) {
        if (m_layer < ImplEditor_Layer_Max) {
            ++m_layer; 
            upFlag = 1;
        }
    }

    if (ImplEditor_Layer*m_layer > ImplEditor_Total_Layer) 
        m_layerHeight = ImplEditor_Total_Layer / m_layer;

    int freeSpace = MAX_COORD - m_layerHeight * 5 / 2 - m_typeButtonHeight;
    m_blank = (freeSpace - m_layer * m_layerHeight) / (m_layer + 1);
    int layer = inLayer(pt.y(), m_layer);
    if (dynamic_cast<DFunc *>(ptrWidget.get()))
        ptrWidget->setGeometry(pt.x(),
                               m_blank*(layer+1)+m_layerHeight*layer
                               +m_layerHeight*5/4+m_typeButtonHeight,
                               ptrWidget->geometry().width(),
                               m_layerHeight);
    if (dynamic_cast<DObjIcon *>(ptrWidget.get()))
        ptrWidget->setGeometry(pt.x(),
                               m_blank*(layer+1) + m_layerHeight*layer
                               +m_layerHeight*5/4+m_typeButtonHeight,
                               750,
                               m_layerHeight);
    else if (upFlag)
    {
        // update all layers    
        for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
        {
            DWidget * pWidget = (*it).get();
            assert(pWidget != NULL);
            
            DRect old = pWidget->geometry();
            int layer = inLayer(old.y()+old.height()/2, m_layer-1);
            old.setTop(m_blank*(layer+1) + m_layerHeight*layer 
                       + m_layerHeight*5/4 + m_typeButtonHeight);
            old.setBottom((m_blank+m_layerHeight)*(layer+1) 
                          + m_layerHeight*5/4 + m_typeButtonHeight);
            pWidget->setGeometry(old);
        }
    }

    m_implWidgets.push_back(ptrWidget);
}

//this function just for duke_media_declare_expanded when recover implement
DWidgetPtr DImplEditor::createWidget(const duke_media_node& node)
{
    DWidgetPtr ptrWidget;
    ptrWidget.reset(new(std::nothrow) DFunc(node.m_hdecl, node.m_hOwnerIf, node.m_inputs, node.m_outputs, getBodyFrame()));

    //register event handle
    ptrWidget->registerEvent(DEvent::Enlarge);
    ptrWidget->registerEvent(DEvent::Shrink);    
    ptrWidget->registerEvent(DEvent::Hover);
    ptrWidget->registerEvent(DEvent::PassingOut);
    ptrWidget->setEventRoutine(DEvent::Hover,
                               this,
                               static_cast<EventRoutine>(&DImplEditor::onHoverChild)); 
    ptrWidget->setEventRoutine(DEvent::PassingOut,
                               this,
                               static_cast<EventRoutine>(&DImplEditor::onPassingOutChild)); 
    ptrWidget->registerEvent(DEvent::DnD_Start);
    ptrWidget->setEventRoutine(DEvent::DnD_Start,
                             this,
                             static_cast<EventRoutine>(&DImplEditor::onDnDStart));
 
    ptrWidget->setFocusAttr(true);
    ptrWidget->registerEvent(DEvent::Delete);
    ptrWidget->setEventRoutine(DEvent::Delete,
                             this,
                             static_cast<EventRoutine>(&DImplEditor::onDeleteWidget));
    ptrWidget->registerEvent(DEvent::Activate);

    if(node.m_hdecl.is_declaration())
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DImplEditor::onActivateFunc));
    }
    return ptrWidget;
}

DWidgetPtr DImplEditor::createWidget(const duke_media_handle &h, bool bCreateFunc,
                                     const duke_media_handle& hFuncOwnerIf /* = NB_INTERFACE_NONE*/, 
                                     const bool is_need_clone /* = false */)
{
    // bCreateFunc matters only when h is a declaration
    
    DWidgetPtr ptrWidget;
    if(h.is_object_exec_iterator() || h.is_object_exec_condition())
    {
         ptrWidget.reset(new(std::nothrow) DFunc(h, getBodyFrame()));
    }
    else if (h.is_implementation())
    {
        duke_media_implement implMedia(h);
        if(implMedia.loop() || implMedia.cond())
            ptrWidget.reset(new(std::nothrow) DFunc(h, getBodyFrame()));
        else{
            DImage img;
            img.setRelation(DImage::KeepSmall);
            setImageDataByHandle(img, h,
                             ImplEditor_DefaultObj_FileName);
            ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
        }
    }
    else if (h.is_declaration() && bCreateFunc) 
    {   
        ptrWidget.reset(new(std::nothrow) DFunc(h, hFuncOwnerIf, getBodyFrame()));
    }
    else if(h.is_object_decl_expanded() && bCreateFunc)
    {
        ptrWidget.reset(new(std::nothrow) DFunc(h, hFuncOwnerIf, getBodyFrame()));
    }
    else if ((h.is_object() || h.is_object_container_des()) && !h.is_access())
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultObj_FileName);
        if (h.is_object_builtin())
        {
            if(is_need_clone)
            {
                //clone handle
                assert(!"Could not need copy when create widget, create it later when editing it.");
                duke_media_handle hnew;
                duke_media_clone(this->getApplication()->get_host_committer_id(), h, hnew);
                ptrWidget.reset(new(std::nothrow) DObjIcon("", img, hnew, getBodyFrame()));
            }
            else
            {
                ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
            }
            
            // set value of built-in obj
            if(!h.is_object_bytes())
            {  
                std::string val;
                ptrWidget->getMediaValue(val);
                dynamic_cast<DObjIcon *>(ptrWidget.get())->setTextContent(val);
            }
        }
        else
        {
            ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
        }
    }
    else if (h.is_storage()) 
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultStorage_FileName);

        ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
    }
    else if (h.is_anchor()) 
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultRootAccess_FileName);

        ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
    }
    else if (h.is_access())
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultAccess_FileName);
        ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, 
                    static_cast<DWidget *>(getBodyFrame())));
    }
    else
    {
        //assert(!"Unsupport type be draged to runeditor.");
        return ptrWidget;
    }    
    //register event handle
    ptrWidget->registerEvent(DEvent::Enlarge);
    ptrWidget->registerEvent(DEvent::Shrink);    
    ptrWidget->registerEvent(DEvent::Hover);
    ptrWidget->registerEvent(DEvent::PassingOut);
    ptrWidget->setEventRoutine(DEvent::Hover,
                               this,
                               static_cast<EventRoutine>(&DImplEditor::onHoverChild)); 
    ptrWidget->setEventRoutine(DEvent::PassingOut,
                               this,
                               static_cast<EventRoutine>(&DImplEditor::onPassingOutChild)); 
    ptrWidget->registerEvent(DEvent::DnD_Start);
    ptrWidget->setEventRoutine(DEvent::DnD_Start,
                             this,
                             static_cast<EventRoutine>(&DImplEditor::onDnDStart));
 
    ptrWidget->setFocusAttr(true);
    ptrWidget->registerEvent(DEvent::Delete);
    ptrWidget->setEventRoutine(DEvent::Delete,
                             this,
                             static_cast<EventRoutine>(&DImplEditor::onDeleteWidget));
    ptrWidget->registerEvent(DEvent::Activate);

/*    if(h.is_storage()) 
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DImplEditor::onActivateStorage));
    }*/
    if(h.is_declaration() && bCreateFunc)
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DImplEditor::onActivateFunc));
    }
    else if(h.is_object()) 
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DImplEditor::onActivateObj));
    }

    return ptrWidget;
}

void DImplEditor::onDnDStart(const DEvent &event)
{
    getApplication()->tip()->remove(event.getCon());
    m_dragPoint = event.getEventPosition();
}

void DImplEditor::onDeleteWidget(const DEvent& rEvent)
{
    NEW_SCOPE_TIMER("DImplEditor::onDeleteWidget", true);

    DWidgetPtr ptrWidget;
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;
    
    LOG_DEBUG("-------------DImplEditor::onDeleteWidget");
    // get duke data from source widget
    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget *>(pObject); 
    if (NULL == pSrcWidget)
        return;

    //set dirty 
    m_isModified = true;

    // Check if the widget is func
    DFunc* pSrcFunc = dynamic_cast<DFunc *>(pObject); 
    if (NULL != pSrcFunc) 
    {
        if(m_menuEdgePair.first.get() != NULL)
        {
            OutPEItems outPort = pSrcFunc->getOutPorts();
            for (OutPEItemIt it = outPort.begin(); it != outPort.end(); ++it) 
            {
            
                for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
                    if (*eIt == m_menuEdgePair.second) {
                        deletePopupMenuAndEdge();
                        it = --outPort.end();
                        break;
                    }
                }        
            }

            if(m_menuEdgePair.second->sourceWidget() == pObject)
                deletePopupMenuAndEdge();
        }
        pSrcFunc->clearAllEdges();
        getBodyFrame()->detachChildWidget(pSrcFunc);

    } 

    // Check if the widget is object
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>(pObject); 
    if (NULL != pSrcObj) 
    {
        if(m_menuEdgePair.first.get() != NULL)
        { 
            EItems items = pSrcObj->outEdges();
            for(EIt iter = items.begin(); iter != items.end(); ++iter)
            {
                if(*iter == m_menuEdgePair.second)
                {
                    deletePopupMenuAndEdge();
                    break;
                }

            }
        }

        pSrcObj->clearAllEdges();
        pSrcObj->deleteTextLabel();
        getBodyFrame()->detachChildWidget(pSrcObj);
    }

    //delete subEditor if there is
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    if(pEditor != NULL)
    {
        pEditor->destorySubEditors(rEvent.getCon());
        pEditor->destory(rEvent.getCon());
        eraseSubEditor(pEditor);        
    }

    //delete the map
    std::map<DWidget*, std::string>::iterator it = m_link.find(pSrcWidget);
    if(it != m_link.end())
    {
        pImplMedia->remove_node(it->second);
        m_link.erase(it);
    }
    else
    {
        assert(!"Could not find the node name!");        
    }    
          
    for (ImplWidgetsIt iter = m_implWidgets.begin(); iter != m_implWidgets.end(); ++iter)
    {
        if (iter->get() == pSrcWidget)
        {
            m_implWidgets.erase(iter);
            break;
        }
    }
    
    getApplication()->tip()->remove(rEvent.getCon());
    
    if(m_implType == impl_node_condition)
       switchToConditionImpl();

    updateAll();
    repaint(rEvent.getCon());

    //save 
    saveNodeInfo();
    m_pMainWin->synchronizeEditors(rEvent.getCon(), this);
}

void DImplEditor::onDnDDrag(const DEvent &event)
{
    LOG_DEBUG("--------------DImplEditor::onDnDDrag");
    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DropCursor);
    }
    
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DPort* pSrcPort = dynamic_cast<DPort*>(pObject); 
    if (pSrcPort == NULL)
        return;

    EItems edges;
    if (dynamic_cast<DFunc*>(pSrcPort->parent())) 
    {
        edges = dynamic_cast<DFunc*>(pSrcPort->parent())->getEdgesFromOutPort(pSrcPort);
    } 
    else if (dynamic_cast<DObjIcon*>(pSrcPort->parent())) 
    {
        edges = dynamic_cast<DObjIcon*>(pSrcPort->parent())->outEdges();
    }
    else 
    {
        return;
    }

    for (EIt eIt = edges.begin(); eIt != edges.end(); eIt++) 
    {
        if (NULL != eIt->get() && NULL == eIt->get()->targetWidget())
        {
            eIt->get()->setTargetParentCoord(event.getEventPosition());
            eIt->get()->updateAll();
            eIt->get()->repaint(event.getCon());
        }
    }
    saveNodeInfo();
}

void DImplEditor::updateEdgesPos()
{
    if(m_ptrInFunc.get() == NULL || m_ptrOutFunc.get() == NULL)
        return;
    
    //update in/out func
    m_ptrInFunc->updateEdgesPos(); 
    m_ptrOutFunc->updateEdgesPos(); 

    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it)
    {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc* pFuncWidget = dynamic_cast<DFunc *>(pWidget);
        if (NULL != pFuncWidget) 
        {
            pFuncWidget->updateEdgesPos();
            continue;
        } 

        DObjIcon *pObjWidget = dynamic_cast<DObjIcon *>(pWidget);
        if (NULL != pObjWidget)
            pObjWidget->updateEdgePos();
    }
}

void DImplEditor::onDnDRelease(const DEvent &event)
{
    NEW_SCOPE_TIMER("DImplEditor::onDnDRelease", true);

    LOG_DEBUG("DImplEditor::onDnDRelease---------------");
    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
       
    //if the drag widget is edge, return for no action
    if (dynamic_cast<DEdge*>(pObject))
    {
       LOG_DEBUG("drag object is edge");  
       return;
    }

    DDialog* pDlg = dynamic_cast<DDialog *>(pObject);
    if (NULL != pDlg)
    {
       dialogRelease(event);
       return;
    }

    //set dirty
    m_isModified =true;
    bool isMove = false; 
    //if the drag widget is port, delete the port's edge
    DPort* pSrcPort = dynamic_cast<DPort*>(pObject); 
    if (pSrcPort != NULL) 
    {
       portRelease(event, pSrcPort);
    }

    // if the draged widget is function,move it
    DFunc* pSrcFunc = dynamic_cast<DFunc* >(pObject);
    if (NULL != pSrcFunc)
    {
       funcRelease(event, pSrcFunc);
       isMove = true;
    }
    
    // if the draged widget is object,move it too.
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon* >(pObject);
    if (NULL != pSrcObj)
    {
        if(m_implType == impl_node_condition)
        {
            DWidget* pSrcWidget = dynamic_cast<DWidget*>(pSrcObj);
            if(pSrcWidget) ajustCondition(pSrcWidget, event.getEventPosition().y());
            isMove = true;
        }
        objRelease(event, pSrcObj);
        isMove = true;
    }                  

    // create widget for duke object
    DButton* pSrcWidget = dynamic_cast<DButton *>(pObject);

    //for condition and loop, object must be implement
    if(impl_node_condition == m_implType || impl_node_loop == m_implType)
    {
        if(!pSrcWidget->getMediaHandle().is_object_implement())
        {
            return;
        }

        duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
        if(!duke_media_implement_cover_implement(pImplMedia->get_handle(), pSrcWidget->getMediaHandle()))
        {
            return;
        }
    }

    if(pSrcWidget)
    {
        duke_media_handle handle = pSrcWidget->getMediaHandle();
    
        if ( (handle != this->getMediaHandle())
             && (handle.is_object() || handle.is_storage() || handle.is_anchor()
                 || handle.is_object_container_des() || handle.is_object_exec_condition()
                 || handle.is_object_exec_iterator()) )
        {
            // if widget is storage
            if (handle.is_storage())
            {
                duke_media_handle hstorageif = duke_media_handle_null;
                duke_media_storage stMedia(handle);
                stMedia.get_type(hstorageif);
                if (hstorageif.is_type_null()) 
                    return;
            }

            duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
            if (NULL == pImplMedia)
                return;

            DWidgetPtr ptrWidget = createWidget(handle, false);
            if(!ptrWidget)
                return;
            addWidgetToEditor(event.getEventPosition(), ptrWidget);
        
            std::string node_name;
            duke_media_get_name(pSrcWidget->getMediaHandle(), node_name);
            node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    
            m_link.insert(std::make_pair(ptrWidget.get(), node_name));

            if(typeid(*ptrWidget.get()) == typeid(DObjIcon))
            {
                pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                            node_name, ptrWidget->getMediaHandle()); 
            }
            else if(typeid(*ptrWidget.get()) == typeid(DFunc))
            {
                duke_media_handle funcOwnerIf = dynamic_cast<DFunc*>(ptrWidget.get())->getOwnerIf();
                pImplMedia->add_func_node(node_name, ptrWidget->getMediaHandle(),funcOwnerIf);
            }
        }
    }

    //switch to impl type    
    switchByImplType();
    
    // repaint
    updateEdgesPos();    
    updateAll();
    repaint(event.getCon());

    //update and repaint subeditors
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);

    //save
    saveNodeInfo();
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DImplEditor::portRelease(const DEvent& rEvent, DPort* pSrcPort)
{
    if (NULL == pSrcPort)
        return;
    
    if(m_menuEdgePair.first.get() != NULL)
    {
        if(typeid(*(m_menuEdgePair.second->sourceWidget())) == typeid(*pSrcPort))
        {
           deletePopMenu(rEvent);
        }
    }

    DEdgePtr ptrEdge;
    bool is_host_port = false;    
    
    duke_media_handle interfaceHandle = duke_media_handle_null;
    duke_media_handle_vector vDeclarationHandle;

    duke_media_handle master = duke_media_handle_null;

    // If the parent of the port is func
    DFunc* pFunc = dynamic_cast<DFunc*>(pSrcPort->parent());
    if (NULL != pFunc) 
    {

        if(pFunc == m_ptrInFunc.get())
        {
            if(pFunc->getIndexByPort(pSrcPort) == 0)
            {
                is_host_port = true;                
            }
        }
        
        int height = pFunc->geometry().height();
        if (rEvent.getEventPosition().y() <= pFunc->geometryY() + height)
        {
            ptrEdge = pFunc->getSuspendEdge(pSrcPort);
            if (NULL == ptrEdge.get())
                return;
            pFunc->deleteEdgeFromOutPort(pSrcPort, ptrEdge.get());        
            return;
        }

        if (!pSrcPort->getMedia())
        {
            pFunc->clearEdgesFromOutPort(pSrcPort);
            return;
        }

        interfaceHandle = pSrcPort->getMediaHandle();

        if(interfaceHandle.is_interface_time_line())
        {
            pFunc->deleteEdgeFromOutPort(pSrcPort, pFunc->getSuspendEdge(pSrcPort).get());
            return;
        }

        if (interfaceHandle.is_object_array())
        {
            duke_media_array harr(interfaceHandle);
            harr.get_interface(interfaceHandle);
        }

        if (interfaceHandle.is_object_map())
        {
            duke_media_map hmap(interfaceHandle);
            hmap.get_interface(interfaceHandle);
        }

        if (interfaceHandle.is_storage())
        {
            //duke_logic_storage hstor(interfaceHandle, "");
            duke_media_storage hstor(interfaceHandle);
            hstor.get_interface(interfaceHandle);
        }
        duke_media_get_declarations_by_interface(interfaceHandle, vDeclarationHandle);

        //for check declare of compose output interface
        for(std::size_t i = 0; i < vDeclarationHandle.size(); ++i)
        {
            if(!vDeclarationHandle[i].is_function_compose())
            {
                continue;
            }

            duke_media_compound_declare  compose(vDeclarationHandle[i]);
            if(compose.get_port_interface(0, false) != interfaceHandle)
            {
                compose.clear_output_ports();
                compose.add_output_port(interfaceHandle);
            }
            break;
        }

        LOG_DEBUG("interface handle"<<interfaceHandle.str());
        LOG_DEBUG("DImplEditor::onSelectChild decls size: " << vDeclarationHandle.size());
        if(((interfaceHandle == duke_media_handle_null) 
            || (vDeclarationHandle.size() == 0) ))
        {
            pFunc->clearEdgesFromOutPort(pSrcPort);
            return;
        }

        LOG_DEBUG("DIFEditor::onSelectChild get suspend edge");
        ptrEdge = pFunc->getSuspendEdge(pSrcPort);
        
        if (!ptrEdge)
            return;
    } 

    // If the parent of the port is object
    DObjIcon *pObj = dynamic_cast<DObjIcon*>(pSrcPort->parent());
    if (NULL != pObj) 
    {
        int height = pObj->geometry().height();
        if (rEvent.getEventPosition().y() <= pObj->geometryY() + height)
        {
            ptrEdge = pObj->getSuspendEdge();
            if (NULL == ptrEdge.get())
                return;
            
            pObj->deleteOutEdge(ptrEdge.get());
            return;
        }

        if (!pObj->getMedia())
        {
            pObj->clearAllEdges();
            return;
        }

        LOG_DEBUG("DImplEditor::onSelectChild get port handle");

        duke_media_handle handle = pObj->getMediaHandle();        
        if(handle.is_storage())
        {
            duke_media_get_interface_by_storage(handle, interfaceHandle);
        }
        else if(handle.is_anchor())
        {
            duke_media_get_interface_by_anchor(handle, interfaceHandle);
        }
        else if(handle.is_object_container_des())
        {
            duke_media_get_interface_by_container(handle, interfaceHandle);
        }
        else
        {            
            duke_media_get_interface_by_object(handle, interfaceHandle, getApplication()->get_host_committer_id());
        }

        if(interfaceHandle == duke_media_handle_null)
        {
            pObj->clearAllEdges();
            return;
        }
        
        duke_media_get_declarations_by_interface(interfaceHandle, vDeclarationHandle);
        //if ( (interfaceHandle == duke_media_handle_null) 
         if(vDeclarationHandle.size() == 0)
        {
            pObj->clearAllEdges();
            return;
        }

        ptrEdge = pObj->getSuspendEdge();

        if (!ptrEdge)
            return;

        //store storage interface
        if(handle.is_storage())
        {            
            dynamic_cast<duke_media_storage *>(pObj->getMedia())->get_compound_interface(m_storage_hif);
        }
    }

    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    if (NULL != ptrPopupMenu.get())
        deletePopupMenuAndEdge();

    ptrPopupMenu.reset(new DPopupMenu(getBodyFrame()));
    assert(NULL != m_ptrPopupMenu.get());
    ptrPopupMenu->setGeometry(rEvent.getEventPosition().x(), 
            rEvent.getEventPosition().y(), 
            1600, 
            (vDeclarationHandle.size() >= PopupMenu_Item_Size) ? 
            4000 : 4000*(vDeclarationHandle.size()+2)/PopupMenu_Item_Size);
  
    ptrPopupMenu->setFocusAttr(true);
    ptrPopupMenu->registerEvent(DEvent::Focus);
    ptrPopupMenu->registerEvent(DEvent::Blur);
    ptrPopupMenu->setEventRoutine(DEvent::Blur,
                                  this,
                                  static_cast<EventRoutine>(&DImplEditor::onMenuBlur));

    int reduce = 0;
    for (duke_media_handle_size_type index = 0; index < vDeclarationHandle.size(); ++index)
    {        
        std::string handleName;
        duke_media_get_name(vDeclarationHandle[index], handleName);
        // make general instructions more obvious
        if(vDeclarationHandle[index].is_instruction_general())
        {
            handleName = "[G] "+handleName;
        }
        else if(vDeclarationHandle[index].is_function_compose()
                || vDeclarationHandle[index].is_function_decompose()
                || vDeclarationHandle[index].is_function_get_anchors()
                || vDeclarationHandle[index].is_function_get_storages())
        {
            if(!is_host_port || m_shared || m_master == duke_media_handle_null)
            {
                ++reduce;
                continue;
            }
        }
        ptrPopupMenu->insertItem(handleName, index - reduce, vDeclarationHandle[index]);
        ptrPopupMenu->connectItem(index - reduce, 
                                  this,         
                                  static_cast<EventRoutine>(&DImplEditor::onSelectDeclaration));

    }
    ptrPopupMenu->updateMenu();

    assert(NULL != ptrEdge.get());
    m_menuEdgePair.first = ptrPopupMenu;
    m_menuEdgePair.second = ptrEdge;
}

void DImplEditor::onSelectDeclaration(const DEvent& rEvent)
{
    NEW_SCOPE_TIMER("DImplEditor::onSelectDeclaration", true);

    const std::vector<DPath>& eventPath = rEvent.getEventPath();
    DObject* pSelectObject = findChild(eventPath[0]);
    DMenuItem* pSelectItem = dynamic_cast<DMenuItem* >(pSelectObject);
    if (NULL == pSelectItem)
        return;
    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    assert(NULL != ptrPopupMenu.get());
        
    DEdgePtr ptrEdge = m_menuEdgePair.second;
    assert(NULL != ptrEdge.get());
    DRect rect = ptrEdge->geometry();

    DWidgetPtr ptrWidget;
    duke_media_handle hOwnerIf;
    
    // we need special work to get FUNC_INTERFACE_CONVERT's owner interface
    if(pSelectItem->getMediaHandle().get_func_type() == NB_FUNC_INTERFACE_CONVERT)
    {
        if(!getConvertInterface(ptrEdge, hOwnerIf))        
            return;
    }
    else
    {
        // for normal decl, we trace the owner interface from the edge
        DPort* pSrcPort = dynamic_cast<DPort*>(ptrEdge->sourceWidget());
        assert(pSrcPort);
        hOwnerIf = pSrcPort->getMediaHandle();
    }
    
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    // create DFunc for the selected declaration
    ptrWidget = createWidget(pSelectItem->getMediaHandle(), true, hOwnerIf);
    if(!ptrWidget)
        return;
        
    addWidgetToEditor(ptrPopupMenu->geometryPos(), ptrWidget);
        
    std::string node_name;
    duke_media_get_name(pSelectItem->getMediaHandle(), node_name);
    node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    
    m_link.insert(std::make_pair(ptrWidget.get(), node_name));
    
    if(typeid(*ptrWidget.get()) == typeid(DFunc))
    {
        duke_media_handle funcOwnerIf = dynamic_cast<DFunc*>(ptrWidget.get())->getOwnerIf();
        if(ptrWidget->getMediaHandle().is_implementation())
        {
            duke_media_implement implMedia(ptrWidget->getMediaHandle());
            if(implMedia.loop() || implMedia.cond())
            {
                duke_media_handle hdecl;
                duke_media_get_declaration_by_object_func(ptrWidget->getMediaHandle(), hdecl);
                pImplMedia->add_func_node(node_name, ptrWidget->getMediaHandle(), funcOwnerIf, hdecl);
            }
            else
            {
                pImplMedia->add_func_node(node_name, ptrWidget->getMediaHandle(),funcOwnerIf);
            }
        }
        else{
            pImplMedia->add_func_node(node_name, ptrWidget->getMediaHandle(),funcOwnerIf);
        }
    }

    DFunc *pFunc = dynamic_cast<DFunc *>(ptrWidget.get());
    if (pFunc)
    {
        pFunc->setEdgeToInPort(ptrEdge, 0);
        this->deal_path(ptrEdge, impl_path_plus);
    }

    if (NULL != ptrPopupMenu.get())
    {
        getBodyFrame()->detachChildWidget(ptrPopupMenu.get());
        m_menuEdgePair.first.reset();
    }

    saveNodeInfo();    
    updateEdgesPos();
    updateAll();
    repaint(rEvent.getCon());

    //save
    m_pMainWin->synchronizeEditors(rEvent.getCon(), this);

    updateSubEditors();
    repaintSubEditors(rEvent.getCon(), false);
    m_storage_hif = duke_media_handle(NB_INTERFACE_NONE);    
}

// for instruction INTERFACE_CONVERT, get the proper interface to cast
// we will search TWO levels AT MOST for simplicity
bool DImplEditor::getConvertInterface(DEdgePtr pEdge, duke_media_handle& hif)
{
    DPort* pPort = dynamic_cast<DPort*>(pEdge->sourceWidget());
    assert(pPort);

    // 1 level : master is an interface-obj
    DObjIcon* pObj = dynamic_cast<DObjIcon*>(pPort->parent());
    if(pObj)
    {
        hif = pObj->getMediaHandle();   
        return true;
    }

    // 2 level : master is func[get_interface] from a const-obj
    DFunc* pFunc = dynamic_cast<DFunc*>(pPort->parent());
    assert(pFunc);
    if(pFunc->getMediaHandle().get_func_type() == NB_FUNC_GENERAL_GET_INTERFACE)
    {
        DPort* pTmpPort = dynamic_cast<DPort*>(pFunc->getEdgeFromFirstPort()->sourceWidget());
        if(dynamic_cast<DObjIcon*>(pTmpPort->parent()))
        {
            hif = pTmpPort->getMediaHandle();
            return true;
        }
    }

    // otherwise error
    return false;
}


void DImplEditor::funcRelease(const DEvent& rEvent, DFunc* pSrcFunc)
{
    if (!pSrcFunc || pSrcFunc->parent() != getBodyFrame())
        return;
    
    // source widget be from this editor
    DPoint releasePos = rEvent.getEventPosition();    
    DPoint adjustPos;
    DRect funcRect = pSrcFunc->geometry();

    adjustPos.setX(releasePos.x() - m_dragPoint.x() * funcRect.width() / 10000);
    adjustPos.setY(releasePos.y() - m_dragPoint.y() * funcRect.height() / 10000);
   
    int layer = inLayer(adjustPos.y() + m_layerHeight / 2, m_layer);
    adjustPos.setY(m_blank * (layer + 1) + m_layerHeight * layer + m_layerHeight * 5 / 4);
            
    if (!pSrcFunc->checkPos(adjustPos, m_layerHeight)) 
        return;

    pSrcFunc->move(adjustPos);
}

void DImplEditor::objRelease(const DEvent& rEvent, DObjIcon* pSrcObj)
{
     if (!pSrcObj || pSrcObj->parent() != getBodyFrame())
        return;

    // source widget be from this editor
     DPoint releasePos = rEvent.getEventPosition();
     DPoint adjustPos;
     DRect objRect = pSrcObj->geometry();

     adjustPos.setX(releasePos.x() - m_dragPoint.x() * objRect.width() / 10000);
     adjustPos.setY(releasePos.y() - m_dragPoint.y() * objRect.height() / 10000);
   
     int layer = inLayer(adjustPos.y() + m_layerHeight / 2, m_layer);
     adjustPos.setY(m_blank * (layer + 1) + m_layerHeight * layer + m_layerHeight * 5 / 4);
 
     if (!pSrcObj->checkPos(adjustPos, m_layerHeight)) 
         return;

     pSrcObj->move(adjustPos);
}

void DImplEditor::dialogRelease(const DEvent& rEvent)
{    
    DPoint releasePos = rEvent.getEventPosition();    
    DPoint adjustPos;
    DRect editorRect = geometry();

    adjustPos.setX(releasePos.x() * editorRect.width() / 10000 + editorRect.x());
    adjustPos.setY(releasePos.y() * editorRect.height() / 10000 + editorRect.y());

    DEvent& eventRef = const_cast<DEvent &>(rEvent);
    eventRef.setEventPosition(adjustPos);
    assert(NULL != m_pMainWin);
    m_pMainWin->onDnDRelease(rEvent); 
}

void DImplEditor::deletePopupMenuAndEdge()
{
    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    if(ptrPopupMenu)
    {
        getBodyFrame()->detachChildWidget(ptrPopupMenu.get());
        m_menuEdgePair.first.reset();           
    }
    
    DEdgePtr ptrEdge = m_menuEdgePair.second;
    
    if (!ptrEdge.get())
        return;

    DWidget* pSourceWidget = ptrEdge->sourceWidget();
    DPort* pSrcPort = dynamic_cast<DPort *>(pSourceWidget);
    if (NULL == pSrcPort)
        return;
    DObject* pObject = pSrcPort->parent();
         
    // the edge is from DFunc
    DFunc* pFunc = dynamic_cast<DFunc *>(pObject);
    if (NULL != pFunc)
    {
        DWidget* pTargetWidget = ptrEdge->targetWidget();
        if (!pTargetWidget)
        {
            pFunc->deleteEdgeFromOutPort(pSrcPort, ptrEdge.get());     
        }
        return;
    }

    // the edge is from DObjIcon
    DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pObject);
    if (NULL != pObjIcon)
    {
        pObjIcon->deleteOutEdge(ptrEdge.get());
    }
}

void DImplEditor::onImplType(const DEvent &event)
{
    NEW_SCOPE_TIMER("DImplEditor::onImplType", true);

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
    {
        LOG_DEBUG("Error: No duke media.");
        LOG_DEBUG("===================================");
        return;
    }

    if((pButton != NULL) && (pButton == m_ptrShare.get()) && !m_shared)
    {
        if(pImplMedia->get_master() == duke_media_handle_null)
        {
            m_shared = true;
            pImplMedia->set_share();
        }
        setCurSelectedType(m_implType);
        updateAll();
        repaint(event.getCon());

        //save
        m_pMainWin->synchronizeEditors(event.getCon(), this);
        return;
    }

    if(pButton == NULL || !pImplMedia->none())
        return;
    //assert(!pImplMedia->none());
    //set dirty
    m_isModified = true;

    if(pButton == m_ptrGeneral.get())
    {
        m_implType = impl_node_general;
        pImplMedia->set_general();
    }
    else if(pButton == m_ptrCondition.get())
    {
        m_implType = impl_node_condition;
        pImplMedia->set_cond();
    }
    else if(pButton == m_ptrLoop.get())
    {
        m_implType = impl_node_loop;
        pImplMedia->set_loop();
    }
    else
    {
        assert(!"unkown button for impl type.");
    }

    setCurSelectedType(m_implType);
    switchByImplType();
    saveImplType();    
    updateAll();
    repaint(event.getCon());

    //save
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DImplEditor::onMenuBlur(const DEvent& rEvent)
{
    LOG_DEBUG("no menupassOut");
    deletePopupMenuAndEdge();
    updateAll();
    repaint(rEvent.getCon());
}

void DImplEditor::onHoverChild(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
    {
        if (pSrcWidget->getMedia()->is_object_builtin()) 
        {   
            if (pSrcWidget->getMedia()->is_object_bytes())
            {
                strTip = "btyes";
            }
            else
            {
                std::string val;
                pSrcWidget->getMediaValue(val);
                strTip = strTip + " " + val; 
            }
        }
        // declaration as object
        else if (pSrcWidget->getMedia()->is_declaration() && dynamic_cast<DObjIcon*>(pSrcWidget))
            strTip += "  [declaration]";
        // interface as object
        else if (pSrcWidget->getMedia()->is_interface())
            strTip += "  [interface]";
        else if (pSrcWidget->getMedia()->is_implementation())
            strTip += "  [implementation]";

    }
    else
    {
        // use path as tip
        strTip = pSrcWidget->strPath();
    }

    getApplication()->tip()->add(pSrcWidget, strTip, event.getCon());
}

void DImplEditor::onPassingOutChild(const DEvent &event)
{
    getApplication()->tip()->remove(event.getCon());
}

void DImplEditor::onActivatePorts(const DEvent &event)
{
    LOG_DEBUG("--------------DImplEditor::onActivatePorts");

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    if((m_implType == impl_node_condition) || (m_implType == impl_node_loop))
        return;

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
    
    //find another decleditor
    DEditor * pHideEditor = NULL;
    if(pSrcWidget == m_ptrInFunc.get())
    {
        pHideEditor = findSubEditorByWidget(m_ptrOutFunc.get());
    }
    else
    {
        pHideEditor = findSubEditorByWidget(m_ptrInFunc.get());  
    }

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    //try to hide another decleditor
    if(pHideEditor != NULL && (!pHideEditor->isHide()))
    {
        pEditor = pHideEditor;
    }

    // display editor
    if (pEditor != NULL) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {

            DDeclEditor * pDeclEditor = dynamic_cast<DDeclEditor *>(pEditor);
            if(pDeclEditor != NULL)
            {
                duke_media_handle_vector hiifs, hoifs;
                pImplMedia->get_interfaces(hiifs, hoifs);

                pDeclEditor->setInPortConstraint(hiifs);
                pDeclEditor->setOutPortConstraint(hoifs);
                pDeclEditor->updateAll();
            }
            else
            {
                assert(!"It is not DeclEditor.");
            }            
            pEditor->display(event.getCon());
        }
        else
        //close the editor, sync the port info
        { 
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
            DDeclEditor * pDeclEditor = dynamic_cast<DDeclEditor *>(pEditor);
            if(pDeclEditor != NULL)
            {   
                WidgetIndexs inPortSeq;
                WidgetIndexs outPortSeq;

                //origin port interfaces
                duke_media_handle_vector old_iifs, old_oifs;
                pImplMedia->get_interfaces(old_iifs, old_oifs);
                
                //new port interfaces
                duke_media_handle_vector new_iifs, new_oifs;
                pDeclEditor->getInPortConstraint(new_iifs, inPortSeq);
                pDeclEditor->getOutPortConstraint(new_oifs, outPortSeq);

                //save new port interfaces
                pImplMedia->set_port_interfaces(new_iifs, new_oifs);

                //if not equal(modified), adjust the edges
                if(old_iifs != new_iifs)
                {
                    //if input have changed, clear input all line
                    m_ptrInFunc->clearAllPorts();
                    
                    //add the port
                    m_ptrInFunc->insertPorts(0, inPortSeq.size());

                    //set duke media handle
                    assert(inPortSeq.size() == new_iifs.size());
                    for (size_t i = 0; i < new_iifs.size(); ++i) 
                    {
                        m_ptrInFunc->setMediaForOutPort(i, new_iifs[i]);
                    }
                }

                if( old_oifs != new_oifs)
                {
                    //if output have changed, clear output all line
                    m_ptrOutFunc->clearAllPorts();
                    
                    //add the port
                    m_ptrOutFunc->insertPorts(outPortSeq.size(), 0);

                    //set duke media handle
                    assert(outPortSeq.size() == new_oifs.size());
                    for (size_t i = 0; i < new_oifs.size(); ++i) 
                    {
                        m_ptrOutFunc->setMediaForInPort(i, new_oifs[i]);
                    }
                }
                //adjustEdgesForPorts(new_iifs, new_oifs, inPortSeq, outPortSeq);                

                switchByImplType();
                updateInOutPorts();
                updateAll();
                repaint(event.getCon());
                m_pMainWin->synchronizeEditors(event.getCon(), this);


                if(!pImplMedia->get_share())
                {
                    m_master = pDeclEditor->getMaster();
                    pImplMedia->set_master(m_master);
                }
            }
            else
            {
                assert(!"It is not DeclEditor.");
            }            
        }

        return;
    }

    // Create new DeclEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    DDeclEditorPtr ptrEditor(new(std::nothrow) DDeclEditor(BodyModel,
                                                           pMainWin,
                                                           pMainWin->getRootWidget()));
    ptrEditor->setEditorFlag(true);
    ptrEditor->initDialog();
    insertSubEditor(pSrcWidget, ptrEditor);



    duke_media_compound_declare mdecl(getApplication()->get_host_committer_id());
    ptrEditor->setMediaByHandle(mdecl.get_handle());

    ptrEditor->initDeclEditor();
    ptrEditor->setMaster(pImplMedia->get_master());

    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                     pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                           3000, 
                           3000);
    ptrEditor->setDisplayOrder(displayOrder() - 1);

    // get input/output interfaces
    duke_media_handle_vector hiifs, hoifs;
    pImplMedia->get_interfaces(hiifs, hoifs);

    ptrEditor->setInPortConstraint(hiifs);
    ptrEditor->setOutPortConstraint(hoifs);

    //ptrEditor->setInPortConstraint(m_iifs);
    //ptrEditor->setOutPortConstraint(m_oifs);
   
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());
}

void DImplEditor::onActivateFunc(const DEvent &event)
{
    LOG_DEBUG("--------------DImplEditor::onActivateInWidget");

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    /*
    if (pSrcWidget->getMediaHandle().is_function_instruction()
        || pSrcWidget->getMediaHandle().is_bridge_declaration()
		|| pSrcWidget->getMediaHandle().is_function_declare())
        return;
    */

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor != NULL) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else 
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(pEditor->isModified())
        {
            m_isModified = true;
        }
        return;
    }

    pEditor = createSubEditor(pSrcWidget);
    pEditor->setReadonly();
    pEditor->updateAll();
    pEditor->show(event.getCon());
}
/*
void DImplEditor::onActivateStorage(const DEvent &event)
{
    LOG_DEBUG("--------------DImplEditor::onActivateStorage");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            pEditor->reload();
            pEditor->updateAll();
            pEditor->repaint(event.getCon());
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        return;
    }

    if (pSrcWidget->getMedia()->is_storage()) {
        // Create new ObjEditor with PanelModel
        DMainWin * pMainWin = m_pMainWin;
        DStorageEditorPtr ptrEditor(new(std::nothrow) DStorageEditor(StorageEditor_ObjName, 
                    DEditor::PanelModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        insertSubEditor(pSrcWidget, ptrEditor);
        ptrEditor->initDialog();

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_StorageEditor_W_InMainWin, 
                Default_StorageEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);

        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
        ptrEditor->initStorageEditor();
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());

        //synchronize
        m_pMainWin->synchronizeEditors(event.getCon(), this);
    } else {
        assert(!"could not reach here!");        
    }
}
*/
void DImplEditor::onActivateObj(const DEvent &event)
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;
    
    LOG_DEBUG("--------------DImplEditor::onActivateObj");
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if ((pSrcWidget == NULL) || (pSrcWidget->getMedia() == NULL)
        || pSrcWidget->getMedia()->is_object_bridge()
        || pSrcWidget->getMedia()->is_access()
		|| pSrcWidget->getMediaHandle().is_function_instruction())
        return;

	duke_media_handle handle = pSrcWidget->getMediaHandle();
	
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pInput && pEditor->isHide())
        {
            pSrcWidget->setMediaValue(pInput->getInputString());
            std::string value;
            pSrcWidget->getMediaValue(value);
            pInput->setInputString(value);            
            dynamic_cast<DObjIcon *>(pSrcWidget)->setTextContent(value);
            
            //replace the node in media
            std::map<DWidget*, std::string>::iterator it = m_link.find(pSrcWidget);

            std::string node_name;
            duke_media_get_name(pSrcWidget->getMediaHandle(), node_name);
            node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    
            //replace path of the current node
            pImplMedia->replace_path_name(it->second, node_name);

            if(it != m_link.end())
            {
                pImplMedia->remove_node(it->second);        
            }
            else
            {
                assert(!"Could not find the node name!");        
            }

            it->second = node_name;            
            pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                        node_name, pSrcWidget->getMediaHandle()); 
            
            saveNodeInfo();
            m_isModified = true;

            updateAll();
            repaint(event.getCon());
        }

        if(pEditor->isModified())
        {
            m_isModified = true;
        }
        if (pSrcWidget->getMedia()->is_object_array())
        {
            DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pSrcWidget);
            if (pObjIcon)
            {
                pObjIcon->reloadObjMedia();
                duke_media_array* pMedia = dynamic_cast<duke_media_array *>(pObjIcon->getMedia());
                if(pMedia)
                {
                    DImage img;
                    img.setXScale(DImage::Stretch);
                    img.setYScale(DImage::Stretch);
                    img.setRelation(DImage::Disrelated);                
                    //change the icon
                    if(pMedia->is_expanded())
                    {
                        img.load(get_builtin_resource_path() + ImplEditor_ArrayExImg_FileName);
                    }
                    else
                    {
                        img.load(get_builtin_resource_path() + ImplEditor_ArrayImg_FileName);
                    }
                    pObjIcon->setImage(img);
                }
                
                //replace the node in media
                std::map<DWidget*, std::string>::iterator it = m_link.find(pSrcWidget);

                std::string node_name;
                duke_media_get_name(pSrcWidget->getMediaHandle(), node_name);
                node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    
                
                //replace path of the current node
                pImplMedia->replace_path_name(it->second, node_name);

                if(it != m_link.end())
                {
                    pImplMedia->remove_node(it->second);        
                }
                else
                {
                    assert(!"Could not find the node name!");        
                }
                it->second = node_name;            
                pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                            node_name, pSrcWidget->getMediaHandle());
                saveNodeInfo();
                m_isModified = true;

                pObjIcon->updateAll();
                pObjIcon->repaint(event.getCon());
            }
        }
        else if (pSrcWidget->getMedia()->is_object_map())
        {
            DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pSrcWidget);
            if (pObjIcon)
            {
                pObjIcon->reloadObjMedia();
                duke_media_map* pMedia = dynamic_cast<duke_media_map *>(pObjIcon->getMedia());
                if(pMedia)
                {
                    DImage img;
                    img.setXScale(DImage::Stretch);
                    img.setYScale(DImage::Stretch);
                    img.setRelation(DImage::Disrelated);                
                    //change the icon
                    if(pMedia->is_expanded())
                    {
                        img.load(get_builtin_resource_path() + ImplEditor_MapExImg_FileName);
                    }
                    else
                    {
                        img.load(get_builtin_resource_path() + ImplEditor_MapImg_FileName);
                    }
                    pObjIcon->setImage(img);
                }

                //replace the node in media
                std::map<DWidget*, std::string>::iterator it = m_link.find(pSrcWidget);

                std::string node_name;
                duke_media_get_name(pSrcWidget->getMediaHandle(), node_name);
                node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    

                //replace path of the current node
                pImplMedia->replace_path_name(it->second, node_name);
                if(it != m_link.end())
                {
                    pImplMedia->remove_node(it->second);        
                }
                else
                {
                    assert(!"Could not find the node name!");        
                }

                it->second = node_name;            
                pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                            node_name, pSrcWidget->getMediaHandle());
                saveNodeInfo();
                m_isModified = true;

                pObjIcon->updateAll();
                pObjIcon->repaint(event.getCon());
            }
        }
        else if (pSrcWidget->getMedia()->is_object_bytes())
        {
            DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pSrcWidget);
            if (pObjIcon)
            {
                pObjIcon->reloadObjMedia();
                
                //replace the node in media
                std::map<DWidget*, std::string>::iterator it = m_link.find(pSrcWidget);

                std::string node_name;
                duke_media_get_name(pSrcWidget->getMediaHandle(), node_name);
                node_name = node_name + "_" + boost::lexical_cast<std::string>(++m_index);    

                //replace path of the current node
                pImplMedia->replace_path_name(it->second, node_name);
                if(it != m_link.end())
                {
                    pImplMedia->remove_node(it->second);        
                }
                else
                {
                    assert(!"Could not find the node name!");        
                }

                it->second = node_name;            
                pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                            node_name, pSrcWidget->getMediaHandle());
                saveNodeInfo();
                m_isModified = true;

                pObjIcon->updateAll();
                pObjIcon->repaint(event.getCon());
            }
        }

        return;
    }

    pEditor = createSubEditor(pSrcWidget);
    if(handle.is_interface() || handle.is_implementation() || handle.is_declaration())
    {
        pEditor->setReadonly();
    }
    pEditor->updateAll();
    pEditor->show(event.getCon());
}

void DImplEditor::onReleaseDecl(const DEvent &event)
{
    NEW_SCOPE_TIMER("DImplEditor::onReleaseDecl", true);

    LOG_DEBUG("DImplEditor::onReleaseDecl()");

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) 
    {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pWidget = dynamic_cast<DWidget *>(pObject);

    if(pWidget == NULL)
    {
        //assert(!"Drag NULL Widget.");
        LOG_ERROR("Drag NULL Widget to in/out ports");
        return;
    }

    //call dfunc default dnd_release event handle
    DFunc* pFunc = dynamic_cast<DFunc *>(pApp->top()->findChild(childPath[0]));
    if(pFunc != NULL)
    {
        pFunc->onDnDRelease(event);
    }
            
    duke_media_handle handle = pWidget->getMediaHandle();
    if(!handle.is_declaration())
    {
        LOG_ERROR("Must drag in a declaration.");
        return;
    }

    //Get the interfaces from the declaration 
    duke_media_handle_vector hiifs, hoifs;

    if (handle.is_object_decl_compound())
    {
       duke_media_compound_declare pDecl(handle);
       pDecl.get_interfaces(hiifs, hoifs);
    }
    else if (handle.is_object_decl_expanded())
    {
        duke_media_declare_expanded pDecl(handle);
        pDecl.get_interfaces(hiifs, hoifs);
    }    
    else 
    {
        duke_media_declare pDecl(handle);
        pDecl.get_interfaces(hiifs, hoifs);
    }

    //Sync interfaces info
    pImplMedia->set_port_interfaces(hiifs, hoifs);

    //update DeclEditor for in/out port if it is not hide
    DDeclEditor * pDeclEditor = 
        dynamic_cast<DDeclEditor *>(findSubEditorByWidget(m_ptrInFunc.get()));
    if((pDeclEditor != NULL) && (!pDeclEditor->isHide()))
    {
        pDeclEditor->setInPortConstraint(hiifs);
        pDeclEditor->setOutPortConstraint(hoifs);
        pDeclEditor->updateAll();
        pDeclEditor->repaint(event.getCon());
    }

    pDeclEditor = dynamic_cast<DDeclEditor *>(findSubEditorByWidget(m_ptrOutFunc.get()));
    if((pDeclEditor != NULL) && (!pDeclEditor->isHide()))
    {
        pDeclEditor->setInPortConstraint(hiifs);
        pDeclEditor->setOutPortConstraint(hoifs);
        pDeclEditor->updateAll();
        pDeclEditor->repaint(event.getCon());
    }

    pImplMedia->set_master(duke_media_handle_null);
    switchByImplType();
    updateInOutPorts();
    updateAll();
    repaint(event.getCon());
}

void DImplEditor::adjustPlacement()
{
    DEditor::adjustPlacement();
   
    m_typeButtonHeight = ImplEditor_Type_Heigth;
    /*
    if((NULL != getBodyFrame()) && (geometrySize().height() != 0)
       && (getViewFrame()->geometrySize().height() != 0)
       && (getBodyFrame()->geometrySize().height() != 0))
    {
        int height = ImplEditor_Type_H_InMainWin * MAX_COORD / geometrySize().height();
        height = height *  MAX_COORD / getViewFrame()->geometrySize().height();
        m_typeButtonHeight = height *  MAX_COORD / getBodyFrame()->geometrySize().height();
        adjustHeight = m_typeButtonHeight - adjustHeight;
    }
    else
    {
        m_typeButtonHeight = 0;
    }
    */

    updateTypeButtons();
    updateImplWidgets();
    updateEdgesPos();
}
    
void DImplEditor::detachEdgeFromPorts()
{
    m_ptrInFunc->clearAllEdges();
    m_ptrOutFunc->clearAllEdges();
}

void DImplEditor::adjustEdgesForPorts(const duke_media_handle_vector& hiifs,
                                      const duke_media_handle_vector& hoifs,
                                      const WidgetIndexs &inPortsSeq,
                                      const WidgetIndexs &outPortsSeq)
{
    //duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);

    if(m_ptrInFunc.get() == NULL || m_ptrOutFunc.get() == NULL)
        return;   

    //---------------------input ports --------------------------
    //store temporary port<->edge relationship for input ports
    //OutPEItems funcOutPorts = m_ptrInFunc->getOutPorts();
    //std::vector< std::vector<DPort *> > inPorts(inPortsSeq.size());    
    //for (size_t i = 0; i < inPorts.size(); ++i) 
    //{
    //    if(inPortsSeq[i] >= static_cast<int>(funcOutPorts.size()))
    //    {
    //        //new port 
    //        continue;            
    //    }

    //    //old port, save the target ports temporary
    //    DPort * funcOutPort = funcOutPorts[inPortsSeq[i]].first.get();        
    //    EItems edges =  m_ptrInFunc->getEdgesFromOutPort(funcOutPort);
    //    if (!edges.size())
    //        continue;

    //    for (EIt e_it = edges.begin(); e_it != edges.end();e_it++)
    //    {
    //        if (NULL == e_it->get()) 
    //            continue;
    //        
    //        DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
    //        if(pTargetPort == NULL)
    //            continue;
    //        
    //        inPorts[i].push_back(pTargetPort);
    //    }        
    //}

    //clear all the input ports
    m_ptrInFunc->clearAllPorts();
    
    //add the port
    m_ptrInFunc->insertPorts(0, inPortsSeq.size());

    //set duke media handle
    assert(inPortsSeq.size() == hiifs.size());
    for (size_t i = 0; i < hiifs.size(); ++i) 
    {
        m_ptrInFunc->setMediaForOutPort(i, hiifs[i]);
    }

    //reconstruct the relationship for input ports
    //int in_index = 0;
    //for(size_t i = 0; i < inPorts.size(); ++i)
    //{
    //    for(size_t j =0; j < inPorts[i].size(); ++j)
    //    {
    //        m_ptrInFunc->connect(i, inPorts[i][j]);            

    //        DFunc*  pFunc = dynamic_cast<DFunc*>(inPorts[i][j]->parent());
    //        in_index = pFunc->getIndexByPort(inPorts[i][j]);
    //        pImplMedia->add_path(m_link.find(m_ptrInFunc.get())->second, i, m_link.find(pFunc)->second, in_index); 
    //    }
    //}

    //---------------------output ports --------------------------
    //typedef std::pair<DWidget*, DPort *> FuncIdxPair;
    //InPEItems funcInPorts = m_ptrOutFunc->getInPorts();
    //std::vector< FuncIdxPair > outPorts(outPortsSeq.size());    
    //clear
    //for(size_t i = 0; i < outPorts.size(); ++i)
    //{
    //    outPorts[i].first = NULL;
    //    outPorts[i].second = 0;
    //}
    //store temporary port<->edge relationship for input ports
    //for (size_t i = 0; i < outPorts.size(); ++i)
    //{
    //    if(outPortsSeq[i] >= static_cast<int>(funcInPorts.size()))
    //    {
    //        //new port 
    //        continue;            
    //    }
    //    
    //    //old port, save the source ports temporary
    //    for(EIt eIt = funcInPorts[outPortsSeq[i]].second.begin(); eIt != funcInPorts[outPortsSeq[i]].second.end(); ++eIt)
    //    {
    //        DEdge * pEdge = eIt->get();
    //        if(pEdge == NULL)
    //        {
    //            continue;
    //        }

    //        DPort *pSourcePort = dynamic_cast<DPort *>(pEdge->sourceWidget());
    //        if(pSourcePort == NULL)
    //        {
    //            continue;
    //        }

    //        DWidget* pWidget = dynamic_cast<DWidget *>(pSourcePort->parent());
    //        // if the source port belongs to function.
    //        if (pWidget != NULL) 
    //        {
    //            outPorts[i] = FuncIdxPair(pWidget, pSourcePort);
    //        }
    //    }
    //} 

    //clear all the output ports
    m_ptrOutFunc->clearAllPorts();
    
    //add the port
    m_ptrOutFunc->insertPorts(outPortsSeq.size(), 0);

    //set duke media handle
    assert(outPortsSeq.size() == hoifs.size());
    for (size_t i = 0; i < hoifs.size(); ++i) 
    {
        m_ptrOutFunc->setMediaForInPort(i, hoifs[i]);
    }

    //int out_index = 0;
    ////reconstruct the relationship for input ports
    //for(size_t i = 0; i < outPorts.size(); ++i)
    //{
    //    DFunc * pFunc = dynamic_cast<DFunc *>(outPorts[i].first);
    //    if(pFunc != NULL)
    //    {
    //        pFunc->connect(outPorts[i].second, m_ptrOutFunc.get(), i);

    //        DFunc* pTemFunc = dynamic_cast<DFunc*>(outPorts[i].second->parent());
    //        out_index = pTemFunc->getIndexByPort(outPorts[i].second);
    //        pImplMedia->add_path(m_link.find(pTemFunc)->second, out_index, m_link.find(m_ptrOutFunc.get())->second, i);
    //        continue;
    //    }
    //    
    //    DObjIcon * pObj = dynamic_cast<DObjIcon *>(outPorts[i].first);
    //    if(pObj != NULL)
    //    {
    //        pObj->connect(m_ptrOutFunc.get(), i);

    //        pImplMedia->add_path(m_link.find(pObj)->second, 0, m_link.find(m_ptrOutFunc.get())->second, i);
    //    }
    //}
}

void DImplEditor::updateInOutPorts()
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    if (m_ptrInFunc.get() == NULL || m_ptrOutFunc.get() == NULL)
        return;   

    duke_media_handle_vector hiifs, hoifs;
    pImplMedia->get_interfaces(hiifs, hoifs);

    //update the input ports edge and duke_media_handle
    if(hiifs.size() <= m_ptrInFunc->outPortsSize())
    {
        int removeSize = m_ptrInFunc->outPortsSize() - hiifs.size(); 
        for(int i = 0; i < removeSize; ++i)
        {
            assert(m_ptrInFunc->outPortsSize() >= 1);
            m_ptrInFunc->deleteOutPort(m_ptrInFunc->outPortsSize() - 1);
        }
    }
    else if (hiifs.size() > m_ptrInFunc->outPortsSize() )
    {        
        m_ptrInFunc->insertPorts(0, hiifs.size() - m_ptrInFunc->outPortsSize());
    }
    m_ptrInFunc->updateFuncView();

    //set duke media handle
    for (size_t i = 0; i < hiifs.size(); ++i) 
    {
        m_ptrInFunc->setMediaForOutPort(i, hiifs[i]);
    }

    //delete the edge when mismatch
    OutPEItems iports = m_ptrInFunc->getOutPorts();
    for (OutPEItemIdx idx = 0; idx < iports.size(); idx++) 
    {        
        DEdgePtr ptrE;
        OutPEItemIt it = iports.begin() + idx;
        
        assert(it->first.get() != NULL);
        if (!it->second.size())
        {
            continue;
        }

        for (EIt e_it = it->second.begin(); e_it != it->second.end();e_it++) 
        {
            if (NULL == e_it->get())
                continue;

            DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
            if(pTargetPort == NULL)
                continue;

            //if pTargePort == NULL or no duke media handle, delete the edge
            if(it->first->getMediaHandle() == duke_media_handle_null
               || pTargetPort->getMediaHandle() == duke_media_handle_null)
            {
                LOG_NOTICE("DImplEditor::updateInOutPorts() : delte mismatch paths");
                m_ptrInFunc->deleteEdgeFromOutPort(it->first.get(), e_it->get());
            }
            
            //if the the interface is not match, delete the edge
            //duke_media_handle_vector vhandle;
            //pTargetPort->getMedia()->get_type(vhandle);
            //std::cout << "type:" << vhandle[0].str() << std::endl;
            if(!duke_media_interface_cover_interface(it->first->getMediaHandle(),
                                                     pTargetPort->getMediaHandle()))
            {
                LOG_NOTICE("DImplEditor::updateInOutPorts() : delte mismatch paths");
                m_ptrInFunc->deleteEdgeFromOutPort(it->first.get(), e_it->get());
            }            
        }

    }
    
    //update the output ports edge and duke_media_handle
    if(hoifs.size() <= m_ptrOutFunc->inPortsSize())
    {
        int removeSize = m_ptrOutFunc->inPortsSize() - hoifs.size(); 
        for(int i = 0; i < removeSize; ++i)
        {
            assert(m_ptrOutFunc->inPortsSize() >= 1);
            m_ptrOutFunc->deleteInPort(m_ptrOutFunc->inPortsSize() - 1);
        }
    }
    else if (hoifs.size() > m_ptrOutFunc->inPortsSize() )
    {        
        m_ptrOutFunc->insertPorts(hoifs.size() - m_ptrOutFunc->inPortsSize(), 0);
    }
    m_ptrOutFunc->updateFuncView();

    //set duke media handle
    for (size_t i = 0; i < hoifs.size(); ++i) 
    {
        m_ptrOutFunc->setMediaForInPort(i, hoifs[i]);
    }

    //delete the edge when mismatch
    InPEItems oports = m_ptrOutFunc->getInPorts();
    for (InPEItemIdx idx = 0; idx < oports.size(); idx++) 
    {        
        DEdgePtr ptrE;
        InPEItemIt it = oports.begin() + idx;
        
        assert(it->first.get() != NULL);
        for(EIt eIt=it->second.begin(); eIt!=it->second.end(); ++eIt)
        { 
            if (eIt->get() == NULL)
            {
                continue;
            }

            DPort *pSourcePort = dynamic_cast<DPort *>((*eIt)->sourceWidget());
            if(pSourcePort == NULL)
            {
                continue;
            }
                
            DFunc* pFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
            // if the source port belongs to function.
            if (pFunc != NULL) 
            {
                //if pTargePort == NULL or no duke media handle, delete the edge
                if(it->first->getMediaHandle() == duke_media_handle_null
                   || pSourcePort->getMediaHandle() == duke_media_handle_null)
                {
                    pFunc->deleteEdgeFromOutPort(pSourcePort, eIt->get());
                }
                
                //if the the interface is not match, delete the edge
                if(!duke_media_interface_cover_interface(pSourcePort->getMediaHandle(),
                                                         it->first->getMediaHandle()))
                {
                    pFunc->deleteEdgeFromOutPort(pSourcePort, eIt->get());
                }          
                continue;
            }

            // Check if the widget is object
            DObjIcon* pObj = dynamic_cast<DObjIcon *>(pSourcePort->parent()); 
            if (pObj != NULL) 
            {
                //if pTargePort == NULL or no duke media handle, delete the edge
                if(it->first->getMediaHandle() == duke_media_handle_null
                   || pSourcePort->getMediaHandle() == duke_media_handle_null)
                {
                    pObj->deleteOutEdge(eIt->get());
                }
                
                //if the the interface is not match, delete the edge
                if(!duke_media_interface_cover_interface(pSourcePort->getMediaHandle(),
                                                         it->first->getMediaHandle()))
                {
                    pObj->deleteOutEdge(eIt->get());
                }          
                continue;
            }
        }
    }
    
    //try to updated the edge
    m_ptrInFunc->updateEdgesPos();
    m_ptrOutFunc->updateEdgesPos();
}

void DImplEditor::saveImplType()
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;
    
    if(m_implType == impl_node_general)
    {
        pImplMedia->set_general();
    }
    else if(m_implType == impl_node_condition)
    {
        pImplMedia->set_cond();
    }
    else if(m_implType == impl_node_loop)
    {
        pImplMedia->set_loop();
    }
    else
    {
        pImplMedia->set_none();
    }
}

void DImplEditor::saveNodeInfo()
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    duke_media_handle implMediaHandle = pImplMedia->get_handle();

    std::vector<node_info> vNodeInfo;

    //Save only position information
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
    
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node without media information.");
            continue;
        }

        std::string dukeName;
        std::map<DWidget*, std::string>::iterator it = m_link.find(pWidget);
        if(it != m_link.end())
        {
            dukeName = it->second;
        }
        else
        {
            assert(!"Could not find the node name!");        
        }    

        DRect rect = pWidget->geometry();
        node_info nodeInfo;
        nodeInfo.name = dukeName;
        nodeInfo.x = rect.x();
        nodeInfo.y = rect.y();
        nodeInfo.w = rect.width();
        nodeInfo.h = rect.height();
        vNodeInfo.push_back(nodeInfo);
    }
    duke_media_set_hattr_node(implMediaHandle, vNodeInfo);
}

void DImplEditor::saveInternalNodeInfo()
{
    NEW_MARK_TIMER("saveInternalNodeInfo");

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    duke_media_handle implMediaHandle = pImplMedia->get_handle();
    if (duke_media_handle_null == implMediaHandle)
        return;

    //clear old implement
    pImplMedia->clear_internal_nodes();

    //sort internal node
    std::sort(m_implWidgets.begin(), m_implWidgets.end(),
              boost::bind(widgetGeometryCompare, _1, _2));

    //Save path for in ports
    OutPEItems out = dynamic_cast<DFunc *>(m_ptrInFunc.get())->getOutPorts();
    for (OutPEItemIdx idx = 0; idx < out.size(); idx++) 
    {
        DEdgePtr ptrE;
        OutPEItemIt it = out.begin() + idx;
        assert(it->first.get() != NULL);
        if (!it->second.size())
        {
            continue;
        }
        for (EIt e_it = it->second.begin(); e_it != it->second.end();e_it++) {
            if (NULL == e_it->get())
                continue;

            DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
            if(pTargetPort == NULL)
                continue;

            DFunc *pTargetFunc = dynamic_cast<DFunc*>(pTargetPort->parent());

            //get targetNodeName;
            std::string targetNodeName;                
            int targetIdx = getIndexByWidget(pTargetFunc);
            if(targetIdx < 0)
            {
                //try to add path related to the out ports
                if(pTargetFunc == m_ptrOutFunc.get())
                {
                    targetNodeName = "output_node";
                }
                else
                {                        
                    assert(!"Could not find index according to widget pointer.");
                    continue;
                }
            }
            else
            {
                std::string funcName;
                pTargetFunc->getMedia()->get_name(funcName);
                targetNodeName = funcName + "_" + boost::lexical_cast<std::string>(targetIdx);
            }
            if(pTargetPort->getMediaHandle().is_interface_time_line())
            {
                pImplMedia->add_time_path("input_node", 
                                     idx,
                                     targetNodeName, 
                                     pTargetFunc->getIndexByPort(pTargetPort), -4);            
            } 
            else
            { 
                pImplMedia->add_path("input_node", 
                    idx,
                    targetNodeName, 
                    pTargetFunc->getIndexByPort(pTargetPort));
            }
        }
    }

    TIMER_MARK("in/out ports");

    std::vector<node_info>  vNodeInfo;
    //Save nodes except in/out ports 
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        DEdgePtr ptrE;
        
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node with media information.");
            continue;
        }
        
        // nodeName = media name + "_" + index ( from 0 )
        // the index if the widget's index in a sorted vector
        std::string nodeName;
        pWidget->getMedia()->get_name(nodeName);
        nodeName.append("_" + boost::lexical_cast<std::string>(getIndexByWidget(pWidget)));
        
        if(dynamic_cast<DObjIcon*>(pWidget))
        {
            pImplMedia->add_object_node(getApplication()->get_host_committer_id(),
                                   nodeName, pWidget->getMediaHandle()); 
        }
        else if(dynamic_cast<DFunc*>(pWidget))
        {
            duke_media_handle funcOwnerIf = dynamic_cast<DFunc*>(pWidget)->getOwnerIf();
            pImplMedia->add_func_node(nodeName, pWidget->getMediaHandle(),funcOwnerIf);
        }

    }     
    TIMER_MARK("save nodes");
	
    //save path 
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        DEdgePtr ptrE;
        
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node with media information.");
            continue;
        }
        
        std::string dukeName;
        pWidget->getMedia()->get_name(dukeName);
        std::string nodeName = dukeName + "_" 
            + boost::lexical_cast<std::string>(getIndexByWidget(pWidget));
        
        DRect rect = pWidget->geometry();
        node_info nodeInfo;
        nodeInfo.name = nodeName;
        nodeInfo.x = rect.x();
        nodeInfo.y = rect.y();
        nodeInfo.w = rect.width();
        nodeInfo.h = rect.height();
        vNodeInfo.push_back(nodeInfo);
        if ((pWidget->getMedia()->is_object() && !pWidget->getMedia()->is_declaration()
             && !pWidget->getMediaHandle().is_implementation()
             && !pWidget->getMediaHandle().is_object_exec_iterator()
             && !pWidget->getMediaHandle().is_object_exec_condition())
             || pWidget->getMedia()->is_storage()
             || pWidget->getMedia()->is_anchor()
             || pWidget->getMedia()->is_object_container_des()
             || (pWidget->getMedia()->is_declaration() && dynamic_cast<DObjIcon*>(pWidget)))//add by tom
        {
            EItems edges = dynamic_cast<DObjIcon *>(pWidget)->outEdges();
            if (!edges.size())
                continue;

            for (EIt e_it = edges.begin(); e_it != edges.end();e_it++) 
            {
                if (NULL == e_it->get()) 
                    continue;

                DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
                if(pTargetPort == NULL)
                        continue;
                DFunc *pTargetFunc = dynamic_cast<DFunc*>(pTargetPort->parent());
            
                //get targetNodeName;
                std::string targetNodeName;                
                int targetIdx = getIndexByWidget(pTargetFunc);
                if(targetIdx < 0)
                {
                    //try to add path related to the out ports
                    if(pTargetFunc == m_ptrOutFunc.get())
                    {
                        targetNodeName = "output_node";
                    }
                    else
                    {                        
                        assert(!"Could not find index according to widget pointer.");
                        continue;
                    }
                }            
                else
                {
                    std::string objName;
                    pTargetFunc->getMedia()->get_name(objName);
                    targetNodeName = objName + "_" 
                        + boost::lexical_cast<std::string>(targetIdx);
                }

                if(pTargetPort->getMediaHandle().is_interface_time_line())
                {
                    pImplMedia->add_time_path(nodeName, 
                                         0,
                                         targetNodeName, 
                                         pTargetFunc->getIndexByPort(pTargetPort), -4);            
                } 
                else
                {
                    pImplMedia->add_path(nodeName, 
                                         0,
                                         targetNodeName, 
                                         pTargetFunc->getIndexByPort(pTargetPort));            
                }
            }
        }
        else if (pWidget->getMedia()->is_declaration()
                || pWidget->getMediaHandle().is_object_exec_iterator() 
                || pWidget->getMediaHandle().is_object_exec_condition())
        {
            OutPEItems out = dynamic_cast<DFunc *>(pWidget)->getOutPorts();
            for (OutPEItemIdx idx = 0; idx < out.size(); idx++) 
            {
                OutPEItemIt it = out.begin() + idx;
                assert(it->first.get() != NULL);
                if (!it->second.size())
                {
                    continue;
                }

                for (EIt e_it = it->second.begin(); e_it != it->second.end();e_it++) {
                    if (NULL == e_it->get())
                        continue;

                    DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
                    if(pTargetPort == NULL)
                        continue;
                    DFunc *pTargetFunc = dynamic_cast<DFunc*>(pTargetPort->parent());

                    //get targetNodeName;
                    std::string targetNodeName;                
                    int targetIdx = getIndexByWidget(pTargetFunc);
                    if(targetIdx < 0)
                    {
                        //try to add path related to the out ports
                        if(pTargetFunc == m_ptrOutFunc.get())
                        {
                            targetNodeName = "output_node";
                        }
                        else
                        {                        
                            assert(!"Could not find index according to widget pointer.");
                            continue;
                        }
                    }
                    else
                    {
                        std::string funcName;
                        pTargetFunc->getMedia()->get_name(funcName);                    
                        targetNodeName = funcName + "_"
                            + boost::lexical_cast<std::string>(targetIdx);
                    }
                    if(pTargetPort->getMediaHandle().is_interface_time_line())
                    {
                        pImplMedia->add_time_path(nodeName, 
                                             idx,
                                             targetNodeName, 
                                             pTargetFunc->getIndexByPort(pTargetPort), -4);            
                    } 
                    else
                    { 
                        pImplMedia->add_path(nodeName, 
                                         idx,
                                         targetNodeName, 
                                         pTargetFunc->getIndexByPort(pTargetPort));
                    }
                }
            }    

        }
    }     

    duke_media_set_hattr_node(implMediaHandle, vNodeInfo);

    TIMER_MARK("save paths");
}

/*
void DImplEditor::saveCondImplNodeInfo()
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return;

    //sort internal node
    std::sort(m_implWidgets.begin(), m_implWidgets.end(),
              boost::bind(widgetGeometryCompare, _1, _2));

    //Save nodes without path except in/out ports
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        DEdgePtr ptrE;
        
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node with media information.");
            continue;
        }

        std::string dukeName;
        pWidget->getMedia()->get_name(dukeName);
        std::string nodeName = dukeName + "_" 
            + boost::lexical_cast<std::string>(getIndexByWidget(pWidget));
        
        //save object node
        if (pWidget->getMedia()->is_object()) 
        {            
            //pImplMedia->add_object_node(nodeName, pWidget->getMediaHandle());
            assert(!"Condition implementatino could not contain object.");
        }
        else if (pWidget->getMedia()->is_declaration()) 
        {
            pImplMedia->add_func_node(nodeName, pWidget->getMediaHandle());
        }    
    }      
}
*/

void DImplEditor::generateSubItems()
{
//    for(ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it)
//    {
//        DWidget * pWidget = (*it).get();
//        if(pWidget == NULL)
//            continue;
//
//        duke_media_handle newh = duke_media_handle_null;
//        DEditor * pEditor = findSubEditorByWidget(pWidget);
//
//        //current widget have the subEditor and subEditor contain Media information
//        if(!pWidget->getMediaHandle().is_storage()
//                && pEditor && pEditor->isModified() && pEditor->getMedia() 
//                && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                && (newh != duke_media_handle_null))
//        {
//            pWidget->setMediaByHandle(newh);
//            pEditor->generateSubItems();
//            continue;
//        }
//
//        bool isEditing = duke_media_get_handle_status(getApplication()->username(),
//                                                      pWidget->getMediaHandle()) == Edit;
//
//        if(isEditing 
//           && !pWidget->getMediaHandle().is_storage()
//           && pWidget->getMedia() 
//           && pWidget->getMedia()->generate(getApplication()->username(), newh)
//           && (newh != duke_media_handle_null))
//        {
//            createSubEditor(pWidget)->generateSubItems();
//            pWidget->setMediaByHandle(newh);
//        }
//    }
}

duke_media_handle DImplEditor::generate()
{
    NEW_SCOPE_TIMER("DImplEditor::generate()", true);

    //if current object already have been generated, just return.
    if (e_handle_core == get_media_handle_status(m_handle))
    {
        LOG_INFO("This object already have been generated");
        return m_handle;        
    }
    
    //DEditor::generate();

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
        return duke_media_handle_null;

    LOG_DEBUG("==========Generate the "<<m_dukeName<<" Implement==========");

    duke_media_handle newHandle = duke_media_handle_null;

    if(isValidImpl(pImplMedia))
    {
        dumpImplementInfo();

        nb_id_t new_id;
        std::map<int, nb_id_t> idx_id_map;
        if (pImplMedia->compile(getApplication()->username(), new_id, idx_id_map))
        {
            // save the generated ids to warehouse ?
            newHandle = new_id;
            save_generated_handle(newHandle, getApplication()->username());

            LOG_INFO("Generate the Implementation successfully.");
        }
    }
    else
    {
        LOG_ERROR("It is not a valid Implementation, could not generate Implementation!");
    }

    std::vector<node_info> vNodeInfo;
    duke_media_get_hattr_node(pImplMedia->get_handle(), vNodeInfo);
    duke_media_set_hattr_node(newHandle, vNodeInfo);

    return newHandle;
}

void DImplEditor::onGenerate(const DEvent& event)
{
    generate();        
    destorySubEditors(event.getCon());
    clearSubEditors();
}

bool DImplEditor::isValidImpl(duke_media_implement* pImplMedia)
{
    NEW_SCOPE_TIMER("DImplEditor::isValidImpl", true);

    if (pImplMedia == NULL)
    {
        m_generateErrorInfo = "no impl media";
        return false;
    }

    LOG_DEBUG("Check Object Completeness: ");

    //check the name is not empty
    std::string name;
    pImplMedia->get_name(name);
    if(name.empty())
    {
        LOG_INFO("Error, missing name.");
        m_generateErrorInfo = "Error, missing name";
        return false;
    }

    //check impl type != none
    if(pImplMedia->none())
    {
        LOG_INFO("Error, missing implementation type.");
        m_generateErrorInfo = "Error, implementation type.";
        return false;
    }

    //check in/out ports
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    pImplMedia->get_interfaces(hiifs, hoifs);

    //check input ports
    if(hiifs.empty())
    {
        LOG_INFO("Error, missing input port.");
        m_generateErrorInfo = "Error, missing input port";
        return false;
    }
    for (size_t i = 0; i < hiifs.size(); ++i) 
    {
        if(hiifs[i] == duke_media_handle_null)
        {
            LOG_INFO("Error, the interface for input port is null.");
            m_generateErrorInfo = "Error,the interface for input is null";
            return false;
        }
    }
    
    //check output ports
    /*
    if(hoifs.empty())
    {
        std::cout<<"Error, missing output port."<<std::endl;
        m_generateErrorInfo = "Error, missing output port";
        return false;
    }
    */
    for (size_t i = 0; i < hoifs.size(); ++i) 
    {
        if(hoifs[i] == duke_media_handle_null)
        {
            LOG_INFO("Error, the interface for output port is null.");
            m_generateErrorInfo = "Error,the interface for output is null";
            return false;
        }
    }

    //check the input port for func should be connected
     for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it)
     {
         DWidget * pWidget = (*it).get();
         DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
         if(pFunc)
         {        
             if(!pFunc->checkInPortsLinked())
             {
                  LOG_INFO("Error, missing the input connection.");
                  m_generateErrorInfo = "Error, missing the input connection";
                  return false;                  
             }
         }
     }
     if(!(m_implType == impl_node_condition || m_implType == impl_node_loop) && !m_ptrOutFunc->checkInPortsLinked())
     {
        return false;
     }

    //check declaration
    if(m_implType == impl_node_condition || m_implType == impl_node_loop)
    {
        for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
        {
             DWidget * pWidget = (*it).get();
             assert(pWidget != NULL);
             duke_media_implement* pObjMedia = dynamic_cast<duke_media_implement *>(pWidget->getMedia());
             if((pObjMedia != NULL) && pWidget->getMediaHandle().is_implementation())
             {
                 duke_media_handle_vector hiifs_decl, hoifs_decl;
                 pObjMedia->get_inports(hiifs_decl);
                 pObjMedia->get_outports(hoifs_decl);
                 if(!pImplMedia->match_declaration(hiifs_decl, hoifs_decl))
                 {
                     LOG_DEBUG("Error, declaration don't match.");
                     m_generateErrorInfo = "Error, declaration don't match";
                     return false;
                 }
             }
        }
    }

    m_generateErrorInfo = "Success";
    //TBD: check node & path
    return true;
}

void DImplEditor::switchByImplType()
{
    if(m_implType == impl_node_condition)
    {
        switchToConditionImpl();
    }
    else if(m_implType == impl_node_loop)
    {
        switchToLoopImpl();
    }
    else
    {
        switchToGeneralImpl();
    }
}

void DImplEditor::switchToGeneralImpl()
{
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
        if(pFunc != NULL)
        {        
            if(pWidget->getMediaHandle().is_object_exec_iterator())
            {
                pFunc->setBodyColor(ImplEditor_Iterator_Color);
            }
            else if(pWidget->getMediaHandle().is_object_exec_condition())
            {
                pFunc->setBodyColor(ImplEditor_Condition_Color);
            }
            else if(pWidget->getMediaHandle().is_implementation())
            {
                duke_media_implement implMedia(pWidget->getMediaHandle());
                if(implMedia.loop())
                {
                    pFunc->setBodyColor(ImplEditor_Iterator_Color);
                }
                else if(implMedia.cond())
                {
                    pFunc->setBodyColor(ImplEditor_Condition_Color);
                }
                else{
                    pFunc->setBodyColor(ImplEditor_Warning_Color);
                }

            }
            else if(pFunc->checkInPortsLinked())
            {
                pFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
            }
            else
            {
                pFunc->setBodyColor(ImplEditor_Warning_Color);
            }
        }        
    }

    if(m_ptrOutFunc->checkInPortsLinked())
    {
        m_ptrOutFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
    }
    else
    {
        m_ptrOutFunc->setBodyColor(ImplEditor_Warning_Color);
    }
}

void DImplEditor::switchToConditionImpl()
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
    {
        return;
    }

    //sort internal node
    /*std::sort(m_implWidgets.begin(), m_implWidgets.end(),
              boost::bind(widgetGeometryCompare, _1, _2));*/

    m_ptrInFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
    m_ptrOutFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);

    
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ) 
    {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
        if(pFunc != NULL)
        {        
            pFunc->clearAllEdges();
            pFunc->clearAllPorts();
            getBodyFrame()->detachChildWidget(pFunc);
            it = m_implWidgets.erase(it);
        }
        else{
            DObjIcon *pObj = dynamic_cast<DObjIcon *>(pWidget);
            if((pObj != NULL))
            {
                if(pWidget->getMediaHandle().is_object_exec_iterator() 
                        || pWidget->getMediaHandle().is_object_exec_condition()
                        || !pWidget->getMediaHandle().is_implementation())
                {
                    pObj->clearAllEdges();
                    pObj->deleteTextLabel();
                    getBodyFrame()->detachChildWidget(pObj);
                    it = m_implWidgets.erase(it);
                }
                else {
                    ++it;
                }
             }
        }
    }
    
    m_layer = m_implWidgets.size();


    if (ImplEditor_Layer*m_layer > ImplEditor_Total_Layer) 
                m_layerHeight = ImplEditor_Total_Layer / m_layer;

    if((NULL != getBodyFrame()) && (geometrySize().height() != 0)
                && (getViewFrame()->geometrySize().height() != 0)
                   && (getBodyFrame()->geometrySize().height() != 0))
    {
        int height = ImplEditor_Type_H_InMainWin * MAX_COORD / geometrySize().height();
        height = height *  MAX_COORD / getViewFrame()->geometrySize().height();
        m_typeButtonHeight = height *  MAX_COORD / getBodyFrame()->geometrySize().height();
    }
    else
    {
        m_typeButtonHeight = 0;
    }

    int freeSpace = MAX_COORD - m_layerHeight * 5 / 2 - m_typeButtonHeight;
        m_blank = (freeSpace - m_layer * m_layerHeight) / (m_layer + 1);


    int layer = 0;
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it ) 
    {
        DWidget * pWidget = (*it).get();
        DRect old = pWidget->geometry();
        old.setLeft( (MAX_COORD - pWidget->geometrySize().width()) / 2 );
        old.setRight( (MAX_COORD + pWidget->geometrySize().width()) / 2 );
        old.setTop(m_blank*(layer+1) + m_layerHeight*layer
                   + m_layerHeight*5/4 + m_typeButtonHeight);
        old.setBottom((m_blank+m_layerHeight)*(layer+1)
                      + m_layerHeight*5/4 + m_typeButtonHeight);
        pWidget->setGeometry(old);

        m_subConPosition.push_back(old.bottom());
        ++layer;
    }
}

void DImplEditor::switchToLoopImpl()
{
    updateInOutPorts();

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
    {
        return;
    }

    m_ptrInFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
    m_ptrOutFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);

    int layer = 0;

    ImplWidgetsIt sole_obj;
    //mark loop object
    bool is_exist = false;
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ) 
    {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
        if(pFunc != NULL)
        {        
            pFunc->clearAllEdges();
            pFunc->clearAllPorts();
            getBodyFrame()->detachChildWidget(pFunc);
            it = m_implWidgets.erase(it);
        }
        else{
            DObjIcon *pObj = dynamic_cast<DObjIcon *>(pWidget);
            if((pObj != NULL))
            {
                if((!pWidget->getMediaHandle().is_object_exec_iterator() 
                        && !pWidget->getMediaHandle().is_object_exec_condition())
                        && pWidget->getMediaHandle().is_implementation())
                {
                    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(pWidget->getMedia());
                    if(pImplMedia)
                    {
                        if(!is_exist)
                        {
                            is_exist = true;
                            sole_obj = it;
                            ++it;
                        }
                        else{
                            pWidget = (*sole_obj).get();
                            pObj = dynamic_cast<DObjIcon *>(pWidget);
                            if(pObj != NULL)
                            {
                                pObj->clearAllEdges();
                                pObj->deleteTextLabel();
                                getBodyFrame()->detachChildWidget(pObj);
                                m_implWidgets.erase(sole_obj);
                                sole_obj = it-1;
                            }
                        }

                    }
                    
                }
                else{
                    pObj->clearAllEdges();
                    pObj->deleteTextLabel();
                    getBodyFrame()->detachChildWidget(pObj);
                    it = m_implWidgets.erase(it);
                }
            }
        }

    }
    if(is_exist)
    {
        DWidget * pWidget = (*sole_obj).get();
        DRect old = pWidget->geometry();
        old.setLeft( (MAX_COORD - pWidget->geometrySize().width()) / 2 );
        old.setRight( (MAX_COORD + pWidget->geometrySize().width()) / 2 );
        old.setTop(m_blank*(layer+1) + m_layerHeight*layer
                   + m_layerHeight*5/4 + m_typeButtonHeight);
        old.setBottom((m_blank+m_layerHeight)*(layer+1)
                      + m_layerHeight*5/4 + m_typeButtonHeight);
        pWidget->setGeometry(old);
    }

}

void DImplEditor::dumpImplementInfo()
{
    NEW_SCOPE_TIMER("DImplEditor::dumpImplementInfo", true);

    LOG_DEBUG("===================================");

    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);
    if (NULL == pImplMedia)
    {
        LOG_DEBUG("Error: No duke media.");
        LOG_DEBUG("===================================");
        return;
    }

//dump name & icon
    std::string name;
    std::string icon;
    pImplMedia->get_name(name);
    pImplMedia->get_icon(icon);
    LOG_DEBUG("Implementation name = "<<name<<std::endl
             <<"Implementation icon = "/*<<toHexString(icon)*/);

    //dump implementation's type
    if(pImplMedia->cond())
    {
        LOG_DEBUG("Implementation type = Condition");
    }
    else if(pImplMedia->loop())
    {
        LOG_DEBUG("Implementation type = Loop");
    }
    else
    {
        LOG_DEBUG("Implementation type = General");
    }    
    
    //dump implementation's interfaces
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    pImplMedia->get_interfaces(hiifs, hoifs);

    //dump input ports
    LOG_DEBUG("input ports size = "<<hiifs.size());
    for (size_t i = 0; i < hiifs.size(); ++i) 
    {
        std::string iPortName;
        if(!duke_media_get_name(hiifs[i], iPortName))
            continue;
        LOG_DEBUG("\t("<<iPortName<<" ) ");
    }

    //dump output ports
    LOG_DEBUG("\noutput ports size = "<<hoifs.size());
    for (size_t i = 0; i < hoifs.size(); ++i) 
    {
        std::string iPortName;
        if(!duke_media_get_name(hoifs[i], iPortName))
            continue;
        LOG_DEBUG("\t("<<iPortName<<") ");
    }    

    //dump nodes
    std::vector<duke_media_node> nodes;
    pImplMedia->get_media_nodes(nodes);
    LOG_DEBUG("\nimplementation node size = "<<nodes.size());
    for (size_t i = 0; i < nodes.size(); ++i ) 
    {
        LOG_DEBUG("\t("<<nodes[i].m_name<<") ");
    }    

    //dump paths
    std::vector<duke_media_path> paths;
    pImplMedia->get_media_paths(paths);
    LOG_DEBUG("\nimplementation paths size = "<<paths.size());
    for (size_t i = 0; i < paths.size(); ++i ) 
    {
        LOG_DEBUG("\t("<<paths[i].m_onode<<"["<<paths[i].m_oport<<"] -> " <<paths[i].m_inode<<"["<<paths[i].m_iport<<"])");
    }    

    LOG_DEBUG("===================================");
}

void DImplEditor::ajustCondition(DWidget *pSrcWidget, int y)
{
    std::vector<int>::size_type insertPosition = 0;
     
    for (std::vector<int>::iterator it = m_subConPosition.begin(); it != m_subConPosition.end(); ++it)
    {
        if(y <= *it)
        {
            break;
        }
        else{
            ++insertPosition;
        }
    }
    for (ImplWidgetsIt it = m_implWidgets.begin(); it != m_implWidgets.end(); ++it ) 
    {
         if(it->get() == pSrcWidget)
         {
             DWidgetPtr pMoveWidget = *it;
             if(insertPosition < m_implWidgets.size())
             {
                 m_implWidgets.erase(it);
                 m_implWidgets.insert(m_implWidgets.begin() + insertPosition, pMoveWidget);
             }
             else             
             {
                 m_implWidgets.erase(it);
                 m_implWidgets.push_back(pMoveWidget);
             }

             break;
         }
         
    }
}

void DImplEditor::deal_path(DEdgePtr ptrE, mode select, bool timeLine /*timeLine = false*/)
{
    duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(m_ptr);

    DPort* pSrcPort = dynamic_cast<DPort*>(ptrE->sourceWidget());
    DPort* pTrtPort = dynamic_cast<DPort*>(ptrE->targetWidget());

    DWidget* pSrc = dynamic_cast<DWidget*>(pSrcPort->parent());
    if(NULL != dynamic_cast<DFunc*>(pSrc))
    {
        DWidget* pTrt = dynamic_cast<DWidget*>(pTrtPort->parent()); 
        if(NULL != dynamic_cast<DFunc*>(pTrt))
        {
            int srcIndex = dynamic_cast<DFunc*>(pSrc)->getIndexByPort(pSrcPort);
            int trtIndex = dynamic_cast<DFunc*>(pTrt)->getIndexByPort(pTrtPort);
            if(impl_path_plus == select)
            {
                // add a path 
                if(timeLine)
                {
                    pImplMedia->add_time_path(m_link.find(pSrc)->second, srcIndex, 
                        m_link.find(pTrt)->second, trtIndex, -4);
                }
                else
                {
                    pImplMedia->add_path(m_link.find(pSrc)->second, srcIndex, 
                        m_link.find(pTrt)->second, trtIndex);
                }
                return;
            }
            else// if(impl_path_minus == select)
            {
                // delete a path
                if(timeLine)
                {
                    pImplMedia->remove_time_path(m_link.find(pSrc)->second, srcIndex, 
                        m_link.find(pTrt)->second, trtIndex, -4);
                }
                else
                {
                    pImplMedia->remove_path(m_link.find(pSrc)->second, srcIndex, 
                        m_link.find(pTrt)->second, trtIndex);
                }
                return;
            }
        }
    }

    if(NULL != dynamic_cast<DObjIcon*>(pSrc))
    {
        DWidget* pTrt = dynamic_cast<DWidget*>(pTrtPort->parent()); 
        if(NULL != dynamic_cast<DFunc*>(pTrt))
        {
            int trtIndex = dynamic_cast<DFunc*>(pTrt)->getIndexByPort(pTrtPort);
            if(impl_path_plus == select)
            {
                pImplMedia->add_path(m_link.find(pSrc)->second, 0, m_link.find(pTrt)->second, trtIndex);
                return;
            }
            else// if(impl_path_minus == select)
            {
                pImplMedia->remove_path(m_link.find(pSrc)->second, 0, m_link.find(pTrt)->second, trtIndex);
                return;
            }
        }
    }

    LOG_DEBUG("DImplEditor::deal_path failed!");
    return;
}

void DImplEditor::deletePopMenu(const DEvent &event)
{
    LOG_DEBUG("--------Destory popmenu---------");
    if(m_menuEdgePair.first.get() != NULL)
    {
        m_menuEdgePair.first.get()->setGeometry(0, 0, 0, 0);
        m_menuEdgePair.first->repaint(event.getCon(), false);
        if(m_menuEdgePair.second.get() != NULL)
        {
            m_menuEdgePair.second.get()->setGeometry(0, 0, 0, 0); 
            m_menuEdgePair.second.get()->repaint(event.getCon(), false);
        }
    }
    
    if(m_menuEdgePair.first.get() != NULL)
        deletePopupMenuAndEdge();
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
