
/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_dimageex.h"

DImageEx::DImageEx(DWidget *parent /* = 0 */, WFlags f /* =0 */)
    : DWidget(*new DImageExCell, parent, f),
      m_minRadio(10000),
      m_maxRadio(10000)
{
    setObjectName(DImageEx_ObjName);    
    d_func()->init();
}

DImageEx::DImageEx(const DImage & image, 
                   DWidget * parent /* = 0 */, 
                   WFlags f /* = 0 */)
    : DWidget(*new DImageExCell, parent, f),
      m_minRadio(10000),
      m_maxRadio(10000)
{
    setObjectName(DImageEx_ObjName);    
    d_func()->init();
    setImage(image);
}

DImageEx::~DImageEx()
{
}

DImage * DImageEx::image() const
{
    return m_ptrImage.get();
}

void DImageEx::setImage(const DImage &image)
{
    m_ptrImage.reset(new(std::nothrow) DImage(image));
    assert(m_ptrImage.get() != NULL);
}

/***************************************************************************
 * DImageExCell member functions
 **************************************************************************/
DImageExCell::DImageExCell()
{
}

DImageExCell::~DImageExCell()
{
}

void DImageExCell::init()
{
    DImageEx *q = q_func();
     
    // init 
    aspectKeeper.minAspectRatio = 10000;
    aspectKeeper.maxAspectRatio = 10000;

    // init image 
    TPlacement tpImage;
    TImage image;
    TPath p1(m_place->path);
    p1.node.push_back(0);
    tpImage.path = p1;
    tpImage.position.x = tpImage.position.y = MIN_COORD;
    tpImage.size.width = MAX_COORD; 
    tpImage.size.height = MAX_COORD;
    tpImage.data = &image;
    subNodes.push_back(tpImage);
    (q->cnum())++;
    tpImage.data = NULL;
}

void DImageExCell::update()
{
    DWidgetCell::update();

    DImageEx *q = q_func();

    m_place->path.node = q->objectPath();

    // update aspectKeeper
    aspectKeeper.minAspectRatio = q->minAspectRatio();
    aspectKeeper.maxAspectRatio = q->maxAspectRatio();

    //Update Image
    TPlacement *imgPlace = &subNodes[0];
    imgPlace->path.node = q->objectPath();
    imgPlace->path.node.push_back(0);
    imgPlace->order = q->displayOrder();
    TImage *pTImage = dynamic_cast<TImage *>(imgPlace->data);
    assert(pTImage != NULL);
    const DImage* pDImage = q_func()->image();
    if (pDImage != NULL) {
        DImage2TImage(*pDImage, *pTImage);
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
