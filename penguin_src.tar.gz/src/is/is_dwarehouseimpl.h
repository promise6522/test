#ifndef DWAREHOUSEIMPL_H
#define DWAREHOUSEIMPL_H

// Boost header files
#include <boost/tr1/memory.hpp>

//C++ 98 header files
#include <fstream>
#include <vector>

//duke header files
#include "is_devent.h"
////#include "media/duke_media_header.h"

//Open this manually if you need the fake duke storge interface
//1. run "./bin/duke_is_snow_simulation"
//2. run "./bin/dukeisd your_ip your_port"
//#define Fake_Duke_Storge_Interface

///////////////////////////////////////////////////////////////
//         fake duke item(just for testing)
///////////////////////////////////////////////////////////////

/*
#ifdef Fake_Duke_Storge_Interface

#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

class duke_fake_item
{
public:
    enum DukeItemType
    {
        UnknowDukeItem = -1,
        ObjDukeItem,
        IFDukeItem,
        DeclDukeItem,
        ImplDukeItem,
        ContDukeItem,
        ExeDukeItem,
        OthersDukeItem
    };

    enum DukeItemClassic
    {
        NoneItems = -1,
        AllItems,
        BuiltInItems,
        EditItems,
        UserDefinedItems,
        SharedItems,
        OtherItems
    };
    
private:
    friend class boost::serialization::access;

    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
        ar & m_id;        
        ar & m_type;
        ar & m_name;
        ar & m_imgFileName;
        ar & m_classic;
    }
public:
    duke_fake_item()
        :m_id(rand()), m_type(UnknowDukeItem),
         m_name(""), m_imgFileName(""), m_classic(NoneItems)
    {
    }
    
    duke_fake_item(DukeItemType type, std::string name,
                   std::string fileName, DukeItemClassic classic)
        :m_id(rand()), m_type(type), m_name(name), m_imgFileName(fileName), m_classic(classic)
    {
    }

    void setProperty(DukeItemType type, std::string name,
                     std::string fileName, DukeItemClassic classic)
    {
        m_id = rand();        
        m_type = type;
        m_name = name;
        m_imgFileName = fileName;
        m_classic = classic;        
    }    

    void printProperty() const
    {
        std::cout<<"Id="<<m_id<<" \ttype="<<m_type<<" \tclassic="<<m_classic
                 <<" \tname="<<m_name<<" \timgFileName="<<m_imgFileName<<std::endl;
    }

public:
    int m_id;    
    DukeItemType m_type;
    std::string m_name;
    std::string m_imgFileName;
    DukeItemClassic m_classic;
};

typedef duke_fake_item duke_item;

#else

class duke_string_item
{
public:
    enum DukeItemType
    {
        UnknowDukeItem = -1,
        ObjDukeItem,
        IFDukeItem,
        DeclDukeItem,
        ImplDukeItem,
        ContDukeItem,
        ExeDukeItem,
        OthersDukeItem
    };

    enum DukeItemClassic
    {
        NoneItems = -1,
        AllItems,
        BuiltInItems,
        EditItems,
        UserDefinedItems,
        SharedItems,
        OtherItems
    };

    std::string m_name;
};

typedef duke_string_item duke_item;

#endif

typedef std::vector<duke_item> WarehouseDukeItems;
typedef WarehouseDukeItems::iterator WarehouseDukeItemsIt;
typedef WarehouseDukeItems::size_type WarehouseDukeItemsIdx;

*/

enum DukeItemClassic
{
    NoneItems = -1,
    AllItems,
    BuiltInItems,
    EditItems,
    UserDefinedItems,
    SharedItems,
    OtherItems
};

class DWarehouseDlg;

class DWarehouseImpl
{
public:
    //duke media related interface
    virtual duke_media_handle getDukeHandle(int pos, std::string keyWord = "");
    virtual int getDukeItemsSize(std::string keyWord = "");
    virtual int getLoadedItemsSize();
    virtual int readDukeItems(DukeItemClassic classic) = 0;

    //Message handle
    virtual void onActivate(const DEvent &event) = 0;
    virtual void onCreateNew(const DEvent &event) = 0;
    virtual void onDnDStart(const DEvent &event) = 0;
    virtual void onHover(const DEvent &event);
    virtual void onPassingOut(const DEvent &event);

protected:
    DWarehouseImpl();    
    virtual ~DWarehouseImpl();
    void reloadCache(std::string keyWord = "");
    void cleanCache();
    
    DWarehouseDlg* m_pWarehouseDlg;
    duke_media_handle_vector m_dukeItems;

    //cache
    std::string m_cacheKeyString;
    std::vector<duke_media_handle_size_type> m_cacheHandleIdxes;
    int m_cacheItemsSize;
};

class DObjhouseImpl : public DWarehouseImpl
{
public:
    DObjhouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DObjhouseImpl();
    virtual int readDukeItems(DukeItemClassic classic);

    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

class DIFhouseImpl : public DWarehouseImpl
{
public:
    DIFhouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DIFhouseImpl();
    virtual int readDukeItems(DukeItemClassic classic);

    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

class DDeclhouseImpl : public DWarehouseImpl
{
public:
    DDeclhouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DDeclhouseImpl();
    virtual int readDukeItems(DukeItemClassic classic);
    
    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

class DImplhouseImpl : public DWarehouseImpl
{
public:
    DImplhouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DImplhouseImpl();   
    virtual int readDukeItems(DukeItemClassic classic);
    
    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);    
};

class DConthouseImpl : public DWarehouseImpl
{
public:
    DConthouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DConthouseImpl();    
    virtual int readDukeItems(DukeItemClassic classic);

    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

class DAcshouseImpl : public DWarehouseImpl
{
public:
    DAcshouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DAcshouseImpl();    
    virtual int readDukeItems(DukeItemClassic classic);

    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

class DExehouseImpl : public DWarehouseImpl
{
public:
    DExehouseImpl(DWarehouseDlg* pWarehouseDlg);
    virtual ~DExehouseImpl();
    virtual int readDukeItems(DukeItemClassic classic);

    //Message handle
    virtual void onActivate(const DEvent &event);
    virtual void onCreateNew(const DEvent &event);
    virtual void onDnDStart(const DEvent &event);
};

typedef std::tr1::shared_ptr<DWarehouseImpl>  DWarehouseImplPtr;
typedef std::tr1::shared_ptr<DObjhouseImpl>   DObjhouseImplPtr;
typedef std::tr1::shared_ptr<DIFhouseImpl>    DIFhouseImplPtr;
typedef std::tr1::shared_ptr<DDeclhouseImpl>  DDeclhouseImplPtr;
typedef std::tr1::shared_ptr<DImplhouseImpl>  DImplhouseImplPtr;
typedef std::tr1::shared_ptr<DConthouseImpl>  DConthouseImplPtr;
typedef std::tr1::shared_ptr<DAcshouseImpl>  DAcshouseImplPtr;
typedef std::tr1::shared_ptr<DExehouseImpl>   DExehouseImplPtr;

#endif /* DWAREHOUSEIMPL_H */ 

// vim:set tabstop=4 shiftwidth=4 expandtab:
