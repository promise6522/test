/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

// Duke header files
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dlogindlg.h"
#include "is_dapplication.h"


DLogInDlg::DLogInDlg(DMainWin *pMainWin /* = NULL */, DWidget * parent /* = 0 */)
    :DDialogEx(LogInDlg_Title_Name, pMainWin, parent)
{
    setObjectName(LogInDlg_ObjName);
    assert(pMainWin != NULL);
}

DLogInDlg::DLogInDlg(std::string title,
                     DMainWin *pMainWin /* = NULL */,
                     DWidget * parent /* = 0 */)
    :DDialogEx(title, pMainWin, parent)
{
    setObjectName(LogInDlg_ObjName);
    assert(pMainWin != NULL);
}

DLogInDlg::~DLogInDlg()
{
}

void DLogInDlg::initDialog()
{
    DDialogEx::initDialog();

    DFrame* pFrame = getViewFrame();
    
    pFrame->setFocusAttr(true);
    pFrame->registerEvent(DEvent::DnD_Release);
    pFrame->setEventRoutine(DEvent::DnD_Release,
                            this,
                            static_cast<EventRoutine>(&DLogInDlg::onDnDRelease));

    //create access button, and hide it.
    DImage img;
    img.setRelation(DImage::KeepSmall);
    img.load(getResPath() + LogInDlg_AccessImg_FileName);    
    m_ptrAccess.reset(new(std::nothrow) DButton("", img, pFrame));
    m_ptrAccess->setGeometry(4000, 3000, 2000, 4000);

    m_ptrAccessText.reset(new(std::nothrow) DLabel("N/A", pFrame));        
    m_ptrAccessText->setAlignment(AlignCenter);
    m_ptrAccessText->setGeometry(0, 7000, MAX_COORD, 1000);
    m_ptrAccessText->setBackgroundColor(Duke_Transparent_Color);
    m_ptrAccessText->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrAccessText->setTextColor(Default_Dialog_TextColor);

    duke_media_handle logInAccess;
    duke_media_get_access(getApplication()->username(), logInAccess);
    if(logInAccess == duke_media_handle_null)
    {
        m_ptrAccess->setHideProperty(true);
        m_ptrAccessText->setHideProperty(true);
    }
    else
    {
        m_ptrAccess->setMediaByHandle(logInAccess);
    }

    std::string strname;
    if(duke_media_get_name(m_ptrAccess->getMediaHandle(), strname) && !strname.empty())
    {
        m_ptrAccessText->setContent(strname);
    }
    else
    {
        m_ptrAccessText->setContent("N/A");                    
    }

    //register event handle
    m_ptrAccess->setFocusAttr(true);
    m_ptrAccess->registerEvent(DEvent::DnD_Release, true);
    m_ptrAccess->registerEvent(DEvent::Delete);
    m_ptrAccess->setEventRoutine(DEvent::Delete,
                                 this,
                                 static_cast<EventRoutine>(&DLogInDlg::onDelAccess));
    m_ptrAccess->registerEvent(DEvent::Activate);
    m_ptrAccess->setEventRoutine(DEvent::Activate,
                                 this,
                                 static_cast<EventRoutine>(&DLogInDlg::onActivate));
    m_ptrAccess->registerEvent(DEvent::Hover);
    m_ptrAccess->setEventRoutine(DEvent::Hover,
                                 this,
                                 static_cast<EventRoutine>(&DLogInDlg::onHover));
    m_ptrAccess->registerEvent(DEvent::PassingOut);
    m_ptrAccess->setEventRoutine(DEvent::PassingOut,
                                 this,
                                 static_cast<EventRoutine>(&DLogInDlg::onPassingOut));
}

//----------------event handle-------------------------
void DLogInDlg::onActivate(const DEvent &event)
{

}

void DLogInDlg::onHover(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
    {
        getApplication()->tip()->add(pSrcWidget, strTip, event.getCon());
    }
    else
    {
        getApplication()->tip()->add(pSrcWidget, pSrcWidget->strPath(), event.getCon());
    }
}

void DLogInDlg::onPassingOut(const DEvent &event)
{
    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DLogInDlg::onDnDRelease(const DEvent &event)
{    
    DApplication* pApp =  getApplication();
    if (pApp != NULL)
    {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    //get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget *>(pApp->top()->findChild(childPath[1]));

    DDialog* pDlg = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL != pDlg)
    {
        DPoint releasePos = event.getEventPosition();    
        DPoint adjustPos;
        DRect editorRect = geometry();

        adjustPos.setX(releasePos.x() * editorRect.width() / 10000 + editorRect.x());
        adjustPos.setY(releasePos.y() * editorRect.height() / 10000 + editorRect.y());

        DEvent& eventRef = const_cast<DEvent &>(event);
        eventRef.setEventPosition(adjustPos);
        assert(NULL != m_pMainWin);
        m_pMainWin->onDnDRelease(event); 

        return;
    }

    deletePopupMenu();
    if(pSrcWidget && pSrcWidget->getMedia() && pSrcWidget->getMedia()->is_access())
    {
        m_ptrAccess->setHideProperty(false);        
        m_ptrAccess->setMediaByHandle(pSrcWidget->getMediaHandle());
        duke_media_set_access(getApplication()->username(), pSrcWidget->getMediaHandle());
        LOG_DEBUG("Set "<<getApplication()->username()<<" Login access id = "<<pSrcWidget->getMediaHandle());

        m_ptrAccessText->setHideProperty(false);
        std::string strname;
        if(duke_media_get_name(m_ptrAccess->getMediaHandle(), strname) && !strname.empty())
        {
            m_ptrAccessText->setContent(strname);
        }
        else
        {
            m_ptrAccessText->setContent("N/A");                    
        }
    }
    else if (pSrcWidget && pSrcWidget->getMedia() && pSrcWidget->getMedia()->is_object_container_des())
    {
        /*
        duke_media_container *pCont = 
            dynamic_cast<duke_media_container *>(pSrcWidget->getMedia());

        duke_media_handle_vector anchors;
        pCont->get_anchor(anchors);

        if(anchors.empty())
            return;
        
        if(anchors.size() == 1)
        {
            duke_media_anchor anchorMedia(8,anchors[0]);
            duke_media_handle access;
            anchorMedia.create_access(access);
            duke_media_access accessMedia(access);
            std::string accessName;
            anchorMedia.get_name(accessName);
            accessMedia.set_name(accessName);
            m_ptrAccess->setHideProperty(false);
            m_ptrAccess->setMediaByHandle(access);
            duke_media_set_access(getApplication()->username(), access);
        }
        else
        {
            //hide the button
            m_ptrAccess->setHideProperty(true);
            
            //create menu to select anchor
            m_ptrPopupMenu.reset(new DPopupMenu(getViewFrame()));
            int menuHeight = (anchors.size() >= Popup_Anchor_Item_Size) ? 8000 
                : 8000 * anchors.size() / Popup_Anchor_Item_Size;
            m_ptrPopupMenu->setGeometry(2000, 
                                        (MAX_COORD - menuHeight) / 2, 
                                        5000, menuHeight);
            m_ptrPopupMenu->setFocusAttr(true);
            m_ptrPopupMenu->registerEvent(DEvent::Focus);
            m_ptrPopupMenu->registerEvent(DEvent::Blur);
            m_ptrPopupMenu->setEventRoutine(DEvent::Blur,
                                            this,
                                            static_cast<EventRoutine>(&DLogInDlg::onMenuBlur));

            for (duke_media_handle_size_type index = 0; index < anchors.size(); ++index)
            {
                std::string handleName;
                duke_media_get_name(anchors[index], handleName);
                m_ptrPopupMenu->insertItem(handleName, index, anchors[index]);
                m_ptrPopupMenu->connectItem(index, 
                                            this,         
                                            static_cast<EventRoutine>(&DLogInDlg::onSelAnchor));
            }
            m_ptrPopupMenu->updateMenu();                                        
        }
        */
    }
    updateAll();
    repaint(event.getCon());
}

void DLogInDlg::onDelAccess(const DEvent &event)
{
    m_ptrAccess->setMediaByHandle(duke_media_handle_null);
    m_ptrAccess->setHideProperty(true);
    m_ptrAccessText->setHideProperty(true);  
    duke_media_set_access(getApplication()->username(), duke_media_handle_null);
    updateAll();
    repaint(event.getCon());
}

void DLogInDlg::onClose(const DEvent& rEvent)
{
    DDialog::onMinimize(rEvent);
}

void DLogInDlg::onMenuBlur(const DEvent& event)
{
    deletePopupMenu();
    updateAll();
    repaint(event.getCon());
}

void DLogInDlg::onSelAnchor(const DEvent& event)
{
    //const std::vector<DPath>& eventPath = event.getEventPath();
    //DObject* pSelectObject = findChild(eventPath[0]);
    //DMenuItem* pSelectItem = dynamic_cast<DMenuItem* >(pSelectObject);
    //duke_media_handle anchor = pSelectItem->getMediaHandle();
    //if (anchor.is_anchor())
    //{
    //    duke_media_anchor  anchorMedia(anchor);
    //    duke_media_handle access;
    //    anchorMedia.create_access(getApplication()->username(), access, getApplication()->get_host_committer_id());
    //    duke_media_access accessMedia(access);
    //    std::string accessName;
    //    anchorMedia.get_name(accessName);
    //    accessMedia.set_name(accessName);
    //    m_ptrAccess->setHideProperty(false);
    //    m_ptrAccess->setMediaByHandle(access);
    //    duke_media_set_access(getApplication()->username(), access);
    //}
    //deletePopupMenu();
    //updateAll();
    //repaint(event.getCon());
}

void DLogInDlg::deletePopupMenu()
{
    if(m_ptrPopupMenu)
    {
        getViewFrame()->detachChildWidget(m_ptrPopupMenu.get());
        m_ptrPopupMenu.reset();
    }    
}

