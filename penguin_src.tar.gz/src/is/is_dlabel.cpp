/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#include "is_dlabel.h"

DLabel::DLabel(DWidget *parent, WFlags f)
    : DFrame(*new DLabelCell, parent, f)
{
    d_func()->init();
    setObjectName(Label_ObjName);
}

DLabel::DLabel(const std::string &text, DWidget *parent, WFlags f)
    : DFrame(*new DLabelCell, parent, f),
      m_text(text)
{
    d_func()->init();
    setObjectName(Label_ObjName);
}

DLabel::~DLabel()
{
}



/***************************************************************************
 * DLabelCell member functions
 **************************************************************************/
DLabelCell::DLabelCell()
{
}

DLabelCell::~DLabelCell()
{
}

void DLabelCell::init()
{
    DLabel *q = q_func();

    //init text
    TPlacement tp;
    TText text;
    TPath p(m_place->path);
    p.node.push_back(1);
    tp.path = p;
    tp.position.x = tp.position.y = MIN_COORD;
    tp.size.width = tp.size.height = MAX_COORD;
    tp.data = &text;
    subNodes.push_back(tp);
    (q->cnum())++;
    tp.data = NULL;
}

void DLabelCell::update()
{
    DFrameCell::update();
    //printf("DLabelCell::update \n");

    DLabel *q = q_func();

    TPlacement *place = &subNodes[1];
    place->path.node = m_place->path.node;
    place->path.node.push_back(1);
    place->order = q->displayOrder();
    TText *text = dynamic_cast<TText *>(place->data);
    assert(text != NULL);

    DText2TText(q->m_text, *text);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
