/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Haijian Li 
**
****************************************************************************/

#ifndef EVENTDISTRIBUTION_H
#define EVENTDISTRIBUTION_H

#include <map>
#include "is_deventloop.h"
#include "is_devent.h"
#include "is_dwidget.h"
#include "duc.h"

class DEventDistribution
{
public:
    DEventDistribution(is_response_call response_call, DWidget* pTopWidget)
        : m_pTopWidget(pTopWidget),
          m_response_call(response_call)          
    {
        assert(NULL != pTopWidget);
        init();
    }
    ~DEventDistribution()
    {
    }

    void distribute_event(const TGesture& rGesture);
    void execute_event(const DEvent& event);

    static TGestureType getGestureByEventType(DEvent::EventType eventType);

private:
    static void init();
   
    static void insertGesEventElement(TGestureType gestureType, DEvent::EventType eventType)
    {
        m_mGesEvent.insert(std::pair<TGestureType,DEvent::EventType>(gestureType, eventType));
    }

private:
    DWidget* m_pTopWidget;    
    is_response_call m_response_call;    
    static std::map<TGestureType, DEvent::EventType> m_mGesEvent;
};

typedef std::tr1::shared_ptr<DEventDistribution> DEventDistributionPtr;

#endif //EVENTDISTRIBUTION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
