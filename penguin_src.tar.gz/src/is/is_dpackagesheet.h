/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DPACKAGESHEET_H
#define DPACKAGESHEET_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dbutton.h"
#include "is_dlabel.h"
#include "is_dimagelabel.h"
#include "is_dmainwin.h"
#include "is_dpackageexplorer.h"

class DPackageSetting;
typedef std::tr1::shared_ptr<DPackageSetting>  DPackageSettingPtr;

typedef std::vector<DButtonPtr> PackageButtons;
typedef PackageButtons::iterator PackageButtonIt;
typedef PackageButtons::size_type PackageButtonIdx;

typedef std::vector<DLabelPtr> PackageNames;
typedef PackageNames::iterator PackageNameIt;
typedef PackageNames::size_type PackageNameIdx;

class DPackageSheet : public DWidget
{
public:
    explicit DPackageSheet(DMainWin * pMainWin = NULL, DWidget *parent = 0);
    virtual ~DPackageSheet();

    //init
    void initPackageSheet();
    void initPackageList();
    void calculatePackages();

    //event handle
    void onUpArrow(const DEvent & event);
    void onPassingInArrow(const DEvent & event);
    void onPassingOutArrow(const DEvent & event);
    void onDownArrow(const DEvent & event);
    void onCurPackage(const DEvent & event);
    void onClickPackage(const DEvent & event);
    void onHoverPackage(const DEvent & event);
    void onPassOutPackage(const DEvent & event);
    void onNewPackage(const DEvent & event);
    void onOpenPackage(const DEvent & event);
    void onAllPackage(const DEvent & event);
    void onAddPackage(const DEvent & event);
    void onDnDRelease(const DEvent & event);

    //Get & set package name for packagesetting dialog
    std::string packageName();
    void setPackageName(const std::string& name);

private:
    //mainwin
    DMainWin* m_pMainWin;
    
    //background image label
    DImageLabelPtr m_ptrBgLabel;

    //current package info
    DButtonPtr m_ptrCurPackage;
    DLabelPtr m_ptrName;
    std::string m_packageName;
    DPackageSettingPtr m_ptrPackageSetting;
    DButtonPtr m_ptrNewPackage;
    DButtonPtr m_ptrOpenPackage;

    //the separator line
    DImageLabelPtr m_ptrSeparatorLine;   

    //the packages which be used
    PackageButtons m_packages;
    PackageNames m_names;
    PackageButtonIdx m_beginPackagePos;

    //the up/add/down button
    DButtonPtr m_ptrUpArrow;
    DButtonPtr m_ptrAllPackage;
    DButtonPtr m_ptrAddPackage;
    DButtonPtr m_ptrDownArrow;

    //package explorer
    DPackageExplorerPtr m_ptrExplorer;
    
};

typedef std::tr1::shared_ptr<DPackageSheet>  DPackageSheetPtr;

const std::string PackageSheet_ObjName("Package_Sheet");

//Background Image
const std::string PackageSheet_BackgroundImage_Filename("toolwin_background.png");

//Package Image/Text
const std::string PackageSheet_Package_Filename("object_origin.png");
const std::string PackageSheet_PackageSel_Filename("object_selected.png");
const DColor Default_PackageSheet_TextColor(255, 255, 255);

//Package Button
const std::string PackageSheet_PackageButton_Filename("folder_close.png");
const std::string PackageSheet_PackageButtonSel_Filename("folder_open.png");

//Create new & open package button
const std::string PackageSheet_CreatePackage_Filename("warehouse_create_button.png");
const std::string PackageSheet_OpenPackage_Filename("warehouse_open_button.png");

//Separator line
const std::string PackageSheet_SeparatorLine_Filename("toolwin_separator_line.png");

//Up & down button
const std::string PackageSheet_DownButton_Filename("toolwin_down.png");
const std::string PackageSheet_DownButtonHover_Filename("toolwin_down_hover.png");
const std::string PackageSheet_DownButtonNone_Filename("toolwin_down_none.png");
const std::string PackageSheet_UpButton_Filename("toolwin_up.png");
const std::string PackageSheet_UpButtonHover_Filename("toolwin_up_hover.png");
const std::string PackageSheet_UpButtonNone_Filename("toolwin_up_none.png");

//All & add package button
const std::string PackageSheet_AllButton_Filename("toolwin_all_package.png");
const std::string PackageSheet_AllButtonHover_Filename("toolwin_all_package.png");
const std::string PackageSheet_AllButtonNone_Filename("toolwin_all_package.png");
const std::string PackageSheet_AddButton_Filename("toolwin_add_package.png");
const std::string PackageSheet_AddButtonHover_Filename("toolwin_add_package.png");
const std::string PackageSheet_AddButtonNone_Filename("toolwin_add_package.png");

const size_t PackageSheet_Package_Size = 7;

//Geometry
const int PackageSheet_Package_StartY = 2070;
const int PackageSheet_Package_X = 2917;
const int PackageSheet_Package_W = 4167;
const int PackageSheet_Package_H = 651;
const int PackageSheet_Package_Spacing = 120;

const int PackageSheet_Package_Button_X = 2917;     // 35/120*10000
const int PackageSheet_Package_Button_Y = 495;      // 38/768*10000
const int PackageSheet_Package_Button_W = 4167;     // 50/120*10000
const int PackageSheet_Package_Button_H = 651;      // 50/768*10000

const int PackageSheet_Name_Label_X = 1000;
const int PackageSheet_Name_Label_Y = 1200;
const int PackageSheet_Name_Label_W = 8000;
const int PackageSheet_Name_Label_H = 250; 

const int PackageSheet_NewPackage_Button_X = 1111;     // 35/120*10000
const int PackageSheet_NewPackage_Button_Y = 1550;     // 38/768*10000
const int PackageSheet_NewPackage_Button_W = 3333;     // 40/120*10000
const int PackageSheet_NewPackage_Button_H = 260;      // 20/768*10000

const int PackageSheet_OpenPackage_Button_X = 5555; 
const int PackageSheet_OpenPackage_Button_Y = 1550; 
const int PackageSheet_OpenPackage_Button_W = 3333; 
const int PackageSheet_OpenPackage_Button_H = 260;

const int PackageSheet_SeparatorLine_X = 834;
const int PackageSheet_SeparatorLine_Y = 1930;
const int PackageSheet_SeparatorLine_W = 8337;
const int PackageSheet_SeparatorLine_H = 70; 

const int PackageSheet_UpArrow_X = 1001;             
const int PackageSheet_AllPackage_X = 3029;           
const int PackageSheet_AddPackage_X = 5057;           
const int PackageSheet_DownArrow_X = 7085;
const int PackageSheet_Arrow_Y = 9622;                   
const int PackageSheet_Arrow_Width = 1917;               
const int PackageSheet_Arrow_Height = 286;               

#endif /* DPACKAGESHEET_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
