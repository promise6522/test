/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DAPPLICATION_H
#define DAPPLICATION_H

// C++ 98 header files
#include <memory>

// Boost header file
#include <boost/thread.hpp>
#include <boost/tr1/memory.hpp>
#include <boost/function.hpp>

// Duke header files
#include "ac_message_type.h"
#include "ac_req_num.h"

#include "nb_id.h"
#include "is_dwidget.h"
#include "is_deventloop.h"
#include "is_deventdistribution.h"
#include "is_dframe.h"
#include "is_dtooltip.h"
#include "is_dbutton.h"
#include "is_dmainwin.h"
#include "is_dtoolwin.h"

class bridge_impl_is;

class DApplication
{
public:
    DApplication(bridge_impl_is* impl_is, is_response_call response);
    ~DApplication();     
  
    std::string username() { return m_username; }
    std::string name() { return m_name; }
    void setName(std::string name) { m_name = name; }
    host_committer_id_t get_host_committer_id() { return m_hc_id; }    
    
    bool exec(const TGesture& gesture);
    bool exec(const DEvent& event);

    DWidget *top() const { return m_ptrTopWidget.get(); }
    DToolTip *tip() const { return m_ptrToolTip.get(); }
   
    void setDragCursor(DCursor::CursorShape cursorShape);

    void run_impl(DWidget* pWidget, duke_media_handle handle);
    
private:
    void request_host_committer_id();    
    bool validateUser(const std::string& username);
    void initScene();
    void initFrame();
    void update();
    void restoreInitScene();
    
private:
    std::string m_username;
    std::string m_name;
    host_committer_id_t m_hc_id;

    DWidgetPtr m_ptrTopWidget;
    DFramePtr m_ptrMainFrame;
    DFramePtr m_ptrToolFrame;
    DFramePtr m_ptrWholeFrame; 
    DFramePtr m_ptrDragFrame;

    DToolTipPtr m_ptrToolTip;
    DToolWinPtr m_ptrToolWin;
    DMainWinPtr m_ptrMainWin;

    bridge_impl_is* m_impl_is;    
    is_response_call m_response_call;    
    DEventDistributionPtr m_ptrEventDistribution;
};

typedef std::tr1::shared_ptr<DApplication> DApplicationPtr;

//Default Value for init scene
const std::string Default_TopWidget_ObjName("TopWidget");

const std::string Default_WholeFrame_ObjName("WholeFrame");

//const int Default_ToolFrame_Width = 439; //(60 /1366 * 10000)
const int Default_ToolFrame_Width = 578; // ((60+19)/1366*10000)

const std::string Default_MainFrame_ObjName("MainFrame");
const DFrame::Shape Default_MainFrame_Style = DFrame::Panel;
const DPenStroke Default_MainFrame_PenStroke(DPenStroke::None, 0);
const DColor Default_MainFrame_Color(85, 85, 85);

const std::string Default_ToolsFrame_ObjName("ToolsFrame");
const DFrame::Shape Default_ToolsFrame_Style = DFrame::Panel;
const DPenStroke Default_ToolsFrame_PenStroke(DPenStroke::None, 0);
const DColor Default_ToolsFrame_Color(85, 85, 85, 0);

#endif //DAPPLICATION_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
