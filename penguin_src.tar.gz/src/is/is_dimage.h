/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author     State    Date
** Qiaowei    Create
** Yinlii     Add      2010-03-19
****************************************************************************/

#ifndef DIMAGE_H
#define DIMAGE_H

// Boost header files
#include <boost/tr1/memory.hpp>

// C++ 98 header files
#include <string>
#include <iostream>
#include <fstream>
#include <string.h>

// Duke header files
#include "is_dmargins.h"

class DImage {
public:    
    enum Scale {
        Tile,
	Center,
	Stretch
    };

    enum Relation {
        KeepLarge,
	KeepSmall,
	Disrelated
    };

    DImage(); 
    DImage(const DImage &);
    ~DImage();

    unsigned char *imageData() const;
    void setImageData(const unsigned char *imageData, int imageSize);

    Scale xScale() const;
    void setXScale(Scale scale);
    Scale yScale() const;
    void setYScale(Scale scale);
    Relation relation() const;
    void setRelation(Relation relation);
    DMargin margin() const;
    void setMargin(const DMargin &margin);

    bool load(const std::string &fileName);
    bool save(const std::string &fileName) const;
    int size() const;
    inline DImage &operator=(const DImage &);

private:
    Relation m_relation;
    Scale m_xscale;
    Scale m_yscale;
    DMargin m_margin;
    //the image's data 
    unsigned char *m_imageData;
    //the size of image
    int m_byteNum;
};

typedef std::tr1::shared_ptr<DImage> DImagePtr;

//Constructs a default image.
inline DImage::DImage()    
    : m_relation(Disrelated),
      m_xscale(Stretch),
      m_yscale(Stretch),
      m_margin(0, 0, 0, 0),
      m_imageData(NULL),
      m_byteNum(0)
{ }

//Returns image data.
inline unsigned char * DImage::imageData() const
{ return m_imageData; }

//Sets image data.
inline void DImage::setImageData(const unsigned char *imageData, int imageSize) 
{
    if(imageData == NULL || imageSize <= 0)
        return;    
    
    if (m_imageData != NULL)
    {
		delete[] m_imageData;
		m_imageData = NULL;
    }
    m_byteNum = imageSize;    
    m_imageData = new unsigned char[m_byteNum + 1];
    memcpy(m_imageData, imageData, m_byteNum);
    m_imageData[m_byteNum] = '\0';
}

//Returns the size of the image
inline int DImage::size() const
{ return m_byteNum; }

inline DImage::Scale DImage::xScale() const
{ return m_xscale; }

inline void DImage::setXScale(DImage::Scale s)
{ m_xscale = s; }

inline DImage::Scale DImage::yScale() const
{ return m_yscale; }

inline void DImage::setYScale(DImage::Scale s)
{ m_yscale = s; }

inline DImage::Relation DImage::relation() const
{ return m_relation; }

inline void DImage::setRelation(DImage::Relation r)
{ m_relation = r; }

inline DMargin DImage::margin() const
{ return m_margin; }

inline void DImage::setMargin(const DMargin &margin)
{ m_margin = margin; }

inline DImage &DImage::operator=(const DImage &image)
{
    m_byteNum = image.m_byteNum;
    m_xscale = image.m_xscale;
    m_yscale = image.m_yscale;
    m_relation = image.m_relation;
    m_margin = image.m_margin;

    if (this != &image) {
	if ((image.m_imageData != NULL) && (m_byteNum > 0)) {
	    if (m_imageData != NULL) {
		delete[] m_imageData;
		m_imageData = NULL;
	    }

	    m_imageData = new unsigned char[m_byteNum + 1];
	    memcpy(m_imageData, image.m_imageData, m_byteNum + 1);
	}    
    }
    return *this;
}

#endif //DIMAGE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
