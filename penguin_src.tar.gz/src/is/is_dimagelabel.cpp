/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author LHJ
**
****************************************************************************/

// Duke header files
#include "is_dimagelabel.h"

DImageLabel::DImageLabel(DWidget *parent, WFlags f)
    : DFrame(*new DImageLabelCell, parent, f)
{
    d_func()->init();
    setObjectName(ImageLabel_ObjName);    
    registerEvent(DEvent::Enlarge);
    registerEvent(DEvent::Shrink);
}

DImageLabel::DImageLabel(const std::string &text, const DImage& rImage,
                         DWidget *parent, WFlags f)
    : DFrame(*new DImageLabelCell, parent, f),
      m_text(text)
{
    d_func()->init();
    setObjectName(ImageLabel_ObjName);
    setImage(rImage);
    registerEvent(DEvent::Enlarge);
    registerEvent(DEvent::Shrink);
}

DImageLabel::~DImageLabel()
{
}


/***************************************************************************
 * DImageLabelCell member functions
 **************************************************************************/
DImageLabelCell::DImageLabelCell()
{
}

DImageLabelCell::~DImageLabelCell()
{
}

void DImageLabelCell::init()
{
    DImageLabel *q = q_func();

    // init image 
    TPlacement imageTp;
    TImage image;
    TPath imagePath(m_place->path);
    imagePath.node.push_back(1);
    imageTp.path = imagePath;
    imageTp.position.x = imageTp.position.y = MIN_COORD;
    imageTp.size.width = imageTp.size.height = MAX_COORD;
    imageTp.data = &image;
    subNodes.push_back(imageTp);
    (q->cnum())++;
    imageTp.data = NULL;

    //init text
    TPlacement textTp;
    TText text;
    TPath textPath(m_place->path);
    textPath.node.push_back(2);
    textTp.path = textPath;
    textTp.position.x = textTp.position.y = MIN_COORD;
    textTp.size.width = textTp.size.height = MAX_COORD;
    textTp.data = &text;
    subNodes.push_back(textTp);
    (q->cnum())++;
    textTp.data = NULL;
}

void DImageLabelCell::update()
{
    DFrameCell::update();
    //printf("DImageLabelCell::update \n");

    DImageLabel *q = q_func();

    m_place->path.node = q->objectPath(); 
    
    // update text
    TPlacement *place = &subNodes[2];
    place->path.node = m_place->path.node;
    place->path.node.push_back(2);
    place->order = q->displayOrder();
    TText *text = dynamic_cast<TText *>(place->data);
    assert(text != NULL);

    DText2TText(q->m_text, *text);

    // update image 
    TPlacement *imagePlace = &subNodes[1];
    imagePlace->path.node = m_place->path.node;
    imagePlace->path.node.push_back(1);
    imagePlace->order = q->displayOrder();
    TImage *pTImage = dynamic_cast<TImage *>(imagePlace->data);
    assert(pTImage != NULL);    

    const DImage* pDImage = q_func()->image();
    if ((NULL == pTImage) || (NULL == pDImage)) {
        return;
    }

    DImage2TImage(*pDImage, *pTImage);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
