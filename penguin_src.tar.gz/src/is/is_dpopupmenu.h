/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DPOPUPMENU_H 
#define DPOPUPMENU_H 

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dframe.h"
#include "is_dbutton.h"
#include "is_dimage.h"
#include "is_dlabel.h"
////#include "media/duke_media_header.h"

typedef DLabel DMenuItem;
typedef DLabelPtr DMenuItemPtr;
typedef std::vector<DLabelPtr> MenuItems;
typedef std::vector<DLabelPtr>::iterator MenuItemIt;
typedef std::vector<DLabelPtr>::size_type MenuItemIdx;

class DPopupMenuCell;

class DPopupMenu : public DWidget {
public:
    DPopupMenu(DWidget *parent = 0, WFlags f = 0);
    virtual ~DPopupMenu();

    void initMenu();
    void updateMenu();

    MenuItemIdx insertItem(const std::string &text, MenuItemIdx idx, 
            const duke_media_handle &h = duke_media_handle_null);
    MenuItemIdx removeItem(MenuItemIdx idx);
    MenuItemIdx changeItem(MenuItemIdx idx, const std::string &text);

    DColor textColor() const;
    void setTextColor(const DColor& rColor);

    void onDefaultSelect(const DEvent& rEvent);

    MenuItemIdx connectItem(MenuItemIdx idx, DWidget* pWidget, EventRoutine callback);
    MenuItemIdx disconnectItem(MenuItemIdx idx);
   
    int getIndexByItem(DMenuItem* pItem);
    void setItemHandle(MenuItemIdx idx, const duke_media_handle &h);

    void calculateItems();
    void onGrabUpArrow(const DEvent& event);
    void onGrabDownArrow(const DEvent& event);
    void onPassingOutArrow(const DEvent& event);

private:
    // the vector for menu items
    MenuItems m_items;
    MenuItemIdx m_beginItemPos;

    // the up/down page button
    DButtonPtr m_ptrUpArrow;
    DButtonPtr m_ptrDownArrow;

    int m_itemHeight;
    DColor m_textColor;

    D_DECLARE_CELL(DPopupMenu)
};

inline DColor DPopupMenu::textColor() const
{ return m_textColor; }

inline void DPopupMenu::setTextColor(const DColor& rColor)
{ m_textColor = rColor; }


class DPopupMenuCell : public DWidgetCell {
public:
    DPopupMenuCell();
    virtual ~DPopupMenuCell();

    void init();
    void update();

private:
    D_DECLARE_PUBLIC(DPopupMenu)
};

const size_t PopupMenu_Item_Size = 10;

typedef std::tr1::shared_ptr<DPopupMenu> DPopupMenuPtr;
typedef std::tr1::shared_ptr<DPopupMenuCell> DPopupMenuCellPtr;

#endif // DPOPUPMENU_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
