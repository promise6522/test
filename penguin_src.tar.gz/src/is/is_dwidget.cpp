/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/
#include <iostream>
#include <sstream>
#include <sys/time.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
////#include "media/duke_media_header.h"
#include "is_dwidget.h"
#include "is_deventdistribution.h"
#include "is_dtool.h"
#include "is_dapplication.h"

DWidget::DWidget(DWidget * parent, WFlags f)
    : DObject(parent),
      m_geometryPos(0, 0),
      m_geometrySize(MAX_COORD, MAX_COORD),
      m_backgroundColor(255, 255, 255),
      m_highlightColor(255, 255, 255),
      m_cursor(DCursor::DefaultCursor),
      m_enlargeFactor(1000, 1000),
      m_shrinkFactor(1000, 1000),
      m_isHide(false),
      m_displayOrder(0),
      m_pApplication(NULL),
      d_ptr(new DWidgetCell),
      m_ptr(NULL),
      m_handle(duke_media_handle_null)
{
    m_wflags = f;
    d_ptr->q_ptr = this;
    d_ptr->init();
    if (NULL != parent) {
        setApplication(parent->getApplication());
    }
    initEventMap();
}

DWidget::DWidget(DWidgetCell &d, DWidget * parent, WFlags f)
    : DObject(parent),
      m_geometryPos(0, 0),
      m_geometrySize(MAX_COORD, MAX_COORD),
      m_backgroundColor(255, 255, 255),
      m_highlightColor(255, 255, 255),
      m_cursor(DCursor::DefaultCursor),
      m_enlargeFactor(1000, 1000),
      m_shrinkFactor(1000, 1000),
      m_isHide(false),
      m_displayOrder(0),
      m_pApplication(NULL),
      d_ptr(&d),
      m_ptr(NULL),
      m_handle(duke_media_handle_null)
{
    m_wflags = f;
    d_ptr->q_ptr = this;
    d_ptr->init();
    if (NULL != parent) {
        setApplication(parent->getApplication());
    }
    initEventMap();
}

DWidget::~DWidget()
{
    if (d_ptr)
        delete d_ptr;
    d_ptr = 0;

    releaseMedia();
}

void DWidget::releaseMedia()
{
    if (m_ptr)
        delete m_ptr;
    m_ptr = 0;
}

void DWidget::setMediaByType(duke_media_type t)
{
    if (m_ptr)
       releaseMedia();

    assert(getApplication() != NULL);
    std::string userName = getApplication()->username();

    // construct different duke media object
    switch(t)
    {
    case DUKE_MEDIA_TYPE_NULL:       
        break;
    case DUKE_MEDIA_TYPE_OBJECT_NONE:
        m_ptr = new duke_media_none(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_BOOL:
        m_ptr = new duke_media_bool(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_INT:
        m_ptr = new duke_media_int(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_FLOAT:
        m_ptr = new duke_media_float(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_STRING:
        m_ptr = new duke_media_string(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_BYTES:
        m_ptr = new duke_media_bytes(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_INTERVAL:
        m_ptr = new duke_media_interval(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_TIME:
        m_ptr = new duke_media_time(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_ARRAY:
        m_ptr = new duke_media_array(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_MAP:
        m_ptr = new duke_media_map(getApplication()->get_host_committer_id());
        break;
    case DUKE_MEDIA_TYPE_OBJECT_USER:
        m_ptr = new duke_media_object(getApplication()->get_host_committer_id(), userName);
        break;
////    case DUKE_MEDIA_TYPE_INTERFACE_BUILTIN:
////        assert(!"unsupport builtin interface.");
////        break;
    case DUKE_MEDIA_TYPE_INTERFACE_COMPOUND:
        m_ptr = new duke_media_compound_interface(getApplication()->get_host_committer_id(), userName);
        break;
    case DUKE_MEDIA_TYPE_INTERFACE_USER: 
        m_ptr = new duke_media_interface(DUKE_MEDIA_TYPE_INTERFACE_USER, userName);
        break;
    //case DUKE_MEDIA_TYPE_FUNCTION_INSTRUCTION:
    //    assert(!"unsupport function instruction.");
    //    break; 
    case DUKE_MEDIA_TYPE_FUNCTION_INSTRUCTION:
        m_ptr = new duke_media_declare(t);
        break;        
    case DUKE_MEDIA_TYPE_FUNCTION_DECLARE:
        m_ptr = new duke_media_compound_declare(getApplication()->get_host_committer_id(), userName);
        break;
    case DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT:
        m_ptr = new duke_media_implement(this->getApplication()->get_host_committer_id(), userName);
        break;

    case DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF:
        m_ptr = new duke_media_container(this->getApplication()->get_host_committer_id(), userName);
        break;
    case DUKE_MEDIA_TYPE_ACCESS:
        m_ptr = new duke_media_access(this->getApplication()->get_host_committer_id(), userName);
        break;

    case DUKE_MEDIA_TYPE_ANCHOR:
        m_ptr = new duke_media_anchor(this->getApplication()->get_host_committer_id(), userName);
        break;
    case DUKE_MEDIA_TYPE_STORAGE:
        m_ptr = new duke_media_storage(this->getApplication()->get_host_committer_id(), userName);
        break;

    case DUKE_MEDIA_TYPE_OBJECT_BRIDGE:
        //m_ptr = new duke_media_bridge(getApplication()->get_host_committer_id());
        assert(!"Error to create an empty bridge object");
        break;
    case DUKE_MEDIA_TYPE_INTERFACE_BRIDGE: 
        //m_ptr = new duke_media_bridge_interface(getApplication()->get_host_committer_id(), userName);
        assert(!"Error to create an empty bridge interface");
        break;
    default:
        assert("unkown duke media type.");
    }

    m_handle = m_ptr->get_handle();
}

void DWidget::setMediaByHandle(const duke_media_handle & h)
{
    if (m_ptr)
        releaseMedia();
    // construct different duke media object
    if (h.is_object_none()) {
        m_ptr = new duke_media_none(h);
    }
    else if (h.is_object_bool()) {
        m_ptr = new duke_media_bool(h);
    }
    else if (h.is_object_int()) {
        m_ptr = new duke_media_int(h);
    }
    else if (h.is_object_float()) {
        m_ptr = new duke_media_float(h);
    }
    else if (h.is_object_string()) {
        m_ptr = new duke_media_string(h);
    }
    else if (h.is_object_bytes()) {
        m_ptr = new duke_media_bytes(h);
    }
    else if (h.is_object_interval()) {
        m_ptr = new duke_media_interval(h);
    }
    else if (h.is_object_time()) {
        m_ptr = new duke_media_time(h);
    }
    else if (h.is_object_array()) {
        m_ptr = new duke_media_array(h);
    }
    else if (h.is_object_map()) {
        m_ptr = new duke_media_map(h);
    }
    else if (h.is_object_bridge()) {
        m_ptr = new duke_media_bridge(h);
    }
    else if (h.is_object_user()) {
        m_ptr = new duke_media_object(h);
    }
    else if(h.is_bridge_interface()) {
        m_ptr = new duke_media_bridge_interface(h);
    }
    else if (h.is_interface_compound()) {
        m_ptr = new duke_media_compound_interface(h);
    }
    else if (h.is_interface()) {
        m_ptr = new duke_media_interface(h);
    }

    // for declarations
    else if (h.is_declaration())
    {
        if (h.is_function_instruction()) {
            m_ptr = new duke_media_declare(h);
        }
        else if ( h.is_object_decl_compound()) {
            m_ptr = new duke_media_compound_declare(h);
        }
        else if (h.is_object_decl_expanded()) {
            m_ptr = new duke_media_declare_expanded(h);
        }
    }

    // for impl/condition/loop
    else if (h.is_implementation()) {
        if (h.is_object_exec_iterator())
            m_ptr = new duke_media_loop(h);
        else if (h.is_object_exec_condition())
            m_ptr = new duke_media_condition(h);
        else
            m_ptr = new duke_media_implement(h);
    }

    // for container_descriptor
    else if (h.is_object_container_des()) {
        m_ptr = new duke_media_container(h);
    }

    // for access (including root access)
    else if (h.is_access()) { 
        m_ptr = new duke_media_access(h);
    }

    else if (h.is_anchor()) {
        m_ptr = new duke_media_anchor(h);
    }
    else if (h.is_storage()) {
        m_ptr = new duke_media_storage(h);
    }

    //else if (h.is_execute()) {
    //    m_ptr = new duke_media_execute(h);
    //}

    m_handle = h;
}

void DWidget::setMediaHandle(const duke_media_handle & h)
{
    m_handle = h;

    if (m_ptr && m_ptr->get_handle() != h)
        setMediaByHandle(h);
}

void DWidget::setMediaHandleOnly(const duke_media_handle & h)
{    
    //if (m_ptr && m_ptr->get_handle() != h)
    //    setMediaByHandle(h);
    releaseMedia();

    m_handle = h;
}

void DWidget::setMediaValue(const std::string value)
{
    if (!m_ptr || !m_ptr->is_object_builtin())
        return;

    if (m_ptr->is_object_int()) {
        int ival;
        try {
            ival = boost::lexical_cast<int>(value);
        } catch (boost::bad_lexical_cast &) {
            return;
        }
        m_handle.set_value(ival);
    } else if (m_ptr->is_object_bool()) {
        if(boost::iequals("false", value)) {
            m_handle.set_value(false);
        }
        else {
            m_handle.set_value(true);
        }
    } else if (m_ptr->is_object_string()) {
        m_handle.set_value(value);
    } else if (m_ptr->is_object_float()) {
        float fval;
        try {
            std::string val = value;
            boost::trim(val);
            fval = boost::lexical_cast<float>(val);
        } catch (boost::bad_lexical_cast &) {
            return;
        }
        m_handle.set_value(fval);
    } else if (m_ptr->is_object_bytes()) {
        m_handle.set_value(value);
    } else if (m_ptr->is_object_time() || m_ptr->is_object_interval()) {
        duke_time_t inputTime;
        std::string::size_type flagIndex = value.find(":");
        if (std::string::npos == flagIndex)
        {
            inputTime.pico_second_cnt = 0; 
        }
        else
        {
            try {
                 inputTime.pico_second_cnt = boost::lexical_cast<uint64_t>(
                                          value.substr(flagIndex + 1, value.size() - flagIndex -1));
            }  catch (boost::bad_lexical_cast &) {
                  return;
            }
        }
        try {
            inputTime.second_cnt = boost::lexical_cast<uint64_t>(
                                      value.substr(0, flagIndex));
        } catch (boost::bad_lexical_cast &) {
                  return;
        }

        if (m_ptr->is_object_time())
        {
            duke_media_time* pTimeMedia = dynamic_cast<duke_media_time *>(m_ptr);
            if (NULL != pTimeMedia)
            {
                pTimeMedia->set_value(inputTime);
                m_handle = pTimeMedia->get_handle();
            }
        }
        else // is_object_interval
        {
            duke_media_interval* pIntervalMedia = dynamic_cast<duke_media_interval *>(m_ptr);
            if (NULL != pIntervalMedia)
            {
                pIntervalMedia->set_value(inputTime);
                m_handle = pIntervalMedia->get_handle(); 
            }
        }
    }
}

bool DWidget::getMediaValue(std::string &value)
{
    if (!m_ptr || !m_ptr->is_object_builtin())
        return false;

    if (m_ptr->is_object_int()) {
        int val;
        if (m_handle.get_value(val)) {
            try {
                 value = boost::lexical_cast<std::string>(val);
            } catch (boost::bad_lexical_cast &) {
                  return false;
            }
            return true;
        }
    } else if (m_ptr->is_object_bool()) {
        bool val;
        if (m_handle.get_value(val)) {
            value = val ? "true" : "false";
            return true;
        }
    } else if (m_ptr->is_object_string()) {
        std::string val;
        if (m_handle.get_value(val)) {
            value = val;
            return true;
        }
    } else if (m_ptr->is_object_float()) {
        float val;
        if (m_handle.get_value(val)) {
            try {
                value = boost::lexical_cast<std::string>(val);
            } catch (boost::bad_lexical_cast &) {
                  return false;
            }
            return true;
        }
    } else if (m_ptr->is_object_bytes()) {
        std::string val;
        if (m_handle.get_value(val)) {
            value = val;
            return true;
        }
    }else if (m_ptr->is_object_time() || m_ptr->is_object_interval()) {
        duke_time_t val;
        bool ret = false;
        if (m_ptr->is_object_time())
        {
            duke_media_time* pTimeMedia = dynamic_cast<duke_media_time *>(m_ptr);
            if (NULL != pTimeMedia)
            {
                pTimeMedia->get_value(val);
                ret = true;
            }
        }
        else // is_object_interval
        {
            duke_media_interval* pIntervalMedia = dynamic_cast<duke_media_interval *>(m_ptr);
            if (NULL != pIntervalMedia)
            {
                pIntervalMedia->get_value(val);
                ret = true;
            }
        }
        if (ret) {
            try {
               value = boost::lexical_cast<std::string>(val.second_cnt) + ":"
                    + boost::lexical_cast<std::string>(val.pico_second_cnt);
            } catch (boost::bad_lexical_cast &) {
                  return false;
            }

            return true;
        }
    }    
    return false;
}

void DWidget::move(int x, int y)
{
    m_geometryPos.setX(x);
    m_geometryPos.setY(y);
}

void DWidget::resize(int w, int h)
{
    m_geometrySize.setWidth(w);
    m_geometrySize.setHeight(h);
}

void DWidget::hide(const is_response_call& response_call)
{
    if (m_isHide)
	return;

    m_isHide = true;
    repaint(response_call);
}

void DWidget::display(const is_response_call& response_call)
{
    if (!m_isHide)
	return;

    m_isHide = false;
    repaint(response_call);
}

void DWidget::show(const is_response_call& response_call)
{
    d_ptr->addNode(response_call);
}

void DWidget::showXML()
{
    d_ptr->toXML();
}

void DWidget::updateAll()
{
    if (NULL == d_ptr) {
        LOG_DEBUG("null");
    }

    d_ptr->update();

    DObjectList *childObjects = children();
    if (childObjects != NULL) {
        for (DObjectListIt it = childObjects->begin(); it != childObjects->end(); it++) {
            DWidget * pWidget = dynamic_cast<DWidget *>(*it);
            assert(pWidget != NULL);
            pWidget->updateAll();
        }
    }
}

void DWidget::repaint(const is_response_call& response_call, bool hasData)
{
    if (hasData)
        d_ptr->changeNode(response_call);
    else
        d_ptr->changeNodePlace(response_call);
}

void DWidget::destory(const is_response_call& response_call)
{
    DWidget* pParentObj = dynamic_cast<DWidget *>(parent());
    if (NULL != pParentObj)
    {
        d_ptr->deleteNode(response_call);
        pParentObj->detachChildWidget(this);     
    }
}

bool DWidget::registerEvent(DEvent::EventType eventType, bool isPassThough)
{
    return d_ptr->registerEvent(eventType, isPassThough);
}

bool DWidget::unRegisterEvent(DEvent::EventType eventType)
{
    return d_ptr->unRegisterEvent(eventType);
}

void DWidget::setFocusAttr(bool isFocus)
{
    d_ptr->isFocusable = isFocus;
}

void DWidget::setEnlargeFactor(int widthFactor, int heightFactor)
{
    m_enlargeFactor.setWidth(widthFactor);
    m_enlargeFactor.setHeight(heightFactor);
}

void DWidget::setShrinkFactor(int widthFactor, int heightFactor)
{
    m_shrinkFactor.setWidth(widthFactor);
    m_shrinkFactor.setHeight(heightFactor);
}

void DWidget::detachChildWidget(DWidget* pWidget)
{
    assert(NULL != pWidget); 
    removeChild(pWidget);
    TPlacement* removePlacement = d_ptr->deleteChildNode(pWidget->getCell());
    delete removePlacement;
    removePlacement = NULL;
}

void DWidget::setParent(DWidget* pWidget)
{
    assert(NULL != pWidget);
    DWidget* pParentWidget = dynamic_cast<DWidget*>(parent());
    TPlacement* removePlacement = NULL;
    if (NULL != pParentWidget) {
        pParentWidget->removeChild(this);
        removePlacement = pParentWidget->getCell()->deleteChildNode(d_ptr);
    }

    pWidget->insertChild(this); 
    if (NULL != removePlacement) {
        pWidget->getCell()->insertChildNode(removePlacement);
        delete removePlacement;
        removePlacement = NULL;
    } else { 
        pWidget->getCell()->insertChildNode(d_ptr);
    }
}

DSize DWidget::enlargeFactor() const
{
    return m_enlargeFactor;
}

DSize DWidget::shrinkFactor() const
{
    return m_shrinkFactor;
}

void DWidget::initEventMap()
{
    insertEventElement(DEvent::PassingIn, this, &DWidget::processPassingInEvent);
    insertEventElement(DEvent::PassingOut, this, &DWidget::processPassingOutEvent);
    insertEventElement(DEvent::Hover, this, &DWidget::processHoverEvent);
    insertEventElement(DEvent::Focus, this, &DWidget::processFocusEvent);
    insertEventElement(DEvent::Blur, this, &DWidget::processBlurEvent);
    insertEventElement(DEvent::Select, this, &DWidget::processSelectEvent);
    insertEventElement(DEvent::Unselect, this, &DWidget::processUnselectEvent);
    insertEventElement(DEvent::Detail, this, &DWidget::processDetailEvent);
    insertEventElement(DEvent::Activate, this, &DWidget::processActivateEvent);
    insertEventElement(DEvent::Deactivate, this, &DWidget::processDeactivateEvent);
    insertEventElement(DEvent::DnD_Start, this, &DWidget::processDnDStartEvent);
    insertEventElement(DEvent::DnD_Release, this, &DWidget::processDnDReleaseEvent);
    insertEventElement(DEvent::Drag, this, &DWidget::processDragEvent);
    insertEventElement(DEvent::Grab, this, &DWidget::processGrabEvent);
    insertEventElement(DEvent::Release, this, &DWidget::processReleaseEvent);
    insertEventElement(DEvent::Moving, this, &DWidget::processMovingEvent);
    insertEventElement(DEvent::Input, this, &DWidget::processInputEvent);
    insertEventElement(DEvent::In, this, &DWidget::processInEvent);
    insertEventElement(DEvent::Out, this, &DWidget::processOutEvent);
    insertEventElement(DEvent::Enlarge, this, &DWidget::processEnlargeEvent);
    insertEventElement(DEvent::Shrink, this, &DWidget::processShrinkEvent);
    insertEventElement(DEvent::Resize_Start, this, &DWidget::processResizeStartEvent);
    insertEventElement(DEvent::Resize_Release, this, &DWidget::processResizeReleaseEvent);
    insertEventElement(DEvent::TG01, this, &DWidget::processTG01Event);
    insertEventElement(DEvent::TG02, this, &DWidget::processTG02Event);
    insertEventElement(DEvent::TG03, this, &DWidget::processTG03Event);
    insertEventElement(DEvent::TG04, this, &DWidget::processTG04Event);
    insertEventElement(DEvent::TG05, this, &DWidget::processTG05Event);
    insertEventElement(DEvent::TG06, this, &DWidget::processTG06Event);
    insertEventElement(DEvent::TG07, this, &DWidget::processTG07Event);
    insertEventElement(DEvent::TG08, this, &DWidget::processTG08Event);
    insertEventElement(DEvent::TG09, this, &DWidget::processTG09Event); 
}

void DWidget::setEventRoutine(DEvent::EventType eventType, 
	DWidget* pCallWidget, 
	EventRoutine eventRoutine)
{
    m_mEventRoutine[eventType] = widgetRoutinePair(pCallWidget, eventRoutine);
}

//add by lhj
bool DWidget::event(const DEvent& rEvent)
{
    DEvent::EventType eventType = rEvent.getEventType();

    std::map<DEvent::EventType, widgetRoutinePair>::iterator iter 
	= m_mEventRoutine.find(eventType);

    if (iter != m_mEventRoutine.end()) {
        widgetRoutinePair widRoutinePr = iter->second;

        DWidget* pWidget = widRoutinePr.first;

        EventRoutine eventRoutine = widRoutinePr.second;

        (pWidget->*eventRoutine)(rEvent);
    } else {
        return false;
    }
    
    return true;
}


void DWidget::processPassingInEvent(const DEvent& rEvent)
{
}

void DWidget::processPassingOutEvent(const DEvent& rEvent)
{
}

void DWidget::processHoverEvent(const DEvent& rEvent)
{
}

void DWidget::processFocusEvent(const DEvent& rEvent)
{
}

void DWidget::processBlurEvent(const DEvent& rEvent)
{
}

void DWidget::processSelectEvent(const DEvent& rEvent)
{
    LOG_DEBUG("select handler");
}

void DWidget::processUnselectEvent(const DEvent& rEvent)
{
}
 
void DWidget::processDetailEvent(const DEvent& rEvent)
{
}

void DWidget::processActivateEvent(const DEvent& rEvent)
{
}

void DWidget::processDeactivateEvent(const DEvent& rEvent)
{
}

void DWidget::processGrabEvent(const DEvent& rEvent)
{
    LOG_DEBUG("Grab event");
}

void DWidget::processDragEvent(const DEvent& rEvent)
{
    LOG_DEBUG("Drag event");
}


void DWidget::processDnDStartEvent(const DEvent& rEvent)
{
     LOG_DEBUG("DnD start event");
}

void DWidget::processDnDReleaseEvent(const DEvent& rEvent)
{
     LOG_DEBUG("DnD release event");
}

void DWidget::processReleaseEvent(const DEvent& rEvent)
{
     LOG_DEBUG("Release event");
}

void DWidget::processResizeStartEvent(const DEvent& rEvent)
{
     LOG_DEBUG("Resize Start event");
     m_resizePoint = rEvent.getEventPosition(); 
}

void DWidget::processResizeReleaseEvent(const DEvent& rEvent)
{
     LOG_DEBUG("Resize Release event");
     int widgetNewWidth = 0;
     int widgetNewHeight = 0;
     DPoint eventPosition = rEvent.getEventPosition();
     if (m_geometryPos.x() == m_resizePoint.x())
     {
          m_geometryPos.setX(eventPosition.x());
          widgetNewWidth = m_geometrySize.width() + m_resizePoint.x() - eventPosition.x();
     }
     else
     { 
          widgetNewWidth = m_geometrySize.width() - m_resizePoint.x() + eventPosition.x();
     }
     
     if (m_geometryPos.y() == m_resizePoint.y())
     {
          m_geometryPos.setY(eventPosition.y());
          widgetNewHeight = m_geometrySize.height() + m_resizePoint.y() - eventPosition.y();
     }
     else
     {
          widgetNewHeight = m_geometrySize.height() - m_resizePoint.y() + eventPosition.y();
     }
     
     m_geometrySize = DSize(widgetNewWidth, widgetNewHeight);
     if(m_geometrySize.width() <= 0)
     {
         m_geometrySize.setWidth(1);
     }
     
     if(m_geometrySize.height() <= 0)
     {
         m_geometrySize.setHeight(1);
     }

     repaint(rEvent.getCon());
}

void DWidget::processMovingEvent(const DEvent& rEvent)
{
    //comment this to avoid verbose logs        
    //LOG_DEBUG("moving event");
}

void DWidget::processInputEvent(const DEvent& rEvent)
{
}

void DWidget::processInEvent(const DEvent& rEvent)
{
}

void DWidget::processOutEvent(const DEvent& rEvent)
{
}

void DWidget::processEnlargeEvent(const DEvent& rEvent)
{
    /*
    std::cout<<"enlarge event"<<std::endl;
    if((m_geometryPos.x() + m_geometrySize.width() + m_enlargeFactor.width() >= 10000) || 
       (m_geometryPos.y() + m_geometrySize.height() + m_enlargeFactor.height() >= 10000))
        return;
    */

    m_geometrySize += m_enlargeFactor;
    repaint(rEvent.getCon());
}
 
void DWidget::processShrinkEvent(const DEvent& rEvent)
{
    LOG_DEBUG("shrink event");
    if ((m_geometrySize.width() - m_shrinkFactor.width() < 100) || 
        (m_geometrySize.height() - m_shrinkFactor.height() < 100))
        return;

    m_geometrySize -= m_shrinkFactor;
    repaint(rEvent.getCon());
}

void DWidget::processTG01Event(const DEvent& rEvent)
{
}

void DWidget::processTG02Event(const DEvent& rEvent)
{
}

void DWidget::processTG03Event(const DEvent& rEvent)
{
}

void DWidget::processTG04Event(const DEvent& rEvent)
{
}

void DWidget::processTG05Event(const DEvent& rEvent)
{
}

void DWidget::processTG06Event(const DEvent& rEvent)
{
}

void DWidget::processTG07Event(const DEvent& rEvent)
{
}

void DWidget::processTG08Event(const DEvent& rEvent)
{
}

void DWidget::processTG09Event(const DEvent& rEvent)
{
}

static void dumpRecursive(int level, DWidget *object)
{
    if (object) {
        std::string buf;
        buf.assign(level/2, '\t');
        if (level%2)
            buf += "    ";
        LOG_DEBUG(buf << object->strPath() <<
            "::" << object->objectName() <<" ("
                  <<object->displayOrder()<<")");

        //dump geomery
        DSize size = object->geometrySize();
        LOG_DEBUG(" ["<<object->geometryX()<<"-"<<object->geometryY()
                 <<"-"<<size.width()<<"-"<<size.height()<<"]");

        //dump hide/show
        if( object->isHide())
        {
            LOG_DEBUG(" H");
        }
        else
        {
            LOG_DEBUG(" S");
        }

        if (object->children()) {
            DObjectListIt it;
            for (it=object->children()->begin(); 
                    it!=object->children()->end(); 
                    it++) {
                DWidget *obj = (DWidget *)*it;
               if(!obj->isHide())
               {
                    dumpRecursive(level+1, obj);
               }                
            }
        }
    }
}

/*
 * Dumps a tree of children to the debug output.
 */
void DWidget::dumpObjectTree()
{
    dumpRecursive(0, this);
}

std::ostream& operator<<(std::ostream& os, const duke_media_handle& dukeMediaHandle)
{
    os<<dukeMediaHandle.str();
    return os;
}


/****************friend function*********************/
std::ostream& operator<<(std::ostream& os, const DWidget& rWidget)
{
    // pos
    os<<rWidget.m_geometryPos.x()<<"   "<<rWidget.m_geometryPos.y()<<"   ";
    // size
    os<<rWidget.m_geometrySize.width()<<"   "<<rWidget.m_geometrySize.height()<<"    ";

    //hide 
    os<<rWidget.m_isHide<<"   ";

    //display order
    os<<rWidget.m_displayOrder<<"   ";
    //hande
    os<<rWidget.m_handle<<std::endl;
    return os;
}


/***************************************************************************
 * DWidgetCell member functions
 **************************************************************************/
DWidgetCell::DWidgetCell()
    : q_ptr(0)
{
    m_place = new TPlacement();
    m_place->data = NULL;
    subNodes.reserve(512);
}

DWidgetCell::~DWidgetCell()
{
    // delete m_place ??
    q_ptr->d_ptr = NULL;
    m_place->data = NULL;
    m_place = NULL;
}

void DWidgetCell::init()
{
    m_place->path.node = q_ptr->objectPath();
    if (q_ptr->parent()) {
        DWidget *q = reinterpret_cast<DWidget *>(q_ptr->parent());
        q->d_ptr->subNodes.push_back(*m_place);
        int nu = q->d_ptr->subNodes.size();
        m_place = &(q->d_ptr->subNodes[nu-1]);
    }
    m_place->position.x = m_place->position.y = MIN_COORD;
    m_place->size.width = m_place->size.height = MAX_COORD;
    m_place->data = this; 
}

DRect DWidgetCell::gemoetry()
{
    return DRect();
}

void DWidgetCell::update()
{
    //printf("DWidgetCell::update \n");
    // TODO update path
    
    
    // m_place->path.node = q_func()->objectPath();    

    m_place->position.x = q_ptr->m_geometryPos.x();
    m_place->position.y = q_ptr->m_geometryPos.y();

    m_place->size.width = q_ptr->m_geometrySize.width();
    m_place->size.height = q_ptr->m_geometrySize.height();
    m_place->display = !q_ptr->m_isHide;
    m_place->order = q_ptr->m_displayOrder;
    DCursor2TCursor(q_ptr->cursor(), cursor);
}

void DWidgetCell::addNode(const is_response_call& response_call)
{
    update();

    Packer p;
    TResponse response(Response_Add, *m_place);
    p.pack(response);

    // send data to client for show
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

void DWidgetCell::changeNode(const is_response_call& response_call)
{
    update();

    Packer p;
    TResponse response(Response_Replace, *m_place);
    p.pack(response);

    // send data to client for show
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

void DWidgetCell::changeNodePlace(const is_response_call& response_call)
{
    update();

    Packer p;
    TResponse response(Response_Update, *m_place);
    p.pack(response);

    // send data to client for show
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

TPlacement* DWidgetCell::deleteChildNode(DWidgetCell* pWidgetCell)
{
     TPlacement* removePlacement = NULL;
     unsigned int subSize = subNodes.size(); 

     for (unsigned int oIndex = 0; oIndex < subSize; ++oIndex) {   

         if (subNodes[oIndex].data == pWidgetCell) {
             removePlacement = new TPlacement;
             pWidgetCell->setNewPlacement(removePlacement);
             removePlacement->data = pWidgetCell;
             removePlacement->size = subNodes[oIndex].size;
             
             for (unsigned int iIndex = oIndex; iIndex < subSize - 1; ++iIndex) {
                 subNodes[iIndex].data = subNodes[iIndex + 1].data;
                 DWidgetCell* pInnerWidgetCell = dynamic_cast<DWidgetCell*>(subNodes[iIndex].data);
                 if (NULL != pInnerWidgetCell) {
                     pInnerWidgetCell->setNewPlacement(&subNodes[iIndex]);
                 }
                 subNodes[iIndex].path = subNodes[iIndex + 1].path;
                 subNodes[iIndex].order = subNodes[iIndex + 1].order;
                 subNodes[iIndex].display = subNodes[iIndex + 1].display;
                 subNodes[iIndex].position = subNodes[iIndex + 1].position;
                 subNodes[iIndex].transformation = subNodes[iIndex + 1].transformation;
                 subNodes[iIndex].matchedCriterion = subNodes[iIndex + 1].matchedCriterion;
             }

             subNodes[subSize - 1].data = NULL;
             subNodes.erase(subNodes.begin() + (subSize - 1));

             break;
         }

     }

     return removePlacement;
}

void DWidgetCell::insertChildNode(DWidgetCell* pWidgetCell)
{
    if (NULL == pWidgetCell) {
        assert(false);
        return;
    }

    TPlacement childNode;
    TPath nodePath(m_place->path);
    nodePath.node.push_back(nodePath.node.size());
    childNode.path = nodePath;

    DRect rect = pWidgetCell->gemoetry();
    childNode.position.x = rect.x();
    childNode.position.y = rect.y();
    childNode.size.width = rect.width();
    childNode.size.height = rect.height();

    childNode.data = pWidgetCell;
    subNodes.push_back(childNode);
    childNode.data = NULL;
}

void DWidgetCell::insertChildNode(TPlacement* pPlacement)
{
    if (NULL == pPlacement) {
        assert(false);
        return;
    }

    TPlacement tp;
    TPath nodePath(m_place->path);
    nodePath.node.push_back(q_ptr->cnum() - 1);

    tp.path = nodePath;
    subNodes.push_back(tp);
    subNodes[subNodes.size() - 1].data = pPlacement->data;
    DWidgetCell* pWidgetCell = dynamic_cast<DWidgetCell*>(subNodes[subNodes.size() - 1].data);
    if (NULL != pWidgetCell) {
        pWidgetCell->setNewPlacement(&subNodes[subNodes.size() - 1]);
    }

    pPlacement->data = NULL;
}

void DWidgetCell::deleteNode(const is_response_call& response_call)
{
    update();

    Packer p;
    TResponse response(Response_Delete, *m_place);
    p.pack(response);

    // send data to client
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

bool DWidgetCell::registerEvent(DEvent::EventType eventType, bool isPassThrough)
{
    TBehavior addBehavior;
    addBehavior.gestureType = DEventDistribution::getGestureByEventType(eventType);
    addBehavior.informServer = true;
    addBehavior.passThrough = isPassThrough;

    std::vector<TBehavior>::iterator iter = behavior.begin();
    for (; iter != behavior.end(); ++iter) {
        if (iter->gestureType == addBehavior.gestureType)
        {
            iter->passThrough = isPassThrough;
            return false;
        }
    }

    behavior.push_back(addBehavior);
    return true;
}

bool DWidgetCell::unRegisterEvent(DEvent::EventType eventType)
{
    TGestureType gestureType = DEventDistribution::getGestureByEventType(eventType);

    std::vector<TBehavior>::iterator iter = behavior.begin();
    for (; iter != behavior.end(); ++iter) {
        if (iter->gestureType == gestureType) { 
            behavior.erase(iter);
            break;
        }
    }
    return true;
}

void DWidgetCell::toXML()
{
    update();

    XPacker p(&std::cout);
    TResponse response(Response_Add, *m_place);
    p.pack("widget", response);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
