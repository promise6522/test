#ifndef DSharedHOUSEDLG_H
#define DSharedHOUSEDLG_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"
#include "is_dlabel.h"
#include "is_dbutton.h"
#include "is_dlineedit.h"
#include "is_dimagelabel.h"

typedef std::vector<DButtonPtr> SharedhouseItems;
typedef SharedhouseItems::iterator SharedhouseItemsIt;
typedef SharedhouseItems::size_type SharedhouseItemsIdx;

typedef std::vector<DLabelPtr> SharedhouseTexts;
typedef SharedhouseTexts::iterator SharedhouseTextsIt;
typedef SharedhouseTexts::size_type SharedhouseTextsIdx;

typedef std::vector<DFramePtr> SharedhouseViewLayers;
typedef SharedhouseViewLayers::iterator SharedhouseViewLayersIt;
typedef SharedhouseViewLayers::size_type SharedhouseViewLayersIdx;


class DSharedhouseDlg : public DDialogEx
{
public:
    explicit DSharedhouseDlg(DMainWin * pMainWin = NULL, DWidget * parent = 0);
    explicit DSharedhouseDlg(const std::string& title,
                           DMainWin *pMainWin = NULL,
                           DWidget * parent = 0);
    virtual ~DSharedhouseDlg();

    //set & get methods
    int SharedhouseRowNum() const;
    int SharedhouseColoumnNum() const;
    int getCurPagePos() const;
    std::string getSearchKeyWord() const;

    //misc
    SharedhouseItemsIdx getButtonItemIdx(DWidget * pWidget);
    
    //Init    
    virtual void initDialog();    

    duke_media_handle getDukeHandle(int pos, std::string keyWord = "");
    int getDukeItemsSize(std::string keyWord = "");
    int readDukeItems();
    bool writeDukeItems();
    
protected:
    //Event handle
    void onDnDRelease(const DEvent& rEvent);
    void processEnlargeEvent(const DEvent& rEvent);
    void processShrinkEvent(const DEvent& rEvent);
    //void processSelectEvent(const DEvent& rEvent);
    //void processDetailEvent(const DEvent& rEvent);
    void processResizeReleaseEvent(const DEvent& rEvent);
    //void onHover(const DEvent &event);

    //Button select event handle
    void onSearch(const DEvent &event);
    void onBeginPage(const DEvent &event);
    void onPrePage(const DEvent &event);
    void onNextPage(const DEvent &event);
    void onEndPage(const DEvent &event);
    void onPassingInBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);
    void onHover(const DEvent &event);
    void onPassingOut(const DEvent &event);
    void onDeleteObject(const DEvent &event);
    //void onInputPage(const DEvent &event);
    void dialogRelease(const DEvent &event,DFrame* pFrame);

    //menu event handle
    virtual void onClose(const DEvent& rEvent);

    //init
    void initControlBar();
    void initSharedhouseView();

    void reloadCache(std::string keyWord = "");
    void cleanCache();

private:
    void fillItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateView();
    
protected:
    //the attribute of SharedhouseDlg
    int m_rowNum;
    int m_columnNum;
    int m_curPage;
    //int m_totalPage;
    std::string m_searchKey;

    //store handle
    duke_media_handle_vector m_dukeItems;

    //cache
    std::string m_cacheKeyString;
    std::vector<duke_media_handle_size_type> m_cacheHandleIdxes;
    int m_cacheItemsSize;

    //control bar, see the style below
    //
    //  < >   [_____]  [Search]
    //
    DLineEditPtr m_ptrSearchKeyWord;
    DImageLabelPtr m_ptrSearchEditBg;
    DButtonPtr m_ptrSearchButton;
    DButtonPtr m_ptrNextPage;
    DButtonPtr m_ptrPrePage;
    
    //Sharedhouse view, see the style below
    // ________________________
    // |  item   item   item   |
    // |  text   text   text   |
    // |-----------------------| (Sharedhouse frame)
    //
    DFramePtr m_ptrSharedhouseViewBg;
    SharedhouseViewLayers m_viewLayers;
    SharedhouseItems m_items;
    SharedhouseTexts m_texts;

    //page control bar, see the style below
    //     <<  <  [X]/88  >  >>
    //DFramePtr m_ptrPageBarBg;
};

typedef std::tr1::shared_ptr<DSharedhouseDlg>  DSharedhouseDlgPtr;
const std::string SharedhouseDlg_ObjName("Sharedhouse_Dialog");
const std::string SharedhouseDlg_Title_Name("Duke Shared Warehouse");

//default value for row & column
const int SharedhouseDlg_Default_RowNum = 4;
const int SharedhouseDlg_Default_ColumnNum = 5;

//the image for Sharedhouse dialog
const std::string SharedhouseItemImage_FileName("object_origin.png");
 
///////////////////////////////////////////////////////////////
//   Change this according to design (1366 * 768)
///////////////////////////////////////////////////////////////
const int Default_SharedhouseWidth_Pixel = 433;
const int Default_SharedhouseHeight_Pixel = 374;

const int Sharedhouse_PrePageX_Pixel = 5;
const int Sharedhouse_PrePageY_Pixel = 24;
const int Sharedhouse_PrePageW_Pixel = 39;
const int Sharedhouse_PrePageH_Pixel = 20;

const int Sharedhouse_NextPageX_Pixel = 45;
const int Sharedhouse_NextPageY_Pixel = 24;
const int Sharedhouse_NextPageW_Pixel = 39;
const int Sharedhouse_NextPageH_Pixel = 20;

/*const int Sharedhouse_CreateX_Pixel = 90;
const int Sharedhouse_CreateY_Pixel = 23;
const int Sharedhouse_CreateW_Pixel = 40;
const int Sharedhouse_CreateH_Pixel = 20;*/

const int Sharedhouse_SearchX_Pixel = 90;//133;
const int Sharedhouse_SearchY_Pixel = 26;
const int Sharedhouse_SearchW_Pixel = 332;
const int Sharedhouse_SearchH_Pixel = 15;

const int Sharedhouse_SearchEditX_Pixel = 143;
const int Sharedhouse_SearchEditW_Pixel = 282;

const int Sharedhouse_Layer_StartY_Pixel = 67;
const int Sharedhouse_TotalLayer_H_Pixel = 300;
const int Sharedhouse_Layer_H_Pixel = Sharedhouse_TotalLayer_H_Pixel / SharedhouseDlg_Default_RowNum;

const int Sharedhouse_Icon_StartX_Pixel = 20;
const int Sharedhouse_Icon_SpacingX_Pixel = 86;
const int Sharedhouse_Icon_StartY_Pixel = 71;
const int Sharedhouse_Icon_W_Pixel = 50;
const int Sharedhouse_Icon_H_Pixel = 50;

const int Sharedhouse_Text_StartX_Pixel = 7;
const int Sharedhouse_Text_SpacingX_Pixel = 86;
const int Sharedhouse_Text_StartY_Pixel = 125;
const int Sharedhouse_Text_W_Pixel = 77;
const int Sharedhouse_Text_H_Pixel = 14;

//auto-count pixel information for others
const int Sharedhouse_ViewW_Pixel = Default_SharedhouseWidth_Pixel;
const int Sharedhouse_ViewH_Pixel = Default_SharedhouseHeight_Pixel - Default_DlgTitleHeight_Pixel;

////////////////////////////////////////////////////////////////
//auto-count the related placement of Sharedhouse in mainwin
////////////////////////////////////////////////////////////////
const int SharedhouseX_InMainWin = 2000;
const int SharedhouseY_InMainWin = 2000;
const int SharedhouseW_InMainWin = Default_SharedhouseWidth_Pixel * MAX_COORD / 1366;
const int SharedhouseH_InMainWin = Default_SharedhouseHeight_Pixel * MAX_COORD / 768;

////////////////////////////////////////////////////////////////
//   auto-count related placement of widgets in Sharedhouse's view frame
///////////////////////////////////////////////////////////////
//previous page button
const int Sharedhouse_PrePageX_InView = Sharedhouse_PrePageX_Pixel*MAX_COORD/Sharedhouse_ViewW_Pixel;
const int Sharedhouse_PrePageY_InView = (Sharedhouse_PrePageY_Pixel - Default_DlgTitleHeight_Pixel)
                                      * MAX_COORD / Sharedhouse_ViewH_Pixel;
const int Sharedhouse_PrePageW_InView = Sharedhouse_PrePageW_Pixel*MAX_COORD/Sharedhouse_ViewW_Pixel;
const int Sharedhouse_PrePageH_InView = Sharedhouse_PrePageH_Pixel*MAX_COORD/Sharedhouse_ViewH_Pixel;
//next page button
const int Sharedhouse_NextPageX_InView = Sharedhouse_NextPageX_Pixel 
                                       * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_NextPageY_InView = (Sharedhouse_NextPageY_Pixel-Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Sharedhouse_ViewH_Pixel;
const int Sharedhouse_NextPageW_InView = Sharedhouse_NextPageW_Pixel * MAX_COORD 
                                       / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_NextPageH_InView = Sharedhouse_NextPageH_Pixel * MAX_COORD 
                                       / Sharedhouse_ViewH_Pixel;

//search line edit backgroud
const int Sharedhouse_SearchX_InView = Sharedhouse_SearchX_Pixel*MAX_COORD/Sharedhouse_ViewW_Pixel;
const int Sharedhouse_SearchY_InView = (Sharedhouse_SearchY_Pixel-Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Sharedhouse_ViewH_Pixel;
const int Sharedhouse_SearchW_InView = Sharedhouse_SearchW_Pixel * MAX_COORD 
                                       / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_SearchH_InView = Sharedhouse_SearchH_Pixel * MAX_COORD 
                                       / Sharedhouse_ViewH_Pixel;
//search line edit 
const int Sharedhouse_SearchEditX_InView = Sharedhouse_SearchEditX_Pixel
                                         * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_SearchEditW_InView = Sharedhouse_SearchEditW_Pixel * MAX_COORD 
                                         / Sharedhouse_ViewW_Pixel;
//layers in Sharedhouse
const int Sharedhouse_Layer_X_InView = MIN_COORD;
const int Sharedhouse_Layer_StartY_InView = (Sharedhouse_Layer_StartY_Pixel - Default_DlgTitleHeight_Pixel)
                                          * MAX_COORD / Sharedhouse_ViewH_Pixel;
const int Sharedhouse_Layer_W_InView = MAX_COORD;

const int Sharedhouse_TotalLayer_H_InView = Sharedhouse_TotalLayer_H_Pixel * MAX_COORD 
                                          / Sharedhouse_ViewH_Pixel;

const int Sharedhouse_Layer_H_InView = Sharedhouse_Layer_H_Pixel * MAX_COORD 
                                          / Sharedhouse_ViewH_Pixel;
//icon in layer
const int Sharedhouse_Icon_StartX_InLayer = Sharedhouse_Icon_StartX_Pixel
                                          * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_Icon_SpacingX_InLayer = Sharedhouse_Icon_SpacingX_Pixel
                                          * MAX_COORD / Sharedhouse_ViewW_Pixel;

const int Sharedhouse_Icon_Y_InLayer = (Sharedhouse_Icon_StartY_Pixel-Sharedhouse_Layer_StartY_Pixel)
                                          * MAX_COORD / Sharedhouse_Layer_H_Pixel;
const int Sharedhouse_Icon_W_InLayer = Sharedhouse_Icon_W_Pixel
                                    * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_Icon_H_InLayer = Sharedhouse_Icon_H_Pixel * MAX_COORD 
                                          / Sharedhouse_Layer_H_Pixel;

//text in layer
const int Sharedhouse_Text_StartX_InLayer = Sharedhouse_Text_StartX_Pixel
                                          * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_Text_SpacingX_InLayer = Sharedhouse_Text_SpacingX_Pixel
                                          * MAX_COORD / Sharedhouse_ViewW_Pixel;

const int Sharedhouse_Text_Y_InLayer = (Sharedhouse_Text_StartY_Pixel-Sharedhouse_Layer_StartY_Pixel)
                                          * MAX_COORD / Sharedhouse_Layer_H_Pixel;
const int Sharedhouse_Text_W_InLayer = Sharedhouse_Text_W_Pixel
                                    * MAX_COORD / Sharedhouse_ViewW_Pixel;
const int Sharedhouse_Text_H_InLayer = Sharedhouse_Text_H_Pixel * MAX_COORD 
                                          / Sharedhouse_Layer_H_Pixel;

#endif /* DWARWHOUSEDLG_H */
    
// vim:set tabstop=4 shiftwidth=4 expandtab:
