/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii
**
****************************************************************************/

#include "is_dapplication.h"
#include "is_dfunc.h"
#include "is_dobjicon.h"

DFunc::DFunc(const std::string &text, 
        const unsigned int inNum,
        const unsigned int outNum,
        DWidget *parent,
        WFlags f)
    : DWidget(*new DFuncCell, parent, f),
      m_text(text),
      m_body(MIN_COORD, FUNC_PORT_HEIGHT, MAX_COORD, MAX_COORD - 2 * FUNC_PORT_HEIGHT),
      m_ownerIf(NB_INTERFACE_NONE)
{
    d_func()->init();
    setObjectName(Func_ObjName);

    insertPorts(inNum, outNum);
    initFuncView();
}

DFunc::DFunc(const duke_media_handle &h,
        DWidget *parent,
        WFlags f)
    : DWidget(*new DFuncCell, parent, f),
      m_text(""),
      m_body(MIN_COORD, FUNC_PORT_HEIGHT, MAX_COORD, 5000),
      m_ownerIf(NB_INTERFACE_NONE)
{ 
    d_func()->init();

    setObjectName(Func_ObjName);
    setMediaByHandle(h);

    initFuncMedia();
    initFuncView();
}

DFunc::DFunc(const duke_media_handle &h,
        const duke_media_handle& hOwnerIf,
        DWidget *parent,
        WFlags f)
    : DWidget(*new DFuncCell, parent, f),
      m_text(""),
      m_body(MIN_COORD, FUNC_PORT_HEIGHT, MAX_COORD, 5000),
      m_ownerIf(hOwnerIf)
{ 
    d_func()->init();

    setObjectName(Func_ObjName);
    setMediaByHandle(h);

    initFuncMedia();
    initFuncView();
}

//caution: this construction funcion only for expanded_declration
DFunc::DFunc(const duke_media_handle &h,
        const duke_media_handle& hOwnerIf,
        const dukeid_vector& iport,
        const dukeid_vector& oport,
        DWidget *parent,
        WFlags f)
    : DWidget(*new DFuncCell, parent, f),
      m_text(""),
      m_body(MIN_COORD, FUNC_PORT_HEIGHT, MAX_COORD, 5000),
      m_ownerIf(hOwnerIf)
{
    d_func()->init();
    setObjectName(Func_ObjName);
    setMediaByHandle(h);

    if (!m_ptr) 
    {
        releaseMedia();
        return;
    }
    else
    {
        duke_media_declare_expanded* pExpand = dynamic_cast<duke_media_declare_expanded*>(m_ptr);
        if(NULL != pExpand)
        {
            int iport_num = iport.size() + 1;
            int oport_num = oport.size() + 1;
            insertPorts(iport_num, oport_num, -4);


            dukeid_vector iifs = iport;
            dukeid_vector oifs = oport;
            iifs.push_back(duke_media_handle(NB_INTERFACE_TIME_LINE));
            oifs.push_back(duke_media_handle(NB_INTERFACE_TIME_LINE));

            // Set input ports
            if (iport_num > 0) {
                for(int i = 0; i < iport_num; ++i) {
                    if (m_inPEs[i].first)
                        m_inPEs[i].first->setMediaByHandle(iifs[i]);
                }
            }
            // Set output ports
            if (oport_num > 0) {
                for(int i = 0; i < oport_num; ++i) {
                    if (m_outPEs[i].first)
                        m_outPEs[i].first->setMediaByHandle(oifs[i]);
                }
            }
        }
    }

    initFuncView();
}

DFunc::~DFunc()
{
}


// get owner port's edge
DEdgePtr DFunc::getEdgeFromFirstPort()
{
    return m_inPEs[0].second[0];
}


void DFunc::initFuncMedia()
{
    if (!m_ptr) 
    {
        releaseMedia();
        return;
    }
    else if(!m_ptr->is_declaration())
    {
        if(m_handle.is_implementation() && !m_handle.is_object_exec_iterator()
           && !m_handle.is_object_exec_condition())
        {
            duke_media_implement implMedia(m_handle);
            if(implMedia.general())
            {
                releaseMedia();
                return;
            }
        }
    }
    // interfaces for inport & outport
    duke_media_handle_vector iifs, oifs;


    // Special process for NB_FUNC_INTERFACE_CONVERT 
    if ( m_handle.is_function_instruction() &&
        m_handle.get_func_type() == NB_FUNC_INTERFACE_CONVERT)
    {
        iifs.push_back(NB_INTERFACE_INTERFACE);
        iifs.push_back(NB_INTERFACE_NONE);
        /// the converted interface
        oifs.push_back(m_ownerIf);
    }
    else
    {
        if (typeid(duke_media_declare) == typeid(*m_ptr))
        {
            duke_media_declare * pDecl = dynamic_cast<duke_media_declare *>(m_ptr);
            pDecl->get_interfaces(iifs, oifs);
        }
        else if (typeid(duke_media_declare_expanded) == typeid(*m_ptr))
        {
            duke_media_declare_expanded* pExpand = dynamic_cast<duke_media_declare_expanded*>(m_ptr);
            pExpand->get_interfaces(iifs, oifs);
        }
        else if (typeid(duke_media_compound_declare) == typeid(*m_ptr))
        {
            duke_media_compound_declare* pComp = dynamic_cast<duke_media_compound_declare*>(m_ptr);
            pComp->get_interfaces(iifs, oifs);
        }
        else if (typeid(duke_media_implement) == typeid(*m_ptr))
        {
            duke_media_implement* pImpl = dynamic_cast<duke_media_implement*>(m_ptr);
            pImpl->get_interfaces(iifs, oifs);
        }
        else if (typeid(duke_media_loop) == typeid(*m_ptr))
        {
            duke_media_loop* pLoop = dynamic_cast<duke_media_loop*>(m_ptr);
            pLoop->get_interfaces(iifs, oifs);
        }
        else if (typeid(duke_media_condition) == typeid(*m_ptr))
        {
            duke_media_condition* pCond = dynamic_cast<duke_media_condition*>(m_ptr);
            pCond->get_interfaces(iifs, oifs);
        }
        else
        {
            LOG_ERROR("DFunc::initFuncMedia() : unknown media type.");
            return;
        }
    }

    // for time line
    iifs.push_back(NB_INTERFACE_TIME_LINE);
    oifs.push_back(NB_INTERFACE_TIME_LINE);

    // set ports number
    insertPorts(iifs.size(), oifs.size(), -4);

    // set ports handle
    for(std::size_t i = 0; i < iifs.size(); ++i) 
    {
        if (m_inPEs[i].first)
            m_inPEs[i].first->setMediaByHandle(iifs[i]);
    }
    for(std::size_t i = 0; i < oifs.size(); ++i)
    {
        if (m_outPEs[i].first)
            m_outPEs[i].first->setMediaByHandle(oifs[i]);
    }

}


void DFunc::setMediaForInPort(InPEItemIdx idx, const duke_media_handle &hif)
{
    if (idx >= m_inPEs.size() || !hif.is_interface())
        return;
    m_inPEs[idx].first->setMediaByHandle(hif);
}

void DFunc::setMediaForOutPort(OutPEItemIdx idx, const duke_media_handle &hif)
{
    if (idx >= m_outPEs.size() || !hif.is_interface())
        return;
    m_outPEs[idx].first->setMediaByHandle(hif);
}

void DFunc::initFuncView()
{
    // Register events
    //registerEvent(DEvent::Drag, true);
    registerEvent(DEvent::Enlarge);
    setEventRoutine(DEvent::Enlarge,
            this,
            static_cast<EventRoutine>(&DFunc::onEnlargeFunc));
    registerEvent(DEvent::Shrink);
    setEventRoutine(DEvent::Shrink,
            this,
            static_cast<EventRoutine>(&DFunc::onShrinkFunc));
    registerEvent(DEvent::Moving);
    registerEvent(DEvent::Delete);
    setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DFunc::onFuncDestroy));
    registerEvent(DEvent::DnD_Release);
    setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DFunc::onDnDRelease));
  
    setFocusAttr(true);

    registerEvent(DEvent::Focus);
    setEventRoutine(DEvent::Focus,
                    this,
                    static_cast<EventRoutine>(&DFunc::onFocusFunc));
    
    registerEvent(DEvent::Blur);
    setEventRoutine(DEvent::Blur,
                    this,
                    static_cast<EventRoutine>(&DFunc::onBlurFunc));
 
   
    unsigned int num = (m_inPEs.size() >= m_outPEs.size()) ? 
            m_inPEs.size() : 
            m_outPEs.size();
 
    // set geometry of the function
    int totalWidth = (num+2+num*FUNC_PORT_BW_RATIO)*FUNC_PORT_WIDTH;
    setGeometry(geometryX(), geometryY(),
            (geometryX()+totalWidth) <= 9500 ? totalWidth : 9500 - geometryX(),
            geometry().height());
    setDisplayOrder(FUNC_DEFAULT_DISPLAY_ORDER);
    m_body.setRadius(5000);
    m_body.setRect(MIN_COORD, FUNC_PORT_HEIGHT,
            MAX_COORD, MAX_COORD-FUNC_PORT_HEIGHT*2);
    DColor bodyColor(FUNC_DEFAULT_BODY_COLOR);
    setBodyColor(bodyColor);

    updateFuncView();
}

void DFunc::updateFuncView()
{
    unsigned int num = (m_inPEs.size() >= m_outPEs.size()) ? 
            m_inPEs.size() : 
            m_outPEs.size();
 
    // set geometry of the function
    int totalWidth = (num+2+num*FUNC_PORT_BW_RATIO)*FUNC_PORT_WIDTH;
    int midx = geometryX() + geometrySize().width()/2;
    if (midx >= MAX_COORD/2)
        totalWidth = (midx + totalWidth/2 <= 9500) ? 
                totalWidth : (9500 - midx) * 2;
    else
        totalWidth = (midx - totalWidth/2 >= 250) ? 
                totalWidth : (midx - 250) * 2;
    setGeometry(midx - totalWidth/2, 
            geometryY(),
            totalWidth,
            geometry().height());

    // calculate the blank between two ports
    int portWidth = MAX_COORD / (num + 2 + (num+1)*FUNC_PORT_BW_RATIO);
    int inBlank = FUNC_PORT_BW_RATIO * portWidth;
    int outBlank = FUNC_PORT_BW_RATIO * portWidth;
    if (m_inPEs.size() != num)
        inBlank = (MAX_COORD-(m_inPEs.size()+2)*portWidth) / 
            (m_inPEs.size()+1);
    if (m_outPEs.size() != num)
        outBlank = (MAX_COORD-(m_outPEs.size()+2)*portWidth) /
            (m_outPEs.size()+1);

    // set gemoetry of input ports
    int count = 0;
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) {
        it->first->setGeometry((count+1)*(inBlank+portWidth), MIN_COORD,
                portWidth, FUNC_PORT_HEIGHT);
        it->first->setDisplayOrder(FUNC_PORT_DISPLAY_ORDER);
        count++;
    }

    // set gemoetry of output ports
    count = 0;
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        it->first->setGeometry((count+1)*(outBlank+portWidth),
                m_body.bottom(),
                portWidth, FUNC_PORT_HEIGHT);
        it->first->setDisplayOrder(FUNC_PORT_DISPLAY_ORDER);
        count++;
    }
}

DColor DFunc::bodyColor() const
{
    return m_body.getRectBackground();    
}

void DFunc::setBodyColor(const DColor &color)
{
    m_body.setRectBackground(color);
    m_body.setRectEdgeColor(color);

}
/*
void DFunc::insertTimePorts()
{
    DPortPtr ptrLPortItem(new(std::nothrow) DPort(this));
    ptrLPortItem.get()->setMediaByType(DUKE_MEDIA_TYPE_OBJECT_INT);
    assert(ptrLPortItem.get() != NULL);
    ptrLPortItem->setDirection(DPort::Left);
    ptrLPortItem->setBackgroundColor(DTime_color); 
    ptrLPortItem->setHighlightColor(DTime_color_high);
    ptrLPortItem->registerEvent(DEvent::Activate);
    ptrLPortItem->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DFunc::onCreateDlg));
    m_TimePEs.push_back(std::make_pair<DPortPtr, DEdgePtr>(ptrLPortItem, DEdgePtr()));

    DPortPtr ptrRPortItem(new(std::nothrow) DPort(this));
    ptrRPortItem.setMediaByType(DUKE_MEDIA_TYPE_OBJECT_INT);
    assert(ptrRPortItem.get() != NULL);
    ptrRPortItem->setDirection(DPort::Right);
    ptrRPortItem->setBackgroundColor(DTime_color); 
    ptrRPortItem->setHighlightColor(DTime_color_high);
    ptrRPortItem->registerEvent(DEvent::Activate);
    ptrRPortItem->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DFunc::onCreateDlg));
    m_TimePEs.push_back(std::make_pair<DPortPtr, DEdgePtr>(ptrRPortItem, DEdgePtr()));

}


void DFunc::onCreateDlg(const DEvent &rEvent)
{
    std::cout << "--------------DFunc::onCreateDlg" << std::endl;

    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if ((pSrcWidget == NULL) || (pSrcWidget->getMedia() == NULL))
        //|| pSrcWidget->getMedia()->is_object_bridge()
		//|| pSrcWidget->getMediaHandle().is_function_instruction())
        return;
    DEditor * pEditor = dynamic_cast<DWidget*>(pSrcWidget->parent())->parent().findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pInput && pEditor->isHide())
        {
            pSrcWidget->setMediaValue(pInput->getInputString());
            std::string value;
            pSrcWidget->getMediaValue(value);
            pInput->setInputString(value);            
            std::cout << value << std::endl;
            dynamic_cast<DObjIcon *>(pSrcWidget)->setTextContent(value);
            saveInternalNodeInfo();
            m_isModified = true;

            updateAll();
            repaint(event.getCon());
        }

        if(pEditor->isModified())
        {
            m_isModified = true;
        }
        if (pSrcWidget->getMedia()->is_object_array())
        {
            DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pSrcWidget);
            if (NULL != pObjIcon)
            {
                pObjIcon->reloadObjMedia();
                saveInternalNodeInfo();
                m_isModified = true;
            }
        }
        return;
    }

    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                     pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    // Create new IFEditor with BodyModel
    DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->initDialog();
    
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_InputEditor_W_InMainWin, 
            Default_InputEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    
    // Set initial value
    std::string value;
    if (pSrcWidget->getMediaValue(value))
        ptrEditor->setInputString(value);
    std::cout << value << std::endl;

    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());
    updateFuncView();
}
*/

bool DFunc::insertPorts(int inNum, int outNum, int color)
{
    for (int i = 0; i != inNum; ++i) {
        DPortPtr ptrPortItem(new(std::nothrow) DPort(this));
        assert(ptrPortItem.get() != NULL);

        if(i == inNum-1)
        {
            ptrPortItem->setDirection(DPort::Up);
            ptrPortItem->setBackgroundColor(DTime_color); 
            ptrPortItem->setHighlightColor(DTime_color_high);
        }
        else
        {
            ptrPortItem->setDirection(DPort::Up);
            ptrPortItem->setBackgroundColor(DFunc_in_color); 
            ptrPortItem->setHighlightColor(DFunc_in_color_high);
        }
        ptrPortItem->registerEvent(DEvent::PassingIn);
        ptrPortItem->setEventRoutine(DEvent::PassingIn,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingIn));
        ptrPortItem->registerEvent(DEvent::PassingOut);
        ptrPortItem->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingOut));
        ptrPortItem->registerEvent(DEvent::DnD_Release);
        ptrPortItem->setEventRoutine(DEvent::DnD_Release,
                this,
                static_cast<EventRoutine>(&DFunc::onInPortDnDRelease));

        //m_inPEs.push_back(std::make_pair<DPortPtr, DEdgePtr>(ptrPortItem, DEdgePtr()));
        m_inPEs.push_back(std::make_pair<DPortPtr, EItems>(ptrPortItem, EItems()));
    }

    for (int i = 0; i != outNum; ++i) {
        DPortPtr ptrPortItem(new(std::nothrow) DPort(this));
        assert(ptrPortItem.get() != NULL);

        if(i == outNum-1)
        {
            ptrPortItem->setDirection(DPort::Down);
            ptrPortItem->setBackgroundColor(DTime_color);
            ptrPortItem->setHighlightColor(DTime_color_high);
        }
        else
        {
            ptrPortItem->setDirection(DPort::Down);
            ptrPortItem->setBackgroundColor(DFunc_out_color);
            ptrPortItem->setHighlightColor(DFunc_out_color_high);
        }
        ptrPortItem->registerEvent(DEvent::Hover);
        ptrPortItem->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DFunc::onPortHover));
        ptrPortItem->registerEvent(DEvent::PassingIn);
        ptrPortItem->setEventRoutine(DEvent::PassingIn,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingIn));
        ptrPortItem->registerEvent(DEvent::PassingOut);
        ptrPortItem->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingOut));
        ptrPortItem->registerEvent(DEvent::DnD_Start);
        ptrPortItem->setEventRoutine(DEvent::DnD_Start,
                this,
                static_cast<EventRoutine>(&DFunc::onOutPortDnDStart));
        ptrPortItem->registerEvent(DEvent::DnD_Release);
        ptrPortItem->setEventRoutine(DEvent::DnD_Release,
                this,
                static_cast<EventRoutine>(&DFunc::onDnDRelease));

        m_outPEs.push_back(std::make_pair<DPortPtr, EItems>(ptrPortItem, EItems()));
    }
    return true;
}

void DFunc::insertPorts(int inNum, int outNum)
{
    for (int i = 0; i != inNum; ++i) {
        DPortPtr ptrPortItem(new(std::nothrow) DPort(this));
        assert(ptrPortItem.get() != NULL);

        ptrPortItem->setDirection(DPort::Up);
        ptrPortItem->setBackgroundColor(DFunc_in_color); 
        ptrPortItem->setHighlightColor(DFunc_in_color_high);
        ptrPortItem->registerEvent(DEvent::PassingIn);
        ptrPortItem->setEventRoutine(DEvent::PassingIn,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingIn));
        ptrPortItem->registerEvent(DEvent::PassingOut);
        ptrPortItem->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingOut));
        ptrPortItem->registerEvent(DEvent::DnD_Release);
        ptrPortItem->setEventRoutine(DEvent::DnD_Release,
                this,
                static_cast<EventRoutine>(&DFunc::onInPortDnDRelease));

        //m_inPEs.push_back(std::make_pair<DPortPtr, DEdgePtr>(ptrPortItem, DEdgePtr()));
        m_inPEs.push_back(std::make_pair<DPortPtr, EItems>(ptrPortItem, EItems()));
    }

    for (int i = 0; i != outNum; ++i) {
        DPortPtr ptrPortItem(new(std::nothrow) DPort(this));
        assert(ptrPortItem.get() != NULL);

        ptrPortItem->setDirection(DPort::Down);
        ptrPortItem->setBackgroundColor(DFunc_out_color);
        ptrPortItem->setHighlightColor(DFunc_out_color_high);
        ptrPortItem->registerEvent(DEvent::Hover);
        ptrPortItem->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DFunc::onPortHover));
        ptrPortItem->registerEvent(DEvent::PassingIn);
        ptrPortItem->setEventRoutine(DEvent::PassingIn,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingIn));
        ptrPortItem->registerEvent(DEvent::PassingOut);
        ptrPortItem->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DFunc::onPortPassingOut));
        ptrPortItem->registerEvent(DEvent::DnD_Start);
        ptrPortItem->setEventRoutine(DEvent::DnD_Start,
                this,
                static_cast<EventRoutine>(&DFunc::onOutPortDnDStart));
        ptrPortItem->registerEvent(DEvent::DnD_Release);
        ptrPortItem->setEventRoutine(DEvent::DnD_Release,
                this,
                static_cast<EventRoutine>(&DFunc::onDnDRelease));

        m_outPEs.push_back(std::make_pair<DPortPtr, EItems>(ptrPortItem, EItems()));
    }
    //insertTimePorts();
}

void DFunc::deleteInPort(InPEItemIdx idx)
{
    if (idx >= m_inPEs.size())
        return;

    InPEItemIt it = m_inPEs.begin() + idx;
    assert(it->first.get() != NULL); 

    for(EIt eIt=it->second.begin(); eIt!=it->second.end(); ++eIt)
    {
        if (eIt->get()) {
            DPort * pSrcPort = dynamic_cast<DPort *>((*eIt)->sourceWidget());
            assert (NULL != pSrcPort); 

            // if the source port belongs to function.
            if (dynamic_cast<DFunc *>(pSrcPort->parent())) {
                dynamic_cast<DFunc *>(pSrcPort->parent())->deleteEdgeFromOutPort(pSrcPort, eIt->get());
            } else if (dynamic_cast<DObjIcon *>(pSrcPort->parent())) {
                dynamic_cast<DObjIcon *>(pSrcPort->parent())->deleteOutEdge(eIt->get());
            } else
                return;
        }
    }

    detachChildWidget(it->first.get());
    m_inPEs.erase(it);
}

void DFunc::deleteOutPort(OutPEItemIdx idx)
{
    if (idx >= m_outPEs.size())
        return;

    OutPEItemIt it = m_outPEs.begin() + idx;
    assert(it->first.get() != NULL); 

    for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
        if (NULL == eIt->get())
            continue;

        // Delete the edge from input port
        if (NULL != eIt->get()->targetWidget()) {
            DPort * pTargetPort = dynamic_cast<DPort *>(eIt->get()->targetWidget()); 

            if (NULL != pTargetPort) {
                assert(dynamic_cast<DFunc *>(pTargetPort->parent()));
                dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, eIt->get());
            } else { 
                DObjIcon * pObj = dynamic_cast<DObjIcon *>(eIt->get()->targetWidget());
                if (NULL != pObj)
                    pObj->deleteInEdge();
            }
        }

        // Delete the edge from current output port
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        assert(NULL != pParent);
        pParent->detachChildWidget(eIt->get());
    }

    it->second.clear();

    detachChildWidget(it->first.get());
    m_outPEs.erase(it);
}

void DFunc::clearAllPorts()
{
    for (InPEItemIdx idx = 0; idx < m_inPEs.size(); idx++) {
        InPEItemIt it = m_inPEs.begin() + idx;
        assert(it->first.get() != NULL); 

        LOG_DEBUG("size = "<<it->second.size());
        
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (NULL == eIt->get())
                continue;

            DPort * pSrcPort = dynamic_cast<DPort *>(eIt->get()->sourceWidget());
            assert(NULL != pSrcPort);
            // if the source iport belongs to function.
            if (dynamic_cast<DFunc *>(pSrcPort->parent())) {
                dynamic_cast<DFunc *>(pSrcPort->parent())->deleteEdgeFromOutPort(pSrcPort, eIt->get());
                break;
            } else if (dynamic_cast<DObjIcon *>(pSrcPort->parent())) {
                dynamic_cast<DObjIcon *>(pSrcPort->parent())->deleteOutEdge(eIt->get());
                break;
            }
        }       

//        if (it->second) {
//            DPort * pSrcPort = dynamic_cast<DPort *>(it->second->sourceWidget());
//            assert (NULL != pSrcPort); 
//
//            // if the source port belongs to function.
//            if (dynamic_cast<DFunc *>(pSrcPort->parent())) {
//                dynamic_cast<DFunc *>(pSrcPort->parent())->deleteEdgeFromOutPort(pSrcPort, it->second.get());
//            } else if (dynamic_cast<DObjIcon *>(pSrcPort->parent())) {
//                dynamic_cast<DObjIcon *>(pSrcPort->parent())->deleteOutEdge(it->second.get());
//            }
//        }
//
        it->second.clear();
        detachChildWidget(it->first.get());
    }

    for (OutPEItemIdx idx = 0; idx < m_outPEs.size(); idx++) {
        OutPEItemIt it = m_outPEs.begin() + idx;
        assert(it->first.get() != NULL);

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (NULL == eIt->get())
                continue;

            DPort * pTargetPort = dynamic_cast<DPort *>(eIt->get()->targetWidget());

            if (NULL != pTargetPort) {
                assert(dynamic_cast<DFunc *>(pTargetPort->parent()));
                dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, eIt->get());
            } else { 
                DObjIcon * pObj = dynamic_cast<DObjIcon *>(eIt->get()->targetWidget());
                if (NULL != pObj)
                    pObj->deleteInEdge();
            }


            // Delete the edge from output port
            DWidget * pParent = dynamic_cast<DWidget *>(parent());
            assert(NULL != pParent);
            pParent->detachChildWidget(eIt->get());
        }

        it->second.clear();
        detachChildWidget(it->first.get());
    }

    m_inPEs.clear();
    m_outPEs.clear();    
}

int DFunc::getIndexByPort(DPort* pPort)
{
    for (InPEItemIdx idx = 0; idx < m_inPEs.size(); idx++) {
        InPEItemIt it = m_inPEs.begin() + idx;
        assert(it->first.get() != NULL); 

        if (it->first.get() == pPort)
            return idx;
    }

    for (OutPEItemIdx idx = 0; idx < m_outPEs.size(); idx++) {
        OutPEItemIt it = m_outPEs.begin() + idx;
        assert(it->first.get() != NULL); 

        if (it->first.get() == pPort)
            return idx;
    }

    return -1;
}

OutPEItems DFunc::getOutPorts()
{
    return m_outPEs; 
}

InPEItems DFunc::getInPorts()
{
    return m_inPEs; 
}

size_t DFunc::inPortsSize()
{
    return m_inPEs.size();
}

size_t DFunc::outPortsSize()
{
    return m_outPEs.size();
}

bool DFunc::checkInPortsLinked()
{
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); it++) {

        if (it->first->getMediaHandle().is_interface_time_line())
            continue;
    /*    if(m_inPEs.size()==0)
        {
            break;
        }*/
        if (it->first && (0 == it->second.size()))
            return false;
    }

    return true;
}

bool DFunc::deleteEdgeFromOutPort(DPort *pOutPort, DEdge *pEdge)
{
    if (NULL == pOutPort || NULL == pEdge)
        return false;

    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        if (it->first.get() != pOutPort)  
            continue;

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (pEdge != eIt->get())  
                continue;

            // Delete the edge from input port
            if (NULL != pEdge->targetWidget()) {
                // target is a func
                DPort * pTargetPort = dynamic_cast<DPort *>(pEdge->targetWidget()); 
                if (NULL != pTargetPort) 
                {
                    if (NULL != dynamic_cast<DFunc *>(pTargetPort->parent()))
                        dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, eIt->get());
                }

                // target is an obj
                if (NULL != dynamic_cast<DObjIcon *>(pEdge->targetWidget()))
                {
                    dynamic_cast<DObjIcon *>(pEdge->targetWidget())->deleteInEdge();
                }
            }

            // Delete the edge from current output port
            DWidget * pParent = dynamic_cast<DWidget *>(parent());
            assert(NULL != pParent);
            pParent->detachChildWidget(pEdge);
            it->second.erase((eIt));
            return true;
        }        
    }

    return false;
}

void DFunc::clearEdgesFromOutPort(DPort *pOutPort)
{
    if (NULL == pOutPort)
        return;

    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        if (it->first.get() != pOutPort)  
            continue;

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (NULL == eIt->get())  
                continue;

            // Delete the edge from input port
            if (NULL != eIt->get()->targetWidget()) {
                DPort * pTargetPort = dynamic_cast<DPort *>(eIt->get()->targetWidget()); 
                if (NULL != pTargetPort) {
                    if (NULL != dynamic_cast<DFunc *>(pTargetPort->parent()))
                        dynamic_cast<DFunc *>(pTargetPort->parent())->deleteEdgeFromInPort(pTargetPort, eIt->get());
                } else {
                    DObjIcon * pObj = dynamic_cast<DObjIcon *>(eIt->get()->targetWidget()); 
                    if (NULL != pObj)
                        pObj->deleteInEdge();
                }
            }

            // Delete the edge from current output port
            DWidget * pParent = dynamic_cast<DWidget *>(parent());
            assert(NULL != pParent);
            pParent->detachChildWidget(eIt->get());
        }        

        it->second.clear();
        break;
    }
}

bool DFunc::deleteEdgeFromInPort(DPort *pInPort, DEdge *pEdge)
{
    if (NULL == pInPort || NULL == pEdge)
        return false;

    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        if (it->first.get() != pInPort)  
            continue;

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if (pEdge != eIt->get())  
                continue;

            DImplEditor *pImpl = dynamic_cast<DImplEditor *>(this->parent()->parent()->parent());
            if (NULL != pImpl) 
            {
                pImpl->deal_path(*eIt, impl_path_minus, pInPort->getMediaHandle().is_interface_time_line());
            }
            else
                LOG_ERROR("DFunc::deleteEdgeFromInPort(): parent impl not found, maybe in RunEditor");

            it->second.erase(eIt);
            return true;
        }        
    }

    return false;
}

//bool DFunc::deleteEdgeFromInPort(DPort *pInPort)
//{
//    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) {
//        if (it->first.get() == pInPort && it->second) { 
//            it->second.reset();
//            return true;
//        }
//    }
//
//    return false;
//}

void DFunc::clearEdgesFromInPort(DPort* pInPort)
{
    if (NULL == pInPort)
        return;

    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) {
        if (it->first.get() != pInPort)  
            continue;

        for (unsigned i=0; i< it->second.size(); ++i) {
            if (NULL == it->second[i].get())  
                continue;

                DPort * pSourcePort = dynamic_cast<DPort*>(it->second[i].get()->sourceWidget());
                assert(NULL != pSourcePort); 

                // if the source port belongs to function.
                DFunc* pFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
                if (NULL != pFunc) {
                    pFunc->deleteEdgeFromOutPort(pSourcePort, it->second[i].get());
                } 

                // if the source port belongs to object.
                DObjIcon * pObj = dynamic_cast<DObjIcon *>(pSourcePort->parent());
                if (NULL != pObj) {
                    pObj->deleteOutEdge(it->second[i].get());
            }

        }        

        it->second.clear();
        break;
    }
}

void DFunc::clearAllEdges()
{
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        if (!it->second.size())
            continue;
        clearEdgesFromOutPort(it->first.get()); 
    }

    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) {

        if(NULL == it->first.get() || !it->second.size())
            continue;
        clearEdgesFromInPort(it->first.get());
    }
}

DEdgePtr DFunc::getSuspendEdge(DPort *pOutPort)
{
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        if (it->first.get() != pOutPort) 
            continue; 

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (NULL != eIt->get() && NULL == eIt->get()->targetWidget())  
                return (*eIt);
        }        
    }

    return DEdgePtr();
}

EItems DFunc::getEdgesFromOutPort(DPort *pOutPort)
{
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        if (it->first.get() == pOutPort) 
        return it->second; 
    }

    return EItems();
}

EItems DFunc::getEdgeFromInPort(DPort *pInPort)
{
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) {
        if (it->first.get() == pInPort)
            return it->second;
    }

    return EItems();
}

void DFunc::setEdgeToInPort(DEdgePtr ptrE, int idx)
{
    if (static_cast<unsigned int>(idx) < m_inPEs.size() && idx >= 0) 
    {
        InPEItemIt it = m_inPEs.begin() + idx;
        if (NULL != it->first.get() && NULL != ptrE.get()) 
        { 
            if(!it->first.get()->getMediaHandle().is_interface_time_line() && 0 == it->second.size())
            {
                ptrE->setColor(DColor(0, 0, 0));
                it->second.push_back(ptrE);
                ptrE->setTargetWidget(it->first.get());
            }
            else if(it->first.get()->getMediaHandle().is_interface_time_line())
            {
                ptrE->setColor(DColor(127, 0, 255));
                it->second.push_back(ptrE);
                ptrE->setTargetWidget(it->first.get());
            }
        }
    }
}

void DFunc::setEdgeToInPort(DEdgePtr ptrE, DPort * pInPort)
{
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        if (pInPort == it->first.get() && NULL != ptrE)
        {
            if(!it->first.get()->getMediaHandle().is_interface_time_line() &&  0 == it->second.size())
            {
                ptrE->setColor(DColor(0, 0, 0));
                it->second.push_back(ptrE);
                ptrE->setTargetWidget(it->first.get());
            }
            else if(it->first.get()->getMediaHandle().is_interface_time_line())
            {
                ptrE->setColor(DColor(127, 0, 255));
                it->second.push_back(ptrE);
                ptrE->setTargetWidget(it->first.get());
            }
            //if(it != --m_inPEs.end() && 0 == it->second.size() && NULL != ptrE.get())
            //{
            //    ptrE->setColor(DColor(0, 0, 0));
            //    it->second.push_back(ptrE);
            //    ptrE->setTargetWidget(it->first.get());
            //}
            //else if(m_inPEs.size() == 1 && !it->first.get()->getMediaHandle().is_interface_time_line() && 0 == it->second.size())
            //{
            //    ptrE->setColor(DColor(0, 0, 0));
            //    it->second.push_back(ptrE);
            //    ptrE->setTargetWidget(it->first.get());
            //}
            //else if(it == --m_inPEs.end() && NULL != ptrE.get())
            //{
            //    ptrE->setColor(DColor(127, 0, 255));
            //    it->second.push_back(ptrE);
            //    ptrE->setTargetWidget(it->first.get());
            //}
            break;
        }
    }
}

void DFunc::updateEdgesPos()
{
    DPoint eP;
    DRect funcRect = geometry();
    DRect portRect;

    // Set the source point for output edges
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        assert(it->first); 

        portRect = it->first->geometry();
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if (NULL != eIt->get()) {
                eP.setX(funcRect.x() + 
                        ((portRect.x()+portRect.width()/2)*funcRect.width()) / MAX_COORD);
                eP.setY(funcRect.y() +
                        ((portRect.y()+portRect.height()*7/8)*funcRect.height()) / MAX_COORD);
                eIt->get()->setSourceParentCoord(eP); 
            }
        }
    }

    // Set the target point for input edges
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        assert(it->first);

        portRect = it->first->geometry();
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if(NULL != eIt->get())
            {
                eP.setX(funcRect.x() + 
                        ((portRect.x()+portRect.width()/2)*funcRect.width()) / MAX_COORD);
                eP.setY(funcRect.y() + 
                        ((portRect.y()+portRect.height()/8)*funcRect.height()) / MAX_COORD);
                eIt->get()->setTargetParentCoord(eP); 
            }
        }
    }

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL != pParent)
        pParent->updateAll();
}

bool DFunc::checkPos(const DPoint& rPoint, int amendLength)
{
    // check the widget the source edge connect
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        assert(NULL != it->first.get());

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
            if ((NULL == eIt->get())) 
                continue;

            if (NULL == eIt->get()->targetWidget())
                continue;

            DFunc* pTargetFunc = dynamic_cast<DFunc *>(eIt->get()->targetWidget()->parent());
            if (NULL != pTargetFunc) {
                if (pTargetFunc->geometryY() <= rPoint.y() + amendLength)
                    return false;
            } 

            DObjIcon* pTargetObj = dynamic_cast<DObjIcon *>(eIt->get()->targetWidget());
            if (NULL != pTargetObj) {
                if (pTargetObj->geometryY() <= rPoint.y() + amendLength)
                    return false;
            } 
        }
    }

    // check the widget the target edge connect
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        assert(it->first.get());
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if (NULL != eIt->get()) 
            {
                if (NULL == eIt->get()->sourceWidget())
                    continue;

                DWidget* pParentWidget = dynamic_cast<DWidget *>(eIt->get()->sourceWidget()->parent());
                if (NULL != pParentWidget) 
                {
                    if (pParentWidget->geometryY() + amendLength >= rPoint.y())
                        return false;
                }
            }
        }
    }

    return true;
}


DEdgePtr DFunc::createEdge(DPort* pOutPort)
{
    if (NULL == pOutPort)
        return DEdgePtr();

    OutPEItemIt it = m_outPEs.begin();
    for (; it != m_outPEs.end(); ++it) {
        // If a edges has already linked to current port,exit.
        if (pOutPort == it->first.get())  
            break;
    }

    // Create a edge, if current port is not linked by any edge.
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return DEdgePtr();

    DEdgePtr currE(new(std::nothrow) DEdge(pParent));
    assert(currE);

    currE->registerEvent(DEvent::DnD_Start);
    it->second.push_back(currE);

    // Get the start point of the edge
    DRect funcRect = geometry();
    DRect portRect = pOutPort->geometry();
    int eX = funcRect.x() + 
        ((portRect.x() + portRect.width()/2) * funcRect.width())/10000;
    int eY = funcRect.y() + 
        ((portRect.y() + portRect.height()*7/8) * funcRect.height())/10000;
    DPoint eP(eX, eY);

    currE->initGeometry(eX, eY, 200, 200);
    currE->setSourceParentCoord(eP);
    currE->setSourceWidget(pOutPort);
    currE->setDisplayOrder(FUNC_EDGE_DISPLAY_ORDER);

    return currE;
}

void DFunc::connect(OutPEItemIdx outIdx, DFunc* pConnFunc, InPEItemIdx inIdx)
{
    if (outIdx >= m_outPEs.size() || inIdx >= pConnFunc->inPortsSize())
        return;

    if (NULL == pConnFunc)
        return;

    // create edge and set its source coordinate
    OutPEItemIt it = m_outPEs.begin() + outIdx;
    DEdgePtr currEdge = createEdge(it->first.get());
    if (!currEdge) 
        return; 

    // set target coordinate of current edge
    pConnFunc->setEdgeToInPort(currEdge, inIdx);
}

void DFunc::connect(DPort* pOutPort, DFunc* pConnFunc, InPEItemIdx inIdx)
{
    if (NULL == pOutPort 
        || NULL == pConnFunc
        || inIdx >= pConnFunc->inPortsSize())
        return;

    DFunc * pParentFunc = dynamic_cast<DFunc *>(pOutPort->parent());
    if (pParentFunc != this)
        return;

    // create edge and set its source coordinate
    DEdgePtr currEdge = createEdge(pOutPort);
    if (!currEdge) 
        return; 

    // set target coordinate of current edge
    pConnFunc->setEdgeToInPort(currEdge, inIdx);
}

void DFunc::connect(OutPEItemIdx outIdx, DPort* pInPort)
{
    if (outIdx >= m_outPEs.size() || NULL == pInPort)
        return;

    DFunc * pConnFunc = dynamic_cast<DFunc *>(pInPort->parent());
    if (NULL == pConnFunc)
        return;

    // create edge and set its source coordinate
    OutPEItemIt it = m_outPEs.begin() + outIdx;
    DEdgePtr currEdge = createEdge(it->first.get());
    if (!currEdge) 
        return; 

    // set target coordinate of current edge
    pConnFunc->setEdgeToInPort(currEdge, pInPort);
}

void DFunc::onEnlargeFunc(const DEvent &rEvent)
{
    // Not enlarge the height
    setEnlargeFactor(enlargeFactor().width(), geometrySize().height() / 4);
    DWidget::processEnlargeEvent(rEvent);

    // Update the position of all edges linking to function.
    updateEdgesPos();
    
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(pParent != NULL);
    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onShrinkFunc(const DEvent &rEvent)
{
    // Not shrink the height
    setShrinkFactor(shrinkFactor().width(), geometrySize().height() / 5);
    DWidget::processShrinkEvent(rEvent);
        
    // Update the position of all edges linking to function.
    updateEdgesPos();

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(pParent != NULL);
    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onPortPassingIn(const DEvent &rEvent)
{
    LOG_DEBUG("Port of Function Passing In.");

    const std::vector<DPath>& currPortPath = rEvent.getEventPath();
    DPort * ptrCurrPort = dynamic_cast<DPort *>(findChild(currPortPath[0]));

    // adjust background color
    DColor portColor = ptrCurrPort->backgroundColor();
    if (portColor == DFunc_in_color) {
        ptrCurrPort->setBackgroundColor(DFunc_in_color_high);
    } else if (portColor == DFunc_out_color) {
        ptrCurrPort->setBackgroundColor(DFunc_out_color_high);
    }
    //else if (portColor == DTime_color) {
    //    ptrCurrPort->setBackgroundColor(DTime_color_high);
    //}

    // adjust port size
    unsigned int portNum = (m_inPEs.size() >= m_outPEs.size()) ? 
            m_inPEs.size() : 
            m_outPEs.size();
    DRect rect = ptrCurrPort->geometry();
    int portWidth = MAX_COORD / (portNum + 2 + (portNum+1)*FUNC_PORT_BW_RATIO);
    if (rect.width() == portWidth) {
        rect.setLeft(rect.left() - portWidth/2);
        rect.setRight(rect.right() + portWidth/2);
        ptrCurrPort->setGeometry(rect);
    }

    updateAll();
    repaint(rEvent.getCon());
}

void DFunc::onPortPassingOut(const DEvent &rEvent)
{
    LOG_DEBUG("Port of Function Passing Out.");

    const std::vector<DPath>& currPortPath = rEvent.getEventPath();
    DPort * ptrCurrPort = dynamic_cast<DPort *>(findChild(currPortPath[0]));

    // adjust background color
    DColor portColor = ptrCurrPort->backgroundColor();
    if (portColor == DFunc_in_color_high) {
        ptrCurrPort->setBackgroundColor(DFunc_in_color);
    } else if (portColor == DFunc_out_color_high) {
        ptrCurrPort->setBackgroundColor(DFunc_out_color);
    } //else if (portColor == DTime_color) {
       // ptrCurrPort->setBackgroundColor(DTime_color_high);
    //} 


    // adjust port size
    unsigned int portNum = (m_inPEs.size() >= m_outPEs.size()) ? 
            m_inPEs.size() : 
            m_outPEs.size();
    DRect rect = ptrCurrPort->geometry();
    int portWidth = MAX_COORD / (portNum + 2 + (portNum+1)*FUNC_PORT_BW_RATIO);
    if (rect.width() != portWidth) {
        rect.setLeft(rect.left() + portWidth/2);
        rect.setRight(rect.right() - portWidth/2);
        ptrCurrPort->setGeometry(rect);
    }

    getApplication()->tip()->remove(rEvent.getCon());

    updateAll();
    repaint(rEvent.getCon());
}


void DFunc::onOutPortDnDStart(const DEvent &rEvent)
{
    LOG_DEBUG("-------------Port of Function DnD Start.");

    const std::vector<DPath>& currPortPath = rEvent.getEventPath();
    DPort * pSourcePort = dynamic_cast<DPort *>(findChild(currPortPath[0]));
    assert(pSourcePort != NULL);

    createEdge(pSourcePort);

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return;

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onDnDRelease(const DEvent &rEvent)
{
    LOG_DEBUG("-------------Function Released.");

    const std::vector<DPath>& eventPath = rEvent.getEventPath();
    DPort * pSourcePort = dynamic_cast<DPort *>(getApplication()->top()->findChild(eventPath[1]));
    if (NULL == pSourcePort || pSourcePort->getMediaHandle().is_interface_time_line())
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return;

    // Get the func including the source port
    DFunc * pSrcFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
    if (NULL != pSrcFunc) {
        DEdgePtr ptrCurrE = pSrcFunc->getSuspendEdge(pSourcePort);
        if (ptrCurrE) {
            pSrcFunc->deleteEdgeFromOutPort(pSourcePort, ptrCurrE.get());
            pParent->updateAll();
            pParent->repaint(rEvent.getCon());
            return;
        }
    }

    DObjIcon* pSrcObj = dynamic_cast<DObjIcon* >(pSourcePort->parent());
    if (NULL != pSrcObj) {
        // Get the edge from source port
        DEdgePtr ptrCurrE = pSrcObj->getSuspendEdge();
        if (ptrCurrE) {
            pSrcObj->deleteOutEdge(ptrCurrE.get());
            pParent->updateAll();
            pParent->repaint(rEvent.getCon());
            return;
        }
    }
}

void DFunc::onInPortDnDRelease(const DEvent &rEvent)
{
    LOG_DEBUG("Input Port of Function Released.");

    const std::vector<DPath>& eventPath = rEvent.getEventPath();
    DPort * pSourcePort = dynamic_cast<DPort *>(getApplication()->top()->findChild(eventPath[1]));
    DPort * pTargetPort = dynamic_cast<DPort *>(findChild(eventPath[0]));
    if (NULL == pTargetPort || NULL == pSourcePort) 
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return;

    if(NULL == pSourcePort->getMedia() || NULL == pTargetPort->getMedia())
        return;
    
    // Get the func including the source port
    DEdgePtr ptrE;
    if (dynamic_cast<DFunc *>(pSourcePort->parent()))
        ptrE = dynamic_cast<DFunc *>(pSourcePort->parent())->getSuspendEdge(pSourcePort);
    else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
        ptrE = dynamic_cast<DObjIcon *>(pSourcePort->parent())->getSuspendEdge();
    else
        return;

    InPEItemIt it = m_inPEs.begin();
    for (; it != m_inPEs.end(); ++it) {
        // If a edges has already linked to current port, exit.
        if (pTargetPort == it->first.get()) {
            duke_media_handle dtype;
            duke_media_handle stype;
                
            stype = pSourcePort->getMediaHandle(); 
            dtype = pTargetPort->getMediaHandle(); 
            if((!stype.is_interface_time_line()) && (!dtype.is_interface_time_line()))            
            {
                if (pSourcePort->getMedia()->is_object_array() || pSourcePort->getMedia()->is_storage())
                {
                    if (pSourcePort->getMedia()->get_handle().is_interface_compound() &&
                            pTargetPort->getMedia()->get_handle().is_interface_compound())
                    {
                        dynamic_cast<duke_media_compound_interface *>(pSourcePort->getMedia())->get_type(stype);
                        dynamic_cast<duke_media_compound_interface *>(pTargetPort->getMedia())->get_type(dtype);
                    }
                    if (pSourcePort->getMedia()->get_handle().is_object_array() &&
                            pTargetPort->getMedia()->get_handle().is_interface_compound())
                    {
                        dynamic_cast<duke_media_array *>(pSourcePort->getMedia())->get_type(stype);
                        dynamic_cast<duke_media_compound_interface *>(pTargetPort->getMedia())->get_type(dtype);
                    }
                    if (pSourcePort->getMedia()->get_handle().is_interface_compound() &&
                            pTargetPort->getMedia()->get_handle().is_object_array())
                    {
                        dynamic_cast<duke_media_array *>(pTargetPort->getMedia())->get_type(dtype);
                        dynamic_cast<duke_media_compound_interface *>(pSourcePort->getMedia())->get_type(stype);
                    }
                    if (pSourcePort->getMedia()->get_handle().is_object_array() &&
                            pTargetPort->getMedia()->get_handle().is_object_array())
                    {
                        dynamic_cast<duke_media_array *>(pSourcePort->getMedia())->get_type(stype);
                        dynamic_cast<duke_media_array *>(pTargetPort->getMedia())->get_type(dtype);
                    }

                    if ((pSourcePort->getMedia()->get_handle().is_object_array() &&
                                !(pTargetPort->getMedia()->get_handle().is_object_array() || pTargetPort->getMedia()->get_handle().is_interface_compound() || pTargetPort->getMedia()->get_handle().is_storage())) ||
                            (!(pSourcePort->getMedia()->get_handle().is_object_array() || pSourcePort->getMedia()->get_handle().is_interface_compound() || pSourcePort->getMedia()->get_handle().is_storage()) &&
                             pTargetPort->getMedia()->get_handle().is_object_array()))
                    {
                        if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                            dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                        else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                            dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                        pParent->updateAll();
                        pParent->repaint(rEvent.getCon());

                        return;
                    }
                }
                else
                {
                    if (pSourcePort->getMedia()->get_handle().is_interface_compound() &&
                            pTargetPort->getMedia()->get_handle().is_interface_compound())
                    {
                        stype = pSourcePort->getMedia()->get_handle();
                        dtype = pTargetPort->getMedia()->get_handle();                
                    }
                    if (pSourcePort->getMedia()->get_handle().is_object_array() &&
                            pTargetPort->getMedia()->get_handle().is_interface_compound())
                    {
                        dynamic_cast<duke_media_array *>(pSourcePort->getMedia())->get_type(stype);
                        dtype = pTargetPort->getMedia()->get_handle();
                    }
                    if (pSourcePort->getMedia()->get_handle().is_interface_compound() &&
                            pTargetPort->getMedia()->get_handle().is_object_array())
                    {
                        stype = pSourcePort->getMedia()->get_handle();
                        dynamic_cast<duke_media_array *>(pTargetPort->getMedia())->get_type(dtype);
                    }
                    if (pSourcePort->getMedia()->get_handle().is_object_array() &&
                            pTargetPort->getMedia()->get_handle().is_object_array())
                    {
                        dynamic_cast<duke_media_array *>(pSourcePort->getMedia())->get_type(stype);
                        dynamic_cast<duke_media_array *>(pTargetPort->getMedia())->get_type(dtype);
                    }

                    if ((pSourcePort->getMedia()->get_handle().is_object_array() &&
                                !(pTargetPort->getMedia()->get_handle().is_object_array() || pTargetPort->getMedia()->get_handle().is_interface_compound() || pTargetPort->getMedia()->get_handle().is_storage())) ||
                            (!(pSourcePort->getMedia()->get_handle().is_object_array() || pSourcePort->getMedia()->get_handle().is_interface_compound() || pSourcePort->getMedia()->get_handle().is_storage()) &&
                             pTargetPort->getMedia()->get_handle().is_object_array()))
                    {
                        if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                            dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                        else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                            dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                        pParent->updateAll();
                        pParent->repaint(rEvent.getCon());

                        return;
                    }
                }
            }

            duke_media_handle targetDecl = dynamic_cast<DFunc *>(pTargetPort->parent())->getMediaHandle();

            if ((getIndexByPort(pTargetPort) == 0) && !targetDecl.is_type_null() && !targetDecl.is_implementation())
            {
                if (!duke_media_judge_interface_include_decl(stype, targetDecl))
                {
                    if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                        dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                    else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                        dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                    pParent->updateAll();
                    pParent->repaint(rEvent.getCon());
                    return;
                }
            } // add by mike for judge if the interface'decls include the target's decl

            else if((!stype.is_interface_time_line() && dtype.is_interface_time_line()) 
                        || (stype.is_interface_time_line() && !dtype.is_interface_time_line()))
            {
                if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                    dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                    dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                pParent->updateAll();
                pParent->repaint(rEvent.getCon());
                return;
            }
            else if (!duke_media_interface_cover_interface(stype, dtype) )
            {
                if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                    dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                    dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                pParent->updateAll();
                pParent->repaint(rEvent.getCon());

                return;
            } 
            else if(!stype.is_interface_time_line() && !dtype.is_interface_time_line() && it->second.size())
            {
                if (dynamic_cast<DFunc *>(pSourcePort->parent()))
                    dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
                else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
                    dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

                pParent->updateAll();
                pParent->repaint(rEvent.getCon());

                return;
            } 

            break;
        }
    }

    // Check if a target port has been linked by the edge
    if (dynamic_cast<DPort *>(ptrE->targetWidget()))
        return;

    // Check the coordinate of the target port
    // The coordinate of the target port should >= that of 
    // the source port for ever 
    DRect targetFuncRect = geometry();
    DRect srcParentRect;
    int targetY = targetFuncRect.y() + 
        (pTargetPort->geometryY() * targetFuncRect.height())/10000;
    srcParentRect = dynamic_cast<DWidget *>(pSourcePort->parent())->geometry();
    int sourceY = srcParentRect.y() + (pSourcePort->geometryY() * srcParentRect.height())/10000;

    if (targetY <= sourceY) {
        if (dynamic_cast<DFunc *>(pSourcePort->parent()))
            dynamic_cast<DFunc *>(pSourcePort->parent())->deleteEdgeFromOutPort(pSourcePort, ptrE.get());
        else if (dynamic_cast<DObjIcon *>(pSourcePort->parent()))
            dynamic_cast<DObjIcon *>(pSourcePort->parent())->deleteOutEdge(ptrE.get());

        pParent->updateAll();
        pParent->repaint(rEvent.getCon());
        return;
    }

    // Set the target coordate
    DRect funcRect = geometry();
    DRect portRect = pTargetPort->geometry();
    int eX = funcRect.x() + 
        ((portRect.x() + portRect.width()/2) * funcRect.width())/10000;
    int eY = funcRect.y() + 
        ((portRect.y() + portRect.height()/8) * funcRect.height())/10000;
    DPoint eP(eX, eY);
    ptrE->setTargetParentCoord(eP);
    ptrE->setTargetWidget(pTargetPort);
    //if(it == --m_inPEs.end() && it->first.get()->getMediaHandle().is_interface_time_line())
    if(it->first.get()->getMediaHandle().is_interface_time_line())
    {
        ptrE->setColor(DColor(127, 0, 255));
        it->second.push_back(ptrE);
    }
    else
    {
        ptrE->setColor(DColor(0, 0, 0));
        it->second.push_back(ptrE);
    }        

    DImplEditor *pImpl = dynamic_cast<DImplEditor *>(pParent->parent()->parent());
    if (NULL != pImpl) {
        //pImpl->saveInternalNodeInfo();
        pImpl->deal_path(ptrE, impl_path_plus, pTargetPort->getMediaHandle().is_interface_time_line());
        pImpl->switchByImplType();        
        pImpl->mainWin()->synchronizeEditors(rEvent.getCon(), pImpl);
        pImpl->updateAll();
        pImpl->repaint(rEvent.getCon());
        return;        
    }

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onFuncDestroy(const DEvent &rEvent)
{
    LOG_DEBUG("------DFunc::onFuncDestroy");

    const std::vector<DPath>& currFuncPath = rEvent.getEventPath();
    DFunc *pCurrFunc = dynamic_cast<DFunc *>(findChild(currFuncPath[0]));
    if (NULL == pCurrFunc)
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(pCurrFunc->parent());
    if (NULL == pParent)
        return;

    // Destroy the memory for current function.
    pCurrFunc->clearAllEdges();
    pParent->detachChildWidget(pCurrFunc);

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onPortHover(const DEvent &rEvent)
{
    LOG_DEBUG("-------------onPortHover");

    const std::vector<DPath>& currPortPath = rEvent.getEventPath();
    DPort * pPort = dynamic_cast<DPort *>(findChild(currPortPath[0]));
    assert(pPort != NULL);

    if (!pPort->getMedia())
        return;

    // TODO
    std::string strTip;
    if (pPort->getMedia()->is_object_builtin() &&
        pPort->getMediaValue(strTip))
        getApplication()->tip()->add(pPort,
            strTip,
            rEvent.getCon());
}

void DFunc::onFocusFunc(const DEvent &rEvent)
{
    LOG_DEBUG("----------DFunc::onFocusFunc");
    
    // output port edge
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        assert(NULL != it->first.get());

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
             (*eIt)->setColor(DColor(255, 0, 0));
            } 
    }

    // inport edge 
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if ((NULL != it->first.get()) && (NULL != eIt->get())) 
            {
                (*eIt)->setColor(DColor(255, 0, 0));
            }
        }
     }
     
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return;

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DFunc::onBlurFunc(const DEvent &rEvent)
{
    LOG_DEBUG("-------------onBlurFunc");
    
    // output port edge
    for (OutPEItemIt it = m_outPEs.begin(); it != m_outPEs.end(); ++it) {
        assert(NULL != it->first.get());

        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if(it->first.get()->getMediaHandle().is_interface_time_line())
            {
                (*eIt)->setColor(DColor(127, 0, 255));
            }
            else
            {
                (*eIt)->setColor(DColor(0, 0, 0));
            }
        } 
    }

    // inport edge 
    for (InPEItemIt it = m_inPEs.begin(); it != m_inPEs.end(); ++it) 
    {
        assert(NULL != it->first.get());
        for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) 
        {
            if(it->first.get()->getMediaHandle().is_interface_time_line())
            {
                (*eIt)->setColor(DColor(127, 0, 255));
            }
            else
            {
                (*eIt)->setColor(DColor(0, 0, 0));
            }
        }
     }
    
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL == pParent)
        return;

    pParent->updateAll();
    pParent->repaint(rEvent.getCon());

}

DFuncCell::DFuncCell()
{
    isFocusable = true;
}

DFuncCell::~DFuncCell()
{
}

void DFuncCell::init()
{
    DFunc *q = q_func();

    // Init rect 
    TPlacement rp;
    TRectangle body;
    TPath rPath(m_place->path);
    rPath.node.push_back(0);
    rp.path = rPath;
    rp.position.x = MIN_COORD;
    rp.position.y = FUNC_PORT_HEIGHT;
    rp.size.width = MAX_COORD;
    rp.size.height = 5000;
    body.roundRadius = q->m_body.getRadius();
    //DColor2TColor(q->backgroundColor(), body.background);
    DColor2TColor(q->bodyColor(), body.background);
    rp.data = &body;
    subNodes.push_back(rp);
    (q->cnum())++;
    rp.data = NULL;

    //init text
    TPlacement tp;
    TText text;
    TPath tPath(m_place->path);
    tPath.node.push_back(1);
    tp.path = tPath;
    tp.position.x = 5000;
    tp.position.y = 3000;
    tp.size.width = tp.size.height = 1000;
    tp.data = &text;
    subNodes.push_back(tp);
    (q->cnum())++;
    tp.data = NULL;
}

void DFuncCell::update()
{
    DWidgetCell::update();

    DFunc *q = q_func();

    m_place->path.node = q->objectPath();

    TPlacement &rp = subNodes[0];
    rp.path.node = m_place->path.node;
    rp.path.node.push_back(0); 
    rp.position.x = q->m_body.left();
    rp.position.y = q->m_body.top();
    rp.size.width = q->m_body.width();
    rp.size.height = q->m_body.height();
    rp.order = q->displayOrder();
    rp.display = true;

    TRectangle *pBody = reinterpret_cast<TRectangle *>(rp.data);
    assert(pBody != NULL);
    pBody->roundRadius = q->m_body.getRadius();
    DColor2TColor(q->m_body.getRectBackground(), pBody->background);    
    DColor2TColor(q->m_body.getRectEdgeColor(), pBody->edgeColor);    

    // update text
    TPlacement &tp = subNodes[1];
    tp.path.node = m_place->path.node;
    tp.path.node.push_back(1); 
    tp.order = q->displayOrder();
    TText *text = reinterpret_cast<TText *>(tp.data);
    assert(text != NULL);
    text->text = q->m_text;
    text->font.size = q->font().size();
    text->font.style = q->font().style();
    DText2TText(q->m_text, *text);

    m_place->referencePointDerivation.clear(); 
    m_place->relativeValueDerivation.clear();
    
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
