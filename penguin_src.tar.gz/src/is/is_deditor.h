/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DEDITOR_H
#define DEDITOR_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"
#include "is_dlineedit.h"
#include "is_dimagelabel.h"

class DEditor;
typedef std::tr1::shared_ptr<DEditor>   DEditorPtr;

typedef std::vector<DEditorPtr> SubEditors;
typedef SubEditors::iterator SubEditorIt;
typedef SubEditors::size_type SubEditorIdx;

//Relationship between Buttons in toolwin and DWidget in mainwin
typedef std::map<DWidget*, DEditor*> DWidgetEditorMap;
typedef DWidgetEditorMap::iterator DWidgetEditorMapIt;
typedef std::pair<DWidget*, DEditor*> DWidgetEditorPair;

////////////////////////////////////////////////////////////////
//     Extend DDialogEx for Editor
///////////////////////////////////////////////////////////////
class DEditor : public DDialogEx
{
    friend class boost::serialization::access;
public:
    enum EditorModel
    {
        TitleModel = 0x01,
        HeaderModel = 0x02,
        BodyModel = 0x04,
        TailModel = 0x08,

        //for convenient
        DialogModel = TitleModel | HeaderModel | BodyModel | TailModel,
        PanelModel = HeaderModel | BodyModel,
    };

    //ctor & dtor
    explicit DEditor(int model = DialogModel, DMainWin * pMainWin = NULL,
                     DWidget * parent = 0, WFlags f = 0);
    explicit DEditor(const std::string& title, int model = DialogModel,
                     DMainWin *pMainWin = NULL, DWidget * parent = 0, WFlags f = 0);
    virtual ~DEditor();

    //Init
    virtual void initDialog();
    
    //set & get methods
    int headHeight() const;
    void setHeadHeight(int height);
    int tailHeight() const;
    void setTailHeight(int height);
    int editorModel() const;
    void setEditorModel(int model);   

    //translate Gemoetry in MainWin
    //pWidget: related widget
    //pos: point in current paint Cell
    //return: point in Mainwin background Cell
    DPoint translatePosToMainWin(DWidget *pWidget, DPoint pos);
    //translate Gemoetry in Editor 
    DPoint translatePosToEditor(DWidget *pWidget, DPoint pos);

    //update placement
    virtual void adjustPlacement();

    //generate
    virtual duke_media_handle generate();
    virtual void generateSubItems();
    DEditor * createSubEditor(DWidget *); 

    //reload
    virtual void reload();
    
    //update subWidget
    void updateSubEditors();
    void repaintSubEditors(const is_response_call& response_call, bool hasData = true);
    void hideAllSubEditors(const is_response_call& response_call);
    void destorySubEditors(const is_response_call& response_call);
    void clearSubEditors();
    void setSubEditorsOrder(int order);
    SubEditors * subEditors();

    //set readonly
    virtual void setReadonly();

    //is modified?
    bool isModified();
    void setModified(bool modified);

    //save
    void saveName();
    void saveIcon();
    
    //get frames
    DFrame * getHeadFrame();
    DFrame * getBodyFrame();    
    DFrame * getTailFrame();
    DFrame * getSelFrame();
    
    //for expanded button
    void adjustIconForExpand(DButton* pButton);
    
protected:
    void updateEditorFrame(); 
    void initHeadFrame();
    void initBodyFrame();
    void initTailFrame();
    void initSelFrame();

    //event handle
    virtual void processEnlargeEvent(const DEvent& rEvent);
    virtual void processShrinkEvent(const DEvent& rEvent);
    //virtual void processSelectEvent(const DEvent& rEvent);
    virtual void processDetailEvent(const DEvent& rEvent);
    virtual void processResizeReleaseEvent(const DEvent& rEvent);

    virtual void onInputMsg(const DEvent &event);
    virtual void onReleaseIcon(const DEvent &event);
    virtual void onGenerate(const DEvent &event);
    virtual void onHoverGen(const DEvent &event);
    virtual void onPassingOutGen(const DEvent &event);

    //menu message handle
    virtual void onMaximize(const DEvent& rEvent);
    virtual void onMinimize(const DEvent& rEvent);
    virtual void onRestore(const DEvent& rEvent);
    virtual void onClose(const DEvent& rEvent);

    //manage the subEditors
    void insertSubEditor(DWidget *pWidget, DEditorPtr subEditor);
    DWidget * findWidgetBySubEditor(DEditor * pEditor);
    DEditor * findSubEditorByWidget(DWidget * pWidget);
    void eraseSubEditor(DWidget *pWidget);
    void eraseSubEditor(DEditor *pEditor);
    void hideSubEditor(DWidget *pWidget);
    void hideSubEditor(DEditor *pEditor);

protected:
    DFramePtr m_ptrHeadFrame;
    DFramePtr m_ptrBodyFrame;
    DFramePtr m_ptrTailFrame;
    DFramePtr m_ptrSelFrame;

    std::string m_dukeName;
    std::string m_dukeIcon;

    //Sub editors
    SubEditors m_subEditors;
    DWidgetEditorMap m_widgetEditorMap;

    //members
    int m_editorModel;
    int m_headHeight;
    int m_tailHeight;

    //is modified?
    bool m_isModified;

    //is readonly
    bool m_isReadOnly;
    
    //headframe's elements
    DImageLabelPtr m_ptrDukeName;
    DLineEditPtr m_ptrNameEdit;
    DImageLabelPtr m_ptrDukeIcon;
    //DLineEditPtr m_ptrIconEdit;
    
    //tailframe's elements
    DButtonPtr m_ptrGeneration;

    //generate error info
    std::string m_generateErrorInfo;
};

const std::string Editor_Title_Name("Editor");
const std::string Editor_ObjName("Editor_Object");

//sel frame
const DColor Default_SelFrame_Color(255, 255, 255);
const int Default_Editor_W_Pixel = 336;
const int Default_Editor_H_Pixel = 424;

//--------------------------head frame---------------------------------
const std::string Editor_NameImg_FileName("editor_name.png");
const std::string Editor_IconImg_FileName("editor_icon.png");

//UI design
const int Editor_HeadFrame_W_Pixel = Default_Editor_W_Pixel;
const int Editor_HeadFrame_H_Pixel = 24;

const int Editor_Name_X_Pixel = 12;
const int Editor_Name_Y_Pixel = 0;
const int Editor_Name_W_Pixel = 151;
const int Editor_Name_H_Pixel = Editor_HeadFrame_H_Pixel;

const int Editor_NameEdit_X_Pixel = 56;
const int Editor_NameEdit_Y_Pixel = 7;
const int Editor_NameEdit_W_Pixel = 105;
const int Editor_NameEdit_H_Pixel = 14;

const int Editor_Icon_X_Pixel = 170;
const int Editor_Icon_Y_Pixel = 0;
const int Editor_Icon_W_Pixel = 154;
const int Editor_Icon_H_Pixel = Editor_HeadFrame_H_Pixel;

const int Editor_IconEdit_X_Pixel = 205;
const int Editor_IconEdit_Y_Pixel = 7;
const int Editor_IconEdit_W_Pixel = 117;
const int Editor_IconEdit_H_Pixel = 14;

//auto-count the related placement
const int Editor_HeadFrame_H_InMainWin = Editor_HeadFrame_H_Pixel * MAX_COORD / 768;

const int Editor_Name_X_InHead = Editor_Name_X_Pixel * MAX_COORD / Editor_HeadFrame_W_Pixel;
const int Editor_Name_Y_InHead = Editor_Name_Y_Pixel * MAX_COORD / Editor_HeadFrame_H_Pixel;
const int Editor_Name_W_InHead = Editor_Name_W_Pixel * MAX_COORD / Editor_HeadFrame_W_Pixel;
const int Editor_Name_H_InHead = Editor_Name_H_Pixel * MAX_COORD / Editor_HeadFrame_H_Pixel;

const int Editor_NameEdit_X_InHead = Editor_NameEdit_X_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_W_Pixel;
const int Editor_NameEdit_Y_InHead = Editor_NameEdit_Y_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_H_Pixel;
const int Editor_NameEdit_W_InHead = Editor_NameEdit_W_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_W_Pixel;
const int Editor_NameEdit_H_InHead = Editor_NameEdit_H_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_H_Pixel;

const int Editor_Icon_X_InHead = Editor_Icon_X_Pixel * MAX_COORD / Editor_HeadFrame_W_Pixel;
const int Editor_Icon_Y_InHead = Editor_Icon_Y_Pixel * MAX_COORD / Editor_HeadFrame_H_Pixel;
const int Editor_Icon_W_InHead = Editor_Icon_W_Pixel * MAX_COORD / Editor_HeadFrame_W_Pixel;
const int Editor_Icon_H_InHead = Editor_Icon_H_Pixel * MAX_COORD / Editor_HeadFrame_H_Pixel;

const int Editor_IconEdit_X_InHead = Editor_IconEdit_X_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_W_Pixel;
const int Editor_IconEdit_Y_InHead = Editor_IconEdit_Y_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_H_Pixel;
const int Editor_IconEdit_W_InHead = Editor_IconEdit_W_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_W_Pixel;
const int Editor_IconEdit_H_InHead = Editor_IconEdit_H_Pixel * MAX_COORD 
                                     / Editor_HeadFrame_H_Pixel;

//tail frame
const int Editor_TailFrame_W_Pixel = Default_Editor_W_Pixel;
const int Editor_TailFrame_H_Pixel = 24;

const int Editor_Generate_X_Pixel = 112;
const int Editor_Generate_Y_Pixel = 0;
const int Editor_Generate_W_Pixel = 112;
const int Editor_Generate_H_Pixel = Editor_TailFrame_H_Pixel;

//auto-count the related placement
const int Editor_TailFrame_H_InMainWin = Editor_TailFrame_H_Pixel * MAX_COORD / 768;

const int Editor_Generate_X_InHead = Editor_Generate_X_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int Editor_Generate_Y_InHead = Editor_Generate_Y_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;
const int Editor_Generate_W_InHead = Editor_Generate_W_Pixel * MAX_COORD 
                                     / Editor_TailFrame_W_Pixel;
const int Editor_Generate_H_InHead = Editor_Generate_H_Pixel * MAX_COORD 
                                     / Editor_TailFrame_H_Pixel;

const std::string Editor_GenerationImg_FileName("editor_generation_ori.png");
const std::string Editor_GenerationSelImg_FileName("editor_generation_sel.png");

const std::string Editor_ArrayImg_FileName("array.png");
const std::string Editor_ArrayExImg_FileName("array_ex.png");
const std::string Editor_MapImg_FileName("map.png");
const std::string Editor_MapExImg_FileName("map_ex.png");

///////////////////////////////////////////////////////////////////////
//    Input Editor
//////////////////////////////////////////////////////////////////////

class DInputEditor : public DEditor
{    
public:
    explicit DInputEditor(int model = BodyModel, DMainWin * pMainWin = NULL,
                     DWidget * parent = 0, WFlags f = 0);
    virtual ~DInputEditor();

    //init 
    virtual void initDialog();
    
    virtual void setReadonly();

    //get & set string
    std::string getInputString() const;
    void setInputString(const std::string & str);

private:
    DLineEditPtr m_ptrInputEdit;
    DImageLabelPtr m_ptrInputEditBg;    
};

const std::string Input_EditImg_FileName("warehouse_search_edit.png");
const std::string InputEditor_ObjName("Input_Editor_Object");

const int Default_InputEditor_W_InMainWin = 2000;
const int Default_InputEditor_H_InMainWin = 300;

typedef std::tr1::shared_ptr<DInputEditor>   DInputEditorPtr;

#endif /* DEDITOR_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
