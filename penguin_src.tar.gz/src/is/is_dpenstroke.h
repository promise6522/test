/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author  State   Date
** Yinlii  Create  2010-03-23
**
****************************************************************************/

#ifndef DPENSTROKE_H
#define DPENSTROKE_H

// Boost header files
#include <boost/tr1/memory.hpp>

class DPenStroke {
public:
    enum PenStyle {
        None,
        S_common,
        M_common,
        L_common,
        S_dot_dash,
        M_dot_dash,
        L_dot_dash
    };
    
    DPenStroke(PenStyle style = None, int width = 0);
    DPenStroke(const DPenStroke & otherPen);
    ~DPenStroke() { }

    //DPenStroke &operator=(const DPenStroke &otherPen);

    PenStyle style() const;
    void setStyle(PenStyle style);

    int width() const;
    void setWidth(int width);

    bool operator==(const DPenStroke &otherPen) const;
    inline bool operator!=(const DPenStroke &otherPen) const { return !(operator==(otherPen)); }

private:
    PenStyle m_penStyle;
    int m_width;
};

typedef std::tr1::shared_ptr<DPenStroke> DPenStrokePtr;

/***************************************************************************
 * DPenStroke inline functions
 **************************************************************************/

//Constructs a pen with a given pen style.
inline DPenStroke::DPenStroke(PenStyle style /* = S_common */ , int width /* = 0 */)
    : m_penStyle(style),
      m_width(width)
{ }

//Constructs a pen with another pen.
inline DPenStroke::DPenStroke(const DPenStroke & otherPen)
    : m_penStyle(otherPen.m_penStyle),
      m_width(otherPen.m_width)
{ }

//Returns the width of the pen.
inline int  DPenStroke::width() const
{ return m_width; }

//Sets the width of the pen.
inline void DPenStroke::setWidth(int width)
{ m_width = width; }

//Returns the style of the pen.
inline DPenStroke::PenStyle DPenStroke::style() const
{ return m_penStyle; }

//Sets the style of the pen.
inline void DPenStroke::setStyle(PenStyle style)
{ m_penStyle = style; };

inline bool DPenStroke::operator==(const DPenStroke &otherPen) const
{ 
    return m_penStyle == otherPen.m_penStyle &&
           m_width == otherPen.m_width;
}

#endif //DPENSTROKE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:

