/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author LHJ
**
****************************************************************************/

#ifndef DIMAGELABEL_H
#define DIMAGELABEL_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "duc.h"
#include "is_dframe.h"
#include "is_dimage.h"
#include "is_dtool.h"

class DImageLabelCell;

class DImageLabel : public DFrame {
public:
    DImageLabel(DWidget *parent = 0, WFlags f = 0);
    DImageLabel(const std::string &text, const DImage& rImage, 
                DWidget *parent = 0, WFlags f = 0);
    virtual ~DImageLabel();

    DText text()const;
    DText &rtext();
    void setText(const DText &text);

    std::string content() const;
    void setContent(const std::string& text);

    DFont font() const;
    void setFont(const DFont& font);

    AlignmentFlag alignment() const;
    void setAlignment(AlignmentFlag);
    
    int indent() const;
    void setIndent(int);

    bool wordWrap() const;
    void setWordWrap(bool);

    DColor textColor() const;
    void setTextColor(const DColor& rColor);

    DImage* image();
    void setImage(const DImage& image);
    
private:
    DImageLabel(const DImageLabel& rLabel);
    DImageLabel& operator=(const DImageLabel& rLabel);

private:
    DText m_text;    
    DImagePtr m_ptrImage;
    int m_indent;

    D_DECLARE_CELL(DImageLabel)
};

const std::string ImageLabel_ObjName("ImageLabel_Object");

typedef std::tr1::shared_ptr<DImageLabel> DImageLabelPtr;
typedef std::tr1::shared_ptr<DImageLabelCell> DImageLabelCellPtr;

/***************************************************************************
 * DImageLabel inline functions
 **************************************************************************/
inline DText DImageLabel::text() const
{ return m_text; }

inline DText &DImageLabel::rtext()
{ return m_text; }

inline void DImageLabel::setText(const DText &text)
{ m_text = text; }

inline std::string DImageLabel::content()const
{ return m_text.textData(); }

inline void DImageLabel::setContent(const std::string &content)
{ m_text.setTextData(content); }

inline DFont DImageLabel::font()const
{ return m_text.font(); }

inline void DImageLabel::setFont(const DFont &font)
{ m_text.setFont(font); }

inline AlignmentFlag DImageLabel::alignment() const
{ return m_text.align(); }

inline void DImageLabel::setAlignment(AlignmentFlag align)
{ m_text.setAlign(align); }

inline int DImageLabel::indent() const
{ return m_indent; }

inline void DImageLabel::setIndent(int indent)
{ m_text.rmargin().setLeft(indent); }

inline bool DImageLabel::wordWrap() const
{ return m_text.wrap(); }

inline void DImageLabel::setWordWrap(bool w)
{ m_text.setWrap(w); }

inline DColor DImageLabel::textColor() const
{ return m_text.color(); }

inline void DImageLabel::setTextColor(const DColor& rColor)
{ m_text.setColor(rColor); }

inline DImage* DImageLabel::image()
{ return m_ptrImage.get(); }

inline void DImageLabel::setImage(const DImage& image) 
{ 
    m_ptrImage.reset(new(std::nothrow) DImage(image));
    assert(m_ptrImage.get() != NULL);
}

class DImageLabelCell : public DFrameCell {
public:
    DImageLabelCell();
    virtual ~DImageLabelCell();

    void init();
    void update();

private:
    D_DECLARE_PUBLIC(DImageLabel)
};


#endif //DIMAGELABEL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
