#ifndef DCONTEDITOR_H
#define DCONTEDITOR_H

#include <boost/tr1/memory.hpp>

#include "is_ddialog.h"
#include "is_dfunc.h"
#include "is_deditor.h"
#include "duke_media_global.h"

class DContEditorCell;

typedef std::pair<DWidgetPtr, DWidgetPtr> ContWidgetPair;

typedef std::vector<ContWidgetPair> StorageConstraints;
typedef StorageConstraints::iterator StorageConstrIt;

typedef std::map<DWidgetPtr, DWidgetPtr> FuncWidgetMap;
typedef FuncWidgetMap::iterator FuncWidgetMapIt;
typedef std::vector<std::pair<DWidgetPtr, DWidgetPtr> > FuncWidgetVector;
typedef FuncWidgetVector::iterator FuncWidgetVectorIt;

typedef std::vector<DWidgetPtr> AnchorWidgets;
typedef AnchorWidgets::iterator AnchorWidgetIt;
typedef AnchorWidgets::size_type AnchorWidgetIdx;

class DContEditor : public DEditor {
public:
    explicit DContEditor(EditorModel model = DialogModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DContEditor(const std::string& title,
            EditorModel model = DialogModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DContEditor();

    // Init
    void initCuttingLine();
    void initFuncFrame();
    void initStorageFrame();
    void initAnchorFrame();
    void initRootAnchorFrame();
    void initFuncExisted();
    void initStorageExisted();
    void initAnchorExisted();
    void initRootAnchorExisted();
    void initContEditor();    

    void duplicateItemsByHandle(const duke_media_handle& hcont);
    void reload();
    bool isValidContainer(duke_media_container *pContMedia);
    void dumpContainerInfo();
    void setReadonly();

    // manage widget in the editor
    DButton * createWidgetForFunc(const DPoint &, DWidget *);
    DButton * createStorage(const int st_idx);
    DButton * createConstraintForStorage(const DPoint &, const duke_media_handle& hif);
    DEditor * createArrayInterfaceEditor(DWidget *pSrcWidget);
    void updateFuncView();
    void updateStorageView();
    void updateAnchorView();

    // Event handle
    void onDnDStart(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onActivateBtn(const DEvent &event);
    void onHoverBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);
    void onGenerate(const DEvent &event);
    // Func
    void onDnDReleaseFuncFrame(const DEvent &event);
    void onDeleteFunc(const DEvent &event);
    void onDnDStartDecl(const DEvent &event);
    void onActivateImplBtn(const DEvent &event);
    // Storage
    void onInputStorageNum(const DEvent &event);
    void onClickStorageCreateBtn(const DEvent &event);
    void onActivateStorageBtn(const DEvent &event);
    void onDnDReleaseStorageFrame(const DEvent &event);
    void onDeleteStorage(const DEvent &event);
    void onSelectInterfaceMenu(const DEvent &event);//interface menu
    void onInterfaceMenuBlur(const DEvent &event);  // interface menu blur
    DPopupMenu* createPopupMenuForInterface(const duke_media_handle& hif, const DEvent &event);
    // Anchor
    void onDnDReleaseAnchorFrame(const DEvent &event);
    void onDeleteAnchor(const DEvent &event);
    void onCreateAnchor(const DEvent &event);
    void onActivateAnchorFrame(const DEvent &event);
    void onActivateAnchorBtn(const DEvent &event);
    void onDnDStartAnchorBtn(const DEvent &event);
    // Root Anchor
    void onDnDStartRootAnchorBtn(const DEvent &event);
    // func page arrow
    void onFuncArrow(const DEvent &event);
    void onPassingInFuncArrow(const DEvent &event);
    void onPassingOutFuncArrow(const DEvent &event);

    void dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame);

private:
    // Save
    void saveFuncInfo();
    void saveStorageInfo();
    void saveAnchorInfo();
    void saveRootAnchorInfo();

    // update
    void updateStorageInfo();
    void updateParentContForItems(duke_media_handle hparentcont);

    // Generate 
    duke_media_handle generate();

private:
    DImageLabelPtr m_ptrHoriCuttingLine;
    DImageLabelPtr m_ptrVertiCuttingLine1;
    DImageLabelPtr m_ptrVertiCuttingLine2;
    DFramePtr m_ptrFuncFrame;
    DFramePtr m_ptrStorageFrame;
    DFramePtr m_ptrAnchorFrame;
    DFramePtr m_ptrRootAnchorFrame;
    DLineEditPtr m_ptrStorageNum;
    DImageLabelPtr m_ptrStorageNumIcon;
    DButtonPtr m_ptrStorageCreateBtn;
    DPopupMenuPtr m_ptrAnchorMenu;
    DPopupMenuPtr m_ptrInterfaceMenu;
    DButtonPtr m_ptrRootAnchorBtn;

    DButtonPtr m_ptrFuncLArrow;
    DButtonPtr m_ptrFuncRArrow;
    std::size_t m_curFuncPage;

    int m_funcLayer;
    int m_storageLayer;
    int m_anchorLayer;
    int m_funcLayerHeight;
    int m_storageLayerHeight;
    int m_anchorLayerHeight;
    int m_anchorRow;
    int m_storageRow;

    FuncWidgetVector m_funcWidgets;
    StorageConstraints m_storageWidgets; 
    AnchorWidgets m_anchorWidgets;

    int m_storageNum;

    int m_horiCuttingLineHeight;
    int m_vertiCuttingLineWidth;
    int m_storageCreateBtnHeight;

    D_DECLARE_CELL(DContEditor)
};

class DContEditorCell : public DDialogCell
{
public:
    DContEditorCell();
    virtual ~DContEditorCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DContEditor)    
};


typedef std::tr1::shared_ptr<DContEditor>  DContEditorPtr;
typedef std::tr1::shared_ptr<DContEditorCell>  DContEditorCellPtr;

const std::string ContEditor_HoriCut_Filename("hori_cutting_line.png");
const std::string ContEditor_VertiCut_Filename("verti_cutting_line.png");
const std::string ContEditor_Decl_Filename("decl_origin.png");
const std::string ContEditor_Impl_Filename("impl_origin.png");
const std::string ContEditor_Anchor_Filename("anchor.png");
const std::string ContEditor_RootAnchorBtn_Filename("root_access.png");
const std::string ContEditor_StorageCreateBtn_Filename("warehouse_create_button.png");
const std::string ContEditor_StorageNumIcon_Filename("storage_number.png");
const std::string ContEditor_Storage_Filename("storage.png");
const std::string ContEditor_StorageIF_Filename("interface_origin.png");
const std::string ContEditor_ObjName("Container_Des_Editor");
const std::string ContEditor_Title("Duke Container Descriptor Editor");
const std::string ContEditor_RightArrowButton_Filename("right_arrow.png");
const std::string ContEditor_RightArrowHoverButton_Filename("right_arrow_hover.png");
const std::string ContEditor_LeftArrowButton_Filename("left_arrow.png");
const std::string ContEditor_LeftArrowHoverButton_Filename("left_arrow_hover.png");
const int ContEditor_Layer = 1000;
const int ContEditor_Total_Layer = 10;
const int Anchor_Layer = 0;
const int Anchor_Menu_Height = 2000;
const int ContEditor_Row_Height = 2000;
const int ContEditor_Col_Items = 6;
const int Storage_Num_Editor_Height = 600;
const int ContEditor_Width = 336;
const int ContEditor_Height = 448;
const int Default_ContEditor_W_InMainWin = ContEditor_Width * MAX_COORD / 1366;
const int Default_ContEditor_H_InMainWin = ContEditor_Height * MAX_COORD / 768;
// horizontal cutting line
const int ContEditor_HoriCuttingLine_X_Pixel = 12;
const int ContEditor_HoriCuttingLine_X_InBodyFrame = ContEditor_HoriCuttingLine_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_HoriCuttingLine_Y_Pixel = 269;
const int ContEditor_HoriCuttingLine_Y_InBodyFrame = ContEditor_HoriCuttingLine_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_HoriCuttingLine_W_Pixel = 312;
const int ContEditor_HoriCuttingLine_W_InBodyFrame = ContEditor_HoriCuttingLine_W_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_HoriCuttingLine_H_Pixel = 2;
const int ContEditor_HoriCuttingLine_H_InMainWin = ContEditor_HoriCuttingLine_H_Pixel * MAX_COORD / 768;
// vertical cutting line1
const int ContEditor_VertiCuttingLine1_X_Pixel = 165;
const int ContEditor_VertiCuttingLine1_X_InBodyFrame = ContEditor_VertiCuttingLine1_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_VertiCuttingLine1_Y_Pixel = 46;
const int ContEditor_VertiCuttingLine1_Y_InBodyFrame = ContEditor_VertiCuttingLine1_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_VertiCuttingLine1_W_Pixel = 2;
const int ContEditor_VertiCuttingLine1_W_InMainWin = ContEditor_VertiCuttingLine1_W_Pixel * MAX_COORD / 1366;
const int ContEditor_VertiCuttingLine1_H_Pixel = 222;
const int ContEditor_VertiCuttingLine1_H_InBodyFrame = ContEditor_VertiCuttingLine1_H_Pixel * MAX_COORD / ContEditor_Height;
// vertical cutting line2
const int ContEditor_VertiCuttingLine2_X_Pixel = 262;
const int ContEditor_VertiCuttingLine2_X_InBodyFrame = ContEditor_VertiCuttingLine2_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_VertiCuttingLine2_Y_Pixel = 275;
const int ContEditor_VertiCuttingLine2_Y_InBodyFrame = ContEditor_VertiCuttingLine2_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_VertiCuttingLine2_W_Pixel = 2;
const int ContEditor_VertiCuttingLine2_W_InMainWin = ContEditor_VertiCuttingLine2_W_Pixel * MAX_COORD / 1366;
const int ContEditor_VertiCuttingLine2_H_Pixel = 135;
const int ContEditor_VertiCuttingLine2_H_InBodyFrame = ContEditor_VertiCuttingLine2_H_Pixel * MAX_COORD / ContEditor_Height;
// storage 
const int ContEditor_StorageFrame_X_Pixel = 12;
const int ContEditor_StorageFrame_X_InBodyFrame = ContEditor_StorageFrame_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_StorageFrame_Y_Pixel = 49;
const int ContEditor_StorageFrame_Y_InBodyFrame = ContEditor_StorageFrame_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_StorageFrame_W_Pixel = 154;
const int ContEditor_StorageFrame_W_InBodyFrame = ContEditor_StorageFrame_W_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_StorageFrame_H_Pixel = 222;
const int ContEditor_StorageFrame_H_InBodyFrame = ContEditor_StorageFrame_H_Pixel * MAX_COORD / ContEditor_Height;
// storage number icon
const int ContEditor_StorageNum_X_Pixel = 0;
const int ContEditor_StorageNum_X_InStorageFrame = ContEditor_StorageNum_X_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageNum_Y_Pixel = 2;//0;
const int ContEditor_StorageNum_Y_InStorageFrame = ContEditor_StorageNum_Y_Pixel * MAX_COORD / ContEditor_StorageFrame_H_Pixel;
const int ContEditor_StorageNum_W_Pixel = 125;
const int ContEditor_StorageNum_W_InStorageFrame = ContEditor_StorageNum_W_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageNum_H_Pixel = 20;
const int ContEditor_StorageNum_H_InMainWin = ContEditor_StorageNum_H_Pixel * MAX_COORD / 768;
// storage number text
const int ContEditor_StorageText_X_Pixel = 100;
const int ContEditor_StorageText_X_InStorageFrame = ContEditor_StorageText_X_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageText_Y_Pixel = 4;//3;
const int ContEditor_StorageText_Y_InStorageFrame = ContEditor_StorageText_Y_Pixel * MAX_COORD / ContEditor_StorageFrame_H_Pixel;
const int ContEditor_StorageText_W_Pixel = 24;
const int ContEditor_StorageText_W_InStorageFrame = ContEditor_StorageText_W_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageText_H_Pixel = 14;
const int ContEditor_StorageText_H_InMainWin = ContEditor_StorageText_H_Pixel * MAX_COORD / 768;
// storage create btn 
const int ContEditor_StorageCreate_X_Pixel = 125;
const int ContEditor_StorageCreate_X_InStorageFrame = ContEditor_StorageCreate_X_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageCreate_Y_Pixel = 3;//0;
const int ContEditor_StorageCreate_Y_InStorageFrame = ContEditor_StorageCreate_Y_Pixel * MAX_COORD / ContEditor_StorageFrame_H_Pixel;
const int ContEditor_StorageCreate_W_Pixel = 26;
const int ContEditor_StorageCreate_W_InStorageFrame = ContEditor_StorageCreate_W_Pixel * MAX_COORD / ContEditor_StorageFrame_W_Pixel;
const int ContEditor_StorageCreate_H_Pixel = 20;
const int ContEditor_StorageCreate_H_InMainWin = ContEditor_StorageCreate_H_Pixel * MAX_COORD / 768;
// function 
const int ContEditor_FuncFrame_X_Pixel = 170;
const int ContEditor_FuncFrame_X_InBodyFrame = ContEditor_FuncFrame_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_FuncFrame_Y_Pixel = 49;
const int ContEditor_FuncFrame_Y_InBodyFrame = ContEditor_FuncFrame_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_FuncFrame_W_Pixel = 154;
const int ContEditor_FuncFrame_W_InBodyFrame = ContEditor_FuncFrame_W_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_FuncFrame_H_Pixel = 222;
const int ContEditor_FuncFrame_H_InBodyFrame = ContEditor_FuncFrame_H_Pixel * MAX_COORD / ContEditor_Height;
// anchor 
const int ContEditor_AnchorFrame_X_Pixel = 12;
const int ContEditor_AnchorFrame_X_InBodyFrame = ContEditor_AnchorFrame_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_AnchorFrame_Y_Pixel = 275;
const int ContEditor_AnchorFrame_Y_InBodyFrame = ContEditor_AnchorFrame_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_AnchorFrame_W_Pixel = 248;
const int ContEditor_AnchorFrame_W_InBodyFrame = ContEditor_AnchorFrame_W_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_AnchorFrame_H_Pixel = 135;
const int ContEditor_AnchorFrame_H_InBodyFrame = 3000;
// root anchor frame 
const int ContEditor_RootAnchorFrame_X_Pixel = 264;
const int ContEditor_RootAnchorFrame_X_InBodyFrame = ContEditor_RootAnchorFrame_X_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_RootAnchorFrame_Y_Pixel = 275;
const int ContEditor_RootAnchorFrame_Y_InBodyFrame = ContEditor_RootAnchorFrame_Y_Pixel * MAX_COORD / ContEditor_Height;
const int ContEditor_RootAnchorFrame_W_Pixel = 60;
const int ContEditor_RootAnchorFrame_W_InBodyFrame = ContEditor_RootAnchorFrame_W_Pixel * MAX_COORD / ContEditor_Width;
const int ContEditor_RootAnchorFrame_H_Pixel = 135;
const int ContEditor_RootAnchorFrame_H_InBodyFrame = 3000;
//page arrow
const int ContEditor_LArrow_X = 100;
const int ContEditor_RArrow_X = 8600;
const int ContEditor_Arrow_Y = 4000;
const int ContEditor_Arrow_Width = 1300;
const int ContEditor_Arrow_Height = 1000;

#endif // DContEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
