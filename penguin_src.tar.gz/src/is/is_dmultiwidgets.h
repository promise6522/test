/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DMULTIWIDGETS_H
#define DMULTIWIDGETS_H

// Boost header files
#include <boost/tr1/memory.hpp>


// Duke header files
#include "duc.h"
#include "is_dwidget.h"

//DWidget in DMultiWidgets
typedef std::vector<DWidget *> MultiWidgets;
typedef MultiWidgets::iterator MultiWidgetsIt;

class DMultiWidgets
{
public:
    DMultiWidgets();    
    ~DMultiWidgets();

    //manage the widget group
    void addWidget(DWidget *);
    void delWidget(DWidget *);
    void clear();
    size_t size();    

    //Send all the widget information in one reponse
    void repaintAll(const is_response_call& response_call, bool hasData = true);
    void showAll(const is_response_call& response_call);
    void destoryAll(const is_response_call& response_call);
    void hideAll(const is_response_call& response_call);
    void displayAll(const is_response_call& response_call);

private:
    MultiWidgets m_widgets;
};

#endif /* DDIALOG_H */
