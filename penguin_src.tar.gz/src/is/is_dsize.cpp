/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Duke header files
#include "is_dsize.h"

/*
 * Swaps the width and height values.
 */
void DSize::transpose()
{
    int tmp = wd;
    wd = ht;
    ht = tmp;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
