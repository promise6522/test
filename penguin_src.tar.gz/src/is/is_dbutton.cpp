/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#include "is_dbutton.h"
#include <iterator>

DButton::DButton(DWidget *parent /* = 0 */, WFlags f /* =0 */)
    : DWidget(*new DButtonCell, parent, f),
      m_isSelected(true)
{
    setObjectName(Button_ObjName);
    setTextAlign(AlignCenter);
    setTextWrap(true);
    d_func()->init();
    registerEvent(DEvent::Select);
    setEventRoutine(DEvent::Select, this, (EventRoutine)(&DButton::processSelectEvent));    
}

DButton::DButton(const std::string &text, DWidget *parent /* = 0 */, WFlags f /* = 0 */)
    : DWidget(*new DButtonCell, parent, f),
      m_isSelected(true)
{
    setObjectName(Button_ObjName);
    setContent(text);
    setTextAlign(AlignCenter);
    setTextWrap(true);
    d_func()->init();
    registerEvent(DEvent::Select);
    setEventRoutine(DEvent::Select, this, (EventRoutine)(&DButton::processSelectEvent));
}

DButton::DButton(const std::string &text, const DImage & img, 
                 DWidget * parent /* = 0 */, WFlags f /* = 0 */)
    : DWidget(*new DButtonCell, parent, f),
      m_isSelected(true)  
{
    setObjectName(Button_ObjName);
    setContent(text);
    setImage(img);
    setTextAlign(AlignCenter);
    setTextWrap(true);
    d_func()->init();
    registerEvent(DEvent::Select);
    setEventRoutine(DEvent::Select, this, (EventRoutine)(&DButton::processSelectEvent));    
}

DButton::DButton(const std::string &text, const DImage & img, 
                 const DImage & selImg, DWidget * parent /*= 0*/, WFlags f /*= 0*/)
    : DWidget(*new DButtonCell, parent, f),
      m_isSelected(true)      
{
    setObjectName(Button_ObjName);
    setContent(text);
    setImage(img);
    setSelImage(selImg);
    setTextAlign(AlignCenter);
    setTextWrap(true);
    d_func()->init();
    registerEvent(DEvent::Select);
    setEventRoutine(DEvent::Select, this, (EventRoutine)(&DButton::processSelectEvent));        
}

DButton::~DButton()
{
}

DColor DButton::textColor() const
{
    return m_text.color();
}

void DButton::setTextColor(const DColor &color)
{
    m_text.setColor(color);
}

AlignmentFlag DButton::textAlign() const
{
    return m_text.align();
}

void DButton::setTextAlign(const AlignmentFlag & align)
{
    m_text.setAlign(align);
}

bool DButton::isTextWrap() const
{
    return m_text.wrap();
}

void DButton::setTextWrap(bool isWrap)
{
    m_text.setWrap(isWrap);
}
    
DMargin DButton::textMargin() const
{
    return m_text.margin();
}
 
void DButton::setTextMargin(const DMargin &margin)
{
    m_text.setMargin(margin);
}

const DImage * DButton::image() const
{ 
    //TBD return m_ptrImage.get(); 
    if(m_isSelected && (m_ptrSelImage.get() != NULL))
    {
        return m_ptrSelImage.get();
    }

    return m_ptrImage.get();
}

void DButton::setImage(const DImage &img)
{
    m_ptrImage.reset(new(std::nothrow) DImage(img));
    assert(m_ptrImage.get() != NULL);
}

const DImage * DButton::selImage() const
{
    return m_ptrSelImage.get();
}

void DButton::setSelImage(const DImage &selImg)
{
    m_ptrSelImage.reset(new(std::nothrow) DImage(selImg));
    assert(m_ptrSelImage.get() != NULL);
}

bool DButton::isSelected() const
{
    return m_isSelected;
}

void DButton::setSelected(bool isSelected /* = true */)
{
    m_isSelected = isSelected;
}

void DButton::processSelectEvent(const DEvent& rEvent)
{
}

/***************************************************************************
 * DButtonCell member functions
 **************************************************************************/
DButtonCell::DButtonCell()
{
}

DButtonCell::~DButtonCell()
{
}

void DButtonCell::init()
{
    DButton *q = q_func();

    // init image 
    TPlacement tpImage;
    TImage image;
    TPath p1(m_place->path);
    p1.node.push_back(0);
    tpImage.path = p1;
    tpImage.position.x = tpImage.position.y = MIN_COORD;
    tpImage.size.width = tpImage.size.height = MAX_COORD;
    tpImage.data = &image;
    subNodes.push_back(tpImage);
    (q->cnum())++;
    tpImage.data = NULL;

    // init text
    TPlacement tpText;
    TText text;
    TPath p2(m_place->path);
    p2.node.push_back(1);
    tpText.path = p2;
    tpText.position.x = tpText.position.y = MIN_COORD;
    tpText.size.width = tpText.size.height = MAX_COORD;
    tpText.data = &text;
    subNodes.push_back(tpText);
    (q->cnum())++;
    tpText.data = NULL;
}

void DButtonCell::update()
{
    DWidgetCell::update();
    //printf("DButtonCell::update \n");

    DButton *q = q_func();

    m_place->path.node = q->objectPath();

    //Update Image
    TPlacement *imgPlace = &subNodes[0];
    imgPlace->path.node = q->objectPath();
    imgPlace->path.node.push_back(0);
    imgPlace->order = q->displayOrder();
    TImage *pTImage = dynamic_cast<TImage *>(imgPlace->data);
    assert(pTImage != NULL);
    const DImage* pDImage = q_func()->image();
    if (pDImage != NULL) {
        DImage2TImage(*pDImage, *pTImage);
    }

    //Update Text
    TPlacement *textPlace = &subNodes[1];
    textPlace->path.node = q->objectPath();
    textPlace->path.node.push_back(1);
    textPlace->order = q->displayOrder();
    TText *pText = dynamic_cast<TText *>(textPlace->data);
    assert(pText != NULL);
    DText2TText(q->m_text, *pText);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
