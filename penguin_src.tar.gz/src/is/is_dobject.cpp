/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Boost header file
#include <boost/thread.hpp>

#include "is_dobject.h"

#include <iostream>
#include <sstream>

static DObjectList* object_trees = 0;
static boost::mutex obj_trees_mutex;

//static void cleanup_object_trees()
//{
//    delete object_trees;
//    object_trees = 0;
//}

static void ensure_object_trees()
{
    object_trees = new DObjectList;
}

static void insert_tree(DObject* obj)
{
    obj_trees_mutex.lock();
    if (!object_trees)
        ensure_object_trees();
    object_trees->push_back(obj);
    obj_trees_mutex.unlock();
}

static void remove_tree(DObject* obj)
{
    if (object_trees) {
        obj_trees_mutex.lock();
        object_trees->remove(obj);
        obj_trees_mutex.unlock();
    }
}


/**************************************************************************
 * DObject member functions
 **************************************************************************/
DObject::DObject(DObject *parent)
    : isTree(false),	// no tree yet
      childNum(0),	// child counter
      parentObj(0),	// no parent yet. It is set by insertChild()
      childObjects(0) 	// no children yet
{
    if (parent) {
        parent->insertChild(this);
    } else {
        insert_tree(this);
        isTree = true;
        objpath.push_back(object_trees->size() - 1);
    }
}

DObject::~DObject()
{
    if (isTree) {
        remove_tree(this);
        isTree = false;
    }

    if (parentObj) {
        parentObj->removeChild(this);
    }

    if (childObjects) {
        DObjectListIt it;
        for (it=childObjects->begin(); it!=childObjects->end(); it++) {
            DObject *obj = (DObject *)*it;
            obj->parentObj = 0;
        }
        childObjects->clear();
        delete childObjects;
    }
}

std::string DObject::strPath() const
{
    if (!objpath.size())
        return 0;

    std::stringstream ss;
    for (int i=0; i<(int)objpath.size(); i++) {
        ss << objpath[i];
        if (i < (int)objpath.size()-1)
            ss << '.';
    }

    return ss.str();
}

/*
 * Searches the children and optionally grandchildren of this object,
 * and returns a child whose location is path.
 *
 * If there is no such object, this function returns 0.
 */
DObject *DObject::findChild(const DPath &path)const
{
    const DObjectList *list = children();
    if (!list)
        return 0;

    DObject *obj = NULL;
    DObjectListIt it;
    for (it=childObjects->begin(); it!=childObjects->end(); it++) {
        obj = (DObject *)*it;
        if (obj->objectPath() == path)
            break;
        obj = obj->findChild(path);
        if(obj != NULL)
            break;        
    }
    return obj;
}

/*
 * Inserts an object obj into the list of child objects.
 */
void DObject::insertChild(DObject *obj)
{
    if (obj->isTree) {
        remove_tree(obj);
        obj->isTree = false;
    }

    if (obj->parentObj && obj->parentObj != this)
        obj->parentObj->removeChild(obj);

    if (!childObjects)
        childObjects = new DObjectList;
    else if (obj->parentObj == this)
        return;

    obj->parentObj = this;
    childObjects->push_back(obj);
    childNum++;

    DPath childPath = objpath;
    childPath.push_back(childNum-1);
    obj->setObjectPath(childPath);
}

/*
 * Removes the child object obj from the list of children.
 */
void DObject::removeChild(DObject *obj)
{
    if (childObjects) {
        childObjects->remove(obj); 
        obj->parentObj = 0;

        if (!childObjects->size()) {
            delete childObjects;
            childObjects = 0;
        }
    }
}

void DObject::dumpObjectInfo()
{
    return;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
