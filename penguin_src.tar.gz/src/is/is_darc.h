/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#ifndef DARC_H
#define DARC_H

#include <boost/tr1/memory.hpp>
#include "is_dwidget.h"
#include "is_dtool.h"
#include "is_dcolor.h"

class DArcCell;

class DArc : public DWidget {
public:
    DArc(DWidget *parent = 0, WFlags f = 0);
    virtual ~DArc();

    int start() const;
    void setStart(const int start);
    int extent() const;
    void setExtent(const int extent);
    bool autoFill() const;
    virtual void setAutoFill(bool fill);
    DColor edgeColor() const;
    void setEdgeColor(const DColor &); 

    int minAspectRatio() const;
    void setMinAspectRatio(const int minRatio);
    int maxAspectRatio() const;
    void setMaxAspectRatio(const int maxRatio);

    // event handle
    virtual bool event(DEvent *);
    void onHoverEvent(const DEvent& rEvent);
    void onPassingOutEvent(const DEvent& rEvent);

private:
    int m_start;
    int m_extent;
    bool m_autoFill;
    DColor m_edgeColor;

    int m_minRatio;
    int m_maxRatio;

    D_DECLARE_CELL(DArc)
};

/***************************************************************************
 * DArc inline functions
 **************************************************************************/
inline int DArc::start() const
{ return m_start; } 

inline void DArc::setStart(const int start)
{ m_start = start; }

inline int DArc::extent() const
{ return m_extent; } 

inline void DArc::setExtent(const int extent)
{ m_extent = extent; }

inline bool DArc::autoFill() const
{ return m_autoFill; }

inline void DArc::setAutoFill(bool fill)
{ m_autoFill = fill; }

inline DColor DArc::edgeColor() const
{ return m_edgeColor; }

inline void DArc::setEdgeColor(const DColor & color)
{ m_edgeColor = color; }

inline int DArc::minAspectRatio() const
{ return m_minRatio; } 

inline void DArc::setMinAspectRatio(const int minRatio)
{ m_minRatio = minRatio; }

inline int DArc::maxAspectRatio() const
{ return m_maxRatio; } 

inline void DArc::setMaxAspectRatio(const int maxRatio)
{ m_maxRatio = maxRatio; }

class DArcCell : public DWidgetCell {
public:
    DArcCell();
    virtual ~DArcCell();

    void init();
    virtual void update();
    virtual void hover(const is_response_call& response_call);

private:
    D_DECLARE_PUBLIC(DArc)
};

typedef std::tr1::shared_ptr<DArc>  DArcPtr;
typedef std::tr1::shared_ptr<DArcCell>  DArcCellPtr;

const std::string DArc_ObjName("DArc_Object");

#endif // DART_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
