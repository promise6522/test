/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_darc.h"

DArc::DArc(DWidget *parent, WFlags f)
    : DWidget(*new DArcCell, parent, f),
      m_start(0),
      m_extent(0),
      m_autoFill(true),
      m_minRatio(10000),
      m_maxRatio(10000)
{
    setObjectName(DArc_ObjName);    
    d_func()->init();
    setEventRoutine(DEvent::Hover, this, (EventRoutine)(&DArc::onHoverEvent));
    setEventRoutine(DEvent::PassingOut, this, (EventRoutine)(&DArc::onPassingOutEvent));
}

DArc::~DArc()
{
}

bool DArc::event(DEvent *e)
{
   // std::cout << "event : " << e->type() << std::endl; 
    return true;
}

void DArc::onHoverEvent(const DEvent& rEvent)
{
    printf("DArc::Hover event processing ---------\n");
    d_func()->hover(rEvent.getCon());
}

void DArc::onPassingOutEvent(const DEvent& rEvent)
{
    printf("DArc::PassingOut event processing ---------\n");
    repaint(rEvent.getCon());
}

/***************************************************************************
 * DArcCell member functions
 **************************************************************************/
DArcCell::DArcCell()
{
}

DArcCell::~DArcCell()
{
}

void DArcCell::init()
{
    DArc *q = q_func();
    TPlacement ap;
    TArc arc;

    // init 
    aspectKeeper.minAspectRatio = 10000;
    aspectKeeper.maxAspectRatio = 10000;

    TPath p(m_place->path);
    p.node.push_back(0);
    ap.path = p;
    arc.closedType = ArcClosedType_PIE; 
    arc.start = 0;
    arc.extent = 360;
    arc.fill = true;
    ap.position.x = ap.position.y = MIN_COORD;
    ap.size.width = ap.size.height = MAX_COORD;

    DColor2TColor(q->edgeColor(), arc.edgeColor);
    DColor2TColor(q->backgroundColor(), arc.background);
    ap.data = &arc;

    subNodes.push_back(ap);
    (q->cnum())++;
    ap.data = NULL;
}

void DArcCell::update()
{
    DWidgetCell::update();

    DArc *q = q_func();
    
    m_place->path.node = q->objectPath();

    // update aspectKeeper
    aspectKeeper.minAspectRatio = q->minAspectRatio();
    aspectKeeper.maxAspectRatio = q->maxAspectRatio();

    TPlacement &ap = subNodes[0];
    ap.path.node = m_place->path.node;
    ap.path.node.push_back(0); 
    ap.order = q->displayOrder();

    TArc *pArc = reinterpret_cast<TArc *>(ap.data);
    pArc->start = q->start();
    pArc->extent = q->extent();
    pArc->fill = q->autoFill();
    DColor2TColor(q->edgeColor(), pArc->edgeColor);
    DColor2TColor(q->backgroundColor(), pArc->background);
}

void DArcCell::hover(const is_response_call& response_call)
{
    DArc *q = q_func();

    TArc *pArc = reinterpret_cast<TArc *>(subNodes[0].data);
    DColor2TColor(q->highlightColor(), pArc->edgeColor);    
    DColor2TColor(q->highlightColor(), pArc->background);    

    Packer p;
    TUpdateNode node(*m_place);
    p.pack(node);
    // send data to client for show
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
