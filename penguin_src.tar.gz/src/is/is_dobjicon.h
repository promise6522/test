/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#ifndef DUKE_IS_DOBJICON_H
#define DUKE_IS_DOBJICON_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dimageex.h"
#include "is_dtool.h"
#include "is_dfunc.h"
#include "is_dedge.h"
#include "is_dport.h"
#include "is_dlabel.h"
////#include "media/duke_media_header.h"

class DObjIconCell;

class DObjIcon : public DWidget {
public:
    //ctor & dtor
    DObjIcon(DWidget * parent = 0, WFlags f = 0);
    DObjIcon(const std::string &text, const DImage & img, DWidget * parent = 0, WFlags f = 0);
    DObjIcon(const std::string &text, 
             const DImage & img, 
             const duke_media_handle & h_obj, 
             DWidget * parent = 0, 
             WFlags f = 0);

    virtual ~DObjIcon();

    //Get & Set method    
    void reloadObjMedia();
    // manage text
    std::string textContent() const;
    void setTextContent(const std::string &text);
    void setTextLabel(const std::string &text);
    DLabelPtr textLabel() const;
    void setTextRect(int x, int y, int w, int h);
    void deleteTextLabel();

    // manage image
    DRect imageGeometry();
    DImageEx * imageEx() const;
    void setImageEx(const DImage &);
    void setImage(const DImage &);

    // Manage port
    void deleteOutPort();

    // Manage edge
    // Update the position of the edge
    void updateEdgePos();
    // Create a new edge
    DEdgePtr createEdge();
    // Delete the edge
    void deleteOutEdge(DEdge *pEdge);
    // Close all edges
    void clearAllEdges();
    // Get suspending edge 
    DEdgePtr getSuspendEdge();
    // Get edge vector
    EItems outEdges();
    // Set input edge
    void setInEdge(DEdgePtr ptrEdge);
    // Delete input edge from obj
    void deleteInEdge();

    // Check whether the objicon can move to the new pos or not
    bool checkPos(const DPoint &p, int len);
    // Connect a func
    void connect(DFunc *pConnFunc, unsigned int inIdx);
    void connect(DPort *pConnInPort);
    
    // Event handle 
    void onOutPortDnDStart(const DEvent &rEvent);
    void onOutPortDnDRelease(const DEvent &rEvent);
    void onDestroy(const DEvent &rEvent);
    void onBodyDnDRelease(const DEvent &rEvent);

private:
    DObjIcon(const DObjIcon &);
    DObjIcon &operator=(const DObjIcon &);
    void initObjView();
    void initObjMedia();

    DRect textRect() const;
    void setTextRect();

private:
    DLabelPtr m_ptrTextLabel;
    DImageExPtr m_ptrImageEx;

    EItems m_outEdges;
    DEdgePtr m_ptrInEdge;
    DPortPtr m_ptrOutPort;

    D_DECLARE_CELL(DObjIcon)
};

const std::string ObjIcon_ObjName("ObjIcon_Object");
/***************************************************************************
 * DObjIcon inline functions
 **************************************************************************/

class DObjIconCell : public DWidgetCell {
public:
    DObjIconCell();
    ~DObjIconCell();

    void init();
    void update();
private:
    D_DECLARE_PUBLIC(DObjIcon)
};

typedef std::tr1::shared_ptr<DObjIcon>  DObjIconPtr;
typedef std::tr1::shared_ptr<DObjIconCell>  DObjIconCellPtr;

#endif /* DOBJICON_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
