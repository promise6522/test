/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#ifndef DIFEDITOR_H
#define DIFEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_dfunc.h"
#include "is_deditor.h"
#include "duke_media_bridge_interface.h"

typedef std::vector<DWidgetPtr> IFWidgets;
typedef IFWidgets::iterator IFWidgetsIt;
typedef IFWidgets::size_type IFWidgetsIdx;

class DIFEditor : public DEditor {
public:
    explicit DIFEditor(EditorModel model = DialogModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DIFEditor(const std::string& title,
            EditorModel model = DialogModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DIFEditor();

    // duplicate
    void duplicateItemsByHandle(const duke_media_handle& hif);
    
    // Init    
    void initIFEditor(bool createNew);
    void initSingletonBar();
    void initExpandBar();
    void initDeclFrame();
    void initItemsInBody();
    void saveDeclInfo();

    // reload and generate
    void reload();
    duke_media_handle generate();
    void generateSubItems();

    // Manage widget in the editor
    DButton * createWidgetForFunc(DWidget *pSrc);
    void updateDeclView();
    void adjustPlacement();
    void setReadonly();

    // Event handle
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onDeleteChild(const DEvent &event);
    void onSelectChild(const DEvent &event);
    void onActivateChild(const DEvent &event);
    void onGenerate(const DEvent &event);
    void onSelectSingleton(const DEvent& event);
    void onHoverSingleton(const DEvent &event);
    void onPassingOutSingleton(const DEvent &event);
    void dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame);

private:
    DFramePtr m_ptrDeclFrame;
    DButtonPtr m_ptrSingletonButton;
    DButtonPtr m_ptrExpandButton;

    IFWidgets m_ifWidgets; 
    bool m_isSingleton;
    bool m_isExpand;
    int m_row;
    int m_rowHeight;
    int m_singletonBarHeight;
};

typedef std::tr1::shared_ptr<DIFEditor>  DIFEditorPtr;

const std::string IFEditor_ObjName("Interface_Editor");
const int IFEditor_Row_Height = 2000;
const int IFEditor_Col_Items = 5;

const int IFEditor_Width = 336;
const int IFEditor_Heigth = 448;
const int IFEditor_DeclFrame_W_Pixel = 313;
const int IFEditor_DeclFrame_W_InBodyFrame = IFEditor_DeclFrame_W_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_DeclFrame_X_Pixel = 12;
const int IFEditor_DeclFrame_X_InBodyFrame = IFEditor_DeclFrame_X_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_SingletonBar_X_Pixel = 112;
const int IFEditor_SingletonBar_X_InBodyFrame = IFEditor_SingletonBar_X_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_SingletonBar_W_Pixel = 112;
const int IFEditor_SingletonBar_W_InBodyFrame = IFEditor_SingletonBar_W_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_SingletonBar_H_Pixel = 24;
const int IFEditor_SingletonBar_H_InMainWin = IFEditor_SingletonBar_H_Pixel * MAX_COORD / 768;
const int IFEditor_ExpandBar_X_Pixel = 112;
const int IFEditor_ExpandBar_X_InBodyFrame = IFEditor_ExpandBar_X_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_ExpandBar_W_Pixel = 112;
const int IFEditor_ExpandBar_W_InBodyFrame = IFEditor_ExpandBar_W_Pixel * MAX_COORD / IFEditor_Width;
const int IFEditor_ExpandBar_H_Pixel = 24;
const int IFEditor_ExpandBar_H_InMainWin = IFEditor_ExpandBar_H_Pixel * MAX_COORD / 768;

const std::string IFEditor_NonSingletonImage_FileName("ifeditor_nonsingleton_A.png");
const std::string IFEditor_NonSingletonSelImage_FileName("ifeditor_nonsingleton_B.png");
const std::string IFEditor_SingletonImage_FileName("ifeditor_singleton_A.png");
const std::string IFEditor_SingletonSelImage_FileName("ifeditor_singleton_B.png");
const std::string IFEditor_NonExpandImage_FileName("ifeditor_nonsingleton_A.png");
const std::string IFEditor_NonExpandSelImage_FileName("ifeditor_nonsingleton_B.png");
const std::string IFEditor_ExpandImage_FileName("ifeditor_singleton_A.png");
const std::string IFEditor_ExpandSelImage_FileName("ifeditor_singleton_B.png");
const std::string IFEditorItemImage_FileName("decl_origin.png");
const std::string IFEditorSelItemImage_FileName("decl_selected.png");

const int Default_IFEditor_W_InMainWin = IFEditor_Width * MAX_COORD / 1366;
const int Default_IFEditor_H_InMainWin = IFEditor_Heigth * MAX_COORD / 768;

#endif // DIFEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
