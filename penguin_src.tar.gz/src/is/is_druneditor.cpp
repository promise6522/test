/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/
#include <boost/lexical_cast.hpp>

#include "is_druneditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"
#include "is_dstorageeditor.h"
#include "is_darrayeditor.h"
#include "is_dbyteseditor.h"

#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_string.h"

DRunEditor::DRunEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */)
    : DEditor(model, pMainWin, parent),
      m_layer(1),
      m_blank(MAX_COORD),
      m_layerHeight(RunEditor_Layer),
      m_storage_hif(NB_INTERFACE_NONE)
{
    setObjectName(RunEditor_ObjName);
    m_menuEdgePair.first.reset();
    assert(pMainWin != NULL);    
}

DRunEditor::DRunEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */)
    : DEditor(title, model, pMainWin, parent),
      m_layer(1),
      m_blank(MAX_COORD),
      m_layerHeight(RunEditor_Layer),
      m_storage_hif(NB_INTERFACE_NONE)
{
    setObjectName(RunEditor_ObjName);
    m_menuEdgePair.first.reset();
    assert(pMainWin != NULL);
}

DRunEditor::~DRunEditor()
{
}

void DRunEditor::initRunEditor()
{
    DFrame* pFrame = getBodyFrame();
    assert(NULL != pFrame);

    registerEvent(DEvent::None);
    setEventRoutine(DEvent::None,
                    this,
                    static_cast<EventRoutine>(&DRunEditor::onResult));

   
    pFrame->setFrameStyle(DFrame::Panel);
    pFrame->setFocusAttr(true);
    pFrame->registerEvent(DEvent::Drag);
    pFrame->setEventRoutine(DEvent::Drag,
                            this,
                            static_cast<EventRoutine>(&DRunEditor::onDnDDrag));
    pFrame->registerEvent(DEvent::DnD_Release);
    pFrame->setEventRoutine(DEvent::DnD_Release,
                            this,
                            static_cast<EventRoutine>(&DRunEditor::onDnDRelease));
    
    m_ptrHeadFrame->setHideProperty(true);
     
    initCmdInTail();

    initItemsInBody();
    dumpExecuteInfo();
}

void DRunEditor::initCmdInTail()
{
    // clear button
    DImage clearImg;
    clearImg.load(getResPath() + Editor_ClearImg_FileName);
    clearImg.setXScale(DImage::Stretch);
    clearImg.setYScale(DImage::Stretch);
    clearImg.setRelation(DImage::Disrelated);
    DImage clearSelImg;
    clearSelImg.load(getResPath() + Editor_ClearSelImg_FileName);
    clearSelImg.setXScale(DImage::Stretch);
    clearSelImg.setYScale(DImage::Stretch);
    clearSelImg.setRelation(DImage::Disrelated);

    m_ptrClear.reset(new(std::nothrow) DButton("",
                clearImg,
                clearSelImg,
                m_ptrTailFrame.get()));
    assert(m_ptrClear.get() != NULL);
    m_ptrClear->setGeometry(RunEditor_Clear_X_InHead, RunEditor_Clear_Y_InHead,
            RunEditor_Clear_W_InHead, RunEditor_Clear_H_InHead);
    m_ptrClear->setBackgroundColor(Duke_Transparent_Color);
    m_ptrClear->registerEvent(DEvent::DnD_Start, true);
    //m_ptrClear->registerEvent(DEvent::Drag, true);
    m_ptrClear->registerEvent(DEvent::DnD_Release, true);
    m_ptrClear->registerEvent(DEvent::Detail, true);
    m_ptrClear->registerEvent(DEvent::Hover);
    m_ptrClear->registerEvent(DEvent::PassingOut);
    m_ptrClear->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DRunEditor::onClear));  
    m_ptrClear->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DRunEditor::onHoverGen)); 
    m_ptrClear->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DRunEditor::onPassingOutGen)); 
    m_ptrClear->setSelected(false);

    // run button
    DImage runImg;
    runImg.load(getResPath() + Editor_RunImg_FileName);
    runImg.setXScale(DImage::Stretch);
    runImg.setYScale(DImage::Stretch);
    runImg.setRelation(DImage::Disrelated);
    DImage runSelImg;
    runSelImg.load(getResPath() + Editor_RunSelImg_FileName);
    runSelImg.setXScale(DImage::Stretch);
    runSelImg.setYScale(DImage::Stretch);
    runSelImg.setRelation(DImage::Disrelated);

    m_ptrRun.reset(new(std::nothrow) DButton("",
                runImg,
                runSelImg,
                m_ptrTailFrame.get()));
    assert(m_ptrRun.get() != NULL);
    m_ptrRun->setGeometry(RunEditor_Run_X_InHead, RunEditor_Run_Y_InHead,
            RunEditor_Run_W_InHead, RunEditor_Run_H_InHead);
    m_ptrRun->setBackgroundColor(Duke_Transparent_Color);
    m_ptrRun->registerEvent(DEvent::DnD_Start, true);
    //m_ptrRun->registerEvent(DEvent::Drag, true);
    m_ptrRun->registerEvent(DEvent::DnD_Release, true);
    m_ptrRun->registerEvent(DEvent::Detail, true);
    m_ptrRun->registerEvent(DEvent::Hover);
    m_ptrRun->registerEvent(DEvent::PassingOut);
    m_ptrRun->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DRunEditor::onRun));  
    m_ptrRun->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DRunEditor::onHoverGen)); 
    m_ptrRun->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DRunEditor::onPassingOutGen)); 
    m_ptrRun->setSelected(false);
}

void DRunEditor::initItemsInBody()
{
    if (!m_ptr || !m_ptr->is_execute()) {
        releaseMedia();
        return;
    }

    duke_media_execute *pRunMedia = dynamic_cast<duke_media_execute *>(m_ptr);
 
    // get name & icon
    pRunMedia->get_name(m_dukeName);
    pRunMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // get all nodes
    std::vector<duke_media_node> nodes;
    pRunMedia->get_media_nodes(nodes);
    LOG_DEBUG("node size = " << nodes.size());

    // get layer, blank and layerHeight
    int layer = 1;
    int layerHeight, blank, intervalX, intervalY;
    layerHeight = RunEditor_Layer;
    intervalX = MAX_COORD / nodes.size();

    // set declaration node
    for (size_t i = 0; i < nodes.size() - 2; ++i ) {
        if (!nodes[i+1].is_object_node())
            layer++;
        if (layerHeight*layer > RunEditor_Total_Layer) 
            layerHeight = RunEditor_Total_Layer / layer;
        blank = (MAX_COORD-layer*layerHeight) / (layer+1);
        intervalY = (blank+layerHeight) / 2;

        DPoint pos(intervalX * (i + 1), 
                intervalY + (blank + layerHeight) * (layer-1));
        if (nodes[i + 1].is_object_node())
            addWidgetToEditor(pos,
                              createWidget(nodes[i+1].m_inputs[0], false));
        else
            addWidgetToEditor(pos,
                              createWidget(nodes[i+1].m_hdecl, true, nodes[i+1].m_hOwnerIf));
    }

    // set paths
    std::vector<duke_media_path> paths;
    pRunMedia->get_media_paths(paths);
    for (size_t i = 0; i < paths.size(); ++i ) {
        int outWidgetIdx = getIndexByNodeName(paths[i].m_onode);
        int inWidgetIdx = getIndexByNodeName(paths[i].m_inode);
        if ( ((outWidgetIdx < 0) && (paths[i].m_onode != "input_node"))
            || ((inWidgetIdx < 0) && (paths[i].m_onode != "output_node")) ) 
            continue;
        
        if(outWidgetIdx > static_cast<int>(m_runWidgets.size())
           || inWidgetIdx > static_cast<int>(m_runWidgets.size()))
            continue;   

        DFunc *pOutFunc = dynamic_cast<DFunc *>(m_runWidgets[outWidgetIdx].get());
        if (pOutFunc != NULL) {
            DFunc * pInFunc = NULL;
            if (paths[i].m_inode == "output_node") {
                // TODO
            } else {
                assert(inWidgetIdx >= 0);
                pInFunc = dynamic_cast<DFunc *>(m_runWidgets[inWidgetIdx].get());
            }
            if (pInFunc != NULL) {
                pOutFunc->connect(paths[i].m_oport, pInFunc, paths[i].m_iport);
            }
            continue;
        }

        DObjIcon * pOutObj = dynamic_cast<DObjIcon *>(m_runWidgets[outWidgetIdx].get());
        if (pOutObj != NULL) {
            DFunc *pInFunc = dynamic_cast<DFunc *>(m_runWidgets[inWidgetIdx].get());
            if (pInFunc != NULL) {
                pOutObj->connect(pInFunc, paths[i].m_iport);
            }
            continue;
        }
    }    

    //restore node pos
    duke_media_handle runMediaHandle = pRunMedia->get_handle();
    if (duke_media_handle_null != runMediaHandle)
    {   
        std::vector<node_info> vNodeInfo;
        duke_media_get_hattr_node(runMediaHandle, vNodeInfo);

        for (unsigned int index = 0; index < vNodeInfo.size() && index < m_runWidgets.size(); ++index)
        {
            m_runWidgets[index]->setGeometry(vNodeInfo[index].x,
                                             vNodeInfo[index].y,
                                             vNodeInfo[index].w,
                                             vNodeInfo[index].h);
        }
    }
 
    updateEdgesPos();
    updateAll();
}

void DRunEditor::reload()
{
    LOG_DEBUG("DRunEditor:: ...............reload ......");

    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) 
    {
        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget((*it).get());
        if(pEditor != NULL)
        {
            m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
            eraseSubEditor(pEditor);        
        }

        // Check if the widget is func
        DFunc* pSrcFunc = dynamic_cast<DFunc *>((*it).get()); 
        if (NULL != pSrcFunc) 
        {
            pSrcFunc->clearAllEdges();
            getBodyFrame()->detachChildWidget(pSrcFunc);
        } 

        // Check if the widget is object
        DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>((*it).get()); 
        if (NULL != pSrcObj) 
        {
            pSrcObj->clearAllEdges();
            pSrcObj->deleteTextLabel();
            getBodyFrame()->detachChildWidget(pSrcObj);
        }
    }
    m_runWidgets.clear();

    m_layer = 0;
    m_blank = MAX_COORD;
    m_layerHeight = RunEditor_Layer;
    setMediaByHandle(m_handle);
    initItemsInBody();
}

int DRunEditor::getIndexByNodeName(const std::string & name)
{
    std::string indexStr = name.substr(name.find_last_of("_") + 1);
    try {
        return boost::lexical_cast<int>(indexStr);
    } catch (boost::bad_lexical_cast &) {
        return -1;
    }
}

void DRunEditor::duplicateItemsByHandle(const duke_media_handle& hrun)
{
    if (!hrun.is_execute()) {
        assert("Invalid execute handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();
        
    duke_media_execute* pRunMedia =
        new(std::nothrow) duke_media_execute(this->getApplication()->get_host_committer_id(), getApplication()->username());
    pRunMedia->copy(hrun);
    m_ptr = pRunMedia;
    m_handle = pRunMedia->get_handle();
    assert(m_ptr != NULL);    
}

int DRunEditor::inLayer(int height, int layer)
{
    int layerHeight = RunEditor_Layer;
    if (layerHeight*layer > RunEditor_Total_Layer) 
        layerHeight = RunEditor_Total_Layer / layer;
    int totalBlank = MAX_COORD - layer * layerHeight;
    int blank = totalBlank / (layer + 1);

    int temp = height / (layerHeight + blank); 
    return (temp >= layer) ? (layer - 1) : temp; 
}

void DRunEditor::addWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget)
{
    if (!ptrWidget)
        return;

    bool upFlag = 0;
    if (ptrWidget->getMedia()->is_declaration() && dynamic_cast<DFunc*>(ptrWidget.get())
        && m_layer < RunEditor_Layer_Max) {
        ++m_layer;
        upFlag = 1;
    }

    if (RunEditor_Layer*m_layer > RunEditor_Total_Layer) 
        m_layerHeight = RunEditor_Total_Layer / m_layer;

    m_blank = (MAX_COORD - m_layer*m_layerHeight) / (m_layer+1);
    int layer = inLayer(pt.y(), m_layer);
    if (dynamic_cast<DFunc *>(ptrWidget.get()))
        ptrWidget->setGeometry(pt.x(),
                m_blank*(layer+1) + m_layerHeight*layer,
                ptrWidget->geometry().width(),
                m_layerHeight);

    DObjIcon * pObj = dynamic_cast<DObjIcon *>(ptrWidget.get()); 
    if (NULL != pObj) {
        pObj->setGeometry(pt.x(),
                m_blank*(layer+1) + m_layerHeight*layer,
                750,
                m_layerHeight);
    } else if (upFlag) {
        // update all layers
        for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
            DWidget * pWidget = (*it).get();
            assert(pWidget != NULL);

            DRect old = pWidget->geometry();
            int layer = inLayer(old.y()+old.height()/2, m_layer-1);
            old.setTop(m_blank*(layer+1) + m_layerHeight*layer);
            old.setBottom((m_blank+m_layerHeight)*(layer+1));
            pWidget->setGeometry(old);
        }
    }

    m_runWidgets.push_back(ptrWidget);
}

DWidgetPtr DRunEditor::createWidget(const duke_media_handle &h, bool bCreateFunc,
                                        const duke_media_handle& hFuncOwnerIf/* = NB_INTERFACE_NONE*/)

{
     DWidgetPtr ptrWidget;
    if(h.is_object_exec_iterator() || h.is_object_exec_condition())
    {
         ptrWidget.reset(new(std::nothrow) DFunc(h, getBodyFrame()));
         DFunc* pFunc = static_cast<DFunc*>(ptrWidget.get());
         if(h.is_object_exec_iterator())
         {
            pFunc->setBodyColor(ImplEditor_Iterator_Color);
         }
         else if(h.is_object_exec_condition())
         {
            pFunc->setBodyColor(ImplEditor_Condition_Color);
         }
    }
    else if (h.is_declaration() && bCreateFunc) 
    {   
        ptrWidget.reset(new(std::nothrow) DFunc(h, hFuncOwnerIf, getBodyFrame()));
    }
    else if ((h.is_object() || h.is_object_container_des()) && !h.is_access())
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultObj_FileName);
        ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, getBodyFrame()));
        if (h.is_object_builtin())
        {
            // set value of built-in obj
            std::string val;
            ptrWidget->getMediaValue(val);
            dynamic_cast<DObjIcon *>(ptrWidget.get())->setTextContent(val);
        }
    }
    else if (h.is_access())
    {
        DImage img;
        img.setRelation(DImage::KeepSmall);
        setImageDataByHandle(img, h,
                             ImplEditor_DefaultAccess_FileName);
        ptrWidget.reset(new(std::nothrow) DObjIcon("", img, h, 
                    static_cast<DWidget *>(getBodyFrame())));
    }
    else
    {
        //assert(!"Unsupport type be draged to runeditor.");
        return ptrWidget;
    }    
    //register event handle
    ptrWidget->registerEvent(DEvent::Hover);
    ptrWidget->registerEvent(DEvent::PassingOut);
    ptrWidget->setEventRoutine(DEvent::Hover,
                               this,
                               static_cast<EventRoutine>(&DRunEditor::onHoverChild)); 
    ptrWidget->setEventRoutine(DEvent::PassingOut,
                               this,
                               static_cast<EventRoutine>(&DRunEditor::onPassingOutChild)); 
    ptrWidget->registerEvent(DEvent::DnD_Start);
    ptrWidget->setEventRoutine(DEvent::DnD_Start,
                             this,
                             static_cast<EventRoutine>(&DRunEditor::onDnDStart));
 
    ptrWidget->setFocusAttr(true);
    ptrWidget->registerEvent(DEvent::Delete);
    ptrWidget->setEventRoutine(DEvent::Delete,
                             this,
                             static_cast<EventRoutine>(&DRunEditor::onDeleteWidget));
    ptrWidget->registerEvent(DEvent::Activate);

    if(h.is_declaration() && bCreateFunc)
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DRunEditor::onActivateFunc));
    }
    else if(h.is_object()) 
    {
        ptrWidget->setEventRoutine(DEvent::Activate,
                                   this,
                                   static_cast<EventRoutine>(&DRunEditor::onActivateObj));
    }

    return ptrWidget;

}

int DRunEditor::getIndexByWidget(DWidget* pWidget)
{
    RunWidgetsIdx idx = 0;

    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
        if( (*it).get() == pWidget)
            return idx;
        ++idx;
    }

    return -1;
}

void DRunEditor::onDnDStart(const DEvent &event)
{
    LOG_DEBUG("DRunEditor::onDnDStart ===========");

    m_dragPoint = event.getEventPosition();
}

void DRunEditor::onDeleteWidget(const DEvent& rEvent)
{
    LOG_DEBUG("-------------DRunEditor::onDeleteWidget");

    const std::vector<DPath>& childPath = rEvent.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget *>(pObject); 
    if (NULL == pSrcWidget)
        return;

    // Check if the widget is func
    DFunc* pSrcFunc = dynamic_cast<DFunc *>(pObject); 
    if (NULL != pSrcFunc) {
        if(m_menuEdgePair.first.get() != NULL)
        {
            OutPEItems outPort = pSrcFunc->getOutPorts();
            for (OutPEItemIt it = outPort.begin(); it != outPort.end(); ++it) 
            {
            
                for (EIt eIt = it->second.begin(); eIt != it->second.end(); ++eIt) {
                    if (*eIt == m_menuEdgePair.second) {
                        deletePopupMenuAndEdge();
                        it = --outPort.end();
                        break;
                    }
                }        
            }

            if(m_menuEdgePair.second->sourceWidget() == pObject)
                deletePopupMenuAndEdge();
        }

        pSrcFunc->clearAllEdges();
        getBodyFrame()->detachChildWidget(pSrcFunc);
    }

    // Check if the widget is object
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>(pObject); 
    if (NULL != pSrcObj) {
        if(m_menuEdgePair.first.get() != NULL)
        { 
            EItems items = pSrcObj->outEdges();
            for(EIt iter = items.begin(); iter != items.end(); ++iter)\
            {
                if(*iter == m_menuEdgePair.second)
                {
                    deletePopupMenuAndEdge();
                    break;
                }

            }
        }

        pSrcObj->clearAllEdges();
        pSrcObj->deleteTextLabel();
        getBodyFrame()->detachChildWidget(pSrcObj);
    }

    //delete subEditor if there is
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    if(pEditor != NULL)
    {
        pEditor->destorySubEditors(rEvent.getCon());
        pEditor->destory(rEvent.getCon());
        eraseSubEditor(pEditor);        
    }

    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
        if (it->get() == pSrcWidget) {
            m_runWidgets.erase(it);
            break;
        }
    }
    for (RunWidgetsIt it = m_resWidgets.begin(); it != m_resWidgets.end(); ++it) {
         if (it->get() == pSrcWidget) {
            m_resWidgets.erase(it);
            break;
         }
    }
    for (ResultWidgetsIt iter = m_resPairs.begin(); iter != m_resPairs.end(); ++iter) {
        if (iter->first.get() == pSrcWidget) {
            m_resPairs.erase(iter);
            break;
        }
    }

    // repaint
    updateAll();
    repaint(rEvent.getCon());

    //save & synchronize
    //dynamic_cast<duke_media_execute *>(m_ptr)->clear();
    //saveNodesInfo();
    m_pMainWin->synchronizeEditors(rEvent.getCon(), this);
}

void DRunEditor::onDnDDrag(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onDnDDrag");

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DropCursor);
    }
    
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DPort* pSrcPort = dynamic_cast<DPort*>(pObject); 
    if (pSrcPort == NULL)
        return;

    EItems edges;
    if (dynamic_cast<DFunc*>(pSrcPort->parent()))
        edges = dynamic_cast<DFunc*>(pSrcPort->parent())->getEdgesFromOutPort(pSrcPort);
    else if (dynamic_cast<DObjIcon*>(pSrcPort->parent()))
        edges = dynamic_cast<DObjIcon*>(pSrcPort->parent())->outEdges();
    else
        return;

    for (EIt eIt = edges.begin(); eIt != edges.end(); eIt++) {
        if (NULL != eIt->get() && NULL == eIt->get()->targetWidget()) {
            eIt->get()->setTargetParentCoord(event.getEventPosition());
            eIt->get()->updateAll();
            eIt->get()->repaint(event.getCon());
        }
    }
}

void DRunEditor::updateEdgesPos()
{
    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc* pFuncWidget = dynamic_cast<DFunc *>(pWidget);
        if (NULL != pFuncWidget) {
            pFuncWidget->updateEdgesPos();
            continue;
        } 

        DObjIcon *pObjWidget = dynamic_cast<DObjIcon *>(pWidget);
        if (NULL != pObjWidget)
            pObjWidget->updateEdgePos();
    }
    for (RunWidgetsIt it = m_resWidgets.begin(); it!= m_resWidgets.end(); ++it) {
        DWidget * pWidget = (*it).get();
        assert(pWidget != NULL);

        DFunc* pFuncWidget = dynamic_cast<DFunc *>(pWidget);
        if (NULL != pFuncWidget) {
            pFuncWidget->updateEdgesPos();
            continue;
        } 

        DObjIcon *pObjWidget = dynamic_cast<DObjIcon *>(pWidget);
        if (NULL != pObjWidget)
            pObjWidget->updateEdgePos();

    }
}

void DRunEditor::onDnDRelease(const DEvent &event)
{
    LOG_DEBUG("DRunEditorRelase---------------");
    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
       
    // if the draged widget is edge, return
    if (dynamic_cast<DEdge*>(pObject))
        return;

    // if the draged widget is this editor
    DDialog* pDlg = dynamic_cast<DDialog *>(pObject);
    if (NULL != pDlg)
    {
        dialogRelease(event);
        return;        
    }

    // if the draged widget is port
    DPort* pSrcPort = dynamic_cast<DPort*>(pObject); 
    if (pSrcPort != NULL) {
        portRelease(event, pSrcPort);
    }

    // if the draged widget is function
    DFunc* pSrcFunc = dynamic_cast<DFunc* >(pObject);
    if (NULL != pSrcFunc) {
        funcRelease(event, pSrcFunc);
    }

    // if the draged widget is object 
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon* >(pObject);
    if (NULL != pSrcObj) {
        objRelease(event, pSrcObj);
    }

    // create widget for duke object
    DButton* pSrcWidget = dynamic_cast<DButton *>(pObject);
    if ( pSrcWidget)
    {
        duke_media_handle handle = pSrcWidget->getMediaHandle();
        
        if (handle.is_object() || handle.is_object_container_des()) 
        {
            if (get_media_handle_status(handle) == e_handle_core)
            {
                addWidgetToEditor(event.getEventPosition(), 
                                  createWidget(pSrcWidget->getMediaHandle(), false));        
            }
            else if((handle.is_object_array()  || handle.is_object_map() || 
                     handle.is_object_string() || handle.is_object_bytes()))
            {
                addWidgetToEditor(event.getEventPosition(), 
                                  createWidget(pSrcWidget->getMediaHandle(), false));
            }   
        }
    }

    // repaint
    updateEdgesPos();
    updateAll();
    repaint(event.getCon());

    // repaint all sub editors
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);

    // save nodes and paths and synchronization
    //dynamic_cast<duke_media_execute *>(m_ptr)->clear();
    //saveNodesInfo();
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DRunEditor::portRelease(const DEvent& rEvent, DPort* pSrcPort)
{
    if (NULL == pSrcPort)
        return;

    if(m_menuEdgePair.first.get() != NULL)
    {
        if(typeid(*(m_menuEdgePair.second->sourceWidget())) == typeid(*pSrcPort))
        {
           deletePopMenu(rEvent);
        }
    }

    DEdgePtr ptrEdge;
    duke_media_handle interfaceHandle = duke_media_handle_null;
    duke_media_handle_vector vDeclarationHandle;

    // If the parent of the port is func
    DFunc* pFunc = dynamic_cast<DFunc*>(pSrcPort->parent());
    if (NULL != pFunc) {
        int height = pFunc->geometry().height();
        if (rEvent.getEventPosition().y() <= pFunc->geometryY() + height)
        {
            ptrEdge = pFunc->getSuspendEdge(pSrcPort);
            if (NULL == ptrEdge.get())
                return;
            pFunc->deleteEdgeFromOutPort(pSrcPort, ptrEdge.get());
            updateAll();
            repaint(rEvent.getCon());
            return;
        }

        if (!pSrcPort->getMedia()) {
            pFunc->clearEdgesFromOutPort(pSrcPort);
            updateAll();
            repaint(rEvent.getCon());
            return;
        }

        interfaceHandle = pSrcPort->getMediaHandle();

        if (interfaceHandle.is_object_array())
        {
            duke_media_array harr(interfaceHandle);
            harr.get_interface(interfaceHandle);
        }
        if (interfaceHandle.is_storage())
        {
            //duke_logic_storage hstor(interfaceHandle, "");
            duke_media_storage hstor(interfaceHandle);
            hstor.get_interface(interfaceHandle);
        }
        duke_media_get_declarations_by_interface(interfaceHandle, vDeclarationHandle);
        if (interfaceHandle == duke_media_handle_null ||
                vDeclarationHandle.size() == 0) {
            pFunc->clearEdgesFromOutPort(pSrcPort);
            updateAll();
            repaint(rEvent.getCon());
            return;
        }

        ptrEdge = pFunc->getSuspendEdge(pSrcPort);
        if (!ptrEdge)
            return;
    } 

    // If the parent of the port is object
    DObjIcon *pObj = dynamic_cast<DObjIcon*>(pSrcPort->parent());
    if (NULL != pObj) {
        int height = pObj->geometry().height();
        if (rEvent.getEventPosition().y() <= pObj->geometryY() + height)
        {
            ptrEdge = pObj->getSuspendEdge();
            if (NULL == ptrEdge.get())
                return;

            pObj->deleteOutEdge(ptrEdge.get());
            updateAll();
            repaint(rEvent.getCon());
            return;
        }


        if (!pObj->getMedia()) {
            pObj->clearAllEdges();
            updateAll();
            repaint(rEvent.getCon());
            return;
        }

        duke_media_handle handle = pObj->getMediaHandle();        
        if(handle.is_storage())
        {
            duke_media_get_interface_by_storage(handle, interfaceHandle);
        }
        else
        {            
            duke_media_get_interface_by_object(handle, interfaceHandle, getApplication()->get_host_committer_id());
        }
        
        duke_media_get_declarations_by_interface(interfaceHandle, vDeclarationHandle);
        if (interfaceHandle == duke_media_handle_null ||
                vDeclarationHandle.size() == 0) {
            pObj->clearAllEdges();
            updateAll();
            repaint(rEvent.getCon());
            return;
        }

        ptrEdge = pObj->getSuspendEdge();
        if (!ptrEdge)
            return;

        //store storage interface
        if(handle.is_storage())
        {            
            dynamic_cast<duke_media_storage *>(pObj->getMedia())->get_compound_interface(m_storage_hif);
        }        
    }

    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    if (NULL != ptrPopupMenu.get())
        deletePopupMenuAndEdge();

    ptrPopupMenu.reset(new DPopupMenu(getBodyFrame()));
    assert(NULL != m_ptrPopupMenu.get());
    ptrPopupMenu->setGeometry(rEvent.getEventPosition().x(), 
            rEvent.getEventPosition().y(), 
            1600, 
            (vDeclarationHandle.size() >= PopupMenu_Item_Size) ? 
            4000 : 4000*vDeclarationHandle.size()/PopupMenu_Item_Size);
    ptrPopupMenu->setFocusAttr(true);
    ptrPopupMenu->registerEvent(DEvent::Focus);
    ptrPopupMenu->registerEvent(DEvent::Blur);
    ptrPopupMenu->setEventRoutine(DEvent::Blur,
            this,
            static_cast<EventRoutine>(&DRunEditor::onMenuBlur));

    for (duke_media_handle_size_type index = 0; 
            index < vDeclarationHandle.size(); 
            ++index) {
        std::string handleName;
        duke_media_get_name(vDeclarationHandle[index], handleName);

        if(vDeclarationHandle[index].is_instruction_general())
        {
            handleName = "[G] "+handleName;
        }
        ptrPopupMenu->insertItem(handleName, index, vDeclarationHandle[index]);
        ptrPopupMenu->connectItem(index, 
                this,         
                static_cast<EventRoutine>(&DRunEditor::onSelectDeclaration));
    }
    ptrPopupMenu->updateMenu();

    assert(NULL != ptrEdge.get());
    m_menuEdgePair.first = ptrPopupMenu;
    m_menuEdgePair.second = ptrEdge;
}

void DRunEditor::onSelectDeclaration(const DEvent& rEvent)
{
    const std::vector<DPath>& eventPath = rEvent.getEventPath();
    DObject* pSelectObject = findChild(eventPath[0]);
    DMenuItem* pSelectItem = dynamic_cast<DMenuItem* >(pSelectObject);
    if (NULL == pSelectItem)
        return;

    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    DEdgePtr ptrEdge = m_menuEdgePair.second;
    DRect rect = ptrEdge->geometry();

    DWidgetPtr ptrWidget;
    duke_media_handle hOwnerIf;
    
    // we need special work to get FUNC_INTERFACE_CONVERT's owner interface
    if(pSelectItem->getMediaHandle().get_func_type() == NB_FUNC_INTERFACE_CONVERT)
    {
        if(!getConvertInterface(ptrEdge, hOwnerIf))        
            return;
    }
    else
    {
        // for normal decl, we trace the owner interface from the edge
        DPort* pSrcPort = dynamic_cast<DPort*>(ptrEdge->sourceWidget());
        assert(pSrcPort);
        hOwnerIf = pSrcPort->getMediaHandle();
    }

    // create DFunc for the selected declaration
    ptrWidget = createWidget(pSelectItem->getMediaHandle(), true, hOwnerIf);
    addWidgetToEditor(ptrPopupMenu->geometryPos(), ptrWidget); 
   
    DFunc *pFunc = dynamic_cast<DFunc *>(ptrWidget.get());
    if (pFunc)
        pFunc->setEdgeToInPort(ptrEdge, 0);

    if (NULL != ptrPopupMenu.get()) {
        getBodyFrame()->detachChildWidget(ptrPopupMenu.get());
        m_menuEdgePair.first.reset();
    }

    updateEdgesPos();
    updateAll();
    repaint(rEvent.getCon());

    updateSubEditors();
    repaintSubEditors(rEvent.getCon(), false);

    // save nodes and paths and synchronization
    //dynamic_cast<duke_media_execute *>(m_ptr)->clear();
    //saveNodesInfo();
    m_pMainWin->synchronizeEditors(rEvent.getCon(), this);
}

void DRunEditor::funcRelease(const DEvent& rEvent, DFunc* pSrcFunc)
{
    if (!pSrcFunc || pSrcFunc->parent() != getBodyFrame())
        return;

    // source widget be from this editor
    DPoint releasePos = rEvent.getEventPosition();
    DPoint adjustPos;
    DRect funcRect = pSrcFunc->geometry();

    adjustPos.setX(releasePos.x() - m_dragPoint.x() * funcRect.width() / 10000);
    adjustPos.setY(releasePos.y() - m_dragPoint.y() * funcRect.height() / 10000);

    int layer = inLayer(adjustPos.y() + m_layerHeight/2, m_layer);
    adjustPos.setY(m_blank*(layer+1) + m_layerHeight*layer);

    if (!pSrcFunc->checkPos(adjustPos, m_layerHeight))
        return;

    pSrcFunc->move(adjustPos);
}

void DRunEditor::objRelease(const DEvent& rEvent, DObjIcon* pSrcObj)
{
    if (!pSrcObj || pSrcObj->parent() != getBodyFrame())
        return;

    // source widget be from this editor
    DPoint releasePos = rEvent.getEventPosition();
    DPoint adjustPos;
    DRect objRect = pSrcObj->geometry();

    adjustPos.setX(releasePos.x() - m_dragPoint.x() * objRect.width() / 10000);
    adjustPos.setY(releasePos.y() - m_dragPoint.y() * objRect.height() / 10000);

    int layer = inLayer(adjustPos.y() + m_layerHeight/2, m_layer);
    adjustPos.setY(m_blank*(layer+1) + m_layerHeight*layer);

    if (!pSrcObj->checkPos(adjustPos, m_layerHeight))
        return;

    pSrcObj->move(adjustPos);
}

void DRunEditor::dialogRelease(const DEvent& rEvent)
{
    DPoint releasePos = rEvent.getEventPosition();
    
    DPoint adjustPos;
    DRect editorRect = geometry();

    adjustPos.setX(releasePos.x() * editorRect.width() / 10000 + editorRect.x());
    adjustPos.setY(releasePos.y() * editorRect.height() / 10000 + editorRect.y());

    DEvent& eventRef = const_cast<DEvent &>(rEvent);
    eventRef.setEventPosition(adjustPos);
    assert(NULL != m_pMainWin);
    m_pMainWin->onDnDRelease(rEvent); 
}

void DRunEditor::deletePopupMenuAndEdge()
{
    DPopupMenuPtr ptrPopupMenu = m_menuEdgePair.first;
    if (ptrPopupMenu) {
        getBodyFrame()->detachChildWidget(ptrPopupMenu.get());
        m_menuEdgePair.first.reset();
    }

    DEdgePtr ptrEdge = m_menuEdgePair.second;
    if (!ptrEdge)
        return;

    DWidget* pSourceWidget = ptrEdge->sourceWidget();
    DPort* pSrcPort = dynamic_cast<DPort *>(pSourceWidget);
    if (NULL == pSrcPort)
        return;
    DObject* pObject = pSrcPort->parent();

    DFunc* pFunc = dynamic_cast<DFunc *>(pObject);
    if (NULL != pFunc) {
        DWidget* pTargetWidget = ptrEdge->targetWidget();
        if (!pTargetWidget)
            pFunc->deleteEdgeFromOutPort(pSrcPort, ptrEdge.get());
        return;
    }

    DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pObject);
    if (NULL != pObjIcon) { 
        pObjIcon->deleteOutEdge(ptrEdge.get());
    }
}

void DRunEditor::onMenuBlur(const DEvent& rEvent)
{
    LOG_DEBUG("-------------no menupassOut");

    deletePopupMenuAndEdge();

    // repaint
    updateAll();
    repaint(rEvent.getCon());
}

void DRunEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onHoverBtn");

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    for(ResultWidgetsIt it = m_resPairs.begin(); it != m_resPairs.end(); ++it)
    {
        if(it->first.get() == pSrcWidget)
        {
            std::string strTip;
            if(getValueByHandle(it->second, strTip))
            {
                getApplication()->tip()->add(pSrcWidget, strTip, event.getCon());

            }
            else{
                getApplication()->tip()->add(pSrcWidget, 
                    pSrcWidget->strPath(),
                    event.getCon());
            }
            return;
        }
    }
    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip)) {
        if (pSrcWidget->getMedia()->is_object_builtin()) {
            if (pSrcWidget->getMedia()->is_object_bytes()) {
                strTip = "btyes";
            }
            else {
                std::string val;
                pSrcWidget->getMediaValue(val);
                strTip = strTip + " " + val; 
            }
       }
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    } else {
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    }
}

void DRunEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onPassingOut");

    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DRunEditor::saveNodesInfo()
{
    nb_id_t impl_id;
    if(generate_runnable_impl(impl_id))
    {
        getApplication()->run_impl(this, impl_id);
    }
    else
    {
        LOG_ERROR("It is not a valid implementation.");
    }
}

DWidgetPtr DRunEditor::createResultWidget(const duke_media_handle &h)
{
    DWidgetPtr ptrWidget;

    if (!h.is_object() && !h.is_bridge_interface())
        return ptrWidget;
    DImage image;
    image.setRelation(DImage::KeepSmall);
    setResultImage(image, h, RunEditor_DefaultObj_FileName);

    ptrWidget.reset(new(std::nothrow) DObjIcon("", image,
                static_cast<DWidget *>(getBodyFrame())));

    dynamic_cast<DObjIcon *>(ptrWidget.get())->deleteOutPort();
    ptrWidget->setFocusAttr(true);
    ptrWidget->registerEvent(DEvent::Hover);
    ptrWidget->registerEvent(DEvent::PassingOut);
    ptrWidget->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DRunEditor::onHoverChild)); 
    ptrWidget->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DRunEditor::onPassingOutChild)); 
    ptrWidget->registerEvent(DEvent::DnD_Start);
    ptrWidget->setEventRoutine(DEvent::DnD_Start,
            this,
            static_cast<EventRoutine>(&DRunEditor::onDnDStart));
    ptrWidget->registerEvent(DEvent::Delete);
    ptrWidget->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DRunEditor::onDeleteWidget));
    ptrWidget->registerEvent(DEvent::Activate);
    ptrWidget->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DRunEditor::onActivateResultObj));
    
    m_resPairs.push_back(std::make_pair(ptrWidget,h));

    return ptrWidget;
}

void DRunEditor::pushResultWidgetToEditor(const DPoint &pt, DWidgetPtr ptrWidget)
{
    if (!ptrWidget || !dynamic_cast<DObjIcon *>(ptrWidget.get()))
        return;

    int layer = inLayer(pt.y(), m_layer);
    if (pt.y() > (m_layerHeight+m_blank)*m_layer) {
        m_layer++;
        if (RunEditor_Layer*m_layer > RunEditor_Total_Layer) 
            m_layerHeight = RunEditor_Total_Layer / m_layer;
        m_blank = (MAX_COORD - m_layer*m_layerHeight) / (m_layer+1);
        layer = inLayer(pt.y(), m_layer);

        // update all layers
        for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
            DWidget * pWidget = (*it).get();
            assert(pWidget != NULL);

            DRect old = pWidget->geometry();
            int layer = inLayer(old.y()+old.height()/2, m_layer-1);
            old.setTop(m_blank*(layer+1) + m_layerHeight*layer);
            old.setBottom((m_blank+m_layerHeight)*(layer+1));
            pWidget->setGeometry(old);
        }
    }

    ptrWidget->setGeometry(pt.x(),
            m_blank*(layer+1) + m_layerHeight*layer,
            750,
            m_layerHeight);

    m_resWidgets.push_back(ptrWidget);
    //m_runWidgets.push_back(ptrWidget);
}

void DRunEditor::generateResult(duke_media_handle_vector &output)
{
    if(output.empty())
        return;
    size_t ocnt = 0;
    for (RunWidgetsIdx index = 0; index < m_runWidgets.size(); ++index) {
        DWidget * pWidget = (*(m_runWidgets.begin()+index)).get();
        assert(pWidget && pWidget->getMedia());

        if (pWidget->getMedia()->is_declaration() || pWidget->getMediaHandle().is_object_exec_iterator() 
                || pWidget->getMediaHandle().is_object_exec_condition())
        {
            DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
            if(pFunc == NULL)
                continue;
            OutPEItems out = pFunc->getOutPorts();

            if (output[0].is_exception()) {
                LOG_DEBUG("output handle[0]:"<<output[0]);
                pFunc->setBodyColor(RunEdiotr_Waring_Color);
                continue;
            } else {
                pFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
            }

            //int intervalX = MAX_COORD / (out.size() + 2);
            for (OutPEItemIdx idx = 0; idx < out.size()-1; idx++) {
                OutPEItemIt it = out.begin() + idx;
                assert(it->first.get() != NULL);
                if (it->second.size())
                    continue;

                // create output object widget 
                DWidgetPtr ptrWidget;
                if(ocnt < output.size())
                {
                    ptrWidget = createResultWidget(output[ocnt]);
                    ocnt++;
                }
                else
               {
                    LOG_DEBUG("func size > output size.");
                    return;
                }
                if(ptrWidget.get() == NULL)
                    continue;
                DPoint place = pFunc->geometry().bottomLeft();
                int space = pFunc->geometry().width() / out.size();
                //place.setX(intervalX * (idx+1));
                place.setX(place.x() + idx * space);
                place.setY(place.y() + m_blank/2);
                pushResultWidgetToEditor(place, ptrWidget); 
                //m_resWidgets.push_back(ptrWidget);
                DObjIcon *pResult = dynamic_cast<DObjIcon *>(ptrWidget.get());
                DEdgePtr ptrEdge = pFunc->createEdge(it->first.get());
                if(pResult)
                {
                    pResult->setInEdge(ptrEdge); 
                }
                else
                {
                    LOG_DEBUG("it is not a objIcon, and media handle ="
                             <<output[ocnt].str());
                }
            }
        }
    }
}

bool DRunEditor::isResultWidget(DWidget* pWidget)
{
    for (RunWidgetsIt it = m_resWidgets.begin(); it != m_resWidgets.end(); ++it) {
        DWidget* pResObj = dynamic_cast<DWidget *>((*it).get()); 
        if (pWidget == pResObj)
            return true;
    }

    return false;
}

void DRunEditor::clearResult(const DEvent& rEvent)
{
    for (RunWidgetsIdx index = 0; index < m_runWidgets.size(); ++index) {
        DWidget * pWidget = (*(m_runWidgets.begin()+index)).get();
        DFunc * pFunc = dynamic_cast<DFunc *>(pWidget);
        if (pFunc)
            pFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
    }

    for (RunWidgetsIt it = m_resWidgets.begin(); it != m_resWidgets.end(); ++it) 
    {
        DObjIcon* pResObj = dynamic_cast<DObjIcon *>((*it).get()); 
        if (NULL != pResObj) {
            pResObj->clearAllEdges();
            pResObj->deleteTextLabel();
            getBodyFrame()->detachChildWidget(pResObj);
        }

        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget(pResObj);
        if(pEditor != NULL)
        {
            pEditor->destorySubEditors(rEvent.getCon());
            pEditor->destory(rEvent.getCon());
            eraseSubEditor(pEditor);        
        }

        for (RunWidgetsIt it2 = m_runWidgets.begin(); it2 != m_runWidgets.end(); ++it2) {
            if((*it2).get() == pResObj) {
                m_runWidgets.erase(it2);
                break;
            }
        }
    }
    m_resWidgets.clear();
    m_resPairs.clear();
}

bool DRunEditor::validate()
{
    bool ret = true;

    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
        DWidget * pWidget = (*it).get();
        assert(pWidget && pWidget->getMedia());

        if (pWidget->getMedia()->is_declaration()) {

            DFunc *pFunc = dynamic_cast<DFunc *>(pWidget);
            if(pFunc == NULL)
                continue;
            InPEItems in = pFunc->getInPorts();
            for (InPEItemIdx idx = 0; idx < in.size()-1; idx++) {
                InPEItemIt it = in.begin() + idx;
                assert(it->first.get() != NULL);

                if (it != in.end()-2 && it->second.size() == 0) {
                    ret = false;
                    pFunc->setBodyColor(RunEdiotr_Waring_Color);
                    break;
                }

                pFunc->setBodyColor(FUNC_DEFAULT_BODY_COLOR);
            }
        }
    }

    return ret;
}

void DRunEditor::onClear(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onClearBtn");

    clearResult(event);

    updateAll();
    repaint(event.getCon());
}

void DRunEditor::onResult(const DEvent &event)
{
    duke_media_handle_vector handles = event.get_handles();
    LOG_DEBUG("DRunEditor get result with media handle size = "<< handles.size());
    for(std::size_t i = 0; i < handles.size(); ++i)
    {
        LOG_DEBUG("Result handle= "<<handles[i].str());
    }
    generateResult(handles);
    updateEdgesPos();
    updateAll();
    LOG_DEBUG("Duke runeditor update.");
    repaint(event.getCon());
}

void DRunEditor::onRun(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onRunBtn");
  
    if (!validate()) {
        LOG_DEBUG("DRunEditor -- Warning");

        updateAll();
        repaint(event.getCon());
        return;
    }

    clearResult(event);

    saveNodesInfo(); 

    repaint(event.getCon());
}

void DRunEditor::generateSubItems()
{
//    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) {
//        if (it->get()) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->get());
//
//            if ( it->get()->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->get()->getMediaHandle()) == Edit) ) {
//                if( it->get()->getMedia()->generate(getApplication()->username(), newh)
//                    && (newh != duke_media_handle_null) ) {
//                    it->get()->setMediaByHandle(newh);
//                }
//            }
//
//            //delete subEditor if there is
//            if (pEditor != NULL) {
//                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
//                eraseSubEditor(pEditor);        
//            }
//        }
//    }
}

void DRunEditor::onGenerate(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onGenerate");

    if(!m_resPairs.size())
        return;

    for(ResultWidgetsIt it = m_resPairs.begin(); it != m_resPairs.end(); ++it)
    {
        duke_media_save_result_by_handle(getApplication()->username(), it->second, it->first->objectName());

        save_generated_handle(it->second, getApplication()->username());
    }
}
/*
void DRunEditor::onActivateStorage(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onActivateStorage");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            pEditor->reload();
            pEditor->updateAll();
            pEditor->repaint(event.getCon());
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        return;
    }

    if (pSrcWidget->getMedia()->is_storage()) {
        // Create new ObjEditor with PanelModel
        DMainWin * pMainWin = m_pMainWin;
        DStorageEditorPtr ptrEditor(new(std::nothrow) DStorageEditor(StorageEditor_ObjName, 
                    DEditor::PanelModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        insertSubEditor(pSrcWidget, ptrEditor);
        ptrEditor->initDialog();

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_StorageEditor_W_InMainWin, 
                Default_StorageEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);

        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
        ptrEditor->initStorageEditor();
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());

        //synchronize
        m_pMainWin->synchronizeEditors(event.getCon(), this);
    } else {
        assert(!"could not reach here!");        
    }
}
*/
void DRunEditor::onActivateResultObj(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onActivateResultObj");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
       return; 
     
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        pEditor->isHide() ? pEditor->display(event.getCon()) 
            : pEditor->hide(event.getCon());
        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pInput && pEditor->isHide())
        {
            pSrcWidget->setObjectName(pInput->getInputString());
            std::string name;
            name = pSrcWidget->objectName();
            pInput->setInputString(name); 
        } 
        return;
    }
    else
    {
        DMainWin * pMainWin = m_pMainWin;
        // Get the postion in mainwin 
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        

        // Create new InputEditor
        DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        insertSubEditor(pSrcWidget, ptrEditor);
        ptrEditor->initDialog();

        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_InputEditor_W_InMainWin, 
                Default_InputEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);

        // Set initial value
        std::string name = pSrcWidget->objectName();
            ptrEditor->setInputString(name);
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    }
}

void DRunEditor::onActivateObj(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onActivateObj");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if ((pSrcWidget == NULL) || (pSrcWidget->getMedia() == NULL)
        || pSrcWidget->getMedia()->is_object_bridge()
        || pSrcWidget->getMedia()->is_access()
		|| pSrcWidget->getMediaHandle().is_function_instruction())
        return;

	duke_media_handle handle = pSrcWidget->getMediaHandle();
	
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pInput && pEditor->isHide())
        {
            pSrcWidget->setMediaValue(pInput->getInputString());
            std::string value;
            pSrcWidget->getMediaValue(value);
            pInput->setInputString(value);            
            dynamic_cast<DObjIcon *>(pSrcWidget)->setTextContent(value);
            updateAll();
            repaint(event.getCon());
        }
 
        if (pSrcWidget->getMedia()->is_object_array() 
                || pSrcWidget->getMedia()->is_object_map())
        { 
            DObjIcon* pObjIcon = dynamic_cast<DObjIcon *>(pSrcWidget);
            if (pObjIcon)
            {                
                pObjIcon->reloadObjMedia();
                DImage img;
                img.setXScale(DImage::Stretch);
                img.setYScale(DImage::Stretch);
                img.setRelation(DImage::Disrelated);                

                duke_media_array* pMedia = dynamic_cast<duke_media_array *>(pObjIcon->getMedia());
                if(pMedia)
                {
                    //change the icon
                    if(pMedia->is_expanded())
                    {
                        img.load(get_builtin_resource_path() + RunEditor_ArrayExImg_FileName);

                    }
                    else
                    {
                        img.load(get_builtin_resource_path() + RunEditor_ArrayImg_FileName);
                    }
                    pObjIcon->setImage(img);
                }

                duke_media_map* pMapMedia = dynamic_cast<duke_media_map *>(pObjIcon->getMedia());
                if(pMapMedia)
                {
                    //change the icon
                    if(pMapMedia->is_expanded())
                    {
                        img.load(get_builtin_resource_path() + RunEditor_MapExImg_FileName);
                    }
                    else
                    {
                        img.load(get_builtin_resource_path() + RunEditor_MapImg_FileName);
                    }
                    pObjIcon->setImage(img);
                }
                pObjIcon->updateAll();
                pObjIcon->repaint(event.getCon());
            }
        }
        
        return;
    }
    
    pEditor = createSubEditor(pSrcWidget);
    if(handle.is_interface() || handle.is_implementation() || handle.is_declaration())
    {
        pEditor->setReadonly();
    }
    pEditor->updateAll();
    pEditor->show(event.getCon());

}

void DRunEditor::onActivateFunc(const DEvent &event)
{
    LOG_DEBUG("--------------DRunEditor::onActivateInWidget");

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    if (pSrcWidget->getMediaHandle().is_function_instruction()
        || !pSrcWidget->getMediaHandle().is_declaration())
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor != NULL) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if (pEditor->isHide()) {
            pEditor->display(event.getCon());
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        return;
    }

    // Create new DeclEditor with PanelModel
    DMainWin * pMainWin = m_pMainWin;
    DDeclEditorPtr  ptrEditor;

    ptrEditor.reset(new(std::nothrow) DDeclEditor(PanelModel,
                                                  pMainWin,
                                                  pMainWin->getRootWidget()));
    ptrEditor->initDialog();
    insertSubEditor(pSrcWidget, ptrEditor);
    // Initialize the editor after inserting widget
    if (get_media_handle_status(pSrcWidget->getMediaHandle()) != e_handle_core)
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDeclEditor();
    ptrEditor->setReadonly();

    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                     pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                           Default_DeclEditor_W_InMainWin, 
                           Default_DeclEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());
}

void DRunEditor::dumpExecuteInfo()
{
    LOG_DEBUG("===================================");

    duke_media_execute* pRunMedia = dynamic_cast<duke_media_execute *>(m_ptr);
    if (NULL == pRunMedia) {
        LOG_DEBUG("Error: No duke media.");
        LOG_DEBUG("===================================");
        return;
    }

    //dump nodes
    std::vector<duke_media_node> nodes;
//    std::vector<duke_logic_data_node> nodes;
    pRunMedia->get_media_nodes(nodes);
    LOG_DEBUG("execute node size = "<<nodes.size());
    for (size_t i = 0; i < nodes.size(); ++i ) {
        LOG_DEBUG("\t("<<nodes[i].m_name<<") ");
    } 

    //dump paths
    std::vector<duke_media_path> paths;
    pRunMedia->get_media_paths(paths);
    LOG_DEBUG("\nexecute paths size = "<<paths.size());
    for (size_t i = 0; i < paths.size(); ++i ) {
        LOG_DEBUG("\t("<<paths[i].m_onode<<"["<<paths[i].m_oport<<"] -> " <<paths[i].m_inode<<"["<<paths[i].m_iport<<"])");
    }    

    LOG_DEBUG("===================================");
}


bool DRunEditor::generate_runnable_impl(nb_id_t& impl_id)
{
    host_committer_id_t hc_id = getApplication()->get_host_committer_id();
    duke_media_implement implMedia(hc_id, getApplication()->username());
    duke_media_handle implMediaHandle = implMedia.get_handle();

    //set this implement is general implement
    implMedia.set_general();
    
    //clear old implement
    implMedia.clear_internal_nodes();

    //sort internal node
    std::sort(m_runWidgets.begin(), m_runWidgets.end(),
              boost::bind(widgetGeometryCompare, _1, _2));

    std::vector<node_info>  vNodeInfo;
    //Save nodes except in/out ports 
    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        DEdgePtr ptrE;
        
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node with media information.");
            continue;
        }
        
        // nodeName = media name + "_" + index ( from 0 )
        // the index if the widget's index in a sorted vector
        std::string nodeName;
        pWidget->getMedia()->get_name(nodeName);
        nodeName.append("_" + boost::lexical_cast<std::string>(getIndexByWidget(pWidget)));
        
        if(dynamic_cast<DObjIcon*>(pWidget))
        {
            implMedia.add_object_node(getApplication()->get_host_committer_id(),
                                   nodeName, pWidget->getMediaHandle()); 
        }
        else if(dynamic_cast<DFunc*>(pWidget))
        {
            duke_media_handle funcOwnerIf = dynamic_cast<DFunc*>(pWidget)->getOwnerIf();
            implMedia.add_func_node(nodeName, pWidget->getMediaHandle(),funcOwnerIf);
        }

    }     
    TIMER_MARK("save nodes");

    std::size_t output_idx = 0;
    
    //save path 
    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) 
    {
        DWidget * pWidget = (*it).get();
        DEdgePtr ptrE;
        
        if (!pWidget || !pWidget->getMedia())
        {
            assert("Could not save the node with media information.");
            continue;
        }
        
        std::string dukeName;
        pWidget->getMedia()->get_name(dukeName);
        std::string nodeName = dukeName + "_" 
            + boost::lexical_cast<std::string>(getIndexByWidget(pWidget));
        
        DRect rect = pWidget->geometry();
        node_info nodeInfo;
        nodeInfo.name = nodeName;
        nodeInfo.x = rect.x();
        nodeInfo.y = rect.y();
        nodeInfo.w = rect.width();
        nodeInfo.h = rect.height();
        vNodeInfo.push_back(nodeInfo);
        if ((pWidget->getMedia()->is_object() && !pWidget->getMedia()->is_declaration()
             && !pWidget->getMediaHandle().is_implementation()
             && !pWidget->getMediaHandle().is_object_exec_iterator()
             && !pWidget->getMediaHandle().is_object_exec_condition())
             || pWidget->getMedia()->is_storage()
             || pWidget->getMedia()->is_anchor()
             || pWidget->getMedia()->is_object_container_des()
             || (pWidget->getMedia()->is_declaration() && dynamic_cast<DObjIcon*>(pWidget)))//add by tom
        {
            EItems edges = dynamic_cast<DObjIcon *>(pWidget)->outEdges();
            if (!edges.size())
                continue;

            for (EIt e_it = edges.begin(); e_it != edges.end();e_it++) 
            {
                if (NULL == e_it->get()) 
                    continue;

                DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
                if(pTargetPort == NULL)
                        continue;
                DFunc *pTargetFunc = dynamic_cast<DFunc*>(pTargetPort->parent());
            
                //get targetNodeName;
                std::string targetNodeName;                
                int targetIdx = getIndexByWidget(pTargetFunc);
                if(targetIdx < 0)
                {
                    assert(!"Could not find index according to widget pointer.");
                    continue;
                }            
                else
                {
                    std::string objName;
                    pTargetFunc->getMedia()->get_name(objName);
                    targetNodeName = objName + "_" + boost::lexical_cast<std::string>(targetIdx);
                }

                if(pTargetPort->getMediaHandle().is_interface_time_line())
                {
                    implMedia.add_time_path(nodeName, 
                                         0,
                                         targetNodeName, 
                                         pTargetFunc->getIndexByPort(pTargetPort), -4);            
                } 
                else
                {
                    implMedia.add_path(nodeName, 
                                         0,
                                         targetNodeName, 
                                         pTargetFunc->getIndexByPort(pTargetPort));            
                }
            }
        }
        else if (pWidget->getMedia()->is_declaration()
                || pWidget->getMediaHandle().is_object_exec_iterator() 
                || pWidget->getMediaHandle().is_object_exec_condition())
        {
            OutPEItems out = dynamic_cast<DFunc *>(pWidget)->getOutPorts();
            for (OutPEItemIdx idx = 0; idx < out.size(); idx++) 
            {
                OutPEItemIt it = out.begin() + idx;
                assert(it->first.get() != NULL);
                if (it->second.empty())
                {
                    //add the result
                    if (idx < out.size() - 1)
                    { 
                        implMedia.add_output_port(it->first->getMediaHandle());
                        implMedia.add_path(nodeName, idx, "output_node", output_idx++);
                    }
                    continue;
                }

                for (EIt e_it = it->second.begin(); e_it != it->second.end();e_it++)
                {
                    if (NULL == e_it->get())
                        continue;

                    DPort *pTargetPort = dynamic_cast<DPort *>(e_it->get()->targetWidget());
                    if(pTargetPort == NULL)
                        continue;
                    DFunc *pTargetFunc = dynamic_cast<DFunc*>(pTargetPort->parent());

                    //get targetNodeName;
                    std::string targetNodeName;                
                    int targetIdx = getIndexByWidget(pTargetFunc);
                    if(targetIdx < 0)
                    {
                        //try to add path related to the out ports
                        
                        assert(!"Could not find index according to widget pointer.");
                        continue;
                    }
                    else
                    {
                        std::string funcName;
                        pTargetFunc->getMedia()->get_name(funcName);                    
                        targetNodeName = funcName + "_"
                            + boost::lexical_cast<std::string>(targetIdx);
                    }
                    if(pTargetPort->getMediaHandle().is_interface_time_line())
                    {
                        implMedia.add_time_path(nodeName, 
                                                idx,
                                                targetNodeName, 
                                                pTargetFunc->getIndexByPort(pTargetPort), -4);            
                    } 
                    else
                    { 
                        implMedia.add_path(nodeName, 
                                           idx,
                                           targetNodeName, 
                                           pTargetFunc->getIndexByPort(pTargetPort));
                    }
                }
            }    

        }
    }     

    duke_media_set_hattr_node(implMediaHandle, vNodeInfo);

    //set name & input/output to pass the validation check
    implMedia.set_name("run_editor_impl");
    nb_id_t iif = NB_INTERFACE_NONE;
    implMedia.add_input_port(duke_media_handle(iif));

    //call complier to generate the impl
    nb_id_t new_id;
    std::map<int, nb_id_t> idx_id_map;
    if (implMedia.compile(getApplication()->username(), new_id, idx_id_map))
    {
        // save the generated ids to warehouse ?
        impl_id = new_id;
        LOG_INFO("Generate the Implementation successfully.");
        return true;
    }
    
    return false;
}

bool DRunEditor::getConvertInterface(DEdgePtr pEdge, duke_media_handle& hif)
{
    DPort* pPort = dynamic_cast<DPort*>(pEdge->sourceWidget());
    assert(pPort);

    // 1 level : master is an interface-obj
    DObjIcon* pObj = dynamic_cast<DObjIcon*>(pPort->parent());
    if(pObj)
    {
        hif = pObj->getMediaHandle();   
        return true;
    }

    // 2 level : master is func[get_interface] from a const-obj
    DFunc* pFunc = dynamic_cast<DFunc*>(pPort->parent());
    assert(pFunc);
    if(pFunc->getMediaHandle().get_func_type() == NB_FUNC_GENERAL_GET_INTERFACE)
    {
        DPort* pTmpPort = dynamic_cast<DPort*>(pFunc->getEdgeFromFirstPort()->sourceWidget());
        if(dynamic_cast<DObjIcon*>(pTmpPort->parent()))
        {
            hif = pTmpPort->getMediaHandle();
            return true;
        }
    }

    // otherwise error
    return false;
}

void DRunEditor::onClose(const DEvent& rEvent)
{
    for (RunWidgetsIt it = m_resWidgets.begin(); it != m_resWidgets.end(); ++it) 
    {
        DObjIcon* pResObj = dynamic_cast<DObjIcon *>((*it).get()); 
        if (NULL != pResObj) {
            pResObj->clearAllEdges();
            pResObj->deleteTextLabel();
            getBodyFrame()->detachChildWidget(pResObj);
        }

        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget(pResObj);
        if(pEditor != NULL)
        {
            pEditor->destorySubEditors(rEvent.getCon());
            pEditor->destory(rEvent.getCon());
            eraseSubEditor(pEditor);        
        }

        for (RunWidgetsIt it2 = m_runWidgets.begin(); it2 != m_runWidgets.end(); ++it2) {
            if((*it2).get() == pResObj) {
                m_runWidgets.erase(it2);
                break;
            }
        }
    }
    m_resWidgets.clear();
    m_resPairs.clear();

    for (RunWidgetsIt it = m_runWidgets.begin(); it != m_runWidgets.end(); ++it) 
    {
        //delete subEditor if there is
        DEditor * pEditor = findSubEditorByWidget((*it).get());
        if(pEditor != NULL)
        {
            m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
            eraseSubEditor(pEditor);        
        }

        // Check if the widget is func
        DFunc* pSrcFunc = dynamic_cast<DFunc *>((*it).get()); 
        if (NULL != pSrcFunc) 
        {
            pSrcFunc->clearAllEdges();
            getBodyFrame()->detachChildWidget(pSrcFunc);
        } 

        // Check if the widget is object
        DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>((*it).get()); 
        if (NULL != pSrcObj) 
        {
            pSrcObj->clearAllEdges();
            pSrcObj->deleteTextLabel();
            getBodyFrame()->detachChildWidget(pSrcObj);
        }
    }
    m_runWidgets.clear();

    DDialog::onMinimize(rEvent);
    m_layer = 1;
    m_blank = MAX_COORD;
    m_layerHeight = RunEditor_Layer;

}

void DRunEditor::setResultImage(DImage & img, const duke_media_handle& handle,
                                 std::string default_image)
{
    std::string path;
    if (handle.is_object_none())
    {
       path = get_builtin_resource_path() + "none.png";
    }
    else if (handle.is_object_bool())
    {
       path = get_builtin_resource_path() + "boolean.png";
    }
    else if (handle.is_object_int())
    {
       path = get_builtin_resource_path() + "integer.png";
    }
    else if (handle.is_object_float())
    {
       path = get_builtin_resource_path() + "float.png";
    }
    else if (handle.is_object_string())
    {
       path = get_builtin_resource_path() + "string.png";
    }
    else if (handle.is_object_bytes())
    {
       path = get_builtin_resource_path() + "bytes.png";
    }
    else if (handle.is_object_interval())
    {
       path = get_builtin_resource_path() + "interval.png";
    }
    else if (handle.is_object_time())
    {
        path = get_builtin_resource_path() + "time.png";
    }
    else if (handle.is_object_array())
    {
        path = get_builtin_resource_path() + "array.png";
    }
    else if (handle.is_object_map())
    {
        path = get_builtin_resource_path() + "map.png";
    }
    else if (handle.is_access())
    {
        path = getResPath() + "access.png";
    }
    else if(handle.is_object())
    {
        path = getResPath() + default_image;
    }
    else if(handle.is_bridge_interface())
    {
        path = getResPath() + default_image;
    }
    if(!path.empty())
        img.load(path);
}

bool DRunEditor::getValueByHandle(duke_media_handle& h, std::string& value)
{
    if (h.is_object_int()) {
        int val;
        if (h.get_value(val)) {
            try {
                 value = boost::lexical_cast<std::string>(val);
            } catch (boost::bad_lexical_cast &) {
                  return false;
            }
            return true;
        }
    } else if (h.is_object_bool()) {
        bool val;
        if (h.get_value(val)) {
            value = val ? "true" : "false";
            return true;
        }
    } else if (h.is_object_string()) {
        std::string val;
                
        content raw_data;    
        if (!duke_media_get_content_from_actor(h, raw_data))
        {       
            return false;
        }
        nb_id_t strId;
        if (obj_impl_string::unpack(raw_data, strId, val))
        {
            value = val;
            return true;
        }
        return false;

    } else if (h.is_object_float()) {
        float val;
        if (h.get_value(val)) {
            try {
                value = boost::lexical_cast<std::string>(val);
            } catch (boost::bad_lexical_cast &) {
                  return false;
            }
            return true;
        }
    } else if (h.is_object_bytes()) {
        std::string val;
        if (h.get_value(val)) {
            value = val;
            return true;
        }
    } else if (h.is_object_time()) {
        value = "time";
        return true;
    } else if(h.is_object_interval()) {
        value = "interval";
        return true;

    } else if(h.is_interface()) {

        if (h.is_builtin_interface()) {
            obj_impl_interface::get_interface_name(h.get_nb_type(), value); 
        } 
        else if (h.is_interface_compound()) {
            content raw_data;
            if (duke_media_get_content_from_actor(h, raw_data)) {
                if_compound_data_t if_data;
                nb_id_t id;
                obj_impl_interface_compound::unpack(raw_data, id, if_data);
                value = if_data.name;
            }
        }

        if (value.empty())
            value = "interface";
        return true;

    }else if(h.is_declaration()) {
        if (h.is_function_instruction()) {
            obj_impl_declaration::get_instruction_name(h.get_nb_type(), value);
        }
        else if (h.is_function_compose())
            value = "compose";
        else if (h.is_function_decompose())
            value = "decompose";
        else if (h.is_function_bridge_compose())     
            value = "bridge compose";
        else if (h.is_function_bridge_decompose())
            value = "bridge decompose";
        else if (h.is_object_decl_compound()) {
            // TODO
        }
        else if (h.is_object_decl_expanded()) {
            // TODO
        } 
        if (value.empty())
            value = "declaration";
        return true;

    }else if(h.is_implementation()){
        value = "implementation";
        return true;
    }else if(h.is_access()){
        value = "access";
        return true;
    }else if(h.is_storage()){
        value = "storage";
        return true;
    }
    else if(h.is_object_container_des()){
        value = "storage";
        return true;
    }
    return false;
}

void DRunEditor::deletePopMenu( const DEvent& event)
{
    LOG_DEBUG("--------Destory popmenu---------");
    if(m_menuEdgePair.first.get() != NULL)
    {
        m_menuEdgePair.first.get()->setGeometry(0, 0, 0, 0);
        m_menuEdgePair.first->repaint(event.getCon(), false);
        if(m_menuEdgePair.second.get() != NULL)
        {
            m_menuEdgePair.second.get()->setGeometry(0, 0, 0, 0); 
            m_menuEdgePair.second.get()->repaint(event.getCon(), false);
        }

    }
    if(m_menuEdgePair.first.get() != NULL)
        deletePopupMenuAndEdge();
}

DRunEditorCell::DRunEditorCell()
{
}

DRunEditorCell::~DRunEditorCell()
{
}

void DRunEditorCell::init()
{
}

void DRunEditorCell::update()
{
    // call parent class at first
    DDialogCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
