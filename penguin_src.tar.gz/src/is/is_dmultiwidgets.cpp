/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/
//C++ 98 header files
#include <algorithm>

//duke header files
#include "is_dmultiwidgets.h"

DMultiWidgets::DMultiWidgets()
{
}

DMultiWidgets::~DMultiWidgets()
{
}

////////////////////////////////////////////////////////////////////////
//    manage the widget group
////////////////////////////////////////////////////////////////////////
void DMultiWidgets::addWidget(DWidget * pWidget)
{
    m_widgets.push_back(pWidget);    
}

void DMultiWidgets::delWidget(DWidget * pWidget)
{
    m_widgets.erase(std::remove_if(m_widgets.begin(), m_widgets.end(),
                                   std::bind2nd(std::equal_to<DWidget *>(), pWidget)),
                    m_widgets.end());    
}

void DMultiWidgets::clear()
{
    m_widgets.clear();    
}

size_t DMultiWidgets::size()
{
    return m_widgets.size();    
}

////////////////////////////////////////////////////////////////////////
//    Send all the widget information in one reponse
////////////////////////////////////////////////////////////////////////
void DMultiWidgets::repaintAll(const is_response_call& response_call, bool hasData /* = true*/)
{
    TResponseClosure responseClosure;
    TResponseType responseType = Response_Update;
    
    for(MultiWidgetsIt it = m_widgets.begin(); it != m_widgets.end(); ++it)
    {
        DWidgetCell * pWidgetCell = (*it)->getCell();
        if(pWidgetCell == NULL)
        {
            assert(!"None DWidgetCell.");            
            continue;
        }

        TPlacement * pPlace = pWidgetCell->getPlacement();        
        if(pPlace == NULL)
        {
            assert(!"None TPlacement.");
            continue;
        }
        
        if(!hasData)
        {
            TPlacement place;
            TNone none;        
            place.path = pPlace->path;
            place.order = pPlace->order;
            place.display = pPlace->display;
            place.position = pPlace->position;
            place.size = pPlace->size;
            place.transformation = pPlace->transformation;
            place.matchedCriterion = pPlace->matchedCriterion;
            place.data = &none;
            TResponse response(responseType, place);
            responseClosure.data.push_back(response);
            place.data = NULL;            
        }
        else
        {
            TResponse response(responseType, *pPlace);
            responseClosure.data.push_back(response);
        }        
    }

    Packer p;
    p.pack(responseClosure);
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

void DMultiWidgets::showAll(const is_response_call& response_call)
{
    assert(!"Unsupport yet!");    
}

void DMultiWidgets::destoryAll(const is_response_call& response_call)
{
    assert(!"Unsupport yet!");    
}

void DMultiWidgets::hideAll(const is_response_call& response_call)
{
    assert(!"Unsupport yet!");    
}

void DMultiWidgets::displayAll(const is_response_call& response_call)
{
    assert(!"Unsupport yet!");    
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
