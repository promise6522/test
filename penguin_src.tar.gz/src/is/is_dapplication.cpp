/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Duke header files
#include "is_dapplication.h"
#include "is_devent.h"
#include "duc.h"
#include "is_dlabel.h"
#include "is_dtool.h"
#include "stdx/stdx_buffer.h"
#include "ac_actor_type.h"
#include "ac_id_dispenser.h"
#include "nb_request_handler.h"
#include "ac_bridge/bridge_impl_is.h"
////#include "media/duke_media_global.h"

DApplication::DApplication(bridge_impl_is* impl_is, is_response_call response)
    : m_ptrTopWidget(new(std::nothrow) DWidget),
      m_impl_is(impl_is),
      m_response_call(response)      
{
    request_host_committer_id();    
    assert(NULL != m_ptrTopWidget.get());
    m_ptrEventDistribution.reset(new(std::nothrow) DEventDistribution(response, m_ptrTopWidget.get()));
    assert(NULL != m_ptrEventDistribution);
}

DApplication::~DApplication()
{
    if (NULL != m_ptrMainWin.get())
        m_ptrMainWin->saveInitScene();
}

void DApplication::request_host_committer_id()
{
    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(g_ac_id_dispenser_acid));
    if(pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        pActor->request_host_committer_id(m_hc_id);
    }
}

void DApplication::update()
{
    m_ptrTopWidget->updateAll();
}

void DApplication::initScene()
{
    initFrame();
    if (NULL != m_ptrMainWin.get())
        m_ptrMainWin->restoreInitScene();
    update();
}

void DApplication::restoreInitScene()
{
    if (NULL != m_ptrMainWin.get())
        m_ptrMainWin->restoreInitScene();
}

void DApplication::initFrame()
{
    m_ptrTopWidget->setObjectName(Default_TopWidget_ObjName);
    m_ptrTopWidget->setApplication(this);
    //Init the whole frame. Must dynamic alloc the DObject. 
    m_ptrWholeFrame.reset(new(std::nothrow) DFrame(m_ptrTopWidget.get()));
    assert(m_ptrWholeFrame.get() != NULL);
    m_ptrWholeFrame->setObjectName(Default_WholeFrame_ObjName);   
    m_ptrWholeFrame->setGeometry(MIN_COORD, 
                                 MIN_COORD,
                                 MAX_COORD, 
                                 MAX_COORD);
    //m_ptrWholeFrame->setFrameStyle(DFrame::NoFrame);
    m_ptrWholeFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrWholeFrame->setAutoFill(false);

    //Init the main frame
    m_ptrMainFrame.reset(new(std::nothrow) DFrame(m_ptrWholeFrame.get()));
    assert(m_ptrMainFrame.get() != NULL);
    m_ptrMainFrame->setObjectName(Default_MainFrame_ObjName);   
    m_ptrMainFrame->setGeometry(MIN_COORD, 
                                MIN_COORD,
                                MAX_COORD, 
                                MAX_COORD);
    m_ptrMainFrame->setFrameStyle(Default_MainFrame_Style);    
    m_ptrMainFrame->setFramePenStroke(Default_MainFrame_PenStroke);    
    m_ptrMainFrame->setFrameRect(m_ptrMainFrame->contentsRect());
    m_ptrMainFrame->setBackgroundColor(Default_MainFrame_Color); 
    m_ptrMainFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrMainFrame->setAutoFill(false);

    //Init the main window
    m_ptrMainWin.reset(new(std::nothrow) DMainWin(m_ptrMainFrame.get()));
    assert(m_ptrMainWin.get() != NULL);    

    //Init the tools frame.
    m_ptrToolFrame.reset(new(std::nothrow) DFrame(m_ptrWholeFrame.get()));
    assert(m_ptrToolFrame.get() != NULL);
    m_ptrToolFrame->setObjectName(Default_ToolsFrame_ObjName);   
    m_ptrToolFrame->setGeometry(MIN_COORD, 
                                MIN_COORD,
                                Default_ToolFrame_Width, 
                                MAX_COORD);
    m_ptrToolFrame->setFrameStyle(Default_ToolsFrame_Style);    
    m_ptrToolFrame->setFramePenStroke(Default_ToolsFrame_PenStroke);    
    m_ptrToolFrame->setFrameRect(m_ptrToolFrame->contentsRect());
    m_ptrToolFrame->setBackgroundColor(Default_ToolsFrame_Color);
    m_ptrToolFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrToolFrame->setAutoFill(false);

    //Init tooltip
    m_ptrToolTip.reset(new(std::nothrow) DToolTip(m_ptrWholeFrame.get()));
    m_ptrToolTip->setHideProperty(true);
    m_ptrToolTip->setDisplayOrder(0);
    
    //Init the tool window
    m_ptrToolWin.reset(new(std::nothrow) DToolWin(m_ptrToolFrame.get(), m_ptrMainWin.get()));
    assert(m_ptrToolWin.get() != NULL);

    //using assert to assure the toolwin and mainwin could find each other.
    assert(m_ptrToolWin->mainWin() != NULL);
    assert(m_ptrMainWin->toolWin() != NULL);
    //init the frame for drag cursor
    m_ptrDragFrame.reset(new(std::nothrow) DFrame(m_ptrTopWidget.get()));
    assert(NULL != m_ptrDragFrame.get());
    m_ptrDragFrame->setAutoFill(false);
    m_ptrDragFrame->setObjectName("drag frame for cursor");
    m_ptrDragFrame->setHideProperty(true);
}

bool DApplication::exec(const TGesture& gesture)
{
    if (gesture.type == Start)
    {
        m_username = gesture.text;                
        std::size_t sep = gesture.text.find_first_of(default_user_pwd_separator);
        if(sep != std::string::npos)
        {                
            m_username = gesture.text.substr(0, sep);
        }
            
        //if there is prefix '$' before user name, it means is_mode
        if(!m_username.empty() && (m_username[0] == default_is_mode_prefix))
        {
            m_username.erase(0, 1);                
        }

        LOG_DEBUG("User "<<m_username<<" Login DAPP.");
        initScene();
        //m_ptrTopWidget->showXML();
        m_ptrTopWidget->show(m_response_call);        
    }
    else
    {
        m_ptrEventDistribution->distribute_event(gesture);
    }    
    
    return true;
}

bool DApplication::exec(const DEvent& event)
{
    m_ptrEventDistribution->execute_event(event);
    return true;
}

void DApplication::setDragCursor(DCursor::CursorShape cursorShape)
{ 
     assert(NULL != m_ptrDragFrame.get());
     DCursor cursor;
     cursor.setShape(cursorShape);
     m_ptrDragFrame->setCursor(cursor);
     m_ptrDragFrame->repaint(m_response_call);
}

void DApplication::run_impl(DWidget* pWidget, duke_media_handle handle)
{
    if(pWidget)
    {        
        m_impl_is->run_impl_(pWidget->objectPath(), handle);
    }
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
