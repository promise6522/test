/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei 
**
****************************************************************************/

#ifndef DBUILTINOBJ_H
#define DBUILTINOBJ_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dlabel.h"
#include "is_dtool.h"
#include "is_dport.h"
#include "is_dfunc.h"
////#include "media/duke_media_header.h"
#include "duke_media_global.h"

typedef std::vector<DEdgePtr> EdgeItems;
typedef std::vector<DEdgePtr>::iterator EdgeIt;
typedef std::vector<DEdgePtr>::size_type EdgeIdx;

class DBuiltinObjCell;

class DBuiltinObj : public DWidget {
public:
    DBuiltinObj(DWidget * parent = 0, WFlags f = 0);
    DBuiltinObj(const duke_media_handle & h_obj, DWidget * parent = 0, WFlags f = 0);
    virtual ~DBuiltinObj();

    void initView();
    void initMedia();

    // manage edge
    void updateEdgePos();
    DEdgePtr createEdge();
    void deleteEdge(DEdge *pEdge);
    void clearAllEdges();
    DEdgePtr getSuspendEdge();
    EdgeItems outEdges();

    bool checkPos(const DPoint &p, int len);
    void connect(DFunc *pFunc, unsigned int idx);

    // event handle 
    void onPortDnDStart(const DEvent &rEvent);
    void onDestroy(const DEvent &rEvent);
    void onDnDRelease(const DEvent &rEvent);

private:
    DPortPtr m_ptrPort;
    DLabelPtr m_ptrBody;

    EdgeItems m_outEdges;

    D_DECLARE_CELL(DBuiltinObj)
};

class DBuiltinObjCell : public DWidgetCell {
public:
    DBuiltinObjCell();
    virtual ~DBuiltinObjCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DBuiltinObj)
};

typedef std::tr1::shared_ptr<DBuiltinObj>  DBuiltinObjPtr;
typedef std::tr1::shared_ptr<DBuiltinObjCell>  DBuiltinObjCellPtr;

const int BuiltinObj_Default_Display_Order = 10;
const int BuiltinObj_Port_Display_Order = 10;
const int BuiltinObj_Edge_Display_Order = 30;
const int BuiltinObj_Port_Width = 1250;
const DColor BuiltinObj_Port_Background(0, 100, 0);
const DColor BuiltinObj_Port_Highlight(0, 255 ,0);
const DColor BuiltinObj_Body_Background(255, 255, 255);

const std::string DBuiltinObj_ObjName("DBuiltinObj_Object");

#endif // DBUILTINOBJ_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
