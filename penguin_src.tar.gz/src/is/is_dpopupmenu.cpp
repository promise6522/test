/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Duke header files
#include "is_dpopupmenu.h"
#include "is_dtoolwin.h"

DPopupMenu::DPopupMenu(DWidget *parent, WFlags f)
    : DWidget(*new DPopupMenuCell, parent, f),
      m_beginItemPos(0),
      m_itemHeight(MAX_COORD),
      m_textColor(255, 255, 255)
{
    setGeometry(0, 0, 0, 0);
    setBackgroundColor(46, 46, 46, 228);
    setHighlightColor(0, 0, 196);
    initMenu();
    d_func()->init();
}

DPopupMenu::~DPopupMenu()
{
}

void DPopupMenu::initMenu()
{
    // init up arrow
    DImage img;
    img.load(getResPath() + ToolWin_UpButton_Filename);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage hoverImg;
    hoverImg.load(getResPath() + ToolWin_UpButtonHover_Filename);
    hoverImg.setXScale(DImage::Stretch);
    hoverImg.setYScale(DImage::Stretch);
    hoverImg.setRelation(DImage::Disrelated);

    m_ptrUpArrow.reset(new(std::nothrow) DButton("", img, hoverImg, this));
    assert(m_ptrUpArrow.get() != NULL);
    m_ptrUpArrow->setGeometry(0, 0, 0, 0);
    m_ptrUpArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrUpArrow->setSelected(false);
    m_ptrUpArrow->registerEvent(DEvent::Select);
    m_ptrUpArrow->registerEvent(DEvent::Grab);
    m_ptrUpArrow->registerEvent(DEvent::PassingOut);
    m_ptrUpArrow->setEventRoutine(DEvent::Select, 
                                  this, 
                                  (EventRoutine)(&DPopupMenu::onGrabUpArrow));    
    m_ptrUpArrow->setEventRoutine(DEvent::Grab, 
                                  this, 
                                  (EventRoutine)(&DPopupMenu::onGrabUpArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::PassingOut, 
                                  this, 
                                  (EventRoutine)(&DPopupMenu::onPassingOutArrow));
 
    // init down arrow
    img.load(getResPath() + ToolWin_DownButton_Filename);
    hoverImg.load(getResPath() + ToolWin_DownButtonHover_Filename);
    m_ptrDownArrow.reset(new(std::nothrow) DButton("", img, hoverImg, this));

    m_ptrDownArrow->setBackgroundColor(ToolWin_Background_Color);
    assert(m_ptrDownArrow.get() != NULL);
    m_ptrDownArrow->setGeometry(0, 0, 0, 0);
    m_ptrDownArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDownArrow->setSelected(false);
    m_ptrDownArrow->registerEvent(DEvent::Select);
    m_ptrDownArrow->registerEvent(DEvent::Grab);
    m_ptrDownArrow->registerEvent(DEvent::PassingOut);
    m_ptrDownArrow->setEventRoutine(DEvent::Select, 
                                    this, 
                                    (EventRoutine)(&DPopupMenu::onGrabDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::Grab, 
                                    this, 
                                    (EventRoutine)(&DPopupMenu::onGrabDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::PassingOut, 
                                    this, 
                                    (EventRoutine)(&DPopupMenu::onPassingOutArrow));
}

void DPopupMenu::updateMenu()
{
    if(m_items.size() == 0)
    {
        return;
    }    
    
    if (m_items.size() > 2) {
        calculateItems();
        return;
    }

    m_itemHeight = MAX_COORD / m_items.size(); 
    int idx = 0;
    for (MenuItemIt it = m_items.begin(); it != m_items.end(); ++it) {        
        (*it)->setGeometry(0, idx*m_itemHeight, MAX_COORD, m_itemHeight);
        (*it)->updateAll();
         idx++;
    }
 
}

MenuItemIdx DPopupMenu::insertItem(const std::string &text, MenuItemIdx idx,
        const duke_media_handle &h)
{
    if (idx >= (m_items.size()))
        idx = m_items.size();

    DLabelPtr ptrItem(new(std::nothrow) DLabel(this));
    ptrItem->registerEvent(DEvent::Select);
    ptrItem->registerEvent(DEvent::PassingIn);
    ptrItem->registerEvent(DEvent::Hover);
    ptrItem->registerEvent(DEvent::PassingOut);
    ptrItem->setFrameStyle(DFrame::Box);
    ptrItem->setContent(text);
    ptrItem->setTextColor(m_textColor);
    ptrItem->setIndent(1000);
    ptrItem->rtext().setFontSize(6000);
    ptrItem->setWordWrap(true);
    ptrItem->setAlignment(AlignLeft);
    ptrItem->setBackgroundColor(backgroundColor());
    ptrItem->setFrameBorderColor(backgroundColor());
    ptrItem->setHighlightColor(highlightColor());
    ptrItem->setMediaHandleOnly(h);

    m_items.insert(m_items.begin()+idx, ptrItem);

    return idx;
}

MenuItemIdx DPopupMenu::removeItem(MenuItemIdx idx)
{
    if (idx >= m_items.size())
        return -1;

    return idx;
}

MenuItemIdx DPopupMenu::changeItem(MenuItemIdx idx, const std::string &text)
{
    if (idx >= m_items.size())
        return -1;

    return idx;
}

MenuItemIdx DPopupMenu::connectItem(MenuItemIdx idx, DWidget* pWidget, EventRoutine callback)
{
    if (idx >= m_items.size())
        return -1;

    m_items[idx]->setEventRoutine(DEvent::Select, pWidget, callback);

    return idx;
}

MenuItemIdx DPopupMenu::disconnectItem(MenuItemIdx idx)
{
    if (idx >= m_items.size())
        return -1;

    m_items[idx]->setEventRoutine(DEvent::Select, 
            m_items[idx].get(), 
            static_cast<EventRoutine>(&DPopupMenu::onDefaultSelect));

    return idx;
}

void DPopupMenu::setItemHandle(MenuItemIdx idx, const duke_media_handle &h)
{
    if (idx >= m_items.size())
        return;

    m_items[idx]->setMediaHandle(h);
}

void DPopupMenu::onDefaultSelect(const DEvent& rEvent)
{
}

int DPopupMenu::getIndexByItem(DMenuItem* pItem)
{
    for (MenuItemIdx index =0; index < m_items.size(); ++index) {
        if (m_items[index].get() == pItem)
            return index;
    }

    return -1;
}

void DPopupMenu::calculateItems()
{
    int menuItemSize = (m_items.size()+2) < PopupMenu_Item_Size ? (m_items.size()+2) : PopupMenu_Item_Size;
    m_itemHeight = MAX_COORD / menuItemSize;
    int curY = m_itemHeight;
    int itemSize = menuItemSize - 2;

    m_ptrUpArrow->setGeometry(0, 0, MAX_COORD, m_itemHeight);
    m_ptrDownArrow->setGeometry(0, m_itemHeight*(menuItemSize-1), 
            MAX_COORD, m_itemHeight);

    
     for (MenuItemIt it = m_items.begin(); it != m_items.end(); ++it) {
        (*it)->setGeometry(0, 0, 0, 0);
     }

     int size = itemSize;
     int itemPos = m_beginItemPos;
     while(size)
     {
        m_items[itemPos]->setGeometry(0, curY, MAX_COORD, m_itemHeight);
        curY += m_itemHeight;

        if(itemPos == static_cast<int>(m_items.size() - 1))
        {
            itemPos = 0;
        }
        else {
            ++itemPos;    
        }
        --size;
     }
}

void DPopupMenu::onGrabUpArrow(const DEvent &event)
{
    if (m_beginItemPos <= 0) {
        m_beginItemPos = m_items.size() -1;
    } else {
        --m_beginItemPos;
    }

    calculateItems();
    updateAll();
    repaint(event.getCon());  
}

void DPopupMenu::onGrabDownArrow(const DEvent &event)
{
    /*if (m_beginItemPos + PopupMenu_Item_Size - 2 >= m_items.size()) {
        m_beginItemPos = m_items.size() - PopupMenu_Item_Size + 2;
    } else {
        ++m_beginItemPos;
    }*/
    if (m_beginItemPos == m_items.size() -1)
    {
        m_beginItemPos = 0;
    }
    else
    {
        ++m_beginItemPos;
    }
 
    calculateItems();
    updateAll();
    repaint(event.getCon());  
}

void DPopupMenu::onPassingOutArrow(const DEvent &event)
{
}


DPopupMenuCell::DPopupMenuCell()
{
}

DPopupMenuCell::~DPopupMenuCell()
{
}

void DPopupMenuCell::init()
{
}

void DPopupMenuCell::update()
{
    DWidgetCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
