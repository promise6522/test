/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/

#include "is_darrayeditor.h"
#include "is_ddecleditor.h"
#include "is_dapplication.h"

DArrayEditor::DArrayEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    m_row = 0;
    m_rowHeight = ArrayEditor_Row_Height;
    setObjectName(ArrayEditor_ObjName);
    assert(pMainWin != NULL);    
}

DArrayEditor::DArrayEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    m_row = 0;
    m_rowHeight = ArrayEditor_Row_Height;
    setObjectName(ArrayEditor_ObjName);
    assert(pMainWin != NULL);
}

DArrayEditor::~DArrayEditor()
{
}

void DArrayEditor::reload()
{
    LOG_DEBUG("DArrayEditor:: reload ......");

    // clear
    m_row = 0;
    m_rowHeight = ArrayEditor_Row_Height;

    for (ArrayWidgetsIt it = m_arrayWidgets.begin(); 
            it != m_arrayWidgets.end(); 
            ++it) {
        if (it->get())
            m_ptrElementFrame->detachChildWidget(it->get());
    }
    m_arrayWidgets.clear();

    // get name & icon
    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia) {
        releaseMedia();
        return;
    }
    pArrayMedia->get_name(m_dukeName);
    pArrayMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // reload media data
    initItemsInBody();
    return;
}

void DArrayEditor::initArrayEditor()
{
    // get name & icon
    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia) {
        releaseMedia();
        return;
    }
    pArrayMedia->get_name(m_dukeName);
    pArrayMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    initTypeFrame();
    initElementFrame();
    return;
}

void DArrayEditor::initElementFrame()
{
    m_ptrElementFrame.reset(new(std::nothrow) DFrame(
                            static_cast<DWidget *>(getBodyFrame())));
    m_ptrElementFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrElementFrame->setHideProperty(false);
    m_ptrElementFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrElementFrame->setAutoFill(false);
    m_ptrElementFrame->setFrameStyle(DFrame::Panel);
    //m_ptrElementFrame->registerEvent(DEvent::Drag);
    m_ptrElementFrame->registerEvent(DEvent::DnD_Release);
    m_ptrElementFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrElementFrame->registerEvent(DEvent::Detail, true);
    m_ptrElementFrame->registerEvent(DEvent::Select, true);
    m_ptrElementFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrElementFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrElementFrame->setGeometry(MIN_COORD, 
                                   2000, 
                                   MAX_COORD, 
                                   8000);
    m_ptrElementFrame->setEventRoutine(DEvent::DnD_Release,
                                       this,
                                       static_cast<EventRoutine>(&DArrayEditor::onDnDRelease));

    initItemsInBody();
    return;
}

void DArrayEditor::initTypeFrame()
{
    m_ptrTypeFrame.reset(new(std::nothrow) DFrame(
                            static_cast<DWidget *>(getBodyFrame())));
    m_ptrTypeFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrTypeFrame->setHideProperty(false);
    m_ptrTypeFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    m_ptrTypeFrame->setAutoFill(false);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    //m_ptrTypeFrame->registerEvent(DEvent::Drag);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Release);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Detail, true);
    m_ptrTypeFrame->registerEvent(DEvent::Select, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrTypeFrame->setGeometry(MIN_COORD, 
                                MIN_COORD, 
                                MAX_COORD, 
                                1500);
    m_ptrTypeFrame->setEventRoutine(DEvent::DnD_Release,
                                       this,
                                       static_cast<EventRoutine>(&DArrayEditor::onDnDReleaseTypeFrame));

    return;
}

void DArrayEditor::initItemsInBody()
{
    if (NULL != m_ptr && !m_ptr->is_object_array()) 
    {
        releaseMedia();
        return;
    }

    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia)
        return;

    duke_media_handle_vector interfaceHandle;
    duke_media_handle_vector hObjs;

    pArrayMedia->get_type(interfaceHandle);

    DImage elementImg;
    elementImg.load(getResPath() + ArrayEditorItemImage_FileName);
    elementImg.setRelation(DImage::KeepSmall);
    if (interfaceHandle.size() > 0)
    {
        m_ptrInterfaceButton.reset(new(std::nothrow) 
                                   DButton("", elementImg, m_ptrTypeFrame.get()));
        setElementProperty(m_ptrInterfaceButton.get());
        m_ptrInterfaceButton->setGeometry(3000, 2000, 4000, 4000); 
        m_ptrInterfaceButton->setMediaByHandle(interfaceHandle[0]);

        m_ptrInterfaceText.reset(new(std::nothrow) DLabel("N/A", m_ptrTypeFrame.get()));        
        m_ptrInterfaceText->setAlignment(AlignCenter);
        m_ptrInterfaceText->setGeometry(0, 6000, MAX_COORD, 2000);
        m_ptrInterfaceText->setBackgroundColor(Duke_Transparent_Color);
        m_ptrInterfaceText->setFrameBorderColor(Duke_Transparent_Color);
        m_ptrInterfaceText->setTextColor(Default_Dialog_TextColor);

        adjustIconForExpand(m_ptrInterfaceButton.get());
        std::string strname;
        if(duke_media_get_name(m_ptrInterfaceButton->getMediaHandle(), strname) && !strname.empty())
        {
            m_ptrInterfaceText->setContent(strname);
        }
        else
        {
            m_ptrInterfaceText->setContent("N/A");                    
        }
    }

    pArrayMedia->get_elements(hObjs);

    for (duke_media_handle_const_iterator it = hObjs.begin(); 
            it != hObjs.end(); ++it) {
        DButtonPtr ptrElementButton(new(std::nothrow) DButton("",
                                    elementImg, m_ptrElementFrame.get()));
        setElementProperty(ptrElementButton.get());
        ptrElementButton->setMediaByHandle(*it);
        m_arrayWidgets.push_back(ptrElementButton);
    }

    updateElementView();
}

void DArrayEditor::updateElementView()
{
    m_row = (m_arrayWidgets.size() % ArrayEditor_Col_Items) ?
            (m_arrayWidgets.size() / ArrayEditor_Col_Items + 1) :
            (m_arrayWidgets.size() / ArrayEditor_Col_Items); 
    if (ArrayEditor_Row_Height*m_row > MAX_COORD)
        m_rowHeight = MAX_COORD / m_row;
    int colWidth = MAX_COORD / ArrayEditor_Col_Items;

    int rcnt = 0;
    int ccnt = 0;
    for (ArrayWidgetsIt it = m_arrayWidgets.begin();
         it != m_arrayWidgets.end();
         ++it) 
    {
        DWidget * pElement = (*it).get();;
        assert(pElement != NULL);
        pElement->setGeometry(ccnt*colWidth + 100,
                           rcnt*m_rowHeight + 100,
                           colWidth - 200,
                           m_rowHeight - 200);

        ccnt++;
        if (ccnt == ArrayEditor_Col_Items)
        {
            rcnt++;
            ccnt = 0;
        }
    }
}

void DArrayEditor::adjustPlacement()
{
    DEditor::adjustPlacement();

    // update declaration view gemoetry
    if (NULL != m_ptrElementFrame.get())
        m_ptrElementFrame->setGeometry(MIN_COORD, 
                2000, 
                MAX_COORD, 
                8000);
    // update declaration view gemoetry
    if (NULL != m_ptrTypeFrame.get())
        m_ptrTypeFrame->setGeometry(MIN_COORD, 
                MIN_COORD, 
                MAX_COORD, 
                2000);

}

void DArrayEditor::setElementProperty(DButton* pElementButton)
{
    if (NULL == pElementButton)
    {
        return;
    }
    pElementButton->setFocusAttr(true);
    pElementButton->registerEvent(DEvent::Select);
    pElementButton->registerEvent(DEvent::Hover);
    pElementButton->registerEvent(DEvent::PassingOut);
    pElementButton->registerEvent(DEvent::Delete);
    pElementButton->registerEvent(DEvent::DnD_Start);
    pElementButton->registerEvent(DEvent::Activate);
 
    pElementButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DArrayEditor::onPassingOutChild));
    pElementButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DArrayEditor::onHoverChild));
    pElementButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DArrayEditor::onDeleteChild));
    pElementButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DArrayEditor::onSelectChild));
    pElementButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DArrayEditor::onActivateObj));  
    return;
}

void DArrayEditor::setTypeProperty(DButton* pTypeButton)
{
    if (NULL == pTypeButton)
    {
        return;
    }
    pTypeButton->setFocusAttr(true);
    pTypeButton->registerEvent(DEvent::Select);
    pTypeButton->registerEvent(DEvent::Hover);
    pTypeButton->registerEvent(DEvent::PassingOut);
    pTypeButton->registerEvent(DEvent::DnD_Start);
    pTypeButton->registerEvent(DEvent::Activate);
    pTypeButton->registerEvent(DEvent::DnD_Release, true);

    pTypeButton->setEventRoutine(DEvent::PassingOut,
                                 this,
                                 static_cast<EventRoutine>(&DArrayEditor::onPassingOutChild));
    pTypeButton->setEventRoutine(DEvent::Hover,
                                 this,
                                 static_cast<EventRoutine>(&DArrayEditor::onHoverChild));
    pTypeButton->setEventRoutine(DEvent::Select,
                                 this,
                                 static_cast<EventRoutine>(&DArrayEditor::onSelectChild));
    pTypeButton->setEventRoutine(DEvent::Activate,
                                 this,
                                 static_cast<EventRoutine>(&DArrayEditor::onActivateObj));
    return;
}

void DArrayEditor::createElementByHandle(const duke_media_handle& rDukeHandle)
{
    DImage elementImg;
    elementImg.load(getResPath() + ArrayEditorItemImage_FileName);
    elementImg.setRelation(DImage::KeepSmall);

    if (ArrayEditor_Row_Height*(m_row+1) > MAX_COORD)
        m_rowHeight = MAX_COORD / m_row;

    DButtonPtr ptrElementButton(new(std::nothrow) DButton("",
                                elementImg,
                                m_ptrElementFrame.get()));
    assert(NULL != ptrElementButton.get());
    setElementProperty(ptrElementButton.get()); 
    if (rDukeHandle.is_object_builtin())
    {
        duke_media_handle hnew;
        duke_media_clone(this->getApplication()->get_host_committer_id(), rDukeHandle, hnew);           
        ptrElementButton->setMediaByHandle(hnew);
    }
    else
    {
        ptrElementButton->setMediaByHandle(rDukeHandle);
    }
    
    m_arrayWidgets.push_back(ptrElementButton);
    updateElementView();
    return;
}

void DArrayEditor::saveDukeData()
{
    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia)
        return;
    
    // get elements of the array
    duke_media_handle_vector vElements;
    for (ArrayWidgetsIt it = m_arrayWidgets.begin();
        it != m_arrayWidgets.end();
        ++it) 
    {
        duke_media_handle dukeHandle = (*it)->getMediaHandle();
        vElements.push_back(dukeHandle);
    }

    // get type of the array
    duke_media_handle elemType;
    if (NULL != m_ptrInterfaceButton.get())
    {
        elemType = m_ptrInterfaceButton->getMediaHandle();
    }
    else
    {
        // default array type
        elemType = NB_INTERFACE_NONE;
    }

    // update media data
    duke_media_handle_vector vType;
    vType.push_back(elemType);
    pArrayMedia->set_value(vType, vElements);
}

void DArrayEditor::setReadonly()
{
    DEditor::setReadonly();

    //m_ptrElementFrame->unRegisterEvent(DEvent::Drag);
    m_ptrElementFrame->unRegisterEvent(DEvent::DnD_Release);

    //m_ptrTypeFrame->unRegisterEvent(DEvent::Drag);
    m_ptrTypeFrame->unRegisterEvent(DEvent::DnD_Release);

    for (ArrayWidgetsIt it = m_arrayWidgets.begin(); it != m_arrayWidgets.end(); ++it) {
        if (NULL != it->get()) {
            it->get()->unRegisterEvent(DEvent::Activate);
            it->get()->unRegisterEvent(DEvent::DnD_Start);
            it->get()->unRegisterEvent(DEvent::Delete);
        }
    }
}
void DArrayEditor::onDnDRelease(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onDnDRelease");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DArrayEditor* pArrayEditor = dynamic_cast<DArrayEditor *>(pObject);
    if (NULL != pArrayEditor) {
        return;
    }
    
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    if (NULL == m_ptrInterfaceButton.get())
        return;

    if(pSrcWidget->parent() && pSrcWidget->parent() == m_ptrElementFrame.get())
    {
        moveElement(pSrcWidget,event.getEventPosition().x(),event.getEventPosition().y());
    }
    else
    {
        // get the dragged widget's interface
        duke_media_handle dragObjInterface;
        duke_media_get_interface_by_object(handle, dragObjInterface);

        if(duke_media_interface_cover_interface(dragObjInterface, m_ptrInterfaceButton->getMediaHandle()))
        {  
            // Create widget for element 
            createElementByHandle(handle); 
        }
        else
        {
            LOG_ERROR("The type of the dragged widget doesn't match the array's type");
            return;
        }

    }
    saveDukeData();

    // Repaint
    updateAll();
    repaint(event.getCon());
    return;
}

void DArrayEditor::onDnDReleaseTypeFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onDnDReleaseTypeFrame");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
   
    DArrayEditor* pArrayEditor = dynamic_cast<DArrayEditor *>(pObject);
    if (NULL != pArrayEditor) {
        return;
    }
    
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    if(!m_ptrInterfaceButton)
    {        
        m_ptrInterfaceButton.reset(new(std::nothrow) DButton("", m_ptrTypeFrame.get()));
        DImage elementImg;
        elementImg.load(getResPath() + ArrayEditorItemImage_FileName);
        elementImg.setRelation(DImage::KeepSmall);
        m_ptrInterfaceButton->setImage(elementImg);
        setTypeProperty(m_ptrInterfaceButton.get());
        m_ptrInterfaceButton->setGeometry(3000, 2000, 4000, 4000);

        m_ptrInterfaceText.reset(new(std::nothrow) DLabel("", m_ptrTypeFrame.get()));        
        m_ptrInterfaceText->setAlignment(AlignCenter);
        m_ptrInterfaceText->setGeometry(0, 6000, MAX_COORD, 2000);
        m_ptrInterfaceText->setBackgroundColor(Duke_Transparent_Color);
        m_ptrInterfaceText->setFrameBorderColor(Duke_Transparent_Color);
        m_ptrInterfaceText->setTextColor(Default_Dialog_TextColor);
    }
    
    duke_media_handle dukeHandleInterface;
    if (handle.is_interface()) 
    {
        createPopupMenuForInterface(handle, event);
    }
    else
    {
        duke_media_get_interface_by_object(handle, dukeHandleInterface);
        m_ptrInterfaceButton->setMediaByHandle(dukeHandleInterface);
        std::string strname;
        if(duke_media_get_name(m_ptrInterfaceButton->getMediaHandle(), strname) && !strname.empty())
        {
            m_ptrInterfaceText->setContent(strname);
        }
        else
        {
            m_ptrInterfaceText->setContent("N/A");                    
        }

        //for array/map icon
        adjustIconForExpand(m_ptrInterfaceButton.get());

        while(!m_arrayWidgets.empty())
        {
            ArrayWidgetsIt it = m_arrayWidgets.begin();
            m_ptrElementFrame->detachChildWidget(it->get());            
            m_arrayWidgets.erase(it);
        }
        saveDukeData();
    }
    // Repaint
    updateAll();
    repaint(event.getCon());
    return;
}

void DArrayEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onPassingOutChild");
    getApplication()->tip()->remove(event.getCon());
}

void DArrayEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onHoverChild");
    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0]));
    if (NULL == pSrcWidget)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
    {
        if (pSrcWidget->getMedia()->is_object_builtin()) 
        {   
            if (pSrcWidget->getMedia()->is_object_bytes())
            {
                strTip = "btyes";
            }
            else
            {
                std::string val;
                pSrcWidget->getMediaValue(val);
                strTip = strTip + " " + val; 
            }
        }
        getApplication()->tip()->add(pSrcWidget, strTip, event.getCon());
    }
    else
    {
        getApplication()->tip()->add(pSrcWidget, pSrcWidget->strPath(), event.getCon());
    }
    return;
}

void DArrayEditor::onDeleteChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onDeleteChild");

    if (m_isReadOnly) return;
    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;
   
    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia)
        return;
   
    if (m_ptrInterfaceButton.get() == pSrcWidget)
    {
       while(m_arrayWidgets.size())
       {
           ArrayWidgetsIt it = m_arrayWidgets.begin();
           m_ptrElementFrame->detachChildWidget(it->get());
           m_arrayWidgets.erase(it);
       }
        m_ptrTypeFrame->detachChildWidget(pSrcWidget);
        m_ptrTypeFrame->detachChildWidget(m_ptrInterfaceText.get());
        m_ptrInterfaceButton.reset();
        m_ptrInterfaceText.reset();
        pArrayMedia->set_null_interface();
    }
    else
    {
        for (ArrayWidgetsIt it = m_arrayWidgets.begin(); 
                it != m_arrayWidgets.end(); 
                ++it) 
        {
            if (it->get() == pSrcWidget)
            {
                m_ptrElementFrame->detachChildWidget(pSrcWidget);
                m_arrayWidgets.erase(it);
                break;
            }
        }
    }

    getApplication()->tip()->remove(event.getCon());

    updateElementView();
    saveDukeData();
    updateAll();
    repaint(event.getCon());
    return;
}

void DArrayEditor::onSelectChild(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onSelectChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;

    getSelFrame()->setGeometry(pSrcWidget->geometry().left() - 100,
            pSrcWidget->geometry().top() - 100,
            pSrcWidget->geometry().width() + 200,
            pSrcWidget->geometry().height() + 200);
    getSelFrame()->setHideProperty(false);

    updateAll();
    repaint(event.getCon());
}

void DArrayEditor::onGenerate(const DEvent &event)
{
    // save name and icon
    DEditor::onGenerate(event);

    duke_media_array *pArrayMedia = dynamic_cast<duke_media_array *>(m_ptr);
    if (NULL == pArrayMedia)
        return;
    
    //add by roger
    duke_media_handle handle;
    //pArrayMedia->generate(getApplication()->username(), handle);
}


void DArrayEditor::onActivateObj(const DEvent &event)
{
    LOG_DEBUG("--------------DArrayEditor::onActivateObj");
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
    duke_media_handle handle = pSrcWidget->getMediaHandle();
        
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) 
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();

        //if it is readonly, just show/hide dialog
        if(m_isReadOnly)
        {
            if(pEditor->isHide())
            {
                pEditor->display(event.getCon());
            }
            else
            {
                pEditor->hideAllSubEditors(event.getCon());
                pEditor->hide(event.getCon());
            }
            return;
        }
        
        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);
        if (pEditor->isHide()) {
            if (pInput) {
                // Set initial value
                std::string value;
                if (pSrcWidget->getMediaValue(value))
                pInput->setInputString(value);
            }
            pEditor->updateAll();
            pEditor->display(event.getCon());
        } 
        else {
            if (pInput) {   
                pSrcWidget->setMediaValue(pInput->getInputString());
                std::string value;
                pSrcWidget->getMediaValue(value);
                pInput->setInputString(value);
                m_isModified = true;
            }
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        if (pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        DButton *pButton = dynamic_cast<DButton*>(pSrcWidget);
        if(pButton)
        {
            adjustIconForExpand(pButton);            
        }        
        
        saveDukeData();
        return;
    }
    pEditor = createSubEditor(pSrcWidget);
    if(pEditor)
    {        
        pEditor->updateAll();
        pEditor->show(event.getCon());
    }    
}

void DArrayEditor::moveElement(DWidget *pSrcWidget,int x,int y)
{
    size_t row = (y / m_rowHeight) >  (m_row - 1) ? m_row : (y / m_rowHeight);
    size_t colWidth = MAX_COORD / ArrayEditor_Col_Items;
    size_t column = x / colWidth;
    size_t index = row * ArrayEditor_Col_Items + column;

    for(ArrayWidgetsIdx idx = 0; idx < m_arrayWidgets.size(); ++idx)
    {
        if(m_arrayWidgets[idx].get() == pSrcWidget)
        {
            DWidgetPtr pMoveWidget = m_arrayWidgets[idx];
            if (index < m_arrayWidgets.size())
            {
                if (index < idx)
                {
                    m_arrayWidgets.erase(m_arrayWidgets.begin()+idx);
                    m_arrayWidgets.insert(m_arrayWidgets.begin() + index, pMoveWidget);
                }
                else if (index >idx)
                {
                    m_arrayWidgets.erase(m_arrayWidgets.begin()+idx);
                    m_arrayWidgets.insert(m_arrayWidgets.begin() + index -1, pMoveWidget);
                }
            }
            else
            {
                m_arrayWidgets.erase(m_arrayWidgets.begin()+idx);
                m_arrayWidgets.push_back(pMoveWidget);
            }
            break;
        }
    }
    updateElementView();
}

DPopupMenu* DArrayEditor::createPopupMenuForInterface(const duke_media_handle& handle, const DEvent& event)
{
     if(m_ptrInterfaceMenu.get())
    {
        m_ptrTypeFrame->detachChildWidget(m_ptrInterfaceMenu.get());
        m_ptrInterfaceMenu.reset();
    }
    m_ptrInterfaceText->setContent(""); 
    m_ptrInterfaceMenu.reset(new DPopupMenu(m_ptrTypeFrame.get()));
    m_ptrInterfaceMenu->setGeometry(5500, 
                                2500, 
                                2000, 
                                4000);
    m_ptrInterfaceMenu->setFocusAttr(true);
    m_ptrInterfaceMenu->registerEvent(DEvent::Focus);
    m_ptrInterfaceMenu->registerEvent(DEvent::Blur);
    m_ptrInterfaceMenu->setEventRoutine(DEvent::Blur,
                              this,
                              static_cast<EventRoutine>(&DArrayEditor::onInterfaceMenuBlur));

    duke_media_handle hif;
    // create a menu item for interface itself
    m_ptrInterfaceMenu->insertItem("set interface", 0, handle);
    m_ptrInterfaceMenu->connectItem(0, 
                              this,         
                              static_cast<EventRoutine>(&DArrayEditor::onSelectInterfaceMenu));

    // create a menu item for interface interface
    duke_media_get_interface_by_object(handle, hif);
    m_ptrInterfaceMenu->insertItem("set its interface", 1, hif);
    m_ptrInterfaceMenu->connectItem(1,
                              this,
                              static_cast<EventRoutine>(&DArrayEditor::onSelectInterfaceMenu));

    m_ptrInterfaceMenu->updateMenu();   

    return m_ptrInterfaceMenu.get();
}

void DArrayEditor::onInterfaceMenuBlur(const DEvent &event)
{
    LOG_DEBUG("DArrayEditor::onInterfaceMenuBlur");
    assert(m_ptrInterfaceMenu.get());

    if(m_ptrInterfaceMenu.get())
    {
        m_ptrTypeFrame->detachChildWidget(m_ptrInterfaceMenu.get());
        m_ptrInterfaceMenu.reset();
    }

    updateAll();
    repaint(event.getCon());
}

void DArrayEditor::onSelectInterfaceMenu(const DEvent &event)
{
    LOG_DEBUG("DArrayEditor::onSelectInterfaceMenu");

    const std::vector<DPath>& eventPath = event.getEventPath();

    DMenuItem* pSelectItem = dynamic_cast<DMenuItem* >(findChild(eventPath[0]));
    if (NULL == pSelectItem)
        return;

    if(!m_ptrInterfaceMenu.get())
        return;

    duke_media_handle hif = pSelectItem->getMediaHandle();
    m_ptrInterfaceButton->setMediaByHandle(hif);
    // destroy the menu
    m_ptrTypeFrame->detachChildWidget(m_ptrInterfaceMenu.get());
    m_ptrInterfaceMenu.reset();
    std::string strname;
    if(duke_media_get_name(m_ptrInterfaceButton->getMediaHandle(), strname) && !strname.empty())
    {
        m_ptrInterfaceText->setContent(strname);
    }
    else
    {
        m_ptrInterfaceText->setContent("N/A");                    
    }
    while(!m_arrayWidgets.empty())
        {
            ArrayWidgetsIt it = m_arrayWidgets.begin();
            m_ptrElementFrame->detachChildWidget(it->get());            
            m_arrayWidgets.erase(it);
        }

    saveDukeData();

    updateAll();
    repaint(event.getCon());
    
    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);

}

// vim:set tabstop=4 shiftwidth=4 expandtab:
