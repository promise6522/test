/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#include "is_dtoolwin.h"
#include "is_dtool.h"
#include "is_dapplication.h"
#include "is_deditor.h"
#include "is_dlogindlg.h"

DToolWin::DToolWin(DWidget *parent /*= 0*/, DMainWin * pMainWin /*= NULL*/, WFlags f /*= 0*/ )
    : DWidget(parent, f),
      m_beginButtonPos(0),
      m_pMainWin(pMainWin)
{
    setObjectName(ToolWin_ObjName);
    assert(pMainWin != NULL);
    pMainWin->setToolWin(this);
    initToolWin();
    update();
}

DToolWin::~DToolWin()
{
}

DMainWin * DToolWin::mainWin()
{
    return m_pMainWin;
}

void DToolWin::setMainWin(DMainWin * mainWin)
{
    m_pMainWin = mainWin;
}

ToolButtonIdx DToolWin::insertButton(DButtonPtr ptrButton, ToolButtonIdx idx)
{    
    if( idx >= (m_dynamicButtons.size() - 1) )
    {
        return pushBackButton(ptrButton);
    }

    m_dynamicButtons.insert(m_dynamicButtons.begin()+idx, ptrButton);
    calculateButtons();    

    return idx;    
}

void DToolWin::eraseButton(DButton * pDelButton)
{
    ToolButtonIt it = m_dynamicButtons.begin();

    for (; it != m_dynamicButtons.end(); ++it)
    {
        DButton *pButton = (*it).get();
        if(pButton == pDelButton)
        {
            m_dynamicButtons.erase(it);
            if(m_beginButtonPos >= m_dynamicButtons.size() - 1)
            {
                m_beginButtonPos = m_dynamicButtons.size() - 1;       
            }

            calculateButtons();
            return;
        }
    }
}    

void DToolWin::destoryWidgetAndButton(DWidget *pWidget, DButton * pButton)
{
    //erase button and widgetd
    eraseButtonWidgetMap(pButton);
    eraseButton(pButton);
    m_pMainWin->eraseWidget(pWidget);
    calculateButtons();   
}

void DToolWin::destoryWidgetAndButton(DWidget *pWidget, DButton * pButton,
                                      const is_response_call& response_call)
{
    LOG_DEBUG("Send destory Widget and Button message to client.");
    
    //destory button
    pWidget->destory(response_call);
    pButton->destory(response_call);

    LOG_DEBUG("Send destory message done.");

    //remove the button and widget from management module
    destoryWidgetAndButton(pWidget, pButton);
    LOG_DEBUG("Destory Widget and Button message in toolwin done.");

    //update the tool windiws
    m_ptrBgLabel->updateAll();
    m_ptrBgLabel->repaint(response_call);
}

void DToolWin::InsertWidgetAndButton(DWidgetPtr ptrWidget, DButtonPtr ptrButton)
{
    //erase button and widgetd
    insertButtonWidgetMap(ptrButton.get(), ptrWidget.get());
    pushBackButton(ptrButton);
    m_pMainWin->insertWidget(ptrWidget);    
}

void DToolWin::InsertWidgetAndButton(DWidgetPtr ptrWidget, 
                                     DButtonPtr ptrButton, 
                                     const is_response_call& response_call)
{
    //Add the button and widget
    ptrWidget->show(response_call);
    ptrButton->show(response_call);
    
    InsertWidgetAndButton(ptrWidget, ptrButton);    
}

ToolButtonIdx DToolWin::pushBackButton(DButtonPtr button)
{
    m_dynamicButtons.push_back(button);
    calculateButtons();
    
    return m_dynamicButtons.size() - 1;
}

DButton* DToolWin::findButton(const DPath& buttonPath)
{
    //using parent to find the DButton's pointer. Also we can using m_toolButtons;
    DObject * pObject = m_ptrBgLabel->findChild(buttonPath);
    return dynamic_cast<DButton *>(pObject);
}

DWidget* DToolWin::getRootWidget()
{
    //TBD: If there is background Image, we will return the m_ptrBgLabel.
    return dynamic_cast<DWidget *>(m_ptrBgLabel.get());
}

void DToolWin::initToolWin()
{
    m_ptrPackageSheet.reset(new(std::nothrow) DPackageSheet(m_pMainWin, this));
    assert(m_ptrPackageSheet.get() != NULL);
    m_ptrPackageSheet->setGeometry(MIN_COORD, MIN_COORD, 0, MAX_COORD);

    //load Images
    DImage img;
    img.load(getResPath() + ToolWin_BackgroundImage_Filename);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    //init background of tool window
    m_ptrBgLabel.reset(new(std::nothrow) DImageLabel("", img, this));
    m_ptrBgLabel->setBackgroundColor(ToolWin_Background_Color);
    m_ptrBgLabel->setFrameBorderColor(Duke_Transparent_Color);
    assert(m_ptrBgLabel.get() != NULL);
    m_ptrBgLabel->setGeometry(ToolWin_Background_X, ToolWin_Background_Y,
                              ToolWin_Background_W, ToolWin_Background_H);

    //init the button for floding/unfloding package sheet
    DImage outImg;
    outImg.load(getResPath() + ToolWin_PackageOutButton_Filename);
    outImg.setXScale(DImage::Stretch);
    outImg.setYScale(DImage::Stretch);
    outImg.setRelation(DImage::Disrelated);
    DImage inImg;
    inImg.load(getResPath() + ToolWin_PackageInButton_Filename);
    inImg.setXScale(DImage::Stretch);
    inImg.setYScale(DImage::Stretch);
    inImg.setRelation(DImage::Disrelated);
    m_ptrPackage.reset(new(std::nothrow) DButton("", outImg, inImg, this));
    assert(m_ptrPackage.get() != NULL);
    m_ptrPackage->setGeometry(ToolWin_Package_Button_X, ToolWin_Package_Button_Y,
                              ToolWin_Package_Button_W, ToolWin_Package_Button_H);
    //m_ptrPackage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPackage->registerEvent(DEvent::Select);
    m_ptrPackage->registerEvent(DEvent::Hover);
    m_ptrPackage->registerEvent(DEvent::PassingOut);    
    m_ptrPackage->setSelected(false);
    m_ptrPackage->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DToolWin::onClickPackage));
    m_ptrPackage->setEventRoutine(DEvent::Hover,
                                  this,
                                  static_cast<EventRoutine>(&DToolWin::onHoverPackge)); 
    m_ptrPackage->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DToolWin::onPassingOutBtn));

    //init access setting for login
    img.load(getResPath() + ToolWin_Nebutown_Log_Filename);
    m_ptrAccessSetting.reset(new(std::nothrow) DButton("", img, m_ptrBgLabel.get()));
    assert(m_ptrAccessSetting.get() != NULL);
    m_ptrAccessSetting->setGeometry(ToolWin_Log_X, ToolWin_Log_Y, 
                                    ToolWin_Log_Width, ToolWin_Log_Height);    
    m_ptrAccessSetting->setBackgroundColor(Duke_Transparent_Color);
    m_ptrAccessSetting->registerEvent(DEvent::Select);
    m_ptrAccessSetting->registerEvent(DEvent::Hover);
    m_ptrAccessSetting->registerEvent(DEvent::PassingOut);
    m_ptrAccessSetting->setEventRoutine(DEvent::Select,
                                        this,
                                        static_cast<EventRoutine>(&DToolWin::onClickButton));
    m_ptrAccessSetting->setEventRoutine(DEvent::Hover,
                                        this,
                                        static_cast<EventRoutine>(&DToolWin::onHoverBtn)); 
    m_ptrAccessSetting->setEventRoutine(DEvent::PassingOut,
                                        this,
                                        static_cast<EventRoutine>(&DToolWin::onPassingOutBtn));
    m_ptrAccessSetting->setSelected(false);
    DLogInDlgPtr ptrLogIn(new(std::nothrow) DLogInDlg(m_pMainWin, m_pMainWin->getRootWidget()));
    ptrLogIn->setGeometry(LogInX_InMainWin, LogInY_InMainWin, 
                          LogInW_InMainWin, LogInH_InMainWin);
    
    //Insert widget to mainwin
    m_pMainWin->insertWidget(ptrLogIn); 
    ptrLogIn->initDialog();
    ptrLogIn->setHideProperty(true);
    insertButtonWidgetMap(m_ptrAccessSetting.get(), ptrLogIn.get());

    //init Separator Line;
    img.load(getResPath() + ToolWin_SeparatorLine_Filename);
    m_ptrSeparatorLine.reset(new(std::nothrow) DImageLabel("", img, m_ptrBgLabel.get()));
    m_ptrSeparatorLine->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSeparatorLine->setFrameBorderColor(Duke_Transparent_Color);
    assert(m_ptrSeparatorLine.get() != NULL);

    //init up arrow
    img.load(getResPath() + ToolWin_UpButton_Filename);
    DImage hoverImg;
    hoverImg.load(getResPath() + ToolWin_UpButtonHover_Filename);
    hoverImg.setXScale(DImage::Stretch);
    hoverImg.setYScale(DImage::Stretch);
    hoverImg.setRelation(DImage::Disrelated);
    m_ptrUpArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrBgLabel.get()));
    assert(m_ptrUpArrow.get() != NULL);
    m_ptrUpArrow->setGeometry(ToolWin_UpArrow_X,
                              ToolWin_Arrow_Y,
                              ToolWin_Arrow_Width,
                              ToolWin_Arrow_Height);
    m_ptrUpArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrUpArrow->setSelected(false);
    m_ptrUpArrow->registerEvent(DEvent::Select);
    m_ptrUpArrow->registerEvent(DEvent::Grab);
    m_ptrUpArrow->registerEvent(DEvent::PassingIn);
    m_ptrUpArrow->registerEvent(DEvent::PassingOut);
    m_ptrUpArrow->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DToolWin::onUpArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::Grab,
                                  this,
                                  static_cast<EventRoutine>(&DToolWin::onUpArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::PassingIn, 
                                  this, 
                                  (EventRoutine)(&DToolWin::onPassingInArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::PassingOut, 
                                  this, 
                                  (EventRoutine)(&DToolWin::onPassingOutArrow));
    
    //init down arrow
    img.load(getResPath() + ToolWin_DownButton_Filename);
    hoverImg.load(getResPath() + ToolWin_DownButtonHover_Filename);
    m_ptrDownArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrBgLabel.get()));

    m_ptrDownArrow->setBackgroundColor(ToolWin_Background_Color);
    assert(m_ptrDownArrow.get() != NULL);
    m_ptrDownArrow->setGeometry(ToolWin_DownArrow_X,
                                ToolWin_Arrow_Y,
                                ToolWin_Arrow_Width,
                                ToolWin_Arrow_Height);
    m_ptrDownArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDownArrow->setSelected(false);
    m_ptrDownArrow->registerEvent(DEvent::Select);
    m_ptrDownArrow->registerEvent(DEvent::Grab);
    m_ptrDownArrow->registerEvent(DEvent::PassingIn);
    m_ptrDownArrow->registerEvent(DEvent::PassingOut);
    m_ptrDownArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DToolWin::onDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::Grab,
                                    this,
                                    static_cast<EventRoutine>(&DToolWin::onDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::PassingIn, 
                                    this, 
                                    (EventRoutine)(&DToolWin::onPassingInArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::PassingOut, 
                                    this, 
                                    (EventRoutine)(&DToolWin::onPassingOutArrow));

    //init warehouse
    initWarehouse();
}

void DToolWin::initWarehouse()
{
    DImage img;
    for(int i = 0; i < RunWarehouse; i++)
    {
        DWarehouseDlgPtr ptrWarehouse(new(std::nothrow)
                                      DWarehouseDlg(static_cast<WarehouseType>(i),
                                                    m_pMainWin,
                                                    m_pMainWin->getRootWidget()));
        ptrWarehouse->setGeometry(WarehouseX_InMainWin, WarehouseY_InMainWin, 
                                  WarehouseW_InMainWin, WarehouseH_InMainWin);
        //Insert widget to mainwin
        m_pMainWin->insertWidget(ptrWarehouse); 
        ptrWarehouse->initDialog();
        ptrWarehouse->setHideProperty(true);    
        createWarehouseButton(ptrWarehouse.get(), static_cast<WarehouseType>(i));
    }
    
    //add Run Editor
    DRunEditorPtr ptrRunhouse(new(std::nothrow) DRunEditor(RunEditor_ObjName, 
                DEditor::DialogModel,
                m_pMainWin,
                m_pMainWin->getRootWidget()));
    ptrRunhouse->setGeometry(4000, 4000, 
            Default_RunEditor_W_InMainWin, 
            Default_RunEditor_H_InMainWin);  
    m_pMainWin->insertWidget(ptrRunhouse); 
    ptrRunhouse->initDialog();
    ptrRunhouse->setHideProperty(true);  
    ptrRunhouse->initRunEditor();
  
    createWarehouseButton(ptrRunhouse.get(), RunWarehouse);
    
    //add Shared Warehouse
    DSharedhouseDlgPtr ptrSharedhouse(new(std::nothrow)
                                         DSharedhouseDlg(m_pMainWin,                                                                                                                             m_pMainWin->getRootWidget()));
    ptrSharedhouse->setGeometry(SharedhouseX_InMainWin, SharedhouseY_InMainWin, 
                                              SharedhouseW_InMainWin, SharedhouseH_InMainWin);
    m_pMainWin->insertWidget(ptrSharedhouse); 
    ptrSharedhouse->initDialog();
    ptrSharedhouse->setHideProperty(true);    
    createWarehouseButton(ptrSharedhouse.get(), SharedWarehouse);
}

DButton * DToolWin::createWarehouseButton(DWidget * pWidget, WarehouseType type)
{
    if(pWidget == NULL)
    {
        assert(!"NUll warehouse dialog object.");
        return NULL;
    }

    std::string buttonImgs[] = { ToolWin_ObjectButton_Filename,
                                 ToolWin_IFButton_Filename,
                                 ToolWin_DeclButton_Filename,
                                 ToolWin_ImplButton_Filename,
                                 ToolWin_ContButton_Filename,
                                 ToolWin_AcsButton_Filename,
                                 ToolWin_RunButton_Filename ,
                                 ToolWin_SharedButton_Filename};

    std::string selButtonImgs[] = { ToolWin_ObjectSelButton_Filename,
                                    ToolWin_IFSelButton_Filename,
                                    ToolWin_DeclSelButton_Filename,
                                    ToolWin_ImplSelButton_Filename,
                                    ToolWin_ContSelButton_Filename,
                                    ToolWin_AcsSelButton_Filename,
                                    ToolWin_RunSelButton_Filename,
                                    ToolWin_SharedSelButton_Filename};
    //load the image from files
    DImage img;
    img.load(getResPath() + buttonImgs[type]);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;    
    selImg.load(getResPath() + selButtonImgs[type]);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);
    
    DButtonPtr ptrButton(new(std::nothrow) DButton("",
                                                   img,
                                                   selImg,
                                                   m_ptrBgLabel.get()));
    assert(ptrButton.get() != NULL);
    ptrButton->registerEvent(DEvent::Select);
    ptrButton->registerEvent(DEvent::Hover);
    ptrButton->registerEvent(DEvent::PassingOut);
    ptrButton->setEventRoutine(DEvent::Select,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onClickButton));
    ptrButton->setEventRoutine(DEvent::Hover,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onHoverBtn)); 
    ptrButton->setEventRoutine(DEvent::PassingOut,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onPassingOutBtn));
    m_warehouseButtons.push_back(ptrButton);
    ptrButton->setSelected(false);
    assert(ptrButton.use_count() == 2);       

    //bind each others
    //Insert button and widget
    insertButtonWidgetMap(ptrButton.get(), pWidget);
    
    //TBC
    //calculateButtons();    
    //m_ptrBgLabel->updateAll();

    return ptrButton.get();
}

void DToolWin::calculateButtons()
{
    int curY = ToolWin_Button_StartY;
    const int curX = ToolWin_Button_X;
    const int curW = ToolWin_Button_Width;
    const int curH = ToolWin_Button_Height;
    
    //set warehouse button's Geometry
    ToolButtonIt it = m_warehouseButtons.begin();
    for(; it != m_warehouseButtons.end(); ++it)
    {
        (*it)->setGeometry(curX, curY, curW, curH);
        curY += ToolWin_Button_Height + ToolWin_Button_Spacing;
    }

    //set Separator Line
    m_ptrSeparatorLine->setGeometry(curX, 
                                    curY, 
                                    ToolWin_SeparatorLine_Width, 
                                    ToolWin_SeparatorLine_Height);
    curY += ToolWin_SeparatorLine_Height + ToolWin_Button_Spacing;

    //for other dynamic buttons
    ToolButtonIdx pos = 0;
    for(ToolButtonIt iter = m_dynamicButtons.begin(); iter != m_dynamicButtons.end(); ++iter)
    {
        if((pos >= m_beginButtonPos) && (pos < m_beginButtonPos + ToolWin_DynamicButton_Size))
        {
            (*iter)->setGeometry(curX, curY, curW, curH);
            curY += ToolWin_Button_Height + ToolWin_Button_Spacing;
            //assert(curY < MAX_COORD);
        }
        else
        {
            (*iter)->setGeometry(0, 0, 0, 0);
        }
        ++pos;
    }
}

DButton * DToolWin::createButtonForWidget(DWidget * pWidget)
{
    if(pWidget == NULL)
        return NULL;
    
    DButtonPtr ptrButton(new(std::nothrow) DButton("",
                                                   m_buttonImg,
                                                   m_selButtonImg,
                                                   m_ptrBgLabel.get()));
    assert(ptrButton.get() != NULL);
    ptrButton->registerEvent(DEvent::Select);
    ptrButton->registerEvent(DEvent::Hover);
    ptrButton->registerEvent(DEvent::PassingOut);
    
    ptrButton->setEventRoutine(DEvent::Select,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onClickButton));
    ptrButton->setEventRoutine(DEvent::Hover,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onHoverBtn)); 
    ptrButton->setEventRoutine(DEvent::PassingOut,
                               this,
                               static_cast<EventRoutine>(&DToolWin::onPassingOutBtn));

    ptrButton->setGeometry(0, 0, 0, 0);
    m_dynamicButtons.push_back(ptrButton);
    assert(ptrButton.use_count() == 2);       

    //bind each others
    //Insert button and widget
    insertButtonWidgetMap(ptrButton.get(), pWidget);
    calculateButtons();
    
    m_ptrBgLabel->updateAll();

    return ptrButton.get();
}

void DToolWin::insertButtonWidgetMap(DButton * pButton, DWidget * pWidget)
{
    if(pButton == NULL || pWidget == NULL)
        return;
    
    m_buttonWidget.insert(ButtonWidgetpair(pButton, pWidget));
}

DWidget *  DToolWin::findWidgetFromButton(DButton * pButton)
{
    ButtonWidgetMapIt it = m_buttonWidget.find(pButton);

    if( it != m_buttonWidget.end())
    {
        return it->second;
    }

    return NULL;
}

DButton *  DToolWin::findButtonFromWidget(DWidget * pWidget)
{
    for(ButtonWidgetMapIt it = m_buttonWidget.begin(); it != m_buttonWidget.end(); ++it)
    {
        if(it->second == pWidget)
        {
            return it->first;
        }
    }

    return NULL;    
}

void DToolWin::eraseButtonWidgetMap(DButton * pButton)
{
    ButtonWidgetMapIt it = m_buttonWidget.find(pButton);

    if( it != m_buttonWidget.end())
    {
        m_buttonWidget.erase(it);
    }
}

void DToolWin::eraseButtonWidgetMap(DWidget * pWidget)
{
    for(ButtonWidgetMapIt it = m_buttonWidget.begin(); it != m_buttonWidget.end(); ++it)
    {
        if(it->second == pWidget)
        {
            m_buttonWidget.erase(it);
        }
    }
}

void DToolWin::update()
{
    //update Tool window
    calculateButtons();
    DWidget *pToolFrame = dynamic_cast<DWidget *>(parent());
    if(pToolFrame == NULL)
    {
        assert(!"Could not get pToolFrame.");
        return;
    }
    pToolFrame->updateAll();    
}

void DToolWin::onClickButton(const DEvent & event)
{
    LOG_DEBUG("====> DToolWin::onClickButton: "<<event.getEventType());
    
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = findButton(rWidgetPath[0]);    
    if(pButton != NULL)
    {
        bool isSelected = false;
        
        //find related widget, and disable/enable this widget
        DWidget * pWidget = findWidgetFromButton(pButton);
        if(pWidget != NULL)
        {
            if (pWidget->isHide())
            {
                pWidget->setHideProperty(false);
                m_pMainWin->setActiveWidget(pWidget);
                //only update the placement
                m_pMainWin->repaintAll(event.getCon(), false);
                /* no muti-paint, but slowly
                m_pMainWin->getRootWidget()->repaint(event.getCon());
                */
                isSelected = true;
            }
            else
            {
                pWidget->setHideProperty(true);
                pWidget->repaint(event.getCon(), false);
                
                DEditor * pEditor = dynamic_cast<DEditor *>(pWidget);
                if(pEditor != NULL)
                {
                    pEditor->hideAllSubEditors(event.getCon());
                }
                
                isSelected = false;
            }
        }

        pButton->setSelected(isSelected);
        
        //send to client_thread_functor
        pButton->repaint(event.getCon());
    }
}

void DToolWin::onClickPackage(const DEvent & event)
{
    if(m_ptrPackage->isSelected())
    { 
        fold(event);
        m_ptrPackage->setSelected(false);
    }
    else
    {
        unfold(event);
        m_ptrPackage->setSelected(true);
    }
    
    updateAll();    
    repaint(event.getCon());

    getApplication()->tip()->remove(event.getCon());
}

void DToolWin::fold(const DEvent & event)
{
    DWidget* pToolFrame = dynamic_cast<DWidget *>(this->parent());

    if(pToolFrame == NULL)
        return;
        
    pToolFrame->setGeometry(MIN_COORD, MIN_COORD, Default_ToolFrame_Width, MAX_COORD);
    m_ptrPackageSheet->setGeometry(MIN_COORD, MIN_COORD, 0, MAX_COORD);
    m_ptrBgLabel->setGeometry(ToolWin_Background_X, ToolWin_Background_Y,
                              ToolWin_Background_W, ToolWin_Background_H);
    m_ptrPackage->setGeometry(ToolWin_Package_Button_X, ToolWin_Package_Button_Y,
                              ToolWin_Package_Button_W, ToolWin_Package_Button_H);
    pToolFrame->updateAll();
    pToolFrame->repaint(event.getCon());
}

void DToolWin::unfold(const DEvent & event)
{
    DWidget* pToolFrame = dynamic_cast<DWidget *>(this->parent());

    if(pToolFrame == NULL)
        return;
        
    pToolFrame->setGeometry(MIN_COORD, MIN_COORD, 3 * Default_ToolFrame_Width, MAX_COORD);
    m_ptrPackageSheet->setGeometry(MIN_COORD, MIN_COORD, 
                                   2*(MAX_COORD-ToolWin_PackageEx_Button_W)/3, MAX_COORD);
    m_ptrBgLabel->setGeometry(2*(MAX_COORD-ToolWin_PackageEx_Button_W)/3, MIN_COORD, 
                              (MAX_COORD-ToolWin_PackageEx_Button_W)/3, MAX_COORD);
    m_ptrPackage->setGeometry(ToolWin_PackageEx_Button_X, ToolWin_PackageEx_Button_Y,
                              ToolWin_PackageEx_Button_W, ToolWin_PackageEx_Button_H);
    pToolFrame->updateAll();
    pToolFrame->repaint(event.getCon());
}

void DToolWin::onUpArrow(const DEvent & event)
{
    if(m_beginButtonPos <= 0)
    {
        m_beginButtonPos = 0;
    }   
    else
    {
        --m_beginButtonPos;
    }

    if(m_beginButtonPos == 0)
    {
        m_ptrUpArrow->setSelected(false);
    }    

    calculateButtons();
    updateAll();
    repaint(event.getCon());    
}

void DToolWin::onDownArrow(const DEvent & event)
{
    if(m_beginButtonPos + ToolWin_DynamicButton_Size >= m_dynamicButtons.size())
    {
        m_beginButtonPos = (m_dynamicButtons.size() < ToolWin_DynamicButton_Size) ? 
            0 : m_dynamicButtons.size() - ToolWin_DynamicButton_Size;
    }
    else
    {        
        ++m_beginButtonPos;
    }

    if((m_dynamicButtons.size() == 0) 
       || (m_beginButtonPos + ToolWin_DynamicButton_Size == m_dynamicButtons.size()))
    {
        m_ptrDownArrow->setSelected(false);
    }    
    calculateButtons();
    updateAll();
    repaint(event.getCon());
}

void DToolWin::onPassingInArrow(const DEvent& event)
{
    LOG_DEBUG("ToolWin: on hover");
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = findButton(rWidgetPath[0]);
    if(pButton != NULL)
    {
        //if up button
        if(pButton == m_ptrUpArrow.get() && (m_beginButtonPos == 0))
        {
            return;
        }

        //if down button
        if(pButton == m_ptrDownArrow.get() 
           && (m_beginButtonPos + ToolWin_DynamicButton_Size >= m_dynamicButtons.size()))
        {
            return;
        }
            
        pButton->setSelected(true);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DToolWin::onPassingOutArrow(const DEvent& event)
{
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = findButton(rWidgetPath[0]);
    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DToolWin::onHoverBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pSrcButton = dynamic_cast<DButton *>(pObject); 
    if (pSrcButton == NULL)
    {
        return;
    }

    DDialog* pSrcDlg = dynamic_cast<DDialog *>(findWidgetFromButton(pSrcButton));
    if (pSrcDlg == NULL)
    {
        return;
    }    

    // open tip
    getApplication()->tip()->add(pSrcButton, pSrcDlg->titleText(), event.getCon());
}

void DToolWin::onPassingOutBtn(const DEvent &event)
{
    // close tip
    getApplication()->tip()->remove(event.getCon());
}

void DToolWin::onHoverPackge(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pSrcButton = dynamic_cast<DButton *>(pObject); 
    if (pSrcButton == NULL)
    {
        return;
    }

    getApplication()->tip()->add(pSrcButton, "Package Sheet", event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:298

