/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/
#include <boost/lexical_cast.hpp>

#include "is_dconteditor.h"
#include "is_dimpleditor.h"
#include "is_danchoreditor.h"
#include "is_dstorageeditor.h"
#include "is_darrayinterfaceeditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"

DContEditor::DContEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f),
      m_curFuncPage(0), m_storageNum(0)
{
    m_funcLayer = m_anchorLayer = m_storageLayer = 0;
    m_funcLayerHeight = m_storageLayerHeight = ContEditor_Layer;
    m_anchorLayerHeight = 2000;
    m_anchorRow = m_storageRow = 0;
    m_horiCuttingLineHeight = m_vertiCuttingLineWidth = 0;
    m_storageCreateBtnHeight = 0;
    setObjectName(ContEditor_ObjName);
    assert(pMainWin != NULL);    
}

DContEditor::DContEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f),
      m_curFuncPage(0), m_storageNum(0)
{
    m_funcLayer = m_anchorLayer = m_storageLayer = 0;
    m_funcLayerHeight = m_storageLayerHeight = ContEditor_Layer;
    m_storageCreateBtnHeight = 0;
    m_anchorLayerHeight = 2000;
    m_anchorRow = m_storageRow = 0;
    m_horiCuttingLineHeight = m_vertiCuttingLineWidth = 0;
    setObjectName(ContEditor_ObjName);
    assert(pMainWin != NULL);
}

DContEditor::~DContEditor()
{
}

void DContEditor::duplicateItemsByHandle(const duke_media_handle& hcont)
{
    if (!hcont.is_object_container_des()) {
        assert(!"Invalid container handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();
        
    duke_media_container* pContMedia = 
        new(std::nothrow) duke_media_container(this->getApplication()->get_host_committer_id(), 
                getApplication()->username());

    pContMedia->copy(hcont);
    m_ptr = pContMedia;
    m_handle = pContMedia->get_handle();

    assert(m_ptr != NULL);    
}

void DContEditor::reload()
{
    LOG_DEBUG("DContEditor:: reload ......");

    //clear wideget
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); 
            it != m_funcWidgets.end(); 
            ++it) {
        if (it->first) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget((it->first).get());
            if(pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrFuncFrame->detachChildWidget(it->first.get());
            
            if (it->second) {
                //delete subEditor if there is
                pEditor = findSubEditorByWidget((it->second).get());
                if(pEditor != NULL) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }

                m_ptrFuncFrame->detachChildWidget(it->second.get());
            }
        }
    }
    m_funcWidgets.clear();

    for (StorageConstrIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        if (it->first.get()) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget((it->first).get());
            if(pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrStorageFrame->detachChildWidget(it->first.get());

            if (it->second) {
                //delete subEditor if there is
                pEditor = findSubEditorByWidget((it->second).get());
                if(pEditor != NULL) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }

                m_ptrStorageFrame->detachChildWidget(it->second.get());
            }
        }
    }
    m_storageWidgets.clear();

    for (AnchorWidgetIt it = m_anchorWidgets.begin(); 
            it != m_anchorWidgets.end(); 
            ++it) {
        if (it->get()) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->get());
            if(pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrAnchorFrame->detachChildWidget(it->get());
        }
    }
    m_anchorWidgets.clear();

    // clear
    m_storageLayer = 0;
    m_funcLayer = 0;
    m_anchorLayer = 0;
    m_funcLayerHeight = ContEditor_Layer;
    m_storageLayerHeight = ContEditor_Layer;
    m_anchorLayerHeight = ContEditor_Layer;

    setMediaByHandle(m_handle);
    // get name & icon
    duke_media_container *pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia) {
        releaseMedia();
        return;
    }
    pContMedia->get_name(m_dukeName);
    pContMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    // reload media data
    initFuncExisted();
    initStorageExisted();
    initAnchorExisted();
    initRootAnchorExisted();

    // update
    updateFuncView();
    updateStorageView();
    updateAnchorView();
}

void DContEditor::initContEditor()
{
    // get name & icon
    duke_media_container *pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia) {
        releaseMedia();
        return;
    }
    pContMedia->get_name(m_dukeName);
    pContMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    dumpContainerInfo();
    initCuttingLine();
    initFuncFrame();
    initStorageFrame();
    initAnchorFrame();
    initRootAnchorFrame();

    updateFuncView();
    updateStorageView();
    updateAnchorView();
}

void DContEditor::initCuttingLine()
{
    // hori
    DImage horiCuttingLineImg;
    horiCuttingLineImg.load(getResPath() + ContEditor_HoriCut_Filename);
    horiCuttingLineImg.setXScale(DImage::Stretch);
    horiCuttingLineImg.setYScale(DImage::Stretch);
    horiCuttingLineImg.setRelation(DImage::Disrelated);

    m_ptrHoriCuttingLine.reset(new(std::nothrow) DImageLabel("", horiCuttingLineImg, this->getBodyFrame()));
    m_ptrHoriCuttingLine->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrHoriCuttingLine.get());
    m_ptrHoriCuttingLine->setHideProperty(false);
    m_ptrHoriCuttingLine->registerEvent(DEvent::DnD_Start, true);
    m_ptrHoriCuttingLine->registerEvent(DEvent::DnD_Release, true);
    m_ptrHoriCuttingLine->registerEvent(DEvent::Detail, true);
    m_ptrHoriCuttingLine->registerEvent(DEvent::Select, true);
    m_ptrHoriCuttingLine->registerEvent(DEvent::Resize_Start, true);
    m_ptrHoriCuttingLine->registerEvent(DEvent::Resize_Release, true);

    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().height() != 0) && (getBodyFrame()->geometrySize().height() != 0)) {
        int heightInEditor = ContEditor_HoriCuttingLine_H_InMainWin * MAX_COORD / geometrySize().height(); 
        int heightInView  = heightInEditor * MAX_COORD / getViewFrame()->geometrySize().height(); 
        m_horiCuttingLineHeight = heightInView *  MAX_COORD / getBodyFrame()->geometrySize().height();         
    }     
    m_ptrHoriCuttingLine->setGeometry(ContEditor_HoriCuttingLine_X_InBodyFrame,
                                      MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame - m_horiCuttingLineHeight,
                                      ContEditor_HoriCuttingLine_W_InBodyFrame,
                                      m_horiCuttingLineHeight);
    // vert1
    DImage vertiCuttingLineImg;
    vertiCuttingLineImg.load(getResPath() + ContEditor_VertiCut_Filename);
    vertiCuttingLineImg.setXScale(DImage::Stretch);
    vertiCuttingLineImg.setYScale(DImage::Stretch);
    vertiCuttingLineImg.setRelation(DImage::Disrelated);

    m_ptrVertiCuttingLine1.reset(new(std::nothrow) DImageLabel("", vertiCuttingLineImg, this->getBodyFrame()));
    m_ptrVertiCuttingLine1->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrVertiCuttingLine1.get());
    m_ptrVertiCuttingLine1->setHideProperty(false);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::DnD_Start, true);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::DnD_Release, true);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::Detail, true);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::Select, true);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::Resize_Start, true);
    m_ptrVertiCuttingLine1->registerEvent(DEvent::Resize_Release, true);

    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().width() != 0) && (getBodyFrame()->geometrySize().width() != 0)) {
        int widthInEditor = ContEditor_VertiCuttingLine1_W_InMainWin * MAX_COORD / geometrySize().width(); 
        int widthInView  = widthInEditor * MAX_COORD / getViewFrame()->geometrySize().width(); 
        m_vertiCuttingLineWidth = widthInView *  MAX_COORD / getBodyFrame()->geometrySize().width();         
    }     
    m_ptrVertiCuttingLine1->setGeometry(ContEditor_VertiCuttingLine1_X_InBodyFrame,
                                      MIN_COORD,
                                      m_vertiCuttingLineWidth,
                                      MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame - m_horiCuttingLineHeight);

    // vert2
    m_ptrVertiCuttingLine2.reset(new(std::nothrow) DImageLabel("", vertiCuttingLineImg, this->getBodyFrame()));
    m_ptrVertiCuttingLine2->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrVertiCuttingLine2.get());
    m_ptrVertiCuttingLine2->setHideProperty(false);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::DnD_Start, true);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::DnD_Release, true);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::Detail, true);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::Select, true);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::Resize_Start, true);
    m_ptrVertiCuttingLine2->registerEvent(DEvent::Resize_Release, true);
    m_ptrVertiCuttingLine2->setGeometry(ContEditor_VertiCuttingLine2_X_InBodyFrame,
                                      MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame,
                                      m_vertiCuttingLineWidth,
                                      ContEditor_VertiCuttingLine2_H_InBodyFrame);
    return;
}

void DContEditor::initFuncFrame()
{
    m_ptrFuncFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrFuncFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrFuncFrame.get());
    m_ptrFuncFrame->setGeometry(ContEditor_FuncFrame_X_InBodyFrame, 
                                MIN_COORD, 
                                ContEditor_FuncFrame_W_InBodyFrame, 
                                MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame - m_horiCuttingLineHeight);
    m_ptrFuncFrame->setHideProperty(false);
    m_ptrFuncFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrFuncFrame->setAutoFill(false);
    m_ptrFuncFrame->setFrameStyle(DFrame::Panel);

    // set pass though
    m_ptrFuncFrame->registerEvent(DEvent::Detail, true);
    m_ptrFuncFrame->registerEvent(DEvent::Select, true);
    m_ptrFuncFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrFuncFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrFuncFrame->registerEvent(DEvent::DnD_Start, true);

    //m_ptrFuncFrame->registerEvent(DEvent::Drag);
    m_ptrFuncFrame->registerEvent(DEvent::DnD_Release);
    m_ptrFuncFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DContEditor::onDnDReleaseFuncFrame));

    DImage img;    
    DImage hoverImg;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    hoverImg.setXScale(DImage::Stretch);
    hoverImg.setYScale(DImage::Stretch);
    hoverImg.setRelation(DImage::Disrelated);

    img.load(getResPath() + ContEditor_LeftArrowButton_Filename);
    hoverImg.load(getResPath() + ContEditor_LeftArrowHoverButton_Filename);
    m_ptrFuncLArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrFuncFrame.get()));
    assert(m_ptrFuncLArrow.get() != NULL);
    m_ptrFuncLArrow->setGeometry(ContEditor_LArrow_X,
                                 ContEditor_Arrow_Y,
                                 ContEditor_Arrow_Width,
                                 ContEditor_Arrow_Height);
    m_ptrFuncLArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncLArrow->setSelected(false);
    m_ptrFuncLArrow->registerEvent(DEvent::Select);
    m_ptrFuncLArrow->registerEvent(DEvent::Grab);
    m_ptrFuncLArrow->registerEvent(DEvent::PassingIn);
    m_ptrFuncLArrow->registerEvent(DEvent::PassingOut);
    m_ptrFuncLArrow->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DContEditor::onFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::Grab,
                                     this,
                                     static_cast<EventRoutine>(&DContEditor::onFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::PassingIn, 
                                     this, 
                                     (EventRoutine)(&DContEditor::onPassingInFuncArrow));
    m_ptrFuncLArrow->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DContEditor::onPassingOutFuncArrow));

    img.load(getResPath() + ContEditor_RightArrowButton_Filename);
    hoverImg.load(getResPath() + ContEditor_RightArrowHoverButton_Filename);
    m_ptrFuncRArrow.reset(new(std::nothrow) DButton("", img, hoverImg, m_ptrFuncFrame.get()));
    assert(m_ptrFuncRArrow.get() != NULL);
    m_ptrFuncRArrow->setGeometry(ContEditor_RArrow_X,
                                 ContEditor_Arrow_Y,
                                 ContEditor_Arrow_Width,
                                 ContEditor_Arrow_Height);
    m_ptrFuncRArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrFuncRArrow->setSelected(false);
    m_ptrFuncRArrow->registerEvent(DEvent::Select);
    m_ptrFuncRArrow->registerEvent(DEvent::Grab);
    m_ptrFuncRArrow->registerEvent(DEvent::PassingIn);
    m_ptrFuncRArrow->registerEvent(DEvent::PassingOut);
    m_ptrFuncRArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DContEditor::onFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::Grab,
                                     this,
                                     static_cast<EventRoutine>(&DContEditor::onFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::PassingIn, 
                                     this, 
                                     (EventRoutine)(&DContEditor::onPassingInFuncArrow));
    m_ptrFuncRArrow->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DContEditor::onPassingOutFuncArrow));


    // TODO init existed decl/impl in this container 
    initFuncExisted();
}

void DContEditor::initFuncExisted()
{
    if (!m_ptr || !m_ptr->is_object_container_des()) {
        releaseMedia();
        return;
    }
    duke_media_handle_vector decls;
    dynamic_cast<duke_media_container *>(m_ptr)->get_declarations(decls);
    for (duke_media_handle_const_iterator it = decls.begin(); 
            it != decls.end(); 
            ++it) {
        // skip the get_anchors and get_storages 
        if (it->is_function_get_anchors() || it->is_function_get_storages())
            continue;

        // decl
        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, *it,
                             ContEditor_Decl_Filename);
        DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                    declImg,
                    m_ptrFuncFrame.get()));
        ptrDeclButton->setFocusAttr(true);
        ptrDeclButton->registerEvent(DEvent::Activate);
        ptrDeclButton->registerEvent(DEvent::DnD_Start);
        //ptrDeclButton->registerEvent(DEvent::Drag);
        ptrDeclButton->registerEvent(DEvent::Hover);
        ptrDeclButton->registerEvent(DEvent::PassingOut);
        ptrDeclButton->registerEvent(DEvent::Delete);
        ptrDeclButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteFunc)); 
        ptrDeclButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrDeclButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrDeclButton->setMediaByHandle((*it));
 
        // impl
        duke_media_handle himpl;
        dynamic_cast<duke_media_container *>(m_ptr)->get_implementation((*it), himpl);
        if (himpl.is_type_null()) {
            m_funcWidgets.push_back(ContWidgetPair(ptrDeclButton, DWidgetPtr()));
            continue;
        }

        DImage implImg;
        implImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(implImg, himpl,
                            ContEditor_Impl_Filename);
        DButtonPtr ptrImplButton(new(std::nothrow) DButton("",
                    implImg,
                    m_ptrFuncFrame.get()));
        ptrImplButton->setFocusAttr(true);
        ptrImplButton->registerEvent(DEvent::Activate);
        ptrImplButton->registerEvent(DEvent::Hover);
        ptrImplButton->registerEvent(DEvent::PassingOut);
        ptrImplButton->registerEvent(DEvent::Delete);
        ptrImplButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteFunc)); 
        ptrImplButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateImplBtn)); 
        ptrImplButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrImplButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrImplButton->setMediaByHandle(himpl);

        m_funcWidgets.push_back(ContWidgetPair(ptrDeclButton, ptrImplButton));
    }

    updateFuncView();
}

void DContEditor::initStorageFrame()
{
    // init storage frame
    m_ptrStorageFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrStorageFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrStorageFrame.get());
    m_ptrStorageFrame->setGeometry(ContEditor_StorageFrame_X_InBodyFrame, 
                                MIN_COORD, 
                                ContEditor_StorageFrame_W_InBodyFrame, 
                                MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame - m_horiCuttingLineHeight);
    m_ptrStorageFrame->setHideProperty(false);
    m_ptrStorageFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrStorageFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrStorageFrame->setAutoFill(false);
    m_ptrStorageFrame->setFrameStyle(DFrame::Panel);

    // set pass through
    m_ptrStorageFrame->registerEvent(DEvent::Detail, true);
    m_ptrStorageFrame->registerEvent(DEvent::Select, true);
    m_ptrStorageFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrStorageFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrStorageFrame->registerEvent(DEvent::DnD_Start, true);
    //m_ptrStorageFrame->registerEvent(DEvent::Drag);
    m_ptrStorageFrame->registerEvent(DEvent::DnD_Release);
    m_ptrStorageFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DContEditor::onDnDReleaseStorageFrame)); 

    //init the icon of the editor
    DImage img;
    img.load(getResPath() + ContEditor_StorageNumIcon_Filename);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    m_ptrStorageNumIcon.reset(new(std::nothrow) DImageLabel("", img, m_ptrStorageFrame.get()));
    assert(m_ptrStorageNumIcon.get() != NULL);
    m_ptrStorageNumIcon->setBackgroundColor(Duke_Transparent_Color);
    m_ptrStorageNumIcon->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrStorageNumIcon->setAutoFill(false);
    m_ptrStorageNumIcon->registerEvent(DEvent::DnD_Start, true);
    //m_ptrStorageNumIcon->registerEvent(DEvent::Drag, true);
    m_ptrStorageNumIcon->registerEvent(DEvent::DnD_Release, true);
    m_ptrStorageNumIcon->registerEvent(DEvent::Detail, true);
    int storageNumHeight = 0;
    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().height() != 0) && (getBodyFrame()->geometrySize().height() != 0)) {
        int heightInEditor = ContEditor_StorageNum_H_InMainWin * MAX_COORD / geometrySize().height(); 
        int heightInView  = heightInEditor * MAX_COORD / getViewFrame()->geometrySize().height(); 
        storageNumHeight = heightInView *  MAX_COORD / getBodyFrame()->geometrySize().height();         
    }     
    m_ptrStorageNumIcon->setGeometry(ContEditor_StorageNum_X_InStorageFrame, 
                                ContEditor_StorageNum_Y_InStorageFrame, 
                                ContEditor_StorageNum_W_InStorageFrame, 
                                storageNumHeight);

    // init the editor of storage number 
    m_ptrStorageNum.reset(new(std::nothrow) DLineEdit(m_ptrStorageFrame.get()));
    assert(m_ptrStorageNum.get() != NULL);
    m_ptrStorageNum->setBackgroundColor(Duke_Transparent_Color);
    m_ptrStorageNum->setFrameBorderColor(Duke_Transparent_Color);    
    m_ptrStorageNum->setFocusAttr(true);
    m_ptrStorageNum->registerEvent(DEvent::Focus);
    m_ptrStorageNum->registerEvent(DEvent::Input);
    m_ptrStorageNum->setEventRoutine(DEvent::Input, 
                                       this,
                                       static_cast<EventRoutine>(&DContEditor::onInputStorageNum));
    int storageTextHeight = 0;
    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().height() != 0) && (getBodyFrame()->geometrySize().height() != 0)) {
        int heightInEditor = ContEditor_StorageText_H_InMainWin * MAX_COORD / geometrySize().height(); 
        int heightInView  = heightInEditor * MAX_COORD / getViewFrame()->geometrySize().height(); 
        storageTextHeight = heightInView *  MAX_COORD / getBodyFrame()->geometrySize().height();         
    }     
    m_ptrStorageNum->setGeometry(ContEditor_StorageText_X_InStorageFrame, 
                                ContEditor_StorageText_Y_InStorageFrame, 
                                ContEditor_StorageText_W_InStorageFrame, 
                                storageTextHeight);

    // init the button of storage creation
    DImage btnImg;
    btnImg.load(getResPath() + ContEditor_StorageCreateBtn_Filename);
    btnImg.setXScale(DImage::Stretch);
    btnImg.setYScale(DImage::Stretch);
    btnImg.setRelation(DImage::Disrelated);
    m_ptrStorageCreateBtn.reset(new(std::nothrow) DButton("",
                btnImg,
                m_ptrStorageFrame.get()));
    m_ptrStorageCreateBtn->setFocusAttr(true);
    m_ptrStorageCreateBtn->registerEvent(DEvent::Select);
    m_ptrStorageCreateBtn->setEventRoutine(DEvent::Select, 
                                       this,
                                       static_cast<EventRoutine>(&DContEditor::onClickStorageCreateBtn));
    m_ptrStorageCreateBtn->registerEvent(DEvent::Hover);
    m_ptrStorageCreateBtn->registerEvent(DEvent::PassingOut);
    if((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().height() != 0) && (getBodyFrame()->geometrySize().height() != 0)) {
        int heightInEditor = ContEditor_StorageCreate_H_InMainWin * MAX_COORD / geometrySize().height(); 
        int heightInView  = heightInEditor * MAX_COORD / getViewFrame()->geometrySize().height(); 
        m_storageCreateBtnHeight = heightInView *  MAX_COORD / getBodyFrame()->geometrySize().height();         
    }     
    m_ptrStorageCreateBtn->setGeometry(ContEditor_StorageCreate_X_InStorageFrame,                                       
                                       ContEditor_StorageCreate_Y_InStorageFrame,
                                       ContEditor_StorageCreate_W_InStorageFrame,
                                       m_storageCreateBtnHeight);

    // TODO init existed storage in this container 
    initStorageExisted();
}

void DContEditor::initStorageExisted()
{
    if (!m_ptr || !m_ptr->is_object_container_des()) {
        releaseMedia();
        return;
    }

    duke_media_handle_pair_vector storageMap;
    dynamic_cast<duke_media_container *>(m_ptr)->get_storages(storageMap);

    // display data for storage number 
    m_storageNum = storageMap.size();
    m_ptrStorageNum->setContent(boost::lexical_cast<std::string>(m_storageNum));
    for (duke_media_handle_pair_vector_const_iterator it = storageMap.begin(); 
            it != storageMap.end(); 
            ++it) {

        DImage storageImg;
        storageImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(storageImg, it->first,
                            ContEditor_Storage_Filename);
        DButtonPtr ptrStorageBtn(new(std::nothrow) DButton("",
                    storageImg,
                    m_ptrStorageFrame.get()));
        ptrStorageBtn->setFocusAttr(true);
        ptrStorageBtn->registerEvent(DEvent::Activate);
        ptrStorageBtn->registerEvent(DEvent::DnD_Start, true);
        //ptrStorageBtn->registerEvent(DEvent::Drag, true);
        ptrStorageBtn->registerEvent(DEvent::Hover);
        ptrStorageBtn->registerEvent(DEvent::PassingOut);
        ptrStorageBtn->registerEvent(DEvent::Delete);  
        ptrStorageBtn->registerEvent(DEvent::Activate);
        ptrStorageBtn->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteStorage)); 
        ptrStorageBtn->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateStorageBtn));
        ptrStorageBtn->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrStorageBtn->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrStorageBtn->registerEvent(DEvent::DnD_Start);
        
        ptrStorageBtn->setMediaByHandle(it->first);
        // test
        std::cout<<"storage loaded:"<<it->first<<std::endl;
        dynamic_cast<duke_media_storage *>(ptrStorageBtn->getMedia())->set_container(m_handle);
        if (it->second.is_type_null()) {
            m_storageWidgets.push_back(ContWidgetPair(ptrStorageBtn, DWidgetPtr()));
            continue;
        }

        DImage ifImg;
        ifImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(ifImg, it->second,
                            ContEditor_StorageIF_Filename);
        DButtonPtr ptrIfButton(new(std::nothrow) DButton("",
                    ifImg,
                    m_ptrStorageFrame.get()));
        ptrIfButton->setFocusAttr(true);
        ptrIfButton->registerEvent(DEvent::Activate);
        ptrIfButton->registerEvent(DEvent::Hover);
        ptrIfButton->registerEvent(DEvent::PassingOut);
        ptrIfButton->registerEvent(DEvent::Delete);
        ptrIfButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteStorage)); 
        ptrIfButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateBtn)); 
        ptrIfButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrIfButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrIfButton->setMediaByHandle(it->second);

        m_storageWidgets.push_back(ContWidgetPair(ptrStorageBtn, ptrIfButton));
    }
}

void DContEditor::initAnchorFrame()
{
    m_ptrAnchorFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrAnchorFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrAnchorFrame.get());
    m_ptrAnchorFrame->setGeometry(ContEditor_AnchorFrame_X_InBodyFrame, 
                                  MAX_COORD - ContEditor_AnchorFrame_H_InBodyFrame, 
                                  ContEditor_AnchorFrame_W_InBodyFrame, 
                                  ContEditor_AnchorFrame_H_InBodyFrame);    
    m_ptrAnchorFrame->setHideProperty(false);
    m_ptrAnchorFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrAnchorFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrAnchorFrame->setAutoFill(false);
    m_ptrAnchorFrame->setFrameStyle(DFrame::Panel);

    // register event
    m_ptrAnchorFrame->registerEvent(DEvent::Activate);
    m_ptrAnchorFrame->setEventRoutine(DEvent::Activate, 
                                       this,
                                       static_cast<EventRoutine>(&DContEditor::onActivateAnchorFrame));
    m_ptrAnchorFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrAnchorFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrAnchorFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrAnchorFrame->registerEvent(DEvent::Select, true);
    m_ptrAnchorFrame->registerEvent(DEvent::Detail, true);
    //m_ptrAnchorFrame->registerEvent(DEvent::Drag);
    m_ptrAnchorFrame->registerEvent(DEvent::DnD_Release);
    m_ptrAnchorFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DContEditor::onDnDReleaseAnchorFrame)); 
            
    // init popup menu
    m_ptrAnchorMenu.reset(new DPopupMenu(m_ptrAnchorFrame.get()));
    assert(NULL != m_ptrAnchorMenu.get());
    m_ptrAnchorMenu->setFocusAttr(true);
    m_ptrAnchorMenu->registerEvent(DEvent::Focus);

    // insert item
    int menuCount = 0;
    m_ptrAnchorMenu->insertItem("New...", menuCount);
    m_ptrAnchorMenu->connectItem(menuCount++, this,
            static_cast<EventRoutine>(&DContEditor::onCreateAnchor));
    m_ptrAnchorMenu->setGeometry(0, 0, 0, 0);
    m_ptrAnchorMenu->setDisplayOrder(0);
    m_ptrAnchorMenu->updateMenu();

    // TODO init existed anchor 
    initAnchorExisted();
}

void DContEditor::initAnchorExisted()
{
    if (!m_ptr || !m_ptr->is_object_container_des()) {
        releaseMedia();
        return;
    }

    duke_media_handle_vector anchors;
    dynamic_cast<duke_media_container *>(m_ptr)->get_anchor(anchors);

    for (duke_media_handle_const_iterator it = anchors.begin(); 
            it != anchors.end(); 
            ++it) {

        // anchor 
        DImage anchorImg;
        anchorImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(anchorImg, *it,
                            ContEditor_Anchor_Filename);
        DButtonPtr ptrAnchorBtn(new(std::nothrow) DButton("",
                    anchorImg,
                    m_ptrAnchorFrame.get()));
        ptrAnchorBtn->setFocusAttr(true);
        ptrAnchorBtn->registerEvent(DEvent::Activate);
        ptrAnchorBtn->registerEvent(DEvent::DnD_Start, true);
        //ptrAnchorBtn->registerEvent(DEvent::Drag, true);
        ptrAnchorBtn->registerEvent(DEvent::Hover);
        ptrAnchorBtn->registerEvent(DEvent::PassingOut);
        ptrAnchorBtn->registerEvent(DEvent::Delete);
        ptrAnchorBtn->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteAnchor)); 
        ptrAnchorBtn->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateAnchorBtn)); 
        ptrAnchorBtn->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrAnchorBtn->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrAnchorBtn->registerEvent(DEvent::DnD_Start);
        ptrAnchorBtn->setEventRoutine(DEvent::DnD_Start,
                this,
                static_cast<EventRoutine>(&DContEditor::onDnDStart)); 

        ptrAnchorBtn->setMediaByHandle((*it));
        dynamic_cast<duke_media_anchor *>(ptrAnchorBtn->getMedia())->set_hcontainer(m_handle);

        m_anchorWidgets.push_back(ptrAnchorBtn);
    }

    // update all layers
    updateAnchorView();
}

void DContEditor::initRootAnchorFrame()
{
    m_ptrRootAnchorFrame.reset(new(std::nothrow) DFrame(static_cast<DWidget *>(getBodyFrame())));
    m_ptrRootAnchorFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    assert(NULL != m_ptrRootAnchorFrame.get());
    m_ptrRootAnchorFrame->setGeometry(ContEditor_RootAnchorFrame_X_InBodyFrame, 
                                  MAX_COORD - ContEditor_RootAnchorFrame_H_InBodyFrame, 
                                  ContEditor_RootAnchorFrame_W_InBodyFrame, 
                                  ContEditor_RootAnchorFrame_H_InBodyFrame);    
    m_ptrRootAnchorFrame->setHideProperty(false);
    m_ptrRootAnchorFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrRootAnchorFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrRootAnchorFrame->setAutoFill(false);
    m_ptrRootAnchorFrame->setFrameStyle(DFrame::Panel);

    // register event
    m_ptrRootAnchorFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrRootAnchorFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrRootAnchorFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrRootAnchorFrame->registerEvent(DEvent::Select, true);
    m_ptrRootAnchorFrame->registerEvent(DEvent::Detail, true);
    //m_ptrRootAnchorFrame->registerEvent(DEvent::Drag);
            

    // init the button of access 
    DImage btnImg;
    btnImg.load(getResPath() + ContEditor_RootAnchorBtn_Filename);
    btnImg.setRelation(DImage::KeepSmall);
    m_ptrRootAnchorBtn.reset(new(std::nothrow) DButton("",
                btnImg,
                m_ptrRootAnchorFrame.get()));
    m_ptrRootAnchorBtn->setFocusAttr(true);
    m_ptrRootAnchorBtn->registerEvent(DEvent::DnD_Start, true);
    //m_ptrRootAnchorBtn->registerEvent(DEvent::Drag, true);
    m_ptrRootAnchorBtn->registerEvent(DEvent::Hover);
    m_ptrRootAnchorBtn->registerEvent(DEvent::PassingOut);
    m_ptrRootAnchorBtn->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
    m_ptrRootAnchorBtn->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
    m_ptrRootAnchorBtn->registerEvent(DEvent::DnD_Start);
    m_ptrRootAnchorBtn->setEventRoutine(DEvent::DnD_Start,
            this,
            static_cast<EventRoutine>(&DContEditor::onDnDStartRootAnchorBtn)); 
    m_ptrRootAnchorBtn->registerEvent(DEvent::Hover);
    m_ptrRootAnchorBtn->registerEvent(DEvent::PassingOut);
    m_ptrRootAnchorBtn->setGeometry(2500, 2500, 5000, 5000); 

    initRootAnchorExisted();
}

void DContEditor::initRootAnchorExisted()
{
    if (!m_ptr || !m_ptr->is_object_container_des()) {
        releaseMedia();
        return;
    }

    if (!m_ptrRootAnchorBtn) 
        return;

    duke_media_handle hanchor = duke_media_handle_null;
    dynamic_cast<duke_media_container *>(m_ptr)->get_rootanchor(hanchor);

    if (!hanchor.is_type_null()) {
        m_ptrRootAnchorBtn->setMediaByHandle(hanchor);
    } else {
        m_ptrRootAnchorBtn->setMediaByType(DUKE_MEDIA_TYPE_ANCHOR);
    }

    duke_media_anchor * rootmedia = dynamic_cast<duke_media_anchor *>(m_ptrRootAnchorBtn->getMedia());

    if (rootmedia == NULL)
        return;

    rootmedia->set_hcontainer(m_handle);
    rootmedia->set_name("root anchor");
    rootmedia->set_index(0);
    dynamic_cast<duke_media_container *>(m_ptr)->set_rootanchor(m_ptrRootAnchorBtn->getMediaHandle());
}

void DContEditor::dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame)
{
    assert(NULL != m_pMainWin);
    DPoint releasePos = rEvent.getEventPosition();
   
    DWidget *pWidget = pFrame;
    DWidget *pParentWidget = dynamic_cast<DWidget *>(pWidget->parent());

    while ((pParentWidget != NULL) && (pParentWidget != m_pMainWin)) {
        DPoint pPos = pWidget->geometryPos();
        DSize pSize = pWidget->geometrySize();
        releasePos.setX(releasePos.x() * pSize.width() / MAX_COORD + pPos.x());
        releasePos.setY(releasePos.y() * pSize.height() / MAX_COORD + pPos.y());
        pWidget = pParentWidget;
        pParentWidget = dynamic_cast<DWidget *>(pParentWidget->parent());
    }

    DEvent& eventRef = const_cast<DEvent &>(rEvent);
    eventRef.setEventPosition(releasePos);
    m_pMainWin->onDnDRelease(rEvent); 
}

void DContEditor::onDnDStart(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDStart" << std::endl;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // repaint
    updateAll();
    repaint(event.getCon());
}

void DContEditor::onDnDRelease(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDRelease" << std::endl;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    // repaint
    updateAll();
    repaint(event.getCon());
}

void DContEditor::onActivateBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onActivateBtn" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;


    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);

    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();

        if(pEditor->isHide()) 
        {
            pEditor->display(event.getCon());
        } 
        else 
        {
            DArrayInterfaceEditor *pArrayInterfaceEditor = dynamic_cast<DArrayInterfaceEditor *>(pEditor);
            if (NULL != pArrayInterfaceEditor) 
            {
                for (StorageConstrIt it = m_storageWidgets.begin(); 
                        it != m_storageWidgets.end(); 
                        ++it) 
                {
                    if (!it->first || !it->second)
                        continue;

                    if (pSrcWidget == it->second.get()) 
                    {
                        pSrcWidget->setMediaByHandle(pArrayInterfaceEditor->getMediaHandle());

                        //set interface for current storage
                        duke_media_handle_pair_vector value;
                        duke_media_handle_vector vtype;
                        vtype.push_back(pSrcWidget->getMediaHandle());
                        dynamic_cast<duke_media_storage *>(it->first->getMedia())->set_value(vtype, value);
                        dynamic_cast<duke_media_container *>(m_ptr)->add_storage(it->first->getMediaHandle(), 
                                pSrcWidget->getMediaHandle());

                        // update storage editor
                        DEditor * pEditor = findSubEditorByWidget(it->first.get());
                        if (pEditor) {
                            pEditor->setMediaByHandle(it->first->getMediaHandle());
                        }

                        break;
                    }
                }
            }

            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        return;
    }

    //duke_media_interface* pMediaInterface = dynamic_cast<duke_media_interface *>(pSrcWidget->getMedia());
    //duke_media_compound_interface pMediaInterface(pSrcWidget->getMediaHandle());

    if (pSrcWidget->getMediaHandle().is_interface_array())
    {
        pEditor = createArrayInterfaceEditor(pSrcWidget);
    }
    else
    {
        pEditor = createSubEditor(pSrcWidget);
    }

    if(pEditor)
    {        
        pEditor->updateAll();
        pEditor->show(event.getCon());
    }    
}

void DContEditor::onHoverBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onHoverBtn" << std::endl;

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    std::string strTip;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    if (pEditor && pEditor->isModified() && pEditor->getMedia()) {
        pEditor->getMedia()->get_name(strTip);

        getApplication()->tip()->add(pSrcWidget, 
                strTip,
                event.getCon());
    } else if ( pSrcWidget->getMedia()) {
        pSrcWidget->getMedia()->get_name(strTip);

        getApplication()->tip()->add(pSrcWidget, 
                strTip,
                event.getCon());
    } else
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
}

void DContEditor::onPassingOutBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onPassingOut" << std::endl;

    // open editor
    getApplication()->tip()->remove(event.getCon());
}

void DContEditor::setReadonly()
{
    DEditor::setReadonly();

    //m_ptrStorageFrame->unRegisterEvent(DEvent::Drag);
    m_ptrStorageFrame->unRegisterEvent(DEvent::DnD_Release);

    //m_ptrFuncFrame->unRegisterEvent(DEvent::Drag);
    m_ptrFuncFrame->unRegisterEvent(DEvent::DnD_Release);

    //m_ptrAnchorFrame->unRegisterEvent(DEvent::Drag);
    m_ptrAnchorFrame->unRegisterEvent(DEvent::DnD_Release);

    for (StorageConstrIt it = m_storageWidgets.begin(); it != m_storageWidgets.end(); ++it) {
        if (it->first) {
            it->first->unRegisterEvent(DEvent::Activate);
            it->first->unRegisterEvent(DEvent::Delete);
        }

        if (it->second) {
            it->second->unRegisterEvent(DEvent::Activate);
            it->second->unRegisterEvent(DEvent::Delete);
        }
    }

    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        if (it->first) {
            it->first->unRegisterEvent(DEvent::Activate);
            it->first->unRegisterEvent(DEvent::Delete);
        }

        if (it->second) {
            it->second->unRegisterEvent(DEvent::Activate);
            it->second->unRegisterEvent(DEvent::Delete);
        }
    }

    for (AnchorWidgetIt it = m_anchorWidgets.begin(); it != m_anchorWidgets.end(); ++it) {
        if (NULL != it->get()) {
            it->get()->unRegisterEvent(DEvent::Activate);
            it->get()->unRegisterEvent(DEvent::Delete);
        }
    }
}

void DContEditor::dumpContainerInfo()
{
    std::cout<<"==================================="<<std::endl;

    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia) {
        std::cout<<"Error: No duke media."<<std::endl;
        std::cout<<"==================================="<<std::endl;
        return;
    }

    //dump name & icon
    std::string name;
    std::string icon;
    pContMedia->get_name(name);
    pContMedia->get_icon(icon);
    std::cout<<"Container name = "<<name<<std::endl
             <<"Container icon = "/*<<toHexString(icon)*/<<std::endl;

    //dump declaration and implementation
    duke_media_handle_vector hdecl;
    pContMedia->get_declarations(hdecl);
    std::cout<<"\ndeclaration size = "<<hdecl.size()<<std::endl;
    for (size_t i = 0; i < hdecl.size(); ++i) {
        std::string declName;
        if(!duke_media_get_name(hdecl[i], declName))
            continue;

        std::cout<<"\t("<<declName<<") "<<std::endl;

        duke_media_handle himpl = duke_media_handle_null;
        pContMedia->get_implementation(hdecl[i], himpl);
        std::string implName;
        if( (himpl != duke_media_handle_null) 
            && duke_media_get_name(hdecl[i], implName) ) {
            std::cout<<"\t<-->\t("<<implName<<") "<<std::endl;            
        }
    }

    //dump storage and storage interface
    duke_media_handle_pair_vector hstorages;
    pContMedia->get_storages(hstorages);
    std::cout<<"\nstorage size = "<<hstorages.size()<<std::endl;
    for (duke_media_handle_pair_vector_iterator it = hstorages.begin(); 
            it != hstorages.end(); 
            ++it) {
        std::string storageName,ifName;
        if(!duke_media_get_name(it->first, storageName))
            continue;
        if(duke_media_handle_null == it->second 
           || !duke_media_get_name(it->second, storageName))
            continue;

        std::cout<<"\t("<<storageName<<") "<<std::endl;
        std::cout<<"\t("<<ifName<<") "<<std::endl;
    }


    //dump anchor
    duke_media_handle_vector hanchores;
    pContMedia->get_anchor(hanchores);
    std::cout<<"\nanchor size = "<<hanchores.size()<<std::endl;
    for (size_t i = 0; i < hanchores.size(); ++i) {
        std::string anchorName;
        if(!duke_media_get_name(hanchores[i], anchorName))
            continue;

        std::cout<<"\t("<<anchorName<<") "<<std::endl;

        duke_media_anchor anchorMedia(hanchores[i]);
        duke_media_handle_vector hdecls;
        duke_media_handle_vector hexcdecls;
        anchorMedia.get_declaration(hdecls, Normal);
        anchorMedia.get_declaration(hexcdecls, Excl);
        for (size_t j = 0; j < hdecls.size();++j) {
            std::string declName;
            if( (hdecls[i] != duke_media_handle_null) 
                    && duke_media_get_name(hdecls[i], declName) ) {
                std::cout<<"\t<-->\t("<<declName<<") "<<std::endl;            
            }
        }
        for (size_t j = 0; j < hexcdecls.size();++j) {
            std::string declName;
            if( (hexcdecls[i] != duke_media_handle_null) 
                    && duke_media_get_name(hexcdecls[i], declName) ) {
                std::cout<<"\t<-->\t("<<declName<<") "<<std::endl;            
            }
        }
    }
}

//***********************function************************//
void DContEditor::updateFuncView()
{
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it)
    {
        DWidget * pDecl = it->first.get();
        assert(pDecl != NULL);
        pDecl->setGeometry(0, 0, 0, 0);

        if (it->second)
        {            
            it->second->setGeometry(0, 0, 0, 0);
        }
    }

    for(int i = (ContEditor_Total_Layer * m_curFuncPage), count = 0;
        (i < static_cast<int>(m_funcWidgets.size())) && (count < ContEditor_Total_Layer); ++i)
    {

        DWidget * pDecl =  m_funcWidgets[i].first.get();
        assert(pDecl != NULL);
        pDecl->setGeometry(1500, count*ContEditor_Layer + 100, 5000 - 3000, ContEditor_Layer - 200);

        if (m_funcWidgets[i].second)
            m_funcWidgets[i].second->setGeometry(6500, count*ContEditor_Layer + 100,
                                                 5000 - 3000, ContEditor_Layer - 200);
        count++;
    }

    std::size_t totalPage =  m_funcWidgets.size() ? (m_funcWidgets.size() - 1) / ContEditor_Total_Layer : 0;
    m_ptrFuncRArrow->setHideProperty(true);
    m_ptrFuncLArrow->setHideProperty(true);
    if(m_curFuncPage < totalPage )
    {
        m_ptrFuncRArrow->setHideProperty(false);        
    }

    if((m_curFuncPage != 0) && (totalPage != 0))
    {
        m_ptrFuncLArrow->setHideProperty(false);        
    }
}

DButton * DContEditor::createWidgetForFunc(const DPoint &pt, DWidget *pSrc)
{
    assert(pSrc || duke_media_handle_null != pSrc->getMediaHandle());
    
    DButtonPtr ptrItemButton;
    
    if (pSrc->getMedia()->is_implementation()) {
        
        int layer = pt.y() / ContEditor_Layer;

        for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
            if (it->first->geometryY()/m_funcLayerHeight == layer && !it->second) {

                duke_media_handle_vector oifs;
                duke_media_implement* pImplMedia = dynamic_cast<duke_media_implement *>(pSrc->getMedia());
                if(pImplMedia == NULL)
                    return NULL;
                pImplMedia->get_in_interfaces(oifs);
                duke_media_handle hif;
                dynamic_cast<duke_media_container *>(m_ptr)->get_interface(hif);

                // modify by roger
                if (!duke_media_implement_match_declare(pSrc->getMediaHandle(), it->first->getMediaHandle())
                    || (!(oifs.size() > 0)))
                {
                    return NULL;
                }
                duke_media_implement impl(pSrc->getMediaHandle()); 
                if(!(impl.get_share() || (impl.get_master() == this->getMediaHandle())))
                {
                    LOG_DEBUG("this object is not the implement's master!");
                    return NULL; 
                }

                DImage implImg;
                implImg.setRelation(DImage::KeepSmall);
                setImageDataByHandle(implImg, pSrc->getMediaHandle(), ContEditor_Impl_Filename);                
                
                // create new implementation
                ptrItemButton.reset(new(std::nothrow) DButton("",
                            implImg,
                            m_ptrFuncFrame.get()));
                ptrItemButton->setFocusAttr(true);
                ptrItemButton->registerEvent(DEvent::Activate);
                ptrItemButton->registerEvent(DEvent::Hover);
                ptrItemButton->registerEvent(DEvent::PassingOut);
                ptrItemButton->registerEvent(DEvent::Delete);
                ptrItemButton->setEventRoutine(DEvent::Delete,
                        this,
                        static_cast<EventRoutine>(&DContEditor::onDeleteFunc)); 
                ptrItemButton->setEventRoutine(DEvent::Activate,
                        this,
                        static_cast<EventRoutine>(&DContEditor::onActivateImplBtn)); 
                ptrItemButton->setEventRoutine(DEvent::Hover,
                        this,
                        static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
                ptrItemButton->setEventRoutine(DEvent::PassingOut,
                        this,
                        static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
                ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());

                it->second = ptrItemButton;
                dynamic_cast<duke_media_container *>(m_ptr)->add_function(
                        it->first->getMediaHandle(), it->second->getMediaHandle());
                break;
            }
        }
    } else if (pSrc->getMedia()->is_declaration()){
        DImage declImg;
        declImg.setRelation(DImage::KeepSmall);
        setImageDataByHandle(declImg, pSrc->getMediaHandle(), ContEditor_Decl_Filename);

        // create new declaration 
        ptrItemButton.reset(new(std::nothrow) DButton("",
                    declImg,
                    m_ptrFuncFrame.get()));
        ptrItemButton->setFocusAttr(true);
        ptrItemButton->registerEvent(DEvent::Activate);
        ptrItemButton->registerEvent(DEvent::Hover);
        ptrItemButton->registerEvent(DEvent::PassingOut);
        ptrItemButton->registerEvent(DEvent::Delete);
        ptrItemButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DContEditor::onDeleteFunc)); 
        ptrItemButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DContEditor::onActivateBtn)); 
        ptrItemButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
        ptrItemButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
        ptrItemButton->registerEvent(DEvent::DnD_Start);
        ptrItemButton->setEventRoutine(DEvent::DnD_Start,
                this,
                static_cast<EventRoutine>(&DContEditor::onDnDStartDecl)); 
        //ptrItemButton->registerEvent(DEvent::Drag, true);
        ptrItemButton->setMediaByHandle(pSrc->getMediaHandle());

        dynamic_cast<duke_media_container *>(m_ptr)->add_function(
                pSrc->getMediaHandle());
        m_funcWidgets.push_back(ContWidgetPair(ptrItemButton, DWidgetPtr()));
        m_curFuncPage = (m_funcWidgets.size() - 1) / ContEditor_Total_Layer;

        if (NULL != m_ptrRootAnchorBtn->getMedia())
            dynamic_cast<duke_media_anchor *>(m_ptrRootAnchorBtn->getMedia())->add_declaration(pSrc->getMediaHandle(), Normal);
    }

    // update all layers
    updateFuncView();

    return ptrItemButton.get();
}

void DContEditor::onDnDReleaseFuncFrame(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDReleaseFuncFrame" << std::endl;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DFrame * pFuncFrame = dynamic_cast<DFrame*>(pSrcWidget->parent()); 
    if (NULL != pFuncFrame 
        && m_ptrFuncFrame.get() == pFuncFrame)
        return;

    // if a dialog release to frame
    DDialog* pDialog = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL  != pDialog) {
        dialogReleaseToFrame(event, m_ptrFuncFrame.get());
        return;
    }

    // only receive duke declaration and implementation
    if ( !pSrcWidget->getMediaHandle().is_declaration() &&
             !pSrcWidget->getMediaHandle().is_implementation()) 
        return;

    // to check the valid implementation add by roger
    if (pSrcWidget->getMediaHandle().is_implementation())
    {
        duke_media_implement impl(pSrcWidget->getMediaHandle());
        if(!impl.check())
        {
            LOG_DEBUG("the implement is a invalid!");
            return;
        }
    }
   
    if (pSrcWidget->getMediaHandle().is_implementation()) {
        std::vector<duke_media_node> nodes;
        duke_media_implement  impl(pSrcWidget->getMediaHandle());
        impl.get_object_nodes(nodes);
        //dynamic_cast<duke_media_implement *>(pSrcWidget->getMedia())->get_object_nodes(nodes);
        for (size_t i = 0; i < nodes.size(); ++i ) {
            if (nodes[i].m_inputs[0].is_anchor()) {
                duke_media_anchor anMedia = duke_media_anchor(nodes[i].m_inputs[0]);
                duke_media_handle parentConth = duke_media_handle_null;
                anMedia.get_hcontainer(parentConth);
                if (parentConth != m_handle) {
                    std::cout<<"dragging impl failed:current implementation includes a anchor of other container."<<std::endl; 
                    return;
                }
            } else if (nodes[i].m_inputs[0].is_storage()) {
                // return when storage in implementation doesn't belong to current container
                duke_media_storage storageMedia = duke_media_storage(nodes[i].m_inputs[0]);
                duke_media_handle parentConth = duke_media_handle_null;
                storageMedia.get_container(parentConth);
                if (parentConth != m_handle) {
                    std::cout<<"dragging impl failed:current implementation includes an invalid storage."<<std::endl; 
                    return;
                }
            } else if (nodes[i].m_inputs[0].is_object_container_des()) {
                // return when container in implementation isn't current container
                if (nodes[i].m_inputs[0] != m_handle) {
                    std::cout<<"dragging impl failed:current implementation includes an invalid root access."<<std::endl; 
                    return;
                }
            } 
        }    
    } 

    // if the decl has been in, exist
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); 
            it != m_funcWidgets.end(); 
            ++it) {
            
        if (it->first 
                && (pSrcWidget->getMediaHandle() 
                    == it->first->getMediaHandle()))
            return;

        if (it->second 
                && (pSrcWidget->getMediaHandle() 
                    == it->second->getMediaHandle()))
            return;
    }

    //set dirty
    m_isModified = true;

    // only add new layer for new duke declaration 
    DPoint pos = event.getEventPosition();
    if (pos.y()/m_funcLayerHeight >= m_funcLayer && pos.x() < 5000)
        m_funcLayer++;

    // create widget for duke function 
    createWidgetForFunc(event.getEventPosition(), pSrcWidget);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::onDnDStartDecl(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDStartDecl" << std::endl;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    // repaint
    updateAll();
    repaint(event.getCon());

}

void DContEditor::onActivateImplBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onActivateImplBtn" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;


    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);

    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide()) {
            pEditor->display(event.getCon());
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        return;
    }

    // Get the postion in mainwin        
    DMainWin * pMainWin = m_pMainWin;
    DImplEditorPtr ptrEditor(new(std::nothrow) DImplEditor(ImplEditor_ObjName, 
                DEditor::PanelModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_IFEditor_W_InMainWin, 
            Default_IFEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    // Initialize the editor after inserting widget
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
    ptrEditor->initDialog();
    ptrEditor->setReadonly();
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}
void DContEditor::onDeleteFunc(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDeleteFunc" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
        
    // set dirty
    m_isModified = true; 

    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); 
            it != m_funcWidgets.end(); 
            ++it) {
        // delete declaration
        if (it->first.get() == pSrcWidget) {
            // delete duke function 
            if (!dynamic_cast<duke_media_container *>(m_ptr)->del_function(
                        it->first->getMediaHandle()))
                return;

            // reload for anchor editor
            for (AnchorWidgetIt anchorIt = m_anchorWidgets.begin();
                    anchorIt != m_anchorWidgets.end();
                    ++anchorIt) {
                DEditor * pEditor = findSubEditorByWidget(anchorIt->get());
                if (pEditor) {
                    DAnchorEditor * pAnchorEditor = dynamic_cast<DAnchorEditor *>(pEditor); 
                    if (pAnchorEditor && pAnchorEditor->findChildWidgets(it->first.get())) {

                        pEditor->setMediaByHandle(anchorIt->get()->getMediaHandle());
                        pEditor->reload();
                        pEditor->updateAll();
                        pEditor->repaint(event.getCon());
                    }
                }
            }

            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->first.get());
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrFuncFrame->detachChildWidget(it->first.get());

            // delete implementation
            if (it->second) {
                //delete subEditor if there is
                DEditor * pEditor = findSubEditorByWidget(it->second.get());
                if (pEditor) {
                    if(!pEditor->isHide()) {
                        pEditor->hideAllSubEditors(event.getCon());
                        pEditor->hide(event.getCon());
                    }
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }
                m_ptrFuncFrame->detachChildWidget(it->second.get());
            }

            // delete delete in root anchor 
            if (NULL != m_ptrRootAnchorBtn->getMedia())
                dynamic_cast<duke_media_anchor *>(m_ptrRootAnchorBtn->getMedia())->del_declaration(it->first->getMediaHandle(), Normal);

            m_funcWidgets.erase(it);

            break;
        }

        // delete implementation
        if (it->second.get() == pSrcWidget) {
            m_ptrFuncFrame->detachChildWidget(it->second.get());
            dynamic_cast<duke_media_container *>(m_ptr)->del_implementation(
                    it->first->getMediaHandle());
            it->second = DWidgetPtr();
            break;
        }
    }
    
    getApplication()->tip()->remove(event.getCon());
    std::size_t totalPage = m_funcWidgets.size() ? ((m_funcWidgets.size() - 1) / ContEditor_Total_Layer) : 0;
    m_curFuncPage = m_curFuncPage > totalPage ? totalPage : m_curFuncPage;

    // repaint
    updateFuncView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::saveFuncInfo()
{
    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia)
        return;

    pContMedia->clear_function();

    //save decl and impl 
    for (FuncWidgetVectorIt it = m_funcWidgets.begin(); it != m_funcWidgets.end(); ++it) {
        DWidget * pDeclWidget = it->first.get();
        if (pDeclWidget == NULL)
            continue;

        duke_media_handle hdecl = pDeclWidget->getMediaHandle();

        if (hdecl == duke_media_handle_null)
            continue;

        duke_media_handle himpl = duke_media_handle_null;

        DWidget * pImplWidget = it->second.get();
        if (pImplWidget != NULL)
            himpl = pImplWidget->getMediaHandle();

        pContMedia->add_function(hdecl, himpl);
    }    
}

//***********************storage************************//
void DContEditor::updateStorageView()
{
    // update layout for storage and if 
    m_storageLayer = m_storageWidgets.size();
    if (ContEditor_Layer*m_storageLayer > (MAX_COORD - m_storageCreateBtnHeight - 150)) 
        m_storageLayerHeight = (MAX_COORD - m_storageCreateBtnHeight - 150) / m_storageLayer;

    int count = 0;
    for (StorageConstrIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {

        DWidget * pStorage = it->first.get();
        assert(pStorage != NULL);
        pStorage->setGeometry(1500, 
                count*m_storageLayerHeight + m_storageCreateBtnHeight + 220,//100,
                5000 - 3000,
                m_storageLayerHeight - 100);

        if (it->second)
            it->second->setGeometry(6500, 
                    count*m_storageLayerHeight + m_storageCreateBtnHeight + 220,//100,
                    5000 - 3000,
                    m_storageLayerHeight - 100);

        count++;
    }

    // update data diaplay  in storage number editor
    duke_media_handle_pair_vector storageMap;
    dynamic_cast<duke_media_container *>(m_ptr)->get_storages(storageMap);
    m_storageNum = storageMap.size();
    m_ptrStorageNum->setContent(boost::lexical_cast<std::string>(m_storageNum));

    // add by mike for updating storage'index in the delete and add operation
    assert(storageMap.size() == m_storageWidgets.size());
    for (int i = 0; i < m_storageNum; ++i)
        dynamic_cast<duke_media_storage *>(m_storageWidgets[i].first->getMedia())->set_storage_idx(i);
}

DButton * DContEditor::createStorage(const int st_idx)
{
    DImage storageImg;
    storageImg.load(getResPath() + ContEditor_Storage_Filename);
    storageImg.setRelation(DImage::KeepSmall);

    // create new storage 
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                storageImg,
                m_ptrStorageFrame.get()));
    ptrItemButton->setFocusAttr(true);
    ptrItemButton->registerEvent(DEvent::Activate);
    ptrItemButton->registerEvent(DEvent::DnD_Start, true);
    //ptrItemButton->registerEvent(DEvent::Drag, true);
    ptrItemButton->registerEvent(DEvent::Hover);
    ptrItemButton->registerEvent(DEvent::PassingOut);
    ptrItemButton->registerEvent(DEvent::Delete);
    ptrItemButton->registerEvent(DEvent::Activate);
    ptrItemButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DContEditor::onDeleteStorage)); 
    ptrItemButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DContEditor::onActivateStorageBtn));
    ptrItemButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
    ptrItemButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
    ptrItemButton->registerEvent(DEvent::DnD_Start);
    
    ptrItemButton->setMediaByType(DUKE_MEDIA_TYPE_STORAGE);
    dynamic_cast<duke_media_storage *>(ptrItemButton->getMedia())->set_container(m_handle);

    dynamic_cast<duke_media_storage *>(ptrItemButton->getMedia())->set_storage_idx(st_idx);
    dynamic_cast<duke_media_container *>(m_ptr)->add_storage(ptrItemButton->getMediaHandle());
    m_storageWidgets.push_back(ContWidgetPair(ptrItemButton, DWidgetPtr()));
    return ptrItemButton.get();
}

DEditor * DContEditor::createArrayInterfaceEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || duke_media_handle_null != pSrcWidget->getMediaHandle())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;


    // Create new IFEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    // Create new arrayEditor with BodyModel
    DArrayInterfaceEditorPtr ptrEditor(new(std::nothrow) DArrayInterfaceEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDialog();
    ptrEditor->initArrayInterfaceEditor();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_ArrayInterfaceEditor_W_InMainWin, 
            Default_ArrayInterfaceEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    return ptrEditor.get();
}


DButton * DContEditor::createConstraintForStorage(const DPoint &pt, const duke_media_handle& hif)
{

    int layer =  (pt.y() - m_storageCreateBtnHeight)/m_storageLayerHeight;   

    if (layer >= m_storageLayer
            || !m_storageWidgets[layer].first
            || (NULL == m_storageWidgets[layer].first->getMedia())
            || m_storageWidgets[layer].second) 
    {
       LOG_ERROR("Invalid layer to set the constaint!");
       return NULL;
    }

    DImage ifImg;
    ifImg.setRelation(DImage::KeepSmall);
    setImageDataByHandle(ifImg, hif,
            ContEditor_StorageIF_Filename);

    // create  interface widget for storage 
    DButtonPtr ptrIFButton(new(std::nothrow) DButton("",
                ifImg,
                m_ptrStorageFrame.get()));
    ptrIFButton->setFocusAttr(true);
    ptrIFButton->registerEvent(DEvent::Activate);
    ptrIFButton->registerEvent(DEvent::Hover);
    ptrIFButton->registerEvent(DEvent::PassingOut);
    ptrIFButton->registerEvent(DEvent::Delete);
    ptrIFButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DContEditor::onDeleteStorage)); 
    ptrIFButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DContEditor::onActivateBtn)); 
    ptrIFButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
    ptrIFButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DContEditor::onPassingOutBtn));

    ptrIFButton->setMediaByHandle(hif);

    //set interface for current storage


    if (!ptrIFButton->getMedia()->is_interface_compound() && !ptrIFButton->getMedia()->is_interface_bridge()
            && dynamic_cast<duke_media_interface *>(ptrIFButton->getMedia())->is_interface_array()) 
    {
        m_storageWidgets[layer].second = ptrIFButton;

        updateStorageView();
        return ptrIFButton.get();
    }

    duke_media_handle_pair_vector value;
    duke_media_handle_vector vtype;
    vtype.push_back(hif);
    dynamic_cast<duke_media_storage *>(m_storageWidgets[layer].first->getMedia())->set_value(vtype, value);
    dynamic_cast<duke_media_container *>(m_ptr)->add_storage(m_storageWidgets[layer].first->getMediaHandle(), 
            ptrIFButton->getMediaHandle());

    // update storage editor
    DEditor * pEditor = findSubEditorByWidget(m_storageWidgets[layer].first.get());
    if (pEditor) 
    {
        pEditor->setMediaByHandle(m_storageWidgets[layer].first.get()->getMediaHandle());
    }

    m_storageWidgets[layer].second = ptrIFButton;

    // update all layers
    updateStorageView();

    return ptrIFButton.get();
}

void DContEditor::onInterfaceMenuBlur(const DEvent &event)
{
    LOG_DEBUG("DContEditor::onInterfaceMenuBlur");
    assert(m_ptrInterfaceMenu);

    if(m_ptrInterfaceMenu)
    {
        m_ptrStorageFrame->detachChildWidget(m_ptrInterfaceMenu.get());
        m_ptrInterfaceMenu.reset();
    }

    updateAll();
    repaint(event.getCon());
}

void DContEditor::onSelectInterfaceMenu(const DEvent &event)
{
    LOG_DEBUG("DContEditor::onSelectInterfaceMenu");

    const std::vector<DPath>& eventPath = event.getEventPath();

    DMenuItem* pSelectItem = dynamic_cast<DMenuItem* >(findChild(eventPath[0]));
    if (NULL == pSelectItem)
        return;

    if(!m_ptrInterfaceMenu.get())
        return;

    duke_media_handle hif = pSelectItem->getMediaHandle();
    
    DPoint pos = m_ptrInterfaceMenu->geometryPos();
    createConstraintForStorage(pos, hif); 

    // destroy the menu
    m_ptrStorageFrame->detachChildWidget(m_ptrInterfaceMenu.get());
    m_ptrInterfaceMenu.reset();

    updateAll();
    repaint(event.getCon());
    
    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);

}

void DContEditor::onDnDReleaseStorageFrame(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDReleaseStorageFrame" << std::endl;

    DApplication* pApp =  getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    dukeid_t  type = pSrcWidget->getMediaHandle();
    if(type.is_object_array())
    {
        duke_media_array ptrArr(pSrcWidget->getMediaHandle());
        if(!ptrArr.is_expanded())
               return; 
    }

    if(type.is_object_map())
    {
        duke_media_map   ptrMap(pSrcWidget->getMediaHandle());
        if(!ptrMap.is_expanded())
            return;
    }
    if(type.is_object_user())
    {
        if (e_handle_core != get_media_handle_status(type))
        {
            return;
        }
    }
 
    // if a dialog release to frame
    DDialog* pDialog = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL  != pDialog) {
        dialogReleaseToFrame(event, m_ptrStorageFrame.get());
        return;
    }

    if (pSrcWidget->getMediaHandle().is_type_null()) 
        return;

    // check the DnDRelease position    
    int layer = (event.getEventPosition().y() - m_storageCreateBtnHeight)/m_storageLayerHeight;   

    if (layer >= m_storageLayer
            || !m_storageWidgets[layer].first
            || (NULL == m_storageWidgets[layer].first->getMedia())
            || m_storageWidgets[layer].second) 
    {
        LOG_DEBUG("Invalid position for storage constraint");
        return;
    }

    // storage obj interface constraints
    if (!pSrcWidget->getMediaHandle().is_object())                // accepts object
    {
        LOG_ERROR("Unsupported type to be set as storage obj's interface");
        return;
    } 

    if (pSrcWidget->getMediaHandle().is_interface()) 
    {
        createPopupMenuForInterface(pSrcWidget->getMediaHandle(), event);
    } 
    else if (pSrcWidget->getMediaHandle().is_object()) 
    {
        duke_media_handle hif;
        duke_media_get_interface_by_object(pSrcWidget->getMediaHandle(), hif);
        createConstraintForStorage(event.getEventPosition(), hif);
    } 
         
    // set dirty
    m_isModified = true;

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize 
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

DPopupMenu* DContEditor::createPopupMenuForInterface(const duke_media_handle& handle, const DEvent& event)
{
     if(m_ptrInterfaceMenu.get())
    {
        m_ptrStorageFrame->detachChildWidget(m_ptrInterfaceMenu.get());
        m_ptrInterfaceMenu.reset();
    }

    m_ptrInterfaceMenu.reset(new DPopupMenu(m_ptrStorageFrame.get()));
    m_ptrInterfaceMenu->setGeometry(event.getEventPosition().x(), 
                                event.getEventPosition().y(), 
                                2000, 
                                1200);
    m_ptrInterfaceMenu->setFocusAttr(true);
    m_ptrInterfaceMenu->registerEvent(DEvent::Focus);
    m_ptrInterfaceMenu->registerEvent(DEvent::Blur);
    m_ptrInterfaceMenu->setEventRoutine(DEvent::Blur,
                              this,
                              static_cast<EventRoutine>(&DContEditor::onInterfaceMenuBlur));

    duke_media_handle hif;
    // create a menu item for interface itself
    m_ptrInterfaceMenu->insertItem("set interface", 0, handle);
    m_ptrInterfaceMenu->connectItem(0, 
                              this,         
                              static_cast<EventRoutine>(&DContEditor::onSelectInterfaceMenu));

    // create a menu item for interface interface
    duke_media_get_interface_by_object(handle, hif);
    m_ptrInterfaceMenu->insertItem("set its interface", 1, hif);
    m_ptrInterfaceMenu->connectItem(1,
                              this,
                              static_cast<EventRoutine>(&DContEditor::onSelectInterfaceMenu));

    m_ptrInterfaceMenu->updateMenu();   

    return m_ptrInterfaceMenu.get();
}

void DContEditor::onInputStorageNum(const DEvent &event)
{
    std::cout << "--------------DContEditor::onInputStorageNum" << std::endl;

    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DWidget * pWidget = static_cast<DWidget *>(findChild(rWidgetPath[0]));

    m_isModified = true;

    if(pWidget != m_ptrStorageNum.get())
        return;

    m_ptrStorageNum->onInputEvent(event);
    std::string numStr = m_ptrStorageNum->content(); 
    try {
        m_storageNum = boost::lexical_cast<int>(numStr); 
    } catch (boost::bad_lexical_cast &) {
        m_storageNum = 0; 
    }

    if (!m_ptr || !m_ptr->is_object_container_des()) {
        releaseMedia();
        return;
    }
    dynamic_cast<duke_media_container *>(m_ptr)->set_storagenum(m_storageNum);

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::onClickStorageCreateBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onClickStorageCreateBtn" << std::endl;

    int st_size = m_storageNum;
    if (m_storageNum > 30)
        st_size = 30;
    std::size_t total_num = m_storageWidgets.size();
    // create new storages
    for(int i = 0;i < st_size;++i) 
        createStorage(i + total_num); 

    // update all layers
    updateStorageView();

    // repatint
    updateAll();
    repaint(event.getCon());
    
    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}
/*
void DContEditor::onActivateStorageBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onActivateStorageBtn" << std::endl; 
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();

        if(pEditor->isHide()) {
            pEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            pEditor->reload();
            pEditor->updateAll();
            pEditor->repaint(event.getCon());
            pEditor->display(event.getCon());
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }
        
        if(pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }
        return;
    }

    if (!pSrcWidget->getMedia()->is_storage()) 
        return;

    // Create new DeclEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    DStorageEditorPtr ptrEditor(new(std::nothrow) DStorageEditor(StorageEditor_ObjName, 
                DEditor::PanelModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->initDialog();

    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_StorageEditor_W_InMainWin, 
            Default_StorageEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);

    // Initialize the editor after inserting widget
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
    
    duke_media_storage * pStorageMedia = dynamic_cast<duke_media_storage *>(ptrEditor->getMedia());
    pStorageMedia->set_container(m_handle);
    ptrEditor->initStorageEditor();
    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}
*/
void DContEditor::onDeleteStorage(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDeleteStorage" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
    
    //set dirty
    m_isModified = true;
    
    // if storage, delete relevant interface 
    for (StorageConstrIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        if (it->first.get() == pSrcWidget) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->first.get());
            // display editor
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrStorageFrame->detachChildWidget(it->first.get());

            if (it->second) {
                //delete subEditor if there is
                DEditor * pEditor = findSubEditorByWidget(it->second.get());
                // display editor
                if (pEditor) {
                    if(!pEditor->isHide()) {
                        pEditor->hideAllSubEditors(event.getCon());
                        pEditor->hide(event.getCon());
                    }
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }
                m_ptrStorageFrame->detachChildWidget(it->second.get());
            }

            dynamic_cast<duke_media_container *>(m_ptr)->del_storage(
                    it->first->getMediaHandle());
            m_storageWidgets.erase(it);
            break;
        }

        if (it->second.get() == pSrcWidget) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->second.get());
            // display editor
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }
            m_ptrStorageFrame->detachChildWidget(it->second.get());
            dynamic_cast<duke_media_container *>(m_ptr)->del_storageifc(it->first->getMediaHandle());
            it->second = DWidgetPtr();
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    // repaint
    updateStorageView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::saveStorageInfo()
{
    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia)
        return;

    pContMedia->clear_storage();

    // save storage and IF
    for (StorageConstrIt it = m_storageWidgets.begin(); 
            it != m_storageWidgets.end(); 
            ++it) {
        if(!it->first || !it->second)
            continue;

        pContMedia->add_storage(it->first->getMediaHandle(), 
                it->second->getMediaHandle());        
    }
}

void DContEditor::updateStorageInfo()
{
    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia)
        return;

    // update storage and IF
    for (StorageConstrIt stit = m_storageWidgets.begin(); stit != m_storageWidgets.end(); ++stit) {
        if(!stit->first)
            continue;

        duke_media_handle oldh = stit->first->getMediaHandle();
        stit->first->setMediaByType(DUKE_MEDIA_TYPE_STORAGE);

        for (FuncWidgetVectorIt funcit = m_funcWidgets.begin(); 
                funcit != m_funcWidgets.end(); 
                ++funcit) {
            if (!funcit->first
                    || !funcit->first->getMedia()
                    || !funcit->second 
                    || !funcit->second->getMedia())
                continue;

            std::vector<duke_media_node> nodes;
            dynamic_cast<duke_media_implement *>(funcit->second->getMedia())->get_object_nodes(nodes);
            for (size_t i = 0; i < nodes.size(); ++i) {
                if (!nodes[i].m_inputs[0].is_storage()) 
                    continue;
                if (oldh != nodes[i].m_inputs[0]) 
                    continue;

                // del decl and impl 
                dynamic_cast<duke_media_container *>(m_ptr)->del_function(
                        funcit->first->getMediaHandle());
                dynamic_cast<duke_media_container *>(m_ptr)->del_implementation(
                        funcit->first->getMediaHandle());

                // reload for anchor editors
                for (AnchorWidgetIt anchorIt = m_anchorWidgets.begin();
                        anchorIt != m_anchorWidgets.end();
                        ++anchorIt) {
                    DEditor * pEditor = findSubEditorByWidget(anchorIt->get());
                    if (!pEditor) 
                        continue; 

                    DAnchorEditor * pAnchorEditor = dynamic_cast<DAnchorEditor *>(pEditor); 
                    if (pAnchorEditor && pAnchorEditor->findChildWidgets(funcit->first.get())) {
                        pEditor->setMediaByHandle(anchorIt->get()->getMediaHandle());
                        pEditor->reload();
                        pEditor->updateAll();
                    }
                }
                //delete decl button its subEditor  
                DEditor * pEditor = findSubEditorByWidget(funcit->first.get());
                if (pEditor) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                    eraseSubEditor(pEditor);        
                }
                m_ptrFuncFrame->detachChildWidget(funcit->first.get());
                funcit->first = DWidgetPtr();

                // delete implementation button and its subEditor 
                DEditor * pImplEditor = findSubEditorByWidget(funcit->second.get());
                if (pImplEditor) {
                    m_pMainWin->getRootWidget()->detachChildWidget(pImplEditor);
                    eraseSubEditor(pImplEditor);        
                }
                m_ptrFuncFrame->detachChildWidget(funcit->second.get());
                funcit->second = DWidgetPtr();
            }
        }

        duke_media_handle hcif = duke_media_handle_null;
        if (stit->second) 
            hcif = stit->second->getMediaHandle();
    }
}

//***********************anchor************************//
void DContEditor::updateAnchorView()
{
    // update the layer of anchor
    m_anchorRow = (m_anchorWidgets.size() % ContEditor_Col_Items) ?
            (m_anchorWidgets.size() / ContEditor_Col_Items + 1) :
            (m_anchorWidgets.size() / ContEditor_Col_Items); 
    if (ContEditor_Row_Height*m_anchorRow > MAX_COORD)
        m_anchorLayerHeight = MAX_COORD / m_anchorRow;
    int colWidth = MAX_COORD / ContEditor_Col_Items;

    int rcnt = 0;
    int ccnt = 0;
    for (AnchorWidgetIt it = m_anchorWidgets.begin();
            it != m_anchorWidgets.end();
            ++it) {
        DWidget * pAnchor = (*it).get();;
        assert(pAnchor != NULL);
        pAnchor->setGeometry(ccnt*colWidth + 100,
                rcnt*m_anchorLayerHeight + 200,
                colWidth - 200,
                m_anchorLayerHeight - 200);

        ccnt++;
        if (ccnt == ContEditor_Col_Items) {
            rcnt++;
            ccnt = 0;
        }
    }
}

void DContEditor::onDnDReleaseAnchorFrame(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDReleaseAnchorFrame" << std::endl;
}

void DContEditor::onActivateAnchorFrame(const DEvent &event)
{
    std::cout << "--------------DContEditor::onActivateAnchorFrame" << std::endl;

    
    // set dirty
    m_isModified = true;

    if (!m_ptrAnchorFrame || !m_ptrAnchorMenu)
        return;

    DSize menuSize = m_ptrAnchorMenu->geometrySize();
    if (menuSize.height() > 0 && menuSize.width() > 0)
        m_ptrAnchorMenu->setGeometry(0, 0, 0, 0);
    else
        m_ptrAnchorMenu->setGeometry(event.getEventPosition().x(), 
                event.getEventPosition().y(), 
                2000, 
                Anchor_Menu_Height);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::onCreateAnchor(const DEvent &event)
{
    std::cout << "--------------DContEditor::onCreateAnchor" << std::endl;

    m_isModified = true;

    DImage anchorImg;
    anchorImg.load(getResPath() + ContEditor_Anchor_Filename);
    anchorImg.setRelation(DImage::KeepSmall);

    // create new anchor 
    DButtonPtr ptrAnchorBtn(new(std::nothrow) DButton("",
                anchorImg,
                m_ptrAnchorFrame.get()));
    ptrAnchorBtn->setFocusAttr(true);
    ptrAnchorBtn->registerEvent(DEvent::Activate);
    ptrAnchorBtn->registerEvent(DEvent::DnD_Start, true);
    //ptrAnchorBtn->registerEvent(DEvent::Drag, true);
    ptrAnchorBtn->registerEvent(DEvent::Hover);
    ptrAnchorBtn->registerEvent(DEvent::PassingOut);
    ptrAnchorBtn->registerEvent(DEvent::Delete);
    ptrAnchorBtn->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DContEditor::onDeleteAnchor)); 
    ptrAnchorBtn->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DContEditor::onActivateAnchorBtn)); 
    ptrAnchorBtn->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DContEditor::onHoverBtn)); 
    ptrAnchorBtn->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DContEditor::onPassingOutBtn)); 
    ptrAnchorBtn->registerEvent(DEvent::DnD_Start);
    ptrAnchorBtn->setEventRoutine(DEvent::DnD_Start,
            this,
            static_cast<EventRoutine>(&DContEditor::onDnDStart)); 
    ptrAnchorBtn->setMediaByType(DUKE_MEDIA_TYPE_ANCHOR);

    dynamic_cast<duke_media_anchor *>(ptrAnchorBtn->getMedia())->set_hcontainer(m_handle);
    dynamic_cast<duke_media_container *>(m_ptr)->add_anchor(
            ptrAnchorBtn->getMediaHandle());
    m_anchorWidgets.push_back(ptrAnchorBtn);

    // update anchor view
    updateAnchorView();

    if (!m_ptrAnchorMenu) 
        return; 

    // minimize the menu
    m_ptrAnchorMenu->setGeometry(0, 0, 0, 0);

    // repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::onActivateAnchorBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onActivateAnchorBtn" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    if (!pSrcWidget->getMedia()->is_anchor()) 
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide()) {
            pEditor->display(event.getCon());
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(pEditor->isModified()) {
            pSrcWidget->setMediaByHandle(pEditor->getMediaHandle());
            saveAnchorInfo();
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        return;
    }

    // Create new Anchor Editor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    DAnchorEditorPtr ptrEditor(new(std::nothrow) DAnchorEditor(AnchorEditor_ObjName, 
                DEditor::PanelModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->initDialog();

    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_AnchorEditor_W_InMainWin, 
            Default_AnchorEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);

    // Initialize the editor after inserting widget
    if (e_handle_core != get_media_handle_status(pSrcWidget->getMediaHandle()))
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
    else
        ptrEditor->duplicateItemsByHandle(pSrcWidget->getMediaHandle());
    // Set parent container of anchor
    duke_media_anchor * pAnchorMedia = dynamic_cast<duke_media_anchor *>(ptrEditor->getMedia());
    pAnchorMedia->set_hcontainer(m_handle);
    ptrEditor->initAnchorEditor();
    ptrEditor->setReadonly();
    ptrEditor->setSourceWidget(m_ptrFuncFrame.get());

    ptrEditor->updateAll();
    ptrEditor->show(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::onDeleteAnchor(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDeleteAnchor" << std::endl;

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
 
    // set dirty
    m_isModified = true;

    // if anchor, delete all declarations in it 
    for (AnchorWidgetIt it = m_anchorWidgets.begin(); 
            it != m_anchorWidgets.end(); 
            ++it) {
        if (it->get() == pSrcWidget) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->get());
            // display editor
            if (pEditor) {
                if(!pEditor->isHide()) {
                    pEditor->hideAllSubEditors(event.getCon());
                    pEditor->hide(event.getCon());
                }
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            if (dynamic_cast<duke_media_container *>(m_ptr)->del_anchor(it->get()->getMediaHandle())) {
                m_ptrAnchorFrame->detachChildWidget(it->get());
                m_anchorWidgets.erase(it);
            }

            break;
        }
    }
    
    getApplication()->tip()->remove(event.getCon());

    // repaint
    updateAnchorView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DContEditor::saveAnchorInfo()
{
    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia)
        return;

    pContMedia->clear_anchor();

    //save decl and impl 
    for (AnchorWidgetIt it = m_anchorWidgets.begin(); it != m_anchorWidgets.end(); ++it) {
        DWidget * pAnchorWidget = it->get();
        if (pAnchorWidget == NULL)
            continue;

        duke_media_handle hAnchor = pAnchorWidget->getMediaHandle();

        if (hAnchor == duke_media_handle_null)
            continue;

        pContMedia->add_anchor(hAnchor);
    }    
}

void DContEditor::onDnDStartRootAnchorBtn(const DEvent &event)
{
    std::cout << "--------------DContEditor::onDnDStartRootAnchorBtn" << std::endl;
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL 
            || !pSrcWidget->getMedia()
            || !pSrcWidget->getMedia()->is_anchor())
        return;

    // generate
    // repatint
    updateAll();
    repaint(event.getCon());
}

void DContEditor::onGenerate(const DEvent &event)
{
    std::cout << "--------------DContEditor::onGenerate" << std::endl;

    generate();
    destorySubEditors(event.getCon());
    clearSubEditors();

    //dump infromatino
    dumpObjectInfo();
}

bool DContEditor::isValidContainer(duke_media_container* pContMedia)
{
    if (pContMedia == NULL)
        return false;

    std::cout<<"Check Container Completeness: ";

    // check if the name is empty
    std::string name;
    pContMedia->get_name(name);
    if (name.empty()) {
        std::cout<<"Error, missing name"<<std::endl;
        return false;
    }

    // check container declaration and implementation
    duke_media_handle_vector hdecls;
    pContMedia->get_declarations(hdecls);
    for (size_t i = 0; i < hdecls.size(); ++i)  {
        if (hdecls[i] == duke_media_handle_null) {
            std::cout<<"Error, the declaration is null"<<std::endl;
            return false;
        }

        duke_media_handle himpl = duke_media_handle_null;
        pContMedia->get_implementation(hdecls[i], himpl);
        if (himpl == duke_media_handle_null) {
            std::cout<<"Error, missing the implementation"<<std::endl;
            return false;
        }
    }

    // check storage 
    duke_media_handle_pair_vector hstorages;
    pContMedia->get_storages(hstorages);
    for (duke_media_handle_pair_vector_iterator it = hstorages.begin(); 
            it != hstorages.end(); 
            ++it) {
        if (it->first == duke_media_handle_null) {
            std::cout<<"Error, the storage is null"<<std::endl;
            return false;
        }
        if (it->second.is_type_null()) {
            std::cout<<"Error, the storage interface is null"<<std::endl;
            return false;
        }
    }

    // check container anchor 
    duke_media_handle_vector hanchores;
    pContMedia->get_anchor(hanchores);
    for (size_t i = 0; i < hanchores.size(); ++i)  {
        if (hanchores[i] == duke_media_handle_null) {
            std::cout<<"Error, the anchor is null"<<std::endl;
            return false;
        }

        duke_media_anchor anchorMedia(hanchores[i]);
        duke_media_handle_vector hdecls;
        duke_media_handle_vector hexcdecls;
        anchorMedia.get_declaration(hdecls, Normal);
        anchorMedia.get_declaration(hexcdecls, Excl);

        if (0 >= hdecls.size() && 0 >= hexcdecls.size()) {
            std::cout<<"Error, no declaration in anchor"<<std::endl;
            return false;
        }

        for (size_t i = 0; i < hdecls.size(); ++i)  {
            if (hdecls[i] == duke_media_handle_null) {
                std::cout<<"Error, the share declaration is null"<<std::endl;
                return false;
            }
        }

        for (size_t i = 0; i < hexcdecls.size(); ++i)  {
            if (hexcdecls[i] == duke_media_handle_null) {
                std::cout<<"Error, the exclusive declaration is null"<<std::endl;
                return false;
            }
        }
    }

    return true;
}

void DContEditor::updateParentContForItems(duke_media_handle hparentcont) 
{
    std::cout << "--------------DContEditor::updateParentContForItems" << std::endl;

    if (hparentcont == duke_media_handle_null)
        return;

    duke_media_container contMedia(hparentcont);

    duke_media_handle_pair_vector hstorages;
    contMedia.get_storages(hstorages);
    for (duke_media_handle_pair_vector_iterator it = hstorages.begin(); it != hstorages.end(); ++it) {
        if (it->first == duke_media_handle_null) {
            std::cout<<"Error, the storage is null"<<std::endl;
            return;
        }

        duke_media_storage storageMedia = duke_media_storage(it->first);
        storageMedia.set_container(hparentcont);
    }

    duke_media_handle_vector hanchors;
    contMedia.get_anchor(hanchors);
    for (size_t i = 0; i < hanchors.size(); ++i)  {
        if (hanchors[i] == duke_media_handle_null) {
            std::cout<<"Error, the anchor is null"<<std::endl;
            return;
        }

        duke_media_anchor anchorMedia = duke_media_anchor(hanchors[i]);
        anchorMedia.set_hcontainer(hparentcont);
    }
}

duke_media_handle DContEditor::generate()
{
    LOG_DEBUG("--------------DContEditor::generate");

    //if current container already have been generated, just return.
    if (e_handle_core == get_media_handle_status(m_handle))
    {
        LOG_INFO("This container already have been generated");
        return m_handle;        
    }

    //DEditor::generate();

    duke_media_container* pContMedia = dynamic_cast<duke_media_container *>(m_ptr);
    if (NULL == pContMedia)
        return duke_media_handle_null;

    LOG_INFO("==========Generate the "<<m_dukeName<<" container==========");
    duke_media_handle newh = duke_media_handle_null;
    if (isValidContainer(pContMedia))
    {
        nb_id_t new_id;
        std::map<int, nb_id_t> idx_id_map;
        if (pContMedia->compile(getApplication()->username(), new_id, idx_id_map))
        {
            LOG_INFO("Generate the container and subItems successful.");

            //generateAccesses(getApplication()->username(), newh);
            //generateRootAccess(newh);

            // save the generated id to warehouse
            newh = new_id;
            save_generated_handle(newh, getApplication()->username());

            // save generated compound declarations
            int decl_num = 0;
            for (std::map<int, nb_id_t>::const_iterator it = idx_id_map.begin();
                    it != idx_id_map.end(); ++it)
            {
                duke_media_handle hdecl;
                // specify the actual type
                if (it->second.get_type() == NBID_TYPE_OBJECT_DECLARATION_COMPOUND)
                {
                    hdecl = it->second;
                    if (save_generated_handle(hdecl, getApplication()->username()))
                        decl_num++;
                }
            }
            LOG_INFO("Generate " << decl_num << " sub declarations.");

            return newh;            
        }
        
    }
    
    LOG_NOTICE("It is not a valid container. Failed to generate container!");
    return duke_media_handle_null;
}

void DContEditor::onFuncArrow(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);

    if(pButton == m_ptrFuncLArrow.get())
    {
        m_curFuncPage = m_curFuncPage <= 0 ? 0 :  m_curFuncPage - 1;
    }
    else if(pButton == m_ptrFuncRArrow.get())
    {
        m_curFuncPage = (m_curFuncPage + 1) * ContEditor_Total_Layer >= m_funcWidgets.size() ? m_curFuncPage
            :  m_curFuncPage + 1;
    }
    else
    {
        return;
    }

    updateFuncView();
    updateAll();
    repaint(event.getCon());
}

void DContEditor::onPassingInFuncArrow(const DEvent &event)
{
}

void DContEditor::onPassingOutFuncArrow(const DEvent &event)
{
}
 
void DContEditor::onActivateStorageBtn(const DEvent &event)
{
    LOG_DEBUG("------DContEditor::onActivateStorage------");
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
       return; 
     
    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor)
    {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        pEditor->isHide() ? pEditor->display(event.getCon()) 
            : pEditor->hide(event.getCon());
        DInputEditor *pInput = dynamic_cast<DInputEditor *>(pEditor);

        if (pInput && pEditor->isHide())
            pSrcWidget->getMedia()->set_name(pInput->getInputString());
    }
    else
    {
        DMainWin * pMainWin = m_pMainWin;
        // Get the postion in mainwin 
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        

        // Create new InputEditor
        DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                    pMainWin,
                    pMainWin->getRootWidget()));
        insertSubEditor(pSrcWidget, ptrEditor);
        ptrEditor->initDialog();

        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_InputEditor_W_InMainWin, 
                Default_InputEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);

        // Set initial value
        std::string name;
        pSrcWidget->getMedia()->get_name(name);
            ptrEditor->setInputString(name);
        ptrEditor->updateAll();
        ptrEditor->show(event.getCon());
    }
}

//*****************************************************//
DContEditorCell::DContEditorCell()
{
}

DContEditorCell::~DContEditorCell()
{
}

void DContEditorCell::init()
{
}

void DContEditorCell::update()
{
    // call parent class at first
    DDialogCell::update();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
