/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei 
**
****************************************************************************/

#include "is_dport.h"

DPort::DPort(DWidget *parent, WFlags f)
    : DWidget(*new DPortCell, parent, f),
      m_direction(Left),
      m_autoFill(true)
{
    setObjectName(DPort_ObjName);    
    d_func()->init();
    setEventRoutine(DEvent::Hover, this, (EventRoutine)(&DPort::onHoverEvent));
    setEventRoutine(DEvent::PassingOut, this, (EventRoutine)(&DPort::onPassingOutEvent));
}

DPort::~DPort()
{
}

bool DPort::event(DEvent *e)
{
   // std::cout << "event : " << e->type() << std::endl; 
    return true;
}

void DPort::onHoverEvent(const DEvent& rEvent)
{
    printf("Hover event processing ---------\n");
    d_func()->hover(rEvent.getCon());
}

void DPort::onPassingOutEvent(const DEvent& rEvent)
{
    printf("PassingOut event processing ---------\n");
    repaint(rEvent.getCon());
}

/***************************************************************************
 * DPortCell member functions
 **************************************************************************/
DPortCell::DPortCell()
{
}

DPortCell::~DPortCell()
{
}

void DPortCell::init()
{
    DPort *q = q_func();
    TPlacement tp;
    TGeneralCurve curve;

    TPath p(m_place->path);
    p.node.push_back(0);
    tp.path = p;
    curve.fill = q->autoFill();
    curve.closed = true;
    tp.position.x = tp.position.y = MIN_COORD;
    tp.size.width = tp.size.height = MAX_COORD;

    setCurvePath(&curve);
    DColor2TColor(q->backgroundColor(), curve.color);
    DColor2TColor(q->backgroundColor(), curve.fillColor);
    tp.data = &curve;

    subNodes.push_back(tp);
    (q->cnum())++;
    tp.data = NULL;
}

void DPortCell::update()
{
    DWidgetCell::update();

    DPort *q = q_func();
    
    m_place->path.node = q->objectPath();

    TPlacement &tp = subNodes[0];
    tp.path.node = m_place->path.node;
    tp.path.node.push_back(0); 
    tp.order = q->displayOrder();

    TGeneralCurve *pCurve = reinterpret_cast<TGeneralCurve *>(tp.data);
    pCurve->fill = q->autoFill();
    DColor2TColor(q->backgroundColor(), pCurve->color);
    DColor2TColor(q->backgroundColor(), pCurve->fillColor);

    pCurve->points.clear();
    setCurvePath(pCurve);
}

void DPortCell::setCurvePath(TGeneralCurve *pCurve)
{
    TPoint pLeftTop(MIN_COORD, MIN_COORD);
    TPoint pRightTop(MAX_COORD, MIN_COORD);
    TPoint pRightBottom(MAX_COORD, MAX_COORD);
    TPoint pLeftBottom(MIN_COORD, MAX_COORD);
    switch (q_func()->m_direction) {
    case DPort::Left:
        pCurve->points.push_back(pRightTop);
        pCurve->points.push_back(pLeftTop);
        pCurve->points.push_back(pLeftBottom);
        pCurve->points.push_back(pRightBottom);
        pCurve->curveType = Curve_CUBIC; 
        break;
    case DPort::Right:
        pCurve->points.push_back(pLeftTop);
        pCurve->points.push_back(pRightTop);
        pCurve->points.push_back(pRightBottom);
        pCurve->points.push_back(pLeftBottom);
        pCurve->curveType = Curve_CUBIC; 
        break;
    case DPort::Up:
        pCurve->points.push_back(pLeftBottom);
        pCurve->points.push_back(pLeftTop);
        pCurve->points.push_back(pRightTop);
        pCurve->points.push_back(pRightBottom);
        pCurve->curveType = Curve_CUBIC; 
        break;
    case DPort::Down:
        pCurve->points.push_back(pLeftTop);
        pCurve->points.push_back(pLeftBottom);
        pCurve->points.push_back(pRightBottom);
        pCurve->points.push_back(pRightTop);
        pCurve->curveType = Curve_CUBIC; 
        break;
    case DPort::None:
        pCurve->points.push_back(pLeftBottom);
        pCurve->points.push_back(pLeftTop);
        pCurve->points.push_back(pRightTop);
        pCurve->points.push_back(pRightBottom);
        //pCurve->curveType = Curve_ELLIPSE; 
        break;
    }
}

void DPortCell::hover(const is_response_call& response_call)
{
    DPort *q = q_func();

    TGeneralCurve *pCurve = reinterpret_cast<TGeneralCurve *>(subNodes[0].data);
    DColor2TColor(q->highlightColor(), pCurve->fillColor);    
    DColor2TColor(q->highlightColor(), pCurve->color);    

    Packer p;
    TUpdateNode node(*m_place);
    p.pack(node);
    // send data to client for show
    byte_stream buf;
    buf.data.assign(p.data().data(), p.data().data() + p.data().size());    
    response_call(buf);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
