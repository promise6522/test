/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Duke header files
#include "is_drect.h"

/*
 * Returns a normalized rectangle; i.e., a rectangle that has a
 * non-negative width and height.
 *
 * If width() < 0 the function swaps the left and right corners, and
 * it swaps the top and bottom corners if height() < 0.
 */
DRect DRect::normalized() const
{
    DRect r;
    if (x2 < x1 - 1) {            // swap bad x values
        r.x1 = x2;
        r.x2 = x1;
    } else {
        r.x1 = x1;
        r.x2 = x2;
    }
    if (y2 < y1 - 1) {            // swap bad y values
        r.y1 = y2;
        r.y2 = y1;
    } else {
        r.y1 = y1;
        r.y2 = y2;
    }
    return r;
}

/*
 * Moves the rectangle, leaving the center point at the given
 * position. The rectangle's size is unchanged.
 */
void DRect::moveCenter(const DPoint &p)
{
    int w = x2 - x1;
    int h = y2 - y1;
    x1 = p.x() - w/2;
    y1 = p.y() - h/2;
    x2 = x1 + w;
    y2 = y1 + h;
}

/*
 * Returns true if the given point is inside or on the edge of
 * the rectangle, otherwise returns false. If proper is true, this
 * function only returns true if the given point is inside the
 * rectangle (i.e., not on the edge).
 */
bool DRect::contains(const DPoint &p, bool proper) const
{
    int l, r;
    if (x2 < x1 - 1) {
        l = x2;
        r = x1;
    } else {
        l = x1;
        r = x2;
    }
    if (proper) {
        if (p.x() <= l || p.x() >= r)
            return false;
    } else {
        if (p.x() < l || p.x() > r)
            return false;
    }
    int t, b;
    if (y2 < y1 - 1) {
        t = y2;
        b = y1;
    } else {
        t = y1;
        b = y2;
    }
    if (proper) {
        if (p.y() <= t || p.y() >= b)
            return false;
    } else {
        if (p.y() < t || p.y() > b)
            return false;
    }
    return true;
}

/*
 * Returns true if the given rectangle is inside this rectangle.
 * otherwise returns false. If proper is true, this function only
 * returns true if the rectangle is entirely inside this
 * rectangle (not on the edge).
 */
bool DRect::contains(const DRect &r, bool proper) const
{
    if (isNull() || r.isNull())
        return false;

    int l1 = x1;
    int r1 = x1;
    if (x2 - x1 + 1 < 0)
        l1 = x2;
    else
        r1 = x2;

    int l2 = r.x1;
    int r2 = r.x1;
    if (r.x2 - r.x1 + 1 < 0)
        l2 = r.x2;
    else
        r2 = r.x2;

    if (proper) {
        if (l2 <= l1 || r2 >= r1)
            return false;
    } else {
        if (l2 < l1 || r2 > r1)
            return false;
    }

    int t1 = y1;
    int b1 = y1;
    if (y2 - y1 + 1 < 0)
        t1 = y2;
    else
        b1 = y2;

    int t2 = r.y1;
    int b2 = r.y1;
    if (r.y2 - r.y1 + 1 < 0)
        t2 = r.y2;
    else
        b2 = r.y2;

    if (proper) {
        if (t2 <= t1 || b2 >= b1)
            return false;
    } else {
        if (t2 < t1 || b2 > b1)
            return false;
    }

    return true;
}

/*
 * Returns the bounding rectangle of this rectangle and the given
 * rectangle.
 */
DRect DRect::operator|(const DRect &r) const
{
    if (isNull())
        return r;
    if (r.isNull())
        return *this;

    int l1 = x1;
    int r1 = x1;
    if (x2 - x1 + 1 < 0)
        l1 = x2;
    else
        r1 = x2;

    int l2 = r.x1;
    int r2 = r.x1;
    if (r.x2 - r.x1 + 1 < 0)
        l2 = r.x2;
    else
        r2 = r.x2;

    int t1 = y1;
    int b1 = y1;
    if (y2 - y1 + 1 < 0)
        t1 = y2;
    else
        b1 = y2;

    int t2 = r.y1;
    int b2 = r.y1;
    if (r.y2 - r.y1 + 1 < 0)
        t2 = r.y2;
    else
        b2 = r.y2;

    DRect tmp;
    tmp.x1 = dMin(l1, l2);
    tmp.x2 = dMax(r1, r2);
    tmp.y1 = dMin(t1, t2);
    tmp.y2 = dMax(b1, b2);
    return tmp;
}

/*
 * Returns the intersection of this rectangle and the given
 * rectangle. Returns an empty rectangle if there is no intersection.
 */
DRect DRect::operator&(const DRect &r) const
{
    if (isNull() || r.isNull())
        return DRect();

    int l1 = x1;
    int r1 = x1;
    if (x2 - x1 + 1 < 0)
        l1 = x2;
    else
        r1 = x2;

    int l2 = r.x1;
    int r2 = r.x1;
    if (r.x2 - r.x1 + 1 < 0)
        l2 = r.x2;
    else
        r2 = r.x2;

    if (l1 > r2 || l2 > r1)
        return DRect();

    int t1 = y1;
    int b1 = y1;
    if (y2 - y1 + 1 < 0)
        t1 = y2;
    else
        b1 = y2;

    int t2 = r.y1;
    int b2 = r.y1;
    if (r.y2 - r.y1 + 1 < 0)
        t2 = r.y2;
    else
        b2 = r.y2;

    if (t1 > b2 || t2 > b1)
        return DRect();

    DRect tmp;
    tmp.x1 = dMax(l1, l2);
    tmp.x2 = dMin(r1, r2);
    tmp.y1 = dMax(t1, t2);
    tmp.y2 = dMin(b1, b2);
    return tmp;
}

/*
 * Returns true if this rectangle intersects with the given
 * rectangle (i.e., there is at least one pixel that is within both
 * rectangles), otherwise returns false.
 *
 * The intersection rectangle can be retrieved using the intersected()
 * function.
 */
bool DRect::intersects(const DRect &r) const
{
    if (isNull() || r.isNull())
        return false;

    int l1 = x1;
    int r1 = x1;
    if (x2 - x1 + 1 < 0)
        l1 = x2;
    else
        r1 = x2;

    int l2 = r.x1;
    int r2 = r.x1;
    if (r.x2 - r.x1 + 1 < 0)
        l2 = r.x2;
    else
        r2 = r.x2;

    if (l1 > r2 || l2 > r1)
        return false;

    int t1 = y1;
    int b1 = y1;
    if (y2 - y1 + 1 < 0)
        t1 = y2;
    else
        b1 = y2;

    int t2 = r.y1;
    int b2 = r.y1;
    if (r.y2 - r.y1 + 1 < 0)
        t2 = r.y2;
    else
        b2 = r.y2;

    if (t1 > b2 || t2 > b1)
        return false;

    return true;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
