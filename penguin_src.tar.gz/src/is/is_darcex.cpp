/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_darcex.h"

DArcEx::DArcEx(DWidget *parent, WFlags f)
    : DWidget(*new DArcExCell, parent, f)
{
    setObjectName(DArcEx_ObjName);    
    d_func()->init();
    setEventRoutine(DEvent::Hover, this, (EventRoutine)(&DArcEx::onHoverEvent));
    setEventRoutine(DEvent::PassingOut, this, (EventRoutine)(&DArcEx::onPassingOutEvent));

    m_ptrArc.reset(new (std::nothrow) DArc(this));
    m_ptrArc->setStart(0);
    m_ptrArc->setExtent(360);
    m_ptrArc->setAutoFill(true);
    m_ptrArc->setEdgeColor(DColor(0, 100, 0));
    m_ptrArc->setBackgroundColor(DColor(0, 100, 0));
    m_ptrArc->setMinAspectRatio(10000);
    m_ptrArc->setMaxAspectRatio(10000);
}

DArcEx::~DArcEx()
{
}

bool DArcEx::event(DEvent *e)
{
    return true;
}

void DArcEx::onHoverEvent(const DEvent& rEvent)
{
    printf("DArcEx::Hover event processing ---------\n");
}

void DArcEx::onPassingOutEvent(const DEvent& rEvent)
{
    printf("DArcEx::PassingOut event processing ---------\n");
    repaint(rEvent.getCon());
}

/***************************************************************************
 * DArcExCell member functions
 **************************************************************************/
DArcExCell::DArcExCell()
{
}

DArcExCell::~DArcExCell()
{
}

void DArcExCell::init()
{
}

void DArcExCell::update()
{
    DWidgetCell::update();

}

// vim:set tabstop=4 shiftwidth=4 expandtab:
