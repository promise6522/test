/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DLINE_H
#define DLINE_H

// Boost header files
#include <boost/tr1/memory.hpp>

class DLine
{
public:
    inline DLine();
    inline DLine(const DPoint &pt1, const DPoint &pt2);
    inline DLine(int x1, int y1, int x2, int y2, int z1 = 0, int z2 = 0);

    inline bool isNull() const;

    inline DPoint p1() const;
    inline DPoint p2() const;

    inline int x1() const;
    inline int y1() const;
    inline int z1() const;

    inline int x2() const;
    inline int y2() const;
    inline int z2() const;

    inline int dx() const;
    inline int dy() const;
    inline int dz() const;

    inline void translate(const DPoint &p);
    inline void translate(int dx, int dy, int dz = 0);

    inline DLine translated(const DPoint &p) const;
    inline DLine translated(int dx, int dy, int dz = 0) const;

    inline void setP1(const DPoint &p1);
    inline void setP2(const DPoint &p2);
    inline void setPoints(const DPoint &p1, const DPoint &p2);
    inline void setLine(int x1, int y1, int x2, int y2, int z1 = 0, int z2 = 0);

    inline bool operator==(const DLine &d) const;
    inline bool operator!=(const DLine &d) const { return !(*this == d); }

private:
    DPoint pt1, pt2;
};

typedef std::tr1::shared_ptr<DLine> DLinePtr;

/***************************************************************************
 * DPoint inline functions
 **************************************************************************/
inline DLine::DLine() { }

inline DLine::DLine(const DPoint &pt1_, const DPoint &pt2_) 
	: pt1(pt1_), pt2(pt2_) { }

inline DLine::DLine(int x1pos, int y1pos, 
                    int x2pos, int y2pos, 
                    int z1pos, int z2pos) 
    : pt1(DPoint(x1pos, y1pos, z1pos)), 
      pt2(DPoint(x2pos, y2pos, z2pos)) { }

inline bool DLine::isNull() const
{
    return pt1 == pt2;
}

inline int DLine::x1() const
{
    return pt1.x();
}

inline int DLine::y1() const
{
    return pt1.y();
}

inline int DLine::z1() const
{
    return pt1.z();
}

inline int DLine::x2() const
{
    return pt2.x();
}

inline int DLine::y2() const
{
    return pt2.y();
}

inline int DLine::z2() const
{
    return pt2.z();
}

inline DPoint DLine::p1() const
{
    return pt1;
}

inline DPoint DLine::p2() const
{
    return pt2;
}

/*
 * Returns the horizontal component of the line's vector.
 */
inline int DLine::dx() const
{
    return pt2.x() - pt1.x();
}

/*
 * Returns the vertical component of the line's vector.
 */
inline int DLine::dy() const
{
    return pt2.y() - pt1.y();
}

/*
 * Returns the vertical component of the line's vector.
 */
inline int DLine::dz() const
{
    return pt2.z() - pt1.z();
}

/*
 * Translates this line by the given offset.
 */
inline void DLine::translate(const DPoint &point)
{
    pt1 += point;
    pt2 += point;
}

inline void DLine::translate(int adx, int ady, int adz)
{
    this->translate(DPoint(adx, ady, adz));
}

/*
 * Returns this line translated by the given offset.
 */
inline DLine DLine::translated(const DPoint &p) const
{
    return DLine(pt1 + p, pt2 + p);
}

inline DLine DLine::translated(int adx, int ady, int adz) const
{
    return translated(DPoint(adx, ady, adz));
}

inline void DLine::setP1(const DPoint &aP1)
{
    pt1 = aP1;
}

inline void DLine::setP2(const DPoint &aP2)
{
    pt2 = aP2;
}

inline void DLine::setPoints(const DPoint &aP1, const DPoint &aP2)
{
    pt1 = aP1;
    pt2 = aP2;
}

inline void DLine::setLine(int aX1, int aY1, 
                           int aX2, int aY2,
                           int aZ1, int aZ2)
{
    pt1 = DPoint(aX1, aY1, aZ1);
    pt2 = DPoint(aX2, aY2, aZ2);
}

inline bool DLine::operator==(const DLine &d) const
{
    return pt1 == d.pt1 && pt2 == d.pt2;
}


#endif /* DLINE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
