/**************************************************************************** 
**
** Copyright 2010 Duke Inc.
** 
** Author    State     Date
** Yinlii    Create    2010-03-18
**
****************************************************************************/

#include "is_dfont.h"

//brief:The DFont class specifies a font used for drawing text
/*
* Constructs a font with the other font
*/
DFont::DFont(const DFont &font)
    : m_style(font.m_style),
      m_size(font.m_size),
      m_family(font.m_family),
      m_styleHint(font.m_styleHint)
{ }

//Returns the family name that corresponds to the current style hint.
std::string DFont::defaultFamily() const
{
    switch (m_styleHint) {
    case DFont::Dialog:
        return std::string("Dialog");    
    case DFont::SansSerif:
        return std::string("SanSerif");
    case DFont::Serif:
        return std::string("Serif");
    case DFont::Monospaced:
        return std::string("Monospaced");
    case DFont::DialogInput:
        return std::string("DialogInput");
    }
    //the default styleHint 
    return std::string("Dialog");
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
