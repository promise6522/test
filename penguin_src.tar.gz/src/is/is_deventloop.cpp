/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Haijian Li 
**
****************************************************************************/

#include "is_deventloop.h"
#include "is_dobject.h"

static const unsigned int eventCompressLength = 6;

void DEventLoop::exec(DWidget& rWidget)
{
    while(!m_isExit) {
        if (isEmpty())
        {
            boost::mutex::scoped_lock lock(m_mutex);
            m_cond.wait(lock);
            continue;
        }        

        DEvent rEvent;
        {
            boost::lock_guard<boost::mutex> lock(m_mutex);
            if (m_vEventDeque.size() > eventCompressLength)
                eventCompress();
            rEvent = m_vEventDeque.back();
            m_vEventDeque.pop_back();
        }

        const std::vector<DPath>& rControlPath = rEvent.getEventPath();
        DObject* pObject = rWidget.findChild(rControlPath[0]);
        
        /*std::copy(rControlPath[0].begin(), 
                rControlPath[0].end(), 
                std::ostream_iterator<int>(std::cout, "-"));
        std::cout<<" get message id("<<rEvent.getEventType()<<") <------"<<std::endl;
        */

        DWidget* pWidget = dynamic_cast<DWidget*>(pObject);
        if (NULL != pWidget) {      
            pWidget->event(rEvent);
        }
    }
}

void DEventLoop::eventCompress()
{
    LOG_DEBUG("compress before :"<<m_vEventDeque.size());
    assert(m_vEventDeque.size() > eventCompressLength);
    for (eventQueIt iter = m_vEventDeque.begin() + 1; iter != m_vEventDeque.end();)
    {
       const DEvent& rEvent = *iter;
       const DEvent& rEventPre = *(iter - 1);
       if (rEvent.getEventType() == rEventPre.getEventType() &&
           rEvent.getEventPath() == rEventPre.getEventPath()) {
              iter = m_vEventDeque.erase(iter);
       }
       else {
           ++iter;
       }
    }
    LOG_DEBUG("compress after :"<<m_vEventDeque.size());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
