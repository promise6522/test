/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author LHJ
**
****************************************************************************/

#ifndef DRESOURCEUNIT_H
#define DRESOURCEUNIT_H

// Boost header files
#include <boost/tr1/memory.hpp>

//std
#include <vector>

// Duke header files
#include "is_dglobal.h"

struct DMIME {
     std::string m_subType;
     DMIME(const std::string subType):m_subType(subType)
     {
     }
};

class DResourceUnit
{
public:
    DResourceUnit(const std::string& fileName,
           const std::vector<uint8_t> vData,
           const DMIME& mime);

    void setFileName(const std::string& fileName);
    std::string fileName() const;
    void setData(const std::vector<uint8_t>& data);
    const std::vector<uint8_t>& data() const;
    void setMIME(const DMIME& mime);
    const DMIME& MIME() const;
private:
    std::string m_fileName;
    std::vector<uint8_t> m_data;
    DMIME m_mime;
};

typedef std::tr1::shared_ptr<DResourceUnit> DResourceUnitPtr;


/***************************************************************************
 * DResourceUnit inline functions
 **************************************************************************/

inline DResourceUnit::DResourceUnit(const std::string& fileName,
                       const std::vector<uint8_t> vData,
                       const DMIME& mime)
                       :m_fileName(fileName),
                       m_data(vData),
                       m_mime(mime)
{ }

inline std::string DResourceUnit::fileName() const
{ return m_fileName; }

inline void DResourceUnit::setFileName(const std::string& fileName)
{ m_fileName = fileName; }

inline const std::vector<uint8_t>& DResourceUnit::data() const
{  return m_data; }

inline void DResourceUnit::setData(const std::vector<uint8_t>& vData)
{ m_data = vData; }

inline void DResourceUnit::setMIME(const DMIME& mime) 
{ m_mime = mime; }

inline const DMIME& DResourceUnit::MIME() const 
{ return m_mime; }

#endif //DRESOURCEUNIT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
