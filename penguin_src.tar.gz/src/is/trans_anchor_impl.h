#ifndef __TRANS_ANCHOR_IMPL_H
#define __TRANS_ANCHOR_IMPL_H

#include "ac_container/anchor_implementation.h"

class trans_anchor_impl : public anchor_implementation 
{
public:
    trans_anchor_impl(anchor_id_t& anchor_id);
    trans_anchor_impl();
    virtual ~trans_anchor_impl();
    virtual bool run(call_id_t call_id,
            const node_invocation_request& input,
            ac_anchor_helper * pHelper);
    void add();
    void sub();
};

typedef std::tr1::shared_ptr<trans_anchor_impl> trans_anchor_impl_ptr;

#endif // __TRANS_ANCHOR_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
