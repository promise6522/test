/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei 
**
****************************************************************************/

#ifndef DPORT_H
#define DPORT_H

#include <boost/tr1/memory.hpp>
#include "is_dwidget.h"
#include "is_dtool.h"

class DPortCell;

class DPort : public DWidget {
public:
    DPort(DWidget *parent = 0, WFlags f = 0);
    virtual ~DPort();

    enum Direction {
        None    = 0x0,
        Left    = 0x1,
        Right	= 0x2,
        Up 	    = 0x3,
        Down    = 0x4,
    };

    Direction direction() const;
    void setDirection(Direction dir);
    bool autoFill() const;
    virtual void setAutoFill(bool fill);

    // event handle
    virtual bool event(DEvent *);
    void onHoverEvent(const DEvent& rEvent);
    void onPassingOutEvent(const DEvent& rEvent);

private:
    Direction m_direction;
    bool m_autoFill;

    D_DECLARE_CELL(DPort)
};

/***************************************************************************
 * DPort inline functions
 **************************************************************************/
inline DPort::Direction DPort::direction() const
{ return m_direction; } 

inline void DPort::setDirection(DPort::Direction dir)
{ m_direction = dir; }

inline bool DPort::autoFill() const
{ return m_autoFill; }

inline void DPort::setAutoFill(bool fill)
{ m_autoFill = fill; }

class DPortCell : public DWidgetCell {
public:
    DPortCell();
    virtual ~DPortCell();

    void init();
    virtual void update();
    void setCurvePath(TGeneralCurve *);

    virtual void hover(const is_response_call& response_call);

private:
    D_DECLARE_PUBLIC(DPort)
};

typedef std::tr1::shared_ptr<DPort>  DPortPtr;
typedef std::tr1::shared_ptr<DPortCell>  DPortCellPtr;

const std::string DPort_ObjName("DPort_Object");


#endif // DPORT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
