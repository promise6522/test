/****************************************************************************
**
** Copyright 2011 Duke Inc.
**
** Author Bruce 
**
****************************************************************************/

#include "is_dmapinterfaceeditor.h"
#include "is_darrayinterfaceeditor.h"
#include "is_ddecleditor.h"
#include "is_dapplication.h"
#include "duke_media_interface.h"

DMapInterfaceEditor::DMapInterfaceEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    setObjectName(MapInterfaceEditor_ObjName);
    assert(pMainWin != NULL);    
}

DMapInterfaceEditor::DMapInterfaceEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    setObjectName(MapInterfaceEditor_ObjName);
    assert(pMainWin != NULL);
}

DMapInterfaceEditor::~DMapInterfaceEditor()
{
}

void DMapInterfaceEditor::reload()
{
    LOG_DEBUG("DMapInterfaceEditor:: reload ......");


    // get name & icon
    duke_media_interface *pMapInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    if (NULL == pMapInterface) {
        releaseMedia();
        return;
    }
    pMapInterface->get_name(m_dukeName);
    pMapInterface->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // reload media data
    initItemsInBody();
    return;
}

void DMapInterfaceEditor::initMapInterfaceEditor()
{
   if (NULL != m_ptr && !m_ptr->is_interface() && !m_ptr->is_interface_compound()) 
    {
        releaseMedia();
        return;
    }

    m_ptr->get_name(m_dukeName);
    m_ptr->get_icon(m_dukeIcon);
 
    initTypeFrame();
    return;
}

void DMapInterfaceEditor::initTypeFrame()
{
    m_ptrTypeFrame.reset(new(std::nothrow) DFrame(
                            static_cast<DWidget *>(getBodyFrame())));
    m_ptrTypeFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrTypeFrame->setHideProperty(false);
    m_ptrTypeFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    m_ptrTypeFrame->setAutoFill(false);
    m_ptrTypeFrame->setFrameStyle(DFrame::Panel);
    //m_ptrTypeFrame->registerEvent(DEvent::Drag);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Release);
    m_ptrTypeFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Detail, true);
    m_ptrTypeFrame->registerEvent(DEvent::Select, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrTypeFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrTypeFrame->setGeometry(MIN_COORD, 
                                MIN_COORD, 
                                MAX_COORD, 
                                MAX_COORD);
    m_ptrTypeFrame->setEventRoutine(DEvent::DnD_Release,
                                    this,
                                    static_cast<EventRoutine>(&DMapInterfaceEditor::onDnDReleaseTypeFrame));
    
    m_ptrKeyIFText.reset(new(std::nothrow) DLabel("key", m_ptrTypeFrame.get()));        
    m_ptrKeyIFText->setAlignment(AlignCenter);
    m_ptrKeyIFText->setGeometry(0, 800, MAX_COORD/2, 1400);
    m_ptrKeyIFText->setBackgroundColor(Duke_Transparent_Color);
    m_ptrKeyIFText->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrKeyIFText->setTextColor(Default_Dialog_TextColor);

    m_ptrValIFText.reset(new(std::nothrow) DLabel("value", m_ptrTypeFrame.get()));        
    m_ptrValIFText->setAlignment(AlignCenter);
    m_ptrValIFText->setGeometry(MAX_COORD/2, 800, MAX_COORD/2, 1400);
    m_ptrValIFText->setBackgroundColor(Duke_Transparent_Color);
    m_ptrValIFText->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrValIFText->setTextColor(Default_Dialog_TextColor);
   
    m_ptrKeyName.reset(new(std::nothrow) DLabel("N/A", m_ptrTypeFrame.get()));        
    m_ptrKeyName->setAlignment(AlignCenter);
    m_ptrKeyName->setGeometry(0, 8000, MAX_COORD/2, 1000);
    m_ptrKeyName->setBackgroundColor(Duke_Transparent_Color);
    m_ptrKeyName->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrKeyName->setTextColor(Default_Dialog_TextColor);

    m_ptrValName.reset(new(std::nothrow) DLabel("N/A", m_ptrTypeFrame.get()));        
    m_ptrValName->setAlignment(AlignCenter);
    m_ptrValName->setGeometry(MAX_COORD/2, 8000, MAX_COORD/2, 1000);
    m_ptrValName->setBackgroundColor(Duke_Transparent_Color);
    m_ptrValName->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrValName->setTextColor(Default_Dialog_TextColor);

    initItemsInBody();
    return;
}

void DMapInterfaceEditor::setReadonly()
{
    DEditor::setReadonly();
    m_ptrTypeFrame->unRegisterEvent(DEvent::DnD_Release);
    return;
}

void DMapInterfaceEditor::initItemsInBody()
{
    if (NULL != m_ptr && !m_ptr->is_interface() && !m_ptr->is_interface_compound()) 
    {
        releaseMedia();
        return;
    }
    
    DImage elementImg;
    elementImg.load(getResPath() + MapInterfaceEditorItemImage_FileName);
    elementImg.setRelation(DImage::KeepSmall);

    m_ptrKeyIFButton.reset(new(std::nothrow) 
                    DButton("", elementImg, m_ptrTypeFrame.get()));
    setElementProperty(m_ptrKeyIFButton.get());
    m_ptrKeyIFButton->setGeometry(666, 3000, 4000,4000); 

    m_ptrValIFButton.reset(new(std::nothrow) 
                DButton("", elementImg, m_ptrTypeFrame.get()));
    setElementProperty(m_ptrValIFButton.get());
    m_ptrValIFButton->setGeometry(5600, 3000, 4000,4000); 

    if (m_ptr->is_interface_compound())
    {
        duke_media_compound_interface *pMapCompoundInterface = dynamic_cast<duke_media_compound_interface *>(m_ptr);
        if (NULL == pMapCompoundInterface)
            return;

        duke_media_handle keyInterfaceHandle = pMapCompoundInterface->get_extension_types(0);
        duke_media_handle valInterfaceHandle= pMapCompoundInterface->get_extension_types(1);
        m_ptrKeyIFButton->setMediaByHandle(keyInterfaceHandle);
        m_ptrValIFButton->setMediaByHandle(valInterfaceHandle); 
    }
    else {
        m_ptrKeyIFButton->setMediaByHandle(duke_media_handle(NB_INTERFACE_NONE));
        m_ptrValIFButton->setMediaByHandle(duke_media_handle(NB_INTERFACE_NONE));
    }

    adjustIconForExpand(m_ptrKeyIFButton.get());
    std::string key_name;
    if(duke_media_get_name(m_ptrKeyIFButton->getMediaHandle(), key_name) && !key_name.empty())
    {
        m_ptrKeyName->setContent(key_name);
    }
    else
    {
        m_ptrKeyName->setContent("N/A");                    
    }

    adjustIconForExpand(m_ptrValIFButton.get());
    std::string val_name;
    if(duke_media_get_name(m_ptrValIFButton->getMediaHandle(), val_name) && !val_name.empty())
    {
        m_ptrValName->setContent(val_name);
    }
    else
    {
        m_ptrValName->setContent("N/A");                    
    }
}

void DMapInterfaceEditor::onActivateBtn(const DEvent &event)
{
    LOG_DEBUG("--------------DMapInterfaceEditor::onActivateBtn");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if(pEditor->isHide())
        {
            pEditor->display(event.getCon());
        }
        else
        {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if(m_isReadOnly)
        {
            return;
        }
        
        DArrayInterfaceEditor *pArrayInterfaceEditor = dynamic_cast<DArrayInterfaceEditor *>(pEditor);
        if ((NULL != pArrayInterfaceEditor) && pArrayInterfaceEditor->isHide())
        {
            pSrcWidget->setMediaByHandle(pArrayInterfaceEditor->getMediaHandle());
            LOG_DEBUG(pArrayInterfaceEditor->getMediaHandle().str());
        }
        
        DMapInterfaceEditor *pMapInterfaceEditor = dynamic_cast<DMapInterfaceEditor *>(pEditor);
        if ((NULL != pMapInterfaceEditor) && pMapInterfaceEditor->isHide())
        {
            pSrcWidget->setMediaByHandle(pMapInterfaceEditor->getMediaHandle());
            LOG_DEBUG(pMapInterfaceEditor->getMediaHandle().str());
        }

        DButton * pButton = dynamic_cast<DButton *>(pSrcWidget);
        if(pButton)
        {
            adjustIconForExpand(pButton);
            pButton->updateAll();
            pButton->repaint(event.getCon());        
        }        

        if(pEditor->isModified())
        {
            //set dirty if sub editor is modified
            m_isModified = true;
        }
        saveDukeData();
        return;
    }
    if(pSrcWidget->getMedia()->is_interface_compound())
    {
        duke_media_compound_interface* pMediaInterface = dynamic_cast<duke_media_compound_interface*>(pSrcWidget->getMedia());
        if ((NULL != pMediaInterface) && pMediaInterface->is_interface_array())
        {
            pEditor = createArrayInterfaceEditor(pSrcWidget);
        }
        else if (((NULL != pMediaInterface) && pMediaInterface->is_interface_map()))
        {
             pEditor = createMapInterfaceEditor(pSrcWidget);
        }
        else
        {
             pEditor = createSubEditor(pSrcWidget);
        }

    }
    else 
    {
        duke_media_interface* pMediaInterface = dynamic_cast<duke_media_interface *>(pSrcWidget->getMedia());
        if ((NULL != pMediaInterface) && pMediaInterface->is_interface_array())
        {
            pEditor = createArrayInterfaceEditor(pSrcWidget);
        }
        else if (((NULL != pMediaInterface) && pMediaInterface->is_interface_map()))
        {
             pEditor = createMapInterfaceEditor(pSrcWidget);
        }
        else
        {
             pEditor = createSubEditor(pSrcWidget);
        }
    }
   
    if(pEditor)
    {
        if(m_isReadOnly)
        {
            pEditor->setReadonly();
        }
        
        pEditor->updateAll();
        pEditor->show(event.getCon());
    }    
}

DEditor * DMapInterfaceEditor::createMapInterfaceEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || !pSrcWidget->getMedia())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;


    // Create new IFEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    // Create new arrayEditor with BodyModel
    DMapInterfaceEditorPtr ptrEditor(new(std::nothrow) DMapInterfaceEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDialog();
    ptrEditor->initMapInterfaceEditor();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_MapInterfaceEditor_W_InMainWin, 
            Default_MapInterfaceEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    return ptrEditor.get();
}

void DMapInterfaceEditor::adjustPlacement()
{
    DEditor::adjustPlacement();

    // update declaration view gemoetry
    if (NULL != m_ptrTypeFrame.get())
        m_ptrTypeFrame->setGeometry(MIN_COORD, 
                MIN_COORD, 
                MAX_COORD, 
                MAX_COORD);

}

void DMapInterfaceEditor::setElementProperty(DButton* pElementButton)
{
    if (NULL == pElementButton)
    {
        return;
    }
    pElementButton->setFocusAttr(true);
    pElementButton->registerEvent(DEvent::DnD_Release, true);
    pElementButton->registerEvent(DEvent::Select);
    pElementButton->registerEvent(DEvent::Hover);
    pElementButton->registerEvent(DEvent::PassingOut);
    pElementButton->registerEvent(DEvent::DnD_Start);
    pElementButton->registerEvent(DEvent::Activate);
    pElementButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DMapInterfaceEditor::onActivateBtn));
    pElementButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DMapInterfaceEditor::onPassingOutChild));
    pElementButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DMapInterfaceEditor::onHoverChild));
    pElementButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DMapInterfaceEditor::onSelectChild));
    return;
}

void DMapInterfaceEditor::saveDukeData()
{
    duke_media_interface *pMapInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    duke_media_compound_interface* pMapComInterface = dynamic_cast<duke_media_compound_interface *>(m_ptr);

    if (NULL != pMapInterface)
    {
        if (!pMapInterface->is_interface_map())
        {
            return;     
        }
        if ((NULL != m_ptrKeyIFButton.get()) && (NULL != m_ptrValIFButton.get()))
        {
            duke_media_handle keyInterfaceHandle = m_ptrKeyIFButton->getMediaHandle();
            duke_media_handle valInterfaceHandle = m_ptrValIFButton->getMediaHandle();
            duke_media_handle compoundInterfaceHandle = duke_media_set_map_interface_type(
                this->getApplication()->get_host_committer_id(), m_handle,
                keyInterfaceHandle, valInterfaceHandle);
            setMediaByHandle(compoundInterfaceHandle);
        }
    }

    if (NULL != pMapComInterface)
    {
        if (!pMapComInterface->is_interface_map())
        {
            return;     
        }
        if ((NULL != m_ptrKeyIFButton.get()) && (NULL != m_ptrValIFButton.get()))
        {
            duke_media_handle keyInterfaceHandle = m_ptrKeyIFButton->getMediaHandle();
            duke_media_handle valInterfaceHandle = m_ptrValIFButton->getMediaHandle();
            duke_media_handle compoundInterfaceHandle = duke_media_set_map_interface_type(
                this->getApplication()->get_host_committer_id(), m_handle,
                keyInterfaceHandle, valInterfaceHandle);
            setMediaByHandle(compoundInterfaceHandle);
        }
   }
}

void DMapInterfaceEditor::onDnDReleaseTypeFrame(const DEvent &event)
{
    LOG_DEBUG("--------------DMapInterfaceEditor::onDnDReleaseTypeFrame");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;
   
    DMapInterfaceEditor* pMapInterfaceEditor = dynamic_cast<DMapInterfaceEditor *>(pObject);
    if (NULL != pMapInterfaceEditor) {
        return;
    }
    
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    
    duke_media_handle dukeHandleInterface;
    duke_media_get_interface_by_object(handle, dukeHandleInterface);
        
    if(event.getEventPosition().x() < MAX_COORD/2)
    {   
        m_ptrTypeFrame->detachChildWidget(pSrcWidget);
        m_ptrKeyIFButton->setMediaByHandle(dukeHandleInterface);
        adjustIconForExpand(m_ptrKeyIFButton.get());
        std::string key_name;
        if(duke_media_get_name(m_ptrKeyIFButton->getMediaHandle(), key_name) && !key_name.empty())
        {
            m_ptrKeyName->setContent(key_name);
        }
        else
        {
            m_ptrKeyName->setContent("N/A");                    
        }

    }    
    else
    {
        m_ptrValIFButton->setMediaByHandle(dukeHandleInterface);
        adjustIconForExpand(m_ptrValIFButton.get());
        std::string val_name;
        if(duke_media_get_name(m_ptrValIFButton->getMediaHandle(), val_name) && !val_name.empty())
        {
            m_ptrValName->setContent(val_name);
        }
        else
        {
            m_ptrValName->setContent("N/A");                    
        }

    }
    saveDukeData();
    // Repaint
    updateAll();
    repaint(event.getCon());
    return;
}

void DMapInterfaceEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DMapInterfaceEditor::onPassingOutChild");
    getApplication()->tip()->remove(event.getCon());
}

void DMapInterfaceEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DMapInterfaceEditor::onHoverChild");
    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0]));
    if (NULL == pSrcWidget)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    else
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    return;
}

void DMapInterfaceEditor::onSelectChild(const DEvent &event)
{
    LOG_DEBUG("--------------DMapInterfaceEditor::onSelectChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;

    updateAll();
    repaint(event.getCon());
}


void DMapInterfaceEditor::onGenerate(const DEvent &event)
{
    // save name and icon
    DEditor::onGenerate(event);

    duke_media_interface *pMapInterface = dynamic_cast<duke_media_interface *>(m_ptr);
    if (NULL == pMapInterface)
        return;
    
    //add by roger
    duke_media_handle handle;
    //pMapMedia->generate(getApplication()->username(), handle);
}

DEditor * DMapInterfaceEditor::createArrayInterfaceEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || !pSrcWidget->getMedia())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;


    // Create new IFEditor with BodyModel
    DMainWin * pMainWin = m_pMainWin;
    // Get the postion in mainwin        
    DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
            pSrcWidget->geometryY());
    DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);

    // Create new arrayEditor with BodyModel
    DArrayInterfaceEditorPtr ptrEditor(new(std::nothrow) DArrayInterfaceEditor(BodyModel,
                pMainWin,
                pMainWin->getRootWidget()));
    insertSubEditor(pSrcWidget, ptrEditor);
    ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

    ptrEditor->initDialog();
    ptrEditor->initArrayInterfaceEditor();
    ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
            Default_ArrayInterfaceEditor_W_InMainWin, 
            Default_ArrayInterfaceEditor_H_InMainWin);
    ptrEditor->setDisplayOrder(displayOrder() - 1);
    return ptrEditor.get();
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
