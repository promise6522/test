#ifndef DABOUTDLG_H
#define DABOUTDLG_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"

class DAboutDlg : public DDialogEx
{
public:
    explicit DAboutDlg(DMainWin * pMainWin = NULL, DWidget * parent = 0);
    explicit DAboutDlg(const std::string& title,
                       DMainWin *pMainWin = NULL,
                       DWidget * parent = 0);
    virtual ~DAboutDlg();

    //Init    
    virtual void initDialog();    

protected:
    //Event handle
    void onOK(const DEvent &event);    

private:
    //OK button
    DButtonPtr m_ptrOKButton;
};

typedef std::tr1::shared_ptr<DAboutDlg>  DAboutDlgPtr;

const std::string AboutDlg_ObjName("About_Dialog");
const std::string AboutDlg_Title_Name("About Duck...");
const std::string AboutDlg_Button_Name("OK");
const std::string AboutDlg_ButtonImage_FileName("smallObject.png");
    
#endif /* DABOUTDLG_H */
    
// vim:set tabstop=4 shiftwidth=4 expandtab:
