/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author  State   Data
** Yinlii  Create  2010-03-26
**
****************************************************************************/

#ifndef DTEXT_H
#define DTEXT_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dfont.h"
#include "is_dcolor.h"
#include "is_dmargins.h"

class DText {
public:
    DText();
    DText(const std::string &textData);
    DText(const std::string &textData, const DFont &faultFont, const DColor &faultColor);
    DText(const DText &otherText);
    ~DText() { };

    std::string textData() const;
    void setTextData(const std::string &text);

    DFont font() const;
    DFont &rfont();
    void setFont(const DFont &font);
    int fontSize() const;
    void setFontSize(const int s);
    DFont::Style fontStyle() const;
    void setFontStyle(const DFont::Style s);

    DColor color() const;
    DColor &rcolor();
    void setColor(const DColor &color);

    DMargin margin() const;
    DMargin &rmargin();
    void setMargin(const DMargin &);

    AlignmentFlag align() const;
    AlignmentFlag &ralign();
    void setAlign(AlignmentFlag align);

    bool wrap() const;
    void setWrap(bool w);

    bool localEditable() const;
    void setLocalEditable(bool editable);

private:
    std::string m_textData;
    DFont m_font;
    DColor m_color;
    DMargin m_margin;
    AlignmentFlag m_align;
    bool m_wrap;
    bool m_localEditable;
};

typedef std::tr1::shared_ptr<DText> DTextPtr;

/***************************************************************************
 * DText inline functions
 **************************************************************************/
inline DText::DText()
    : m_color(0, 0, 0),
      m_align(AlignLeft),
      m_wrap(false),
      m_localEditable(false)
{ }

inline DText::DText(const std::string &textData)
    : m_textData(textData), 
      m_color(0, 0, 0),
      m_align(AlignLeft),
      m_wrap(false),
      m_localEditable(false)
{ }

//Constructs a text with the specialed text,font,color.
inline DText::DText(const std::string &textData, const DFont &faultFont,const DColor &faultColor)
    : m_textData(textData),
      m_font(faultFont),
      m_color(faultColor),
      m_align(AlignLeft),
      m_wrap(false),
      m_localEditable(false)
{ }

//Constructs a text with the given text
inline DText::DText(const DText &otherText)
    : m_textData(otherText.m_textData),
      m_font(otherText.m_font),
      m_color(otherText.m_color),
      m_align(otherText.m_align),
      m_wrap(otherText.m_wrap),
      m_localEditable(otherText.m_localEditable)
{ }

//Returns the text data
inline std::string DText::textData() const
{ return m_textData; }

//Sets the text data
inline void DText::setTextData(const std::string &textData)
{ m_textData = textData; }

//Returns the font of the text
inline DFont DText::font() const
{ return m_font; }

inline DFont &DText::rfont()
{ return m_font; }

inline int DText::fontSize() const
{ return m_font.size(); }

inline void DText::setFontSize(const int s)
{ m_font.setSize(s); }

inline DFont::Style DText::fontStyle() const
{ return m_font.style(); }

inline void DText::setFontStyle(const DFont::Style s)
{ m_font.setStyle(s); }

//Sets the font of the text
inline void DText::setFont(const DFont & font)
{ m_font = font; }

//Returns the color of the text
inline DColor DText::color() const
{ return m_color; }

inline DColor &DText::rcolor()
{ return m_color; }

//Sets the color of the text
inline void DText::setColor(const DColor &color)
{ m_color = color; }

inline DMargin DText::margin() const
{ return m_margin; }

inline DMargin &DText::rmargin()
{ return m_margin; }

inline void DText::setMargin(const DMargin &margin)
{ m_margin = margin; }

inline AlignmentFlag DText::align() const
{ return m_align; }

inline AlignmentFlag &DText::ralign()
{ return m_align; }

inline void DText::setAlign(AlignmentFlag align)
{ m_align = align; }

inline bool DText::wrap() const
{ return m_wrap; }

inline void DText::setWrap(bool w)
{ m_wrap = w; }

inline bool DText::localEditable() const
{ return m_localEditable; }

inline void DText::setLocalEditable(bool editable)
{ m_localEditable = editable; }

#endif


// vim:set tabstop=4 shiftwidth=4 expandtab:
