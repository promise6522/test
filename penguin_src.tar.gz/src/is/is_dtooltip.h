/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DTOOLTIP_H
#define DTOOLTIP_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dcolor.h"

class DToolTipCell;

class DToolTip : public DWidget {
public:
    DToolTip(DWidget *parent = 0, WFlags f = 0);
    virtual ~DToolTip();

    void add(DWidget *, const std::string &, const is_response_call&);
    void remove(const is_response_call& response_call);

private:
    std::string m_tip;
    int m_line;
    int m_width;
    int m_height;

    D_DECLARE_CELL(DToolTip)
};

class DToolTipCell : public DWidgetCell {
public:
    DToolTipCell();
    virtual ~DToolTipCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DToolTip)
};

typedef std::tr1::shared_ptr<DToolTip>  DToolTipPtr;
typedef std::tr1::shared_ptr<DToolTipCell>  DToolTipCellPtr;

const int DToolTip_Space_Between = 50;
const int DToolTip_Line_Words = 30;
const int DToolTip_Line_Height = 300;
const int DToolTip_Max_Width = 2300;

const DColor DToolTip_Font_Color(255, 255, 255);
const DColor DToolTip_Background_Color(46, 46, 46, 228);
const DColor DToolTip_Edge_Color(46, 46, 46, 228);

const std::string DToolTip_ObjName("DToolTip_Object");


#endif // DTOOLTIP_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
