 /****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author     State     Date
** Yinlii     Create    2010-03-22
**
****************************************************************************/
#ifndef DCURSOR_H
#define DCURSOR_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dimage.h"

class DCursor { 
public:
    enum CursorShape {
        DefaultCursor,
        TextCursor,
        CrosshairCursor,
        HandCursor,
        DragCursor,
        DropCursor,
        NoDropCursor,
        WaitCursor,
        IdleCursor,
        CustomCursor
    };

    DCursor();
    DCursor(CursorShape shape);
    DCursor(const DCursor &cursor);

    ~DCursor(){ }

    DCursor &operator=(const DCursor &cursor);

    CursorShape shape() const;
    void setShape(CursorShape newShape);

    const DImage * image() const;
    void setImage(const DImage &);

    const DSize size() const;
    void setSize(DSize &);

private:
    DSize m_size;
    CursorShape m_shape;
    DImagePtr m_pImage;
};

typedef std::tr1::shared_ptr<DCursor> DCursorPtr;

/***************************************************************************
 * DCursor inline functions
 **************************************************************************/
//Constructs a cursor with the default arrow shape.
inline DCursor::DCursor()
    : m_size(0, 0),
      m_shape(DefaultCursor)
{ }

//Constructs a cursor with the specified a shape.
inline DCursor::DCursor(CursorShape shape)
    : m_size(0, 0),
      m_shape(shape)
{
    if (shape == CustomCursor) {
        m_size.setWidth(1000);
	m_size.setHeight(1000);
	m_pImage.reset(new(std::nothrow) DImage);
	assert(m_pImage.get() != NULL);
    }
}

//Constructs a copy of the cursor
inline DCursor::DCursor(const DCursor & other)
     : m_size(other.m_size),
       m_shape(other.m_shape)
{
    if (other.m_shape == CustomCursor) { 
	m_pImage.reset(new(std::nothrow) DImage(*other.m_pImage));
	assert(m_pImage.get() != NULL);
    }
}

//Assigns \a other to this cursor and returns a reference to this cursor.
inline DCursor &DCursor::operator=(const DCursor & other)
{
    m_size = other.m_size;
    m_shape = other.m_shape;
    if (other.m_shape == CustomCursor) 
	m_pImage.reset(new(std::nothrow) DImage(*other.m_pImage));

    return *this;
}

 
//Returns the cursor shape identifier.
inline DCursor::CursorShape DCursor::shape() const
{ return m_shape; }

//Sets the cursor to the shape identified by a shape.
inline void DCursor::setShape(CursorShape newShape)
{ m_shape = newShape; }

inline const DImage * DCursor::image() const
{ return m_pImage.get(); }

inline void DCursor::setImage(const DImage &img)
{
    m_pImage.reset(new(std::nothrow) DImage(img));
    assert(m_pImage.get() != NULL);
}

inline const DSize DCursor::size() const
{ return m_size; }

inline void DCursor::setSize(DSize &size)
{ m_size = size; }

#endif /* DCURSOR_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
