/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

#ifndef DMAINWIN_H
#define DMAINWIN_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_dbutton.h"
#include "is_dtool.h"
#include "is_ddialog.h"
#include "is_dimagelabel.h"
#include "is_ddecleditor.h"
#include "is_druneditor.h"
#include "is_dconteditor.h"
#include "is_dobjeditor.h"
#include "is_difeditor.h"
#include "is_dimpleditor.h"

class DToolWin;

//DWidget in main windows
typedef std::vector<DWidgetPtr> MainWidgets;
typedef MainWidgets::iterator MainWidgetsIt;
typedef MainWidgets::size_type MainWidgetsIdx;

class DMainWin : public DWidget
{
    //friend class boost::serialization::access;
public:
    DMainWin(DWidget *parent = 0, WFlags f = 0);
    virtual ~DMainWin();

    //Set & Get DToolWin
    DToolWin * toolWin();
    void setToolWin(DToolWin * pToolWin);

    //Get MainWin topWidget
    DWidget * getRootWidget();

    //Manager the widget in main windows
    MainWidgetsIdx insertWidget(DWidgetPtr ptrWidget);
    void eraseWidget(DWidget* pDelWidget);    
    DWidget* findWidget(const DPath& buttonPath);

    //Destory the widget both in main windows and related buttions in tool window
    void destoryWidgetAndButton(DWidget *pWidget, const is_response_call& response_call);

    //Destory the managed children from mainwin
    void destoryChildWidgets(DObjectList * pChildWidgets, const is_response_call& response_call);

    //Erase/Insert button and buttonWidgetMap in toolwin
    void eraseButtonAndMap(DWidget *pWidget, const is_response_call& response_call);
    void insertButtonAndMap(DWidget *pWidget, const is_response_call& response_call);

    //update function
    void update();
    void repaintAll(const is_response_call& response_call, bool hasData = true);
    void repaintAllAndSubEditor(const is_response_call& response_call, bool hasData = true);

    //drag widget
    DWidget * dragWidget();
    void setDragWidget(DWidget * pWidget);

    //active widget
    DWidget * activeWidget();
    void setActiveWidget(DWidget * pWidget);

    //Event handle
    void onDnDStart(const DEvent &event);
    void onDnDDrag(const DEvent &event);    
    void onDnDRelease(const DEvent &event);
    void onSelect(const DEvent &event);
    void saveInitScene();
    void restoreInitScene();

    //synchronize editor with same handle
    void synchronizeEditors(const is_response_call& response_call, DEditor * pSrcEditor);

private:
    void initMainWin();
    void getWidgetRecursive(DWidget *pWidget, std::vector<DWidget *> &allWidget);
    bool createEditorByHandle(const duke_media_handle& rDukeMediaHandle);
    DDeclEditorPtr createNewDeclEditor(const duke_media_handle& rDukeMediaHandle);
    DRunEditorPtr createNewRunEditor(const duke_media_handle& rDukeMediaHandle);
    DIFEditorPtr createNewIFEditor(const duke_media_handle& rDukeMediaHandle);
    DImplEditorPtr createNewImplEditor(const duke_media_handle& rDukeMediaHandle);
    DObjEditorPtr createNewObjEditor(const duke_media_handle& rDukeMediaHandle);
    DContEditorPtr createNewContEditor(const duke_media_handle& rDukeMediaHandle);
    DMainWin(const DMainWin& rMainWin);
    DMainWin& operator=(const DMainWin& rMainWin);

private:
    //the vector for buttons
    MainWidgets m_mainWidgets;

    //save the mainframe's ptr for dynamic creating dwidgets in maiframe
    DToolWin * m_pToolWin;

    //active dwidget
    DWidget * m_pActiveWidget;
    DWidget * m_pDragWidget;
    DPoint m_dragPoint;
    DImageLabelPtr m_ptrBgLabel;
};

typedef std::tr1::shared_ptr<DMainWin>  DMainWinPtr;

const std::string MainWin_ObjName("Main_Window");
const std::string MainWin_Background_ObjName("MainWin_Background");
const std::string MainWin_BackgroundImg_FileName("mainwin_background.png");
const DColor MainWin_Background_Color(85, 85, 85);

const int MainWin_Background_DisplayOrder = 10000;
const int MainWin_Display_StartOrder = 1000;

#endif //DMAINWIN_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
