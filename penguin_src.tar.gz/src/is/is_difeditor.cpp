/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/

#include "is_difeditor.h"
#include "is_ddecleditor.h"
#include "is_dmainwin.h"
#include "is_dapplication.h"
////#include "media/duke_media_header.h"

DIFEditor::DIFEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    m_isSingleton = false;
    m_isExpand = false;
    m_row = 0;
    m_rowHeight = IFEditor_Row_Height;
    setObjectName(IFEditor_ObjName);
    assert(pMainWin != NULL);    
}

DIFEditor::DIFEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    m_isSingleton = false;
    m_isExpand = false;
    m_row = 0;
    m_rowHeight = IFEditor_Row_Height;
    setObjectName(IFEditor_ObjName);
    assert(pMainWin != NULL);
}

DIFEditor::~DIFEditor()
{
}

void DIFEditor::duplicateItemsByHandle(const duke_media_handle& hif)
{
    if (!hif.is_interface()) {
        assert(!"Invalid interface handle.");
        return;
    }

    if (m_ptr)
        releaseMedia();
    
    if (hif.is_builtin_interface())
    {
        duke_media_interface* pIFMedia = new(std::nothrow) duke_media_interface(hif);
        m_ptr = pIFMedia;
        m_handle = hif;
    }
    else if (hif.is_bridge_interface())
    {
        assert(!"bridge interface can't be processed by DIFEditor");
        // duke_media_bridge_interface* pIFMedia = new(std::nothrow) duke_media_bridge_interface(
        //                                         getApplication()->get_host_committer_id(), 
        //                                         getApplication()->username());
        // pIFMedia->copy(hif);      
        // m_ptr = pIFMedia;
        // m_handle = pIFMedia->get_handle();
    }
    else/* interface compound */
    {    
        duke_media_compound_interface* pIFMedia = new(std::nothrow) duke_media_compound_interface(
                                                    getApplication()->get_host_committer_id(), 
                                                    getApplication()->username());
        pIFMedia->copy(hif);
        m_ptr = pIFMedia;
        m_handle = pIFMedia->get_handle();
    }
    assert(m_ptr != NULL);    
}

void DIFEditor::reload()
{
    LOG_DEBUG("DIFEditor:: reload ......");

    for (IFWidgetsIt it = m_ifWidgets.begin(); it != m_ifWidgets.end(); ++it) {
        if (it->get()) {
            //delete subEditor if there is
            DEditor * pEditor = findSubEditorByWidget(it->get());
            if (pEditor != NULL) {
                m_pMainWin->getRootWidget()->detachChildWidget(pEditor);
                eraseSubEditor(pEditor);        
            }

            m_ptrDeclFrame->detachChildWidget(it->get());
        }
    }
    m_ifWidgets.clear();

    // clear
    m_isSingleton = false;
    m_row = 0;
    m_rowHeight = IFEditor_Row_Height;

    setMediaByHandle(m_handle);
    // get name & icon
    duke_media_compound_interface *pIfMedia = dynamic_cast<duke_media_compound_interface *>(m_ptr);
    if (NULL == pIfMedia) {
        releaseMedia();
        return;
    }
    pIfMedia->get_name(m_dukeName);
    pIfMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // reload media data
    initItemsInBody();

    m_isSingleton = dynamic_cast<duke_media_compound_interface *>(m_ptr)->get_singleton();
    DImage img, selImg;
    if (m_isSingleton) {
        img.load(getResPath() + IFEditor_SingletonImage_FileName);
        selImg.load(getResPath() + IFEditor_SingletonSelImage_FileName);
        m_isSingleton = false;
    } else {
        img.load(getResPath() + IFEditor_NonSingletonImage_FileName);
        selImg.load(getResPath() + IFEditor_NonSingletonSelImage_FileName);
        m_isSingleton = true;
    }
    m_ptrSingletonButton->setImage(img);
    m_ptrSingletonButton->setSelImage(selImg);
    m_ptrSingletonButton->setSelected(false);
}

void DIFEditor::initIFEditor(bool createNew)
{
    // get name & icon

    /*
    duke_media_compound_interface *pIfMedia = dynamic_cast<duke_media_compound_interface *>(m_ptr);
    if (NULL == pIfMedia) {
        releaseMedia();
        return;
    }
    */
    if(createNew)
        m_dukeName = "";
    else
        m_ptr->get_name(m_dukeName);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    m_ptr->get_icon(m_dukeIcon);

    initDeclFrame();
    initSingletonBar();
    initExpandBar();

    if(getMediaHandle().is_builtin_interface()
        || getMediaHandle().is_bridge_interface())
    {
        this->setReadonly();
    }
}

void DIFEditor::initDeclFrame()
{
    m_ptrDeclFrame.reset(new(std::nothrow) DFrame(
                static_cast<DWidget *>(getBodyFrame())));
    m_ptrDeclFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrDeclFrame->setHideProperty(false);
    m_ptrDeclFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDeclFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrDeclFrame->setAutoFill(false);
    m_ptrDeclFrame->setFrameStyle(DFrame::Panel);
    //m_ptrDeclFrame->registerEvent(DEvent::Drag);
    m_ptrDeclFrame->registerEvent(DEvent::DnD_Release);
    m_ptrDeclFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrDeclFrame->registerEvent(DEvent::Detail, true);
    m_ptrDeclFrame->registerEvent(DEvent::Select, true);
    m_ptrDeclFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrDeclFrame->registerEvent(DEvent::Resize_Release, true);

    m_ptrDeclFrame->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DIFEditor::onDnDRelease));

    initItemsInBody();
}

void DIFEditor::initItemsInBody()
{
    if (!m_ptr || !m_ptr->is_interface()) {
        releaseMedia();
        return;
    }

    duke_media_handle_vector hdecls;

    //comment : all these interfaces should inherit from one base and use virtual funcs
    if(dynamic_cast<duke_media_interface*>(m_ptr))
        dynamic_cast<duke_media_interface*>(m_ptr)->get_declarations(hdecls);
    else if(dynamic_cast<duke_media_compound_interface *>(m_ptr))
        dynamic_cast<duke_media_compound_interface *>(m_ptr)->get_declarations(hdecls);
    else if(dynamic_cast<duke_media_bridge_interface*>(m_ptr))
        dynamic_cast<duke_media_bridge_interface*>(m_ptr)->get_declarations(hdecls);

    DImage declImg;
    declImg.load(getResPath() + IFEditorItemImage_FileName);
    declImg.setRelation(DImage::KeepSmall);
    DImage declSelImg;
    declSelImg.load(getResPath() + IFEditorSelItemImage_FileName);
    declSelImg.setRelation(DImage::KeepSmall);

    for (duke_media_handle_const_iterator it = hdecls.begin(); 
            it != hdecls.end(); ++it) {
        
        // not create button for general instructions for clarity
        if(it->is_instruction_general())
            continue;

        DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                    declImg,
                    declSelImg,
                    m_ptrDeclFrame.get()));
        ptrDeclButton->setSelected(false);
        ptrDeclButton->setFocusAttr(true);
        ptrDeclButton->registerEvent(DEvent::Select);
        ptrDeclButton->registerEvent(DEvent::Activate);
        ptrDeclButton->registerEvent(DEvent::Hover);
        ptrDeclButton->registerEvent(DEvent::PassingOut);
        ptrDeclButton->registerEvent(DEvent::Delete);
        ptrDeclButton->setEventRoutine(DEvent::PassingOut,
                this,
                static_cast<EventRoutine>(&DIFEditor::onPassingOutChild));
        ptrDeclButton->setEventRoutine(DEvent::Hover,
                this,
                static_cast<EventRoutine>(&DIFEditor::onHoverChild));
        ptrDeclButton->setEventRoutine(DEvent::Delete,
                this,
                static_cast<EventRoutine>(&DIFEditor::onDeleteChild));
        ptrDeclButton->setEventRoutine(DEvent::Select,
                this,
                static_cast<EventRoutine>(&DIFEditor::onSelectChild));
        ptrDeclButton->setEventRoutine(DEvent::Activate,
                this,
                static_cast<EventRoutine>(&DIFEditor::onActivateChild));

        ptrDeclButton->setMediaByHandle(*it);
        m_ifWidgets.push_back(ptrDeclButton);
    }

    updateDeclView();
}

void DIFEditor::initSingletonBar()
{
    if (!m_ptr || !m_ptr->is_interface()) {
        releaseMedia();
        return;
    }
    
    // get singleton flag
    if(dynamic_cast<duke_media_interface*>(m_ptr))
        m_isSingleton = false;
    else if(dynamic_cast<duke_media_bridge_interface*>(m_ptr))
        m_isSingleton = false;
    else
        m_isSingleton = dynamic_cast<duke_media_compound_interface *>(m_ptr)->get_singleton();

    DImage img, selImg;
    if (m_isSingleton) {
        img.load(getResPath() + IFEditor_SingletonImage_FileName);
        selImg.load(getResPath() + IFEditor_SingletonSelImage_FileName);
    } else {
        img.load(getResPath() + IFEditor_NonSingletonImage_FileName);
        selImg.load(getResPath() + IFEditor_NonSingletonSelImage_FileName);
    }
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    m_ptrSingletonButton.reset(new(std::nothrow) DButton("",
                img,   
                selImg,
                static_cast<DWidget *>(getBodyFrame()))); 
    m_ptrSingletonButton->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrSingletonButton->registerEvent(DEvent::Select);
    m_ptrSingletonButton->registerEvent(DEvent::Hover);
    m_ptrSingletonButton->registerEvent(DEvent::PassingOut);
    m_ptrSingletonButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DIFEditor::onSelectSingleton));
    m_ptrSingletonButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DIFEditor::onHoverSingleton)); 
    m_ptrSingletonButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DIFEditor::onPassingOutSingleton)); 
    m_ptrSingletonButton->setSelected(false);

    m_ptrSingletonButton->registerEvent(DEvent::DnD_Start, true);
    m_ptrSingletonButton->registerEvent(DEvent::DnD_Release, true);
    m_ptrSingletonButton->registerEvent(DEvent::Resize_Start, true);
    m_ptrSingletonButton->registerEvent(DEvent::Resize_Release, true);
}

void DIFEditor::initExpandBar()
{
    if (!m_ptr || !m_ptr->is_interface()) {
        releaseMedia();
        return;
    }

    DImage img, selImg;
    if (m_isExpand) {
        img.load(getResPath() + IFEditor_ExpandImage_FileName);
        selImg.load(getResPath() + IFEditor_ExpandSelImage_FileName);
    } else {
        img.load(getResPath() + IFEditor_NonExpandImage_FileName);
        selImg.load(getResPath() + IFEditor_NonExpandSelImage_FileName);
    }
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    m_ptrExpandButton.reset(new(std::nothrow) DButton("",
                img,   
                selImg,
                static_cast<DWidget *>(getBodyFrame()))); 
    m_ptrExpandButton->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrExpandButton->registerEvent(DEvent::Select);
    m_ptrExpandButton->registerEvent(DEvent::Hover);
    m_ptrExpandButton->registerEvent(DEvent::PassingOut);
    m_ptrExpandButton->setSelected(false);

    m_ptrExpandButton->registerEvent(DEvent::DnD_Start, true);
    m_ptrExpandButton->registerEvent(DEvent::DnD_Release, true);
    m_ptrExpandButton->registerEvent(DEvent::Resize_Start, true);
    m_ptrExpandButton->registerEvent(DEvent::Resize_Release, true);
}

void DIFEditor::updateDeclView()
{
    m_row = (m_ifWidgets.size() % IFEditor_Col_Items) ?
            (m_ifWidgets.size() / IFEditor_Col_Items + 1) :
            (m_ifWidgets.size() / IFEditor_Col_Items); 
    if (IFEditor_Row_Height*m_row > MAX_COORD)
        m_rowHeight = MAX_COORD / m_row;
    int colWidth = MAX_COORD / IFEditor_Col_Items;

    int rcnt = 0;
    int ccnt = 0;
    for (IFWidgetsIt it = m_ifWidgets.begin();
            it != m_ifWidgets.end();
            ++it) {
        DWidget * pDecl = (*it).get();;
        assert(pDecl != NULL);
        pDecl->setGeometry(ccnt*colWidth + 100,
                rcnt*m_rowHeight + 100,
                colWidth - 200,
                m_rowHeight - 200);

        ccnt++;
        if (ccnt == IFEditor_Col_Items) {
            rcnt++;
            ccnt = 0;
        }
    }
}

void DIFEditor::adjustPlacement()
{
    DEditor::adjustPlacement();

    // update singleton button gemoetry
    if ((NULL != getBodyFrame()) && (NULL != getViewFrame())
            && (geometrySize().height() != 0) 
            && (getBodyFrame()->geometrySize().height() != 0)) {

        int heightInEditor = IFEditor_SingletonBar_H_InMainWin * MAX_COORD / 
            geometrySize().height(); 
        int heightInView  = heightInEditor * MAX_COORD / 
            getViewFrame()->geometrySize().height(); 
        m_singletonBarHeight = heightInView * MAX_COORD / 
            getBodyFrame()->geometrySize().height();         

    } else {
        m_singletonBarHeight = 0;
    }

    if (NULL != m_ptrSingletonButton)
        m_ptrSingletonButton->setGeometry(IFEditor_SingletonBar_X_InBodyFrame, 
                MAX_COORD - m_singletonBarHeight, 
                IFEditor_SingletonBar_W_InBodyFrame, 
                m_singletonBarHeight);

    if (NULL != m_ptrExpandButton)
        m_ptrExpandButton->setGeometry(IFEditor_ExpandBar_X_InBodyFrame, 
                MAX_COORD - m_singletonBarHeight * 2, 
                IFEditor_ExpandBar_W_InBodyFrame, 
                m_singletonBarHeight);

    // update declaration view gemoetry
    if (NULL != m_ptrDeclFrame.get())
        m_ptrDeclFrame->setGeometry(IFEditor_DeclFrame_X_InBodyFrame, 
                MIN_COORD, 
                IFEditor_DeclFrame_W_InBodyFrame, 
                MAX_COORD - m_singletonBarHeight * 2);
}

DButton * DIFEditor::createWidgetForFunc(DWidget *pSrc)
{
    assert(pSrc || pSrc->getMedia());

    DImage declImg;
    declImg.load(getResPath() + IFEditorItemImage_FileName);
    declImg.setRelation(DImage::KeepSmall);
    DImage declSelImg;
    declSelImg.load(getResPath() + IFEditorSelItemImage_FileName);
    declSelImg.setRelation(DImage::KeepSmall);

    if (IFEditor_Row_Height*(m_row+1) > MAX_COORD)
        m_rowHeight = MAX_COORD / m_row;

    // create new declaration 
    DButtonPtr ptrDeclButton(new(std::nothrow) DButton("",
                declImg,
                declSelImg,
                m_ptrDeclFrame.get()));
    ptrDeclButton->setSelected(false);
    ptrDeclButton->setFocusAttr(true);
    ptrDeclButton->registerEvent(DEvent::Select);
    ptrDeclButton->registerEvent(DEvent::Activate);
    ptrDeclButton->registerEvent(DEvent::Hover);
    ptrDeclButton->registerEvent(DEvent::PassingOut);
    ptrDeclButton->registerEvent(DEvent::Delete);
    ptrDeclButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DIFEditor::onPassingOutChild));
    ptrDeclButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DIFEditor::onHoverChild));
    ptrDeclButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DIFEditor::onDeleteChild));
    ptrDeclButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DIFEditor::onSelectChild));
    ptrDeclButton->setEventRoutine(DEvent::Activate,
            this,
            static_cast<EventRoutine>(&DIFEditor::onActivateChild));

    ptrDeclButton->setMediaByHandle(pSrc->getMediaHandle());
    if (!dynamic_cast<duke_media_compound_interface *>(m_ptr)->add_declaration(
                pSrc->getMediaHandle()))
        m_ptrDeclFrame->detachChildWidget(ptrDeclButton.get());

    m_ifWidgets.push_back(ptrDeclButton);

    updateDeclView();

    return ptrDeclButton.get();
}

void DIFEditor::dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame)
{
    assert(NULL != m_pMainWin);
    DPoint releasePos = rEvent.getEventPosition();
   
    DWidget *pWidget = pFrame;
    DWidget *pParentWidget = dynamic_cast<DWidget *>(pWidget->parent());

    while ((pParentWidget != NULL) && (pParentWidget != m_pMainWin)) {
        DPoint pPos = pWidget->geometryPos();
        DSize pSize = pWidget->geometrySize();
        releasePos.setX(releasePos.x() * pSize.width() / MAX_COORD + pPos.x());
        releasePos.setY(releasePos.y() * pSize.height() / MAX_COORD + pPos.y());
        pWidget = pParentWidget;
        pParentWidget = dynamic_cast<DWidget *>(pParentWidget->parent());
    }

    DEvent& eventRef = const_cast<DEvent &>(rEvent);
    eventRef.setEventPosition(releasePos);
    m_pMainWin->onDnDRelease(rEvent); 
}

void DIFEditor::onDnDRelease(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onDnDRelease");
    DApplication* pApp = getApplication();
    if (pApp != NULL) {
        pApp->setDragCursor(DCursor::DefaultCursor);
    }

    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = pApp->top()->findChild(childPath[1]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    duke_media_handle handle = pSrcWidget->getMediaHandle();
    if (pSrcWidget == NULL)
        return;
 
    // if a dialog release to frame
    DDialog* pDialog = dynamic_cast<DDialog *>(pSrcWidget);
    if (NULL  != pDialog) {
        dialogReleaseToFrame(event, m_ptrDeclFrame.get());
        return;
    }

    // only receive duke declaration
    if (!handle.is_declaration()) 
        return;
    
    //set dirty
    m_isModified = true;
    
    // Create widget for duke declaration 
    createWidgetForFunc(pSrcWidget);

    // Repatint
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DIFEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onPassingOutChild");
    getApplication()->tip()->remove(event.getCon());
}

void DIFEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onHoverChild");
    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0]));
    if (NULL == pSrcWidget)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    else
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
}

void DIFEditor::onDeleteChild(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onDeleteChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;
    
    //set dirty
    m_isModified = true;

    // Delete declaration 
    for (IFWidgetsIt it = m_ifWidgets.begin(); 
            it != m_ifWidgets.end(); 
            ++it) {
        if (it->get() == pSrcWidget) {
            dynamic_cast<duke_media_compound_interface *>(m_ptr)->del_declaration(
                    pSrcWidget->getMediaHandle());
            m_ptrDeclFrame->detachChildWidget(pSrcWidget);
            m_ifWidgets.erase(it);
            break;
        }
    }

    getApplication()->tip()->remove(event.getCon());

    updateDeclView();
    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DIFEditor::onSelectChild(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onSelectChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DButton* pSrcWidget = dynamic_cast<DButton *>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;

    for (IFWidgetsIt it = m_ifWidgets.begin(); 
            it != m_ifWidgets.end(); 
            ++it) {
        if (it->get() != pSrcWidget) {
            DButton* pBtn = dynamic_cast<DButton *>(it->get()); 
            if (pBtn != NULL)
                pBtn->setSelected(false);
        }
    }

    pSrcWidget->setSelected(true);

    updateAll();
    repaint(event.getCon());
}

void DIFEditor::onActivateChild(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onActivateChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(pObject); 
    if (pSrcWidget == NULL)
        return;

    if (pSrcWidget->getMediaHandle().is_function_instruction())
        return;

    DEditor * pEditor = findSubEditorByWidget(pSrcWidget);
    // display editor
    if (pEditor) {
        pEditor->setDisplayOrder(displayOrder() - 1);
        pEditor->updateAll();
        if (pEditor->isHide()) { 
            pEditor->display(event.getCon()) ;
        } else {
            pEditor->hideAllSubEditors(event.getCon());
            pEditor->hide(event.getCon());
        }

        if (pEditor->isModified()) {
            //set dirty if sub editor is modified
            m_isModified = true;
        }

        return;
    }

    pEditor = createSubEditor(pSrcWidget);
    pEditor->updateAll();
    pEditor->show(event.getCon());
}

void DIFEditor::onGenerate(const DEvent &event)
{
    LOG_DEBUG("--------------DIFEditor::onGenerate");

    generate();
    destorySubEditors(event.getCon());
    clearSubEditors();
}

void DIFEditor::setReadonly()
{
    DEditor::setReadonly();
 
    //m_ptrDeclFrame->unRegisterEvent(DEvent::Drag);
    m_ptrDeclFrame->unRegisterEvent(DEvent::DnD_Release);

    m_ptrSingletonButton->unRegisterEvent(DEvent::Select);
    m_ptrSingletonButton->unRegisterEvent(DEvent::Hover);
    m_ptrSingletonButton->unRegisterEvent(DEvent::PassingOut);

    for (IFWidgetsIt it = m_ifWidgets.begin(); it != m_ifWidgets.end(); ++it) {
        it->get()->unRegisterEvent(DEvent::DnD_Start);
        it->get()->unRegisterEvent(DEvent::Activate);
        it->get()->unRegisterEvent(DEvent::Delete);
    }
}

void DIFEditor::saveDeclInfo()
{
    duke_media_compound_interface* pIfMedia = dynamic_cast<duke_media_compound_interface *>(m_ptr);
    if (NULL == pIfMedia)
        return;
    // clear declarations
    pIfMedia->clear_declaration();

    for (IFWidgetsIt it = m_ifWidgets.begin(); it != m_ifWidgets.end(); ++it) {
        DWidget * pDeclWidget = it->get();
        if(pDeclWidget == NULL)
            continue;

        duke_media_handle hdecl = pDeclWidget->getMediaHandle();
        if (hdecl == duke_media_handle_null)
            continue;

        pIfMedia->add_declaration(hdecl);
    }
}

void DIFEditor::generateSubItems()
{
//    for (IFWidgetsIt it = m_ifWidgets.begin(); it != m_ifWidgets.end(); ++it) {
//        if (it->get()) {
//            duke_media_handle newh = duke_media_handle_null;
//            DEditor * pEditor = findSubEditorByWidget(it->get());
//
//            // current widget have the subEditor and subEditor contain Media information
//            if (pEditor && pEditor->isModified() && pEditor->getMedia() 
//                    && (pEditor->getMedia()->generate(getApplication()->username(), newh))
//                    && (newh != duke_media_handle_null)) {
//                it->get()->setMediaByHandle(newh);
//                pEditor->generateSubItems();
//            } else if ( it->get()->getMedia()
//                    && (duke_media_get_handle_status(getApplication()->username(),
//                            it->get()->getMediaHandle()) == Edit)
//                    && it->get()->getMedia()->generate(getApplication()->username(), newh) 
//                    && newh != duke_media_handle_null) {
//                createSubEditor(it->get())->generateSubItems();
//                it->get()->setMediaByHandle(newh);
//            }
//        }
//    }
}

duke_media_handle DIFEditor::generate()
{
    //if current interface already have been generated, just return.
    if (e_handle_core == get_media_handle_status(m_handle))
    {
        LOG_ERROR("This object already have been generated");
        return m_handle;        
    }

    // check if name is empty
    if (m_dukeName.empty())
    {
        LOG_ERROR("The interface name is empty");
        return m_handle;
    }
    // check if new decl is added
    if (m_ifWidgets.empty())
    {
        LOG_ERROR("The interface needs at least one declartion");
        return m_handle;
    }


    //DEditor::generate();

    duke_media_compound_interface* pIfMedia = dynamic_cast<duke_media_compound_interface *>(m_ptr);
    if (NULL == pIfMedia)
        return duke_media_handle_null;

    duke_media_handle newh = duke_media_handle_null;
    pIfMedia->set_singleton(m_isSingleton);

    saveDeclInfo();
    
    // compile
    nb_id_t new_id;
    std::map<int, nb_id_t> idx_id_map;

    if(pIfMedia->compile(getApplication()->username(), new_id, idx_id_map))
    {
        LOG_INFO("Generate the Interface and subItems successful.");

        // save the generated id to warehouse
        newh = new_id;
        save_generated_handle(newh, getApplication()->username());

        return newh;            
    }

    LOG_INFO("It is not a valid Interface, could not generate Object!");
    return duke_media_handle_null;
}

void DIFEditor::onSelectSingleton(const DEvent& event)
{
    // change the exception image and change the state 
    if (m_isSingleton) {
        DImage img;
        img.load(getResPath() + IFEditor_NonSingletonImage_FileName);
        img.setXScale(DImage::Stretch);
        img.setYScale(DImage::Stretch);
        img.setRelation(DImage::Disrelated);
        DImage selImg;
        selImg.load(getResPath() + IFEditor_NonSingletonSelImage_FileName);
        selImg.setXScale(DImage::Stretch);
        selImg.setYScale(DImage::Stretch);
        selImg.setRelation(DImage::Disrelated);

        m_ptrSingletonButton->setImage(img);
        m_ptrSingletonButton->setSelImage(selImg);
        m_isSingleton = false;
    } else {
        DImage img;
        img.load(getResPath() + IFEditor_SingletonImage_FileName);
        img.setXScale(DImage::Stretch);
        img.setYScale(DImage::Stretch);
        img.setRelation(DImage::Disrelated);
        DImage selImg;
        selImg.load(getResPath() + IFEditor_SingletonSelImage_FileName);
        selImg.setXScale(DImage::Stretch);
        selImg.setYScale(DImage::Stretch);
        selImg.setRelation(DImage::Disrelated);

        m_ptrSingletonButton->setImage(img);
        m_ptrSingletonButton->setSelImage(selImg);
        m_isSingleton = true;
    }
    m_ptrSingletonButton->setSelected(true);

    // set dirty
    m_isModified = true;

    updateAll();
    repaint(event.getCon());

    //synchronize
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}


void DIFEditor::onHoverSingleton(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);
    if (!pButton)
        return;

    pButton->setSelected(true);
    pButton->updateAll();
    pButton->repaint(event.getCon());
}

void DIFEditor::onPassingOutSingleton(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);
    if (!pButton)
        return;

    pButton->setSelected(false);
    pButton->updateAll();
    pButton->repaint(event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
