/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DFRAME_H
#define DFRAME_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_dwidget.h"
#include "is_drect.h"
#include "is_dtool.h"

class DFrameCell;

class DFrame : public DWidget {
public:
    DFrame(DWidget *parent = 0, WFlags f = 0);
    virtual ~DFrame();

    enum Shape {
        NoFrame	= 0,		// no frame
        Panel	= 0x0001,	// rectangular panel
        Box	= 0x0002,	// draw a box around its contents
    };

    //Get & Set operation
    int frameStyle() const;
    virtual void setFrameStyle(Shape);
    int frameWidth() const;
    DRect frameRect() const;
    DRect &rframeRect();
    virtual void setFrameRect(const DRect &);
    int margin() const;
    virtual void setMargin(int);
    DColor frameBorderColor() const;
    virtual void setFrameBorderColor(const DColor &);
    DPenStroke framePenStroke() const;
    DPenStroke &rframePenStroke();
    virtual void setFramePenStroke(const DPenStroke &);    
    bool autoFill() const;
    virtual void setAutoFill(bool fill);

    //calculate the content rect according to geometry and frameWidth information
    DRect contentsRect() const;

    //Event handle
    virtual bool event(DEvent *);
    void onPassingInEvent(const DEvent& rEvent);
    void onPassingOutEvent(const DEvent& rEvent);

protected:
    DFrame(DFrameCell &dd, DWidget* parent = 0, WFlags f = 0);

private:
    void updateFrameWidth();
    DRect m_frect; // by default, it is equivalent to the widget rectangle
    int m_fstyle;
    int m_fwidth;
    int m_margin;
    bool m_autoFill;
    DColor m_frameBorderColor;
    DPenStroke m_penStroke;    

    D_DECLARE_CELL(DFrame)
};

/***************************************************************************
 * DFrame inline functions
 **************************************************************************/
inline int DFrame::frameStyle() const
{ return m_fstyle; }

inline int DFrame::frameWidth() const
{ return m_fwidth; }

inline int DFrame::margin() const
{ return m_margin; }

inline bool DFrame::autoFill() const
{ return m_autoFill; }


class DFrameCell : public DWidgetCell {
public:
    DFrameCell();
    virtual ~DFrameCell();

    void init();
    virtual void update();

    virtual void onPassingInEvent(const is_response_call& response_call);

private:
    D_DECLARE_PUBLIC(DFrame)
};

typedef std::tr1::shared_ptr<DFrame>  DFramePtr;
typedef std::tr1::shared_ptr<DFrameCell>  DFrameCellPtr;

const std::string DFrame_ObjName("DFrame_Object");

#endif //DFRAME_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
