/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii
**
****************************************************************************/

#ifndef DFUNC_H
#define DFUNC_H

// Boost header files
#include <boost/tr1/memory.hpp>
// Duke header files
#include "is_dwidget.h"
#include "is_dport.h"
#include "is_dedge.h"
////#include "media/duke_media_header.h"

// output port
typedef std::vector<DEdgePtr> EItems;
typedef std::vector<DEdgePtr>::iterator EIt;
typedef std::vector<DEdgePtr>::size_type EIdx;
typedef std::pair<DPortPtr, EItems> OutPEPair;
typedef std::vector<OutPEPair> OutPEItems;
typedef std::vector<OutPEPair>::iterator OutPEItemIt;
typedef std::vector<OutPEPair>::size_type OutPEItemIdx;

// input port
//typedef std::pair<DPortPtr, DEdgePtr> InPEPair;
typedef std::pair<DPortPtr, EItems> InPEPair;
typedef std::vector<InPEPair> InPEItems;
typedef std::vector<InPEPair>::iterator InPEItemIt;
typedef std::vector<InPEPair>::size_type InPEItemIdx;


class DFuncCell; 

class DFunc : public DWidget {
public:
    DFunc(const std::string &text, 
            const unsigned int inNum = 2,
            const unsigned int outNum = 1,
            DWidget *parent = 0,
            WFlags f = 0); 

    DFunc(const duke_media_handle &h, 
            DWidget *parent = 0,
            WFlags f = 0); 

    DFunc(const duke_media_handle &h, 
            const duke_media_handle& hOwnerIf,
            DWidget *parent = 0,
            WFlags f = 0); 

    //caution: only for reconversion of duke_media_declare_expanded
    DFunc(const duke_media_handle &h,
        const duke_media_handle& hOwnerIf,
        const dukeid_vector& iport,
        const dukeid_vector& oport,
        DWidget *parent = 0,
        WFlags f = 0);

    virtual ~DFunc();

    // Set and Get
    void setText(const std::string &text) {
        m_text = text;
    }
    std::string text() const {
        return m_text;
    }

    // Manage body
    void setBodyColor(const DColor &);
    DColor bodyColor() const;

    // Manage ports in the function
    void insertPorts(int inNum, int outNum);
    bool insertPorts(int inNum, int outNum, int color);
    duke_media_handle getFuncIf();
    //void insertTimePorts();
    void deleteInPort(InPEItemIdx idx);
    void deleteOutPort(OutPEItemIdx idx);
    void clearAllPorts();
    void setMediaForInPort(InPEItemIdx idx, const duke_media_handle & hif); 
    void setMediaForOutPort(OutPEItemIdx idx, const duke_media_handle & hif);
    int getIndexByPort(DPort* pPort);
    OutPEItems getOutPorts();
    InPEItems getInPorts();
    size_t inPortsSize();
    size_t outPortsSize();
    bool checkInPortsLinked();

    // Manage edges linked with ports
    bool deleteEdgeFromOutPort(DPort *pOutPort, DEdge *pEdge); 
    //bool deleteEdgeFromInPort(DPort *pInPort);
    bool deleteEdgeFromInPort(DPort *pInPort, DEdge *pEdge);
    void clearEdgesFromOutPort(DPort *pOutPort);
    void clearEdgesFromInPort(DPort* pInPort);
    void clearAllEdges();
    DEdgePtr getSuspendEdge(DPort *pOutPort);
    EItems getEdgesFromOutPort(DPort *pOutPort);
    //DEdgePtr getEdgeFromInPort(DPort *pInPort);
    EItems getEdgeFromInPort(DPort *pInPort);
    DEdgePtr getEdgeFromFirstPort();
    duke_media_handle getObjInterface();
    void updateEdgesPos();
    void setEdgeToInPort(DEdgePtr ptrE, int idx);
    void setEdgeToInPort(DEdgePtr ptrE, DPort *pInPort);
    DEdgePtr createEdge(DPort* pOutPort);
    void connect(OutPEItemIdx outIdx, DFunc* pConnFunc, InPEItemIdx inIdx);
    void connect(DPort* pOutPort, DFunc* pConnFunc, InPEItemIdx inIdx);
    void connect(OutPEItemIdx outIdx, DPort* pInPort);

    //check whether the func can move to the set pos
    bool checkPos(const DPoint& rPoint, int amendLength);

    // Event handle
    void onEnlargeFunc(const DEvent &rEvent);
    void onShrinkFunc(const DEvent &rEvent);
    void onOutPortDnDStart(const DEvent &rEvent);
    void onDnDRelease(const DEvent &rEvent);
    void onInPortDnDRelease(const DEvent &rEvent); 
    void onPortPassingIn(const DEvent &rEvent);
    void onPortPassingOut(const DEvent &rEvent);
    void onFuncDestroy(const DEvent &rEvent);
    void onPortHover(const DEvent &rEvent);
    void onFocusFunc(const DEvent &rEvent);
    void onBlurFunc(const DEvent &rEvent);

    // Init / update
    void initFuncMedia();
    void initFuncView();
    void updateFuncView();
    
    // owner interface
    duke_media_handle getOwnerIf() const { return m_ownerIf; }

private:
    std::string m_text;
    DRect m_body;
    InPEItems m_inPEs;
    OutPEItems m_outPEs;
    duke_media_handle m_ownerIf;//this func's owner interface

    D_DECLARE_CELL(DFunc)
};

class DFuncCell : public DWidgetCell {
public:
    DFuncCell();
    virtual ~DFuncCell();

    void init();
    void update();

private:
    D_DECLARE_PUBLIC(DFunc)
};

typedef std::tr1::shared_ptr<DFunc> DFuncPtr;
typedef std::tr1::shared_ptr<DFuncCell> DFuncCellPtr;

const int FUNC_PORT_HEIGHT = 3000;  // relative value
const int FUNC_PORT_WIDTH = 300;    // absolute value
const int FUNC_PORT_BW_RATIO = 2;   // blank/width
const DColor FUNC_DEFAULT_BODY_COLOR(250, 230, 55);
const DColor DFunc_in_color(0, 100, 0);
const DColor DFunc_in_color_high(0, 255 ,0);
const DColor DFunc_out_color(0, 41, 166);
const DColor DFunc_out_color_high(0, 0, 255);
const int FUNC_DEFAULT_DISPLAY_ORDER = 10;
const int FUNC_PORT_DISPLAY_ORDER = 20;
const int FUNC_EDGE_DISPLAY_ORDER = 30;

const DColor DTime_color(0, 180, 180);
const DColor DTime_color_high(0, 255 ,0);

const std::string Func_ObjName("Function");


#endif // DFUNC_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
