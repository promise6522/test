/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Yinlii 
**
****************************************************************************/
#include "is_dapplication.h"
#include "is_dobjicon.h"
#include <iterator>

const int OBJICON_DEFAULT_DISPLAY_ORDER = 10;
const int OBJICON_PORT_DISPLAY_ORDER = 10;
const int OBJICON_IMAGE_DISPLAY_ORDER = 20;
const int OBJICON_EDGE_DISPLAY_ORDER = 30;

DObjIcon::DObjIcon(DWidget *parent /* = 0 */, WFlags f /* =0 */)
    : DWidget(*new DObjIconCell, parent, f)
{
    setObjectName(ObjIcon_ObjName);

    initObjView(); 
    initObjMedia();

    d_func()->init();
}

DObjIcon::DObjIcon(const std::string &text, 
                   const DImage & img, 
                   DWidget * parent /* = 0 */, 
                   WFlags f /* = 0 */)
: DWidget(*new DObjIconCell, parent, f)
{
    setObjectName("");
    setTextLabel(text);
    setImageEx(img);

    initObjView(); 
    //initObjMedia();
    d_func()->init();

}

DObjIcon::DObjIcon(const std::string &text, 
                   const DImage & img,
                   const duke_media_handle & h_obj,
                   DWidget * parent /* = 0 */, 
                   WFlags f /* = 0 */)
    : DWidget(*new DObjIconCell, parent, f)
{
    setObjectName(ObjIcon_ObjName);
    setMediaByHandle(h_obj);
    setTextLabel(text);
    setImageEx(img);

    initObjView();
    initObjMedia();
    d_func()->init();
}

DObjIcon::~DObjIcon()
{
}

void DObjIcon::initObjMedia()
{
    assert(m_ptr);
    assert(m_ptr->is_object() 
		|| m_ptr->is_storage() 
		|| m_ptr->is_anchor() 
		|| m_ptr->is_object_container_des() 
		|| m_ptr->is_access());
    assert(NULL != m_ptrOutPort.get()); 

    duke_media_handle hif;

    if(m_ptr->is_object() && !m_ptr->is_access())
    {
        duke_media_get_interface_by_object(getMediaHandle(), hif); 
        if(hif.is_interface_array())
            dynamic_cast<duke_media_array *>(m_ptr)->get_compound_interface(hif);
    }
    else if(m_ptr->is_storage())
    {
        dynamic_cast<duke_media_storage *>(m_ptr)->get_interface(hif);
    }
    else if(m_ptr->is_anchor())
    {
        dynamic_cast<duke_media_anchor *>(m_ptr)->get_interface(hif);
    }
    else if(m_ptr->is_object_container_des())
    {
        dynamic_cast<duke_media_container *>(m_ptr)->get_interface(hif);
    }
    else if(m_ptr->is_access())
    {
        dynamic_cast<duke_media_access *>(m_ptr)->get_interface(hif);
    }
    else
    {
        assert(!"Unsupport type. ");        
    }    

    m_ptrOutPort->setMediaByHandle(hif);
}

void DObjIcon::reloadObjMedia()
{
    setMediaByHandle(m_handle);
    
    duke_media_handle hif;
    if (m_ptr->is_object() && NULL != m_ptrOutPort.get())
    {
        duke_media_get_interface_by_object(getMediaHandle(), hif); 

        if (hif.is_interface_array())
            dynamic_cast<duke_media_array *>(m_ptr)->get_compound_interface(hif);

        m_ptrOutPort->setMediaByHandle(hif);
    }
}

void DObjIcon::initObjView()
{
    setFocusAttr(true);
    registerEvent(DEvent::Delete);
    setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DObjIcon::onDestroy));
    registerEvent(DEvent::DnD_Release);
    setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DObjIcon::onBodyDnDRelease));
    registerEvent(DEvent::DnD_Start, true);
    //registerEvent(DEvent::Drag, true);
    registerEvent(DEvent::Moving);
    registerEvent(DEvent::Hover, true);
    registerEvent(DEvent::PassingOut, true);
    registerEvent(DEvent::Activate, true);

    // Init the port of object 
    m_ptrOutPort.reset(new(std::nothrow) DPort(this));
    assert(m_ptrOutPort.get() != NULL);
    m_ptrOutPort->setDirection(DPort::Up);
    m_ptrOutPort->setBackgroundColor(Duke_Transparent_Color);
    m_ptrOutPort->registerEvent(DEvent::DnD_Start);
    m_ptrOutPort->setEventRoutine(DEvent::DnD_Start,
            this,
            static_cast<EventRoutine>(&DObjIcon::onOutPortDnDStart));
    m_ptrOutPort->registerEvent(DEvent::DnD_Release);
    m_ptrOutPort->setEventRoutine(DEvent::DnD_Release,
            this,
            static_cast<EventRoutine>(&DObjIcon::onOutPortDnDRelease));
    m_ptrOutPort->setDisplayOrder(OBJICON_PORT_DISPLAY_ORDER);
    m_ptrOutPort->setGeometry(-MAX_COORD/4, 0, MAX_COORD/2, MAX_COORD/2);

    // Init object
    if (m_ptrImageEx) {
        // Register events for object
        m_ptrImageEx->setFocusAttr(true);
        m_ptrImageEx->registerEvent(DEvent::DnD_Start, true);
        //m_ptrImageEx->registerEvent(DEvent::Drag, true);
        m_ptrImageEx->registerEvent(DEvent::Delete, true);
        m_ptrImageEx->registerEvent(DEvent::Moving);
        m_ptrImageEx->registerEvent(DEvent::DnD_Release, true);
        m_ptrImageEx->registerEvent(DEvent::Hover, true);
        m_ptrImageEx->registerEvent(DEvent::PassingOut, true);
        m_ptrImageEx->registerEvent(DEvent::Activate, true);
             
        // Set the default order of object 
        m_ptrImageEx->setDisplayOrder(OBJICON_IMAGE_DISPLAY_ORDER);
    }

    // Init the label 
    if (m_ptrTextLabel)
    {
        m_ptrTextLabel->setAlignment(AlignCenter);
        m_ptrTextLabel->setTextColor(DColor(255, 0 , 0));
        m_ptrTextLabel->setBackgroundColor(Duke_Transparent_Color);
        m_ptrTextLabel->setFrameBorderColor(Duke_Transparent_Color);
        m_ptrTextLabel->setGeometry(-MAX_COORD/2,
                                    MAX_COORD/2,
                                    MAX_COORD,
                                    MAX_COORD/4);
        m_ptrTextLabel->setDisplayOrder(OBJICON_DEFAULT_DISPLAY_ORDER);
    }
}

std::string DObjIcon::textContent() const
{
    if (m_ptrTextLabel)
        return m_ptrTextLabel->content();

    return std::string();
}

void DObjIcon::setTextLabel(const std::string &text)
{
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(pParent != NULL);

    m_ptrTextLabel.reset(new(std::nothrow) DLabel(text, pParent));
    assert(m_ptrTextLabel.get() != NULL);
}

void DObjIcon::setTextContent(const std::string &text)
{
    if (m_ptrTextLabel)
        m_ptrTextLabel->setContent(text);
}

void DObjIcon::setTextRect(int x, int y, int w, int h)
{
    if (m_ptrTextLabel)
        m_ptrTextLabel->setGeometry(x, y, w, h);
}

DLabelPtr DObjIcon::textLabel() const
{
    if (m_ptrTextLabel)
        return m_ptrTextLabel;

    return DLabelPtr();
}
void DObjIcon::deleteTextLabel()
{
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    if (NULL != pParent && m_ptrTextLabel)
        pParent->detachChildWidget(m_ptrTextLabel.get());
}

DRect DObjIcon::imageGeometry()
{
	DRect rect1 = geometry();
	DRect rect2 = m_ptrImageEx->geometry();
	return DRect(rect1.x() + rect2.x()/MAX_COORD,
                 rect2.y() + rect2.y()/MAX_COORD,
                 rect1.width()*rect2.width()/MAX_COORD,
                 rect1.height()*rect2.height()/MAX_COORD);
}

DImageEx * DObjIcon::imageEx() const
{ 
    return m_ptrImageEx.get();
}

void DObjIcon::setImageEx(const DImage &img)
{
    m_ptrImageEx.reset(new(std::nothrow) DImageEx(img, this));
    assert(m_ptrImageEx.get() != NULL);
}

void DObjIcon::setImage(const DImage &img)
{
    if(m_ptrImageEx)
    {        
        m_ptrImageEx->setImage(img);
    }
}

void DObjIcon::deleteOutPort()
{
    if (!m_ptrOutPort)
        return;

    for (EIt eIt = m_outEdges.begin(); eIt != m_outEdges.end(); ++eIt) {
        if (NULL == eIt->get())
            continue;

        // Delete the edge from input port
        if (NULL != eIt->get()->targetWidget()) {
            DPort * pTargetPort = dynamic_cast<DPort *>(eIt->get()->targetWidget()); 

            if (NULL != pTargetPort) {
	        DFunc * pParentFunc = dynamic_cast<DFunc *>(pTargetPort->parent());
                assert(NULL != pParentFunc);
                pParentFunc->deleteEdgeFromInPort(pTargetPort, eIt->get());
            } else { 
                DObjIcon * pObj = dynamic_cast<DObjIcon *>(eIt->get()->targetWidget());
                if (NULL != pObj)
                    pObj->deleteInEdge();
            }
        }

        // Delete the edge from current output port
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        assert(NULL != pParent);
        pParent->detachChildWidget(eIt->get());
    }

    m_outEdges.clear();

    detachChildWidget(m_ptrOutPort.get());
}
void DObjIcon::updateEdgePos()
{
    if (!m_ptrOutPort) 
        return;

    DPoint eP;
    eP.setX(geometry().x() + geometry().width()/2);
    eP.setY(geometry().y() + geometry().height()/2);

    // output edges
    for (EIt e_it = m_outEdges.begin(); e_it != m_outEdges.end(); e_it++)
    {
        if (NULL == e_it->get())
            continue;
        e_it->get()->setSourceParentCoord(eP); 
    }

    // input edge
    if (m_ptrInEdge)
    {
        m_ptrInEdge->setTargetParentCoord(eP); 
    }

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(NULL != pParent);
    pParent->updateAll();
}

DEdgePtr DObjIcon::createEdge()
{
    if (!m_ptrOutPort)
        return DEdgePtr();

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(pParent != NULL);

    DEdgePtr eItem(new(std::nothrow) DEdge(pParent));
    assert(eItem);

    DRect objRect = geometry();
    DRect imageRect = m_ptrImageEx->geometry();
    int eX = objRect.x() + ((imageRect.x() + imageRect.width()/2) * objRect.width())/10000;
    int eY = objRect.y() + ((imageRect.y() + imageRect.height()*7/8) * objRect.height())/10000;
    DPoint eP(eX, eY);
    eItem->initGeometry(eX, eY, 200, 200);
    eItem->setSourceParentCoord(eP);
    eItem->setSourceWidget(m_ptrOutPort.get());
    eItem->setDisplayOrder(OBJICON_EDGE_DISPLAY_ORDER);
    eItem->registerEvent(DEvent::DnD_Start);
    m_outEdges.push_back(eItem);
    
    return eItem;
}

void DObjIcon::deleteOutEdge(DEdge *pEdge)
{
    if (!m_ptrOutPort || NULL == pEdge)
        return;

    for (EIt eIt = m_outEdges.begin(); eIt != m_outEdges.end(); ++eIt) {
        if (pEdge != eIt->get())
            continue;

        // Delete the edge from the relative func
        if (NULL != pEdge->targetWidget()) 
        {
            DPort * pTargetPort = dynamic_cast<DPort *>(pEdge->targetWidget()); 
            assert(NULL != pTargetPort);
	        DFunc * pParentFunc = dynamic_cast<DFunc *>(pTargetPort->parent()); 
            assert(NULL != pParentFunc);

            pParentFunc->deleteEdgeFromInPort(pTargetPort, pEdge);
        }

        // Delete the edge from current objiconc
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        assert(NULL != pParent);
        pParent->detachChildWidget(pEdge);
        eIt->reset();
        // Reset the shared_ptr of edge in source function
        m_outEdges.erase(eIt);

        break;
    }
}

void DObjIcon::clearAllEdges()
{
    for (EIt eIt = m_outEdges.begin(); eIt != m_outEdges.end(); ++eIt) {
        if (NULL == eIt->get())  
            continue;

        // Delete the edge from input port
        if (NULL != eIt->get()->targetWidget()) 
        {
            DPort * pTargetPort = dynamic_cast<DPort *>(eIt->get()->targetWidget()); 
            assert(NULL != pTargetPort);

            DFunc * pParentFunc = dynamic_cast<DFunc *>(pTargetPort->parent()); 
            assert(pParentFunc);

            pParentFunc->deleteEdgeFromInPort(pTargetPort, eIt->get());
        }

        // Delete the edge from current output port
        DWidget * pParent = dynamic_cast<DWidget *>(parent());
        assert(NULL != pParent);
        pParent->detachChildWidget(eIt->get());
    }        

    m_outEdges.clear();

    if (m_ptrInEdge) {
        DPort * pSourcePort = dynamic_cast<DPort*>(m_ptrInEdge->sourceWidget());
        assert(NULL != pSourcePort); 

        // if the source port belongs to function.
        DFunc* pFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
        if (NULL != pFunc) {
            pFunc->deleteEdgeFromOutPort(pSourcePort, m_ptrInEdge.get());
            return;
        } 

        // if the source port belongs to object.
        DObjIcon * pObj = dynamic_cast<DObjIcon *>(pSourcePort->parent());
        if (NULL != pObj) {
            pObj->deleteOutEdge(m_ptrInEdge.get());
            return;
        }
    }
}

DEdgePtr DObjIcon::getSuspendEdge()
{
    if (NULL == m_ptrOutPort) 
        return DEdgePtr(); 

    for (EIt eIt = m_outEdges.begin(); 
	    eIt != m_outEdges.end(); 
	    ++eIt) {
	if (NULL != eIt->get() 
		&& NULL == eIt->get()->targetWidget())  
            return (*eIt);
    } 

    return DEdgePtr();
}

EItems DObjIcon::outEdges() 
{
    return m_outEdges;
}

void DObjIcon::setInEdge(DEdgePtr ptrEdge)
{
    DPort * pSourcePort = dynamic_cast<DPort *>(ptrEdge->sourceWidget());
    assert(NULL != pSourcePort);

    DFunc * pSrcFunc = (dynamic_cast<DFunc *>(pSourcePort->parent()));
    assert(NULL != pSrcFunc);

    if (m_ptrInEdge) {
        pSrcFunc->deleteEdgeFromOutPort(pSourcePort, ptrEdge.get());
        return;
    }

    // Check the target coordinate of current edge 
    // The coordinate of the target  should >= that of the source for ever 
    int targetY = geometryY();
    DRect srcFuncRect = pSrcFunc->geometry();
    int sourceY = pSrcFunc->geometryY() + (pSourcePort->geometryY() * pSrcFunc->geometry().height())/10000;

    if (targetY <= sourceY) {
        pSrcFunc->deleteEdgeFromOutPort(pSourcePort, ptrEdge.get());
        return;
    }

    m_ptrInEdge = ptrEdge;

    // Set the target coordate
    int eX = geometryX() + geometry().width()/2;
    int eY = geometryY() + 10; 
    DPoint eP(eX, eY);
    m_ptrInEdge->setTargetParentCoord(eP);
    m_ptrInEdge->setTargetWidget(this);
}

void DObjIcon::deleteInEdge()
{
    LOG_DEBUG("DObjIcon::deleteInEdge()");
    if (m_ptrInEdge)
        m_ptrInEdge.reset();
}

bool DObjIcon::checkPos(const DPoint &p, int len)
{
    // check the target widget current edge links to
    for (EIt eIt = m_outEdges.begin(); eIt != m_outEdges.end(); eIt++) {
        if (NULL == eIt->get())
            continue;

        if (NULL == eIt->get()->targetWidget()) 
            continue;

        // Compare with the relative func linked by the same edge.
        DFunc* pTargetFunc = dynamic_cast<DFunc *>(eIt->get()->targetWidget()->parent());
        if (NULL != pTargetFunc) {
            if (pTargetFunc->geometryY() <= p.y() + len)
                return false;
        } 
    }

    // check the source widget current edge links to
    if (m_ptrInEdge && NULL != m_ptrInEdge->sourceWidget()) {
        DWidget* pParentWidget = dynamic_cast<DWidget *>(m_ptrInEdge->sourceWidget()->parent());
        if (NULL != pParentWidget) {
            if (pParentWidget->geometryY() + len >= p.y())
                return false;
        }
    }
    
    return true;
}

void DObjIcon::connect(DFunc *pConnFunc, unsigned int inIdx)
{
    if (NULL == pConnFunc)
        return;

    if (inIdx >= pConnFunc->inPortsSize())
        return;

    // create edge and set its source coordinate
    DEdgePtr currEdge;
    if (m_ptr->is_object_array()) {
	duke_media_array * ptrMediaArray = dynamic_cast<duke_media_array *>(m_ptr);
	duke_media_handle_vector types;
	if (NULL != ptrMediaArray 
		&& ptrMediaArray->get_type(types)
		&& 0 < types.size())
	    currEdge = createEdge();
	else 
	    return;
    } else 
	currEdge = createEdge();

    if (!currEdge) 
        return; 

    // set target coordinate of current edge
    pConnFunc->setEdgeToInPort(currEdge, inIdx);
}

void DObjIcon::connect(DPort *pConnInPort)
{
    if (NULL == pConnInPort)
        return;

    DFunc * pConnFunc = dynamic_cast<DFunc *>(pConnInPort->parent());
    if (NULL == pConnFunc)
        return;

    // create edge and set its source coordinate
    DEdgePtr currEdge;
    if (m_ptr->is_object_array()) {
	duke_media_array * ptrMediaArray = dynamic_cast<duke_media_array *>(m_ptr);
	duke_media_handle_vector types;
	if (NULL != ptrMediaArray 
		&& ptrMediaArray->get_type(types)
		&& 0 < types.size())
	    currEdge = createEdge();
	else 
	    return;
    } else 
	currEdge = createEdge();

    if (!currEdge) 
        return; 

    // set target coordinate of current edge
    pConnFunc->setEdgeToInPort(currEdge, pConnInPort);
}

/***************************************************************************
 * DObjIcon event handle functions
 **************************************************************************/
void DObjIcon::onOutPortDnDStart(const DEvent &rEvent)
{
    LOG_DEBUG("-------------Port of ObjIcon DnD Start.");

    const std::vector<DPath>& currPortPath = rEvent.getEventPath();

    DPort * pSourcePort = dynamic_cast<DPort *>(findChild(currPortPath[0]));
    if(NULL == pSourcePort || pSourcePort != m_ptrOutPort.get())
        return;

    // create a new edge
    if (m_ptr->is_object_array()) {
	duke_media_array * ptrMediaArray = dynamic_cast<duke_media_array *>(m_ptr);
	duke_media_handle_vector types;
	if (NULL != ptrMediaArray 
		&& ptrMediaArray->get_type(types)
		&& 0 < types.size())
	    createEdge();
	else 
	    return;
    } else 
	createEdge();

    // Create a edge,if current port is not linked by any edge.
    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(pParent != NULL);
    pParent->updateAll();
    pParent->repaint(rEvent.getCon());
}

void DObjIcon::onOutPortDnDRelease(const DEvent &rEvent)
{
    LOG_DEBUG("-------------Output Port of ObjIcon Released.");

    // Get the path of current widgets 
    const std::vector<DPath>& eventPath = rEvent.getEventPath();

    DPort * pSourcePort = dynamic_cast<DPort *>(getApplication()->top()->findChild(eventPath[1]));
    if (NULL == pSourcePort)
        return;

    DWidget * pParent = dynamic_cast<DWidget *>(parent());
    assert(NULL != pParent);

    // If the parent of output port is func
    DFunc * pSrcFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
    if (NULL != pSrcFunc) {
        DEdgePtr ptrCurrE = pSrcFunc->getSuspendEdge(pSourcePort);
        if (!ptrCurrE )
            return;

        pSrcFunc->deleteEdgeFromOutPort(pSourcePort, ptrCurrE.get());
        pParent->updateAll();
        pParent->repaint(rEvent.getCon());

        return;
    }

    // If the parent of output port is object
    DObjIcon* pSrcObj = dynamic_cast<DObjIcon* >(pSourcePort->parent());
    if (NULL != pSrcObj) {
        DEdgePtr ptrCurrE = pSrcObj->getSuspendEdge();

        if (!ptrCurrE)
            return;

        pSrcObj->deleteOutEdge(ptrCurrE.get());
        pParent->updateAll();
        pParent->repaint(rEvent.getCon());
        return;
    }
}

void DObjIcon::onDestroy(const DEvent &rEvent)
{
    LOG_DEBUG("-------------ObjIcon Deleted.");
    const std::vector<DPath>& currObjPath = rEvent.getEventPath();

    DObjIcon *pCurrObj = dynamic_cast<DObjIcon *>(findChild(currObjPath[0]));
    if (NULL == pCurrObj) 
        return;

    DWidget * pObjParent = dynamic_cast<DWidget *>(pCurrObj->parent());
    assert(NULL != pObjParent);

    pCurrObj->clearAllEdges();
    pCurrObj->deleteTextLabel();
    pObjParent->detachChildWidget(pCurrObj);

    pObjParent->updateAll();
    pObjParent->repaint(rEvent.getCon());
}

void DObjIcon::onBodyDnDRelease(const DEvent &rEvent)
{
    LOG_DEBUG("-------------Body of object Released.");

    const std::vector<DPath>& eventPath = rEvent.getEventPath();

    DPort * pSourcePort = dynamic_cast<DPort *>(getApplication()->top()->findChild(eventPath[1]));
    if (NULL == pSourcePort)
        return;

    DFunc * pSrcFunc = dynamic_cast<DFunc *>(pSourcePort->parent());
    if (NULL != pSrcFunc) {
        DEdgePtr ptrCurrE = pSrcFunc->getSuspendEdge(pSourcePort);
        if (!ptrCurrE ) 
            return; 

        pSrcFunc->deleteEdgeFromOutPort(pSourcePort, ptrCurrE.get());

        dynamic_cast<DWidget *>(pSrcFunc->parent())->updateAll();
        dynamic_cast<DWidget *>(pSrcFunc->parent())->repaint(rEvent.getCon());

        return;
    }

    DObjIcon * pSrcObj = dynamic_cast<DObjIcon *>(pSourcePort->parent());
    if (NULL != pSrcObj){ 
        DEdgePtr ptrCurrE = pSrcObj->getSuspendEdge();
        if (!ptrCurrE ) 
            return; 

        pSrcObj->deleteOutEdge(ptrCurrE.get());

        dynamic_cast<DWidget *>(pSrcObj->parent())->updateAll();
        dynamic_cast<DWidget *>(pSrcObj->parent())->repaint(rEvent.getCon());
    }
}

/***************************************************************************
 * DObjIconCell member functions
 **************************************************************************/
DObjIconCell::DObjIconCell()
{
}

DObjIconCell::~DObjIconCell()
{
}

void DObjIconCell::init()
{
    DObjIcon *q = q_func();

    TPlacement &imgPlace = subNodes[0];
    TPlacement &portPlace = subNodes[1];
    portPlace.referencePoint = TPostionType_Center_Out;
    portPlace.referencePointDerivation = imgPlace.path.node;
    portPlace.relativeValueDerivation = imgPlace.path.node;

    DLabelPtr ptrTextLabel = q->textLabel();
    if (!ptrTextLabel)
	return;

    DLabelCell * pTextCell = dynamic_cast<DLabelCell *>(ptrTextLabel->getCell());
    TPlacement * ptrTextPlace = pTextCell->getPlacement();
    ptrTextPlace->referencePoint = TPostionType_Center_Out;
    ptrTextPlace->referencePointDerivation = m_place->path.node;
    ptrTextPlace->relativeValueDerivation = m_place->path.node;
}

void DObjIconCell::update()
{
    DWidgetCell::update();

    DObjIcon *q = q_func();

    DLabelPtr ptrTextLabel = q->textLabel();
    if (!ptrTextLabel)
	return;

    DLabelCell * pTextCell = dynamic_cast<DLabelCell *>(ptrTextLabel->getCell());
    TPlacement * ptrTextPlace = pTextCell->getPlacement();
    ptrTextPlace->referencePoint = TPostionType_Center_Out;
    ptrTextPlace->referencePointDerivation = m_place->path.node;
    ptrTextPlace->relativeValueDerivation = m_place->path.node;

    m_place->referencePointDerivation.clear(); 
    m_place->relativeValueDerivation.clear();
}

//vim:set tabstop=4 shiftwidth=4 expandtab:
