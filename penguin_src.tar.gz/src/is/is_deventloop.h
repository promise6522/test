/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Haijian Li 
**
****************************************************************************/

#ifndef DEVENTLOOP_H
#define DEVENTLOOP_H

// C++ 98 header files
#include <deque>

// Boost header file
#include <boost/thread.hpp>
#include <boost/thread/condition.hpp>

#include "is_devent.h"
#include "is_dwidget.h"

typedef std::deque<DEvent> vEventQue;
typedef std::deque<DEvent>::iterator eventQueIt;

class DEventLoop {
public:
    DEventLoop(): m_isExit(false)
    { }

    ~DEventLoop()
    { }

public:
    void push_front(const DEvent& event)
    {
        boost::lock_guard<boost::mutex> lock(m_mutex);
        m_vEventDeque.push_front(event);
        m_cond.notify_one();
    }

    void clear()
    {
        boost::lock_guard<boost::mutex> lock(m_mutex);
        m_vEventDeque.clear();
    }

    void exit()
    {
        m_isExit = true;
        m_cond.notify_all();
    }

    bool isEmpty()
    {
        boost::lock_guard<boost::mutex> lock(m_mutex);
        return m_vEventDeque.empty();
    }

    void exec(DWidget& rWidget);

private:
    void eventCompress();
private:
    boost::mutex m_mutex;
    boost::condition m_cond;    
    vEventQue m_vEventDeque;
    bool m_isExit;    
};


#endif  //DEVENTLOOP_H


// vim:set tabstop=4 shiftwidth=4 expandtab:
