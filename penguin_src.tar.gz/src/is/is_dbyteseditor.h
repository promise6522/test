/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/

#ifndef DBYTEEDITOR_H
#define DBYTEEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dmainwin.h"
#include "duke_logic_object_data.h"

class DBytesEditor : public DEditor {
public:
    explicit DBytesEditor(EditorModel model = PanelModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DBytesEditor(const std::string& title,
            EditorModel model = PanelModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DBytesEditor();
   
    void initBytesEditor();
    void initElementFrame();
    void initItemsInBody();

    // Manage widget in the editor
    void adjustPlacement();
    void setElementProperty(DButton* pElementButton);

    void reload();
    // Event handle
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDnDRelease(const DEvent &event);
    void onDeleteChild(const DEvent &event);
    void onSelectChild(const DEvent &event);
    void onGenerate(const DEvent &event);
private:
   void saveDukeData();
private:
    std::string m_dukeBytesData;
    DFramePtr m_ptrElementFrame;
    DButtonPtr m_ptrDataButton;
};

typedef std::tr1::shared_ptr<DBytesEditor>  DBytesEditorPtr;

const std::string BytesEditor_ObjName("Bytes_Editor");

const int BytesEditor_Width = 336;
const int BytesEditor_Heigth = 448;
const int BytesEditor_DeclFrame_W_Pixel = 313;
const int BytesEditor_DeclFrame_W_InBodyFrame = BytesEditor_DeclFrame_W_Pixel * MAX_COORD / BytesEditor_Width;
const int BytesEditor_DeclFrame_X_Pixel = 12;
const int BytesEditor_DeclFrame_X_InBodyFrame = BytesEditor_DeclFrame_X_Pixel * MAX_COORD / BytesEditor_Width;
const int BytesEditor_SingletonBar_X_Pixel = 112;
const int BytesEditor_SingletonBar_X_InBodyFrame = BytesEditor_SingletonBar_X_Pixel * MAX_COORD / BytesEditor_Width;
const int BytesEditor_SingletonBar_W_Pixel = 112;
const int BytesEditor_SingletonBar_W_InBodyFrame = BytesEditor_SingletonBar_W_Pixel * MAX_COORD / BytesEditor_Width;
const int BytesEditor_SingletonBar_H_Pixel = 24;
const int BytesEditor_SingletonBar_H_InMainWin = BytesEditor_SingletonBar_H_Pixel * MAX_COORD / 768;

const std::string BytesEditorItemImage_FileName("object_origin.png");

const int Default_BytesEditor_W_InMainWin = BytesEditor_Width * MAX_COORD / 1366;
const int Default_BytesEditor_H_InMainWin = BytesEditor_Heigth * MAX_COORD / 768;

#endif // DARRAYEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
