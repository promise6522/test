/****************************************************************************
**
** Copyright 2011 Duke Inc.
**
** Author Bruce 
**
****************************************************************************/

#ifndef MAPINTERFACEEDITOR_H
#define MAPINTERFACEEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dmainwin.h"
#include "duke_media_global.h"

typedef std::vector<DWidgetPtr> MapWidgets;
typedef MapWidgets::iterator MapWidgetsIt;
typedef MapWidgets::size_type MapWidgetsIdx;

class DMapInterfaceEditor : public DEditor {
public:
    explicit DMapInterfaceEditor(EditorModel model = PanelModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DMapInterfaceEditor(const std::string& title,
            EditorModel model = PanelModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DMapInterfaceEditor();
   
    void initMapInterfaceEditor();
    void initTypeFrame();
    void initItemsInBody();

    // Manage widget in the editor
    void adjustPlacement();
    virtual void setReadonly();

    void reload();
    // Event handle
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDnDReleaseTypeFrame(const DEvent &event);
    void onSelectChild(const DEvent &event);
    void onGenerate(const DEvent &event);
    void onActivateBtn(const DEvent &event);
private:
   DEditor* createMapInterfaceEditor(DWidget *pSrcWidget);
   DEditor* createArrayInterfaceEditor(DWidget *pSrcWidget);
   void setElementProperty(DButton* pElementButton);
   void saveDukeData();
private:
    DFramePtr m_ptrTypeFrame;
    DButtonPtr m_ptrKeyIFButton;
    DLabelPtr m_ptrKeyIFText;    
    DButtonPtr m_ptrValIFButton;
    DLabelPtr m_ptrValIFText;
    DLabelPtr m_ptrKeyName;
    DLabelPtr m_ptrValName;
};

typedef std::tr1::shared_ptr<DMapInterfaceEditor>  DMapInterfaceEditorPtr;

const std::string MapInterfaceEditor_ObjName("Map_Interface_Editor");
const int MapInterfaceEditor_Row_Height = 2000;
const int MapInterfaceEditor_Col_Items = 5;

const int MapInterfaceEditor_Width = 336;
const int MapInterfaceEditor_Heigth = 448;
const int MapInterfaceEditor_DeclFrame_W_Pixel = 313;
const int MapInterfaceEditor_DeclFrame_W_InBodyFrame = MapInterfaceEditor_DeclFrame_W_Pixel * MAX_COORD / MapInterfaceEditor_Width;
const int MapInterfaceEditor_DeclFrame_X_Pixel = 12;
const int MapInterfaceEditor_DeclFrame_X_InBodyFrame = MapInterfaceEditor_DeclFrame_X_Pixel * MAX_COORD / MapInterfaceEditor_Width;
const int MapInterfaceEditor_SingletonBar_X_Pixel = 112;
const int MapInterfaceEditor_SingletonBar_X_InBodyFrame = MapInterfaceEditor_SingletonBar_X_Pixel * MAX_COORD / MapInterfaceEditor_Width;
const int MapInterfaceEditor_SingletonBar_W_Pixel = 112;
const int MapInterfaceEditor_SingletonBar_W_InBodyFrame = MapInterfaceEditor_SingletonBar_W_Pixel * MAX_COORD / MapInterfaceEditor_Width;
const int MapInterfaceEditor_SingletonBar_H_Pixel = 24;
const int MapInterfaceEditor_SingletonBar_H_InMainWin = MapInterfaceEditor_SingletonBar_H_Pixel * MAX_COORD / 768;

const std::string MapInterfaceEditorItemImage_FileName("object_origin.png");

const int Default_MapInterfaceEditor_W_InMainWin = MapInterfaceEditor_Width * MAX_COORD / 1366;
const int Default_MapInterfaceEditor_H_InMainWin = MapInterfaceEditor_Heigth * MAX_COORD / 1536;

#endif // DARRAYINTERFACEEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
