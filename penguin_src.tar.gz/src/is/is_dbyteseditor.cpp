/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/
//boost header files
#include <boost/algorithm/string.hpp>

#include "is_dbyteseditor.h"
#include "is_ddecleditor.h"
#include "is_dapplication.h"
////#include "media/duke_media_header.h"

DBytesEditor::DBytesEditor(DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */, 
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(model, pMainWin, parent, f)
{
    setObjectName(BytesEditor_ObjName);
    assert(pMainWin != NULL);    
}

DBytesEditor::DBytesEditor(const std::string &title,
        DEditor::EditorModel model,
        DMainWin *pMainWin /* = NULL */,
        DWidget * parent /* = 0 */,
        WFlags f /* = 0 */)
    : DEditor(title, model, pMainWin, parent, f)
{
    setObjectName(BytesEditor_ObjName);
    assert(pMainWin != NULL);
}

DBytesEditor::~DBytesEditor()
{
}

void DBytesEditor::reload()
{
    LOG_DEBUG("DBytesEditor:: reload ......");

    // get name & icon
    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia) {
        releaseMedia();
        return;
    }
    pBytesMedia->get_name(m_dukeName);
    pBytesMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    

    // reload media data
    initItemsInBody();
    return;
}

void DBytesEditor::initBytesEditor()
{
    // get name & icon
    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia) {
        releaseMedia();
        return;
    }
    pBytesMedia->get_name(m_dukeName);
    pBytesMedia->get_icon(m_dukeIcon);
    m_ptrNameEdit->setContent(m_dukeName);    
 
    initElementFrame();
    return;
}

void DBytesEditor::initElementFrame()
{
   /* m_ptrElementFrame.reset(new(std::nothrow) DFrame(
                            static_cast<DWidget *>(getBodyFrame())));
    m_ptrElementFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrElementFrame->setHideProperty(false);
    m_ptrElementFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrElementFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrElementFrame->setAutoFill(false);
    m_ptrElementFrame->setFrameStyle(DFrame::Panel);
    m_ptrElementFrame->registerEvent(DEvent::Drag);
    m_ptrElementFrame->registerEvent(DEvent::DnD_Release);
    m_ptrElementFrame->registerEvent(DEvent::DnD_Start, true);
    m_ptrElementFrame->registerEvent(DEvent::Detail, true);
    m_ptrElementFrame->registerEvent(DEvent::Select, true);
    m_ptrElementFrame->registerEvent(DEvent::Resize_Start, true);
    m_ptrElementFrame->registerEvent(DEvent::Resize_Release, true);
    m_ptrElementFrame->setGeometry(MIN_COORD, 
                                   MIN_COORD, 
                                   MAX_COORD, 
                                   MAX_COORD);
    m_ptrElementFrame->setEventRoutine(DEvent::DnD_Release,
                                       this,
                                       static_cast<EventRoutine>(&DBytesEditor::onDnDRelease));*/

    DFrame* pBodyFrame = getBodyFrame();
    if (NULL != pBodyFrame)
    {
        pBodyFrame->registerEvent(DEvent::DnD_Release);
        pBodyFrame->setEventRoutine(DEvent::DnD_Release,
                                       this,
                                       static_cast<EventRoutine>(&DBytesEditor::onDnDRelease));
    }
    initItemsInBody();
    dumpObjectTree();
    return;
}


void DBytesEditor::initItemsInBody()
{
    if (NULL != m_ptr && !m_ptr->is_object_bytes()) 
    {
        releaseMedia();
        return;
    }
////
    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia)
        return;

    duke_bytes_t dukeBytesData;
    DImage elementImg;
    elementImg.load(getResPath() + BytesEditorItemImage_FileName);
    elementImg.setRelation(DImage::KeepSmall);
    pBytesMedia->get_value(dukeBytesData);

    if (dukeBytesData.m_value.size() > 0)
    {
        DImage elementImg;
        elementImg.load(getResPath() + BytesEditorItemImage_FileName);
        elementImg.setRelation(DImage::KeepSmall);

        m_ptrDataButton.reset(new(std::nothrow) 
                DButton("", elementImg, getBodyFrame()));
        assert(NULL != m_ptrDataButton.get());
        m_ptrDataButton->setGeometry(3000, 3000, 4000, 4000);
        setElementProperty(m_ptrDataButton.get());
    }
    return;
}

void DBytesEditor::adjustPlacement()
{
    DEditor::adjustPlacement();

    // update declaration view gemoetry
  /*  if (NULL != m_ptrElementFrame.get())
        m_ptrElementFrame->setGeometry(MIN_COORD, 
                MIN_COORD, 
                MAX_COORD, 
                MAX_COORD);*/
}

void DBytesEditor::setElementProperty(DButton* pElementButton)
{
    if (NULL == pElementButton)
    {
        return;
    }
    pElementButton->setFocusAttr(true);
    pElementButton->registerEvent(DEvent::Select);
    pElementButton->registerEvent(DEvent::Hover);
    pElementButton->registerEvent(DEvent::PassingOut);
    pElementButton->registerEvent(DEvent::Delete);
    pElementButton->registerEvent(DEvent::DnD_Start);
    pElementButton->setEventRoutine(DEvent::PassingOut,
            this,
            static_cast<EventRoutine>(&DBytesEditor::onPassingOutChild));
    pElementButton->setEventRoutine(DEvent::Hover,
            this,
            static_cast<EventRoutine>(&DBytesEditor::onHoverChild));
    pElementButton->setEventRoutine(DEvent::Delete,
            this,
            static_cast<EventRoutine>(&DBytesEditor::onDeleteChild));
    pElementButton->setEventRoutine(DEvent::Select,
            this,
            static_cast<EventRoutine>(&DBytesEditor::onSelectChild));
    return;
}

void DBytesEditor::saveDukeData()
{
    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia)
        return;

    duke_bytes_t dukeData;
    dukeData.m_length = m_dukeBytesData.size();
    dukeData.m_value = m_dukeBytesData;
    pBytesMedia->set_value(dukeData);
    return;
}

void DBytesEditor::onDnDRelease(const DEvent &event)
{
    LOG_DEBUG("-------------- DBytesEditor::onDnDRelease"); 
    if (NULL != m_ptrDataButton.get())
         return;

    //check if the source path is local
    const std::vector<DPath>& widgetPath = event.getEventPath();
    if(widgetPath[1][0] != -1)
        return;

    const std::vector<DResourceUnit>& resUnits = event.getEventResourceUnit();
    if(resUnits.empty())
        return;

    //only deal with first image resource
    for(size_t i = 0; i < resUnits.size(); ++i)
    {
        const std::vector<uint8_t>& data = resUnits[i].data();
        if (data.size() > 0)
        {
            LOG_DEBUG("Receive : "<<resUnits[i].MIME().m_subType<<" size="<<data.size());            
            m_dukeBytesData = toString(&data[0], data.size());
            DImage elementImg;
            elementImg.load(getResPath() + BytesEditorItemImage_FileName);
            elementImg.setRelation(DImage::KeepSmall);

            m_ptrDataButton.reset(new(std::nothrow) 
                    DButton("", elementImg, getBodyFrame()));
            assert(NULL != m_ptrDataButton.get());
            m_ptrDataButton->setGeometry(3000, 3000, 4000, 4000);
            setElementProperty(m_ptrDataButton.get());

            break;
        }
    }

    saveDukeData();
    m_pMainWin->synchronizeEditors(event.getCon(), this);
    
    // Repaint
    updateAll();
    repaint(event.getCon());
    return;
}

void DBytesEditor::onPassingOutChild(const DEvent &event)
{
    LOG_DEBUG("--------------DBytesEditor::onPassingOutChild");
    getApplication()->tip()->remove(event.getCon());
}

void DBytesEditor::onHoverChild(const DEvent &event)
{
    LOG_DEBUG("--------------DBytesEditor::onHoverChild");
    // Get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0]));
    if (NULL == pSrcWidget)
        return;

    std::string strTip;
    if (pSrcWidget->getMedia() && pSrcWidget->getMedia()->get_name(strTip))
        getApplication()->tip()->add(pSrcWidget, 
                strTip, 
                event.getCon());
    else
        getApplication()->tip()->add(pSrcWidget, 
                pSrcWidget->strPath(),
                event.getCon());
    return;
}

void DBytesEditor::onDeleteChild(const DEvent &event)
{
    LOG_DEBUG("--------------DBytesEditor::onDeleteChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;
   
    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia)
        return;
    if (pSrcWidget == m_ptrDataButton.get())
    {
        DFrame* pBodyFrame = getBodyFrame();
        if (NULL != pBodyFrame)
        {
            pBodyFrame->detachChildWidget(m_ptrDataButton.get());
        }
        m_ptrDataButton.reset();
    }
    m_dukeBytesData = "";
    saveDukeData();
    updateAll();
    repaint(event.getCon());
    return;
}

void DBytesEditor::onSelectChild(const DEvent &event)
{
    LOG_DEBUG("--------------DBytesEditor::onSelectChild");

    const std::vector<DPath>& childPath = event.getEventPath();    
    DWidget* pSrcWidget = dynamic_cast<DWidget*>(findChild(childPath[0])); 
    if (pSrcWidget == NULL)
        return;

    getSelFrame()->setGeometry(pSrcWidget->geometry().left() - 100,
            pSrcWidget->geometry().top() - 100,
            pSrcWidget->geometry().width() + 200,
            pSrcWidget->geometry().height() + 200);
    getSelFrame()->setHideProperty(false);

    updateAll();
    repaint(event.getCon());
}


void DBytesEditor::onGenerate(const DEvent &event)
{
    // save name and icon
    DEditor::onGenerate(event);

    duke_media_bytes *pBytesMedia = dynamic_cast<duke_media_bytes *>(m_ptr);
    if (NULL == pBytesMedia)
        return;

    //add by roger
    duke_media_handle handle;
    //pBytesMedia->generate(getApplication()->username(), handle);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
