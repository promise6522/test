/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "trans_anchor_impl.h"

trans_anchor_impl::trans_anchor_impl(anchor_id_t& anchor_id)
    : anchor_implementation(anchor_id)
{
    func_pair_t func_pair;
    func_pair.declaration_id = nb_id_t(NB_FUNC_INT_ADD);
    func_pair.implementation_id = nb_id_t(NB_FUNC_INT_ADD);
    m_cData.funcs.push_back(func_pair);
}

trans_anchor_impl::trans_anchor_impl()
{
    func_pair_t func_pair;
    func_pair.declaration_id = nb_id_t(NB_FUNC_INT_ADD);
    func_pair.implementation_id = nb_id_t(NB_FUNC_INT_ADD);
    m_cData.funcs.push_back(func_pair);
}

trans_anchor_impl::~trans_anchor_impl()
{
}

void trans_anchor_impl::add()
{
    std::cout<<"1+1 = 2"<<std::endl;
}

void trans_anchor_impl::sub()
{
    std::cout<<"2-1 = 0"<<std::endl;
}

bool trans_anchor_impl::run(call_id_t call_id,
	    const node_invocation_request& input,
	    ac_anchor_helper * pHelper)
{
    switch (input.declaration_id.get_func_type()) {
	case NB_FUNC_INT_ADD:
	    add();
	    break;
	case NB_FUNC_INT_SUB:
	    sub();
	    break;
	default:
	    break;
    }

    return true; 
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
