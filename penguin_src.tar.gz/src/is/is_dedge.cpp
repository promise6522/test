/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author lhj
**
****************************************************************************/

// Duke header files
#include "is_dedge.h"
#include "is_dtool.h"
#include "is_dfunc.h"
#include "is_dobjicon.h"
#include "is_dimpleditor.h"

DEdge::DEdge(DWidget * parent /* = 0 */)
    : DWidget(*new DEdgeCell, parent, 0),
      m_edgeType(DEdge::CurveCubic),
      m_sourcePoint(0, 0),
      m_targetPoint(10000, 10000),
      m_sourceParentCoord(0, 0),
      m_targetParentCoord(0, 0),
      m_pSourceWidget(NULL),
      m_pTargetWidget(NULL),
      m_edgeColor(0, 0, 0)
{
    setFocusAttr(true);
    //registerEvent(DEvent::Drag, true);
    registerEvent(DEvent::DnD_Release, true);

    registerEvent(DEvent::Focus);
    setEventRoutine(DEvent::Focus,
                    this,
                    static_cast<EventRoutine>(&DEdge::onFocusEdge));
    
    registerEvent(DEvent::Blur);
    setEventRoutine(DEvent::Blur,
                    this,
                    static_cast<EventRoutine>(&DEdge::onBlurEdge));
 
    registerEvent(DEvent::Delete);
    setEventRoutine(DEvent::Delete,
                    this,
                    static_cast<EventRoutine>(&DEdge::onDeleteEdge));

    d_func()->init();
}

DEdge::~DEdge()
{
    LOG_DEBUG("=============>Destroy edge");
}

DEdge::EdgeType DEdge::edgeType() const
{
    return m_edgeType; 
}

void DEdge::setEdgeType(EdgeType edgeType)
{
    m_edgeType = edgeType;
}

DColor DEdge::color() const
{
    return m_edgeColor; 
}

void DEdge::setColor(const DColor& color)
{
    m_edgeColor = color;
}

void DEdge::initGeometry(int xCoord, int yCoord, int width, int height)
{
    setGeometry(xCoord, yCoord, width, height);
    m_sourceParentCoord = DPoint(xCoord, yCoord);
    m_targetParentCoord = DPoint(xCoord + width, yCoord + height);
}

DPoint DEdge::sourcePoint() const
{
    return m_sourcePoint;
}

void DEdge::setSourceParentCoord(const DPoint& point)
{
    m_sourceParentCoord = point;
    updateGeometry();
}

DPoint DEdge::targetPoint() const
{
    return m_targetPoint;
}

void DEdge::setTargetParentCoord(const DPoint& point)
{
    m_targetParentCoord = point;
    updateGeometry();
}

void DEdge::updateGeometry()
{
    int xCoord = std::min(m_sourceParentCoord.x(), m_targetParentCoord.x());
    int yCoord = std::min(m_sourceParentCoord.y(), m_targetParentCoord.y());
    int width = abs(m_targetParentCoord.x() - m_sourceParentCoord.x());
    int height = abs(m_targetParentCoord.y() - m_sourceParentCoord.y());
 
    setGeometry(xCoord, yCoord, width, height);
   
    if (xCoord == m_sourceParentCoord.x()) {
        m_sourcePoint.setX(0);
        m_targetPoint.setX(10000);
    }
    else {
        m_sourcePoint.setX(10000);
        m_targetPoint.setX(0);
    }

    if (yCoord == m_sourceParentCoord.y()) {
        m_sourcePoint.setY(0);
        m_targetPoint.setY(10000);
    }
    else {
        m_sourcePoint.setY(10000);
        m_targetPoint.setY(0);
    }
}

DWidget* DEdge::sourceWidget() const
{
    return m_pSourceWidget; 
}

void DEdge::setSourceWidget(DWidget* pSourceWidget)
{
    m_pSourceWidget = pSourceWidget;
}

DWidget* DEdge::targetWidget() const
{
    return m_pTargetWidget; 
}

void DEdge::setTargetWidget(DWidget* pTargetWidget)
{
    m_pTargetWidget = pTargetWidget;
}

/**********************event handle**********************/

void DEdge::onDeleteEdge(const DEvent& rEvent)
{
    LOG_DEBUG("------------delete edge----------------");

    if (NULL == m_pSourceWidget)
        return;

    DFunc* pSourceFunc = dynamic_cast<DFunc *>(m_pSourceWidget->parent());
    if (NULL != pSourceFunc)
    {
        DPort* pSrcPort = dynamic_cast<DPort *>(m_pSourceWidget);
        if (NULL != pSrcPort)
        {
            pSourceFunc->deleteEdgeFromOutPort(pSrcPort, this);

            // Show
            DWidget* pParentWidget = dynamic_cast<DWidget *>(pSourceFunc->parent());
            assert(NULL != pParentWidget);
            //DImplEditor* pImpl = dynamic_cast<DImplEditor*>(pParentWidget->parent()->parent());
            //if(NULL != pImpl)
            //{
            //    pImpl->saveInternalNodeInfo();
            //}
            pParentWidget->updateAll();
            pParentWidget->repaint(rEvent.getCon());

            return;
        }
    } 

    DObjIcon* pSrcObj = dynamic_cast<DObjIcon *>(m_pSourceWidget->parent());
    if (NULL != pSrcObj)
    {
        pSrcObj->deleteOutEdge(this); 

        // Show
        DWidget* pParentWidget = dynamic_cast<DWidget *>(pSrcObj->parent());
        assert(NULL != pParentWidget);
        pParentWidget->updateAll();
        pParentWidget->repaint(rEvent.getCon());
    }
}

void DEdge::onFocusEdge(const DEvent& rEvent)
{
    LOG_DEBUG("------------focus edge----------------");
    setColor(DColor(255, 0, 0));
    repaint(rEvent.getCon());
}

void DEdge::onBlurEdge(const DEvent& rEvent)
{
    LOG_DEBUG("------------blur edge----------------");
    setColor(DColor(0, 0, 0));
    repaint(rEvent.getCon());
}



/*************DEdgeCell**********************************/

DEdgeCell::DEdgeCell()
{
    isFocusable = true;
}

DEdgeCell::~DEdgeCell()
{
}

void DEdgeCell::init()
{
    DEdge *q = q_func();
    TPlacement place;

    //Create the TEdge data in TPlacement
    TCurve* pCurve = new(std::nothrow) TCurve;
    assert(pCurve != NULL);
    place.data = pCurve;

    //set line width 
    pCurve->stroke.width = 2;
    //record the path
    TPath path(m_place->path);
    path.node.push_back(0);
    place.path = path;

    //clear the position
    place.position.x = place.position.y = MIN_COORD;
    place.size.width = place.size.height = MAX_COORD;
    
    subNodes.push_back(place);
    (q->cnum())++;
    update();
}

void DEdgeCell::update()
{
    //call base class at first
    DWidgetCell::update();
    
    //update itself
    DEdge *pEdge = q_func();
    assert(NULL != pEdge);
    
    m_place->path.node = pEdge->objectPath();
    TPlacement *curvePlace = &subNodes[0];
    curvePlace->path.node = pEdge->objectPath();
    curvePlace->path.node.push_back(0);

    TCurve* pCurve = dynamic_cast<TCurve*>(curvePlace->data);
    assert(NULL != pCurve);

    DEdge2TCurve(*pEdge, *pCurve);

    m_place->referencePointDerivation.clear(); 
    m_place->relativeValueDerivation.clear();
}    

// vim:set tabstop=4 shiftwidth=4 expandtab:
