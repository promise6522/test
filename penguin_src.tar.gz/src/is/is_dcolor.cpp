/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#include "is_dcolor.h"

/*
 * Constructs a color with the value rgba.
 */
DColor::DColor(DRgb rgba)
{
    r = (rgba >> 24) & 0xff;
    g = (rgba >> 16) & 0xff;
    b = (rgba >> 8) & 0xff;
    a = rgba & 0xff;
}

/*
 * Returns the RGB value of the color.
 */
DRgb DColor::rgba() const
{
    return ((r << 24) |
            (g << 16) |
            (b << 8) |
            a);
}

/*
 * Sets the RGBA value to rgba.
 */
void DColor::setRgba(DRgb rgba)
{
    r = (rgba >> 24) & 0xff;
    g = (rgba >> 16) & 0xff;
    b = (rgba >> 8) & 0xff;
    a = rgba & 0xff;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
