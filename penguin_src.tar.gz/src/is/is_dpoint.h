/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DPOINT_H
#define DPOINT_H

// Boost header files
#include <boost/tr1/memory.hpp>

class DPoint
{
public:
    DPoint();
    DPoint(int xpos, int ypos, int zpos = 0);

    bool isNull() const;

    int x() const;
    int y() const;
    int z() const;
    void setX(int x);
    void setY(int y);
    void setZ(int z);

    int &rx();
    int &ry();
    int &rz();

    DPoint &operator+=(const DPoint &p);
    DPoint &operator-=(const DPoint &p);

    friend inline bool operator==(const DPoint &, const DPoint &);
    friend inline bool operator!=(const DPoint &, const DPoint &);
    friend inline const DPoint operator+(const DPoint &, const DPoint &);
    friend inline const DPoint operator-(const DPoint &, const DPoint &);

private:
    int xp;
    int yp;
    int zp;
};

typedef std::tr1::shared_ptr<DPoint> DPointPtr;

/**************************************************************************
 * DPoint inline functions
 **************************************************************************/
inline DPoint::DPoint()
{ xp=0; yp=0; zp=0; }

inline DPoint::DPoint(int xpos, int ypos, int zpos)
{ xp = xpos; yp = ypos; zp = zpos; }

inline bool DPoint::isNull() const
{ return xp == 0 && yp == 0 && zp == 0; }

inline int DPoint::x() const
{ return xp; }

inline int DPoint::y() const
{ return yp; }

inline int DPoint::z() const
{ return zp; }

inline void DPoint::setX(int xpos)
{ xp = xpos; }

inline void DPoint::setY(int ypos)
{ yp = ypos; }

inline void DPoint::setZ(int zpos)
{ zp = zpos; }

inline int &DPoint::rx()
{ return xp; }

inline int &DPoint::ry()
{ return yp; }

inline int &DPoint::rz()
{ return zp; }

inline DPoint &DPoint::operator+=(const DPoint &p)
{ xp+=p.xp; yp+=p.yp; zp+=p.zp; return *this; }

inline DPoint &DPoint::operator-=(const DPoint &p)
{ xp-=p.xp; yp-=p.yp; zp-=p.zp; return *this; }

inline bool operator==(const DPoint &p1, const DPoint &p2)
{ return p1.xp == p2.xp && p1.yp == p2.yp && p1.zp == p2.zp; }

inline bool operator!=(const DPoint &p1, const DPoint &p2)
{ return p1.xp != p2.xp || p1.yp != p2.yp || p1.zp != p2.zp; }

inline const DPoint operator+(const DPoint &p1, const DPoint &p2)
{ return DPoint(p1.xp+p2.xp, p1.yp+p2.yp, p1.zp+p2.zp); }

inline const DPoint operator-(const DPoint &p1, const DPoint &p2)
{ return DPoint(p1.xp-p2.xp, p1.yp-p2.yp, p1.zp-p2.zp); }

#endif //DPOINT_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
