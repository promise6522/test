#ifndef DWAREHOUSEDLG_H
#define DWAREHOUSEDLG_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"
#include "is_dlabel.h"
#include "is_dbutton.h"
#include "is_dlineedit.h"
#include "is_dimagelabel.h"
#include "is_dwarehouseimpl.h"

typedef std::vector<DButtonPtr> WarehouseItems;
typedef WarehouseItems::iterator WarehouseItemsIt;
typedef WarehouseItems::size_type WarehouseItemsIdx;

typedef std::vector<DLabelPtr> WarehouseTexts;
typedef WarehouseTexts::iterator WarehouseTextsIt;
typedef WarehouseTexts::size_type WarehouseTextsIdx;

typedef std::vector<DFramePtr> WarehouseViewLayers;
typedef WarehouseViewLayers::iterator WarehouseViewLayersIt;
typedef WarehouseViewLayers::size_type WarehouseViewLayersIdx;

//warehouse type
enum WarehouseType
{
    UnknowWarehouse = -1,
    ObjWarehouse,
    IFWarehouse,
    DeclWarehouse,
    ImplWarehouse,
    ContWarehouse,
    AcsWarehouse,
    RunWarehouse,
    SharedWarehouse
};

class DWarehouseDlg : public DDialogEx
{
public:
    explicit DWarehouseDlg(DMainWin * pMainWin = NULL, DWidget * parent = 0);
    explicit DWarehouseDlg(WarehouseType type, 
                           DMainWin * pMainWin = NULL, 
                           DWidget * parent = 0);
    explicit DWarehouseDlg(const std::string& title,
                           WarehouseType type,
                           DMainWin *pMainWin = NULL,
                           DWidget * parent = 0);
    virtual ~DWarehouseDlg();

    //set & get methods
    WarehouseType warehouseType() const;
    void setWarehouseType(WarehouseType type);
    int warehouseRowNum() const;
    int warehouseColoumnNum() const;
    int getCurPagePos() const;
    std::string getSearchKeyWord() const;
    DukeItemClassic  getCurClassic() const;
    bool isEditing() const;

    //misc
    WarehouseItemsIdx getButtonItemIdx(DWidget * pWidget);
    
    //Init    
    virtual void initDialog();    

protected:
    //Event handle
    void processEnlargeEvent(const DEvent& rEvent);
    void processShrinkEvent(const DEvent& rEvent);
    //void processSelectEvent(const DEvent& rEvent);
    //void processDetailEvent(const DEvent& rEvent);
    void processResizeReleaseEvent(const DEvent& rEvent);
    void onDnDStart(const DEvent &event);
    void onActivate(const DEvent &event);
    void onHover(const DEvent &event);
    void onPassingOut(const DEvent &event);
    void onPassingInBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);

    //Button select event handle
    void onSearch(const DEvent &event);
    void onAllItem(const DEvent &event);
    void onBuiltInItem(const DEvent &event);
    void onEditItem(const DEvent &event);
    void onUserItem(const DEvent &event);
    void onSharedItem(const DEvent &event);
    void onBeginPage(const DEvent &event);
    void onPrePage(const DEvent &event);
    void onNextPage(const DEvent &event);
    void onEndPage(const DEvent &event);
    void onInputPage(const DEvent &event);
    void onCreateNew(const DEvent &event);

    //menu event handle
    virtual void onClose(const DEvent& rEvent);

    //init
    void initControlBar();
    void initTabBar();
    void initWarehouseView();

private:
    void fillItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateView();
    void setCurSelectedClassic(DukeItemClassic classic);
    
protected:
    //the attribute of warehouseDlg
    WarehouseType m_wType;
    int m_rowNum;
    int m_columnNum;
    int m_curPage;
    //int m_totalPage;
    std::string m_searchKey;
    DukeItemClassic m_curClassic;
    DWarehouseImplPtr m_ptrImpl;

    //control bar, see the style below
    //
    //  < >   [_____]  [Search]
    //
    DLineEditPtr m_ptrSearchKeyWord;
    DImageLabelPtr m_ptrSearchEditBg;
    DButtonPtr m_ptrSearchButton;
    DButtonPtr m_ptrNextPage;
    DButtonPtr m_ptrPrePage;
    DButtonPtr m_ptrCreate;
    
    //tab bar, see the style below
    //
    //   [All]  [Built-in]  [Edit]  [User-defined]  [Shared]
    //
    DButtonPtr m_ptrAllItem;
    DButtonPtr m_ptrBuiltInItem;
    DButtonPtr m_ptrEditItem;
    DButtonPtr m_ptrUserItem;
    DButtonPtr m_ptrSharedItem;

    //warehouse view, see the style below
    // ________________________
    // |  item   item   item   |
    // |  text   text   text   |
    // |-----------------------| (warehouse frame)
    //
    DFramePtr m_ptrWarehouseViewBg;
    WarehouseViewLayers m_viewLayers;
    WarehouseItems m_items;
    WarehouseTexts m_texts;

    //page control bar, see the style below
    //     <<  <  [X]/88  >  >>
    //DFramePtr m_ptrPageBarBg;
};

typedef std::tr1::shared_ptr<DWarehouseDlg>  DWarehouseDlgPtr;

const std::string WarehouseDlg_Item_DefaultName("N/A");

const std::string WarehouseDlg_ObjName("Warehouse_Dialog");
const std::string WarehouseDlg_Title_Name("Warehouse");

//default value for row & column
const int WarehouseDlg_Default_RowNum = 4;
const int WarehouseDlg_Default_ColumnNum = 5;

//default title for warehouse
const std::string Unkown_Warehouse_Title_Name("Duke Warehouse");
const std::string Object_Warehouse_Title_Name("Duke Object Warehouse");
const std::string Interface_Warehouse_Title_Name("Duke Interface Warehouse");
const std::string Declaration_Warehouse_Title_Name("Duke Declaration Warehouse");
const std::string Implement_Warehouse_Title_Name("Duke Implement Warehouse");
const std::string Container_Warehouse_Title_Name("Duke Container Descriptor Warehouse");
const std::string Access_Warehouse_Title_Name("Duke Access Warehouse");
const std::string Run_Warehouse_Title_Name("Duke Run Warehouse");

//the image for warehouse dialog
const std::string Search_EditImg_FileName("warehouse_search_edit.png");
const std::string Tab_ButtonImg_FileName("warehouse_tab_classic.png");
const std::string Tab_ButtonSelImg_FileName("warehouse_tab_classic_sel.png");
const std::string Control_NextPageImg_FileName("warehouse_next_page.png");
const std::string Control_NextPageSelImg_FileName("warehouse_next_page_sel.png");
const std::string Control_PrePageImg_FileName("warehouse_pre_page.png");
const std::string Control_PrePageSelImg_FileName("warehouse_pre_page_sel.png");
const std::string Control_CreateImg_FileName("warehouse_create_button.png");
const std::string Control_BeginButtonImg_FileName("none.png");
const std::string Control_EndButtonImg_FileName("none.png");

const std::string WarehouseItemImage_FileName("object_origin.png");
 
///////////////////////////////////////////////////////////////
//   Change this according to design (1366 * 768)
///////////////////////////////////////////////////////////////
const int Default_WarehouseWidth_Pixel = 433;
const int Default_WarehouseHeight_Pixel = 374;

const int Warehouse_PrePageX_Pixel = 5;
const int Warehouse_PrePageY_Pixel = 24;
const int Warehouse_PrePageW_Pixel = 39;
const int Warehouse_PrePageH_Pixel = 20;

const int Warehouse_NextPageX_Pixel = 45;
const int Warehouse_NextPageY_Pixel = 24;
const int Warehouse_NextPageW_Pixel = 39;
const int Warehouse_NextPageH_Pixel = 20;

const int Warehouse_CreateX_Pixel = 90;
const int Warehouse_CreateY_Pixel = 23;
const int Warehouse_CreateW_Pixel = 40;
const int Warehouse_CreateH_Pixel = 20;

const int Warehouse_SearchX_Pixel = 133;
const int Warehouse_SearchY_Pixel = 26;
const int Warehouse_SearchW_Pixel = 292;
const int Warehouse_SearchH_Pixel = 15;

const int Warehouse_SearchEditX_Pixel = 143;
const int Warehouse_SearchEditW_Pixel = 282;

const int Warehouse_Tab_AllX_Pixel = 7;
const int Warehouse_Tab_BuiltX_Pixel = 91;
const int Warehouse_Tab_EditX_Pixel = 175;
const int Warehouse_Tab_UserX_Pixel = 259;
const int Warehouse_Tab_SharedX_Pixel = 343;
const int Warehouse_TabY_Pixel = 45;
const int Warehouse_TabW_Pixel = 84;
const int Warehouse_TabH_Pixel = 17;

const int Warehouse_Layer_StartY_Pixel = 67;
const int Warehouse_TotalLayer_H_Pixel = 300;
const int Warehouse_Layer_H_Pixel = Warehouse_TotalLayer_H_Pixel / WarehouseDlg_Default_RowNum;

const int Warehouse_Icon_StartX_Pixel = 20;
const int Warehouse_Icon_SpacingX_Pixel = 86;
const int Warehouse_Icon_StartY_Pixel = 71;
const int Warehouse_Icon_W_Pixel = 50;
const int Warehouse_Icon_H_Pixel = 50;

const int Warehouse_Text_StartX_Pixel = 7;
const int Warehouse_Text_SpacingX_Pixel = 86;
const int Warehouse_Text_StartY_Pixel = 125;
const int Warehouse_Text_W_Pixel = 77;
const int Warehouse_Text_H_Pixel = 14;

//auto-count pixel information for others
const int Warehouse_ViewW_Pixel = Default_WarehouseWidth_Pixel;
const int Warehouse_ViewH_Pixel = Default_WarehouseHeight_Pixel - Default_DlgTitleHeight_Pixel;

////////////////////////////////////////////////////////////////
//auto-count the related placement of warehouse in mainwin
////////////////////////////////////////////////////////////////
const int WarehouseX_InMainWin = 2000;
const int WarehouseY_InMainWin = 2000;
const int WarehouseW_InMainWin = Default_WarehouseWidth_Pixel * MAX_COORD / 1366;
const int WarehouseH_InMainWin = Default_WarehouseHeight_Pixel * MAX_COORD / 768;

////////////////////////////////////////////////////////////////
//   auto-count related placement of widgets in warehouse's view frame
///////////////////////////////////////////////////////////////
//previous page button
const int Warehouse_PrePageX_InView = Warehouse_PrePageX_Pixel*MAX_COORD/Warehouse_ViewW_Pixel;
const int Warehouse_PrePageY_InView = (Warehouse_PrePageY_Pixel - Default_DlgTitleHeight_Pixel)
                                      * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_PrePageW_InView = Warehouse_PrePageW_Pixel*MAX_COORD/Warehouse_ViewW_Pixel;
const int Warehouse_PrePageH_InView = Warehouse_PrePageH_Pixel*MAX_COORD/Warehouse_ViewH_Pixel;
//next page button
const int Warehouse_NextPageX_InView = Warehouse_NextPageX_Pixel 
                                       * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_NextPageY_InView = (Warehouse_NextPageY_Pixel-Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_NextPageW_InView = Warehouse_NextPageW_Pixel * MAX_COORD 
                                       / Warehouse_ViewW_Pixel;
const int Warehouse_NextPageH_InView = Warehouse_NextPageH_Pixel * MAX_COORD 
                                       / Warehouse_ViewH_Pixel;
//Create button
const int Warehouse_CreateX_InView = Warehouse_CreateX_Pixel 
                                       * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_CreateY_InView = (Warehouse_CreateY_Pixel-Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_CreateW_InView = Warehouse_CreateW_Pixel * MAX_COORD 
                                       / Warehouse_ViewW_Pixel;
const int Warehouse_CreateH_InView = Warehouse_CreateH_Pixel * MAX_COORD 
                                       / Warehouse_ViewH_Pixel;

//search line edit backgroud
const int Warehouse_SearchX_InView = Warehouse_SearchX_Pixel*MAX_COORD/Warehouse_ViewW_Pixel;
const int Warehouse_SearchY_InView = (Warehouse_SearchY_Pixel-Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_SearchW_InView = Warehouse_SearchW_Pixel * MAX_COORD 
                                       / Warehouse_ViewW_Pixel;
const int Warehouse_SearchH_InView = Warehouse_SearchH_Pixel * MAX_COORD 
                                       / Warehouse_ViewH_Pixel;
//search line edit 
const int Warehouse_SearchEditX_InView = Warehouse_SearchEditX_Pixel
                                         * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_SearchEditW_InView = Warehouse_SearchEditW_Pixel * MAX_COORD 
                                         / Warehouse_ViewW_Pixel;
//tab classic buttons
const int Warehouse_Tab_AllX_InView = Warehouse_Tab_AllX_Pixel
                                      * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Tab_BuiltX_InView = Warehouse_Tab_BuiltX_Pixel
                                        * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Tab_EditX_InView = Warehouse_Tab_EditX_Pixel
                                       * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Tab_UserX_InView = Warehouse_Tab_UserX_Pixel
                                       * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Tab_SharedX_InView = Warehouse_Tab_SharedX_Pixel
                                         * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_TabY_InView = (Warehouse_TabY_Pixel - Default_DlgTitleHeight_Pixel)
                                       * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_TabW_InView = Warehouse_TabW_Pixel * MAX_COORD 
                                       / Warehouse_ViewW_Pixel;
const int Warehouse_TabH_InView = Warehouse_TabH_Pixel * MAX_COORD 
                                       / Warehouse_ViewH_Pixel;

//layers in warehouse
const int Warehouse_Layer_X_InView = MIN_COORD;
const int Warehouse_Layer_StartY_InView = (Warehouse_Layer_StartY_Pixel - Default_DlgTitleHeight_Pixel)
                                          * MAX_COORD / Warehouse_ViewH_Pixel;
const int Warehouse_Layer_W_InView = MAX_COORD;

const int Warehouse_TotalLayer_H_InView = Warehouse_TotalLayer_H_Pixel * MAX_COORD 
                                          / Warehouse_ViewH_Pixel;

const int Warehouse_Layer_H_InView = Warehouse_Layer_H_Pixel * MAX_COORD 
                                          / Warehouse_ViewH_Pixel;
//icon in layer
const int Warehouse_Icon_StartX_InLayer = Warehouse_Icon_StartX_Pixel
                                          * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Icon_SpacingX_InLayer = Warehouse_Icon_SpacingX_Pixel
                                          * MAX_COORD / Warehouse_ViewW_Pixel;

const int Warehouse_Icon_Y_InLayer = (Warehouse_Icon_StartY_Pixel-Warehouse_Layer_StartY_Pixel)
                                          * MAX_COORD / Warehouse_Layer_H_Pixel;
const int Warehouse_Icon_W_InLayer = Warehouse_Icon_W_Pixel
                                    * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Icon_H_InLayer = Warehouse_Icon_H_Pixel * MAX_COORD 
                                          / Warehouse_Layer_H_Pixel;

//text in layer
const int Warehouse_Text_StartX_InLayer = Warehouse_Text_StartX_Pixel
                                          * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Text_SpacingX_InLayer = Warehouse_Text_SpacingX_Pixel
                                          * MAX_COORD / Warehouse_ViewW_Pixel;

const int Warehouse_Text_Y_InLayer = (Warehouse_Text_StartY_Pixel-Warehouse_Layer_StartY_Pixel)
                                          * MAX_COORD / Warehouse_Layer_H_Pixel;
const int Warehouse_Text_W_InLayer = Warehouse_Text_W_Pixel
                                    * MAX_COORD / Warehouse_ViewW_Pixel;
const int Warehouse_Text_H_InLayer = Warehouse_Text_H_Pixel * MAX_COORD 
                                          / Warehouse_Layer_H_Pixel;

#endif /* DWARWHOUSEDLG_H */
    
// vim:set tabstop=4 shiftwidth=4 expandtab:
