/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DGLOBAL_H
#define DGLOBAL_H

#include <stdint.h>
#include <memory>

/* Text formatting flags */
enum AlignmentFlag {
    AlignLeft = 0x0001,
    AlignRight = 0x0002,
    AlignHCenter = 0x0004,
    AlignJustify = 0x0008,
    AlignHorizontal_Mask = AlignLeft | AlignRight | AlignHCenter | AlignJustify,

    AlignTop = 0x0020,
    AlignBottom = 0x0040,
    AlignVCenter = 0x0080,
    AlignVertical_Mask = AlignTop | AlignBottom | AlignVCenter,

    AlignCenter = AlignVCenter | AlignHCenter
};

/* Widget flags */
typedef unsigned int WFlags;

enum WidgetFlags {
    WStyle_NoBorder         = 0x00000000,
};

const int MAX_COORD = 10000;
const int MIN_COORD = 0;

/*
 * Utility macros and inline functions
 */
template <typename T>
inline const T &dMin(const T &a, const T &b) { if (a < b) return a; return b; }
template <typename T>
inline const T &dMax(const T &a, const T &b) { if (a < b) return b; return a; }



#define D_DECLARE_CELL(Class) \
    inline Class##Cell* d_func() { return reinterpret_cast<Class##Cell *>(d_ptr); } \
    inline const Class##Cell* d_func() const { return reinterpret_cast<const Class##Cell *>(d_ptr); } \
    friend class Class##Cell;

#define D_DECLARE_PUBLIC(Class)                                    \
    inline Class* q_func() { return static_cast<Class *>(q_ptr); } \
    inline const Class* q_func() const { return static_cast<const Class *>(q_ptr); } \
    friend class Class;


#endif //DGLOBAL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
