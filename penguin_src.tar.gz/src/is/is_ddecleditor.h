/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author LHJ
**
****************************************************************************/

#ifndef DDECEDITOR_H
#define DDECEDITOR_H

#include <boost/tr1/memory.hpp>

#include "is_ddialog.h"
#include "is_dbutton.h"
#include "is_dlineedit.h"
#include "is_dimagelabel.h"
#include "is_dframe.h"
#include "is_deditor.h"
#include "duke_media_declare.h"
#include "duke_media_global.h"

typedef std::vector<DButtonPtr> PortItems;
typedef std::vector<DButtonPtr>::iterator PortItemIt;
typedef std::vector<DButtonPtr>::size_type PortItemIdx;

typedef std::vector<int> WidgetIndexs;
typedef WidgetIndexs::iterator WidgetIndexsIt;
typedef WidgetIndexs::size_type WidgetIndexIdx;

class DDeclEditorCell;

class DDeclEditor : public DEditor {
    friend class boost::serialization::access;
public:
    explicit DDeclEditor(EditorModel model = DialogModel,
                         DMainWin * pMainWin = NULL,
                         DWidget * parent = 0,
                         WFlags flag = 0);
    explicit DDeclEditor(const std::string& title,
                         EditorModel model = DialogModel,
                         DMainWin *pMainWin = NULL,
                         DWidget * parent = 0,
                         WFlags flag = 0);
    explicit DDeclEditor(const std::string& title,
                         const duke_media_handle& rHandle,
                         DEditor::EditorModel model,                  
                         DMainWin *pMainWin  = NULL,
                         DWidget * parent = 0,
                         WFlags flag  = 0);
 
    virtual ~DDeclEditor();
    //init interface 
    void initDeclEditor();
    void duplicateItemsByHandle(const duke_media_handle& rDukeMediaHandle);
    //update placement
    virtual void adjustPlacement();
 
    //generate
    virtual duke_media_handle generate();
    
    //Event handle
    void onSelectExcepButton(const DEvent& rEvent);
    void onDnDStart(const DEvent &rEvent);
    void onDnDDrag(const DEvent &rEvent);    
    void onDnDRelease(const DEvent &rEvent);
    void onDnDReleaseInFrame(const DEvent &rEvent);
    void onDnDReleaseOutFrame(const DEvent &rEvent);
    void onDeletePort(const DEvent &rEvent);
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onHoverException(const DEvent &event);
    void onPassingOutException(const DEvent &event);
    void onActivateBtn(const DEvent &event);
    void onSelectBtn(const DEvent &event);
    void onDnDReleaseMaster(const DEvent &event);

    //interface only for impl editor
    void setEditorFlag(bool editorFlag);
    bool setInPortConstraint(const duke_media_handle_vector& rVecHandle);
    bool setOutPortConstraint(const duke_media_handle_vector& rVecHandle);
    bool getInPortConstraint(duke_media_handle_vector& rVecHandle, WidgetIndexs& vInportSeq); 
    bool getOutPortConstraint(duke_media_handle_vector& rVecHandle, WidgetIndexs& vOutPortSeq);

    virtual void generateSubItems();
    //set readonly
    virtual void setReadonly();
    //reload
    virtual void reload();

    duke_media_handle getMaster() const;
    void setMaster(duke_media_handle handle);
protected:
    virtual void onGenerate(const DEvent& rEvent);
private:
    void dumpDukeInfo();
    void adjustOutFramePos();
    void addConstraintOutFrame(DButtonPtr ptrConstraintButton, int x, int y);
    void addConstraintOutFrameByHandle(const duke_media_handle& rHandle);
    
    void adjustInFramePos();
    void addConstraintInFrame(DButtonPtr ptrConstraintButton, int x, int y); 
    void addConstraintInFrameByHandle(const duke_media_handle& rHandle, bool zeroPortFlag);

    DEditor* createArrayInterfaceEditor(DWidget *pSrcWidget);
    DEditor* createMapInterfaceEditor(DWidget *pSrcWidget);    
    void updateDeclEditorFrame();
    void setConstraintButtonProperty(DButton* pConstraintButton);
    void initInFrame();
    void initCuttingLine();
    void initOutFrame();
    void initExceptionBar();
    void initDukeMedia();
    void dialogReleaseToFrame(const DEvent& rEvent, DFrame* pFrame);
    void constraintReleaseOutFrame(const duke_media_handle& rDukeHandle, const DEvent& rEvent);
    void constraintReleaseInFrame(const duke_media_handle& rDukeHandle, const DEvent& rEvent);
    void changeOutConstraintSeq(DButton* pDragButton, const DEvent& rEvent);
    void changeInConstraintSeq(DButton* pDragButton, const DEvent& rEvent);
    void clearInPortConstraint();
    void clearOutPortConstraint();
    void saveInportInfo();
    void saveOutportInfo();
    bool isValidDecl(duke_media_compound_declare* pDeclMedia);
private:
    WidgetIndexs m_vInportSeq;
    WidgetIndexs m_vOutportSeq;
    PortItems m_vOutConstraints;
    PortItems m_vInConstraints;
    DFramePtr m_ptrInFrame;
    DFramePtr m_ptrOutFrame;
    DButtonPtr m_ptrIsExcepButton;
    DImageLabelPtr m_ptrCuttingLineLabel;
    bool m_isAccException;
    int m_cuttingLineHeight;
    int m_exceptionBarHeight;
    bool m_editorFlag;
    int m_insertIndex;

    duke_media_handle m_master;
    D_DECLARE_CELL(DDeclEditor)
};

class DDeclEditorCell : public DDialogCell
{
public:
    //ctor & detor
    DDeclEditorCell();
    virtual ~DDeclEditorCell();

    void init();
    virtual void update();

private:
    D_DECLARE_PUBLIC(DDeclEditor)    
};


typedef std::tr1::shared_ptr<DDeclEditor>  DDeclEditorPtr;
typedef std::tr1::shared_ptr<DDeclEditorCell>  DDeclEditorCellPtr;

const int DeclEditor_Width = 336;
const int DeclEditor_Heigth = 448;
const int Default_DeclEditor_W_InMainWin = DeclEditor_Width * MAX_COORD / 1366;
const int Default_DeclEditor_H_InMainWin = DeclEditor_Heigth * MAX_COORD / 768;

const int DeclEditor_CuttingLine_H_Pixel = 4;
const int DeclEditor_CuttingLine_H_InMainWin = DeclEditor_CuttingLine_H_Pixel * MAX_COORD / 768;

const int DeclEditor_CuttingLine_X_Pixel = 12;
const int DeclEditor_CuttingLine_X_InBodyFrame = DeclEditor_CuttingLine_X_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_CuttingLine_W_Pixel = 312;
const int DeclEditor_CuttingLine_W_InBodyFrame = DeclEditor_CuttingLine_W_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_InFrame_W_Pixel = 313;
const int DeclEditor_InFrame_W_InBodyFrame = DeclEditor_InFrame_W_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_InFrame_X_Pixel = 12;
const int DeclEditor_InFrame_X_InBodyFrame = DeclEditor_InFrame_X_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_OutFrame_W_Pixel = 313;
const int DeclEditor_OutFrame_W_InBodyFrame = DeclEditor_OutFrame_W_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_OutFrame_X_Pixel = 12;
const int DeclEditor_OutFrame_X_InBodyFrame = DeclEditor_OutFrame_X_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_ExceptionBar_X_Pixel = 112;
const int DeclEditor_ExceptionBar_X_InBodyFrame = DeclEditor_ExceptionBar_X_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_ExceptionBar_W_Pixel = 112;
const int DeclEditor_ExceptionBar_W_InBodyFrame = DeclEditor_ExceptionBar_W_Pixel * MAX_COORD / DeclEditor_Width;

const int DeclEditor_ExceptionBar_H_Pixel = 24;
const int DeclEditor_ExceptionBar_H_InMainWin = DeclEditor_ExceptionBar_H_Pixel * MAX_COORD / 768;

const std::string DeclEditor_ExceptionImage_FileName("decleditor_exception_A.png");
const std::string DeclEditor_ExceptionSelImage_FileName("decleditor_exception_B.png");
const std::string DeclEditor_IFButton_FileName("interface_origin.png");
const std::string DeclEditor_SelIFButton_FileName("interface_selected.png");
const std::string DeclEditor_NoExceptionImage_FileName("decleditor_noexception_A.png");
const std::string DeclEditor_NoExceptionSelImage_FileName("decleditor_noexception_B.png");
const std::string DeclEditor_CuttingLineImage_FileName("decleditor_cutting_line.png");
const std::string DeclEditor_ObjName("Decl_Editor");

const std::string DeclEditor_ArrayImg_FileName("array.png");
const std::string DeclEditor_ArrayExImg_FileName("array_ex.png");
const std::string DeclEditor_MapImg_FileName("map.png");
const std::string DeclEditor_MapExImg_FileName("map_ex.png");

#endif // DRUEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
