/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

//boost header files
#include <boost/lexical_cast.hpp>

//duke header files
#include "is_dpackagesheet.h"
#include "is_dpackagesetting.h"

DPackageSheet::DPackageSheet(DMainWin * pMainWin /*= NULL*/, DWidget *parent /*= 0*/)
    :DWidget(parent),
     m_pMainWin(pMainWin),
     m_packageName(Default_Package_Name),
     m_beginPackagePos(0)
{
    setObjectName(PackageSheet_ObjName);
    initPackageSheet();
}

DPackageSheet::~DPackageSheet()
{
}

std::string DPackageSheet::packageName()
{
    return m_packageName;
}

void DPackageSheet::setPackageName(const std::string& name)
{
    m_packageName = name;
    m_ptrName->setContent(m_packageName);
}

void DPackageSheet::initPackageSheet()
{
    //load Images
    DImage img;
    img.load(getResPath() + PackageSheet_BackgroundImage_Filename);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);

    //init background of tool window
    m_ptrBgLabel.reset(new(std::nothrow) DImageLabel("", img, this));
    m_ptrBgLabel->setBackgroundColor(Duke_Transparent_Color);
    m_ptrBgLabel->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrBgLabel->registerEvent(DEvent::DnD_Release);
    m_ptrBgLabel->setEventRoutine(DEvent::DnD_Release,
                                  this,
                                  static_cast<EventRoutine>(&DPackageSheet::onDnDRelease));
    assert(m_ptrBgLabel.get() != NULL);

    //load the image from files
    img.load(getResPath() + PackageSheet_Package_Filename);
    DImage selImg;    
    selImg.load(getResPath() + PackageSheet_PackageSel_Filename);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //Current package icon & text
    m_ptrCurPackage.reset(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    m_ptrCurPackage->setGeometry(PackageSheet_Package_Button_X, PackageSheet_Package_Button_Y,
                                 PackageSheet_Package_Button_W, PackageSheet_Package_Button_H); 
    m_ptrCurPackage->registerEvent(DEvent::Select);
    m_ptrCurPackage->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DPackageSheet::onCurPackage));

    m_ptrName.reset(new(std::nothrow) DLabel(m_packageName, m_ptrBgLabel.get()));
    m_ptrName->setGeometry(PackageSheet_Name_Label_X, PackageSheet_Name_Label_Y,
                           PackageSheet_Name_Label_W, PackageSheet_Name_Label_H); 
    m_ptrName->setBackgroundColor(Duke_Transparent_Color);
    m_ptrName->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrName->setTextColor(Default_PackageSheet_TextColor);
    m_ptrName->setAlignment(AlignCenter);

    //init create new package button
    img.load(getResPath() + PackageSheet_CreatePackage_Filename);
    m_ptrNewPackage.reset(new(std::nothrow) DButton("", img, m_ptrBgLabel.get()));
    assert(m_ptrNewPackage.get() != NULL);
    m_ptrNewPackage->setGeometry(PackageSheet_NewPackage_Button_X,
                                 PackageSheet_NewPackage_Button_Y,
                                 PackageSheet_NewPackage_Button_W,
                                 PackageSheet_NewPackage_Button_H);
    m_ptrNewPackage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNewPackage->setSelected(false);
    m_ptrNewPackage->registerEvent(DEvent::Select);
    m_ptrNewPackage->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DPackageSheet::onNewPackage));

    //init open package button
    img.load(getResPath() + PackageSheet_OpenPackage_Filename);
    m_ptrOpenPackage.reset(new(std::nothrow) DButton("", img, m_ptrBgLabel.get()));
    assert(m_ptrNewPackage.get() != NULL);
    m_ptrOpenPackage->setGeometry(PackageSheet_OpenPackage_Button_X,
                                  PackageSheet_OpenPackage_Button_Y,
                                  PackageSheet_OpenPackage_Button_W,
                                  PackageSheet_OpenPackage_Button_H);
    m_ptrOpenPackage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrOpenPackage->setSelected(false);
    m_ptrOpenPackage->registerEvent(DEvent::Select);
    m_ptrOpenPackage->setEventRoutine(DEvent::Select,
                                      this,
                                      static_cast<EventRoutine>(&DPackageSheet::onOpenPackage));

    //Separator Line;
    img.load(getResPath() + PackageSheet_SeparatorLine_Filename);
    m_ptrSeparatorLine.reset(new(std::nothrow) DImageLabel("", img, m_ptrBgLabel.get()));
    assert(m_ptrSeparatorLine.get() != NULL);
    m_ptrSeparatorLine->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSeparatorLine->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrSeparatorLine->setGeometry(PackageSheet_SeparatorLine_X, PackageSheet_SeparatorLine_Y,
                                    PackageSheet_SeparatorLine_W, PackageSheet_SeparatorLine_H);

    //init up arrow
    img.load(getResPath() + PackageSheet_UpButton_Filename);
    selImg.load(getResPath() + PackageSheet_UpButtonHover_Filename);
    m_ptrUpArrow.reset(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    assert(m_ptrUpArrow.get() != NULL);
    m_ptrUpArrow->setGeometry(PackageSheet_UpArrow_X,
                              PackageSheet_Arrow_Y,
                              PackageSheet_Arrow_Width,
                              PackageSheet_Arrow_Height);
    m_ptrUpArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrUpArrow->setSelected(false);
    m_ptrUpArrow->registerEvent(DEvent::Grab);
    m_ptrUpArrow->registerEvent(DEvent::Select);
    m_ptrUpArrow->registerEvent(DEvent::PassingIn);
    m_ptrUpArrow->registerEvent(DEvent::PassingOut);
    m_ptrUpArrow->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DPackageSheet::onUpArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::Grab,
                                  this,
                                  static_cast<EventRoutine>(&DPackageSheet::onUpArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::PassingIn, 
                                  this, 
                                  (EventRoutine)(&DPackageSheet::onPassingInArrow));
    m_ptrUpArrow->setEventRoutine(DEvent::PassingOut, 
                                  this, 
                                  (EventRoutine)(&DPackageSheet::onPassingOutArrow));

    //init all package button
    img.load(getResPath() + PackageSheet_AllButton_Filename);
    selImg.load(getResPath() + PackageSheet_AllButtonHover_Filename);
    m_ptrAllPackage.reset(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    assert(m_ptrAllPackage.get() != NULL);
    m_ptrAllPackage->setGeometry(PackageSheet_AllPackage_X,
                                 PackageSheet_Arrow_Y,
                                 PackageSheet_Arrow_Width,
                                 PackageSheet_Arrow_Height);
    m_ptrAllPackage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrAllPackage->setSelected(false);
    m_ptrAllPackage->registerEvent(DEvent::Select);
    //m_ptrAllPackage->registerEvent(DEvent::Hover);
    //m_ptrAllPackage->registerEvent(DEvent::PassingOut);
    m_ptrAllPackage->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DPackageSheet::onAllPackage));
    /*
    m_ptrAllPackage->setEventRoutine(DEvent::Hover, 
                                     this, 
                                     (EventRoutine)(&DPackageSheet::onHoverArrow));
    m_ptrAllPackage->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DPackageSheet::onPassingOutArrow));
    */

    //init add package button
    img.load(getResPath() + PackageSheet_AddButton_Filename);
    selImg.load(getResPath() + PackageSheet_AddButtonHover_Filename);
    m_ptrAddPackage.reset(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    assert(m_ptrAddPackage.get() != NULL);
    m_ptrAddPackage->setGeometry(PackageSheet_AddPackage_X,
                                 PackageSheet_Arrow_Y,
                                 PackageSheet_Arrow_Width,
                                 PackageSheet_Arrow_Height);
    m_ptrAddPackage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrAddPackage->setSelected(false);
    m_ptrAddPackage->registerEvent(DEvent::Select);
    //m_ptrAddPackage->registerEvent(DEvent::Hover);
    //m_ptrAllPackage->registerEvent(DEvent::PassingOut);
    m_ptrAddPackage->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DPackageSheet::onAddPackage));
    /*
    m_ptrAddPackage->setEventRoutine(DEvent::Hover, 
                                     this, 
                                     (EventRoutine)(&DPackageSheet::onHoverArrow));
    m_ptrAddPackage->setEventRoutine(DEvent::PassingOut, 
                                     this, 
                                     (EventRoutine)(&DPackageSheet::onPassingOutArrow));
    */

    
    //init down arrow
    img.load(getResPath() + PackageSheet_DownButton_Filename);
    selImg.load(getResPath() + PackageSheet_DownButtonHover_Filename);
    m_ptrDownArrow.reset(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    m_ptrDownArrow->setBackgroundColor(Duke_Transparent_Color);
    assert(m_ptrDownArrow.get() != NULL);
    m_ptrDownArrow->setGeometry(PackageSheet_DownArrow_X,
                                PackageSheet_Arrow_Y,
                                PackageSheet_Arrow_Width,
                                PackageSheet_Arrow_Height);
    m_ptrDownArrow->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDownArrow->setSelected(false);
    m_ptrDownArrow->registerEvent(DEvent::Select);
    m_ptrDownArrow->registerEvent(DEvent::Grab);
    m_ptrDownArrow->registerEvent(DEvent::PassingIn);
    m_ptrDownArrow->registerEvent(DEvent::PassingOut);
    m_ptrDownArrow->setEventRoutine(DEvent::Grab,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSheet::onDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSheet::onDownArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::PassingIn, 
                                    this, 
                                    (EventRoutine)(&DPackageSheet::onPassingInArrow));
    m_ptrDownArrow->setEventRoutine(DEvent::PassingOut, 
                                    this, 
                                    (EventRoutine)(&DPackageSheet::onPassingOutArrow));

    initPackageList();

    //calculate the gemoetry for package button
    calculatePackages();
}

void DPackageSheet::initPackageList()
{
    //load image 
    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;    
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);    
    img.load(getResPath() + PackageSheet_PackageButton_Filename);
    selImg.load(getResPath() + PackageSheet_PackageButtonSel_Filename);

    int packageSize = 11; // for test
    for(int i = 0; i < packageSize; ++i)
    {
        DButtonPtr ptrPackage(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
        assert(ptrPackage);
        ptrPackage->registerEvent(DEvent::Select);
        ptrPackage->registerEvent(DEvent::Hover);
        ptrPackage->registerEvent(DEvent::PassingOut);
        ptrPackage->setEventRoutine(DEvent::Select,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSheet::onClickPackage));
        ptrPackage->setEventRoutine(DEvent::Hover,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSheet::onHoverPackage)); 
        ptrPackage->setEventRoutine(DEvent::PassingOut,
                                    this,
                                    static_cast<EventRoutine>(&DPackageSheet::onPassOutPackage));
        m_packages.push_back(ptrPackage);
        ptrPackage->setSelected(false);  

        std::string packageName("Package " + boost::lexical_cast<std::string>(i));
        DLabelPtr ptrName(new(std::nothrow) DLabel(packageName, m_ptrBgLabel.get()));
        ptrName->setAlignment(AlignCenter);
        ptrName->setBackgroundColor(Duke_Transparent_Color);
        ptrName->setFrameBorderColor(Duke_Transparent_Color);
        ptrName->setTextColor(Default_PackageSheet_TextColor);
        m_names.push_back(ptrName);
    }
}

void DPackageSheet::calculatePackages()
{
    int curY = PackageSheet_Package_StartY;
    
    //for dynamic packages
    PackageButtonIdx pos = 0;    
    for(PackageButtonIt iter = m_packages.begin(); iter != m_packages.end(); ++iter)
    {
        if((pos >= m_beginPackagePos) && (pos < m_beginPackagePos + PackageSheet_Package_Size))
        {
            (*iter)->setGeometry(PackageSheet_Package_X, curY, 
                                 PackageSheet_Package_W, PackageSheet_Package_H);
            curY += PackageSheet_Package_H + PackageSheet_Package_Spacing / 2;
            m_names[pos]->setGeometry(PackageSheet_Name_Label_X, curY, 
                                     PackageSheet_Name_Label_W, PackageSheet_Name_Label_H);
            curY += PackageSheet_Name_Label_H + PackageSheet_Package_Spacing;
            assert(curY < MAX_COORD);
        }
        else
        {
            (*iter)->setGeometry(0, 0, 0, 0);
            m_names[pos]->setGeometry(0, 0, 0, 0);
        }
        ++pos;
    }
}

void DPackageSheet::onUpArrow(const DEvent & event)
{
    if(m_beginPackagePos <= 0)
    {
        m_beginPackagePos = 0;
    }   
    else
    {
        --m_beginPackagePos;
    }

    if(m_beginPackagePos == 0)
    {
        m_ptrUpArrow->setSelected(false);
    }    

    calculatePackages();
    updateAll();
    repaint(event.getCon());    
}

void DPackageSheet::onDownArrow(const DEvent & event)
{
    if(m_beginPackagePos + PackageSheet_Package_Size >= m_packages.size())
    {
        m_beginPackagePos = (m_packages.size() < PackageSheet_Package_Size) ? 
            0 : m_packages.size() - PackageSheet_Package_Size;
    }
    else
    {        
        ++m_beginPackagePos;
    }

    if((m_packages.size() == 0) 
       || (m_beginPackagePos + PackageSheet_Package_Size == m_packages.size()))
    {
        m_ptrDownArrow->setSelected(false);
    }    

    calculatePackages();
    updateAll();
    repaint(event.getCon());
}
 
void DPackageSheet::onPassingInArrow(const DEvent & event)
{
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = dynamic_cast<DButton *>(m_ptrBgLabel->findChild(rWidgetPath[0]));
    if(pButton != NULL)
    {
        //if up button
        if(pButton == m_ptrUpArrow.get() && (m_beginPackagePos == 0))
        {
            return;
        }

        //if down button
        if(pButton == m_ptrDownArrow.get() 
           && (m_beginPackagePos + PackageSheet_Package_Size >= m_packages.size()))
        {
            return;
        }
            
        pButton->setSelected(true);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DPackageSheet::onPassingOutArrow(const DEvent & event)
{
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = dynamic_cast<DButton *>(m_ptrBgLabel->findChild(rWidgetPath[0]));
    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DPackageSheet::onCurPackage(const DEvent & event)
{
    if(m_pMainWin == NULL)
        return;

    if(m_ptrPackageSetting)
    {
        if(m_ptrPackageSetting->isHide())
        {
            m_ptrPackageSetting->setHideProperty(false);
            m_pMainWin->setActiveWidget(m_ptrPackageSetting.get());
            //only update the placement
            m_pMainWin->repaintAll(event.getCon(), false);
        }
        else
        {
            m_ptrPackageSetting->setHideProperty(true);
            m_ptrPackageSetting->repaint(event.getCon(), false);
        }
    }
    else
    {
        m_ptrPackageSetting.reset(new(std::nothrow) DPackageSetting(m_packageName + " Setting",
                                                    DEditor::TitleModel | DEditor::BodyModel,
                                                    this, m_pMainWin, m_pMainWin->getRootWidget()));
        assert(m_ptrPackageSetting.get() != NULL);
        m_ptrPackageSetting->initDialog();
        m_ptrPackageSetting->setGeometry(2000, 2000, 
                                         Default_PackageSetting_W, Default_PackageSetting_H);
        m_pMainWin->insertWidget(m_ptrPackageSetting);
        m_ptrPackageSetting->updateAll();
        m_ptrPackageSetting->show(event.getCon());
    }    
}

void DPackageSheet::onClickPackage(const DEvent & event)
{
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DButton * pButton = dynamic_cast<DButton *>(m_ptrBgLabel->findChild(rWidgetPath[0]));
    if(!pButton)
        return;
    
    if(pButton->isSelected())
    {
        pButton->setSelected(false);
    }
    else
    {
        pButton->setSelected(true);
    }    

    pButton->updateAll();
    pButton->repaint(event.getCon());
}

void DPackageSheet::onHoverPackage(const DEvent & event)
{
}

void DPackageSheet::onPassOutPackage(const DEvent & event)
{
}

void DPackageSheet::onNewPackage(const DEvent & event)
{
}

void DPackageSheet::onOpenPackage(const DEvent & event)
{
}

void DPackageSheet::onAllPackage(const DEvent & event)
{
}

void DPackageSheet::onAddPackage(const DEvent & event)
{
    if(m_pMainWin == NULL)
        return;

    if(m_ptrExplorer)
    {
        if(m_ptrExplorer->isHide())
        {
            m_ptrExplorer->setHideProperty(false);
            m_pMainWin->setActiveWidget(m_ptrExplorer.get());
            //only update the placement
            m_pMainWin->repaintAll(event.getCon(), false);
        }
        else
        {
            m_ptrExplorer->setHideProperty(true);
            m_ptrExplorer->repaint(event.getCon(), false);
        }
    }
    else
    {
        m_ptrExplorer.reset(new(std::nothrow) 
                            DPackageExplorer(DEditor::TitleModel | DEditor::BodyModel,
                                             m_pMainWin, m_pMainWin->getRootWidget()));
        assert(m_ptrExplorer.get() != NULL);
        m_ptrExplorer->initDialog();
        m_ptrExplorer->setGeometry(2000, 2000, 
                                   ExplorerW_InMainWin, ExplorerH_InMainWin);
        m_pMainWin->insertWidget(m_ptrExplorer);
        m_ptrExplorer->updateAll();
        m_ptrExplorer->show(event.getCon());
    }    
}

void DPackageSheet::onDnDRelease(const DEvent & event)
{
    LOG_DEBUG("Release New Package");

    //load image 
    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;    
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);    
    img.load(getResPath() + PackageSheet_PackageButton_Filename);
    selImg.load(getResPath() + PackageSheet_PackageButtonSel_Filename);

    DButtonPtr ptrPackage(new(std::nothrow) DButton("", img, selImg, m_ptrBgLabel.get()));
    assert(ptrPackage);
    ptrPackage->registerEvent(DEvent::Select);
    ptrPackage->registerEvent(DEvent::Hover);
    ptrPackage->registerEvent(DEvent::PassingOut);
    ptrPackage->setEventRoutine(DEvent::Select,
                                this,
                                static_cast<EventRoutine>(&DPackageSheet::onClickPackage));
    ptrPackage->setEventRoutine(DEvent::Hover,
                                this,
                                static_cast<EventRoutine>(&DPackageSheet::onHoverPackage)); 
    ptrPackage->setEventRoutine(DEvent::PassingOut,
                                this,
                                static_cast<EventRoutine>(&DPackageSheet::onPassOutPackage));
    m_packages.push_back(ptrPackage);
    ptrPackage->setSelected(false);  

    std::string packageName("Package " + boost::lexical_cast<std::string>(m_names.size()));
    DLabelPtr ptrName(new(std::nothrow) DLabel(packageName, m_ptrBgLabel.get()));
    ptrName->setAlignment(AlignCenter);
    ptrName->setBackgroundColor(Duke_Transparent_Color);
    ptrName->setFrameBorderColor(Duke_Transparent_Color);
    ptrName->setTextColor(Default_PackageSheet_TextColor);
    m_names.push_back(ptrName);

    //update 
    calculatePackages();
    updateAll();
    repaint(event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:


