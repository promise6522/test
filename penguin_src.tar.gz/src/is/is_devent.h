/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

#ifndef DEVENT_H
#define DEVENT_H

//C++ 98 header files
#include <string>
#include <vector>

//boost header files
#include <boost/function.hpp>

#include "ac_message_type.h"
#include "stdx/stdx_socket.h"
#include "is_dpoint.h"
#include "is_dsize.h"
#include "is_dobject.h"
#include "is_dresourceunit.h"
#include "duke_media_base.h"

typedef boost::function<bool (byte_stream&)> is_response_call;

class DEvent
{
public:
    enum EventType {
        None,	// invalid event
        PassingIn,	// mouse enters widget
        PassingOut,	// mouse leaves widget
        Hover,	// mouse move in widget
        Focus, 	// focus received
        Blur,	// focus lost
        Select,
        Unselect,
        Delete,
        Detail,
        Activate,
        Deactivate,
        DnD_Start,
        DnD_Release,
        Drag,
        Grab,
        Release,
        Moving,
        Input,
        In,
        Out,
        Enlarge,	// enlarge widget
        Shrink,	// shrink widget
        Resize_Start,
        Resize_Release,
        TG01,
        TG02,
        TG03,
        TG04,
        TG05,
        TG06,
        TG07,
        TG08,
        TG09,
        TG10,
        Any,
    };

    DEvent()
        :m_eventType(DEvent::None)
    { }
    
    DEvent(is_response_call response_call, EventType eventType, const std::vector<DPath>& path,
           const DPoint& position, const DSize& eventSize,const std::vector<DResourceUnit>& resourceUnit,
           const std::string eventStr ="")
        : m_response_call(response_call),
          m_eventType(eventType),
          m_eventPoint(position),
          m_eventPath(path),
          m_eventSize(eventSize),
          m_eventResourceUnit(resourceUnit),
          m_eventText(eventStr)
    { }

    DEvent(is_response_call response_call, EventType eventType, const std::vector<DPath>& path,
           const duke_media_handle_vector& handles)
        : m_response_call(response_call),
          m_eventType(eventType),
          m_eventPath(path),
          m_handles(handles)
    { }
    
    DEvent(const DEvent& rEvent)
        : m_response_call(rEvent.getCon()),
          m_eventType(rEvent.getEventType()),
          m_eventPoint(rEvent.getEventPosition()),
          m_eventPath(rEvent.getEventPath()),
          m_eventSize(rEvent.getEventSize()),
          m_eventResourceUnit(rEvent.getEventResourceUnit()),
          m_eventText(rEvent.getEventText())
    { }

    virtual ~DEvent()
    {}
   
    DEvent& operator=(const DEvent& rEvent)
    {
        m_response_call = rEvent.getCon(),
        m_eventType = rEvent.getEventType();
        m_eventPoint = rEvent.getEventPosition();
        m_eventPath = rEvent.getEventPath();
        m_eventSize = rEvent.getEventSize();
        m_eventText = rEvent.getEventText();
        m_eventResourceUnit = rEvent.getEventResourceUnit();
        return *this;
    }


    EventType getEventType() const
    {
        return m_eventType;
    }

    std::string getEventText() const
    {
        return m_eventText;
    }

    const std::vector<DPath>& getEventPath() const
    {
        return m_eventPath;
    }

    const DPoint& getEventPosition() const
    {
        return m_eventPoint;
    }
    
    const is_response_call& getCon() const
    {
        return m_response_call;
    }

    const DSize& getEventSize() const
    {
        return m_eventSize;
    }

    void setEventPosition(const DPoint& pos)
    {
        m_eventPoint = pos;
    }

    void setEventResourceUnit(const std::vector<DResourceUnit>& resourceUnit)
    {
        m_eventResourceUnit = resourceUnit;
    }

    const std::vector<DResourceUnit>& getEventResourceUnit() const
    {
        return m_eventResourceUnit;
    }

    duke_media_handle_vector get_handles() const
    {
        return m_handles;
    }
    
protected:
    is_response_call m_response_call;    
    EventType m_eventType;
    DPoint m_eventPoint;
    std::vector<DPath> m_eventPath;
    DSize m_eventSize;
    std::vector<DResourceUnit> m_eventResourceUnit;
    std::string m_eventText;
    duke_media_handle_vector m_handles;    
};
#endif //DEVENT_H



// vim:set tabstop=4 shiftwidth=4 expandtab:
