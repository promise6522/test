/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Haijian Li 
**
****************************************************************************/
#include <vector>
#include "is_deventdistribution.h"
#include "is_dobject.h"


std::map<TGestureType,DEvent::EventType> DEventDistribution::m_mGesEvent;

void DEventDistribution::init()
{
    insertGesEventElement(PassingIn, DEvent::PassingIn);
    insertGesEventElement(PassingOut, DEvent::PassingOut);
    insertGesEventElement(Hover, DEvent::Hover); 
    insertGesEventElement(Focus, DEvent::Focus);
    insertGesEventElement(Blur, DEvent::Blur);
    insertGesEventElement(Select, DEvent::Select);
    insertGesEventElement(Unselect, DEvent::Unselect);
    insertGesEventElement(Detail, DEvent::Detail);
    insertGesEventElement(Delete, DEvent::Delete);
    insertGesEventElement(Activate, DEvent::Activate);
    insertGesEventElement(Deactivate, DEvent::Deactivate);
    insertGesEventElement(DnD_Start, DEvent::DnD_Start);
    insertGesEventElement(DnD_Release, DEvent::DnD_Release);
    insertGesEventElement(Drag, DEvent::Drag);
    insertGesEventElement(Grab, DEvent::Grab);
    insertGesEventElement(Release, DEvent::Release); 
    insertGesEventElement(Moving, DEvent::Moving);
    insertGesEventElement(Input, DEvent::Input);
    insertGesEventElement(In, DEvent::In);
    insertGesEventElement(Out, DEvent::Out);
    insertGesEventElement(Enlarge, DEvent::Enlarge);
    insertGesEventElement(Shrink, DEvent::Shrink); 
    insertGesEventElement(Resize_Start, DEvent::Resize_Start); 
    insertGesEventElement(Resize_Release, DEvent::Resize_Release);
    /*
    insertGesEventElement(TG01, DEvent::TG01);
    insertGesEventElement(TG02, DEvent::TG02);
    insertGesEventElement(TG03, DEvent::TG03);
    insertGesEventElement(TG04, DEvent::TG04);
    insertGesEventElement(TG05, DEvent::TG05);
    insertGesEventElement(TG06, DEvent::TG06);
    insertGesEventElement(TG07, DEvent::TG07);
    insertGesEventElement(TG08, DEvent::TG08);
    insertGesEventElement(TG09, DEvent::TG09);
    */
}

TGestureType DEventDistribution::getGestureByEventType(DEvent::EventType eventType)
{
    std::map<TGestureType, DEvent::EventType>::iterator iter = m_mGesEvent.begin();
    for (iter = m_mGesEvent.begin(); iter != m_mGesEvent.end(); iter++) {
        if (iter->second == eventType) {
            return iter->first;
        }
    }
    return Any;
}

void DEventDistribution::distribute_event(const TGesture& rGesture)
{
    if (Start == rGesture.type)
        return;
    
    DEvent::EventType eventType = m_mGesEvent[rGesture.type];
    std::vector<DPath> vPath;
    for(unsigned int pathIndex = 0; pathIndex < rGesture.path.size(); ++pathIndex)
    {
        vPath.push_back(DPath(rGesture.path[pathIndex].node));
    }
    DPoint position(0,0);
    DSize eventSize(0,0);    
    if(rGesture.visualSizes.size() > 0)
    {
        eventSize.setWidth(rGesture.visualSizes[0].width);
        eventSize.setHeight(rGesture.visualSizes[0].height);
    }
    if (rGesture.positions.size() > 0)
    {
         position.setX(rGesture.positions[0].x);
         position.setY(rGesture.positions[0].y);
    }
    std::vector<DResourceUnit> eventResourceUnit;
    for (unsigned int index = 0; index < rGesture.resources.size(); ++index)
    {
        const TResourceUnit& tResourceUnit = rGesture.resources[index];
        
        DMIME mime(tResourceUnit.resourceType.type_subType);
     
        DResourceUnit dResourceUnit(tResourceUnit.fileName,
                                    tResourceUnit.data, mime);
        eventResourceUnit.push_back(dResourceUnit);
    }
    DEvent event(m_response_call, eventType, vPath, position, eventSize, eventResourceUnit, rGesture.text);
    
    execute_event(event);    
}

void DEventDistribution::execute_event(const DEvent& event)
{
    const std::vector<DPath>& rControlPath = event.getEventPath();
    DObject* pObject = m_pTopWidget->findChild(rControlPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject);
    if (NULL != pWidget)
    {      
        pWidget->event(event);
    }
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
