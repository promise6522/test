/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author     State       Date
** Yinlii     Create      2010-03-19
****************************************************************************/

#include <boost/filesystem.hpp>

#include "is_dimage.h"

//Constructs a shallow copy of the given image. 
DImage::DImage(const DImage & image)   
    : m_relation(image.m_relation),
      m_xscale(image.m_xscale),
      m_yscale(image.m_yscale),
      m_margin(image.m_margin),
      m_byteNum(image.m_byteNum)
{
    if ((image.m_imageData != NULL) && (m_byteNum > 0)) {
        m_imageData = new unsigned char[m_byteNum + 1];
        memcpy(m_imageData, image.m_imageData, m_byteNum + 1);
    }
    else
    {
        m_imageData = NULL;
    }
}

DImage::~DImage()
{
    delete[] m_imageData;
    m_imageData = NULL;
}

//Loads image from a given file.
bool DImage::load(const std::string &fileName)
{
    std::fstream input;

    //if it is a directory, return false
    if(boost::filesystem::is_directory(fileName))
        return false;
    
    //Opens the file
    input.open(fileName.c_str(), std::ios::in|std::ios::binary);
    //Fails to open the file
    if (!input)
        return false;

    //Moves to the end of the file
    input.seekg(0, std::ios::end);
    //Gets the size of the file
    m_byteNum = input.tellg();
    if (m_byteNum <= 0)
        return false;

    
    //Moves to the begin of the file
    input.seekg(0, std::ios::beg);
    
    //Creates the memory for the image
    char * tempImageData = new char[m_byteNum + 1]; 
   
    if(m_imageData != NULL){
        delete[] m_imageData;
        m_imageData = NULL;
    }

    m_imageData = new unsigned char[m_byteNum + 1];

    //Reads the file to the buffer
    input.read(tempImageData, m_byteNum);
    //Gets the data from the temprate buffer
    memcpy(m_imageData, tempImageData, m_byteNum);
    m_imageData[m_byteNum] = '\0';
    //Releases the temporary memory
    delete[] tempImageData;

    //Closes the file
    input.close();
    input.clear();

    return true;
}

//Saves image to a given file
bool DImage::save(const std::string &fileName) const
{
    std::fstream output;

    //Opens the file
    output.open(fileName.c_str(), std::ios::ate|std::ios::out|std::ios::binary);
    //Fails to open the file
    if (!output)
        return false;

    if(m_imageData != NULL)
    {
        //changes unsigned char to char
        char * tempImageData = new char[m_byteNum];
        memcpy(tempImageData, m_imageData, m_byteNum);
        //Writes the buffer to the file
        output.write(tempImageData, m_byteNum);
        //Releases the temporary memory
        delete[] tempImageData;

    }

    //Closes the file
    output.close();
    output.clear();

    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
