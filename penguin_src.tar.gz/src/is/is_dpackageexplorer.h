#ifndef DPACKAGE_EXPLORER_H
#define DPACKAGE_EXPLORER_H

// Boost header files
#include <boost/tr1/memory.hpp>

// Duke header files
#include "is_ddialog.h"
#include "is_dlabel.h"
#include "is_dbutton.h"
#include "is_dlineedit.h"
#include "is_dimagelabel.h"

typedef std::vector<DButtonPtr> ExplorerItems;
typedef ExplorerItems::iterator ExplorerItemIt;
typedef ExplorerItems::size_type ExplorerItemIdx;

typedef std::vector<DLabelPtr> ExplorerTexts;
typedef ExplorerTexts::iterator ExplorerTextsIt;
typedef ExplorerTexts::size_type ExplorerTextsIdx;

typedef std::vector<DFramePtr> ExplorerViewLayers;
typedef ExplorerViewLayers::iterator ExplorerViewLayerIt;
typedef ExplorerViewLayers::size_type ExplorerViewLayerIdx;

class DPackageExplorer : public DEditor
{
public:
    explicit DPackageExplorer(int model = PanelModel, DMainWin * pMainWin = NULL,
                              DWidget * parent = 0);
    virtual ~DPackageExplorer();

    //set & get methods
    int explorerRowNum() const;
    int explorerColoumnNum() const;
    int getCurPagePos() const;
    std::string getSearchKeyWord() const;

    //misc
    ExplorerItemIdx getButtonItemIdx(DWidget * pWidget);
    
    //Init    
    virtual void initDialog();    

protected:
    //Event handle
    void processEnlargeEvent(const DEvent& rEvent);
    void processShrinkEvent(const DEvent& rEvent);
    void processResizeReleaseEvent(const DEvent& rEvent);
    void onActivate(const DEvent &event);
    void onHover(const DEvent &event);
    void onPassingOut(const DEvent &event);
    void onPassingInBtn(const DEvent &event);
    void onPassingOutBtn(const DEvent &event);

    //Button select event handle
    void onSearch(const DEvent &event);
    void onPrePage(const DEvent &event);
    void onUpLayer(const DEvent &event);
    void onNextPage(const DEvent &event);
    void onCreateNew(const DEvent &event);

    //menu event handle
    virtual void onClose(const DEvent& rEvent);

    //init
    void initControlBar();
    void initExplorerView();

private:
    void fillItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateItemsInViewLayer(DFrame * pViewLayer, int lineNum);
    void updateView();
    
protected:
    //the attribute
    int m_rowNum;
    int m_columnNum;
    int m_curPage;
    std::string m_searchKey;

    //control bar, see the style below
    //
    //  < ^ > New [Search]
    //
    DButtonPtr m_ptrNextPage;
    DButtonPtr m_ptrUpLayer;
    DButtonPtr m_ptrPrePage;
    DButtonPtr m_ptrCreate;
    DLineEditPtr m_ptrSearchKeyWord;
    DImageLabelPtr m_ptrSearchEditBg;
    DButtonPtr m_ptrSearchButton;
    
    //explorer view, see the style below
    // ________________________
    // |  item   item   item   |
    // |  text   text   text   |
    // |-----------------------| (explorer frame)
    //
    DFramePtr m_ptrWarehouseViewBg;
    ExplorerViewLayers m_viewLayers;
    ExplorerItems m_items;
    ExplorerTexts m_texts;
};

typedef std::tr1::shared_ptr<DPackageExplorer>  DPackageExplorerPtr;

const std::string Explorer_Item_DefaultName("N/A");

const std::string Explorer_ObjName("Package_Explorer");
const std::string Explorer_Title_Name("Package Explorer");

//default value for row & column
const int Explorer_Default_RowNum = 4;
const int Explorer_Default_ColumnNum = 5;

//the image for warehouse dialog
const std::string Explorer_SearchEditImg_FileName("warehouse_search_edit.png");
const std::string Explorer_NextPageImg_FileName("warehouse_next_page.png");
const std::string Explorer_NextPageSelImg_FileName("warehouse_next_page_sel.png");
const std::string Explorer_UpLayerImg_FileName("warehouse_up_page.png");
const std::string Explorer_UpLayerSelImg_FileName("warehouse_up_page_sel.png");
const std::string Explorer_PrePageImg_FileName("warehouse_pre_page.png");
const std::string Explorer_PrePageSelImg_FileName("warehouse_pre_page_sel.png");
const std::string Explorer_CreateImg_FileName("warehouse_create_button.png");

const std::string ExplorerItemImage_FileName("folder_close.png");
 
///////////////////////////////////////////////////////////////
//   Change this according to design (1366 * 768)
///////////////////////////////////////////////////////////////
const int Default_ExplorerWidth_Pixel = 433;
const int Default_ExplorerHeight_Pixel = 352;

const int Explorer_PrePageX_Pixel = 5;
const int Explorer_PrePageY_Pixel = 30;
const int Explorer_PrePageW_Pixel = 39;
const int Explorer_PrePageH_Pixel = 20;

const int Explorer_UpLayerX_Pixel = 45;
const int Explorer_UpLayerY_Pixel = 30;
const int Explorer_UpLayerW_Pixel = 39;
const int Explorer_UpLayerH_Pixel = 20;

const int Explorer_NextPageX_Pixel = 85;
const int Explorer_NextPageY_Pixel = 30;
const int Explorer_NextPageW_Pixel = 39;
const int Explorer_NextPageH_Pixel = 20;

const int Explorer_CreateX_Pixel = 130;
const int Explorer_CreateY_Pixel = 29;
const int Explorer_CreateW_Pixel = 40;
const int Explorer_CreateH_Pixel = 20;

const int Explorer_SearchX_Pixel = 173;
const int Explorer_SearchY_Pixel = 32;
const int Explorer_SearchW_Pixel = 252;
const int Explorer_SearchH_Pixel = 15;

const int Explorer_SearchEditX_Pixel = 183;
const int Explorer_SearchEditW_Pixel = 242;

const int Explorer_Layer_StartY_Pixel = 55;
const int Explorer_TotalLayer_H_Pixel = 290;
const int Explorer_Layer_H_Pixel = Explorer_TotalLayer_H_Pixel / Explorer_Default_RowNum;

const int Explorer_Icon_StartX_Pixel = 20;
const int Explorer_Icon_SpacingX_Pixel = 86;
const int Explorer_Icon_StartY_Pixel = 55;
const int Explorer_Icon_W_Pixel = 50;
const int Explorer_Icon_H_Pixel = 50;

const int Explorer_Text_StartX_Pixel = 7;
const int Explorer_Text_SpacingX_Pixel = 86;
const int Explorer_Text_StartY_Pixel = 109;
const int Explorer_Text_W_Pixel = 77;
const int Explorer_Text_H_Pixel = 14;

//auto-count pixel information for others
const int Explorer_ViewW_Pixel = Default_ExplorerWidth_Pixel;
const int Explorer_ViewH_Pixel = Default_ExplorerHeight_Pixel - Default_DlgTitleHeight_Pixel;

////////////////////////////////////////////////////////////////
//auto-count the related placement of warehouse in mainwin
////////////////////////////////////////////////////////////////
const int ExplorerX_InMainWin = 2000;
const int ExplorerY_InMainWin = 2000;
const int ExplorerW_InMainWin = Default_ExplorerWidth_Pixel * MAX_COORD / 1366;
const int ExplorerH_InMainWin = Default_ExplorerHeight_Pixel * MAX_COORD / 768;

////////////////////////////////////////////////////////////////
//   auto-count related placement of widgets in Explorer's view frame
///////////////////////////////////////////////////////////////
//previous page button
const int Explorer_PrePageX_InView = Explorer_PrePageX_Pixel * MAX_COORD/Explorer_ViewW_Pixel;
const int Explorer_PrePageY_InView = (Explorer_PrePageY_Pixel - Default_DlgTitleHeight_Pixel)
                                     * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_PrePageW_InView = Explorer_PrePageW_Pixel * MAX_COORD/Explorer_ViewW_Pixel;
const int Explorer_PrePageH_InView = Explorer_PrePageH_Pixel * MAX_COORD/Explorer_ViewH_Pixel;

//next page button
const int Explorer_UpLayerX_InView = Explorer_UpLayerX_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_UpLayerY_InView = (Explorer_UpLayerY_Pixel - Default_DlgTitleHeight_Pixel)
                                      * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_UpLayerW_InView = Explorer_UpLayerW_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_UpLayerH_InView = Explorer_UpLayerH_Pixel * MAX_COORD / Explorer_ViewH_Pixel;

//next page button
const int Explorer_NextPageX_InView = Explorer_NextPageX_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_NextPageY_InView = (Explorer_NextPageY_Pixel - Default_DlgTitleHeight_Pixel)
                                      * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_NextPageW_InView = Explorer_NextPageW_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_NextPageH_InView = Explorer_NextPageH_Pixel * MAX_COORD / Explorer_ViewH_Pixel;

//Create button
const int Explorer_CreateX_InView = Explorer_CreateX_Pixel 
                                    * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_CreateY_InView = (Explorer_CreateY_Pixel-Default_DlgTitleHeight_Pixel)
                                    * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_CreateW_InView = Explorer_CreateW_Pixel * MAX_COORD 
                                    / Explorer_ViewW_Pixel;
const int Explorer_CreateH_InView = Explorer_CreateH_Pixel * MAX_COORD 
                                    / Explorer_ViewH_Pixel;

//search line edit backgroud
const int Explorer_SearchX_InView = Explorer_SearchX_Pixel*MAX_COORD/Explorer_ViewW_Pixel;
const int Explorer_SearchY_InView = (Explorer_SearchY_Pixel - Default_DlgTitleHeight_Pixel)
                                    * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_SearchW_InView = Explorer_SearchW_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_SearchH_InView = Explorer_SearchH_Pixel * MAX_COORD / Explorer_ViewH_Pixel;

//search line edit 
const int Explorer_SearchEditX_InView = Explorer_SearchEditX_Pixel
                                        * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_SearchEditW_InView = Explorer_SearchEditW_Pixel * MAX_COORD 
                                        / Explorer_ViewW_Pixel;

//layers in Explorer
const int Explorer_Layer_X_InView = MIN_COORD;
const int Explorer_Layer_StartY_InView = (Explorer_Layer_StartY_Pixel
                                          - Default_DlgTitleHeight_Pixel)
                                          * MAX_COORD / Explorer_ViewH_Pixel;
const int Explorer_Layer_W_InView = MAX_COORD;
const int Explorer_TotalLayer_H_InView = Explorer_TotalLayer_H_Pixel * MAX_COORD
                                         /Explorer_ViewH_Pixel;
const int Explorer_Layer_H_InView = Explorer_Layer_H_Pixel * MAX_COORD / Explorer_ViewH_Pixel;

//icon in layer
const int Explorer_Icon_StartX_InLayer = Explorer_Icon_StartX_Pixel
                                         * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_Icon_SpacingX_InLayer = Explorer_Icon_SpacingX_Pixel
                                           * MAX_COORD / Explorer_ViewW_Pixel;

const int Explorer_Icon_Y_InLayer = (Explorer_Icon_StartY_Pixel-Explorer_Layer_StartY_Pixel)
                                    * MAX_COORD / Explorer_Layer_H_Pixel;
const int Explorer_Icon_W_InLayer = Explorer_Icon_W_Pixel * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_Icon_H_InLayer = Explorer_Icon_H_Pixel * MAX_COORD / Explorer_Layer_H_Pixel;

//text in layer
const int Explorer_Text_StartX_InLayer = Explorer_Text_StartX_Pixel
                                         * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_Text_SpacingX_InLayer = Explorer_Text_SpacingX_Pixel
                                           * MAX_COORD / Explorer_ViewW_Pixel;

const int Explorer_Text_Y_InLayer = (Explorer_Text_StartY_Pixel-Explorer_Layer_StartY_Pixel)
                                          * MAX_COORD / Explorer_Layer_H_Pixel;
const int Explorer_Text_W_InLayer = Explorer_Text_W_Pixel
                                    * MAX_COORD / Explorer_ViewW_Pixel;
const int Explorer_Text_H_InLayer = Explorer_Text_H_Pixel * MAX_COORD 
                                          / Explorer_Layer_H_Pixel;

#endif /* DPACKAGE_EXPLORER_H */
    
// vim:set tabstop=4 shiftwidth=4 expandtab:
