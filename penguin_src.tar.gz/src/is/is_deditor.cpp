/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

//boost header files
#include <boost/algorithm/string.hpp>

// Duke header files
#include "is_deditor.h"
#include "is_dmainwin.h"
#include "is_difeditor.h"
#include "is_dobjeditor.h"
#include "is_dimpleditor.h"
#include "is_ddecleditor.h"
#include "is_darrayeditor.h"
#include "is_dmapeditor.h"
#include "is_dbyteseditor.h"
#include "is_dapplication.h"

DEditor::DEditor(int model /* = DialogModel */,
                 DMainWin *pMainWin /* = NULL */,
                 DWidget *parent /* = 0 */,
                 WFlags f /* = 0 */)
    :DDialogEx(pMainWin, parent, f),
     m_editorModel(model),
     m_headHeight(Editor_HeadFrame_H_InMainWin),
     m_tailHeight(Editor_TailFrame_H_InMainWin),
     m_isModified(false),
     m_isReadOnly(false)
{
    setObjectName(Editor_ObjName);
}

DEditor::DEditor(const std::string &title,
                 int model /* = DialogModel */,
                 DMainWin *pMainWin /* = NULL */,
                 DWidget *parent /* = 0 */,
                 WFlags f /* = 0 */)
    :DDialogEx(title, pMainWin, parent, f),
     m_editorModel(model),
     m_headHeight(Editor_HeadFrame_H_InMainWin),
     m_tailHeight(Editor_TailFrame_H_InMainWin),
     m_isModified(false),
     m_isReadOnly(false)
{    
    setObjectName(Editor_ObjName);
}

DEditor::~DEditor()
{
}

//set & get method
int DEditor::headHeight() const
{
    return m_headHeight;    
}

void DEditor::setHeadHeight(int height)
{
    m_headHeight = height;    
}

int DEditor::tailHeight() const
{
    return m_tailHeight;
}    

void DEditor::setTailHeight(int height)
{
    m_tailHeight = height;    
}

int DEditor::editorModel() const
{
    return m_editorModel;
}

void DEditor::setEditorModel(int model)
{
    m_editorModel = model;
    updateEditorFrame();
}

//Init
void DEditor::initDialog()
{
    DDialogEx::initDialog();    

    //init
    initHeadFrame();
    initBodyFrame();
    initTailFrame();
    
    //update placement
    updateEditorFrame();    
}

void DEditor::initHeadFrame()
{
    //Head frame
    m_ptrHeadFrame.reset(new(std::nothrow) DFrame(getViewFrame()));
    assert(m_ptrHeadFrame.get() != NULL);
    m_ptrHeadFrame->setFrameStyle(DFrame::Panel);
    m_ptrHeadFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrHeadFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrHeadFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrHeadFrame->setAutoFill(false);

    //pass through message
    passThroughMessages(m_ptrHeadFrame.get());

    //Name background
    DImage img;
    img.load(getResPath() + Editor_NameImg_FileName);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    m_ptrDukeName.reset(new(std::nothrow) DImageLabel("", img, m_ptrHeadFrame.get()));
    assert(m_ptrDukeName.get() != NULL);
    m_ptrDukeName->setGeometry(Editor_Name_X_InHead, Editor_Name_Y_InHead,
                               Editor_Name_W_InHead, Editor_Name_H_InHead);
    m_ptrDukeName->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDukeName->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrDukeName->setAutoFill(false);
    m_ptrDukeName->registerEvent(DEvent::DnD_Start, true);
    //m_ptrDukeName->registerEvent(DEvent::Drag, true);
    m_ptrDukeName->registerEvent(DEvent::DnD_Release, true);
    m_ptrDukeName->registerEvent(DEvent::Detail, true);

    //Name Edit
    m_ptrNameEdit.reset(new(std::nothrow) DLineEdit(m_ptrHeadFrame.get()));
    assert(m_ptrNameEdit.get() != NULL);
    m_ptrNameEdit->setGeometry(Editor_NameEdit_X_InHead, Editor_NameEdit_Y_InHead,
                               Editor_NameEdit_W_InHead, Editor_NameEdit_H_InHead);
    m_ptrNameEdit->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNameEdit->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrNameEdit->setEventRoutine(DEvent::Input, this,
                                   (EventRoutine)(&DEditor::onInputMsg));
    m_ptrNameEdit->setAlignment(AlignCenter);

    //Icon
    img.load(getResPath() + Editor_IconImg_FileName);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    m_ptrDukeIcon.reset(new(std::nothrow) DImageLabel("", img, m_ptrHeadFrame.get()));
    assert(m_ptrDukeIcon.get() != NULL);
    m_ptrDukeIcon->setGeometry(Editor_Icon_X_InHead, Editor_Icon_Y_InHead,
                               Editor_Icon_W_InHead, Editor_Icon_H_InHead);
    m_ptrDukeIcon->setBackgroundColor(Duke_Transparent_Color);
    m_ptrDukeIcon->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrDukeIcon->setAutoFill(false);
    m_ptrDukeIcon->registerEvent(DEvent::DnD_Start, true);
    //m_ptrDukeIcon->registerEvent(DEvent::Drag, true);
    m_ptrDukeIcon->registerEvent(DEvent::Detail, true);
    m_ptrDukeIcon->registerEvent(DEvent::DnD_Release);
    m_ptrDukeIcon->setEventRoutine(DEvent::DnD_Release, this,
                                   (EventRoutine)(&DEditor::onReleaseIcon));
    
    //Icon Edit
    /*
    m_ptrIconEdit.reset(new(std::nothrow) DLineEdit(m_ptrHeadFrame.get()));
    assert(m_ptrIconEdit.get() != NULL);
    m_ptrIconEdit->setGeometry(Editor_IconEdit_X_InHead, Editor_IconEdit_Y_InHead,
                               Editor_IconEdit_W_InHead, Editor_IconEdit_H_InHead);
    m_ptrIconEdit->setBackgroundColor(Duke_Transparent_Color);
    m_ptrIconEdit->setFrameBorderColor(Duke_Transparent_Color);    
    m_ptrIconEdit->setEventRoutine(DEvent::Input, this,
                                   (EventRoutine)(&DEditor::onInputMsg)); 
    */  
}

void DEditor::initBodyFrame()
{
    //Body frame
    m_ptrBodyFrame.reset(new(std::nothrow) DFrame(getViewFrame()));
    assert(m_ptrBodyFrame.get() != NULL);
    m_ptrBodyFrame->setFrameStyle(DFrame::Panel);
    m_ptrBodyFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrBodyFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrBodyFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrBodyFrame->setAutoFill(false);

    //pass through message
    passThroughMessages(m_ptrBodyFrame.get());

    //Sel frame
    initSelFrame();
}

void DEditor::initTailFrame()
{
    //Tail frame
    m_ptrTailFrame.reset(new(std::nothrow) DFrame(getViewFrame()));
    assert(m_ptrTailFrame.get() != NULL);
    m_ptrTailFrame->setFrameStyle(DFrame::Panel);
    m_ptrTailFrame->setDisplayOrder(Default_Dialog_DisplayOrder);
    m_ptrTailFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrTailFrame->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrTailFrame->setAutoFill(false);

    //pass through message
    passThroughMessages(m_ptrTailFrame.get());

    //Generation button
    DImage img;
    img.load(getResPath() + Editor_GenerationImg_FileName);
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;
    selImg.load(getResPath() + Editor_GenerationSelImg_FileName);
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    m_ptrGeneration.reset(new(std::nothrow) DButton("",
                                                    img,
                                                    selImg,
                                                    m_ptrTailFrame.get()));
    assert(m_ptrGeneration.get() != NULL);
    m_ptrGeneration->setGeometry(Editor_Generate_X_InHead, Editor_Generate_Y_InHead,
                                 Editor_Generate_W_InHead, Editor_Generate_H_InHead);
    m_ptrGeneration->setBackgroundColor(Duke_Transparent_Color);
    m_ptrGeneration->registerEvent(DEvent::DnD_Start, true);
    //m_ptrGeneration->registerEvent(DEvent::Drag, true);
    m_ptrGeneration->registerEvent(DEvent::DnD_Release, true);
    m_ptrGeneration->registerEvent(DEvent::Detail, true);
    m_ptrGeneration->registerEvent(DEvent::Hover);
    m_ptrGeneration->registerEvent(DEvent::PassingOut);
    m_ptrGeneration->setEventRoutine(DEvent::Select,
                                     this,
                                     static_cast<EventRoutine>(&DEditor::onGenerate));  
    m_ptrGeneration->setEventRoutine(DEvent::Hover,
                                     this,
                                     static_cast<EventRoutine>(&DEditor::onHoverGen)); 
    m_ptrGeneration->setEventRoutine(DEvent::PassingOut,
                                     this,
                                     static_cast<EventRoutine>(&DEditor::onPassingOutGen)); 
    m_ptrGeneration->setSelected(false);
}

void DEditor::initSelFrame()
{
    //Sel frame
    m_ptrSelFrame.reset(new(std::nothrow) DFrame(getBodyFrame()));
    assert(m_ptrSelFrame.get() != NULL);
    m_ptrSelFrame->setFrameStyle(DFrame::Panel);
    m_ptrSelFrame->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSelFrame->setFrameBorderColor(Default_SelFrame_Color);
    m_ptrSelFrame->setAutoFill(false);
    m_ptrSelFrame->setHideProperty(true);
    m_ptrSelFrame->rframePenStroke().setStyle(DPenStroke::M_dot_dash);

    //pass through message
    passThroughMessages(m_ptrSelFrame.get());
}

//update the editor's inside placement
void DEditor::updateEditorFrame()
{
    int startY = MIN_COORD;
    int leftY = MAX_COORD;
    
    //dose it show title?
    if(m_editorModel &  DEditor::TitleModel)
    {
        hideTitle(false);
    }
    else
    {
        hideTitle(true);
    }

    //dose it show header?
    if(m_ptrHeadFrame.get() != NULL)
    {
        if( m_editorModel & DEditor::HeaderModel )
        {
            m_ptrHeadFrame->setGeometry(MIN_COORD, MIN_COORD,
                                        MAX_COORD, m_headHeight);
            leftY -= m_headHeight;        
            startY += m_headHeight;
        }
        else
        {
            m_ptrHeadFrame->setGeometry(0, 0, 0, 0);
        }
    }

    //dose it show tail?
    if(m_ptrTailFrame.get() != NULL)
    {
        if(m_editorModel & DEditor::TailModel)
        {
            m_ptrTailFrame->setGeometry(MIN_COORD, MAX_COORD - m_tailHeight,
                                        MAX_COORD, m_tailHeight);
            leftY -= m_tailHeight;        
        }
        else
        {
            m_ptrTailFrame->setGeometry(0, 0, 0, 0);
        }
    }

    //dose it show body?
    if(m_ptrBodyFrame.get() != NULL)
    {
        if(m_editorModel &  DEditor::BodyModel)
        {
            m_ptrBodyFrame->setGeometry(MIN_COORD, startY,
                                        MAX_COORD, leftY);
        }
        else
        {
            m_ptrBodyFrame->setGeometry(0, 0, 0, 0);
        }
    }
}

//get view frames
DFrame * DEditor::getHeadFrame()
{
    return m_ptrHeadFrame.get();
}

DFrame * DEditor::getBodyFrame()
{
    return m_ptrBodyFrame.get();
}
DFrame * DEditor::getTailFrame()
{
    return m_ptrTailFrame.get();
}

DFrame * DEditor::getSelFrame()
{
    return m_ptrSelFrame.get();
}

void DEditor::insertSubEditor(DWidget *pWidget, DEditorPtr subEditor)
{
    if((pWidget == NULL) || (subEditor.get() == NULL))
    {
        assert(!"widget and subEditor could not be NULL!");
        return;
    }

    subEditor->setDisplayOrder(displayOrder() - 1);    
    m_subEditors.push_back(subEditor);

    m_widgetEditorMap.insert(DWidgetEditorPair(pWidget, subEditor.get()));
}

DWidget * DEditor::findWidgetBySubEditor(DEditor * pEditor)
{
    for(DWidgetEditorMapIt it = m_widgetEditorMap.begin(); it != m_widgetEditorMap.end(); ++it)
    {
        if(it->second == pEditor)
        {
            return it->first;
        }
    }

    return NULL;        
}

DEditor * DEditor::findSubEditorByWidget(DWidget * pWidget)
{
    DWidgetEditorMapIt it = m_widgetEditorMap.find(pWidget);
    if(it != m_widgetEditorMap.end())
    {
        return it->second;
    }
    else
    {
        return NULL;
    }
}

void DEditor::eraseSubEditor(DWidget *pWidget)
{
    DEditor *pSubEditor = findSubEditorByWidget(pWidget);
    if(pSubEditor == NULL)
    {
        assert(!"Could not find the del editor");
        return;
    }

    eraseSubEditor(pSubEditor);
}

void DEditor::eraseSubEditor(DEditor *pDelEditor)
{
    SubEditorIt it = m_subEditors.begin();

    for (; it != m_subEditors.end(); ++it)
    {
        DEditor *pEditor = (*it).get();
        if(pEditor == pDelEditor)
        {
            DWidget *pWidget = findWidgetBySubEditor(pEditor);
            if(pEditor != NULL)
            {
                m_widgetEditorMap.erase(pWidget);
                m_subEditors.erase(it);
                return;
            }
        }
    }

    assert(!"Could not find the del editor");
}

void DEditor::hideSubEditor(DWidget *pWidget)
{
    DEditor *pEditor = findSubEditorByWidget(pWidget);
    pEditor->setHideProperty(true);
}

void DEditor::hideSubEditor(DEditor *pEditor)
{
    pEditor->setHideProperty(true);
}

SubEditors * DEditor::subEditors()
{
    return &m_subEditors;
}

//translate Gemoetry in MainWin
DPoint DEditor::translatePosToMainWin(DWidget *pWidget, DPoint pos)
{
    if((pWidget == NULL) || (pWidget->parent() == NULL))
        return pos;
    
    DWidget *p = dynamic_cast<DWidget *>(pWidget->parent());

    while( (p != NULL) && (p != m_pMainWin->getRootWidget()) )
    {
        DPoint pPos = p->geometryPos();
        DSize pSize = p->geometrySize();
        pos.setX(pos.x() * pSize.width() / MAX_COORD + pPos.x());
        pos.setY(pos.y() * pSize.height() / MAX_COORD + pPos.y());

        p = dynamic_cast<DWidget *>(p->parent());
    }

    return pos;
}

//translate Gemoetry in MainWin
DPoint DEditor::translatePosToEditor(DWidget *pWidget, DPoint pos)
{
    if((pWidget == NULL) || (pWidget->parent() == NULL))
        return pos;
    
    DWidget *p = dynamic_cast<DWidget *>(pWidget->parent());

    while( (p != NULL) && (p != this) )
    {
        DPoint pPos = p->geometryPos();
        DSize pSize = p->geometrySize();
        pos.setX(pos.x() * pSize.width() / MAX_COORD + pPos.x());
        pos.setY(pos.y() * pSize.height() / MAX_COORD + pPos.y());

        p = dynamic_cast<DWidget *>(p->parent());
    }

    return pos;
}

//update placement
void DEditor::adjustPlacement()
{
    DDialogEx::adjustPlacement();

    if((m_ptrHeadFrame.get() != NULL) && (geometrySize().height() != 0) 
       && (getViewFrame()->geometrySize().height() != 0))
    {
        int height = Editor_HeadFrame_H_InMainWin * MAX_COORD / geometrySize().height(); 
        m_headHeight = height *  MAX_COORD / getViewFrame()->geometrySize().height();         
    }
    else
    {
        m_headHeight = 0;
    }

    if((m_ptrTailFrame.get() != NULL) && (geometrySize().height() != 0) 
       && (getViewFrame()->geometrySize().height() != 0))
    {
        int height = Editor_TailFrame_H_InMainWin * MAX_COORD / geometrySize().height(); 
        m_tailHeight = height *  MAX_COORD / getViewFrame()->geometrySize().height();         
    }
    else
    {
        m_tailHeight = 0;
    }

    updateEditorFrame();
}

duke_media_handle DEditor::generate()
{
    //save name and icon 
    saveName();
    saveIcon();
    return duke_media_handle_null;
}

void DEditor::generateSubItems()
{
}

DEditor * DEditor::createSubEditor(DWidget *pSrcWidget)
{
    if (!pSrcWidget || !pSrcWidget->getMedia())
        return NULL;

    DEditor * pSubEditor = findSubEditorByWidget(pSrcWidget);
    if (pSubEditor)
        return pSubEditor;

    if (pSrcWidget->getMedia()->is_interface())
    {

        if(!pSrcWidget->getMedia()->is_interface_compound())
            return NULL;        
        
        // Create new IFEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        DIFEditorPtr ptrEditor(new(std::nothrow) DIFEditor(IFEditor_ObjName, 
                                                           DEditor::PanelModel,
                                                           pMainWin,
                                                           pMainWin->getRootWidget()));
        insertSubEditor(pSrcWidget, ptrEditor);
        ptrEditor->initDialog();

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                Default_IFEditor_W_InMainWin, 
                Default_IFEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
        // Initialize the editor after inserting widget
        ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
        ptrEditor->initIFEditor(false);
        if (e_handle_core == get_media_handle_status(pSrcWidget->getMediaHandle()))
        {
            ptrEditor->setReadonly();
        }        

        if(m_isReadOnly)
        {
            ptrEditor->setReadonly();
        }
        
        return ptrEditor.get();
    }
    else if (pSrcWidget->getMediaHandle().is_declaration())
    {

        // Create new DeclEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        DDeclEditorPtr ptrEditor(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                                                               DEditor::PanelModel,
                                                               pMainWin,
                                                               pMainWin->getRootWidget()));
        ptrEditor->initDialog();
        insertSubEditor(pSrcWidget, ptrEditor);

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                               Default_DeclEditor_W_InMainWin, 
                               Default_DeclEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
        // Initialize the editor after inserting widget
        if (e_handle_core != get_media_handle_status(pSrcWidget->getMediaHandle()))
        {            
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initDeclEditor();
        }        
        else
        {
            //it means we will to change the the declaration.
            //ptrEditor->duplicateItemsByHandle(pSrcWidget->getMediaHandle());
            //set back temp interface id to button
            //pSrcWidget->setMediaByHandle(ptrEditor->getMediaHandle());
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initDeclEditor();
            //do not allow to change declaration in sub editor
            ptrEditor->setReadonly();
        }

        if(m_isReadOnly)
        {
            ptrEditor->setReadonly();
        }
        return ptrEditor.get();
    }
    else if (pSrcWidget->getMedia()->is_object_builtin())
    {
        // Create new IFEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        
        if (pSrcWidget->getMedia()->is_object_array())
        {
            //force to copy the array even if it is generated.
            duke_media_handle handle = pSrcWidget->getMediaHandle();
            duke_media_array ary_media(handle);
            handle = ary_media.clone_new_handle(getApplication()->get_host_committer_id());
            pSrcWidget->setMediaByHandle(handle);
            
            // Create new arrayEditor with BodyModel
            DArrayEditorPtr ptrEditor(new(std::nothrow) DArrayEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->setMediaByHandle(handle);

            ptrEditor->initDialog();
            ptrEditor->initArrayEditor();
            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                                   Default_ArrayEditor_W_InMainWin, Default_ArrayEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            if(m_isReadOnly)
            {
                ptrEditor->setReadonly();
            }
            return ptrEditor.get();
        }
        else if (pSrcWidget->getMedia()->is_object_map())
        {
            //force to copy the array even if it is generated.
            duke_media_handle handle = pSrcWidget->getMediaHandle();
            duke_media_map map_media(handle);
            handle = map_media.clone_new_handle(getApplication()->get_host_committer_id());
            pSrcWidget->setMediaByHandle(handle);
            
            // Create new arrayEditor with BodyModel
            DMapEditorPtr ptrEditor(new(std::nothrow) DMapEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

            ptrEditor->initDialog();
            ptrEditor->initMapEditor();
            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_MapEditor_W_InMainWin, 
                    Default_MapEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);


            if(m_isReadOnly)
            {
                ptrEditor->setReadonly();
            }
            return ptrEditor.get();
        }
        else if (pSrcWidget->getMedia()->is_object_bytes())
        {
            //force to copy the bytes even if it is generated.
            duke_media_handle handle = pSrcWidget->getMediaHandle();
            duke_media_bytes bytes_media(handle);
            handle = bytes_media.clone_new_handle(getApplication()->get_host_committer_id());
            pSrcWidget->setMediaByHandle(handle);
            
            // Create new arrayEditor with BodyModel
            DBytesEditorPtr ptrEditor(new(std::nothrow) DBytesEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());

            ptrEditor->initDialog();
            ptrEditor->initBytesEditor();
            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_MapEditor_W_InMainWin, 
                    Default_MapEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            if(m_isReadOnly)
            {
                ptrEditor->setReadonly();
            }
            return ptrEditor.get();            
        }
        else if (pSrcWidget->getMedia()->is_object_string())
        {
             //force to copy the bytes even if it is generated.
            duke_media_handle handle = pSrcWidget->getMediaHandle();
            duke_media_string str_media(handle);
            handle = str_media.clone_new_handle(getApplication()->get_host_committer_id());
            pSrcWidget->setMediaByHandle(handle);

            // Create new IFEditor with BodyModel
            DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->initDialog();

            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_InputEditor_W_InMainWin, 
                    Default_InputEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            // Set initial value
            std::string value;
            if (pSrcWidget->getMediaValue(value))
                ptrEditor->setInputString(value);

            if(m_isReadOnly)
            {
                ptrEditor->setReadonly();
            }
            return ptrEditor.get();
        }
        else
        {
            // Create new IFEditor with BodyModel
            DInputEditorPtr ptrEditor(new(std::nothrow) DInputEditor(BodyModel,
                        pMainWin,
                        pMainWin->getRootWidget()));
            insertSubEditor(pSrcWidget, ptrEditor);
            ptrEditor->initDialog();

            ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                    Default_InputEditor_W_InMainWin, 
                    Default_InputEditor_H_InMainWin);
            ptrEditor->setDisplayOrder(displayOrder() - 1);

            // Set initial value
            std::string value;
            if (pSrcWidget->getMediaValue(value))
                ptrEditor->setInputString(value);

            if(m_isReadOnly)
            {
                ptrEditor->setReadonly();
            }
            return ptrEditor.get();
        }
    }    
    else if (pSrcWidget->getMediaHandle().is_implementation())
    {
        // Create new DeclEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        DImplEditorPtr ptrEditor(new(std::nothrow) DImplEditor(ImplEditor_ObjName, 
                                                               DEditor::PanelModel,
                                                               pMainWin,
                                                               pMainWin->getRootWidget()));

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                               Default_IFEditor_W_InMainWin, 
                               Default_IFEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
        

        // Initialize the editor after inserting widget
        if (e_handle_core != get_media_handle_status(pSrcWidget->getMediaHandle()))
        {            
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initDialog();
        }        
        else if(pSrcWidget->getMediaHandle().is_object_exec_iterator())
        {
            duke_media_handle himpl;
            duke_media_get_impl_from_iterator(pSrcWidget->getMediaHandle(),himpl);
            ptrEditor->setMediaByHandle(himpl);
            ptrEditor->initDialog();
            ptrEditor->setReadonly();
        }
        else if(pSrcWidget->getMediaHandle().is_object_exec_condition())
        {
            duke_media_handle himpl;
            duke_media_get_impl_from_condition(pSrcWidget->getMediaHandle(),himpl);
            ptrEditor->setMediaByHandle(himpl);
            ptrEditor->initDialog();
            ptrEditor->setReadonly();
        }
        else
        {
            /*
            //it means we will to change the the declaration.
            ptrEditor->duplicateItemsByHandle(pSrcWidget->getMediaHandle());
            //set back temp interface id to button
            pSrcWidget->setMediaByHandle(ptrEditor->getMediaHandle()); 
            ptrEditor->initDialog();
            */
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initDialog();
            ptrEditor->setReadonly();
        }

        insertSubEditor(pSrcWidget, ptrEditor);

        if(m_isReadOnly)
        {
            ptrEditor->setReadonly();
        }
        return ptrEditor.get();
    }
    else if (pSrcWidget->getMedia()->is_object())
    {

        if(pSrcWidget->getMedia()->is_object_bridge())
            return NULL;
        
        // Create new ObjEditor with BodyModel
        DMainWin * pMainWin = m_pMainWin;
        DObjEditorPtr ptrEditor(new(std::nothrow) DObjEditor(ObjEditor_ObjName, 
                                                             DEditor::PanelModel,
                                                             pMainWin,
                                                             pMainWin->getRootWidget()));
        ptrEditor->initDialog();
        insertSubEditor(pSrcWidget, ptrEditor);

        // Get the postion in mainwin        
        DPoint posInCell(pSrcWidget->geometryX() + pSrcWidget->geometrySize().width(), 
                         pSrcWidget->geometryY());
        DPoint posInMain = translatePosToMainWin(pSrcWidget, posInCell);
        ptrEditor->setGeometry(posInMain.x(), posInMain.y(), 
                               Default_ObjEditor_W_InMainWin, 
                               Default_ObjEditor_H_InMainWin);
        ptrEditor->setDisplayOrder(displayOrder() - 1);
        // Initialize the editor after inserting widget
        if (e_handle_core != get_media_handle_status(pSrcWidget->getMediaHandle()))
        {            
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initObjEditor();
        }        
        else
        {
            /*
            //it means we will to change the the declaration.
            ptrEditor->duplicateItemsByHandle(pSrcWidget->getMediaHandle());
            //set back temp interface id to button
            pSrcWidget->setMediaByHandle(ptrEditor->getMediaHandle());
            */
            ptrEditor->setMediaByHandle(pSrcWidget->getMediaHandle());
            ptrEditor->initObjEditor();
            ptrEditor->setReadonly();            
        }

        if(m_isReadOnly)
        {
            ptrEditor->setReadonly();
        }
        return ptrEditor.get();
    }

    return NULL;
}

void DEditor::reload()
{
}

void DEditor::updateSubEditors()
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();
        if(pEditor != NULL)
        {
            DWidget * pWidget = findWidgetBySubEditor(pEditor);
            if(pWidget != NULL)
            {
                DPoint posInCell(pWidget->geometryX() + pWidget->geometrySize().width(), 
                                 pWidget->geometryY());
                DPoint posInMain = translatePosToMainWin(pWidget, posInCell);
                pEditor->setGeometry(posInMain.x(),
                                     posInMain.y(),
                                     pEditor->geometrySize().width(),
                                     pEditor->geometrySize().height());
                pEditor->updateAll();
            }

            pEditor->updateSubEditors();
        }
    }
}

void DEditor::repaintSubEditors(const is_response_call& response_call, bool hasData)
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();
        if(pEditor != NULL)
        {
            DWidget * pWidget = findWidgetBySubEditor(pEditor);
            if(pWidget != NULL)
            {
                DPoint posInCell(pWidget->geometryX() + pWidget->geometrySize().width(), 
                                 pWidget->geometryY());
                DPoint posInMain = translatePosToMainWin(pWidget, posInCell);
                pEditor->setGeometry(posInMain.x(),
                                     posInMain.y(),
                                     pEditor->geometrySize().width(),
                                     pEditor->geometrySize().height());
                pEditor->updateAll();
                pEditor->repaint(response_call, hasData);
            }
        }
    }
}

void DEditor::hideAllSubEditors(const is_response_call& response_call)
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();        
        if(pEditor != NULL)
        {
            pEditor->setHideProperty(true);
            pEditor->updateAll();            
            pEditor->repaint(response_call, false);
        }
    }
}

void DEditor::destorySubEditors(const is_response_call& response_call)
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();        
        if(pEditor != NULL)
        {
            pEditor->destorySubEditors(response_call);
            pEditor->destory(response_call);
        }
    }
}

void DEditor::clearSubEditors()
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();        
        if(pEditor != NULL)
        {
            pEditor->clearSubEditors();
        }
    }
    m_subEditors.clear();
    m_widgetEditorMap.clear();
}

void DEditor::setSubEditorsOrder(int order)
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();        
        if(pEditor != NULL)
        {
            pEditor->setSubEditorsOrder(order - 1);
            pEditor->setDisplayOrder(order);            
            pEditor->updateAll();
        }
    }    
}

void DEditor::setReadonly()
{
    // for name input
    m_ptrNameEdit->unRegisterEvent(DEvent::Input);
    m_ptrNameEdit->setLocalEditable(false);

    // for icon input
    m_ptrDukeIcon->unRegisterEvent(DEvent::DnD_Release);
    //m_ptrIconEdit->unRegisterEvent(DEvent::Input);
    //m_ptrIconEdit->setLocalEditable(false);   

    // for generation btn
    m_ptrGeneration->unRegisterEvent(DEvent::Select);
    m_ptrGeneration->unRegisterEvent(DEvent::Hover);
    m_ptrGeneration->unRegisterEvent(DEvent::PassingOut);
    
    m_isReadOnly = true;
}

bool DEditor::isModified()
{
    return m_isModified;
}

void DEditor::setModified(bool modified)
{
    m_isModified = modified;
}
void DEditor::processEnlargeEvent(const DEvent& event)
{
    DDialog::processEnlargeEvent(event);
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);    
}

void DEditor::processShrinkEvent(const DEvent& event)
{
    DDialog::processShrinkEvent(event);
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);    
}

void DEditor::processDetailEvent(const DEvent& event)
{
    //Disable the menu if not dialogmodel
    if(m_editorModel & TitleModel)
    {
        DDialog::processDetailEvent(event);
    }    
}

void DEditor::processResizeReleaseEvent(const DEvent& event)
{
    DDialog::processResizeReleaseEvent(event);
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);    
}

void DEditor::onMaximize(const DEvent& event)
{
    DDialog::onMaximize(event);    
    updateSubEditors();
    repaintSubEditors(event.getCon(), false);    
}

void DEditor::onMinimize(const DEvent& event)
{
    DDialog::onMinimize(event);
    hideAllSubEditors(event.getCon());    
}

void DEditor::onRestore(const DEvent& event)
{
    DDialog::onRestore(event);   
    updateSubEditors(); 
    repaintSubEditors(event.getCon(), false);
}

void DEditor::onClose(const DEvent& event)
{
    for(SubEditorIt it = m_subEditors.begin(); it != m_subEditors.end(); ++it)
    {
        DEditor * pEditor = (*it).get();        
        if(pEditor != NULL)
        {
            pEditor->destorySubEditors(event.getCon());
            pEditor->destory(event.getCon());
        }
    }    

    DDialog::onClose(event);
}

//----------------------Event handle-------------------------
void DEditor::onInputMsg(const DEvent &event)
{
    const std::vector<DPath>& rWidgetPath = event.getEventPath();
    DWidget * pWidget = static_cast<DWidget *>(findChild(rWidgetPath[0]));

    m_isModified = true;

    if(pWidget == m_ptrNameEdit.get())
    {        
        m_ptrNameEdit->onInputEvent(event);
        m_dukeName = m_ptrNameEdit->content();
        saveName();
        pWidget->repaint(event.getCon());
    }
    /*
    else if(pWidget == m_ptrIconEdit.get())
    {
        //m_ptrIconEdit->onInputEvent(event);
        //m_dukeIcon = m_ptrIconEdit->content();
        //saveIcon();
    }*/
    else
    {
        assert(!"Unkown Input Edit.");
    }

     if(m_ptr == NULL)
        return;

     m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DEditor::saveName()
{
    if(m_ptr == NULL)
    {
        m_generateErrorInfo = "no duke media";
        return;
    }

    //Save Name
    if(!m_dukeName.empty())
    {
        m_ptr->set_name(m_dukeName);
    }
    else
    {
        m_generateErrorInfo = "lost name";
    }
}

void DEditor::onReleaseIcon(const DEvent& event)
{
    //check if the source path is local
    const std::vector<DPath>& widgetPath = event.getEventPath();\
    if(widgetPath[1][0] != -1)
        return;

    const std::vector<DResourceUnit>& resUnits = event.getEventResourceUnit();
    if(resUnits.empty())
        return;

    //only deal with first image resource
    for(size_t i = 0; i < resUnits.size(); ++i)
    {
        const std::vector<uint8_t>& data = resUnits[i].data();
        if(boost::istarts_with(resUnits[i].MIME().m_subType, "image") && data.size() > 0)
        {
            m_dukeIcon = toString(&data[0], data.size());
            break;
        }
    }

    saveIcon();
    
    m_pMainWin->synchronizeEditors(event.getCon(), this);
}

void DEditor::saveIcon()
{
    if(m_ptr == NULL)
    {
        m_generateErrorInfo = "no duke media";
        return;
    }

    if(m_dukeIcon.size() > 0)
    {
        m_ptr->set_icon(m_dukeIcon);
    }
    else
    {        
        m_ptr->set_icon("");
    }
}

void DEditor::onGenerate(const DEvent &event)
{
    std::cout<<"Generate the Duke Item"<<std::endl;
    m_pMainWin->dumpObjectTree();

    saveName();
    saveIcon();
}

void DEditor::onHoverGen(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(true);
        pButton->updateAll();
        getApplication()->tip()->add(pButton, m_generateErrorInfo, event.getCon());
        pButton->repaint(event.getCon());
    }
}

void DEditor::onPassingOutGen(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        getApplication()->tip()->remove(event.getCon());
        pButton->repaint(event.getCon());
    }
}

void DEditor::adjustIconForExpand(DButton* pButton)
{
    if(!pButton)
    {
        return;
    }

    DImage buttonImage;
    buttonImage.setRelation(DImage::KeepSmall);

    duke_media_interface * pif
        = dynamic_cast<duke_media_interface *>(pButton->getMedia());    
    duke_media_compound_interface * pcomif
        = dynamic_cast<duke_media_compound_interface *>(pButton->getMedia());

    if(pif)
    {
        if(pif->is_interface_array())
        {
            buttonImage.load(get_builtin_resource_path() + Editor_ArrayImg_FileName);
            pButton->setImage(buttonImage);
        }
        else if(pif->is_interface_map())      
        {
            buttonImage.load(get_builtin_resource_path() + Editor_MapImg_FileName);
            pButton->setImage(buttonImage);
        }
    }

    if(pcomif)
    {
        if(pcomif->is_interface_array())
        {
            buttonImage.load(get_builtin_resource_path() + Editor_ArrayExImg_FileName);
            pButton->setImage(buttonImage);
        }
        else if(pcomif->is_interface_map())      
        {
            buttonImage.load(get_builtin_resource_path() + Editor_MapExImg_FileName);
            pButton->setImage(buttonImage);
        }
    }
}


///////////////////////////////////////////////////////////////////////
//    Input Editor
//////////////////////////////////////////////////////////////////////

DInputEditor::DInputEditor(int model /* = BodyModel */,
                           DMainWin *pMainWin /* = NULL */,
                           DWidget *parent /* = 0 */,
                           WFlags f /* = 0 */)
    :DEditor(model, pMainWin, parent, f)
{
    setObjectName(InputEditor_ObjName);
}

DInputEditor::~DInputEditor()
{    
}

void DInputEditor::initDialog()
{
    DEditor::initDialog();

    m_ptrBorder->setHideProperty(true);

    //init input background
    DImage img;
    img.load(getResPath() + Input_EditImg_FileName);
    m_ptrInputEditBg.reset(new(std::nothrow) DImageLabel("", img, getBodyFrame()));
    assert(m_ptrInputEditBg.get() != NULL);
    m_ptrInputEditBg->setGeometry(MIN_COORD, MIN_COORD,
                                  MAX_COORD, MAX_COORD);
    m_ptrInputEditBg->setBackgroundColor(Duke_Transparent_Color);
    m_ptrInputEditBg->setFrameBorderColor(Duke_Transparent_Color);    
    
    //search line edit 
    m_ptrInputEdit.reset(new(std::nothrow) DLineEdit(getBodyFrame()));
    assert(m_ptrInputEdit.get() != NULL);
    //TBD: change the X 
    m_ptrInputEdit->setGeometry(MIN_COORD, MIN_COORD,
                                MAX_COORD, MAX_COORD);
    m_ptrInputEdit->setBackgroundColor(Duke_Transparent_Color);
    m_ptrInputEdit->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrInputEdit->setAutoFill(false);
    
    /*
    m_ptrInputEdit->setEventRoutine(DEvent::Input, this,
                                    (EventRoutine)(&DInputEditor::onInput));
    */
}

void DInputEditor::setReadonly()
{
    DEditor::setReadonly();
    m_ptrInputEdit->setLocalEditable(false);
}

std::string DInputEditor::getInputString() const
{
    return m_ptrInputEdit->content();
}

void DInputEditor::setInputString(const std::string & str)
{
    m_ptrInputEdit->setContent(str);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
