/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Lhj 
**
****************************************************************************/

#ifndef DMAPEDITOR_H
#define DMAPEDITOR_H

//boost header files
#include <boost/tr1/memory.hpp>

//duke header files
#include "is_ddialog.h"
#include "is_deditor.h"
#include "is_dmainwin.h"

typedef std::pair<DButtonPtr, DButtonPtr>  MapWidgetElement;
typedef std::vector<MapWidgetElement> MapWidgets;
typedef MapWidgets::iterator MapWidgetsIt;
typedef MapWidgets::size_type MapWidgetsIdx;

typedef std::multimap<duke_media_handle, duke_media_handle> HandleMultimap;

class DMapEditor : public DEditor 
{
public:
    explicit DMapEditor(EditorModel model = PanelModel,
            DMainWin * pMainWin = NULL, 
            DWidget * parent = 0,
            WFlags f = 0);
    explicit DMapEditor(const std::string& title,
            EditorModel model = PanelModel,
            DMainWin *pMainWin = NULL,
            DWidget * parent = 0,
            WFlags f = 0);
    virtual ~DMapEditor();
   
    void initMapEditor();
    void initTypeFrame();    
    void initElementFrame();
    void initItemsInBody();

    // Manage widget in the editor
    void updateElementView();
    void adjustPlacement();
    virtual void setReadonly();

    void reload();
    // Event handle
    void onHoverChild(const DEvent &event);
    void onPassingOutChild(const DEvent &event);
    void onDnDReleaseTypeFrame(const DEvent &event);    
    void onDnDRelease(const DEvent &event);
    void onDeleteChild(const DEvent &event);
    void onSelectChild(const DEvent &event);
    void onGenerate(const DEvent &event);
    void onActivateObj(const DEvent &event);
    //interface menu event
    void onSelectInterfaceMenu(const DEvent &event);
    void onInterfaceMenuBlur(const DEvent &event);
    DPopupMenu* createPopupMenuForInterface(const duke_media_handle& handle, const DEvent &event);

private:
    void saveDukeData();
    void setElementProperty(DButton* pElementButton);
    void createElementByHandle(const duke_media_handle& rDukeHandle, const DEvent& rEvent);
private:
    DFramePtr m_ptrElementFrame;
    DFramePtr m_ptrTypeFrame;
    DButtonPtr m_ptrKeyIFButton;
    DLabelPtr m_ptrKeyIFText;    
    DButtonPtr m_ptrValIFButton;
    DLabelPtr m_ptrValIFText;
    MapWidgets m_mapWidgets; 
    int m_row;
    int m_rowHeight;
    DPopupMenuPtr m_ptrInterfaceMenu;
};

typedef std::tr1::shared_ptr<DMapEditor>  DMapEditorPtr;

const std::string MapEditor_ObjName("Map_Editor");
const int MapEditor_Row_Height = 1000;
const int MapEditor_Col_Items = 5;

const int MapEditor_Width = 336;
const int MapEditor_Heigth = 448;
const int MapEditor_DeclFrame_W_Pixel = 313;
const int MapEditor_DeclFrame_W_InBodyFrame = MapEditor_DeclFrame_W_Pixel * MAX_COORD / MapEditor_Width;
const int MapEditor_DeclFrame_X_Pixel = 12;
const int MapEditor_DeclFrame_X_InBodyFrame = MapEditor_DeclFrame_X_Pixel * MAX_COORD / MapEditor_Width;
const int MapEditor_SingletonBar_X_Pixel = 112;
const int MapEditor_SingletonBar_X_InBodyFrame = MapEditor_SingletonBar_X_Pixel * MAX_COORD / MapEditor_Width;
const int MapEditor_SingletonBar_W_Pixel = 112;
const int MapEditor_SingletonBar_W_InBodyFrame = MapEditor_SingletonBar_W_Pixel * MAX_COORD / MapEditor_Width;
const int MapEditor_SingletonBar_H_Pixel = 24;
const int MapEditor_SingletonBar_H_InMainWin = MapEditor_SingletonBar_H_Pixel * MAX_COORD / 768;

const std::string MapEditorItemImage_FileName("object_origin.png");

const int Default_MapEditor_W_InMainWin = MapEditor_Width * MAX_COORD / 1366;
const int Default_MapEditor_H_InMainWin = MapEditor_Heigth * MAX_COORD / 768;

#endif // DMAPEDITOR_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
