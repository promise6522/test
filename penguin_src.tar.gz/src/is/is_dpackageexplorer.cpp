/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

//boost header files, using lexical_cast for test example, remove it in future
#include "boost/lexical_cast.hpp"
#include "boost/algorithm/string.hpp"

// Duke header files
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dpackageexplorer.h"
#include "is_daboutdlg.h"

DPackageExplorer::DPackageExplorer(int model /* = PanelModel */, DMainWin *pMainWin /* = NULL */,
                                   DWidget * parent /* = 0 */)
    :DEditor(Explorer_Title_Name, model, pMainWin, parent),
     m_rowNum(Explorer_Default_RowNum),
     m_columnNum(Explorer_Default_ColumnNum),
     m_curPage(0)
{
    setObjectName(Explorer_ObjName);
    assert(pMainWin != NULL);
}

DPackageExplorer::~DPackageExplorer()
{
}

int DPackageExplorer::explorerRowNum() const
{
    return m_rowNum;    
}

int DPackageExplorer::explorerColoumnNum() const
{
    return m_columnNum;    
}

int DPackageExplorer::getCurPagePos() const
{
    return m_curPage;
}

std::string DPackageExplorer::getSearchKeyWord() const
{
    return m_searchKey;
}

ExplorerItemIdx DPackageExplorer::getButtonItemIdx(DWidget * pWidget)
{
    ExplorerItemIdx idx = 0;
    for(ExplorerItemIt it = m_items.begin(); it != m_items.end(); ++it)
    {
        if((*it).get() == pWidget)
        {
            return idx;
        }
        ++idx;
    }    

    return idx;
}

void DPackageExplorer::initDialog()
{
    DEditor::initDialog();
    
    initControlBar();
    initExplorerView();
    updateView();
   
    setEventRoutine(DEvent::Enlarge,
                    this,
                    static_cast<EventRoutine>(&DPackageExplorer::processEnlargeEvent));
    setEventRoutine(DEvent::Shrink,
                    this,
                    static_cast<EventRoutine>(&DPackageExplorer::processShrinkEvent));
    setEventRoutine(DEvent::Resize_Release,
                    this, 
                    static_cast<EventRoutine>(&DPackageExplorer::processResizeReleaseEvent));
    updateAll();
}

//control bar, see the style below
//
//  < ^ > New [Search]
//
void DPackageExplorer::initControlBar()
{
    DImage img;
    img.setXScale(DImage::Stretch);
    img.setYScale(DImage::Stretch);
    img.setRelation(DImage::Disrelated);
    DImage selImg;
    selImg.setXScale(DImage::Stretch);
    selImg.setYScale(DImage::Stretch);
    selImg.setRelation(DImage::Disrelated);

    //Previous page button
    img.load(getResPath() + Explorer_PrePageImg_FileName);
    selImg.load(getResPath() + Explorer_PrePageSelImg_FileName);
    m_ptrPrePage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrPrePage.get() != NULL);
    m_ptrPrePage->setGeometry(Explorer_PrePageX_InView, Explorer_PrePageY_InView, 
                              Explorer_PrePageW_InView, Explorer_PrePageH_InView);
    m_ptrPrePage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrPrePage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrPrePage->registerEvent(DEvent::Drag, true);
    m_ptrPrePage->registerEvent(DEvent::DnD_Release, true);
    m_ptrPrePage->registerEvent(DEvent::Detail, true);
    m_ptrPrePage->registerEvent(DEvent::PassingIn);
    m_ptrPrePage->registerEvent(DEvent::PassingOut);
    m_ptrPrePage->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onPrePage));
    m_ptrPrePage->setEventRoutine(DEvent::PassingIn,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onPassingInBtn)); 
    m_ptrPrePage->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onPassingOutBtn));
    m_ptrPrePage->setSelected(false);

    //Up Layer button
    img.load(getResPath() + Explorer_UpLayerImg_FileName);
    selImg.load(getResPath() + Explorer_UpLayerSelImg_FileName);
    m_ptrUpLayer.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrUpLayer.get() != NULL);
    m_ptrUpLayer->setGeometry(Explorer_UpLayerX_InView, Explorer_UpLayerY_InView, 
                              Explorer_UpLayerW_InView, Explorer_UpLayerH_InView);
    m_ptrUpLayer->setBackgroundColor(Duke_Transparent_Color);
    m_ptrUpLayer->registerEvent(DEvent::Detail, true);
    m_ptrUpLayer->registerEvent(DEvent::DnD_Start, true);
    //m_ptrUpLayer->registerEvent(DEvent::Drag, true);
    m_ptrUpLayer->registerEvent(DEvent::DnD_Release, true);
    m_ptrUpLayer->registerEvent(DEvent::PassingIn);
    m_ptrUpLayer->registerEvent(DEvent::PassingOut);
    m_ptrUpLayer->setEventRoutine(DEvent::Select,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onUpLayer));
    m_ptrUpLayer->setEventRoutine(DEvent::PassingIn,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onPassingInBtn)); 
    m_ptrUpLayer->setEventRoutine(DEvent::PassingOut,
                                  this,
                                  static_cast<EventRoutine>(&DPackageExplorer::onPassingOutBtn));
    m_ptrUpLayer->setSelected(false);
    
    //Next page button
    img.load(getResPath() + Explorer_NextPageImg_FileName);
    selImg.load(getResPath() + Explorer_NextPageSelImg_FileName);
    m_ptrNextPage.reset(new(std::nothrow) DButton("",
                                                 img,
                                                 selImg,
                                                 getViewFrame()));
    assert(m_ptrNextPage.get() != NULL);
    m_ptrNextPage->setGeometry(Explorer_NextPageX_InView, Explorer_NextPageY_InView, 
                               Explorer_NextPageW_InView, Explorer_NextPageH_InView);
    m_ptrNextPage->setBackgroundColor(Duke_Transparent_Color);
    m_ptrNextPage->registerEvent(DEvent::Detail, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Start, true);
    //m_ptrNextPage->registerEvent(DEvent::Drag, true);
    m_ptrNextPage->registerEvent(DEvent::DnD_Release, true);
    m_ptrNextPage->registerEvent(DEvent::PassingIn);
    m_ptrNextPage->registerEvent(DEvent::PassingOut);
    m_ptrNextPage->setEventRoutine(DEvent::Select,
                                   this,
                                   static_cast<EventRoutine>(&DPackageExplorer::onNextPage));    
    m_ptrNextPage->setEventRoutine(DEvent::PassingIn,
                                   this,
                                   static_cast<EventRoutine>(&DPackageExplorer::onPassingInBtn)); 
    m_ptrNextPage->setEventRoutine(DEvent::PassingOut,
                                   this,
                                   static_cast<EventRoutine>(&DPackageExplorer::onPassingOutBtn));
    m_ptrNextPage->setSelected(false);

    //create button
    img.load(getResPath() + Explorer_CreateImg_FileName);
    m_ptrCreate.reset(new(std::nothrow) DButton("",
                                                img,
                                                getViewFrame()));
    assert(m_ptrCreate.get() != NULL);
    m_ptrCreate->setGeometry(Explorer_CreateX_InView, Explorer_CreateY_InView, 
                             Explorer_CreateW_InView, Explorer_CreateH_InView);
    m_ptrCreate->setBackgroundColor(Duke_Transparent_Color);
    m_ptrCreate->registerEvent(DEvent::Detail, true);
    m_ptrCreate->registerEvent(DEvent::DnD_Start, true);
    //m_ptrCreate->registerEvent(DEvent::Drag, true);
    m_ptrCreate->registerEvent(DEvent::DnD_Release, true);
    m_ptrCreate->setEventRoutine(DEvent::Select,
                                 this,
                                 static_cast<EventRoutine>(&DPackageExplorer::onCreateNew));

    //search line edit background
    img.load(getResPath() + Search_EditImg_FileName);
    m_ptrSearchEditBg.reset(new(std::nothrow) DImageLabel("", img, getViewFrame()));
    assert(m_ptrSearchEditBg.get() != NULL);
    m_ptrSearchEditBg->setGeometry(Explorer_SearchX_InView, Explorer_SearchY_InView,
                                   Explorer_SearchW_InView, Explorer_SearchH_InView);
    m_ptrSearchEditBg->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchEditBg->setFrameBorderColor(Duke_Transparent_Color);    

    //search line edit 
    m_ptrSearchKeyWord.reset(new(std::nothrow) DLineEdit(getViewFrame()));
    assert(m_ptrSearchKeyWord.get() != NULL);
    m_ptrSearchKeyWord->setGeometry(Explorer_SearchEditX_InView, Explorer_SearchY_InView,
                                    Explorer_SearchEditW_InView, Explorer_SearchH_InView);
    m_ptrSearchKeyWord->setBackgroundColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setFrameBorderColor(Duke_Transparent_Color);
    m_ptrSearchKeyWord->setEventRoutine(DEvent::Input, this,
                                        (EventRoutine)(&DPackageExplorer::onSearch));
}

//Explorerview, see the style below
//
//   item   item   item
//   text   text   text
//-------------------------(Horizontal Line image)
//
void DPackageExplorer::initExplorerView()
{
    int layerHeight = Explorer_TotalLayer_H_InView / m_rowNum;
    for(int i = 0 ; i < m_rowNum; ++i)
    {
        DFramePtr ptrViewLayer(new(std::nothrow) DFrame(getViewFrame()));
        assert(ptrViewLayer.get() != NULL);
        ptrViewLayer->setGeometry(Explorer_Layer_X_InView, 
                                  Explorer_Layer_StartY_InView + layerHeight * i,
                                  Explorer_Layer_W_InView,
                                  layerHeight);
        
        ptrViewLayer->setBackgroundColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameBorderColor(Duke_Transparent_Color);
        ptrViewLayer->setFrameStyle(DFrame::Panel);
        ptrViewLayer->setDisplayOrder(Default_Dialog_DisplayOrder);
        ptrViewLayer->registerEvent(DEvent::DnD_Start, true);
        //ptrViewLayer->registerEvent(DEvent::Drag, true);
        ptrViewLayer->registerEvent(DEvent::DnD_Release, true);
        ptrViewLayer->registerEvent(DEvent::Detail, true);
        ptrViewLayer->registerEvent(DEvent::Select, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Start, true);
        ptrViewLayer->registerEvent(DEvent::Resize_Release, true);
        m_viewLayers.push_back(ptrViewLayer);
        fillItemsInViewLayer(ptrViewLayer.get(), i);
    }
}

void DPackageExplorer::fillItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{
    DImage dukeItemImg;
    dukeItemImg.load(getResPath() + ExplorerItemImage_FileName);   

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                           dukeItemImg,
                                                           pViewLayer));
        int dukeIconX = Explorer_Icon_StartX_InLayer + Explorer_Icon_SpacingX_InLayer * i;
        ptrItemButton->setGeometry(dukeIconX,
                                   Explorer_Icon_Y_InLayer,
                                   Explorer_Icon_W_InLayer,
                                   Explorer_Icon_H_InLayer);
        m_items.push_back(ptrItemButton);        

        DLabelPtr ptrItemText(new(std::nothrow) DLabel("N/A",
                                                       pViewLayer));
        int dukeTextX = Explorer_Text_StartX_InLayer + Explorer_Text_SpacingX_InLayer * i;
        ptrItemText->setAlignment(AlignCenter);
        ptrItemText->setGeometry(dukeTextX,
                                 Explorer_Text_Y_InLayer,
                                 Explorer_Text_W_InLayer,
                                 Explorer_Text_H_InLayer);
        ptrItemText->setBackgroundColor(Duke_Transparent_Color);
        ptrItemText->setFrameBorderColor(Duke_Transparent_Color);
        ptrItemText->setTextColor(Default_Dialog_TextColor);

        //add the event (passthrough)
        ptrItemText->registerEvent(DEvent::DnD_Start, true);
        //ptrItemText->registerEvent(DEvent::Drag, true);
        ptrItemText->registerEvent(DEvent::DnD_Release, true);
        ptrItemText->registerEvent(DEvent::Detail, true);
        ptrItemText->registerEvent(DEvent::Select, true);
        //ptrItemButton->registerEvent(DEvent::Drag, true);
        ptrItemButton->registerEvent(DEvent::DnD_Release, true);
        ptrItemButton->registerEvent(DEvent::Detail, true);
        ptrItemButton->registerEvent(DEvent::Select, true);
        //add the real event
        ptrItemButton->registerEvent(DEvent::DnD_Start);
        ptrItemButton->registerEvent(DEvent::Activate);
        ptrItemButton->registerEvent(DEvent::Hover);
        ptrItemButton->registerEvent(DEvent::PassingOut);
        ptrItemButton->setEventRoutine(DEvent::Activate,
                                       this, 
                                       static_cast<EventRoutine>(&DPackageExplorer::onActivate));
        ptrItemButton->setEventRoutine(DEvent::Hover,
                                       this,
                                       static_cast<EventRoutine>(&DPackageExplorer::onHover)); 
        ptrItemButton->setEventRoutine(DEvent::PassingOut,
                                       this,
                                       static_cast<EventRoutine>(&DPackageExplorer::onPassingOut));
        
        m_texts.push_back(ptrItemText);        
    }    
}

void DPackageExplorer::updateItemsInViewLayer(DFrame * pViewLayer, int lineNum)
{

    /*
    //In order to improve performance, just update the img and text when change dukeitem
    DImage dukeDefaultImg;
    dukeDefaultImg.load(getResPath() + ExplorerItemImage_FileName);   
    int pageNum = m_rowNum * m_columnNum;
    int curSize = m_ptrImpl->getDukeItemsSize(m_searchKey);

    for(int i = 0; i < m_columnNum; ++i )
    {
        DButton* pItemButton = m_items[lineNum *  m_columnNum + i].get();
        DLabel* pItemText = m_texts[lineNum *  m_columnNum + i].get();
        int curPos = i + lineNum * m_columnNum + m_curPage * pageNum;
        if( curPos >= curSize)
        {
            //more than current item       
            pItemButton->setHideProperty(true);
            pItemText->setHideProperty(true);
        }
        else
        {
            pItemButton->setHideProperty(false);
            pItemText->setHideProperty(false);        

            duke_media_handle handle =
                m_ptrImpl->getDukeHandle(m_curPage*pageNum+lineNum*m_columnNum+i, m_searchKey);
            pItemButton->setMediaByHandle(handle);
            if(handle.is_type_null())
            {
                pItemText->setContent(ExplorerDlg_Item_DefaultName);
                pItemButton->setImage(dukeDefaultImg);
            }
            else
            {
                std::string strname;
                if(duke_media_get_name(handle, strname) && !strname.empty())
                {
                    pItemText->setContent(strname);
                }
                else
                {
                    pItemText->setContent(ExplorerDlg_Item_DefaultName);                    
                }

                std::string stricon;
                if(duke_media_get_icon(handle, stricon) && !stricon.empty())
                {
                    DImage img;
                    img.setXScale(DImage::Stretch);
                    img.setYScale(DImage::Stretch);
                    img.setRelation(DImage::Disrelated);
                    std::vector<unsigned char> tempData(stricon.begin(), stricon.end());
                    img.setImageData(&tempData[0], tempData.size());
                    pItemButton->setImage(img);
                }
                else
                {
                    pItemButton->setImage(dukeDefaultImg);                    
                }
            }
        }
    }
    */
}

void DPackageExplorer::updateView()
{    
    //Get list    
    ExplorerViewLayerIt it;
    int i = 0;
    for(it = m_viewLayers.begin(); it != m_viewLayers.end(); ++it)
    {
        DFrame* pViewLayer = (*it).get();
        assert(pViewLayer != NULL);
        updateItemsInViewLayer(pViewLayer, i);
        i++;
    }        
}

/*---------------Event Handle-----------------*/
void DPackageExplorer::processEnlargeEvent(const DEvent& rEvent)
{
    DDialog::processEnlargeEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DPackageExplorer::processShrinkEvent(const DEvent& rEvent)
{
    DDialog::processShrinkEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DPackageExplorer::processResizeReleaseEvent(const DEvent& rEvent)
{
    DDialog::processResizeReleaseEvent(rEvent);
    adjustPlacement();
    repaint(rEvent.getCon());    
}

void DPackageExplorer::onClose(const DEvent& rEvent)
{
    DDialog::onMinimize(rEvent);
}

void DPackageExplorer::onSearch(const DEvent &event)
{    
    m_curPage = 0;
    m_ptrSearchKeyWord->onInputEvent(event);
    m_searchKey = m_ptrSearchKeyWord->content();    

    //update
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DPackageExplorer::onPrePage(const DEvent &event)
{
    assert(m_curPage >= 0);
    if(m_curPage == 0)
        return;

    m_curPage--;

    updateView();
    updateAll();
    repaint(event.getCon());
}

void DPackageExplorer::onUpLayer(const DEvent &event)
{
    updateView();
    updateAll();
    repaint(event.getCon());
}

void DPackageExplorer::onNextPage(const DEvent &event)
{
    /*
    //On next page, reload the new duke item and update view
    int totalPage = (m_ptrImpl->getDukeItemsSize(m_searchKey) - 1)
        / (m_rowNum * m_columnNum);    

    if(m_curPage == totalPage)
        return;

    m_curPage++;
    updateView();
    updateAll();
    repaint(event.getCon());
    */
}

void DPackageExplorer::onActivate(const DEvent &event)
{
}

void DPackageExplorer::onHover(const DEvent &event)
{
}

void DPackageExplorer::onPassingOut(const DEvent &event)
{
}

void DPackageExplorer::onPassingInBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(true);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DPackageExplorer::onPassingOutBtn(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton *>(pObject);

    if(pButton != NULL)
    {
        pButton->setSelected(false);
        pButton->updateAll();
        pButton->repaint(event.getCon());
    }
}

void DPackageExplorer::onCreateNew(const DEvent &event)
{
    //TBD
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
