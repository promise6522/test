/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Ning
**
****************************************************************************/

//boost header files
#include <boost/algorithm/string.hpp>
#include <boost/bind.hpp>

//C++ 98 header files
#include <functional>

// Duke header files
#include "is_dmainwin.h"
#include "is_dtoolwin.h"
#include "is_dwarehousedlg.h"
#include "is_daboutdlg.h"
#include "is_dwarehouseimpl.h"
#include "is_deditor.h"
#include "is_druneditor.h"
#include "is_dimpleditor.h"
#include "is_dobjeditor.h"
#include "is_ddecleditor.h"
#include "is_difeditor.h"
#include "is_dconteditor.h"
#include "is_danchoreditor.h"
#include "is_dfunc.h"
#include "is_dapplication.h"
////#include "media/duke_media_global.h"

//===========================================================================
//          Implement for warehouse 
//===========================================================================

DWarehouseImpl::DWarehouseImpl(): m_cacheItemsSize(0)
{
}

DWarehouseImpl::~DWarehouseImpl()
{
}

void DWarehouseImpl::cleanCache()
{
    //clear cache
    m_cacheItemsSize = 0;
    m_cacheKeyString.clear();
    m_cacheHandleIdxes.clear();
}

void DWarehouseImpl::reloadCache(std::string keyWord /* = "" */)
{
    cleanCache();
        
    //reload cache for the new keyword
    int readNum = 0;
    std::string dukeName;
    duke_media_handle_size_type idx = 0;    
    for(duke_media_handle_iterator it = m_dukeItems.begin();
        it != m_dukeItems.end();
        ++it, ++idx)
    {
        if(!duke_media_get_name(*it, dukeName))
            continue;
        
        if(boost::icontains(dukeName, keyWord))
        {
            readNum++;
            m_cacheHandleIdxes.push_back(idx);
        }
    }

    //ret cache
    m_cacheKeyString = keyWord;
    m_cacheItemsSize = m_cacheHandleIdxes.size();    
}

int DWarehouseImpl::getDukeItemsSize(std::string keyWord /* = "" */)
{
    boost::trim(keyWord);

    //optimize for empty keyword
    if(keyWord.empty())
        return m_dukeItems.size();

    if(m_cacheKeyString != keyWord)
        reloadCache(keyWord);
            
    return m_cacheItemsSize;
}

duke_media_handle DWarehouseImpl::getDukeHandle(int pos, std::string keyWord /* = "" */)
{
    boost::trim(keyWord);
    
    //optimize for empty keyword
    if(keyWord.empty())
    {
        if(pos < static_cast<int>(m_dukeItems.size()))
            return m_dukeItems[pos];

        return duke_media_handle_null;
    }

    if(m_cacheKeyString != keyWord)
        reloadCache(keyWord);
    
    if(pos < static_cast<int>(m_cacheHandleIdxes.size()))
        return m_dukeItems[m_cacheHandleIdxes[pos]];

    return duke_media_handle_null;
}

int DWarehouseImpl::getLoadedItemsSize()
{
    return static_cast<int>(m_dukeItems.size());    
    return 0;
}

void DWarehouseImpl::onHover(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (pWidget == NULL)
        return;

    size_t idx = m_pWarehouseDlg->getButtonItemIdx(pWidget);

    // open editor
    int curPos = idx + m_pWarehouseDlg->getCurPagePos() * m_pWarehouseDlg->warehouseRowNum() 
        * m_pWarehouseDlg->warehouseColoumnNum();
    std::string itemTip;
    duke_media_handle handle = getDukeHandle(curPos, 
                                             m_pWarehouseDlg->getSearchKeyWord());
    if(!handle.is_type_null() && duke_media_get_name(handle, itemTip))
    {        
        m_pWarehouseDlg->getApplication()->tip()->add(pWidget, 
                                                      itemTip, 
                                                      event.getCon());
    }
}

void DWarehouseImpl::onPassingOut(const DEvent &event)
{
    //close editor
    m_pWarehouseDlg->getApplication()->tip()->remove(event.getCon());
}

//===========================================================================
//          Implement for warehouse Object dialog
//===========================================================================
DObjhouseImpl::DObjhouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DObjhouseImpl::~DObjhouseImpl()
{
}

int DObjhouseImpl::readDukeItems(DukeItemClassic classic)
{    
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;

    switch(classic)
    {
    case AllItems:
        duke_media_get_builtin_objects(m_pWarehouseDlg->getApplication()->get_host_committer_id(), m_dukeItems);
        {            
            duke_media_handle_vector decls;        
            duke_media_get_bridge(m_dukeItems, decls);
        }
        
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )        
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object() 
                            && !iter->is_interface()
                            && !iter->is_declaration()
                            && !iter->is_implementation()
                            && !iter->is_access())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }
        break;
    case BuiltInItems:
        duke_media_get_builtin_objects(m_pWarehouseDlg->getApplication()->get_host_committer_id(), m_dukeItems);
        break;
    case EditItems:
        duke_media_get_tmp_objects(m_dukeItems, m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_objects(m_pWarehouseDlg->getApplication()->username(), m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object()
                            && !iter->is_interface()
                            && !iter->is_declaration()
                            && !iter->is_implementation()
                            && !iter->is_access())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }                
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }

    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke object");
    return static_cast<int>(m_dukeItems.size());
}

//Message handle
void DObjhouseImpl::onActivate(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject);

    if(!pWidget)
        return;

    duke_media_handle handle = pWidget->getMediaHandle();
    if (handle.is_object_builtin() || handle.is_object_bridge())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DObjEditorPtr ptrDlg(new(std::nothrow) DObjEditor(ObjEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
                        Default_ObjEditor_W_InMainWin, Default_ObjEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    DImage img;
    img.load(getResPath() + ToolWin_ObjectButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ObjectSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    if(m_pWarehouseDlg->isEditing())
    {
        ptrDlg->setMediaByHandle(handle);
        ptrDlg->initObjEditor();
    }
    else
    {
        //ptrDlg->duplicateItemsByHandle(pWidget->getMediaHandle());
        ptrDlg->setMediaByHandle(handle);
        ptrDlg->initObjEditor();
        ptrDlg->setReadonly();        
    }

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());
   
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

void DObjhouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create new button in warehouse
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                       *pButton->image(),
                                                       pMainWin->getRootWidget()));
    ptrItemButton->setGeometry(0, 0, 500, 500);
    pMainWin->insertWidget(ptrItemButton);    
    pMainWin->setDragWidget(ptrItemButton.get());
}

void DObjhouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DObjEditorPtr ptrDlg(new(std::nothrow) DObjEditor(ObjEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_ObjEditor_W_InMainWin, 
            Default_ObjEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    DImage img;
    img.load(getResPath() + ToolWin_ObjectButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ObjectSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    ptrDlg->setMediaByType(DUKE_MEDIA_TYPE_OBJECT_USER);
    ptrDlg->initObjEditor();

    //Save the editing handle
    duke_media_handle newh = ptrDlg->getMediaHandle();
    save_editing_handle(newh,
            m_pWarehouseDlg->getApplication()->username());

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());
   
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

//===========================================================================
///          Implement for warehouse IF dialog
//===========================================================================
DIFhouseImpl::DIFhouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DIFhouseImpl::~DIFhouseImpl()
{
}

int DIFhouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;
    dukeid_vector vobjs;
    duke_media_handle out_ac_if;

    switch(classic)
    {
    case AllItems:
        // get builtin interfaces
        duke_media_get_builtin_interfaces(m_pWarehouseDlg->getApplication()->get_host_committer_id(), m_dukeItems);
        // get outgoing access interface
        duke_media_get_outgoing_access_if(out_ac_if);
        m_dukeItems.push_back(out_ac_if);

        //
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object_interface() || iter->is_object_compound_interface())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }
        break;
    case BuiltInItems:    
        // get builtin interfaces
        duke_media_get_builtin_interfaces(m_pWarehouseDlg->getApplication()->get_host_committer_id(), m_dukeItems);
        duke_media_get_outgoing_access_if(out_ac_if);
        m_dukeItems.push_back(out_ac_if);
	break;
    case EditItems:
        duke_media_get_tmp_compound_interfaces(m_dukeItems,
                                      m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_compound_interfaces(m_pWarehouseDlg->getApplication()->username(), m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object_interface() || iter->is_object_compound_interface())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        } 
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }

    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke interface.");
    return static_cast<int>(m_dukeItems.size());
    return 0;
}

//Message handle
void DIFhouseImpl::onActivate(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (!pWidget)
    {
        return;
    }

    duke_media_handle handle = pWidget->getMediaHandle();
    if(!handle.is_interface())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DIFEditorPtr ptrDlg(new(std::nothrow) DIFEditor(IFEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_IFEditor_W_InMainWin, 
            Default_IFEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_IFButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_IFSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    // Initialize the editor after inserting widget
    if(m_pWarehouseDlg->isEditing())
    {
        ptrDlg->setMediaByHandle(handle);
        ptrDlg->initIFEditor(false);
    }
    else
    {
        //ptrDlg->duplicateItemsByHandle(pWidget->getMediaHandle());
        ptrDlg->setMediaByHandle(handle);
        ptrDlg->initIFEditor(false);
        ptrDlg->setReadonly();        
    }
    
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

void DIFhouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create new button in warehouse
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                       *pButton->image(),
                                                       pMainWin->getRootWidget()));
    ptrItemButton->setGeometry(0, 0, 500, 500);
    pMainWin->insertWidget(ptrItemButton);    
    pMainWin->setDragWidget(ptrItemButton.get());
}

void DIFhouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DIFEditorPtr ptrDlg(new(std::nothrow) DIFEditor(IFEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_IFEditor_W_InMainWin, 
            Default_IFEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_IFButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_IFSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);

    // Initialize the editor after inserting widget
    ptrDlg->setMediaByType(DUKE_MEDIA_TYPE_INTERFACE_COMPOUND);
    ptrDlg->initIFEditor(true);

    //Save the editing handle
    duke_media_handle newh = ptrDlg->getMediaHandle();
    save_editing_handle(newh,
            m_pWarehouseDlg->getApplication()->username());

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());
    
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

//===========================================================================
///          Implement  for warehouse Declatation dialog
//===========================================================================
DDeclhouseImpl::DDeclhouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DDeclhouseImpl::~DDeclhouseImpl()
{
}

int DDeclhouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;

    switch(classic)
    {
    case AllItems:
        {            
            duke_media_handle_vector objs;  
            duke_media_handle_vector  dukeItems; 
            duke_media_get_bridge(objs, dukeItems);
            m_dukeItems.insert(m_dukeItems.end(),dukeItems.begin(),dukeItems.end());
        }
        duke_media_get_semi_decl(m_dukeItems);
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();
                    iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_declaration())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }        
        break;
    case BuiltInItems:
        duke_media_get_semi_decl(m_dukeItems);        
        break;
    case EditItems:
        duke_media_get_tmp_declarations(m_dukeItems,
                                        m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_declarations(m_pWarehouseDlg->getApplication()->username(), m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_declaration())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }

    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke declaration.");
    return static_cast<int>(m_dukeItems.size());
    return 0;
}

//Message handle
void DDeclhouseImpl::onActivate(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (!pWidget || !pWidget->getMediaHandle().is_declaration())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    DDeclEditorPtr ptrDlg(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                                                      DEditor::DialogModel, 
                                                      pMainWin,
                                                      pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_DeclButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_DeclSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    if(m_pWarehouseDlg->isEditing())
    {
        ptrDlg->setMediaByHandle(pWidget->getMediaHandle());
        ptrDlg->initDeclEditor();
    }
    else
    {
        //ptrDlg->duplicateItemsByHandle(pWidget->getMediaHandle());
        ptrDlg->setMediaByHandle(pWidget->getMediaHandle());
        ptrDlg->initDeclEditor();
        ptrDlg->setReadonly();
    }

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());
     
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

void DDeclhouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create the dfunc in mainwin
    DFuncPtr ptrItem(new(std::nothrow) DFunc("",
                                             2,
                                             2,
                                             pMainWin->getRootWidget()));
    ptrItem->setGeometry(0, 0, 1000, 1000);
    ptrItem->setHideProperty(true);    
    pMainWin->insertWidget(ptrItem);    
    pMainWin->setDragWidget(ptrItem.get());
}

void DDeclhouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    DDeclEditorPtr ptrDlg(new(std::nothrow) DDeclEditor(DeclEditor_ObjName, 
                                                        DEditor::DialogModel, 
                                                        pMainWin,
                                                        pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_DeclEditor_W_InMainWin, 
            Default_DeclEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_DeclButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_DeclSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    ptrDlg->setMediaByType(DUKE_MEDIA_TYPE_FUNCTION_DECLARE);
    ptrDlg->initDeclEditor();

    //Save the editing handle
    duke_media_handle newh = ptrDlg->getMediaHandle();
    save_editing_handle(newh,
            m_pWarehouseDlg->getApplication()->username());

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());

    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

//===========================================================================
///          Implement for warehouse implementation dialog
//===========================================================================
DImplhouseImpl::DImplhouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DImplhouseImpl::~DImplhouseImpl()
{
}

int DImplhouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;

    switch(classic)
    {
    case AllItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it)
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();
                    iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_implementation())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }                
            }
        }
        break;
    case BuiltInItems:
        break;
    case EditItems:
        duke_media_get_tmp_implementations(m_dukeItems, 
                                           m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_implementations(m_pWarehouseDlg->getApplication()->username(),
                                       m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_implementation())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }

            }
        }  
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }
////
    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke implementation");
    return static_cast<int>(m_dukeItems.size());
////    return 0;
}

//Message handle
void DImplhouseImpl::onActivate(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 
////
    if (!pWidget || pWidget->getMediaHandle().is_object_exec_iterator() 
        || pWidget->getMediaHandle().is_object_exec_condition()
        || !pWidget->getMediaHandle().is_implementation())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DImplEditorPtr ptrEditor(new(std::nothrow) DImplEditor(ImplEditor_ObjName,
                                                           DEditor::DialogModel,
                                                           pMainWin,
                                                           pMainWin->getRootWidget()));
    ptrEditor->setGeometry(4000, 4000,
                           Default_ImplEditor_W_InMainWin, Default_ImplEditor_H_InMainWin);
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrEditor.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ImplButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ImplSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrEditor);
    //must insert to mainwin at first, then initDialo
    if(m_pWarehouseDlg->isEditing())
    {
        ptrEditor->setMediaByHandle(pWidget->getMediaHandle());
        ptrEditor->initDialog();
    }
    else
    {
        /// TODO (tom) currently we don't make a copy of the impl,
        /// simply make the editor readonly to avoid editing

        //std::vector<node_info> vNodeInfo;
        //duke_media_get_hattr_node(pWidget->getMediaHandle(), vNodeInfo);
        //ptrEditor->duplicateItemsByHandle(pWidget->getMediaHandle());
        //duke_media_set_hattr_node(ptrEditor->getMediaHandle(), vNodeInfo);
        //ptrEditor->initDialog();

        ptrEditor->setMediaByHandle(pWidget->getMediaHandle());
        ptrEditor->initDialog();
        ptrEditor->setReadonly();
    }

    //set Active widget
    pMainWin->setActiveWidget(ptrEditor.get());
    
    //update children and show
    pButton->updateAll();
    ptrEditor->updateAll();
    pButton->show(event.getCon());
    ptrEditor->show(event.getCon());
}

void DImplhouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    DFuncPtr ptrItem(new(std::nothrow) DFunc("",
                                             2,
                                             2,
                                             pMainWin->getRootWidget()));
    ptrItem->setGeometry(0, 0, 1000, 1000);
    ptrItem->setHideProperty(true);    
    pMainWin->insertWidget(ptrItem);    
    pMainWin->setDragWidget(ptrItem.get());
}

void DImplhouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DImplEditorPtr ptrEditor(new(std::nothrow) DImplEditor(ImplEditor_ObjName,
                                                           DEditor::DialogModel,
                                                           pMainWin,
                                                           pMainWin->getRootWidget()));
    ptrEditor->setGeometry(4000, 4000,
                           Default_ImplEditor_W_InMainWin, Default_ImplEditor_H_InMainWin);    
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrEditor.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ImplButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ImplSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrEditor);
    //must insert to mainwin at first, then initDialog
    ptrEditor->setMediaByType(DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT);
    ptrEditor->initDialog();

    //Save the editing handle
    duke_media_handle newh = ptrEditor->getMediaHandle();
    save_editing_handle(newh,
            m_pWarehouseDlg->getApplication()->username());

    //set Active widget
    pMainWin->setActiveWidget(ptrEditor.get());
    
    //update children and show
    pButton->updateAll();
    ptrEditor->updateAll();
    pButton->show(event.getCon());
    ptrEditor->show(event.getCon());
}

//===========================================================================
///          Implement for warehouse container dialog
//===========================================================================
DConthouseImpl::DConthouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DConthouseImpl::~DConthouseImpl()
{
}

int DConthouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;
////
    switch(classic)
    {
    case AllItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object_container_des())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }
        break;
    case BuiltInItems:
        break;
    case EditItems:
        duke_media_get_tmp_containers_def(m_dukeItems, 
                                           m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_containers_def(m_pWarehouseDlg->getApplication()->username(),
                                       m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_object_container_des())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }  
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }

    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke container");
    return static_cast<int>(m_dukeItems.size());
////    return 0;
}

//Message handle
void DConthouseImpl::onActivate(const DEvent &event)
{
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (!pWidget || !pWidget->getMediaHandle().is_object_container_des())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DContEditorPtr ptrEditor(new(std::nothrow) DContEditor(ContEditor_ObjName,
                                                DEditor::DialogModel,
                                                pMainWin,
                                                pMainWin->getRootWidget()));
    ptrEditor->setGeometry(4000, 4000, Default_ContEditor_W_InMainWin, Default_ContEditor_H_InMainWin);    
    ptrEditor->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrEditor.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ContButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ContSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrEditor);
    //must insert to mainwin at first, then initDialo
    if(m_pWarehouseDlg->isEditing())
    {
        ptrEditor->setMediaByHandle(pWidget->getMediaHandle());
        ptrEditor->initContEditor();
    }
    else
    {
        //(tom) don't make duplicates
        //ptrEditor->duplicateItemsByHandle(pWidget->getMediaHandle());

        ptrEditor->setMediaByHandle(pWidget->getMediaHandle());
        ptrEditor->initContEditor();
        ptrEditor->setReadonly();
    }

    //set Active widget
    pMainWin->setActiveWidget(ptrEditor.get());
    
    //update children and show
    pButton->updateAll();
    ptrEditor->updateAll();
    pButton->show(event.getCon());
    ptrEditor->show(event.getCon());
}

void DConthouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create new button in warehouse
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                       *pButton->image(),
                                                       pMainWin->getRootWidget()));
    ptrItemButton->setGeometry(0, 0, 500, 500);
    pMainWin->insertWidget(ptrItemButton);    
    pMainWin->setDragWidget(ptrItemButton.get());
}

void DConthouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DContEditorPtr ptrDlg(new(std::nothrow) DContEditor(ContEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, Default_ContEditor_W_InMainWin, Default_ContEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_ContButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_ContSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    //must insert to mainwin at first, then initDialog
    ptrDlg->setMediaByType(DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF);
    ptrDlg->initContEditor();

    //Save the editing handle
    duke_media_handle newh = ptrDlg->getMediaHandle();
    save_editing_handle(newh,
            m_pWarehouseDlg->getApplication()->username());

    //set Active widget
    pMainWin->setActiveWidget(ptrDlg.get());
   
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

//===========================================================================
///          Implement for warehouse access dialog
//===========================================================================
DAcshouseImpl::DAcshouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DAcshouseImpl::~DAcshouseImpl()
{
}

int DAcshouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;

    switch(classic)
    {
    case AllItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_access())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }
        break;
    case BuiltInItems:
        break;
    case EditItems:
        duke_media_get_tmp_accesses(m_dukeItems, 
                                           m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_accesses(m_pWarehouseDlg->getApplication()->username(),
                                       m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_handle_vector dukeTmepItems;
                duke_media_get_shared_objs(*it, dukeTmepItems);
                for(duke_media_handle_iterator iter = dukeTmepItems.begin();iter != dukeTmepItems.end();++iter)
                {
                    if(iter->is_access())
                    {
                        m_dukeItems.push_back(*iter);
                    }
                }
            }
        }  
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }
    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke access");
    return static_cast<int>(m_dukeItems.size());
}

//Message handle
void DAcshouseImpl::onActivate(const DEvent &event)
{
    // add by roger on 10/17/11
    return;
    // get duke data from source widget
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 

    if (!pWidget  || !pWidget->getMediaHandle().is_access())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DAnchorEditorPtr ptrEditor(new(std::nothrow) DAnchorEditor(AnchorEditor_ObjName,
                                                DEditor::DialogModel,
                                                pMainWin,
                                                pMainWin->getRootWidget()));
    ptrEditor->setGeometry(4000, 4000, Default_AnchorEditor_W_InMainWin, Default_ContEditor_H_InMainWin);    
    ptrEditor->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrEditor.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_AcsButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_AcsSelButton_Filename);
    pButton->setSelImage(img);

    //must insert to mainwin at first, then initDialo
    pMainWin->insertWidget(ptrEditor);

    duke_media_handle access;
    duke_media_access accessMedia(pWidget->getMediaHandle());
    int an_idx = accessMedia.get_anchor_idx();
    duke_media_handle hcont;
    accessMedia.get_container(hcont);

    duke_media_container contMedia(hcont);
    duke_media_handle_vector vanchor;
    contMedia.get_anchor(vanchor);

    int st = vanchor.size();
    if (an_idx < 0 || an_idx >= st)
        return;

    ptrEditor->setMediaByHandle(vanchor[an_idx]);
    ptrEditor->initAnchorEditor();
    //set Active widget
    pMainWin->setActiveWidget(ptrEditor.get());
    
    //update children and show
    pButton->updateAll();
    ptrEditor->updateAll();
    pButton->show(event.getCon());
    ptrEditor->show(event.getCon());
}

void DAcshouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create new button in warehouse
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                       *pButton->image(),
                                                       pMainWin->getRootWidget()));
    ptrItemButton->setGeometry(0, 0, 500, 500);
    pMainWin->insertWidget(ptrItemButton);    
    pMainWin->setDragWidget(ptrItemButton.get());
}

void DAcshouseImpl::onCreateNew(const DEvent &event)
{
}

//===========================================================================
///          Implement for warehouse execution dialog
//===========================================================================
DExehouseImpl::DExehouseImpl(DWarehouseDlg * pWarehouseDlg)
{
    m_pWarehouseDlg = pWarehouseDlg;
}

DExehouseImpl::~DExehouseImpl()
{
}

int DExehouseImpl::readDukeItems(DukeItemClassic classic)
{
    m_dukeItems.clear();
    cleanCache();
    std::vector<std::string> users;
////
    switch(classic)
    {
    case AllItems:
////        /*
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            duke_media_handle_vector  dukeItems;
            duke_media_get_executions(*it, dukeItems);
            m_dukeItems.insert(m_dukeItems.end(),dukeItems.begin(),dukeItems.end());
        }
////        */
        break;
    case BuiltInItems:
        break;
    case EditItems:
        duke_media_get_tmp_executions(m_dukeItems,
                                      m_pWarehouseDlg->getApplication()->username());
        break;
    case UserDefinedItems:
        duke_media_get_executions(m_pWarehouseDlg->getApplication()->username(), m_dukeItems);
        break;
    case SharedItems:
        duke_media_get_register_users(users);
        for(std::vector<std::string>::iterator it = users.begin(); it != users.end(); ++it )
        {
            if(*it != m_pWarehouseDlg->getApplication()->username())
            {
                duke_media_get_executions(*it, m_dukeItems);
            }
        }
        break;
    default:
        assert(!"Unkonw duke item classic.");
    }

    LOG_DEBUG("Read "<<m_dukeItems.size()<<" duke executions.");
    return static_cast<int>(m_dukeItems.size());
////    return 0;
}

//Message handle
void DExehouseImpl::onActivate(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DWidget* pWidget = dynamic_cast<DWidget*>(pObject); 
    if (!pWidget || !pWidget->getMedia() || 
            !pWidget->getMedia()->is_execute())
        return;

    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DRunEditorPtr ptrDlg(new(std::nothrow) DRunEditor(RunEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_RunEditor_W_InMainWin, 
            Default_RunEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_RunButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_RunSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    if(m_pWarehouseDlg->isEditing())
    {
        ptrDlg->setMediaByHandle(pWidget->getMediaHandle());
    }
    else
    {  
        ptrDlg->duplicateItemsByHandle(pWidget->getMediaHandle());
//        std::vector<node_info> vNodeInfo;
//        duke_media_get_hattr_node(pWidget->getMediaHandle(), vNodeInfo);
//        duke_media_set_hattr_node(ptrDlg->getMediaHandle(), vNodeInfo);
    }
    ptrDlg->initRunEditor();
    
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

void DExehouseImpl::onDnDStart(const DEvent &event)
{
    const std::vector<DPath>& childPath = event.getEventPath();    
    DObject* pObject = m_pWarehouseDlg->findChild(childPath[0]);
    DButton* pButton = dynamic_cast<DButton*>(pObject);
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    if(pButton == NULL)
    {
        assert(!"Only support drag button in warehouse dialog.");
    }

    //Create new button in warehouse
    DButtonPtr ptrItemButton(new(std::nothrow) DButton("",
                                                       *pButton->image(),
                                                       pMainWin->getRootWidget()));
    ptrItemButton->setGeometry(0, 0, 1000, 1000);
    pMainWin->insertWidget(ptrItemButton);    
    pMainWin->setDragWidget(ptrItemButton.get());
}

void DExehouseImpl::onCreateNew(const DEvent &event)
{
    DMainWin * pMainWin = m_pWarehouseDlg->mainWin();

    //Create new about dialog in mainwin and new button in toolwin
    DRunEditorPtr ptrDlg(new(std::nothrow) DRunEditor(RunEditor_ObjName, 
                DEditor::DialogModel,
                pMainWin,
                pMainWin->getRootWidget()));
    ptrDlg->setGeometry(4000, 4000, 
            Default_RunEditor_W_InMainWin, 
            Default_RunEditor_H_InMainWin);    
    ptrDlg->initDialog();
    DButton* pButton = pMainWin->toolWin()->createButtonForWidget(ptrDlg.get());
    //Updated the button image
    DImage img;
    img.load(getResPath() + ToolWin_RunButton_Filename);
    pButton->setImage(img);
    img.load(getResPath() + ToolWin_RunSelButton_Filename);
    pButton->setSelImage(img);

    //Insert widget to mainwin
    pMainWin->insertWidget(ptrDlg);
    ptrDlg->setMediaByType(/*DUKE_MEDIA_TYPE_FUNCTION_EXECUTE*/DUKE_MEDIA_TYPE_NULL);
    ptrDlg->initRunEditor();
    
    //update children and show
    pButton->updateAll();
    ptrDlg->updateAll();
    pButton->show(event.getCon());
    ptrDlg->show(event.getCon());
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
