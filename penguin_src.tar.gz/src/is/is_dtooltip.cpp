/****************************************************************************
**
** Copyright 2010 Duke Inc.
**
** Author Qiaowei
**
****************************************************************************/

// Duke header files
#include "is_dtooltip.h"
#include "is_dtool.h"

DToolTip::DToolTip(DWidget *parent, WFlags f)
    : DWidget(*new DToolTipCell, parent, f),
      m_tip("Unknown"),
      m_line(1),
      m_width(DToolTip_Max_Width),
      m_height(DToolTip_Line_Height)
{
    setObjectName(DToolTip_ObjName);    
    d_func()->init();
}

DToolTip::~DToolTip()
{
}

void DToolTip::add(DWidget *w, const std::string &s, const is_response_call& response_call)
{
    DRect rect = w->geometry();
    DWidget *p = dynamic_cast<DWidget *>(w->parent());
    if(p == NULL)
        return;

    while (p != parent()) {
        DRect parentRect = p->geometry();
        rect.setLeft(parentRect.left() + 
                (parentRect.width() * rect.left())/MAX_COORD);
        rect.setTop(parentRect.top() + 
                (parentRect.height() * rect.top())/MAX_COORD);
        rect.setRight(parentRect.left() + 
                (parentRect.width() * rect.right())/MAX_COORD);
        rect.setBottom(parentRect.top() + 
                (parentRect.height() * rect.bottom())/MAX_COORD);

        p = dynamic_cast<DWidget *>(p->parent());
    }

    int strLen = s.size();
    int textWidth = DToolTip_Max_Width - DToolTip_Line_Height;
    if (strLen < DToolTip_Line_Words) {
        m_line = 1;
        m_width = (strLen*textWidth)/DToolTip_Line_Words + DToolTip_Line_Height;
        m_height = DToolTip_Line_Height;
    } else {
        m_line = strLen/DToolTip_Line_Words + 
            (strLen % DToolTip_Line_Words ? 1 : 0);
        m_width = DToolTip_Max_Width;
        m_height = DToolTip_Line_Height * m_line; 
    }

    if (rect.right() + DToolTip_Space_Between + m_width > MAX_COORD) {
        // right tip
        setGeometry(rect.left() - DToolTip_Space_Between - m_width,
                rect.top() + (rect.height() - m_height) / 2,
                m_width,
                m_height);
    } else {
        // left tip
        setGeometry(rect.right() + DToolTip_Space_Between,
                rect.top() + (rect.height() - m_height) / 2,
                m_width,
                m_height);
    }

    m_tip = s;

    updateAll();
    display(response_call);
}

void DToolTip::remove(const is_response_call& response_call)
{
    hide(response_call);
}

/***************************************************************************
 * DToolTipCell member functions
 **************************************************************************/
DToolTipCell::DToolTipCell()
{
}

DToolTipCell::~DToolTipCell()
{
}

void DToolTipCell::init()
{
    DToolTip *q = q_func();

    // rectangle border
    TPlacement tRectPlace;
    TRectangle tRect;

    TPath tRectPath(m_place->path);
    tRectPath.node.push_back(0);
    tRectPlace.path = tRectPath;
    tRect.fill = true;
    DColor2TColor(DToolTip_Background_Color, tRect.background);
    DColor2TColor(DToolTip_Edge_Color, tRect.edgeColor);
    tRectPlace.position.x = tRectPlace.position.y = MIN_COORD;
    tRectPlace.size.width = tRectPlace.size.height = MAX_COORD;
    tRect.roundRadius = 5000;
    tRectPlace.data = &tRect;

    subNodes.push_back(tRectPlace);
    (q->cnum())++;
    tRectPlace.data = NULL;
}

void DToolTipCell::update()
{
    DWidgetCell::update();

    DToolTip *q = q_func();

    subNodes.erase(subNodes.begin()+1, subNodes.end());

    TPlacement *place = &subNodes[0];
    TRectangle *rect = dynamic_cast<TRectangle *>(place->data);
    assert(rect != NULL);
    rect->roundRadius = 5000 / q->m_line;

    int textLeft = (DToolTip_Line_Height*MAX_COORD)/(2*q->m_width);
    int fontSize = MAX_COORD*8/11;//(q->m_line*11);

//    if (q->m_tip.size() < (unsigned int)DToolTip_Line_Words) 
//        fontSize = MAX_COORD / q->m_tip.size();
//    else
//        fontSize = MAX_COORD / DToolTip_Line_Words;
//    std::cout << "tip " << q->m_tip << ", size " << 
//        q->m_tip.size() << ", line " << q->m_line << std::endl;
//    std::cout << "tip width " << q->m_width << 
//        ", tip height " << q->m_height << std::endl;

    for (int i=0; i<q->m_line; i++) {
        TPlacement tTextPlace;
        TText tText;

        TPath tTextPath(m_place->path);
        tTextPath.node.push_back(i+1);
        tTextPlace.path = tTextPath;
        DColor2TColor(DToolTip_Font_Color, tText.color);
        tTextPlace.position.x = textLeft;
        tTextPlace.position.y = (MAX_COORD/q->m_line)*i;
        tTextPlace.size.width = MAX_COORD - textLeft*2;
        tTextPlace.size.height = MAX_COORD/q->m_line;
        tTextPlace.order = q->displayOrder();
        tText.layout = Left;
        tText.font.size = fontSize;
        tText.text = q->m_tip.substr(i*DToolTip_Line_Words, 
                (i<q->m_line-1) ? DToolTip_Line_Words
                                : q->m_tip.size() - i*DToolTip_Line_Words); 
        tTextPlace.data = &tText;

        subNodes.push_back(tTextPlace);
        (q->cnum())++;
        tTextPlace.data = NULL;
//        std::cout << "" << i << " line " << tText.text << 
//            ", nodes " << subNodes.size() << 
//            ", font size " << fontSize << std::endl;
    }
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
