#include "duke_media_implement.h"

#include "stdx_log.h"
#include "nb_profiler.h"
#include "duke_media_global.h"

#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
duke_media_implement::duke_media_implement()
{
}


duke_media_implement::~duke_media_implement()
{
}


duke_media_implement::duke_media_implement(const host_committer_id_t& host_id, const std::string& username)
    : duke_media_base(DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT, host_id), 
    m_type(DUKE_NODE_NONE), 
    m_master(duke_media_handle_null),
    m_shared(false)
{
    // save to tempobj_db
    bool ret = init_save(); 
    assert(ret);
}


duke_media_implement::duke_media_implement(const duke_media_handle& himpl, const std::string& username) 
{
    bool ret = this->assign(himpl);
    assert(ret);
}

//virtual
void duke_media_implement::unpack(const std::string& strval)
{
    unpack_helper(strval);
}

void duke_media_implement::unpack_helper(const std::string& strval)
{
    nb_handle_status  status;
    status = this->get_handle_status();

    if (status == e_handle_temp || status == e_handle_formal)
    {
        deserialize_by_msgpack(strval, *this);

        //----for DB forward-compability-----
        duke_media_handle_vector hiifs, hoifs;
        m_decl.get_interfaces(hiifs, hoifs);

        if (hiifs.empty())
            hiifs = m_in_ports;
        if (hoifs.empty())
            hoifs = m_out_ports;

        m_decl.set_interfaces(hiifs, hoifs);
        //-----------------------------------
    }
    else if (status == e_handle_core)
    {
        unpack_from_core_data(strval);
    }
}

bool duke_media_implement::unpack_from_core_data(const std::string& strval)
{
    if (strval.empty())
        return false;
    
    // set the impl type
    m_type = DUKE_NODE_DEFAULT;


    content con;
    unpack_object(strval, con);

    exec_impl_graph_t graph;
    nb_id_t tmp_id;
    obj_impl_exec_impl::unpack(con, tmp_id, graph);

    // set the impl name
    m_decl.m_name = graph.name;

    // set the impl interface
    duke_media_handle_vector hiifs, hoifs;
    duke_media_compound_declare hdecl(graph.external_decl);
    hdecl.get_interfaces(hiifs, hoifs);

    m_decl.set_interfaces(hiifs, hoifs);

    // set the input node
    int inum(0), onum(0);
    for (std::vector<node_path_t>::const_iterator it = graph.paths.begin(); it != graph.paths.end(); ++it)
    {
        if (it->in_node == -1)
            ++inum;
        if (it->out_node == -3)
            ++onum;
    }
    m_graph.set_input_node("input_node", inum);
    m_graph.set_output_node("output_node", onum);

    // object nodes
    // (we must append a unique index to each of the obj name)
    const int obj_index_base = 0;
    int obj_index = obj_index_base;
    for (std::vector<nb_id_t>::const_iterator it = graph.constants.begin(); it != graph.constants.end(); ++it)
    {
        // get the constant name
        std::string name;
        duke_media_get_name(*it, name); 
        // append an index
        name.append("_" + boost::lexical_cast<std::string>(obj_index++));

        m_graph.add_object_node(name, *it);
    }

    // func nodes
    // (we must append a unique index to each of the func name)
    const int func_index_base = obj_index;
    int func_index = func_index_base;
    for (std::vector<nb_id_t>::const_iterator it = graph.nodes.begin(); it != graph.nodes.end(); ++it)
    {
        // load the obj func from db
        std::string strval;
        ac_object_db_impl::instance().read_(it->str(), strval);
        if (!strval.empty())
        {
            content con;
            unpack_object(strval, con);

            if (it->is_object_exec_obj_func())
            {
                // get the func name and decl
                exec_obj_func_data_t data_t;
                nb_id_t obj_id;
                obj_impl_exec_obj_func::unpack(con, obj_id, data_t);

                // append an index
                data_t.name.append("_" + boost::lexical_cast<std::string>(func_index++));

                m_graph.add_func_node(data_t.name, data_t.selected_decl);
            }
        }
    }

    // Paths
    for (std::vector<node_path_t>::const_iterator it = graph.paths.begin(); it != graph.paths.end(); ++it)
    {
        duke_logic_data_path tmp_path;
        if (it->in_node == -1) // set input node
            tmp_path.m_onode = "input_node";
        else if (it->in_node == -2) // set object node
        {
            std::string name;
            duke_media_get_name(graph.constants[it->in_port], name);

            int index = obj_index_base + it->in_port;
            name.append("_" + boost::lexical_cast<std::string>(index));

            tmp_path.m_onode = name;
        }
        else
        /// it->in_node > 0, means the path is from a function
        {
            assert(it->in_node >= 0);
            assert(static_cast<std::size_t>(it->in_node) < graph.nodes.size());

            // read name from core
            nb_id_t id = graph.nodes[it->in_node];
            std::string strval;
            ac_object_db_impl::instance().read_(id.str(), strval);
            content con;
            unpack_object(strval, con);

            if (id.is_object_exec_obj_func())
            {
                exec_obj_func_data_t data_t;
                nb_id_t obj_id;
                obj_impl_exec_obj_func::unpack(con, obj_id, data_t);

                int index = func_index_base + it->in_node;
                data_t.name.append("_" + boost::lexical_cast<std::string>(index));

                tmp_path.m_onode = data_t.name;
            }
        }

        // set in port
        if (it->in_node == -1)
            tmp_path.m_oport = it->in_port;
        else if (it->in_node == -2)
            tmp_path.m_oport = 0;
        else 
            tmp_path.m_oport = it->in_port;

        // set out node
        if (it->out_node == -3)
            tmp_path.m_inode = "output_node";
        else
        {
            nb_id_t id = graph.nodes.at(it->out_node);
            std::string strval;
            ac_object_db_impl::instance().read_(id.str(), strval);
            content con;
            unpack_object(strval, con);

            if (id.is_object_exec_obj_func())
            {
                exec_obj_func_data_t data_t;
                nb_id_t obj_id;
                obj_impl_exec_obj_func::unpack(con, obj_id, data_t);

                int index = func_index_base + it->out_node;
                data_t.name.append("_" + boost::lexical_cast<std::string>(index));

                tmp_path.m_inode = data_t.name;
            }
        }

        // set out port
        tmp_path.m_iport = it->out_port;

        m_graph.add_path(tmp_path);
    }

    // master
    m_master = graph.master;

    // TODO shared
    if (duke_media_handle_null == m_master || m_master.is_object_none())
    {
        m_shared = true;
    }
    else
    {
        m_shared = false;
    }

    return true; 
}


// methods for implement
bool duke_media_implement::assign(const duke_media_handle& himpl)
{
    assert(himpl.is_implementation());

    if (himpl.is_implementation())
    {
        std::string strimpl;
        this->set_handle_status( himpl.get_value(strimpl) );

        if(!strimpl.empty())
        {
            this->unpack(strimpl);
        }
        else
        {
            LOG_DEBUG("this implement " << himpl.str() << " has no data! Maybe in edit init period.");
        }
        
        this->set_handle(himpl);
    }

    return true;
}

bool duke_media_implement::clear_flags()
{
    return this->set_general();
}

bool duke_media_implement::loop() const
{
    return (m_type == DUKE_NODE_LOOP) ? true : false;
}

bool duke_media_implement::set_loop()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = true;
    if (m_type != DUKE_NODE_LOOP)
    {
        m_type = DUKE_NODE_LOOP;
        ret = this->save();
    }
    return ret;
}

bool duke_media_implement::cond() const
{
    return (m_type == DUKE_NODE_COND) ? true : false;
}

bool duke_media_implement::set_cond()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = true;
    if (m_type != DUKE_NODE_COND)
    {
        m_type = DUKE_NODE_COND;
        ret = this->save();
    }
    return ret;
}

bool duke_media_implement::general() const
{
    return (m_type == DUKE_NODE_DEFAULT) ? true : false;
}

bool duke_media_implement::set_general()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = true;
    if (m_type != DUKE_NODE_DEFAULT)
    {
        m_type = DUKE_NODE_DEFAULT;
        ret = this->save();
    }
    return ret;
}

bool duke_media_implement::none() const
{
    return (m_type == DUKE_NODE_NONE) ?  true : false;
}

bool duke_media_implement::set_none()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = true;
    if (m_type != DUKE_NODE_NONE)
    {
        m_type = DUKE_NODE_NONE;
        ret = this->save();
    }
    return ret;
}

bool duke_media_implement::get_name(std::string& name) const
{
    name = m_decl.m_name;
    return true;
}

bool duke_media_implement::set_name(const std::string& name)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_decl.m_name = name;
    this->save();

    bool ret = duke_media_save_handle_name(this->get_handle(), name);
    assert(ret);

    return ret;
}

bool duke_media_implement::get_icon(std::string& icon) const
{
    icon = m_decl.m_icon;
    return true;
}

bool duke_media_implement::set_icon(const std::string& icon)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_decl.m_icon = icon;
    return this->save();
}

// interfaces
bool duke_media_implement::get_interfaces(duke_media_handle_vector& hiifs,
                                          duke_media_handle_vector& hoifs) const
{
    return m_decl.get_interfaces(hiifs, hoifs);
}

bool duke_media_implement::get_in_interfaces(duke_media_handle_vector& hiifs) const
{
    duke_media_handle_vector hoifs;
    return m_decl.get_interfaces(hiifs, hoifs);
}

bool duke_media_implement::get_out_interfaces(duke_media_handle_vector& hoifs) const
{
    duke_media_handle_vector hiifs;
    return m_decl.get_interfaces(hiifs, hoifs);
}

int duke_media_implement::get_iport_number() const
{
    return m_decl.get_iport_number();
}

int duke_media_implement::get_oport_number() const
{
    return m_decl.get_oport_number();
}

bool duke_media_implement::match_declaration(const duke_media_handle& hdecl) const
{
    duke_media_handle_vector hiifs_impl;
    duke_media_handle_vector hoifs_impl;
    bool ret = this->get_interfaces(hiifs_impl, hoifs_impl);
    assert(ret);

    duke_media_compound_declare mdecl(hdecl);
    duke_media_handle_vector hiifs_decl;
    duke_media_handle_vector hoifs_decl;
    ret = mdecl.get_interfaces(hiifs_decl, hoifs_decl);
    assert(ret);

    /*return hiifs_impl.size() == hiifs_decl.size()
        && hoifs_impl.size() == hoifs_decl.size()
        && duke::unordered_match(hiifs_impl.begin(), hiifs_impl.end(),
                                 hiifs_decl.begin(), hiifs_decl.end())
        && duke::unordered_match(hoifs_impl.begin(), hoifs_impl.end(),
                                 hoifs_decl.begin(), hoifs_decl.end());*/

    return hiifs_impl.size() == hiifs_decl.size()
        && hoifs_impl.size() == hoifs_decl.size()
        && unordered_match_t(hiifs_impl.begin(), hiifs_impl.end(),
                                 hiifs_decl.begin(), hiifs_decl.end())
        && unordered_match_t(hoifs_impl.begin(), hoifs_impl.end(),
                                 hoifs_decl.begin(), hoifs_decl.end());

}

bool duke_media_implement::match_declaration(const duke_media_handle_vector& hiifs_decl, const duke_media_handle_vector& hoifs_decl) const
{
    duke_media_handle_vector hiifs_impl;
    duke_media_handle_vector hoifs_impl;
    bool ret = this->get_interfaces(hiifs_impl, hoifs_impl);
    assert(ret);

    return hiifs_impl.size() == hiifs_decl.size()
        && hoifs_impl.size() == hoifs_decl.size()
        && unordered_match_t(hiifs_impl.begin(), hiifs_impl.end(),
                                 hiifs_decl.begin(), hiifs_decl.end())
        && unordered_match_t(hoifs_impl.begin(), hoifs_impl.end(),
                                 hoifs_decl.begin(), hoifs_decl.end());
}

// input interfaces for declaration 
bool duke_media_implement::add_input_port(const duke_media_handle& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = m_decl.add_input_port(hif);
    int nport = m_decl.get_iport_number();
    m_graph.set_input_node("input_node", nport);

    if (ret)
        ret = this->save();
    return ret;
}

bool duke_media_implement::del_input_port(const int& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = m_decl.del_input_port(hif);
    int nport = m_decl.get_iport_number();
    m_graph.set_input_node("input_node", nport);

    if (ret)
        ret = this->save();
    return ret;
}

// output interfaces for declaration 
bool duke_media_implement::add_output_port(const duke_media_handle& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = m_decl.add_output_port(hif);
    int nport = m_decl.get_oport_number();
    m_graph.set_output_node("output_node", nport);
    if (ret)
        ret = this->save();
    return ret;
}

bool duke_media_implement::del_output_port(const int& hif)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool ret = m_decl.del_output_port(hif);
    int nport = m_decl.get_oport_number();
    m_graph.set_output_node("output_node", nport);
    if (ret)
        ret = this->save();
    return ret;
}

bool duke_media_implement::clear_input_ports() 
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_decl.clear_input_ports();
    int nport = m_decl.get_iport_number();
    m_graph.set_input_node("input_node", nport);
    return this->save();
}

bool duke_media_implement::clear_output_ports() 
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_decl.clear_output_ports();
    int nport = m_decl.get_oport_number();
    m_graph.set_output_node("output_node", nport);
    return this->save();
}

bool duke_media_implement::clear_internal_nodes() 
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_graph.clear_internal_nodes();
    return this->save();
}

// methods for nodes and paths
void duke_media_implement::get_media_nodes(std::vector<duke_media_node>& nodes) const
{
    return m_graph.get_media_nodes(nodes);
}

void duke_media_implement::get_object_nodes(std::vector<duke_media_node>& nodes) const
{
    return m_graph.get_object_nodes(nodes);
}

bool duke_media_implement::set_object_node(const dukeid_t& source, const dukeid_t& dest)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_graph.set_object_node(source, dest);
    return this->save();
}

void duke_media_implement::get_func_nodes(std::vector<duke_media_node>& nodes) const
{
    return m_graph.get_func_nodes(nodes);
}

void duke_media_implement::get_media_paths(std::vector<duke_media_path>& paths) const
{
    return m_graph.get_media_paths(paths);
}

// methods for nodes
bool duke_media_implement::add_func_node(const std::string& name, 
                                        const duke_media_handle& hDecl,
                                        const duke_media_handle& hOwnerIf/* = NB_INTERFACE_NONE*/, 
                                        const duke_media_handle& hexdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_graph.add_func_node(name, hDecl, hOwnerIf, hexdecl);
    return this->save();
}

bool duke_media_implement::add_object_node(const host_committer_id_t& host_id, const std::string& name, const duke_media_handle& hobj)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    //replace the implement node in loop
    if(m_type == DUKE_NODE_LOOP && m_graph.m_nodes.size())
    {
        m_graph.m_nodes.clear();
    }

    m_graph.add_object_node(name, hobj);
    return this->save();
}

bool duke_media_implement::set_ports_by_declaration(const duke_media_handle& hdecl)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    duke_media_handle_vector hiifs, hoifs;
    duke_media_compound_declare mdecl(hdecl);
    mdecl.get_interfaces(hiifs, hoifs);

    m_decl.set_interfaces(hiifs, hoifs);

    return this->save();
}

bool duke_media_implement::remove_node(const std::string& name)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_graph.remove_node(name);
    return this->save();
}

bool duke_media_implement::add_time_path(const std::string& onode, int oport,
                  const std::string& inode, int iport, int timePort)    
{
    if (e_handle_core == this->get_handle_status())
        return false;

    if(timePort == -4)
    {
        m_graph.add_node_cnt(inode);
    }
    return this->add_path(onode, oport, inode, iport);
}

bool duke_media_implement::remove_time_path(const std::string& onode, int oport,
                     const std::string& inode, int iport, int timePort)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    if(timePort == -4)
    {
        m_graph.sub_node_cnt(inode);
    }
    return this->remove_path(onode, oport, inode, iport);
}

// methods for paths
bool duke_media_implement::add_path(const std::string& onode, int oport,
              const std::string& inode, int iport)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    if(m_graph.is_path_exist(onode, oport, inode, iport))
    {
        boost::shared_ptr<FILE> pFile(fopen("exist_path.txt", "a"), fclose);
        if (pFile.get() != NULL)
        {
            time_t tm;
            time(&tm);
            fprintf(pFile.get(), "exist_path detected at %s ,path : ( %s, %d, %s, %d) in implement : %s\n", 
                    ctime(&tm), onode.c_str(), oport, inode.c_str(), iport, m_decl.m_name.c_str());
        } 
        return true;
    }
    m_graph.add_path(onode, oport, inode, iport);

    if (0 == iport)
    {
        if (onode == "input_node")
        {
            duke_media_handle_vector vin, vout;
            m_decl.get_interfaces(vin, vout);

            int sz = vin.size();
            assert(sz > oport && oport >= 0);

            this->add_owner_func_pair(vin[oport], inode); 
            return this->save();
        }

        duke_media_node node;

        if (m_graph.get_node(onode, node))
        {
            if (node.m_hdecl.get_func_type() == NB_FUNC_GENERAL_IDENTITY)
                this->add_owner_func_pair(node.m_inputs[0], inode); 
            else if (node.m_hdecl.is_declaration() || node.m_hdecl.is_declaration_compound()
                    || node.m_hdecl.is_object_exec_condition() || node.m_hdecl.is_object_exec_iterator()
                    || node.m_hdecl.is_implementation())
                this->add_owner_func_pair(node.m_outputs[oport], inode); 
        }
    }

    return this->save();
}

bool duke_media_implement::remove_path(const std::string& onode, int oport,
                 const std::string& inode, int iport)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_graph.remove_path(onode, oport, inode, iport);

    if (0 == iport)
    {
        duke_media_node node;

        if (m_graph.get_node(onode, node))
        {
            if (node.m_hdecl.get_func_type() == NB_FUNC_GENERAL_IDENTITY)
                this->del_owner_func_pair(node.m_inputs[0], inode); 
            else if (node.m_hdecl.is_declaration() || node.m_hdecl.is_declaration_compound()
                    || node.m_hdecl.is_object_exec_condition() || node.m_hdecl.is_object_exec_iterator()
                    || node.m_hdecl.is_implementation())
                this->del_owner_func_pair(node.m_outputs[oport], inode); 
        }
    }

    return this->save();
}

bool duke_media_implement::add_owner_func_pair(const duke_media_handle& owner, const std::string& func)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_ownerfuncs.push_back(std::make_pair(owner, func));
    return this->save();
}

bool duke_media_implement::del_owner_func_pair(const duke_media_handle& owner, const std::string& func)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    for (dukeidstr_pair_vector_iterator it = m_ownerfuncs.begin(); it != m_ownerfuncs.end();++it)
    {
        if (it->first == owner && it->second == func)
        {
            m_ownerfuncs.erase(it);
            return this->save();
        }
    }

    return false;
}

bool duke_media_implement::find_owner_func_pair(const duke_media_handle& owner, const std::string& func)
{
    for (dukeidstr_pair_vector_const_iterator it = m_ownerfuncs.begin(); it != m_ownerfuncs.end();++it)
    {
        if (it->first == owner && it->second == func)
        {
            return true;
        }
    }

    return false;
}

bool duke_media_implement::find_owner(const std::string& func, duke_media_handle& owner)
{
    for (dukeidstr_pair_vector_const_iterator it = m_ownerfuncs.begin(); it != m_ownerfuncs.end();++it)
    {
        std::cout << "decl name:" << it->first.str() << ":" << it->second << std::endl;
        if (it->second == func)
        {
            owner = it->first;
            return true;
        }
    }

    return false;
}

bool duke_media_implement::clear_owner_func()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_ownerfuncs.clear();
    return this->save();
}

// Unused
void duke_media_implement::generate_out_path_info(exec_impl_graph_t& tmp_graph)
{
    std::vector<duke_media_node> nodes;
    this->get_func_nodes(nodes); 

    tmp_graph.out_paths.clear();
    std::vector<out_port_path_idx_t> tmp_path;
    for (int i = 0; i < (int)tmp_graph.paths.size(); ++i)
    {
        int icount(0);
        out_port_path_idx_t path_idx;
        for (std::vector<node_path_t>::const_iterator it = tmp_graph.paths.begin(); it != tmp_graph.paths.end(); ++it)
        {
            if (it->in_node == i)
                path_idx.path_idxs.push_back(icount);
            icount++;
        }
//        if (path_idx.path_idxs.size() != 0)
            tmp_path.push_back(path_idx);
    }
    for (int i = 0; i < (int)(nodes.size() - tmp_path.size()); ++i)
    {
        out_port_path_idx_t path_idx;
        tmp_path.push_back(path_idx);
    }
    tmp_graph.out_paths = tmp_path;

    int icount(0);
    for (std::vector<node_path_t>::const_iterator it = tmp_graph.paths.begin(); it != tmp_graph.paths.end(); ++it)
    {
        if ((*it).out_node == -3)
            ++icount;
    }
    tmp_graph.out_port_size = icount;
}


bool duke_media_implement::is_node_outport_time(const std::string& nodeName, const unsigned portNum)
{
    if(nodeName == "input_node")
    {
        return false;
    }
    return (m_graph.find_node_by_name(nodeName).m_outputs.size()==portNum) ? true : false;
}


bool duke_media_implement::is_node_inport_time(const std::string& nodeName, const unsigned portNum)
{
    if(nodeName=="output_node" || nodeName == "input_node")
        return false;
    return (m_graph.find_node_by_name(nodeName).m_inputs.size()==portNum) ? true : false;
}


bool duke_media_implement::generate(const std::string& username, duke_media_handle& handle, const host_committer_id_t& host_id, const duke_media_handle& hfather)
{
//    if(!m_graph.check() || (m_type == DUKE_NODE_NONE))
//    {
//        return false;
//    }
// 
//    std::string positioninfo;
//    duke_media_get_hattr_node(this->get_handle(), positioninfo);
//
//    bool ret = duke_media_clear_cipair_handle(this->get_handle());
//    assert(ret);
//    ret = duke_media_clear_pair_handle(this->get_handle());
//    assert(ret);
//
//    if (m_type == DUKE_NODE_DEFAULT)
//    {
//        std::string strval;
//        if (m_type == DUKE_NODE_DEFAULT)
//        {
//            strval = ""; 
//            std::string strkey = username + "-implement";
//            assert(this->get_handle().is_implementation());    
//
//            assert(this->m_graph.check());
//
//            ///////////////////////////
//            duke_media_implement impl(host_id);
//            bool ret = this->get_handle().get_value(strval);
//            assert(ret);
//            
//            std::string strname;
//            this->get_name(strname);
//            ret = duke_media_save_handle_name(impl.get_handle(), strname);
//            assert(ret);
//
//            if (!hfather.is_type_null())
//            {
//                ret = duke_media_write_pair_handle(hfather, this->get_handle(), impl.get_handle());
//                assert(ret);
//            }
//
//            replace_content(username, strval, host_id, hfather);
//
//            ret = impl.get_handle().set_value(strval);
//            assert(ret);
//
//            ret = impl.get_handle().set_value(strval);
//            assert(ret);
//            impl.unpack(strval);
//
//            duke_media_remove_handle("anonymous-name-tmp-implement", impl.get_handle());
//            duke_media_remove_handle(username + "-tmp-implement", impl.get_handle());
//
//            strval = "";
//            ret = duke_media_read_handle(strkey, strval);
//            strval += "(" + impl.get_handle().str() + ")";
//            ret = duke_media_write_handle(strkey, strval);
//            assert(ret);
//            handle = impl.get_handle();
//
//            impl.generate_general_node(hfather);
//            obj_id.str(impl.get_handle().str());
//
//            impl.print_info(impl.graph_t);
//
//            content tmp_content;
//            obj_impl_exec_impl::pack(impl.graph_t, obj_id, tmp_content);
//            strval = pack_object(tmp_content);
//
//            ac_object_db_impl::instance().write_(obj_id.str(), strval);
//
//            ret = duke_media_set_hattr_node(impl.get_handle(), positioninfo);
//
//            unsigned int iret = duke_media_tempobj_db::instance().del(impl.get_handle().str());
//            if (iret == NB_DB_RESULT_NOTFOUND)
//                LOG_NOTICE("DEL the " << impl.get_handle().str() << " implement in temp media not found;");
//            else if (iret == NB_DB_RESULT_FAILED)
//                LOG_NOTICE("DEL the " << impl.get_handle().str() << " implement in temp media failed;");
//
//            ret = duke_media_clear_pair_handle(this->get_handle());
//            assert(ret);
//        }
//    }
//        
//    if (hfather.is_implementation() || hfather.is_object_user() || hfather.is_object_container_des())
//    {
//        std::string strval;
//        if (m_type == DUKE_NODE_COND)
//        {
//            //save the graph
//            generate_general_node();
//            obj_id.str(this->get_handle().str());
//
//            std::vector<duke_media_node> obj_nodes;
//            m_graph.get_object_nodes(obj_nodes);
//
//            std::vector<duke_media_handle> vhandle;
//            std::vector<duke_media_node>::const_iterator cit;
//            for (cit = obj_nodes.begin(); cit != obj_nodes.end(); ++cit)
//            {
//                duke_media_handle hnew;
//                hnew = (*cit).m_inputs[0];
//                if ((duke_media_get_handle_status(username, (*cit).m_inputs[0]) == Edit))
//                {
//                    bool ret = duke_media_read_pair_handle(hfather, (*cit).m_inputs[0], hnew);
//                    assert(ret);
//
//                    if (hnew.is_type_null())
//                    {
//                        duke_media_implement impl((*cit).m_inputs[0]);
//                        if (!impl.generate(username, hnew, host_id, hfather))
//                        {
//                            assert(false);
//                        }
//                    }
//                }
//                vhandle.push_back(hnew);
//            }
//
//            content tmp_content;
//            obj_impl_exec_impl::pack(graph_t, obj_id, tmp_content);
//            strval = pack_object(tmp_content);
//
//            ac_object_db_impl::instance().write_(obj_id.str(), strval);
//
//            //save the iterator id  and himpl id
//            
//            duke_media_handle_pair_vector ipair;
//            strval = "";
//            duke_media_read_handle("condition_impl_id", strval);
//            unpack_dukeid_pair_vector(strval, ipair);
//
//            nb_id_t cond_id = generate_exec_condition(username, host_id, vhandle, hfather);
//            duke_media_handle cond_handle;
//            cond_handle.str(cond_id.str());
//            ipair.push_back(std::make_pair(cond_handle, this->get_handle()));
//
//            duke_media_write_handle("condition_impl_id", pack_dukeid_pair_vector(ipair));
//
//            //////////////
//            strval = "";
//            std::string strkey = username + "-implement";
//            duke_media_handle hfunc;
//            hfunc.str(cond_id.str());
//            assert(hfunc.is_implementation());
//
//            //duke_media_remove_handle_func("anonymous-name-tmp-implement", this->get_handle(), hfunc);
//            //duke_media_remove_handle_func(username + "-tmp-implement", this->get_handle(), hfunc);
//            
//            bool ret = duke_media_write_handle(hfunc.str(), "Formal");
//            assert(ret);
//
//            assert(this->m_graph.check());
//            ret = duke_media_save_handle_name(hfunc, m_decl.m_name);
//            assert(ret);
//
//            ret = duke_media_read_handle(strkey, strval);
//            strval += "(" + hfunc.str() + ")";
//            ret = duke_media_write_handle(strkey, strval);
//            assert(ret);
//        }
//        else if (m_type == DUKE_NODE_LOOP)
//        {
//            std::string strval;
//
//            std::vector<duke_media_node> obj_nodes, func_nodes;
//            m_graph.get_object_nodes(obj_nodes);
//
//            assert(obj_nodes.size() == 1);
//            assert(obj_nodes[0].m_inputs[0].is_implementation());
//
//            duke_media_handle hnew;
//            hnew = obj_nodes[0].m_inputs[0];
//            if ((duke_media_get_handle_status(username, obj_nodes[0].m_inputs[0]) == Edit))
//            {
//                bool ret = duke_media_read_pair_handle(hfather, obj_nodes[0].m_inputs[0], hnew);
//                assert(ret);
//
//                if (hnew.is_type_null())
//                {
//                    duke_media_implement impl(obj_nodes[0].m_inputs[0]);
//                    if (!impl.generate(username, hnew, host_id, hfather))
//                    {
//                        assert(false);
//                    }
//                }
//            }
//
//            assert(!hnew.is_type_null());
//            duke_media_handle himpl(hnew);
//            //save the iterator id  and himpl id
//            duke_media_handle_pair_vector ipair;
//            duke_media_read_handle("iterator_impl_id", strval);
//            unpack_dukeid_pair_vector(strval, ipair);
//
//            nb_id_t id = generate_exec_iterator(username, host_id, himpl, hfather);
//            duke_media_handle hiter;
//            hiter.str(id.str());
//            ipair.push_back(std::make_pair(hiter, himpl));
//
//            duke_media_write_handle("iterator_impl_id", pack_dukeid_pair_vector(ipair));
//
//            /////////////////
//            strval = "";
//            std::string strkey = username + "-implement";
//            duke_media_handle hfunc;
//            hfunc.str(id.str());
//            assert(hfunc.is_implementation());
//
//            //duke_media_remove_handle_func("anonymous-name-tmp-implement", this->get_handle(), hfunc);
//            //duke_media_remove_handle_func(username + "-tmp-implement", this->get_handle(), hfunc);
//
//            //bool ret = duke_media_write_handle(hfunc.str(), "Formal");
//            //assert(ret);
//
//            assert(this->m_graph.check());
//            ret = duke_media_save_handle_name(hfunc, m_decl.m_name);
//            assert(ret);
//
//            ret = duke_media_read_handle(strkey, strval);
//            strval += "(" + hfunc.str() + ")";
//            ret = duke_media_write_handle(strkey, strval);
//            assert(ret);
//        }
//    }
    return true;
}

void duke_media_implement::print_info(const exec_impl_graph_t& tmp_graph)
{
    LOG_INFO(std::string(30, '&'));
    LOG_INFO("implementation id:" << this->get_handle().str());

    LOG_DEBUG("constants ids:");
    for (std::vector<nb_id_t>::const_iterator it = tmp_graph.constants.begin(); it != tmp_graph.constants.end(); ++it)
    {
        LOG_DEBUG((*it).str());
    }
    
    LOG_DEBUG("nodes ids:");
    for (std::vector<nb_id_t>::const_iterator it = tmp_graph.nodes.begin(); it != tmp_graph.nodes.end(); ++it)
    {
        LOG_DEBUG((*it).str());
    }

    LOG_DEBUG("paths:");
    for (std::vector<node_path_t>::const_iterator it = tmp_graph.paths.begin(); it != tmp_graph.paths.end(); ++it)
    {
        LOG_DEBUG("(" << (int)it->in_node << "," 
            << (int)it->in_port << "," 
            << (int)it->out_node << "," 
            << (int)it->out_port << ")");
    }

    LOG_DEBUG(std::string(30, '*'));

    LOG_DEBUG("out paths:");
    int i(0);
    for (std::vector<out_port_path_idx_t>::const_iterator it = tmp_graph.out_paths.begin();
            it != tmp_graph.out_paths.end(); ++it)
    {
        std::ostringstream oss;
        oss << i << " func out_path idx: ";
        for (std::vector<int>::const_iterator iter = it->path_idxs.begin(); iter != it->path_idxs.end(); ++iter)
        {
            oss << *iter << " : ";
        }
        LOG_DEBUG(oss.str());

        i++;
    }

    LOG_DEBUG("out path size:" << tmp_graph.out_port_size);

    LOG_DEBUG(std::string(30, '*'));
}


bool duke_media_implement::copy(const duke_media_handle& himpl)
{
    assert(himpl.is_implementation());

    std::string strval;
    himpl.get_value(strval);;

    this->unpack(strval);

    bool ret = this->save();
    assert(ret);

    return ret;
}


bool duke_media_implement::check() const
{
    if (m_type == DUKE_NODE_NONE)
        return false;
    else if (m_decl.m_name.empty())
        return false;
    else 
        return true;
}

bool duke_media_implement::replace_path_name(const std::string& srcName, const std::string& targetName)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    bool edit = false;
    for (std::vector<duke_media_path>::iterator it = m_graph.m_paths.begin();
            it != m_graph.m_paths.end(); ++it)
    {
        if( it->m_onode == srcName)
        {
            it->m_onode = targetName;
            edit = true;
        }

    }

    if (edit)
        this->save();

    return edit;
}

bool duke_media_implement::set_share()
{
    if (e_handle_core == this->get_handle_status())
        return false;

    if (!m_shared)
        m_shared = true;
        return this->save();
}

bool duke_media_implement::get_share() const
{
    return m_shared;
}

bool duke_media_implement::set_master(const duke_media_handle& master)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_master = master;
    return this->save();
}

duke_media_handle duke_media_implement::get_master() const
{
    return m_master;
}

bool duke_media_implement::get_inports(duke_media_handle_vector& vinports) const
{
    duke_media_handle_vector vnull;
    m_decl.get_interfaces(vinports, vnull);
    return true;
}

bool duke_media_implement::get_outports(duke_media_handle_vector& voutports) const
{
    duke_media_handle_vector vnull;
    m_decl.get_interfaces(vnull, voutports);
    return true;
}

bool duke_media_implement::set_port_interfaces(const duke_media_handle_vector& viifs,
        const duke_media_handle_vector& voifs)
{
    if (e_handle_core == this->get_handle_status())
        return false;

    m_decl.set_interfaces(viifs, voifs);
    return this->save();
}

//get all duke_media_handle in duke_media_object except this object's handle
void duke_media_implement::get_related_handles(duke_media_handle_vector& vHandles)
{
    vHandles.clear();

    //master id
    vHandles.push_back(m_master);
    
    //input and output ports' interface
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    m_decl.get_interfaces(hiifs, hoifs);
    vHandles.insert(vHandles.end(), hiifs.begin(), hiifs.end());
    vHandles.insert(vHandles.end(), hoifs.begin(), hoifs.end());

    //Object Nodes
    std::vector<duke_media_node> obj_nodes;
    m_graph.get_object_nodes(obj_nodes);
    for(std::vector<duke_media_node>::iterator it = obj_nodes.begin();
            it != obj_nodes.end(); ++it)
    {
        assert(it->m_inputs.size() == 1);
        vHandles.push_back(it->m_inputs[0]);           //object node handle
    }

    //Func Nodes
    std::vector<duke_media_node> func_nodes;
    m_graph.get_func_nodes(obj_nodes);
    for(std::vector<duke_media_node>::iterator it = func_nodes.begin();
            it != func_nodes.end(); ++it)
    {
        vHandles.push_back(it->m_hdecl);                //func node handle
    }
}

// Check validation before generation
bool duke_media_implement::is_valid()
{
    if (m_type == DUKE_NODE_NONE)
    {
        LOG_ERROR("duke_media_implement::is_valid() : implementation type unset.");
        return false;
    }

    if (m_decl.m_name.empty())
    {
        LOG_ERROR("duke_media_implement::is_valid() : implementation name unset.");
        return false;
    }

    // Check input/output interfaces
    duke_media_handle_vector hiifs, hoifs;
    m_decl.get_interfaces(hiifs, hoifs);
    if (hiifs.size() < 1)
    {
        LOG_ERROR("duke_media_implement::is_valid() : inport num less than 1.");
        return false;
    }

    for (size_t i = 0; i < hiifs.size(); ++i)
    {
        if (!hiifs[i].is_interface())
        {
            LOG_ERROR("duke_media_implement::is_valid() : inport[" << i << "] invalid.");
            return false;
        }
    }

    for (size_t i = 0; i < hoifs.size(); ++i)
    {
        if (!hoifs[i].is_interface())
        {
            LOG_ERROR("duke_media_implement::is_valid() : inport[" << i << "] invalid.");
            return false;
        }
    }

    // Check object nodes
    std::vector<duke_media_node> obj_nodes;
    m_graph.get_object_nodes(obj_nodes);
    for (size_t i = 0; i < obj_nodes.size(); ++i)
    { 
        if (e_handle_unknown == get_media_handle_status(obj_nodes[i].m_inputs[0]))
        {
            LOG_ERROR("duke_media_implement::is_valid() : obj[" << i << "] invalid.");
            return false;
        }
    }

    if (m_type == DUKE_NODE_LOOP)
    {
        if (obj_nodes.size() != 1)
        {
            LOG_ERROR("duke_media_implement::is_valid() : loop must have one exec_impl.");
            return false;
        }

        if (!obj_nodes[0].m_inputs[0].is_implementation());
        {
            LOG_ERROR("duke_media_implement::is_valid() : loop must have one exec_impl.");
            return false;
        }
    }
    else if (m_type == DUKE_NODE_COND)
    {
        if (obj_nodes.size() < 1)
        {
            LOG_ERROR("duke_media_implement::is_valid() : condition have no exec_impl.");
            return false;
        }

        for (size_t i = 0; i < obj_nodes.size(); ++i)
        {
            if (!obj_nodes[i].m_inputs[0].is_implementation());
            {
                LOG_ERROR("duke_media_implement::is_valid() : condition alterante_exec[" << i << "] invalid.");
                return false;
            }
        }

    }

    // Check graphs
    // remain this work to the compiler module

    return true;
}

//transfrom duke_media_object's data struct to a xml struct(prepare for compiler)
editor_base_ptr duke_media_implement::to_xml_struct(index_manager& mgr, int& main_index)
{
    if (!this->is_valid())
        return editor_base_ptr();

    if (m_type == DUKE_NODE_DEFAULT)
    {
        return to_xml_general(mgr, main_index);
    }
    else if(m_type == DUKE_NODE_LOOP)
    {
        return to_xml_exec_iterator(mgr, main_index);
    }
    else if(m_type == DUKE_NODE_COND)
    {
        return to_xml_exec_condition(mgr, main_index);
    }
    else//m_type == DUKE_NODE_NONE
    {
        // maybe the usr forget to set the graph type

        // print a error info, regard it as DUKE_NODE_DEFAULT
        std::string name;
        this->get_name(name);
        LOG_ERROR("duke_media_implement::to_xml_struct() : graph[" << name << "]'s type not set.");

        return to_xml_general(mgr, main_index);
    }

    return editor_base_ptr();
}

editor_base_ptr duke_media_implement::to_xml_general(index_manager& mgr, int& main_index)
{
    Implementation_editor_ptr pImpl(new(std::nothrow) Implementation_editor());

    if(!pImpl)
        return pImpl;

    //obj name
    pImpl->set_name(m_decl.m_name);

    //master id
    int master = mgr.get_index_from_handle(m_master);
    pImpl->set_master(master);

    //unsupport info, give the default value
    bool repeatedStorage = false;
    pImpl->set_repeatedStorage(repeatedStorage);
    ExceptionType ex_type = NO_EXCEPTION;
    pImpl->set_handlesException(ex_type);
    
    //input and output ports' interface
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    m_decl.get_interfaces(hiifs, hoifs);

    //inports' interfaces
    std::vector<int> iports;
    for(duke_media_handle_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        iports.push_back(idx);
    }
    pImpl->set_Inputports(iports);
    
    //outports' interfaces
    std::vector<int> oports;
    for(duke_media_handle_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        oports.push_back(idx);
    }
    pImpl->set_Outputports(oports);
    
    std::map<std::string, int> name_obj, name_fun;
    std::map<std::string, int>::const_iterator citer;

    //get positon info
    std::vector<node_info> vNodeInfo;
    duke_media_get_hattr_node(get_handle(), vNodeInfo);
    std::vector<Coordinate> coordinates;
    
    //Object Node's interface
    std::vector<duke_media_node> obj_nodes;
    m_graph.get_object_nodes(obj_nodes);
    std::vector<int> constants;
    std::vector<int> timelines;
    for(std::vector<duke_media_node>::iterator it = obj_nodes.begin();
            it != obj_nodes.end(); ++it)
    {
        int idx = 0;
        assert(it->m_inputs.size() == 1);
        
        if (it->m_inputs[0].is_storage())
        {
            // get storage index
            duke_media_storage stor(it->m_inputs[0]);
            int index;
            stor.get_storage_idx(index);

            // we use an int obj with the index of the storage
            nb_id_t dummyId(NBID_TYPE_OBJECT_INT);
            dummyId.set_value(index);

            //
            idx = mgr.get_index_from_handle(duke_media_handle(dummyId));
        }
        else
        {
            idx = mgr.get_index_from_handle(it->m_inputs[0]);   
        }
        constants.push_back(idx);
        coordinates.push_back(get_coordinate_by_name(vNodeInfo, it->m_name));
        name_obj.insert(std::make_pair(it->m_name, -2));
    }
    pImpl->set_constants(constants);

    //Func Node's interface
    std::vector<duke_media_node> func_nodes;
    m_graph.get_func_nodes(func_nodes);
    std::vector<int> nodes;
    int index(-1);
    for(std::vector<duke_media_node>::iterator it = func_nodes.begin();
            it != func_nodes.end(); ++it)
    {
        //add the time line in implementation
        timelines.push_back(it->cnt);

        //chekc it is need to generate_exec_obj_func
        if (it->m_hdecl.is_object_exec_condition() || it->m_hdecl.is_object_exec_iterator())
        {
            int idx = mgr.get_index_from_handle(it->m_hdecl);
            nodes.push_back(idx);
            coordinates.push_back(get_coordinate_by_name(vNodeInfo, it->m_name));
            name_fun.insert(std::make_pair(it->m_name, ++index));
        }
        else if (it->m_hdecl.is_implementation())
        {
            duke_media_implement impl(it->m_hdecl);
            if (impl.loop())
            {
                int loop_idx;
                impl.to_xml_exec_iterator(mgr, loop_idx);
                nodes.push_back(loop_idx);
                coordinates.push_back(get_coordinate_by_name(vNodeInfo, it->m_name));
                name_fun.insert(std::make_pair(it->m_name, ++index));
            }
            else if (impl.cond())
            {
                int cond_idx;
                impl.to_xml_exec_condition(mgr, cond_idx);
                nodes.push_back(cond_idx);
                coordinates.push_back(get_coordinate_by_name(vNodeInfo, it->m_name));
                name_fun.insert(std::make_pair(it->m_name, ++index));
            }
        }
        else if (it->m_hdecl.is_declaration() || it->m_hdecl.is_declaration_compound())
        {
            // find owner to see if its storage_func or object_func
            duke_media_handle owner;
            if (!this->find_owner(it->m_name, owner))
            {
                LOG_ERROR("Found owner failed.");
                assert(false);
            }
            
            int func_index;
            if (owner.is_storage())
            {
                // get storage index
                duke_media_storage stor(owner);
                int index;
                stor.get_storage_idx(index);

                // generate storage func
                func_index = to_xml_storage_func(index, it->m_hdecl, mgr);
            }
            else
            {
                // generate object func
                func_index = to_xml_obj_func(it->m_hdecl, mgr);
            }

            nodes.push_back(func_index);
            coordinates.push_back(get_coordinate_by_name(vNodeInfo, it->m_name));
            name_fun.insert(std::make_pair(it->m_name, ++index));
        }
    }
    pImpl->set_nodes(nodes);
    pImpl->set_coordinates(coordinates);
    pImpl->set_timelines(timelines);
    
    //fill the path
    index = -1;
    std::vector<Path> paths;
    for (std::vector<duke_media_path>::const_iterator it = m_graph.m_paths.begin(); it != m_graph.m_paths.end(); ++it)
    {
        Path tmp_path;

        // set start node
        if (it->m_onode == "input_node")
            tmp_path.startNode = -1;
        else if ((citer = name_obj.find(it->m_onode)) != name_obj.end())
            tmp_path.startNode = citer->second;
        else if ((citer = name_fun.find(it->m_onode)) != name_fun.end())
            tmp_path.startNode = citer->second;

        // set start port
        if (tmp_path.startNode == -1)
        {
            tmp_path.startPort = it->m_oport;
        }
        else if (tmp_path.startNode == -2)
        {
            int index = 0;
            for(std::vector<duke_media_node>::const_iterator cit = obj_nodes.begin();
                cit != obj_nodes.end(); 
                ++cit,++index)
            {
                if(cit->m_name == it->m_onode)
                    break;
            }
            tmp_path.startPort = index;
        }
        else// startNode > 0, the path is from a func node
        {
            if(is_node_outport_time(it->m_onode, it->m_oport))
                tmp_path.startPort = -4;
            else
                tmp_path.startPort = it->m_oport;
        }


        // set stop node
        if (it->m_inode == "output_node")
            tmp_path.stopNode = -3;
        else
        {
            if ((citer = name_fun.find(it->m_inode)) == name_fun.end())
            {
                LOG_ERROR("duke_media_implement::to_xml_struct() : find no corresponding stop node for a path");

                // simple ignore the path
                //assert(false);
                continue;
            }
            tmp_path.stopNode = citer->second;
        }

        // set stop port
        if (tmp_path.stopNode == -3)
        {
            tmp_path.stopPort = it->m_iport;
        }
        else
        {
            if(is_node_inport_time(it->m_inode, it->m_iport))
            {
                tmp_path.stopPort = -4;
            }
            else
            {
                tmp_path.stopPort = it->m_iport;
            }
        }

        // save the path
        paths.push_back(tmp_path);

    }
    pImpl->set_paths(paths);
    

    // main index
    main_index = mgr.request_index_for_editor(this->get_handle(), pImpl);

    return pImpl;
}

editor_base_ptr duke_media_implement::to_xml_exec_iterator(index_manager& mgr, int& main_index)
{
    IterativeExcutable_editor_ptr pImpl(new(std::nothrow) IterativeExcutable_editor());

    //set name;
    pImpl->set_name(m_decl.m_name);

    //input and output ports' interface
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    m_decl.get_interfaces(hiifs, hoifs);

    //inports' interfaces
    std::vector<int> iports;
    for(duke_media_handle_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        iports.push_back(idx);
    }
    pImpl->set_Inputports(iports);
    
    //outports' interfaces
    std::vector<int> oports;
    for(duke_media_handle_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        oports.push_back(idx);
    }
    pImpl->set_Outputports(oports);

    //set repeated Executables
    std::vector<duke_media_node> obj_nodes, func_nodes;
    m_graph.get_object_nodes(obj_nodes);
    assert(obj_nodes.size() == 1);
    assert(obj_nodes[0].m_inputs[0].is_implementation());
    int idx = mgr.get_index_from_handle(obj_nodes[0].m_inputs[0]);
    pImpl->set_repeatedExecutable(idx);
    
    // main index
    main_index = mgr.request_index_for_editor(this->get_handle(), pImpl);

    return pImpl;
}

editor_base_ptr duke_media_implement::to_xml_exec_condition(index_manager& mgr, int& main_index)
{
    ConditionalExcutable_editor_ptr pImpl(new(std::nothrow) ConditionalExcutable_editor());

    //set name;
    pImpl->set_name(m_decl.m_name);

    //input and output ports' interface
    duke_media_handle_vector hiifs;
    duke_media_handle_vector hoifs;
    m_decl.get_interfaces(hiifs, hoifs);

    //inports' interfaces
    std::vector<int> iports;
    for(duke_media_handle_iterator it = hiifs.begin(); it != hiifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        iports.push_back(idx);
    }
    pImpl->set_Inputports(iports);
    
    //outports' interfaces
    std::vector<int> oports;
    for(duke_media_handle_iterator it = hoifs.begin(); it != hoifs.end(); ++it)
    {
        int idx = mgr.get_index_from_handle(*it);
        oports.push_back(idx);
    }
    pImpl->set_Outputports(oports);

    //set alternate Executable;
    std::vector<duke_media_node> obj_nodes;
    m_graph.get_object_nodes(obj_nodes);
    std::vector<int> alternateExecutables;
    std::vector<duke_media_node>::const_iterator cit;
    for (cit = obj_nodes.begin(); cit != obj_nodes.end(); ++cit)
    {
        int idx = mgr.get_index_from_handle((*cit).m_inputs[0]);
        alternateExecutables.push_back(idx);
    }
    pImpl->set_alternateExecutables(alternateExecutables);
    
    // main index
    main_index = mgr.request_index_for_editor(this->get_handle(), pImpl);

    return pImpl;
}

int duke_media_implement::to_xml_obj_func(const duke_media_handle& decl_id, index_manager& mgr)
{
    ObjectFunctionExecutable_editor_ptr obj_exec_ptr(new(std::nothrow) ObjectFunctionExecutable_editor());

    // set name for obj_exec
    std::string name = "obj_func";
    obj_exec_ptr->set_name(name);

    //set recoverer for obj_exec
    duke_media_handle recover = duke_media_handle(NBID_TYPE_OBJECT_NONE);
    int idx = mgr.get_index_from_handle(recover);
    obj_exec_ptr->set_recoverer(idx);

    //set selectedDeclaration
    idx = mgr.get_index_from_handle(decl_id);
    obj_exec_ptr->set_selectedDeclaration(idx);
    
    //set post cut
    bool isPostCut = false;
    obj_exec_ptr->set_postCut(isPostCut);

    //request index for the editor
    return mgr.request_index_for_editor(obj_exec_ptr);
}

int duke_media_implement::to_xml_storage_func(const int storage_idx, 
        const duke_media_handle& hdecl,
        index_manager& mgr)
{
    StorageFunctionExecutable_editor_ptr stor_func_ptr(new(std::nothrow) StorageFunctionExecutable_editor());

    stor_func_ptr->set_name("");//TODO
    stor_func_ptr->set_storageIdx(storage_idx);
    stor_func_ptr->set_selectedDeclaration(mgr.get_index_from_handle(hdecl));
    
    return mgr.request_index_for_editor(stor_func_ptr);
}

Coordinate duke_media_implement::get_coordinate_by_name(const std::vector<node_info>& vNodeInfo, const std::string& name)
{
    Coordinate coo = {};
    for (std::size_t index = 0; index < vNodeInfo.size(); ++index)
    {
        if(vNodeInfo[index].name == name)
        {
            coo.x = vNodeInfo[index].x;
            coo.y = vNodeInfo[index].y;
            coo.width = vNodeInfo[index].w;
            coo.height = vNodeInfo[index].h;
            return coo;
        }
    }

    assert(!"Unkown node position info");
    return coo;
}

bool duke_media_implement::init_save(DbTxn* txn)
{
    // only when handle is temp (or formal)
    // save to tempobj_db only
    if (e_handle_core != this->get_handle_status())
    {
        // call the virtual pack()
        return this->get_handle().set_value(this->pack_helper(), txn);
    }
    else
    {
        return false;
    }
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
