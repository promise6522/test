#ifndef __DUKE_MEDIA_GLOBAL_H
#define __DUKE_MEDIA_GLOBAL_H

#include <boost/smart_ptr.hpp>

//#include "core/duc.h"
//#include "core/duke_stdx_algorithm.h"
#include "duke_media_base.h"
#include "duke_media_declare.h"
#include "duke_media_interface.h"
#include "duke_media_bridge.h"
#include "duke_media_bridge_interface.h"
#include "duke_media_object.h"
#include "duke_media_execute.h"
#include "duc.h"
#include "stdx_algorithm.h"
#include "nb_id.h"
#include "duke_logic_object_data.h"
#include "duke_logic_handle_info.h"
#include "duke_media_verify.h"
#include "duke_media_implement.h"
#include "nb_user_manager.h"
#include "duke_media_container.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "duke_media_access.h"
#include "duke_media_anchor.h"
#include "duke_media_storage.h"
#include "duke_media_compound_interface.h"
#include "nb_semi_info_manager.h"
#include "nb_profiler.h"
#include "stdx_log.h"
#include "ac_access.h"
#include "ac_container.h"
#include "ac_storage.h"
#include "ac_anchor.h"
#include "ac_db/ac_container_db_impl.h"
#include "duke_constant_def.h"
#include "duke_media_loop.h"
#include "duke_media_condition.h"
#include "duke_media_array.h"
#include "duke_media_map.h"

template <typename _InputIterator1, typename _InputIterator2>
inline bool unordered_includes_t(_InputIterator1 first1, _InputIterator1 last1,
                               _InputIterator2 first2, _InputIterator2 last2)
{
    NEW_FUNC_SCOPE_TIMER(false);

    typedef typename std::iterator_traits<_InputIterator1>::value_type  _ValueType1;
    typedef typename std::iterator_traits<_InputIterator2>::value_type  _ValueType2;

    for ( ; first2 != last2; ++first2)
    {
        if ((*first2).is_interface_compound())
        { 
            for ( ; first1 != last1; ++first1)
            {
                if ((*first1).is_interface_compound())
                {
                    duke_media_compound_interface ifc(*first2);
                    duke_media_compound_interface ifc_t(*first1);

                    duke_media_handle hifc, hifc_t;

                    ifc.get_type(hifc);
                    ifc_t.get_type(hifc_t);

                    if (hifc == hifc_t)
                        break;
                }
            }
        }
        else 
        {
            if (std::find(first1, last1, *first2) == last1)
                break;
        }
    }
    return first2 == last2;
    return true;
}

template <typename _InputIterator1, typename _InputIterator2>
inline bool unordered_match_t(_InputIterator1 first1, _InputIterator1 last1,
                              _InputIterator2 first2, _InputIterator2 last2)
{
    NEW_FUNC_SCOPE_TIMER(false);

    typedef typename std::iterator_traits<_InputIterator1>::value_type  _ValueType1;
    typedef typename std::iterator_traits<_InputIterator2>::value_type  _ValueType2;
    
    return unordered_includes_t(first1, last1, first2, last2)
        && unordered_includes_t(first2, last2, first1, last1);
}

//print graph info and  used for error graph 
inline void print_path_info(const duke_media_graph& graph)
{
    std::vector<duke_media_path>::const_iterator it_path = graph.m_paths.begin();
    while(it_path != graph.m_paths.end())
    {
        LOG_NOTICE( "========================starting graph info=====================");
        LOG_NOTICE("( " << it_path->m_onode << ", " << it_path->m_oport << ", " 
                    << it_path->m_inode << ", " << it_path->m_iport << " )");
        ++it_path;
    }
    LOG_NOTICE( "========================ending graph info=====================");
}

//check the accuracy of map:add by elison
inline bool  graph_check(const duke_media_graph& graph)
{
    std::vector<duke_media_path>::const_iterator it_path = graph.m_paths.begin();
    std::vector<duke_media_node>::const_iterator it_node = graph.m_nodes.begin();
    //path check
    while(it_path != graph.m_paths.end())
    {
        //check input node and input port
        for(it_node = graph.m_nodes.begin(); it_node != graph.m_nodes.end(); ++it_node)
        {
            if(it_node->m_name == it_path->m_onode)
            {
                //check port
                if(static_cast<int>(it_node->m_outputs.size()) < it_path->m_oport)
                {
                    LOG_ERROR("error input port num: ( " << it_path->m_onode << ", " << it_path->m_oport << ", "
                            << it_path->m_inode << ", " << it_path->m_iport << " )"  << std::endl);
                    print_path_info(graph);
                    return false;
                }
                break;
            }
        }

        if(it_node == graph.m_nodes.end() && !(it_path->m_onode == graph.m_inode.m_name 
                    && it_path->m_oport <= static_cast<int>(graph.m_inode.m_outputs.size())))
        {
            LOG_ERROR("error input nodes: ( " << it_path->m_onode << ", " << it_path->m_oport << ", "
                    << it_path->m_inode << ", " << it_path->m_iport << " )"  << std::endl);
            print_path_info(graph);
            return false;
        }

        //check output node and output port
        for(it_node = graph.m_nodes.begin(); it_node != graph.m_nodes.end(); ++it_node)
        {
            if(it_node->m_name == it_path->m_inode)
            {
                //check port
                if(static_cast<int>(it_node->m_inputs.size()) < it_path->m_iport)
                {
                    LOG_ERROR("error output port num: ( " << it_path->m_onode << ", " << it_path->m_oport << ", "
                            << it_path->m_inode << " ," << it_path->m_iport << " )"  << std::endl);
                    print_path_info(graph);
                    return false;
                }
                break;
            }
        }


        if(it_node == graph.m_nodes.end() && !(it_path->m_inode == graph.m_onode.m_name
                    && it_path->m_iport <= static_cast<int>(graph.m_onode.m_inputs.size())))
        {
            LOG_ERROR("error output nodes: ( " << it_path->m_onode << ", " << it_path->m_oport << ", "
                    << it_path->m_inode << ", " << it_path->m_iport << " )"  << std::endl);
            print_path_info(graph);
            return false;
        }
        ++it_path;
    }

    //node check
    std::vector<duke_media_node>   vNode;
    graph.get_media_nodes(vNode);
    for(std::vector<duke_media_node>::const_iterator iteNode = vNode.begin(); 
            iteNode != vNode.end(); ++iteNode)
    {
        for(std::size_t inNum = 0; inNum != iteNode->m_inputs.size(); ++inNum)
        {
            std::vector<duke_media_path>::const_iterator itePath;
            for(itePath = graph.m_paths.begin(); itePath != graph.m_paths.end(); ++itePath)
            {
                if(static_cast<int>(inNum) == itePath->m_iport)
                {
                    break;
                }
            }

            if(itePath == graph.m_paths.end())
            {
                LOG_ERROR("ERROR : node( " << iteNode->m_name << ", " << inNum << ", " 
                        << iteNode->m_inputs.size() << " ) lack of input");  
                print_path_info(graph);
                return false;
            }
        }
    }

    return true;
}

inline duke_media_handle duke_media_set_array_interface_type(const host_committer_id_t& host_id,
        const duke_media_handle& hif, duke_media_handle& type)
{
    NEW_FUNC_SCOPE_TIMER(false);

    //assert(hif.is_interface_array());
    duke_media_compound_interface cif(host_id);
    cif.set_name("array-interface");
    duke_logic_data_interface_compound comdata;
    get_builtin_interface_compound(dukeid_t(NB_INTERFACE_ARRAY), comdata);

    //comdata.m_ifc.str(cif.get_handle().str());
    comdata.m_ifc = cif.get_handle();
    comdata.m_hext.push_back(type);
    comdata.m_type = duke_media_handle(NB_INTERFACE_ARRAY_TYPE);
    comdata.name = "array-interface";

    //content tmp_content;
    //std::string strnew;

    //comdata.m_decls.clear();
    
    for(std::size_t i = 0; i < comdata.m_decls.size(); ++i)
    {
        std::string name;
        duke_logic_static_declaration::get_builtin_name(comdata.m_decls[i].get_func_type(), name);

        duke_media_declare_expanded decl(host_id);

        decl.set_name(name);
        std::size_t ins = NB_FUNC_ARRAY_INSTRUCTION + i + 1;
        decl.set_array_type(dukeid_t(static_cast<nb_builtin_instruction_t>(ins)), type);
/*
        duke_media_compound_declare func(host_id, comdata.m_decls[i]);
        std::vector<dukeid_t> ifType(1,type);
        func.set_template_type(ifType);
        func.template_instantiation();
        decl.set_array_type(func.get_handle(), type);

        decl_expanded_data_t  cData;
        decl.get_name(cData.name);
        cData.origin_decl_id.str(decl.get_handle().str());
        for(std::size_t j = 0; j < decl.get_decl_vif().size(); ++j)
        {
            cData.expanded_ifs.push_back(nb_id_t(decl.get_decl_vif().at(i).str()));
        }
*/
        //decl_expanded_data_t  cData;

        //cData.name = name;
        //cData.origin_decl_id = nb_id_t(static_cast<nb_builtin_instruction_t>(ins));
        //cData.expanded_ifs.push_back(nb_id_t(type.str()));

        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write_(decl.get_handle().get_nb_type().str(), pack_object(tmp_content));

        comdata.m_decls[i] = decl.get_handle();
    }

    duke_logic_static_interface::get_general_instructions(comdata.m_decls);

    //duke_media_compound_interface cif2(host_id, comdata);
    //duke_media_compound_interface cif2(comdata, "");
    //duke_media_compound_interface tmp_ifc(1, comdata.m_ifc);
    //tmp_ifc.pack_new_structure();

    cif.set_data_to_handle(comdata);

    LOG_DEBUG("&&& return cif="<<cif.get_handle().str());

    return cif.get_handle();
}


inline duke_media_handle duke_media_set_map_interface_type(const host_committer_id_t& host_id,
                                                           const duke_media_handle& hif,
                                                           duke_media_handle& key_type,
                                                           duke_media_handle& val_type)
{
    NEW_FUNC_SCOPE_TIMER(false);

    //assert(hif.is_interface_array());
    duke_media_compound_interface cif(host_id);
    duke_logic_data_interface_compound comdata;
    get_builtin_interface_compound(dukeid_t(NB_INTERFACE_MAP), comdata);

    //comdata.m_ifc.str(cif.get_handle().str());
    comdata.m_ifc = cif.get_handle();
    comdata.m_hext.push_back(key_type);
    comdata.m_hext.push_back(val_type);
    comdata.m_type = duke_media_handle(NB_INTERFACE_MAP_TYPE);

    content tmp_content;
    std::string strnew;

    //comdata.m_decls.clear();
    
    for(std::size_t i = 0; i < comdata.m_decls.size(); ++i)
    {
        std::string name;
        duke_logic_static_declaration::get_builtin_name(comdata.m_decls[i].get_func_type(), name);

        duke_media_declare_expanded decl(host_id);
        decl.set_name(name);
        std::size_t ins = NB_FUNC_MAP_INSTRUCTION + i + 1;
        dukeid_vector exp_types;
        exp_types.push_back(key_type);
        exp_types.push_back(val_type);
        decl.set_expanded_type(dukeid_t(static_cast<nb_builtin_instruction_t>(ins)), exp_types);

        //decl_expanded_data_t  cData;
        //cData.name = name;
        //cData.origin_decl_id = nb_id_t(static_cast<nb_builtin_instruction_t>(ins));
        //cData.expanded_ifs.push_back(nb_id_t(key_type.str()));
        //cData.expanded_ifs.push_back(nb_id_t(val_type.str()));

        //content tmp_content;
        //obj_impl_decl_expanded::pack(cData, decl.get_handle().get_nb_type(), tmp_content);
        //ac_object_db_impl::instance().write_(decl.get_handle().get_nb_type().str(),
        //                                     pack_object(tmp_content));

        comdata.m_decls[i] = decl.get_handle();
    }

    duke_logic_static_interface::get_general_instructions(comdata.m_decls);
    //duke_media_compound_interface cif2(comdata, "");
    //duke_media_compound_interface tmp_ifc(1, comdata.m_ifc);
    //tmp_ifc.pack_new_structure();

    cif.set_data_to_handle(comdata);
    LOG_DEBUG("&&& return cif="<<cif.get_handle().str());

    return cif.get_handle();
}

inline bool duke_media_get_interface_by_object(
        const duke_media_handle& hobj, duke_media_handle& hif, const host_committer_id_t& host_id = 0)
{
    NEW_FUNC_SCOPE_TIMER(false);

    bool ret = false;
    if (hobj.is_object_none())
    {
        duke_media_none obj(hobj);
        ret= obj.get_interface(hif);
    }
    else if (hobj.is_object_bool())
    {
        duke_media_bool obj(hobj);
        ret= obj.get_interface(hif);
    }
    else if (hobj.is_object_int())
    {
        duke_media_int obj(hobj);
        ret= obj.get_interface(hif);
    }
    else if (hobj.is_object_float())
    {
        duke_media_float obj(hobj);
        ret= obj.get_interface(hif);
    }
    else if (hobj.is_object_string())
    {
        duke_media_string obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_bytes())
    {
        duke_media_bytes obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_interval())
    {
        duke_media_interval obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_time())
    {
        duke_media_time obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_array())
    {
        duke_media_array obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_map())
    {
        duke_media_map obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_user())
    {
       duke_media_object obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_bridge())
    {
        duke_media_bridge obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_container_des())
    {
        duke_media_container obj(hobj);
        ret = obj.get_interface(hif);
    }
    else if (hobj.is_object_declaration()
            || hobj.is_object_decl_compound()
            || hobj.is_object_decl_expanded())
    {
        hif = NB_INTERFACE_DECLARATION;
        ret = true;
    }
    else if (hobj.is_object_interface() 
            || hobj.is_object_compound_interface())
    {
        hif = NB_INTERFACE_INTERFACE;
        ret = true;
    }
    else if (hobj.is_object_implement())
    {
        hif = NB_INTERFACE_EXEC_IMPLEMENTATION;
        ret = true;
    }
    // for access
    else if (hobj.is_access())
    {
        duke_media_access acc(hobj, "anonymous-name");
        ret = acc.get_interface(hif);
    }

    assert(ret);
    return ret;
}

inline bool duke_media_get_interface_by_storage(
        const duke_media_handle& hstorage, duke_media_handle& hif)
{
    bool ret = false;
    if (hstorage.is_storage())
    {
        duke_media_storage stor(hstorage);
        ret= stor.get_interface(hif);
    }
    assert(ret);
    return ret;
}

inline bool duke_media_get_interface_by_container(
        const duke_media_handle& hcontainer, duke_media_handle& hif)
{
    assert(hcontainer.is_object_container_des());
    duke_media_container container(hcontainer);
    bool ret = container.get_interface(hif);
    assert(ret);
    return ret;
}

inline bool duke_media_get_interface_by_anchor(
        const duke_media_handle& hanchor, duke_media_handle& hif)
{
    assert(hanchor.is_anchor());
    duke_media_anchor anchor(hanchor);
    bool ret = anchor.get_interface(hif);
    assert(ret);
    return ret;
}

inline bool duke_media_get_declaration_by_object_func(
        const duke_media_handle& hobj, duke_media_handle& hdecl)
{
    if (hobj.is_object_exec_iterator())
    {
        std::string strval;
        ac_object_db_impl::instance().read(hobj.str(), strval);
        if (!strval.empty())
        {
            content tmp_content;
            exec_iterator_data_t iterator_data;
            nb_id_t id;
            unpack_object(strval, tmp_content);
            obj_impl_exec_iterator::unpack(tmp_content, id, iterator_data);
            hdecl.str(iterator_data.external_decl.str());
        }
    }
    else if (hobj.is_object_exec_condition())
    {
        std::string strval;
        ac_object_db_impl::instance().read(hobj.str(), strval);
        if (!strval.empty())
        {
            content tmp_content;
            exec_cond_data_t cond_data;
            nb_id_t id;
            unpack_object(strval, tmp_content);
            obj_impl_exec_condition::unpack(tmp_content, id, cond_data);
            hdecl.str(cond_data.external_decl.str());
        }
    }
    else if (hobj.is_implementation() && (!hobj.is_object_exec_condition()) && (!hobj.is_object_exec_iterator()))
    {
        //duke_media_implement impl(1, hobj);
        //impl.get_hdeclaration(hdecl);
    }
    else
        LOG_ERROR("object func decl is null!");
    return true;
}

inline bool duke_media_get_declarations_by_interface(
        const duke_media_handle& hif, duke_media_handle_vector& hdecls)
{
    NEW_FUNC_SCOPE_TIMER(false);

    assert(hif.is_interface());
    if(!hif.is_interface())
        return false;

    if (hif.is_bridge_interface())
    {
        duke_media_bridge_interface mif(hif);
        return mif.get_declarations(hdecls);
    }
    else if (hif.is_interface_compound())
    {
        duke_media_compound_interface mif(hif);
        return mif.get_declarations(hdecls);
    }
    else
    {
        LOG_DEBUG("&&& duke_media_get_declarations_by_interface, hif="<<hif.str());
        duke_media_interface mif(hif);
        mif.get_declarations(hdecls);
        LOG_DEBUG("  hedcls.size="<<hdecls.size());
        return true;
    }


    return false;
}

inline bool duke_media_get_interfaces_by_declaration(
        const duke_media_handle& hdecl,
        duke_media_handle_vector& hiifs,
        duke_media_handle_vector& hoifs
        )
{
    NEW_FUNC_SCOPE_TIMER(false);

    duke_media_declare mdecl(hdecl);
    return mdecl.get_interfaces(hiifs, hoifs);
}

inline bool duke_media_get_name(const duke_media_handle& h, std::string& strname)
{
    NEW_FUNC_SCOPE_TIMER(false);

    strname.clear();
    bool ret(false);

    ret = duke_name_db_impl::instance().read(h.str(), strname);
    // ##comment out by tom
    // assert(ret);
    if (!strname.empty())
        return ret;


    if (h.is_object_none())
    {
        duke_media_none obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_bool())
    {
        duke_media_bool obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_int())
    {
        duke_media_int obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_float())
    {
        duke_media_float obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_string())
    {
        duke_media_string obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_bytes())
    {
        duke_media_bytes obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_interval())
    {
        duke_media_interval obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_time())
    {
        duke_media_time obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_array())
    {
        duke_media_array obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_map())
    {
        duke_media_map obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_user())
    {
        duke_media_object obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_bridge())
    {
        duke_media_bridge obj(h);
        ret = obj.get_name(strname);
    }
    else if (h.is_object_container_des())
    {
        duke_media_container container(h);
        ret = container.get_name(strname);
    }
    else if (h.is_object_exec_iterator()) 
    {
        std::string strval;
        ac_object_db_impl::instance().read(h.str(), strval);
        if (!strval.empty())
        {
            content tmp_content;
            exec_iterator_data_t iterator_data;
            nb_id_t id;
            unpack_object(strval, tmp_content);
            obj_impl_exec_iterator::unpack(tmp_content, id, iterator_data);
            strname = iterator_data.name;
        }
        else
            strname = "default-iterator";
        ret = true;
    }
    else if (h.is_object_exec_condition())
    {
        std::string strval;
        ac_object_db_impl::instance().read(h.str(), strval);
        if (!strval.empty())
        {
            content tmp_content;
            exec_cond_data_t cond_data;
            nb_id_t id;
            unpack_object(strval, tmp_content);
            obj_impl_exec_condition::unpack(tmp_content, id, cond_data);
            strname = cond_data.name;
        }
        else
            strname = "default-condition";
        ret = true;
    }
    else if (h.is_access())
    {
        duke_media_access access(h);
        ret = access.get_name(strname);
    }
    else if (h.is_declaration())
    {
        if (h.is_object_decl_compound())
        {
            duke_media_compound_declare mdecl(h);
            mdecl.get_name(strname);
            ret = true;
        }
        else if(h.is_object_decl_expanded())
        {
            duke_media_declare_expanded mdecl(h);
            mdecl.get_name(strname);
            ret = true;
        }
        else if(h.is_function_instruction())
        {
            duke_logic_static_declaration::get_builtin_name(h, strname);
        }
        else
        {            
            duke_media_declare mdecl(h);
            ret = mdecl.get_name(strname);
        }        
    }
    else if (h.is_interface())
    {
        if (h.is_bridge_interface())
        {
            duke_media_bridge_interface mif(h);
            ret = mif.get_external_name(strname); 
        }
        else if (h.is_interface_compound())
        {
            duke_media_compound_interface mif(h);
            ret = mif.get_name(strname);
        }
        else
        {
            duke_media_interface mif(h);
            ret = mif.get_name(strname);
        }
    }
    else if (h.is_function_implement())
    {
        duke_media_implement mimpl(h);
        ret = mimpl.get_name(strname);
    }
    else if (h.is_execute())
    {
        //duke_media_execute mexec(1, h);
        //ret = mexec.get_name(strname);
    }
    else if (h.is_anchor())
    {
        duke_media_anchor anchor(h);
        ret = anchor.get_name(strname);
    }
    else if (h.is_storage())
    {
        duke_media_storage storage(h);
        ret = storage.get_name(strname);
    }

    ret = duke_name_db_impl::instance().write(h.str(), strname);
    assert(ret);

    return ret;
}

inline bool duke_media_get_icon(const duke_media_handle& h, std::string& stricon)
{
    NEW_FUNC_SCOPE_TIMER(false);

    bool ret = false;
    if (h.is_object())
    {
        if (h.is_object_none())
        {
            duke_media_none obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_bool())
        {
            duke_media_bool obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_int())
        {
            duke_media_int obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_float())
        {
            duke_media_float obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_string())
        {
            duke_media_string obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_bytes())
        {
            duke_media_bytes obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_interval())
        {
            duke_media_interval obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_time())
        {
            duke_media_time obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_array())
        {
            duke_media_array obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_map())
        {
            duke_media_map obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_user())
        {
            duke_media_object obj(h);
            ret = obj.get_icon(stricon);
        }
        else if (h.is_object_declaration())
        {
            duke_media_declare mdecl(h);
            ret = mdecl.get_icon(stricon);
        }
        else if (h.is_object_decl_compound())
        {
            duke_media_compound_declare comDeclare(h); 
            ret = comDeclare.get_icon(stricon);
        }
        else if (h.is_object_implement())
        {
            if (h.is_object_exec_iterator())
            {
                duke_media_loop loop(h);
                ret = loop.get_icon(stricon);
            }
            else if (h.is_object_exec_condition())
            {
                duke_media_condition con(h);
                ret = con.get_icon(stricon);
            }
            else
            {
                duke_media_implement mimpl(h);
                ret = mimpl.get_icon(stricon);
            }
        }
        else if (h.is_interface())
        {
            if (h.is_bridge_interface())
            {
                stricon = "";
                ret     = true;
            }
            else if (h.is_interface_compound())
            {
                duke_media_compound_interface comInterface(h);
                ret = comInterface.get_icon(stricon);
            }
            else
            {
                duke_media_interface mif(h);
                ret = mif.get_icon(stricon);
            }
        }
        else if (h.is_access())
        {
            duke_media_access access(h);
            ret = access.get_icon(stricon);
        }
    }
    else if (h.is_object_container_des())
    {
        duke_media_container container(h);
        ret = container.get_icon(stricon);
    }
    else if (h.is_anchor())
    {
        duke_media_anchor anchor(h);
        ret = anchor.get_icon(stricon);
    }
    else if (h.is_storage())
    {
        duke_media_storage storage(h);
        ret = storage.get_icon(stricon);
    }
    return ret;
}

inline bool add_object_handle(dukeid_t& g_handle, const duke_media_handle& hobj)
{
    std::string hstr;
    g_handle.get_value(hstr);
    hstr += "<" + hobj.str() + ">";
    LOG_DEBUG( "the hstr is:" << hstr);
    return g_handle.set_value(hstr);
}

inline bool get_object_handle(const duke_media_handle& handle, duke_media_handle_vector& hobject_vec)
{
    std::string hstr, s_handle;
    bool ret = handle.get_value(hstr);
    assert(ret);
    assert(!hstr.empty());
    std::string::size_type idx(0), idx_t(-1);
    
    while (idx_t != idx)
    {    
        idx_t = idx;
        idx = find_between(hstr, s_handle, "<", ">", idx);
        duke_media_handle handle1;
        handle1.str(s_handle);
        hobject_vec.push_back(handle1);
    }
    return true;
}

inline bool duke_media_interface_match_object(const duke_media_handle& hif, const duke_media_handle& hobj)
{
    duke_media_handle_vector hif_hdecls, obj_hdecls;
    duke_media_interface dm_if(hif);
    dm_if.get_declarations(hif_hdecls);

    duke_media_object dm_obj(hobj);
    dm_obj.get_declarations(obj_hdecls);

    //return duke_media_declarations_match<duke_media_handle_const_iterator>(obj_hdecls.begin(), obj_hdecls.end(), hif_hdecls.begin(), hif_hdecls.end());
    return true;
}

bool duke_media_interface_match_interface(const duke_media_handle& hif1, const duke_media_handle& hif2);
bool duke_media_interface_cover_interface(const duke_media_handle& hif1, const duke_media_handle& hif2);

inline bool duke_media_decls_match_decls(duke_media_handle_vector& hif1_decls, duke_media_handle_vector& hif2_decls)
{
    while(hif2_decls.size())
    {
        if (hif2_decls[0].is_function_compose() || hif2_decls[0].is_function_decompose())
        {
            hif2_decls.erase(hif2_decls.begin());
            continue;
        }

        else if (hif2_decls[0].is_function_instruction() || hif2_decls[0].is_object_decl_compound())
        {
            size_t hif1_decls_size = hif1_decls.size();
            for (size_t i = 0; i < hif1_decls.size(); ++i)
            {
                if (hif2_decls[0] == hif1_decls[i])
                {
                    hif1_decls.erase(hif1_decls.begin() + i);
                    hif2_decls.erase(hif2_decls.begin());
                    break;
                }
            }

            if (hif1_decls_size != hif1_decls.size() + 1)
            {
                LOG_NOTICE("if cover if failed");
                return false;
            }
            continue;
        }

        else
        {
            duke_media_declare_expanded  decl_expanded(hif2_decls[0]);
            duke_media_handle  origin_decl = decl_expanded.get_decl_id();
            duke_media_handle_vector  expanded_ifs = decl_expanded.get_decl_vif();

            size_t hif1_decls_size = hif1_decls.size();
            for (size_t i = 0; i < hif1_decls.size(); ++i)
            {
                if (hif1_decls[i].is_object_decl_expanded())
                {
                    duke_media_declare_expanded  decl_exp(hif1_decls[i]);
                    duke_media_handle  orig_decl = decl_exp.get_decl_id();

                    if (orig_decl == origin_decl)
                    {
                        duke_media_handle_vector exp_ifs = decl_exp.get_decl_vif();

                        if (exp_ifs.size() != expanded_ifs.size())
                        {
                            LOG_NOTICE("if cover if failed");
                            return false;
                        }

                        for (size_t j = 0; j < exp_ifs.size(); ++j)
                            if (!duke_media_interface_cover_interface(expanded_ifs[j], exp_ifs[j]) ||
                                !duke_media_interface_cover_interface(exp_ifs[j], expanded_ifs[j]))
                            {
                                LOG_NOTICE("if cover if failed");
                                return false;
                            }
                        hif1_decls.erase(hif1_decls.begin() + i);
                        hif2_decls.erase(hif2_decls.begin());
                        break;
                    }
                }
            }

            if (hif1_decls_size != hif1_decls.size() + 1)
            {
                LOG_NOTICE("if cover if failed");
                return false;
            }
            continue;
        }
    }

    LOG_NOTICE("if cover if success");
    return true;
}

//this func is used for interface cover in two implement's input/ouput
inline bool duke_media_implement_cover_implement(const duke_media_handle& hImpl1, const duke_media_handle& hImpl2)
{
    if(!hImpl1.is_object_implement() || !hImpl2.is_object_implement())
    {
        return false;
    }
    
    duke_media_implement          impl1(hImpl1);
    duke_media_implement          impl2(hImpl2);

    dukeid_vector          vIn1, vOut1;
    impl1.get_interfaces(vIn1, vOut1);

    dukeid_vector          vIn2, vOut2;
    impl2.get_interfaces(vIn2, vOut2);
    
    if(vIn1.size() != vIn2.size() || vIn1.size() != vOut1.size())
    {
        LOG_ERROR("input/output decl do not cover implement's decl of your draging");
        return false;
    }

    for(std::size_t i = 0; i != vIn1.size(); ++i)
    {
        if(!duke_media_interface_cover_interface(vIn1[i], vIn2[i]))
        {
            LOG_ERROR("input/output decl do not cover implement's decl of your draging");
            return false;
        }
    }

    for(std::size_t i = 0; i != vOut1.size(); ++i)
    {
        if(!duke_media_interface_cover_interface(vOut1[i], vOut2[i]))
        {
            LOG_ERROR("input/output decl do not cover implement's decl of your draging");
            return false;
        }
    }
    return true;
}

inline bool duke_media_interface_cover_interface(const duke_media_handle& hif1, const duke_media_handle& hif2)
{
    NEW_FUNC_SCOPE_TIMER(false);

    // add for duke_media_handle_null
    if (hif1 == duke_media_handle_null || hif2 == duke_media_handle_null)
    {
        LOG_DEBUG( "&&& duke_media_interface_cover_interface, hif1 = " << hif1.str() << 
                                                           ", hif2 = " << hif2.str());
        LOG_NOTICE("if cover if failed");
        return false;
    }

    //assert(hif1.is_interface() && hif2.is_interface());
    if (!hif1.is_interface())
    {
        LOG_NOTICE("Oh No : the input's hif1 id is not a interface id");
        return false;
    }
    else if (!hif2.is_interface())
    {
        LOG_NOTICE("Oh No : the input's hif2 id is not a interface id");
        return false;
    }

    LOG_DEBUG( "&&& duke_media_interface_cover_interface, hif1 = " << hif1.str() << 
                                                       ", hif2 = " << hif2.str());

    if (hif1.is_interface_none() || hif2.is_interface_none())
    {
        LOG_NOTICE("if cover if success");
        return true;
    }
    else if (hif1 == hif2)
    {
        LOG_NOTICE("if cover if success");
        return true;
    }
    else if (hif1.is_interface_compound() && hif2.is_interface_compound())
    {
        duke_media_handle_vector        hif1_decls, hif2_decls;
        duke_media_compound_interface   cif1(hif1);
        duke_media_compound_interface   cif2(hif2);

        if (cif1.get_hext().size() == cif2.get_hext().size())
        {
            cif1.get_declarations(hif1_decls);
            cif2.get_declarations(hif2_decls);

            return duke_media_decls_match_decls(hif1_decls, hif2_decls);
        }
        else
        {
            LOG_NOTICE("if cover if failed");
            return false;
        }
    }
    else if (hif1.is_bridge_interface() && hif2.is_bridge_interface())
    {
        duke_media_bridge_interface  bif1(hif1);
        duke_media_bridge_interface  bif2(hif2);

        std::string bif1_name, bif2_name, abstractvisible_name("TAbstractVisible"), tnone_name("TNone");
        bif1.get_external_name(bif1_name);
        bif2.get_external_name(bif2_name);

        if(bif1_name == abstractvisible_name || bif2_name == abstractvisible_name ||
           bif1_name == tnone_name           || bif2_name == tnone_name           ||
           bif1_name == bif2_name)
        {
            LOG_NOTICE("if cover if success");
            return true;
        }
    }

    LOG_NOTICE("if cover if failed");
    return false;
}

inline bool duke_media_interface_match_interface(const duke_media_handle& hif1, const duke_media_handle& hif2)
{
    NEW_FUNC_SCOPE_TIMER(false);

    // add for duke_media_handle_null
    if (hif1 == duke_media_handle_null || hif2 == duke_media_handle_null)
    {
        LOG_DEBUG("&&& duke_media_interface_match_interface, hif1 = " << hif1.str() << 
                                                          ", hif2 = " << hif2.str());
        LOG_NOTICE("if match if failed");
        return false;
    }

    //assert(hif1.is_interface() && hif2.is_interface());
    if (!hif1.is_interface())
    {
        LOG_NOTICE("Oh No : the input's hif1 id is not a interface id");
        return false;
    }
    else if (!hif2.is_interface())
    {
        LOG_NOTICE("Oh No : the input's hif2 id is not a interface id");
        return false;
    }

    LOG_DEBUG("&&& duke_media_interface_match_interface, hif1 = " << hif1.str() << 
                                                      ", hif2 = " << hif2.str());

    if (hif1 == hif2)
    {
        LOG_NOTICE("if match if success");
        return true;
    }
    else if (hif1.is_interface_compound() && hif2.is_interface_compound())
    {
        duke_media_handle_vector        hif1_decls, hif2_decls;
        duke_media_compound_interface   cif1(hif1);
        duke_media_compound_interface   cif2(hif2);

        if (cif1.get_hext().size() == cif2.get_hext().size())
        {
            if (duke_media_interface_cover_interface(hif1, hif2) && duke_media_interface_cover_interface(hif2, hif1))
            {
                LOG_NOTICE("if match if success");
                return true;
            }
            LOG_NOTICE("if match if failed");
            return false;
        }
        else
        {
            LOG_NOTICE("if match if failed");
            return false;
        }
    }
    else if (hif1.is_bridge_interface() && hif2.is_bridge_interface())
    {
        duke_media_bridge_interface  bif1(hif1);
        duke_media_bridge_interface  bif2(hif2);

        std::string bif1_name, bif2_name;
        bif1.get_external_name(bif1_name);
        bif2.get_external_name(bif2_name);

        if (bif1_name == bif2_name)
        {
            LOG_NOTICE("if match if success");
            return true;
        }
    }

    LOG_NOTICE("if match if failed");
    return false;
}

inline bool duke_media_implement_match_declare(const duke_media_handle& himpl, const duke_media_handle& hdecl)
{
    NEW_FUNC_SCOPE_TIMER(false);

    LOG_DEBUG("&&& duke_media_implement_match_declare");

    duke_media_implement       impl(himpl);
    duke_media_handle_vector   impl_in;
    duke_media_handle_vector   impl_out;

    bool ret = impl.get_interfaces(impl_in, impl_out);
    if (!ret) 
    {
        LOG_NOTICE("impl match decl failed");
        return false;
    }

    duke_media_handle_vector   decl_in;
    duke_media_handle_vector   decl_out;

    if (hdecl.is_object_decl_compound() || hdecl.is_function_compose() || hdecl.is_function_decompose())
    {
        duke_media_compound_declare  decl(hdecl);
        ret = decl.get_interfaces(decl_in, decl_out);
        if (!ret) 
        {
            LOG_NOTICE("impl match decl failed");
            return false;
        }
    }
    else
    {
        duke_media_declare  decl(hdecl);
        ret = decl.get_interfaces(decl_in, decl_out);
        if (!ret) 
        {
            LOG_NOTICE("impl match decl failed");
            return false;
        }
    }
   
    if (impl_in.size()  == decl_in.size()  &&
            impl_out.size() == decl_out.size() &&
            std::equal(impl_in.begin() + 1, impl_in.end(), decl_in.begin() + 1, duke_media_interface_match_interface) &&
            std::equal(impl_out.begin(), impl_out.end(), decl_out.begin(), duke_media_interface_match_interface))
    {
        LOG_NOTICE("impl match decl success");
        return true;
    }
    else
    {
        LOG_NOTICE("impl match decl failed");
        return false;
    }
}

inline bool duke_media_judge_interface_include_decl(const duke_media_handle& hif, const duke_media_handle& decl)
{
    //assert(hif.is_interface() && decl.is_declaration());
    if (!hif.is_interface())
    {
        LOG_NOTICE("Oh No : the input's interface id is not a interface id");
        return false;
    }
    else if (!decl.is_declaration())
    {
        LOG_NOTICE("Oh No : the input's declaration id is not a declaration id");
        return false;
    }

    duke_media_handle_vector hif_decls;
    if (hif.is_builtin_interface())
    {
        duke_media_interface mif(hif);
        mif.get_declarations(hif_decls);
    }
    else if (hif.is_interface_compound())
    {
        duke_media_compound_interface cif(hif);
        cif.get_declarations(hif_decls);
    }
    else if (hif.is_bridge_interface())
    {
        duke_media_bridge_interface bif(hif);
        bif.get_declarations(hif_decls);
    }
    else
    {
        LOG_NOTICE("judge_if_include_decl : get_declarations error!");
        return false;
    }

    for (size_t i = 0; i < hif_decls.size(); ++i)
    {
        if (hif_decls[i] == decl)
        {
            LOG_NOTICE("OK : This Decl is belong to the interface !");
            return true;
        }
    }

    LOG_NOTICE("ERROR : This Decl is not belong to the interface !");
    return false;
}

inline bool duke_media_deal_compound(const duke_media_handle& handle, duke_media_handle& type)
{
    if (handle.is_interface_compound())
    {
        duke_media_compound_interface cif1(handle);
        duke_media_handle type1 = cif1.get_extension_types(0);
        if (type1.is_bridge_interface())
        {
            type = duke_media_handle_null;
            return true;
        }
        else
        {
            type = type1;
            return true;
        }
    }
    return true;
}

inline std::string duke_media_make_execute(const duke_media_handle& hdecl, const duke_media_handle_vector& vparam)
{
    // the first element is access or object, others are parameters

    duke_media_declare ddecl(hdecl);
    assert((unsigned int)ddecl.get_iport_number() == vparam.size());
    const size_t onum = ddecl.get_oport_number();

    host_committer_id_t host_id;
    duke_media_execute mexec(host_id);
    mexec.add_input_node("input_node", vparam);
    mexec.add_func_node("decl_node", hdecl);
    mexec.add_output_node("output_node", onum);

    // building the paths from "input_node" to "decl_node"
    for (size_t i = 0; i < vparam.size(); ++i)
    {
        mexec.add_path("input_node", i, "decl_node", i);
    }

    // building the paths from "decl_node" to "output_node"
    for (size_t i = 0; i < onum; ++i)
    {
        mexec.add_path("decl_node", i, "output_node", i);
    }

    return mexec.pack();
    //    return true;
}

inline bool duke_media_send(const std::string& strexec, duke_media_handle_vector& vresult)
{
    LOG_DEBUG(">>>>>    duke_media_send is entering ...");

//    dukelog log("duke_media_send");
//    dukecmd<DUKE_CMD_TRANSD_DISPATCH_EXECUTE> cmd("localhost", g_hostid, log);
//    if (!cmd.request(strexec)) {
//        DUKELOG_ERROR(log, "DUKECMD_DISPACH_MEDIATASK request() return false.");
//        return false;
//    }

//    std::string strresult;
//    if (!cmd.respond(strresult)) {
//        DUKELOG_ERROR(log, "DUKECMD_DISPACH_MEDIATASK respond() return false.");
//        return false;
//    }
//    DUKELOG_WARNING(log, "DUKECMD_DISPACH_MEDIATASK respond() get result ID: " << strresult);

//    unpack_duke_media_handle_vector(strresult, vresult);

//    std::cout << ">>>>>    duke_media_send is leaving ..." << std::endl;

    return true;
}

//inline bool duke_media_send(const duke_media_execute& mexec, duke_media_handle_vector& vresult)
//{
//    return duke_media_send(mexec.pack(), vresult);
//}

//inline bool duke_media_send(const duke_media_handle& hdecl,
//        const duke_media_handle_vector& vparam, duke_media_handle_vector& vresult)
//{
//    std::string strexec = duke_media_make_execute(hdecl, vparam);
//    return duke_media_send(strexec, vresult);
//}

/*
inline bool duke_media_register_user(const std::string& username, const std::string& pwd = "", const std::string& id_card = "")
{
    duke_media_verify info;
    return info.register_user(username, pwd, id_card);
}

inline bool duke_media_get_register_users(std::vector<std::string>& vusers)
{
    duke_media_verify info;
    info.get_all_users(vusers);
    return true;
}

inline bool duke_media_verify_user(const std::string& username)
{
    duke_media_verify info;
    return info.verify_user(username);
}

inline bool duke_media_write_userinfo(const std::string& username, const std::string& info)
{
    if (duke_media_verify_user(username))
    {
        bool ret = duke_media_write_handle(username, info);
        return ret;
    }
    else
        return false;
}

inline bool duke_media_read_userinfo(const std::string& username, std::string& info)
{
    if (duke_media_verify_user(username))
        return duke_media_read_handle(username, info);
    else 
        return false;
}
*/

inline bool duke_media_set_scene(const std::string& username, const std::string& info)
{
    return duke_media_write_handle(username + "-scene", info);
}

inline bool duke_media_get_scene(const std::string& username, std::string& info)
{
    return duke_media_read_handle(username + "-scene", info);
}

inline bool duke_media_clear_scene(const std::string& username)
{
    return duke_media_write_handle(username + "-scene", "");
}

inline bool duke_media_set_access(const std::string& username, const duke_media_handle& handle)
{
    access_id_t access_id;
    access_id.str(handle.str());
    if(!nb_user_manager::instance().set_access_by_user(username, access_id))
    {
        LOG_ERROR("Get user access failed.");
        return false;
    }
    return true;
}

inline bool duke_media_get_access(const std::string& username, duke_media_handle& handle)
{
    access_id_t access_id;
    if(!nb_user_manager::instance().get_access_by_user(username, access_id))
    {
        LOG_ERROR("Get user access failed.");
        return false;
    }

    handle.str(access_id.str());   
    return true;
}

inline void duke_media_get_builtin_objects(const host_committer_id_t& host_id, duke_media_handle_vector& hobjs)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    bool ret = duke_media_read_handle("duke_media_builtin_objs", strval);
    assert(ret);
    if (!strval.empty())
    {
        unpack_duke_media_handle_vector(strval, hobjs);

        for (size_t i = 0; i < hobjs.size(); ++i)
        {
            if (hobjs[i].is_object_string())
            {
                duke_media_string old_str(hobjs[i]);
                std::string old_s;
                old_str.get_value(old_s);

                if (!old_s.empty())
                {
                    host_committer_id_t hc_id;
                    duke_media_string duke_str(hc_id);
                    duke_str.set_value(std::string(""));
                    hobjs[i] = duke_str.get_handle();

                    strval = pack_duke_media_handle_vector(hobjs);
                    ret = duke_media_write_handle("duke_media_builtin_objs", strval);
                }
            }
            else if (hobjs[i].is_object_bytes())
            {
                duke_media_bytes old_bytes(hobjs[i]);
                duke_bytes_t old_b;
                old_bytes.get_value(old_b);

                if (!old_b.m_value.empty())
                {
                    host_committer_id_t hc_id;
                    duke_media_bytes duke_byte(hc_id);
                    hobjs[i] = duke_byte.get_handle();

                    strval = pack_duke_media_handle_vector(hobjs);
                    ret = duke_media_write_handle("duke_media_builtin_objs", strval);
                }
            }

        }
        return;
    }
    
    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_NONE));
    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_BOOL));

    duke_media_string objstr(host_id);
    hobjs.push_back(objstr.get_handle());

    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_INT));
    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_FLOAT));

    duke_media_bytes objbytes(host_id);
    hobjs.push_back(objbytes.get_handle());

    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_INTERVAL));
    hobjs.push_back(duke_media_handle(NBID_TYPE_OBJECT_TIME));

    duke_media_array objarray(host_id);
    hobjs.push_back(objarray.get_handle());

    duke_media_map objmap(host_id);
    hobjs.push_back(objmap.get_handle());

    strval.clear();
    strval = pack_duke_media_handle_vector(hobjs);
    ret = duke_media_write_handle("duke_media_builtin_objs", strval);
    assert(ret);
}

inline void duke_media_get_builtin_interfaces(const host_committer_id_t& host_id, duke_media_handle_vector& hifs)
{
    NEW_FUNC_SCOPE_TIMER(false);

    //interface for builtin-objs
    hifs.push_back(NB_INTERFACE_NONE);
    hifs.push_back(NB_INTERFACE_BOOL);
    hifs.push_back(NB_INTERFACE_INT);
    hifs.push_back(NB_INTERFACE_FLOAT);
    hifs.push_back(NB_INTERFACE_STRING);
    hifs.push_back(NB_INTERFACE_BYTES);
    hifs.push_back(NB_INTERFACE_INTERVAL);
    hifs.push_back(NB_INTERFACE_TIME);

    //interface for declaration
    hifs.push_back(NB_INTERFACE_DECLARATION);
    //interface for interface
    hifs.push_back(NB_INTERFACE_INTERFACE);
    //interface for impl
    hifs.push_back(NB_INTERFACE_EXEC_IMPLEMENTATION);

    hifs.push_back(NB_INTERFACE_ROOT_ACCESS);

}

inline bool duke_media_get_impl_from_iterator(const duke_media_handle& hiter, duke_media_handle& himpl)
{
    assert(hiter.is_object_exec_iterator());
    std::string strval;
    duke_media_handle_pair_vector ipair;
    duke_media_read_handle("iterator_impl_id", strval);
    unpack_dukeid_pair_vector(strval, ipair);
    for (duke_media_handle_pair_vector_const_iterator it = ipair.begin(); it != ipair.end(); ++it)
    {
        if (it->first == hiter)
        {
            himpl = it->second;
            return true;
        }
    }
    return false;
}

inline bool duke_media_get_iterator_from_impl(const duke_media_handle& himpl, duke_media_handle& hiter)
{
    assert(himpl.is_implementation());
    std::string strval;
    duke_media_handle_pair_vector ipair;
    duke_media_read_handle("iterator_impl_id", strval);
    unpack_dukeid_pair_vector(strval, ipair);
    for (duke_media_handle_pair_vector_const_iterator it = ipair.begin(); it != ipair.end(); ++it)
    {
        if (it->second == himpl)
        {
            hiter = it->first;
            return true;
        }
    }
    return false;
}

inline bool duke_media_get_impl_from_condition(const duke_media_handle& hcond, duke_media_handle& himpl)
{
    assert(hcond.is_object_exec_condition());
    std::string strval;
    duke_media_handle_pair_vector ipair;
    duke_media_read_handle("condition_impl_id", strval);
    unpack_dukeid_pair_vector(strval, ipair);
    for (duke_media_handle_pair_vector_const_iterator it = ipair.begin(); it != ipair.end(); ++it)
    {
        if (it->first == hcond)
        {
            himpl = it->second;
            return true;
        }
    }
    return false;
}

inline bool duke_media_get_condition_from_impl(const duke_media_handle& himpl, duke_media_handle& hcond)
{
    assert(himpl.is_implementation());
    std::string strval;
    duke_media_handle_pair_vector ipair;
    duke_media_read_handle("condition_impl_id", strval);
    unpack_dukeid_pair_vector(strval, ipair);
    for (duke_media_handle_pair_vector_const_iterator it = ipair.begin(); it != ipair.end(); ++it)
    {
        if (it->second == himpl)
        {
            hcond = it->first;
            return true;
        }
    }
    return false;
}

inline bool duke_media_get_interfaces(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-interface", vid);
}

inline bool duke_media_get_compound_interfaces(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-interface-compound", vid);
}

inline bool duke_media_get_tmp_interfaces(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-interface", vid);
}

inline bool duke_media_get_tmp_compound_interfaces(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-compound-interface", vid);
}

inline bool duke_media_get_declarations(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-declaration-compound", vid);
}

inline bool duke_media_get_tmp_declarations(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-compound-declaration", vid);
}

inline bool duke_media_get_implementations(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-implement", vid);
}

inline bool duke_media_get_tmp_implementations(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-implement", vid);
}

inline bool duke_media_get_executions(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-execute", vid);
}

inline bool duke_media_get_tmp_executions(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-execute", vid);
}

inline bool duke_media_get_objects(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-object", vid);
}

inline bool duke_media_get_tmp_objects(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-object", vid);
}

inline bool duke_media_get_accesses(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-access", vid);
}

inline bool duke_media_get_tmp_accesses(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-access", vid);
}

inline bool duke_media_get_containers_def(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-container-def", vid);
}

inline bool duke_media_get_tmp_containers_def(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-container-def", vid);
}

inline bool duke_media_get_anchors(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-anchor", vid);
}

inline bool duke_media_get_tmp_anchors(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-anchor", vid);
}

inline bool duke_media_get_nokey_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-nokey-storage", vid);
}

inline bool duke_media_get_tmp_nokey_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-nokey-storage", vid);
}

inline bool duke_media_get_nokey_singleton_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-nokey-singleton-storage", vid);
}

inline bool duke_media_get_tmp_nokey_singleton_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-nokey-singleton-storage", vid);
}

inline bool duke_media_get_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-storage", vid);
}

inline bool duke_media_get_tmp_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-storage", vid);
}

inline bool duke_media_get_singleton_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-singleton-storage", vid);
}

inline bool duke_media_get_tmp_singleton_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-singleton-storage", vid);
}

inline bool duke_media_get_multi_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-multi-storage", vid);
}
inline bool duke_media_get_tmp_multi_storage(const std::string& username, duke_media_handle_vector& vid)
{
    return duke_media_get_handle(username + "-tmp-multi-storage", vid);
}

inline bool duke_media_get_multi_singleton_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-multi-singleton-storage", vid);
}

inline bool duke_media_get_tmp_multi_singleton_storage(duke_media_handle_vector& vid, const std::string& username = "anonymous-name")
{
    return duke_media_get_handle(username + "-tmp-multi-singleton-storage", vid);
}

inline bool duke_media_set_bridge(const duke_media_handle& id)
{
    std::string strkey = "bridge";
    std::string strval;
    bool ret = duke_media_check_handle(strkey, id, strval);
    if (!ret)
    {
        strval += "(" + id.str() + ")";
        ret = duke_media_write_handle(strkey, strval);
        assert(ret);
    }
    return ret;
}

inline bool create_bridge()
{
//    bridge_factory::get_factory(0, "");
    return true;
}

/*inline duke_media_handle bridge_object_material(UBuffer& buf, bridge_factory& factory, 
                                                const std::string& tx)
{
    int32_t p = buf.takeInt();
    if(int32_t(STRUCT) != p) {
        duke_object_none id;
        return id.get_id();
    }
    int32_t l = buf.takeInt();

    dukeid_t t = factory.get_interface(l);

    DUnpacker u(buf);
    return u.getData(t, tx);
}*/

inline bool duke_media_get_semi_decl(duke_media_handle_vector& decl_ids)
{
    nb_semi_info info;    
    if(nb_semi_info_manager::instance().load_semi_info(info))
    {
        for(nb_id_vector_it it = info.semi_decl.begin(); it != info.semi_decl.end(); ++it)
        {
            duke_media_handle hdecl;
            hdecl.str(it->str());        
            decl_ids.push_back(hdecl);        
        }
        return true;
    }
    return false;
}

inline bool duke_media_get_outgoing_access_if(duke_media_handle& out_ac_if)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    bridge_factory_id_t bf_id;
    bridge_factory_info_set bf_info_set;
    bridge_decl_info bf_decls;
    nb_id_t ac_if;

    //get bridge factory info from DB
    if(!read_bridge_factory_id(bf_id.str(), strval))
    {
        return false;
    }
    ac_bridge_factory_impl::unpack(strval, bf_id, bf_info_set, bf_decls, ac_if);
    out_ac_if.str(ac_if.str());
    return true;
}

inline bool duke_media_get_bridge(duke_media_handle_vector& obj_ids, duke_media_handle_vector& decl_ids)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    bridge_factory_id_t bf_id;
    bridge_factory_info_set bf_info_set;
    bridge_decl_info bf_decls;
    nb_id_t out_ac_if;

    //get bridge factory info from DB
    if(!read_bridge_factory_id(bf_id.str(), strval))
    {
        return false;
    }
    ac_bridge_factory_impl::unpack(strval, bf_id, bf_info_set, bf_decls, out_ac_if);

    //get bridge object
    for(bf_info_set_by_name::iterator it = bf_info_set.get<1>().begin();
        it != bf_info_set.get<1>().end(); ++it)
    {
        const bridge_factory_info& bf_info = (*it);
        duke_media_handle hobj;
        hobj.str(bf_info.obj_id.str());        
        obj_ids.push_back(hobj);        
    }

    //get bridge decl
    duke_media_handle hdecl;
    for(std::vector<id_name_pair>::iterator it = bf_decls.default_decls.begin();
        it != bf_decls.default_decls.end(); ++it)
    {
        hdecl.str(it->id.str());        
        decl_ids.push_back(hdecl);        
    }
    for(std::vector<id_name_pair>::iterator it = bf_decls.start_decls.begin();
        it != bf_decls.start_decls.end(); ++it)
    {
        hdecl.str(it->id.str());        
        decl_ids.push_back(hdecl);        
    }
    hdecl.str(bf_decls.general_decl.id.str());
    decl_ids.push_back(hdecl);
    return true;
}

inline bool duke_media_clone(const host_committer_id_t& host_id, const duke_media_handle& hold, duke_media_handle& hnew)
{
    NEW_FUNC_SCOPE_TIMER(false); 

    bool ret = false;
    if (hold.is_object_none())
    {
        boost::scoped_ptr<duke_media_none> new_handle(new duke_media_none(host_id));
        ret = new_handle->set_value();
        assert(ret);
        hnew = new_handle->get_handle();
    }
    else if (hold.is_object_int())
    {
        //int ival(0);
        //ret = hold.get_value(ival);
        //assert(ret);
        //boost::scoped_ptr<duke_media_int> new_handle(new duke_media_int(host_id));
        //ret = new_handle->get_handle().set_value(ival);
        //assert(ret);
        //hnew = new_handle->get_handle();
        //std::cout << hnew.str() << std::endl;
        hnew = hold;
        ret = true;
    }
    else if (hold.is_object_bool())
    {
        /*bool bval;
        ret = hold.get_value(bval);
        assert(ret);
        boost::scoped_ptr<duke_media_bool> new_handle(new duke_media_bool(host_id));
        ret = new_handle->get_handle().set_value(bval);
        assert(ret);
        hnew = new_handle->get_handle();*/
        hnew = hold;
        ret = true;
    }
    else if (hold.is_object_float())
    {
        /*float fval;
        ret = hold.get_value(fval);
        assert(ret);
        boost::scoped_ptr<duke_media_float> new_handle(new duke_media_float(host_id));
        ret = new_handle->get_handle().set_value(fval);
        assert(ret);
        hnew = new_handle->get_handle();*/
        hnew = hold;
        ret = true;
    }
    else if (hold.is_object_string())
    {
        std::string strval;
        ret = hold.get_value(strval);
        assert(ret);
        boost::scoped_ptr<duke_media_string> new_handle(new duke_media_string(host_id));
        ret = new_handle->get_handle().set_value(strval);
        assert(ret);
        hnew = new_handle->get_handle();
    }
    else if (hold.is_object_bytes())
    {
        duke_bytes_t strval;
        duke_media_bytes dbytes(hold);
        ret = dbytes.get_value(strval);
        assert(ret);
        boost::scoped_ptr<duke_media_bytes> new_handle(new duke_media_bytes(host_id));
        duke_media_bytes dbytes2(new_handle->get_handle());
        ret = dbytes2.set_value(strval);
        assert(ret);
        hnew = new_handle->get_handle();
    }
    else if (hold.is_object_interval())
    {
        duke_time_t tval;
        ret = hold.get_value(tval.second_cnt, tval.pico_second_cnt);
        assert(ret);

        boost::scoped_ptr<duke_media_interval> new_handle(new duke_media_interval(host_id));
        ret = new_handle->get_handle().set_value(tval.second_cnt, tval.pico_second_cnt);
        assert(ret);
        hnew = new_handle->get_handle();
    }
    else if (hold.is_object_time())
    {
        duke_time_t tval;
        ret = hold.get_value(tval.second_cnt, tval.pico_second_cnt);
        assert(ret);

        boost::scoped_ptr<duke_media_time> new_handle(new duke_media_time(host_id));
        ret = new_handle->get_handle().set_value(tval.second_cnt, tval.pico_second_cnt);
        assert(ret);
        hnew = new_handle->get_handle();
    }
    else if (hold.is_object_array())
    {
        std::vector<duke_media_handle> doval;
        duke_media_array darr(hold);
        ret = darr.get_elements(doval);
        assert(ret);
        duke_media_handle_vector vtype;
        //set default interface for array
        duke_media_handle handle(DUKE_MEDIA_TYPE_NULL);
        vtype.push_back(handle);
        ret = darr.get_type(vtype);
        assert(ret);

        //boost::scoped_ptr<duke_media_array> new_handle(new duke_media_array(host_id));

        //duke_media_array darr2(new_handle->get_handle(), host_id);
        duke_media_array new_handle(host_id);
        ret = new_handle.set_value(vtype, doval);
        assert(ret);
        hnew = new_handle.get_handle();
    }
    else if (hold.is_object_map())
    {
        std::multimap<duke_media_handle, duke_media_handle> doval;
        duke_media_map dmap(hold);
        ret = dmap.get_value(doval);
        assert(ret);
        duke_media_handle_vector vtype;
        duke_media_handle handle(DUKE_MEDIA_TYPE_NULL);
        vtype.push_back(handle);
        vtype.push_back(handle);
        ret = dmap.get_type(vtype);
        assert(ret);

        duke_media_map dmap2(host_id);
        ret = dmap2.set_value(vtype, doval);
        assert(ret);
        hnew = dmap2.get_handle();
    }
    else if (hold.is_declaration() && !hold.is_general_identity() && !hold.is_general_return())
    {
        duke_media_compound_declare decl(host_id);
        ret = decl.copy(hold);
        assert(ret);
        hnew = decl.get_handle();
    }
    else if (hold.is_implementation())
    {
        duke_media_implement impl(host_id);
        ret = impl.copy(hold);
        assert(ret);
        hnew = impl.get_handle();
    }
    else if (hold.is_interface())
    {
        if (hold.is_object_builtin())
        {
            // builtin-interface
            //duke_media_interface ifc(host_id);
            //ret = ifc.copy(hold);
            //assert(ret);
            hnew = hold;
        }
        else
        {
           // interface_compound 
           duke_media_compound_interface ifc(host_id);
           ret = ifc.copy(hold);
           assert(ret);
           hnew = ifc.get_handle();
        }
        //TODO bridge_interface
    }
    else if (hold.is_object_user())
    {
        LOG_ERROR("duke_media_clone() for user_obj not defined!");
        return false;
        //duke_media_object obj(host_id);
        //ret = obj.copy(hold);
        //assert(ret);
        //if (!obj.is_singleton_object())
        //    hnew = obj.get_handle();
    }
//    else if (hold.is_access())
//    {
//        duke_media_access access;
//        bool ret = access.copy(hold);
//        assert(ret);
//        if (!access.is_singleton_object())
//            hnew = access.get_handle();
//    }
    else if (hold.is_object_container_des())
    {
        duke_media_container container(host_id);
        ret = container.copy(hold);
        assert(ret);
        hnew = container.get_handle();
    }
//    else if (hold.is_anchor())
//    {
//        duke_media_anchor anchor;
//        bool ret = anchor.copy(hold);
//        assert(ret);
//        hnew = anchor.get_handle();
//    }
//    else if (hold.is_nokey_storage())
//    {
//        duke_media_nokey_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
//    else if (hold.is_nokey_singleton_storage())
//    {
//        duke_media_nokey_singleton_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
//    else if (hold.is_storage())
//    {
//        duke_media_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
//    else if (hold.is_singleton_storage())
//    {
//        duke_media_singleton_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
//    else if (hold.is_multi_storage())
//    {
//        duke_media_multi_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
//    else if (hold.is_multi_singleton_storage())
//    {
//        duke_media_multi_singleton_storage storage;
//        bool ret = storage.copy(hold);
//        assert(ret);
//        hnew = storage.get_handle();
//    }
    else
    {
        hnew = hold;
    }
    return ret;
}

inline unsigned int duke_media_read_counter()
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    unsigned int icount(0);
    duke_media_read_info("duke_media_counter", strval);
    if (strval.empty())
    {
        std::string strid = to_string(2);
        bool ret = duke_media_write_info("duke_media_counter", strid);
        assert(ret);
        icount = 2;
    }
    else if (!strval.empty())
    {
        icount = from_string<unsigned int>(strval);
        icount += 1;
        strval = to_string(icount);
        bool ret = duke_media_write_info("duke_media_counter", strval);
        assert(ret);
    }
    return icount;
}

inline bool duke_media_add_file(const unsigned int parent, const std::string& filename, unsigned int& result)
{
    std::string strval;
    result = 0;
    bool ret = duke_media_read_info(to_string(parent), strval);
    if (!strval.empty() && ret)
    {
         struct file_node m_node;
         m_node.unpack(strval);
         //judge the file name unique
         for (fileid_vector_const_iterator it = m_node.m_vhfileid.begin();
                 it != m_node.m_vhfileid.end(); ++it)
         {
             std::string strval;
             bool ret = duke_media_read_info(to_string(*it), strval);
             if (!strval.empty() && ret)
             {
                 if (strval == filename)
                    return true;
             }
         } 

         result = duke_media_read_counter();
         m_node.m_vhfileid.push_back(result);
         bool ret = duke_media_write_info(to_string(parent), m_node.pack());
         assert(ret);
    }
    else
    {
        result = duke_media_read_counter();
        struct file_node m_node;
        m_node.m_vhfileid.push_back(result);
        bool ret = duke_media_write_info(to_string(parent), m_node.pack());
        assert(ret);
    } 
    ret = duke_media_write_info(to_string(result), filename);
    assert(ret);
    return ret;
}

inline bool duke_media_add_handle(const unsigned int parent, const duke_media_handle& handle)
{    
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    bool ret = duke_media_read_info(to_string(parent), strval);
    if (!strval.empty() && ret)
    {
         struct file_node m_node;
         m_node.unpack(strval);
         if (m_node.add_handle(handle))
         {
             ret = duke_media_write_info(to_string(parent), m_node.pack());
            assert(ret);
         }
    }
    else
    {
        struct file_node m_node;
        if (m_node.add_handle(handle))
        {
            ret = duke_media_write_info(to_string(parent), m_node.pack());
            assert(ret);
        }
    } 
    return ret;
}

inline bool duke_media_read_name(const unsigned int id, std::string& filename)
{
    bool ret = duke_media_read_info(to_string(id), filename);
    if (!filename.empty() && ret)
        return true;
    else
        filename = "";
}
inline bool duke_media_read_info(const unsigned int parent, struct file_node& st_file)
{
    std::string strval;
    bool ret = duke_media_read_info(to_string(parent), strval);
    if (!strval.empty() && ret)
    {
        st_file.unpack(strval);
        return true;
    }
    return true;
}

inline bool duke_media_read_object_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "object_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_storage_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "storage_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_interface_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "interface_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_implement_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "implement_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_declare_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "declare_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_container_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "container_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_bridge_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "bridge_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}
inline bool duke_media_read_anchor_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "anchor_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_read_access_name(dukeid_vector& vhandle, dukestr_vector& vname)
{
    std::string strkey = "object_handle_name";
    return duke_media_read_name(strkey, vhandle, vname);
}

inline bool duke_media_remove_access(const std::string& username)
{
    std::string strformkey = username + "-access";
    std::string strtempkey = username + "-tmp-access";
    
    bool ret = duke_media_write_handle(strformkey, "");
    assert(ret);
 
    ret = duke_media_write_handle(strtempkey, "");
    assert(ret);
    return ret;
}

inline bool duke_media_remove_container(const std::string& username)
{
    std::string strformkey = username + "-container";
    std::string strtempkey = username + "-tmp-container";
    
    bool ret = duke_media_write_handle(strformkey, "");
    assert(ret);
 
    ret = duke_media_write_handle(strtempkey, "");
    assert(ret);
    return ret;
}

inline bool duke_media_remove_container_des(const std::string& username)
{
    std::string strformkey = username + "-object";
    
    duke_media_handle_vector vobjid, vid;
    duke_media_get_handle(strformkey, vid);
    //assert(ret);
    for (duke_media_handle_const_iterator it = vid.begin(); it != vid.end(); ++it)
    {
        if (!it->is_object_container_des())
            vobjid.push_back(*it);
    } 

    std::string strval = pack_duke_media_handle_vector(vobjid);
    bool ret = duke_media_write_handle(strformkey, strval);
    assert(ret);
    return ret;
}

// add the handle attribute interface

inline bool duke_media_set_handle_shared(const duke_media_handle& handle, bool isFlag)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    bool ret = duke_media_read_info(handle.str(), strval);
    if (!strval.empty() && ret)
    {
        handle_attr hattr;
        hattr.unpack(strval);
        hattr.is_shared = isFlag;
        strval = hattr.pack();

        ret = duke_media_write_info(handle.str(), strval);
        assert(ret);
        return ret;
    }
    return false;
}

inline bool duke_media_get_shared_objs(const std::string user_name,
                                       std::vector<duke_media_handle>& shared_obj)
{
    NEW_FUNC_SCOPE_TIMER(false);

    shared_obj.clear();    
        
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);

    for(nb_id_vector_it it = user_content.shared_objs.begin(); it != user_content.shared_objs.end(); ++it)
    {
        shared_obj.push_back(duke_media_handle(it->str()));        
    }

    for(std::vector<container_id_t>::iterator it = user_content.shared_conts.begin();
        it != user_content.shared_conts.end(); ++it)
    {
        shared_obj.push_back(duke_media_handle(it->str()));        
    }
    
    return true;
}

inline bool duke_media_remove_shared_container(const std::string user_name)
{
    NEW_FUNC_SCOPE_TIMER(false);
        
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    user_content.shared_conts.clear();
    strval.clear();
    pack_user_content(user_content, strval);

    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("write user info in database failed.");
        return false;            
    }
    
    return true;
}

inline bool duke_media_remove_shared_container_des(const std::string user_name)
{
    NEW_FUNC_SCOPE_TIMER(false);
        
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    nb_id_vector shared_objs;
    for (nb_id_vector::iterator it = user_content.shared_objs.begin(); it != user_content.shared_objs.end(); ++it)
    {
        if (!it->is_object_container_des())
            shared_objs.push_back(*it);
    }
    user_content.shared_objs = shared_objs;
    strval.clear();
    pack_user_content(user_content, strval);

    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("write user info in database failed.");
        return false;            
    }
    
    return true;
}

inline bool duke_media_remove_shared_access(const std::string user_name)
{
    NEW_FUNC_SCOPE_TIMER(false);
        
    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    user_content.shared_access_id = access_id_t();

    strval.clear();
    pack_user_content(user_content, strval);

    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("write user info in database failed.");
        return false;            
    }
    
    return true;
}

inline bool duke_media_set_shared_objs(const std::string user_name,
                                       const std::vector<duke_media_handle>& shared_obj)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;
    if(!read_user_content(user_name, strval))
    {
        LOG_ERROR("Read user info in database failed.");
        return false;            
    }
    nb_user_content user_content;        
    unpack_user_content(strval, user_content);
    user_content.shared_objs.clear();
    user_content.shared_conts.clear();

    for(std::vector<duke_media_handle>::const_iterator it = shared_obj.begin();
        it != shared_obj.end(); ++it)
    {
        user_content.shared_objs.push_back(nb_id_t(it->str()));
    }

    strval.clear();    
    pack_user_content(user_content, strval);
    if(!write_user_content(user_name, strval))
    {
        LOG_ERROR("Write user info to database failed.");
        return false;            
    }
    return true;
}

inline 
bool duke_media_get_register_users(std::vector<std::string>& user_names)
{
    NEW_FUNC_SCOPE_TIMER(false);

    std::string strval;        
    //read users info in database
    if(!read_users_info(strval))
    {
        LOG_ERROR("Read users info to database failed.");
        return false; 
    }

    nb_users_info users_info;    
    unpack_users_info(strval, users_info);
    user_names = users_info.user_names;    

    return true;
}

inline 
bool duke_media_replace_handle(std::string& strval, const duke_media_handle& hold, const duke_media_handle& hnew)
{    
    NEW_FUNC_SCOPE_TIMER(false);

    std::string old_str = hold.str();
    std::string new_str = hnew.str();
    std::size_t length = old_str.length();

    std::size_t pos(0);
    while ((pos = strval.find(old_str, pos)) != std::string::npos)
    {
        strval.replace(pos, length, new_str);
        pos += length;
    }

    return true;
}
inline bool duke_media_get_container_content_from_actor(const duke_media_handle& handle, con_content& output)
{
    if(handle.is_container())
    {
        container_id_t id(handle.str());
        ac_id_t dest_id;
        if(!ac_manager::instance().get_ac_id(id, dest_id))
            return false;

        ac_container* pActor = dynamic_cast<ac_container*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->get_value_sync(output);
        }
    } 
    return false;
}

inline bool duke_media_get_content_from_actor(const duke_media_handle& handle, content& output)
{
    if(handle.is_access())
    {
        access_id_t id(handle.str());
        ac_id_t dest_id;
        if(!ac_manager::instance().get_ac_id(id, dest_id))
            return false;

        ac_access* pActor = dynamic_cast<ac_access*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->get_value_sync(output);
        }
    } 
    else if(handle.is_storage())
    {
        storage_id_t id(handle.str());
        ac_id_t dest_id;
        if(!ac_manager::instance().get_ac_id(id, dest_id))
            return false;

        ac_storage* pActor = dynamic_cast<ac_storage*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->get_value_sync(output);
        }
    }
    else if(handle.is_anchor())
    {
        anchor_id_t id(handle.str());
        ac_id_t dest_id;
        if(!ac_manager::instance().get_ac_id(id, dest_id))
            return false;

        ac_anchor* pActor = dynamic_cast<ac_anchor*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->get_value_sync(output);
        }
    }
    else
    {
        nb_id_t id(handle.str());
        ac_id_t dest_id;
        if(!ac_manager::instance().get_ac_id(id, dest_id))
            return false;

        ac_object* pActor = dynamic_cast<ac_object*>(ac_manager::instance().acid_to_actor(dest_id));
        if(pActor)
        {
            boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
            return pActor->get_value_sync(output);
        }
    }
    
    return false;    
}
/*
inline bool duke_media_read_storage_value(const storage_id_t& id, std::vector<nb_id_t>& vid)
{
    ac_storage_db_impl *ac_stor = new ac_storage_db_impl();
    ac_stor->run(ac_storage_env_impl::instance().get_env(), id.str());

    return ac_stor->get_all(vid);
}
*/
inline bool duke_media_save_result_by_handle(const std::string& username, const duke_media_handle& handle,
                                             const std::string& name)
{
    if(handle.is_type_null())
    {
        return false;
    }
    
    if(handle.is_object_none() || handle.is_object_bool() || handle.is_object_interval()
       || handle.is_object_int() || handle.is_object_float() || handle.is_object_time() 
       || handle.is_builtin_interface() || handle.is_function_declare())
    {
        //no need to save
        return true;
    }

    LOG_NOTICE("==== Start to Save "<<handle.str()<<".");

    //there is alread a same id in database, just return true
    std::string strval;    
    NbDbResult db_ret = ac_object_db_impl::instance().read_(handle.str(), strval);
    if(db_ret == NB_DB_RESULT_SUCCESS)
    {
        return true;
    }

    if(handle.is_container())
    {
        con_content con_raw_data;    
        if(!duke_media_get_container_content_from_actor(handle, con_raw_data))
        {
            LOG_ERROR("could not get content from actor or database for id : "<<handle.str());        
            return false;
        }

        container_id_t cont_id;
        container_data_t cont_data;
        container_implementation::unpack(con_raw_data, cont_id, cont_data);
        cont_data.name = name;

        for(std::size_t i = 0; i < cont_data.anchors.size(); ++i)
        {
            std::string anchor_name = name + "_anchor_" +  boost::lexical_cast<std::string>(i);
            if(!duke_media_save_result_by_handle(username, cont_data.anchors[i], anchor_name))
            {
                LOG_ERROR("Save "<<cont_data.anchors[i].str()<<" failed;");
            }
            content output;
            duke_media_get_content_from_actor(cont_data.anchors[i], output);
            ac_object_db_impl::instance().write_(cont_data.anchors[i].str(), pack_object(output));       
        }

        
        for(std::size_t i = 0; i < cont_data.storages.size(); ++i)
        {
            std::string storage_name = name + "_storage_" +  boost::lexical_cast<std::string>(i);
            if(!duke_media_save_result_by_handle(username, cont_data.storages[i], storage_name))
            {
                LOG_ERROR("Save "<<cont_data.storages[i].str()<<" failed;");
            }
            content output;
            duke_media_get_content_from_actor(cont_data.storages[i], output);
            ac_object_db_impl::instance().write_(cont_data.storages[i].str(), pack_object(output));       

            /*
            std::vector<nb_id_t> vid;
            if (duke_media_read_storage_value(cont_data.storages[i], vid))
            {
                for (std::vector<nb_id_t>::const_iterator it = vid.begin(); it != vid.end(); ++it)
                {
                    duke_media_handle handle;
                    handle.str((*it).str());
                    if(!duke_media_save_result_by_handle(username, handle, name))
                    {
                        LOG_ERROR("Save "<< handle.str() <<" failed;");
                    }
                }
            }
            content output;
            duke_media_get_content_from_actor(cont_data.storages[i], output);    
            ac_object_db_impl::instance().write_(cont_data.storages[i].str(), pack_object(output)); */ 
        }
        
        //write container content to db
        strval.clear();
        strval = container_data_packer::pack_to_stream(con_raw_data);    
        ac_container_db_impl::instance().write(handle.str(), strval);       
        return true;
    }
    
    content raw_data;    
    if(!duke_media_get_content_from_actor(handle, raw_data))
    {
        LOG_ERROR("could not get content from actor or database for id : " <<handle.str());
        return false;
    }
    
    for(std::size_t i = 0; i < raw_data.id_value.ids.size(); ++i)
    {
        std::string subname = name + "_sub_" + boost::lexical_cast<std::string>(i);        
        if(!duke_media_save_result_by_handle(username, raw_data.id_value.ids[i], subname))
        {
            LOG_ERROR("Save "<<raw_data.id_value.ids[i].str()<<" failed;");
        }
    }
    
    bool ret = duke_media_save_handle_name(handle, name);
    assert(ret);
    if(handle.is_access())
    {
        access_data_t ac_data;
        access_implementation::unpack(raw_data, ac_data);
        std::string cont_name = name + "_cont";
        if(!duke_media_save_result_by_handle(username, ac_data.parent_container, cont_name))
        {
            LOG_ERROR("Save "<<ac_data.parent_container.str()<<" failed;");
        }
    }

    //save handle if not exist.
    if(handle.is_object_builtin())
    {
        //if it is builtin object, write to database
        if(handle.is_object_string() || handle.is_object_bytes() || handle.is_object_array()
           || handle.is_object_map())
        {
            std::string strval;    
            ac_object_db_impl::instance().read_(handle.str(), strval);
            if(strval.empty())
            {
                strval = pack_object(raw_data);
                ac_object_db_impl::instance().write_(handle.str(), strval);
            }
        }

        return true;
    }
    else if(handle.is_object_user())
    {
        //write new name to user object
        user_data_t logic_data;        
        nb_id_t id;        
        obj_impl_user::unpack(raw_data, id, logic_data);
        logic_data.name = name;
        obj_impl_user::pack(logic_data, id, raw_data);
    }
    else if(handle.is_object_bridge())
    {
        // write new name to bridge object
        bridge_data_t logic_data;        
        nb_id_t id;        
        obj_impl_bridge::unpack(raw_data, id, logic_data);
        logic_data.name = name;
        obj_impl_bridge::pack(logic_data, id, raw_data);

        // save the handle to warehouse
        std::string strkey = username + "-object";
        std::string strval = "";
        bool ret = duke_media_read_handle(strkey, strval);
        strval += "(" + handle.str() + ")";//append only?
        ret = duke_media_write_handle(strkey, strval);
    }
    else if(handle.is_declaration())
    {
        if(handle.is_object_decl_expanded())
        {
            decl_expanded_data_t logic_data;        
            nb_id_t id;        
            obj_impl_decl_expanded::unpack(raw_data, id, logic_data);
            logic_data.name = name;
            obj_impl_decl_expanded::pack(logic_data, id, raw_data);
        }
        else if (handle.is_object_decl_compound())
        {
            decl_compound_data_t logic_data;        
            nb_id_t id;        
            obj_impl_decl_compound::unpack(raw_data, id, logic_data);
            logic_data.name = name;
            obj_impl_decl_compound::pack(logic_data, id, raw_data);
        }
    }
    else if(handle.is_interface_compound())
    {
        if_compound_data_t logic_data;        
        nb_id_t id;        
        obj_impl_interface_compound::unpack(raw_data, id, logic_data);
        logic_data.name = name;
        obj_impl_interface_compound::pack(logic_data, id, raw_data);
    }
    else if(handle.is_access())
    {
        //duke_media_access(username, handle, raw_data, name);

        //write new name to access object
        access_data_t logic_data;        
        access_implementation::unpack(raw_data, logic_data);
        logic_data.name = name;
        access_implementation::pack(logic_data, raw_data);
    }
    else
    {
        LOG_ERROR("Unsupport handle for duke_media_save_result_by_handle: "<<handle.str());
    }

    //write content to db
    strval.clear();
    db_ret = ac_object_db_impl::instance().read_(handle.str(), strval);
    if(db_ret != NB_DB_RESULT_SUCCESS)
    {
        strval = pack_object(raw_data);    
        ac_object_db_impl::instance().write_(handle.str(), strval);
    }
    return true;
}

inline 
bool save_editing_handle(const duke_media_handle& h,
        const std::string& username)
{
    if (!h.is_object_user() && !h.is_interface_compound() && !h.is_object_decl_compound() &&
        !h.is_object_implement() && !h.is_object_container_des() && !h.is_access())
        return false;

    std::string dir;
    if (h.is_object_user())
        dir = "object";
    else if (h.is_interface_compound())
        dir = "compound-interface";
    else if (h.is_object_decl_compound())
        dir = "compound-declaration";
    else if (h.is_object_implement())
        dir = "implement";
    else if (h.is_object_container_des())
        dir = "container-def";
    else if (h.is_access())
        dir = "access";

    std::string strkey = username + "-tmp-" + dir;
    std::string strval;
    bool ret = duke_media_check_handle(strkey, h, strval);
    if (!ret)
    {
        strval += "(" + h.str() + ")";
        ret = duke_media_write_handle(strkey, strval);
        assert(ret);

        return true;
    }

    LOG_ERROR("save_editing_handle() : a same handle already exists!");
    return false;
}


inline 
bool save_generated_handle(const duke_media_handle& h,
        const std::string& username)
{
    if (!h.is_object_user() && !h.is_interface_compound() && !h.is_object_decl_compound() &&
        !h.is_object_implement() && !h.is_object_container_des() && !h.is_access())
        return false;

    std::string dir;
    if (h.is_object_user())
        dir = "object";
    else if (h.is_interface_compound())
        dir = "interface-compound";
    else if (h.is_object_decl_compound())
        dir = "declaration-compound";
    else if (h.is_object_implement())
        dir = "implement";
    else if (h.is_object_container_des())
        dir = "container-def";
    else if (h.is_access())
        dir = "access";

    std::string strkey = username + "-" + dir;
    std::string strval;
    bool ret = duke_media_check_handle(strkey, h, strval);
    if (!ret)
    {
        strval += "(" + h.str() + ")";
        ret = duke_media_write_handle(strkey, strval);
        assert(ret);

        return true;
    }

    LOG_ERROR("save_generated_handle() : a same handle already exists!");
    return false;
}

#endif /* __DUKE_MEDIA_GLOBAL_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
