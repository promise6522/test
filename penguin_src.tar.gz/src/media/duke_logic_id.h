#ifndef __DUKE_LOGIC_ID_H
#define __DUKE_LOGIC_ID_H

//C 98 header file
#include <string>
#include <fstream>

#include <limits.h>
/*
#include <boost/serialization/list.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/version.hpp>
#include <boost/serialization/split_member.hpp>
#include <boost/smart_ptr.hpp>
*/
//#include <boost/filesystem.hpp>

//duke header file

// C 89 header files
#include <assert.h>

// C 99 header files
#include <stdint.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <iomanip>
#include <sstream>
#include <vector>

// msgpack serialization lib
#include <msgpack.hpp>

#include "stdx_string.h"
#include "nb_id.h"
#include "duke_media_tempobj_db.h"
#include "duke_media_formobj_db.h"

#include "ac_global_db.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_bytes.h"

/*
#include "logic/duke_logic_object_data.h"


typedef dukeid_t        duke_media_nb_handle;
*/

enum duke_media_type {
    DUKE_MEDIA_TYPE_NULL                          = NBID_TYPE_NULL,
    DUKE_MEDIA_TYPE_OBJECT_NONE                   = NBID_TYPE_OBJECT_NONE,
    DUKE_MEDIA_TYPE_OBJECT_BOOL                   = NBID_TYPE_OBJECT_BOOL,
    DUKE_MEDIA_TYPE_OBJECT_INT                    = NBID_TYPE_OBJECT_INT,
    DUKE_MEDIA_TYPE_OBJECT_FLOAT                  = NBID_TYPE_OBJECT_FLOAT,
    DUKE_MEDIA_TYPE_OBJECT_STRING                 = NBID_TYPE_OBJECT_STRING,
    DUKE_MEDIA_TYPE_OBJECT_BYTES                  = NBID_TYPE_OBJECT_BYTES,
    DUKE_MEDIA_TYPE_OBJECT_INTERVAL               = NBID_TYPE_OBJECT_INTERVAL,
    DUKE_MEDIA_TYPE_OBJECT_TIME                   = NBID_TYPE_OBJECT_TIME,
    DUKE_MEDIA_TYPE_OBJECT_ARRAY                  = NBID_TYPE_OBJECT_ARRAY,
    DUKE_MEDIA_TYPE_OBJECT_MAP                    = NBID_TYPE_OBJECT_MAP,
    DUKE_MEDIA_TYPE_OBJECT_USER                   = NBID_TYPE_OBJECT_USER,
    DUKE_MEDIA_TYPE_OBJECT_BRIDGE                 = NBID_TYPE_OBJECT_BRIDGE,
    DUKE_MEDIA_TYPE_OBJECT_INTERFACE_EXPANDED     = NBID_TYPE_OBJECT_INTERFACE_EXPANDED, 
    DUKE_MEDIA_TYPE_OBJECT_DECLARATION_EXPANDED   = NBID_TYPE_OBJECT_DECLARATION_EXPANDED, 
//    DUKE_MEDIA_TYPE_INTERFACE_BUILTIN           = NBID_TYPE_INTERFACE_BUILTIN,
    DUKE_MEDIA_TYPE_INTERFACE_USER                = NBID_TYPE_OBJECT_INTERFACE,
    DUKE_MEDIA_TYPE_INTERFACE_COMPOUND            = NBID_TYPE_OBJECT_INTERFACE_COMPOUND,
    
    DUKE_MEDIA_TYPE_INTERFACE_BRIDGE              = NBID_TYPE_OBJECT_BRIDGE_INTERFACE,
    DUKE_MEDIA_TYPE_FUNCTION_INSTRUCTION          = NBID_TYPE_OBJECT_DECLARATION,
    DUKE_MEDIA_TYPE_FUNCTION_DECLARE              = NBID_TYPE_OBJECT_DECLARATION_COMPOUND,
    //DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_DECLARE     = NBID_TYPE_FUNCTION_BRIDGE_DECLARE,

    DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT   = NBID_TYPE_OBJECT_IMPLEMENTATION,

    // Compose/Decompose identifier
    DUKE_MEDIA_TYPE_FUNCTION_COMPOSE              = NBID_TYPE_FUNCTION_COMPOSE,
    DUKE_MEDIA_TYPE_FUNCTION_DECOMPOSE            = NBID_TYPE_FUNCTION_DECOMPOSE,
    DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_COMPOSE       = NBID_TYPE_FUNCTION_BRIDGE_COMPOSE,
    DUKE_MEDIA_TYPE_FUNCTION_BRIDGE_DECOMPOSE     = NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE,
    DUKE_MEDIA_TYPE_FUNCTION_GET_ANCHORS          = NBID_TYPE_FUNCTION_GET_ANCHORS,
    DUKE_MEDIA_TYPE_FUNCTION_GET_STORAGES         = NBID_TYPE_FUNCTION_GET_STORAGES,
    DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_SYNC   = NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC,
    DUKE_MEDIA_TYPE_FUNCTION_OUTGOING_SEND_ASYNC  = NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC,


    DUKE_MEDIA_TYPE_CONTAINER            = NBID_TYPE_CONTAINER,
    DUKE_MEDIA_TYPE_ACCESS               = NBID_TYPE_OBJECT_ACCESS,

    DUKE_MEDIA_TYPE_STORAGE              = NBID_TYPE_STORAGE_SINGLEVALUE,
    DUKE_MEDIA_TYPE_ANCHOR               = NBID_TYPE_ANCHOR,
    DUKE_MEDIA_TYPE_OBJECT_CONTAINER_DEF = NBID_TYPE_OBJECT_CONTAINER_DEF,
    DUKE_MEDIA_TYPE_OBJECT_DESCRIPTOR    = NBID_TYPE_OBJECT_DESCRIPTOR,
    DUKE_MEDIA_TYPE_ACCESS_ROOT,          //     = NBID_TYPE_OBJECT_ACCESS,
//    DUKE_MEDIA_TYPE_PACKAGE              = NBID_TYPE_PACKAGE,
//    DUKE_MEDIA_INTERFACE_NONE            = NB_INTERFACE_NONE
    DUKE_MEDIA_TYPE_FUNCTION_EXECUTE     = NBID_TYPE_FUNCTION_EXECUTE,//used to identify duke_media_execute        
};

//extern const duke_media_nb_handle duke_media_nb_handle_null;


struct media_id_32
{
    union {
        uint8_t  idu_id8[4];
        uint16_t idu_id16[2];
        uint32_t idu_id32[1];
    }id32;
#define media32_id32 id32.idu_id32
};

struct media_id_64
{
public:
    union {
        uint8_t  idu_id8[8];
        uint16_t idu_id16[4];
        uint32_t idu_id32[2];
        uint64_t idu_id64[1];
    }id64;
#define media64_id64 id64.idu_id64
#define media64_type id64.idu_id8[7]
};

struct media_id_128
{
public:
    union {
        uint8_t  idu_id8[16];
        uint16_t idu_id16[8];
        uint32_t idu_id32[4];
        uint64_t idu_id64[2];
    }id;

#define media128_id32 id.idu_id32
#define media128_id64 id.idu_id64
#define media128_type id.idu_id8[15]
};

struct media_id_256
{
    union {
        uint8_t  idu_id8[32];
        uint16_t idu_id16[16];
        uint32_t idu_id32[8];
        uint64_t idu_id64[4];
    }id256;

#define media256_id64 id256.idu_id64
#define media256_type id256.idu_id8[15]
};

typedef enum {
    e_handle_core,//the handle is in ac_object_db
    e_handle_temp,//the handle is in tempobj_db
    e_handle_unknown,
    e_handle_formal,//formobj_db is obsoleted, we maintain it just for backward-compability
} nb_handle_status;

struct nb_handle
{
public:
    typedef struct nb_handle __self_type;

    union
    { 
        media_id_32    idu_32;
        media_id_64    idu_64;
        media_id_128   idu_128;
        media_id_256   idu_256;       
    }id;
    enum id {Id32, Id64, Id128, Id256} idtype;

public:
    nb_handle()
    {
        initid_(0);
    }        

    nb_handle(uint8_t type) {
        initid_(0);
        set_type(type);
    }

    void set_idtype(enum id type)
    {
        assert(type >= 0 && type <= 3);
        if (type >= 0 && type <= 3)
            idtype = type;
    }

    void set_type(uint8_t type) {
        if ((static_cast<duke_media_type>(type) == DUKE_MEDIA_TYPE_ANCHOR) ||
             (static_cast<duke_media_type>(type) == DUKE_MEDIA_TYPE_STORAGE))
        {
            id.idu_64.media64_type = type;
            idtype = Id64;
        }
        else 
        {
            id.idu_128.media128_type = type;
            idtype = Id128;
        }
    }

    nb_handle(nb_builtin_instruction_t ins) {
        initid_(ins, 0);
        set_type(NBID_TYPE_OBJECT_DECLARATION);
    }

    nb_handle(nb_builtin_interface_t dif) {
        initid_(dif, 0);
        set_type(NBID_TYPE_OBJECT_INTERFACE);
    }
    
    nb_handle(nb_compound_interface_t dif) {
        initid_(dif, 0);
        set_type(NBID_TYPE_OBJECT_INTERFACE_COMPOUND);
    }

    duke_media_type get_type() const {
        if (idtype == Id64)
            return static_cast<duke_media_type>(id.idu_64.media64_type);
        else if (idtype == Id128)
            return static_cast<duke_media_type>(id.idu_128.media128_type);
        else if (idtype == Id256)
            return static_cast<duke_media_type>(id.idu_256.media256_type);
        else
            return DUKE_MEDIA_TYPE_NULL;
    }
  
    nb_builtin_instruction_t get_func_mask() const {
        return static_cast<nb_builtin_instruction_t>(id.idu_128.media128_id32[0] & ~0xFF);
    }

    nb_builtin_instruction_t get_func_type() const {
        return this->get_nb_type().get_func_type();
    }

    nb_compound_interface_t get_interface_compound_type() const {
        return this->get_nb_type().get_compound_interface_type(); 
    }

    nb_builtin_interface_t get_interface_type() const {
        return this->get_nb_type().get_interface_type();
    }

    nb_id_t get_nb_type() const {
        assert(this->idtype == 2);
        return nb_id_t(this->str());
    }
   
    anchor_id_t get_anchor_type() const 
    {
        assert(this->idtype == 1);
        return anchor_id_t(this->str());
    }
 
    storage_id_t get_storage_type() const 
    {
        assert(this->idtype == 1);
        return storage_id_t(this->str());
    }
   
    bool is_array_type() const {
       return (this->get_nb_type().get_compound_interface_type() == NB_INTERFACE_ARRAY_TYPE);
    } 

    bool is_map_type() const {
       return (this->get_nb_type().get_compound_interface_type() == NB_INTERFACE_MAP_TYPE);
    } 

    bool is_storage_type() const {
       return this->get_nb_type().is_interface_storage();
    }

    bool is_object() const {
        if (idtype == 2)
            return this->get_nb_type().is_object();
        else
            return false;
    }
   
    bool is_object_container_des() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_container_des();
        else
            return false;
    }

    bool is_object_des() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_des();
        else
            return false;
    }

    bool is_container() const {
        return this->get_type() == DUKE_MEDIA_TYPE_CONTAINER;
    }

    bool is_object_func() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_func();
        else
            return false;
    }

    bool is_object_exec_iterator() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_exec_iterator();
        else
            return false;
    }

    bool is_object_exec_condition() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_exec_condition();
        else
            return false;
    }

    bool is_object_exec_anchor_func() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_exec_anchor_func();
        else
            return false;
    }

    bool is_object_exec_storage_func() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_exec_storage_func();
        else
            return false;
    }

    bool is_access() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_access();
        else 
            return false;
    }

    bool is_anchor() const {
        if (idtype == 1)
            return this->get_anchor_type().get_type() == NBID_TYPE_ANCHOR;
        else
            return false;
    }

    bool is_storage() const {
        if (idtype == 1)
        {
            nbid_type_t type = this->get_storage_type().get_type();
            return type == NBID_TYPE_STORAGE_SINGLEVALUE;
        }
        else
            return false;
    }

    bool is_type_null() const
    {
        return (this->get_type() == DUKE_MEDIA_TYPE_NULL);
    }
    
    bool is_object_none() const {
        return (this->get_type() == DUKE_MEDIA_TYPE_OBJECT_NONE);
    }
    
    bool is_object_bool() const {
        return (this->get_type() == DUKE_MEDIA_TYPE_OBJECT_BOOL);
    }
    
    bool is_object_int() const {
        return (this->get_type() == DUKE_MEDIA_TYPE_OBJECT_INT);
    }

    bool is_object_float() const {
        return (this->get_type() == DUKE_MEDIA_TYPE_OBJECT_FLOAT);
    }

    bool is_object_string() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_STRING;
    }

    bool is_object_bytes() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_BYTES;
    }

    bool is_object_interval() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_INTERVAL;
    }

    bool is_object_time() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_TIME;
    }

    bool is_object_array() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_ARRAY;
    }

    bool is_object_map() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_MAP;
    }

    bool is_object_user() const {
        return (this->get_type() == DUKE_MEDIA_TYPE_OBJECT_USER);
    }

    bool is_object_bridge() const {
        return this->get_type() == DUKE_MEDIA_TYPE_OBJECT_BRIDGE;
    }

    bool is_object_builtin() const {
        if (this->idtype == 2)
            return this->get_nb_type().is_builtin_object();
        return false;
    }

    bool is_object_wrapper() const {
        return true;
    }

    bool is_bridge_interface() const {
        return this->get_type() == DUKE_MEDIA_TYPE_INTERFACE_BRIDGE;
    }

    bool is_interface_compound() const {
        return this->get_type() == DUKE_MEDIA_TYPE_INTERFACE_COMPOUND; 
    }

    bool is_user_interface() const {
        if (idtype == 2)
            return this->get_nb_type().is_interface_user();
        else
            return false;
    }
    
    bool is_object_interface() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_interface();
        else
            return false;
    }

    bool is_object_compound_interface() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_interface_compound();
        else
            return false;
    }

/*
    bool is_array_interface() const {
        return this->get_nb_type().is_interface_user();
    }
  
    bool is_array_type_interface() const {
        return this->get_nb_type().is_interface_array_type();
    }

    bool is_map_type_interface() const {
        return this->get_nb_type().is_interface_map_type();
    }
*/

    bool is_access_interface() const {
        return this->get_nb_type().is_interface_access();
    }

    bool is_interface() const {
        if (idtype == 2)
            return this->get_nb_type().is_interface();
        else
            return false;
    }

    bool is_interface_bool() const {
        return this->get_nb_type().is_interface_bool();
    }

    bool is_interface_time_line() const {
        return this->get_nb_type().is_interface_time_line();
    }

    bool is_wrapper() const {
        return true;
    }

    bool is_function_instruction() const {
        return this->get_type() == DUKE_MEDIA_TYPE_FUNCTION_INSTRUCTION;
    }

    bool is_function_declare() const {
        return this->get_type() == DUKE_MEDIA_TYPE_FUNCTION_DECLARE;
    }

    bool is_function_implement() const {
        return this->get_type() == DUKE_MEDIA_TYPE_FUNCTION_IMPLEMENT ||
            this->is_object_exec_iterator() ||
            this->is_object_exec_condition();
    }

    bool is_object_declaration() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_declaration();
        else 
            return false;
    }

    bool is_object_decl_expanded() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_decl_expanded();
        else 
            return false;
    }

    bool is_object_decl_compound() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_decl_compound();
        else
            return false;
    }

    bool is_object_implement() const {
        return this->is_function_implement();
    }

    bool is_execute() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_exec_obj_func();
        else
            return false;
    }
    
    bool is_exception() const {
        if (idtype == 2)
            return this->get_nb_type().is_exception();
        else
            return false;
    }

    bool is_implementation() const {
        if (idtype == 2)
            return this->is_function_implement();
        else
            return false;
    }

    bool is_function_compose() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_compose();
        else
            return false;
    }

    bool is_function_decompose() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_decompose();
        else
            return false;
    }

    bool is_function_get_anchors() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_get_anchors();
        else
            return false;
    }

    bool is_function_get_storages() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_get_storages();
        else
            return false;
    }

     bool is_function_outgoing_async() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_outgoing_async();
        else
            return false;
    }

     bool is_function_outgoing_sync() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_outgoing_sync();
        else
            return false;
    }

    bool is_function_bridge_compose() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_bridge_compose();
        else
            return false;
    }

    bool is_function_bridge_decompose() const {
        if (idtype == 2)
            return this->get_nb_type().is_function_bridge_decompose();
        else
            return false;
    }

    bool is_general_identity() const {
        if (idtype == 2)
            return this->get_nb_type().is_general_identity();
        else 
            return false;
    }
    bool is_general_return() const {
        if (idtype == 2)
            return this->get_nb_type().is_general_return();
        else 
            return false;
    }

    ///////////////////
    int get_instruction_number() const {
        if (idtype != 2)
            return false;
        return this->get_nb_type().get_instruction_number();
    }

    bool is_instruction_general() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_general();
    }

    bool is_instruction_bool() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_bool();
    }

    bool is_instruction_int() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_int();
    }

    bool is_instruction_float() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_float();
    }

    bool is_instruction_string() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_string();
    }

    bool is_instruction_bytes() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_bytes();
    }

    bool is_instruction_interval() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_interval();
    }

    bool is_instruction_time() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_time();
    }

    bool is_instruction_array() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_array();
    }

    bool is_instruction_map() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_map();
    }

    bool is_instruction_user() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_user();
    }

    bool is_instruction_storage() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_storage();
    }

    bool is_instruction_root_access() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_root_access();
    }

    bool is_instruction_container_def() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_container_def();
    }

    bool is_instruction_bridge() const {
        if (idtype != 2) 
            return false;
        return this->get_nb_type().is_instruction_bridge();
    }

    bool is_instruction_interface() const {
        if (idtype == 2)
            return get_nb_type().is_instruction_interface();
        else
            return false;
    }

    bool is_instruction_interface_compound() const {
        if (idtype == 2)
            return get_nb_type().is_instruction_interface_compound();
        else
            return false;
    }
 
    bool is_instruction_declaration() const {
        if (idtype == 2)
            return get_nb_type().is_instruction_declaration();
        else
            return false;
    }

    bool is_instruction_declaration_compound() const {
        if (idtype == 2)
            return get_nb_type().is_instruction_declaration_compound();
        else
            return false;
    }
    
    bool is_instruction_implementation() const {
        if (idtype == 2)
            return get_nb_type().is_instruction_implementation();
        else
            return false;
    }
    
    bool is_function_storage_compound_declare() const {
        nb_builtin_instruction_t type = get_func_type();
        return (type>NB_FUNC_STORAGE_INSTRUCTION)&&
                (type<=NB_FUNC_STORAGE_INSTRUCTION_END);
    }

    bool is_declaration() const {
        if (idtype == 2)
            return is_function_instruction()
                || is_object_decl_compound()
                || is_object_decl_expanded()
                || is_function_declare()
                || is_function_compose()
                || is_function_decompose()
                || is_function_get_anchors()
                || is_function_get_storages()
                || is_function_bridge_compose()     //add on 09/01 by tom
                || is_function_bridge_decompose()   //add on 09/01 by tom
                || is_function_outgoing_sync()      //add on 09/30 by ning
                || is_function_outgoing_async();    //add on 09/30 by ning
        else
            return false;
    }

    bool is_declaration_compound() const {
        if (idtype == 2)
            return this->get_nb_type().is_object_decl_compound();
        else
            return false;
    }

    bool is_builtin_interface() const {
        if (idtype ==2)
            return this->get_nb_type().is_builtin_interface();
        else
            return false;
    }

    bool is_interface_array() const {
        return this->get_nb_type().is_interface_array();
    }

    bool is_interface_root_access() const
    {
        return this->get_nb_type().is_interface_root_access();
    }

    bool is_interface_none() const {
        return this->get_nb_type().is_interface_none();
    }

    bool is_interface_int() const {
        return this->get_nb_type().is_interface_int();
    }

    bool is_interface_float() const {
        return this->get_nb_type().is_interface_float();
    }

    bool is_interface_string() const {
        return this->get_nb_type().is_interface_string();
    }

    bool is_interface_bytes() const {
        return this->get_nb_type().is_interface_bytes();
    }

    bool is_interface_interval() const {
        return this->get_nb_type().is_interface_interval();
    }

    bool is_interface_time() const {
        return this->get_nb_type().is_interface_time();
    }

    bool is_interface_map() const {
        return this->get_nb_type().is_interface_map();
    }

    bool is_interface_storage() const {
        return this->get_nb_type().is_interface_storage();
    }

    bool is_persistent_type() const;

    bool set_value(int value) {
        id.idu_128.media128_id32[0] = value;
        return true;
    }

    bool get_value(int& value) const {
        value = id.idu_128.media128_id32[0];
        return true;
    }

    bool set_value(bool value) {
        id.idu_128.media128_id32[0] = static_cast<int>(value);
        return true;
    }

    bool get_value(bool& value) const {
        value = static_cast<bool>(id.idu_128.media128_id32[0]);
        return true;
    }

    bool set_value(float value) {
        assert(sizeof(value) == sizeof(id.idu_128.media128_id32[0]));
        memcpy(&id.idu_128.media128_id32[0], &value, sizeof(value));
        return true;
    }

    bool get_value(float& value) const {
        assert(sizeof(value) == sizeof(id.idu_128.media128_id32[0]));
        memcpy(&value, &id.idu_128.media128_id32[0], sizeof(value));
        return true;
    }

    bool set_value(uint64_t low, uint64_t high = 0) {
        uint64_t mask = NB_ID_MASK;
        mask <<= 32;
        id.idu_128.media128_id64[1] &= mask;
        id.idu_128.media128_id64[1] |= high & ~mask;
        id.idu_128.media128_id64[0] = low;
        return true;
    }

    bool get_value(uint64_t& low, uint64_t& high) const {
        uint64_t mask = NB_ID_MASK;
        mask <<= 32;
        high = id.idu_128.media128_id64[1] & ~mask;
        low  = id.idu_128.media128_id64[0];
        return true;
    }

    bool set_value(const std::string& strval, DbTxn* txn = NULL);

    nb_handle_status get_value(std::string& strval) const;

    nb_handle(const nb_id_t& v1)
    {
        memcpy(this, &v1, sizeof(v1));
        idtype = Id128;
    }

    nb_handle(const container_id_t& v1)
    {
        memcpy(this, &v1, sizeof(v1));
        idtype = Id256;
    }

    nb_handle(const anchor_id_t& v1)
    {
        memset(this, 0, sizeof(*this));
        memcpy(this, &v1, sizeof(v1));
        idtype = Id64;
    }

    nb_handle(const storage_id_t& v1)
    {
        memcpy(this, &v1, sizeof(v1));
        idtype = Id64;
    }

    nb_handle(const nb_handle& v1)
    {
        memcpy(this, &v1, sizeof(v1));
    }

    nb_handle(const std::string& strid)
    {
	    this->str(strid);
    }

    nb_handle& operator=(const nb_handle& v1)
    {
        if (this == &v1)
            return *this;

        memcpy(this, &v1, sizeof(v1));
        return *this;
    }

    nb_handle& operator=(const nb_id_t& v1)
    {
        memcpy(this, &v1, sizeof(v1));
        idtype = Id128;
        return *this;
    }

    nb_handle& operator=(const nb_builtin_interface_t dif)
    {
        initid_(dif, 0);
        set_type(NBID_TYPE_OBJECT_INTERFACE);
        return *this;
    }

    std::string
    str() const
    {  
        std::ostringstream oss;
        //std::cout << "str() idtype:" << idtype << std::endl;
        if (idtype == Id32)
        {
            oss << std::setw(8) << std::setfill('0') << std::hex << this->id.idu_32.media32_id32[0];
        }
        else if (idtype == Id64)
        {
            oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_64.media64_id64[0];
        }
        else if (idtype == Id128)
        {
            // for performance, not to use the stringstream
            char buf[32+1];
            stdx::ulong_to_hex(this->id.idu_128.media128_id64[1], buf);
            stdx::ulong_to_hex(this->id.idu_128.media128_id64[0], buf+16);
            return std::string(buf);
            //oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_128.media128_id64[1];
            //oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_128.media128_id64[0];
        }
        else if (idtype == Id256)
        {
            oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_256.media256_id64[3];
            oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_256.media256_id64[2];
            oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_256.media256_id64[1];
            oss << std::setw(16) << std::setfill('0') << std::hex << this->id.idu_256.media256_id64[0];
        }

        return oss.str();
    }

    void
    str(const std::string& strid)
    {
        if (strid.size() == 8)
        {
            std::istringstream iss(strid.substr(0, 8));
            iss >> std::hex >> this->id.idu_32.media32_id32[0];
            idtype = Id32;
        }
        else if (strid.size() == 16)
        {
            std::istringstream iss(strid.substr(0, 16));
            iss >> std::hex >> this->id.idu_64.media64_id64[0];
            idtype = Id64;
        }
        else if (strid.size() == 32)
        {
            // for performance, not to use the stringstream
            const char* buf = strid.c_str();
            this->id.idu_128.media128_id64[1] = stdx::hex_to_ulong(buf);
            this->id.idu_128.media128_id64[0] = stdx::hex_to_ulong(buf+16);
            //std::istringstream iss(strid.substr(0, 16) + " " + strid.substr(16, 16));
            //iss >> std::hex >> this->id.idu_128.media128_id64[1] >> this->id.idu_128.media128_id64[0];
            idtype = Id128;
        }
        else if (strid.size() == 64)
        {
            assert(strid.size() == 64);
            std::istringstream iss(strid.substr(0, 16) + " " + strid.substr(16, 16) + " " + strid.substr(32, 16) + " " + strid.substr(48, 16));
            iss >> std::hex >> this->id.idu_256.media256_id64[3] >> this->id.idu_256.media256_id64[2] >> this->id.idu_256.media256_id64[1] >> this->id.idu_256.media256_id64[0];
            idtype = Id256; 
        }
        else
        {
            initid_(0);
        }
    }

    friend bool operator<(const nb_handle& v1, const nb_handle& v2);
    friend bool operator==(const nb_handle& v1, const nb_handle& v2);
    friend bool operator!=(const nb_handle& v1, const nb_handle& v2);
    friend bool operator>(const nb_handle& v1, const nb_handle& v2);
    friend bool operator>=(const nb_handle& v1, const nb_handle& v2);
    friend bool operator<=(const nb_handle& v1, const nb_handle& v2);

    /*
    friend class boost::serialization::access;
    template<class Archive>
    void save(Archive & ar, const unsigned int version) const
    {
        std::string strval = str();        
        std::cout<<"Saving duke_media_handle "<<strval<<std::endl;
        ar & strval;
        ar & idtype;
    }
    template<class Archive>
    void load(Archive & ar, const unsigned int version)
    {
        std::string strval;        
        ar & strval;
        std::cout<<"Loading duke_media_handle "<<strval<<std::endl;
        str(strval);        
        ar & idtype;
    }
    BOOST_SERIALIZATION_SPLIT_MEMBER()
    */

public:
    // MSGPACK SERIALIZATION
    // callback for msgpack::pack(...)
    template<typename Packer>
    void msgpack_pack(Packer& pk) const
    {
        pk.pack(this->str());
    }

    void msgpack_unpack(msgpack::object o)
    {
        std::string strval;
        o.convert(&strval);

        this->str(strval);
    }


private:
    void initid_(int i)
    {
        memset(this, 0, sizeof(*this));
        idtype = Id128;
    }

    void initid_(uint64_t low = 0, uint64_t high = 0)
    {
        id.idu_128.media128_id64[0] = low;
        id.idu_128.media128_id64[1] = high;
    }
};

inline bool operator<(const nb_handle& v1, const nb_handle& v2)
{
    if(v1.idtype!=v2.idtype)
    {
        return v1.idtype<v2.idtype;
    }
    assert(v1.idtype==v2.idtype);
    if(v1.idtype==nb_handle::Id32)
    {
        return v1.id.idu_32.media32_id32[0]<v2.id.idu_32.media32_id32[0];
    }
    else if(v1.idtype==nb_handle::Id64)
    {
        return v1.id.idu_64.media64_id64[0]<v2.id.idu_64.media64_id64[0];
    }
    else if(v1.idtype==nb_handle::Id128)
    {
        return (v1.id.idu_128.media128_id64[1]<v2.id.idu_128.media128_id64[1])||
                (v1.id.idu_128.media128_id64[1]==v2.id.idu_128.media128_id64[1]&&v1.id.idu_128.media128_id64[0]<v2.id.idu_128.media128_id64[0]);
    }
    else if(v1.idtype==nb_handle::Id256)
    {
        return (v1.id.idu_256.media256_id64[3]<v2.id.idu_256.media256_id64[3])||
        (v1.id.idu_256.media256_id64[3]==v2.id.idu_256.media256_id64[3]&&v1.id.idu_256.media256_id64[2]<v2.id.idu_256.media256_id64[2])||
        (v1.id.idu_256.media256_id64[3]==v2.id.idu_256.media256_id64[3]&&v1.id.idu_256.media256_id64[2]==v2.id.idu_256.media256_id64[2]&&v1.id.idu_256.media256_id64[1]<v2.id.idu_256.media256_id64[1])||
        (v1.id.idu_256.media256_id64[3]==v2.id.idu_256.media256_id64[3]&&v1.id.idu_256.media256_id64[2]==v2.id.idu_256.media256_id64[2]&&v1.id.idu_256.media256_id64[1]==v2.id.idu_256.media256_id64[1]&&v1.id.idu_256.media256_id64[0]<v2.id.idu_256.media256_id64[0]);
    }
    return false;
}

inline bool operator==(const nb_handle& v1, const nb_handle& v2)
{
    if(v1.idtype!=v2.idtype)
    {
        return false;
    }
    if(v1.idtype==nb_handle::Id32)
    {
        return v1.id.idu_32.media32_id32[0]==v2.id.idu_32.media32_id32[0];
    }
    else if(v1.idtype==nb_handle::Id64)
    {
        return v1.id.idu_64.media64_id64[0]==v2.id.idu_64.media64_id64[0];
    }
    else if(v1.idtype==nb_handle::Id128)
    {
        return (v1.id.idu_128.media128_id64[1]==v2.id.idu_128.media128_id64[1])&&
        (v1.id.idu_128.media128_id64[0]==v2.id.idu_128.media128_id64[0]);
    }
    else if(v1.idtype==nb_handle::Id256)
    {
        return (v1.id.idu_256.media256_id64[3]==v2.id.idu_256.media256_id64[3])&&
        (v1.id.idu_256.media256_id64[2]==v2.id.idu_256.media256_id64[2])&&
        (v1.id.idu_256.media256_id64[1]==v2.id.idu_256.media256_id64[1])&&
        (v1.id.idu_256.media256_id64[0]==v2.id.idu_256.media256_id64[0]);
    }
    return false;
}

inline bool operator!=(const nb_handle& v1, const nb_handle& v2)
{
    return !(v1==v2);
}

inline bool operator>(const nb_handle& v1, const nb_handle& v2)
{
    return !(v1<v2||v1==v2);
}

inline bool operator>=(const nb_handle& v1, const nb_handle& v2)
{
    return (v1>v2||v1==v2);
}

inline bool operator<=(const nb_handle& v1, const nb_handle& v2)
{
    return (v1<v2||v1==v2);
}

typedef nb_handle dukeid_t;
typedef nb_handle duke_media_handle;
const duke_media_handle duke_media_handle_null;


nb_handle_status get_media_handle_status(const nb_handle& h);

#endif /* __DUKE_LOGIC_ID_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
