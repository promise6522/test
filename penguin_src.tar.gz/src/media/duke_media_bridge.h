/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**
**************************************************************************/

#ifndef __DUKE_MEDIA_BRIDGE_H
#define __DUKE_MEDIA_BRIDGE_H

#include <iostream>
#include <string.h>
#include <map>

#include "duke_logic_object_data.h"
#include "duke_media_base.h"
#include "duke_media_bridge_interface.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_global_db.h"

// duke_media_bridge simple reads data from core
// and do some query job.It should never write to db
class duke_media_bridge : public duke_media_base
{
protected:
    duke_bridge_object_data m_data;


public:
    duke_media_bridge()
    {
    }

    // #MIND# (tom)
    // We never need to create a new empty bridge object in media
    //
    // duke_media_bridge(const host_committer_id_t& host_id, 
    //         const std::string& username = "anonymous-name") 
    //         : duke_media_base(DUKE_MEDIA_TYPE_OBJECT_BRIDGE, host_id)
    // {
    // }


    duke_media_bridge(const duke_media_handle& hbridge)
    {
        assert(hbridge.is_object_bridge());

        //only read bridge object from ac_object_db
        std::string strval;
        NbDbResult ret = ac_object_db_impl::instance().read(hbridge.str(), strval, 0);
        if (NB_DB_RESULT_SUCCESS != ret)
        {
            LOG_ERROR("duke_media_bridge : read bridge from core failed.");
            return;
        }

        this->unpack(strval);

        this->set_handle(hbridge);

        //forbids write
        this->set_handle_status(e_handle_core);
    }

    bool get_name(std::string& name) const
    {
        name = m_data.m_name;
        return true;
    }

    bool get_interface(duke_media_handle& hif) const
    {
        hif = m_data.m_interface;
        return true;
    }

    bool get_descriptor(duke_media_handle& hdes) const
    {
        hdes = m_data.m_descriptor;
        return true;
    }

    bool get_declarations(duke_media_handle_vector& hdecls) const
    {
        duke_media_bridge_interface m_mif(m_data.m_interface);
        return m_mif.get_declarations(hdecls);
    }

    void unpack(const std::string& strbridge)
    {
        //strbridge comes only from core
        //use the unpack() from core
        content con;
        unpack_object(strbridge, con);

        bridge_data_t data_t;
        nb_id_t obj_id;
        obj_impl_bridge::unpack(con, obj_id, data_t);

        m_data = duke_bridge_object_data(data_t);
    }

    std::string pack() const
    {
        return this->m_data.pack();
    }

};

#endif /* __DUKE_MEDIA_BRIDGE_H */

// vim:set tabstop=4 shiftwidth=4 expandtab:
