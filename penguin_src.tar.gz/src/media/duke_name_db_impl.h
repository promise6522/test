/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/


#ifndef __DUKE_NAME_DB_IMPL_H
#define __DUKE_NAME_DB_IMPL_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

//#include "nb_id.h"
#include "ac_tool/ac_nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"
#include "stdx_log.h"

class duke_name_db_impl : public boost_singleton<duke_name_db_impl>
{
public:
    bool write(const std::string& strkey, const std::string& value);
    bool read(const std::string& strkey, std::string& value);
    bool commit(int flag);
    bool rollback(int flag);

private:    
    duke_name_db_impl();

public:
    virtual ~duke_name_db_impl(void); 
    friend struct boost_singleton<duke_name_db_impl>;

private:
    nbnv* penv;
    nbdb* pdb;
};

#endif // __DUKE_NAME_DB_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
