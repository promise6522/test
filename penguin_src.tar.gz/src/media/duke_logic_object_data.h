#ifndef __DUKE_LOGIC_OBJECT_DATA_H
#define __DUKE_LOGIC_OBJECT_DATA_H

#include <vector>
#include <string>

#include <msgpack.hpp>
//#include <stdint.h>

#include "nb_profiler.h"
#include "duke_logic_id.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"

typedef std::vector<dukeid_t>   dukeid_vector;
typedef dukeid_vector::iterator   dukeid_vector_iterator;
typedef dukeid_vector::const_iterator   dukeid_vector_const_iterator;

typedef std::vector<unsigned int>   fileid_vector;
typedef fileid_vector::iterator   fileid_vector_iterator;
typedef fileid_vector::const_iterator   fileid_vector_const_iterator;

typedef std::vector<std::string>   dukestr_vector;
typedef dukestr_vector::iterator   dukestr_vector_iterator;
typedef dukestr_vector::const_iterator   dukestr_vector_const_iterator;

typedef std::map<dukeid_t, dukeid_t> dukeid_map;
typedef dukeid_map::iterator dukeid_map_iterator;
typedef dukeid_map::const_iterator dukeid_map_const_iterator;

typedef std::map<dukeid_t, std::string> strid_map;
typedef strid_map::iterator strid_map_iterator;
typedef strid_map::const_iterator strid_map_const_iterator;

typedef std::multimap<dukeid_t, dukeid_t> dukeid_multimap;
typedef dukeid_multimap::iterator dukeid_multimap_iterator;
typedef dukeid_multimap::const_iterator dukeid_multimap_const_iterator;

typedef std::vector<std::pair<dukeid_t, dukeid_t> > dukeid_pair_vector;
typedef dukeid_pair_vector::iterator    dukeid_pair_vector_iterator;
typedef dukeid_pair_vector::const_iterator    dukeid_pair_vector_const_iterator;

typedef std::vector<std::pair<dukeid_t, std::string> > dukeidstr_pair_vector;
typedef dukeidstr_pair_vector::iterator    dukeidstr_pair_vector_iterator;
typedef dukeidstr_pair_vector::const_iterator    dukeidstr_pair_vector_const_iterator;

typedef std::vector<std::pair<std::string, std::string> > str_pair_vector;
typedef str_pair_vector::iterator    str_pair_vector_iterator;
typedef str_pair_vector::const_iterator    str_pair_vector_const_iterator;

const static int ID_LENGTH = 32;
const static uint INT64_LENGTH = 16;
const static uint INT32_LENGTH = 8;

/******************************************************************************/
// two templates func to use lib:msgpack to pack/unpack

template<typename TYPE_TO_PACK>
inline std::string serialize_by_msgpack(const TYPE_TO_PACK& obj)
{
    msgpack::sbuffer sbuf;
    msgpack::pack(&sbuf, obj);

    return std::string(sbuf.data(), sbuf.size());
}

template<typename TYPE_TO_UNPACK>
inline bool deserialize_by_msgpack(const std::string& val, TYPE_TO_UNPACK& obj)
{
    msgpack::unpacked result;
    msgpack::unpack(&result, val.data(), val.size(), NULL);
    try {
        result.get().convert(&obj);
    }
    catch(msgpack::type_error& e) {
        assert(false);
        LOG_ERROR(e.what());
        return false;
    }

    return true;
}


inline std::string int64_2_str(const int64_t& id64)
{
    std::ostringstream oss;
    oss << std::setw(INT64_LENGTH) << std::setfill('0') << std::hex << id64;
    assert(oss.str().size() == INT64_LENGTH);
    return oss.str();
}

inline int64_t str_2_id64(const std::string& strid)
{
    assert(strid.size() == INT64_LENGTH);
    int64_t id64;
    std::istringstream iss(strid.substr(0, INT64_LENGTH));
    iss >> std::hex >> id64;
    return id64;
}

inline std::string int32_2_str(const int32_t& id32)
{
    std::ostringstream oss;
    oss << std::setw(INT32_LENGTH) << std::setfill('0') << std::hex << id32;
    assert(oss.str().size() == INT32_LENGTH);
    return oss.str();
}

inline int64_t str_2_id32(const std::string& strid)
{
    assert(strid.size() == INT32_LENGTH);
    int32_t id32;
    std::istringstream iss(strid.substr(0, INT32_LENGTH));
    iss >> std::hex >> id32;
    return id32;
}


inline std::string pack_int32t_map(const std::map<int32_t, int32_t>& hmap)
{
    std::string strhmap;
    for (std::map<int32_t, int32_t>::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + int32_2_str(it->first) + ")";
        strhmap += "(" + int32_2_str(it->second) + ")";
    }
    return strhmap;
}

inline void unpack_int32t_map(const std::string& strhmap, std::map<int32_t, int32_t>& hmap)
{
    std::string::size_type pos(0);
    hmap.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        int32_t hfirst = str_2_id32(strfirst);
        int32_t hsecond = str_2_id32(strsecond);
        hmap.insert(std::make_pair(hfirst, hsecond));
    }
}

/******************************************************************************/
// bytes type

struct duke_bytes_t
{
    int         m_crc;
    int         m_length;
    std::string m_value;

    MSGPACK_DEFINE(m_crc, m_length, m_value);
};

inline void unpack_bytes(const std::string strval, duke_bytes_t& value)
{
    deserialize_by_msgpack(strval, value);
}

inline std::string pack_bytes(const duke_bytes_t& value)
{
    return serialize_by_msgpack(value);
}
/*
// access_root type
inline void unpack_access_root(const std::string strval, dukeid_t& value)
{
    dukeid_t id(strval);
    value = id;
}

inline std::string pack_access_root(const dukeid_t& value)
{
    std::string strval;
    strval.assign(value.str());
    return strval;
}
*/
struct duke_time_t
{
    uint64_t  pico_second_cnt;
    uint64_t  second_cnt;

    //MSGPACK_DEFINE(pico_second_cnt, second_cnt);
};

// time
inline void pack_time(const duke_time_t& dtime, uint64_t& low, uint64_t& high)
{
    uint64_t mask = 0xFF000000;
    mask = mask << 32;
    low = dtime.second_cnt;
    high &= mask;
    high |= dtime.pico_second_cnt;
}

inline void unpack_time(uint64_t low, uint64_t high, duke_time_t& dtime)
{
    uint64_t mask = 0x00FFFFFF;
    mask = (mask << 32) | 0xFFFFFFFF;
    dtime.second_cnt = low;
    dtime.pico_second_cnt = high & mask;
}

/******************************************************************************/
/*
// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline std::string pack_int_vector(const std::vector<int>& vh)
{
    std::string strhandles;
    for (std::vector<int>::const_iterator it = vh.begin(); it != vh.end(); ++it)
    {
        strhandles += "(" + to_string(*it) + ")";
    }
    return strhandles;
}

// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline void unpack_int_vector(const std::string& strvec,
        std::vector<int>& vi)
{
    std::string::size_type pos(0);
    std::string stri;
    // after calling find_between(), stri will be node0 or DUKEID
    while ((pos = find_between(strvec, stri, "(", ")", pos))
            != std::string::npos)
    {
        int i = from_string<int>(stri);
        vi.push_back(i);
    }
}
*/

// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline std::string pack_dukeid_vector(const dukeid_vector& vh)
{
    std::string strhandles;
    for (dukeid_vector::const_iterator it = vh.begin(); it != vh.end(); ++it)
    {
        strhandles += "(" + it->str() + ")";
    }
    return strhandles;
}

// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline void unpack_dukeid_vector(const std::string& strhandles,
        dukeid_vector& vid)
{
    vid.clear();
    std::string::size_type pos(0);
    std::string strh;
    // after calling find_between(), strh will be node0 or DUKEID
    while ((pos = find_between(strhandles, strh, "(", ")", pos))
            != std::string::npos)
    {
        if (!strh.empty())
        {
            dukeid_t h(strh);
            vid.push_back(h);
        }
    }
}

// (first)(second)...(first)(second)
inline std::string pack_strid_map(const strid_map& hmap)
{
    std::string strhmap;
    for (strid_map::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + it->first.str() + ")";
        strhmap += "=" + it->second + "=";
    }
    return strhmap;
}

// (first)(second)...(first)(second)
inline void unpack_strid_map(const std::string& strhmap, strid_map& hmap)
{
    std::string::size_type pos(0);
    hmap.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strval;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strval, "=", "=", pos);
        assert(pos != std::string::npos);

        dukeid_t hfirst(strfirst);
        hmap.insert(std::make_pair(hfirst, strval));
    }
}

inline std::string pack_fileid_vector(const fileid_vector& vh)
{
    std::string strhandles;
    for (fileid_vector::const_iterator it = vh.begin(); it != vh.end(); ++it)
    {
        strhandles += "(" + to_string(*it) + ")";
    }
    return strhandles;
}

inline void unpack_fileid_vector(const std::string& strhandles, fileid_vector& vid)
{
    vid.clear();
    std::string::size_type pos(0);
    std::string strh;
    while ((pos = find_between(strhandles, strh, "(", ")", pos)) != std::string::npos)
    {
        unsigned int fileid = from_string<unsigned int>(strh);
        vid.push_back(fileid);
    }
}

inline std::string pack_string_vector(const std::vector<std::string>& vs)
{
    std::string strhandles;
    for (std::vector<std::string>::const_iterator it = vs.begin(); it != vs.end(); ++it)
    {
        strhandles += "(" + (*it) + ")";
    }
    return strhandles;
}

inline void unpack_string_vector(const std::string& strhandles,
        std::vector<std::string>& vid)
{
    vid.clear();
    std::string::size_type pos(0);
    std::string strh;
    // after calling find_between(), strh will be node0 or DUKEID
    while ((pos = find_between(strhandles, strh, "(", ")", pos))
            != std::string::npos)
    {
        vid.push_back(strh);
    }
}

// (first)(second)...(first)(second)
inline std::string pack_str_pair_vector(const str_pair_vector& vpair)
{
    std::string strval;
    for (str_pair_vector::const_iterator it = vpair.begin(); it != vpair.end(); ++it)
    {
        strval += "(" + it->first + ")";
        strval += "(" + it->second + ")";
    }
    return strval;
}

// (first)(second)...(first)(second)
inline void unpack_str_pair_vector(const std::string& strval,
        str_pair_vector& vpair)
{
    std::string::size_type pos(0);
    vpair.clear();
    while (true && strval.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strval, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strval, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        vpair.push_back(std::make_pair(strfirst, strsecond));
    }
}

// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline std::string pack_duke_media_handle_vector(const dukeid_vector& vh)
{
    return pack_dukeid_vector(vh);
}

// strhandles will be (DUKEID)(node0)(node1)...(DUKEID)
inline void unpack_duke_media_handle_vector(const std::string& strhandles,
        dukeid_vector& vid)
{
    return unpack_dukeid_vector(strhandles, vid);
}

// (first)(second)...(first)(second)
inline std::string pack_dukeid_multimap(const dukeid_multimap& hmap)
{
    std::string strhmap;
    for (dukeid_multimap::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + it->first.str() + ")";
        strhmap += "(" + it->second.str() + ")";
    }
    return strhmap;
}

// (first)(second)...(first)(second)
inline void unpack_dukeid_multimap(const std::string& strhmap, dukeid_multimap& hmap)
{
    std::string::size_type pos(0);
    hmap.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        dukeid_t hfirst(strfirst);
        dukeid_t hsecond(strsecond);
        hmap.insert(std::make_pair(hfirst, hsecond));
    }
}

// (first)(second)...(first)(second)
inline std::string pack_dukeid_map(const dukeid_map& hmap)
{
    std::string strhmap;
    for (dukeid_map::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + it->first.str() + ")";
        strhmap += "(" + it->second.str() + ")";
    }
    return strhmap;
}

// (first)(second)...(first)(second)
inline void unpack_dukeid_map(const std::string& strhmap, dukeid_map& hmap)
{
    std::string::size_type pos(0);
    hmap.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        dukeid_t hfirst(strfirst);
        dukeid_t hsecond(strsecond);
        hmap.insert(std::make_pair(hfirst, hsecond));
    }
}

// (first)(second)...(first)(second)
inline std::string pack_dukeid_pair_vector(const dukeid_pair_vector& hmap)
{
    std::string strhmap;
    for (dukeid_pair_vector::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + it->first.str() + ")";
        strhmap += "(" + it->second.str() + ")";
    }
    return strhmap;
}

// (first)(second)...(first)(second)
inline void unpack_dukeid_pair_vector(const std::string& strhmap,
        dukeid_pair_vector& vpair)
{
    std::string::size_type pos(0);
    vpair.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        dukeid_t hfirst(strfirst);
        dukeid_t hsecond(strsecond);
        vpair.push_back(std::make_pair(hfirst, hsecond));
    }
}

// (first)(second)...(first)(second)
inline std::string pack_dukeidstr_pair_vector(const dukeidstr_pair_vector& hmap)
{
    std::string strhmap;
    for (dukeidstr_pair_vector::const_iterator it = hmap.begin(); it != hmap.end(); ++it)
    {
        strhmap += "(" + it->first.str() + ")";
        strhmap += "(" + it->second + ")";
    }
    return strhmap;
}

// (first)(second)...(first)(second)
inline void unpack_dukeidstr_pair_vector(const std::string& strhmap,
        dukeidstr_pair_vector& vpair)
{
    std::string::size_type pos(0);
    vpair.clear();
    while (true && strhmap.length())
    {
        std::string strfirst, strsecond;
        pos = find_between(strhmap, strfirst, "(", ")", pos);
        if (pos == std::string::npos)
            break;
        pos = find_between(strhmap, strsecond, "(", ")", pos);
        assert(pos != std::string::npos);

        dukeid_t handle(strfirst);
        vpair.push_back(std::make_pair(handle, strsecond));
    }
}

struct duke_logic_data_base
{
    std::string m_name;
    std::string m_icon;

    MSGPACK_DEFINE(m_name, m_icon);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};
/*
struct duke_logic_data_none : public duke_logic_data_base
{
    std::string pack() const
    {
        return duke_logic_data_base::pack();
    }

    void unpack(const std::string& strval)
    {
        return duke_logic_data_base::unpack(strval);
    }
};

struct duke_logic_data_boolean : public duke_logic_data_base
{
    std::string pack() const
    {
        return duke_logic_data_base::pack();
    }

    void unpack(const std::string& strval)
    {
        return duke_logic_data_base::unpack(strval);
    }
};

struct duke_logic_data_integer : public duke_logic_data_base
{
    std::string pack() const
    {
        return duke_logic_data_base::pack();
    }

    void unpack(const std::string& strval)
    {
        return duke_logic_data_base::unpack(strval);
    }
};

struct duke_logic_data_float : public duke_logic_data_base
{
    std::string pack() const
    {
        return duke_logic_data_base::pack();
    }

    void unpack(const std::string& strval)
    {
        return duke_logic_data_base::unpack(strval);
    }
};

struct duke_logic_data_string : public duke_logic_data_base
{
    std::string pack() const
    {
        return duke_logic_data_base::pack();
    }

    void unpack(const std::string& strval)
    {
        return duke_logic_data_base::unpack(strval);
    }
};
*/
struct duke_logic_data_bytes : public duke_logic_data_base
{
    std::string pack(const duke_bytes_t& dbytes) const
    {
        return pack_bytes(dbytes);
    }

    void unpack(const std::string& strval, duke_bytes_t& dbytes)
    {
        return unpack_bytes(strval, dbytes);
    }
};

struct duke_logic_data_interval : public duke_logic_data_base
{
    void pack(const duke_time_t& dtime, uint64_t& low, uint64_t& high) const
    {
        return pack_time(dtime, low, high);
    }

    void unpack(uint64_t low, uint64_t high, duke_time_t& dtime)
    {
        return unpack_time(low, high, dtime);
    }
};

struct duke_logic_data_time : public duke_logic_data_base
{
    void pack(const duke_time_t& dtime, uint64_t& low, uint64_t& high) const
    {
        return pack_time(dtime, low, high);
    }

    void unpack(uint64_t low, uint64_t high, duke_time_t& dtime)
    {
        return unpack_time(low, high, dtime);
    }
};

struct duke_logic_data_interface_expanded : public duke_logic_data_base
{
    dukeid_t m_expansive_interface ;
    dukeid_vector m_vif;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_expansive_interface, m_vif);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

};


struct duke_logic_data_interface_compound : public duke_logic_data_base
{
    bool                  m_singleton;
    dukeid_t              m_ifc;
    dukeid_vector         m_hext;
    dukeid_vector         m_decls;
    bool                  m_expanded;
    dukeid_t              m_type;
    std::string           name;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_singleton, m_ifc, m_hext, m_decls, m_expanded, m_type, name);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_interface_compound()
    {}

    // construct from core structure
    duke_logic_data_interface_compound(const if_compound_data_t& tmp_data)
    {
        m_name = tmp_data.name;
        name = tmp_data.name;
        m_singleton = tmp_data.is_singleton;
	
        m_decls.clear();
        for(nb_id_vector_const_it it = tmp_data.decls.begin(); it != tmp_data.decls.end(); ++it)
        {
            m_decls.push_back(*it);
        }

        m_hext.clear();
        std::vector<if_exp_group>::const_iterator iter;
        for (iter = tmp_data.groups.begin(); iter != tmp_data.groups.end(); ++iter)
        {
            m_hext.push_back(iter->min_if);
        }
    }
};

// {(handle)...(handle)}
// {(handle)...(handle)}
struct duke_logic_data_declaration_parameters
{
    dukeid_vector m_hiifs;  // Input InterFace handle vector
    dukeid_vector m_hoifs;  // Output InterFace handle vector

    MSGPACK_DEFINE(m_hiifs, m_hoifs);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

};

struct duke_logic_data_declare_compound : public duke_logic_data_base
{
    struct m_iport_t
    {
        std::string name;
        dukeid_t interface;
        dukeid_t default_value;
        MSGPACK_DEFINE(name, interface, default_value);
    };

    struct m_oport_t
    {
        std::string name;
        dukeid_t interface;
        MSGPACK_DEFINE(name, interface);
    };

    struct m_decl_exp_idx
    {
        bool is_input;
        int port_idx;
        int relay_idx;
        MSGPACK_DEFINE(is_input, port_idx, relay_idx);
    };

    struct m_decl_exp_group
    {
        std::string name;
        dukeid_t min_if;
        std::vector<m_decl_exp_idx> members;
        bool expanded;
        MSGPACK_DEFINE(name, min_if, members, expanded);
    };

    std::string name;
    std::vector<m_iport_t> iports;
    std::vector<m_oport_t> oports;
    std::vector<m_decl_exp_group> groups;

    MSGPACK_DEFINE(m_name, m_icon, 
        name, iports, oports, groups);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_declare_compound() {};

    // construct from core structure
    duke_logic_data_declare_compound(const decl_compound_data_t& tmp_data)
    {
        typedef std::vector<iport_t>::const_iterator  iport_ite;
        typedef std::vector<oport_t>::const_iterator  oport_ite;
        typedef std::vector<decl_exp_group>::const_iterator group_ite;
        typedef std::vector<decl_exp_idx>::const_iterator decl_exp_ite;

        name = tmp_data.name;
        for (iport_ite it = tmp_data.iports.begin(); it != tmp_data.iports.end(); ++it)
        {
            m_iport_t tmp;
            tmp.name = it->name;
            tmp.interface.str(it->interface.str());
            tmp.default_value.str(it->default_value.str());
            iports.push_back(tmp);        
        }

        for (oport_ite it = tmp_data.oports.begin(); it != tmp_data.oports.end(); ++it)
        {
            //nb_id_t id;
            //memcpy(&id, &(*it), sizeof(id));
            m_oport_t tmp;
            tmp.name = it->name;
            tmp.interface.str(it->interface.str());
            oports.push_back(tmp);        
        }

        for(group_ite it = tmp_data.groups.begin(); it != tmp_data.groups.end(); ++it)
        {
            m_decl_exp_group tmp;
            tmp.name = it->name;
            tmp.min_if.str(it->min_if.str());
            for(decl_exp_ite ite = it->members.begin(); ite != it->members.end(); ++ite)
            {
                m_decl_exp_idx decl_data;
                memcpy(&decl_data, &(*ite), sizeof(decl_data));
                tmp.members.push_back(decl_data);
            }
            tmp.expanded = it->expanded;
            groups.push_back(tmp);
        }
    }

};

//struct duke_logic_data_declare_compound : public duke_logic_data_base
//{
//    duke_logic_data_declaration_parameters m_param; //
//    dukeid_t      m_interface;
//
//    dukeid_t      m_instructionid;
//
//    dukeid_t      m_ifctype;
//
//    std::string   func_type;
//
//    int index;
//
//    std::string pack()
//    {
//        std::string strval;
//
//        // duke_logic_data_base
//        strval += "{{{" + duke_logic_data_base::pack() + "}}}";
//        // input/output interfaces
//        strval += "&" + m_param.pack() + "&";
//
//        strval += "[" + m_interface.str() + "]";
//
//        strval += "[" + m_instructionid.str() + "]";
//
//        strval += "[" + m_ifctype.str() + "]";
//
//        strval += "[" + func_type + "]";
//
//        strval += "[" + to_string(index) + "]";
//
//        return strval;
//    }
//    
//    void unpack(const std::string& strval)
//    {
//        std::string::size_type idx(0);
//        std::string strbase, strparam, strifc, strinsid, strfunctype, strindex, strifctype;
//        // get all string
//        idx = find_between(strval, strbase, "{{{", "}}}", idx);
//        idx = find_between(strval, strparam, "&", "&", idx);
//        idx = find_between(strval, strifc, "[", "]", idx);
//        idx = find_between(strval, strinsid, "[", "]", idx);
//        idx = find_between(strval, strifctype, "[", "]", idx);
//        idx = find_between(strval, strfunctype, "[", "]", idx);
//        idx = find_between(strval, strindex, "[", "]", idx);
//
//        // duke_logic_data_base
//        if (!strbase.empty())
//            duke_logic_data_base::unpack(strbase);
//
//        // input/output interfaces
//        if (!strparam.empty())
//            m_param.unpack(strparam);
//
//        if (!strifc.empty())
//            m_interface.str(strifc);
//
//        if (!strinsid.empty())
//            m_instructionid.str(strinsid);
//
//        if (!strifctype.empty())
//            m_ifctype.str(strifctype);
//
//        if (!strfunctype.empty())
//            func_type = strfunctype;
//
//        if (!strindex.empty())
//            index = from_string<int>(strindex);
//    }
//};

struct duke_logic_data_array : public duke_logic_data_base
{
    dukeid_t                            m_iftype;
    duke_logic_data_interface_compound  m_compound;
    dukeid_vector                       m_vid;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_iftype, m_compound, m_vid);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};

struct duke_logic_data_multimap : public duke_logic_data_base
{
    dukeid_vector   m_type;
    dukeid_multimap m_vid;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_type, m_vid);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

};

struct duke_logic_data_map : public duke_logic_data_base
{
    dukeid_t                            m_iftype;
    duke_logic_data_interface_compound  m_compound;
    dukeid_multimap                     m_vid;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_iftype, m_compound, m_vid);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};

struct duke_logic_data_storage : public duke_logic_data_base
{
    dukeid_pair_vector m_objs;
    //not used
    dukeid_t m_sif;
    
    dukeid_t m_hcontainer;

    //storage's compound interface
    dukeid_t m_iftype;
    duke_logic_data_interface_compound m_compound;    

    int storage_idx;
    dukeid_t exdecl;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_objs, m_sif, m_hcontainer, m_iftype, m_compound,
        storage_idx, exdecl);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};
/*
struct duke_logic_data_nokey_storage : public duke_logic_data_base
{
    dukeid_vector m_objs;
    dukeid_t m_sif;
   
    std::string pack() const
    {
        std::string strval;
        // duke_logic_data_base
        strval += "{" + duke_logic_data_base::pack() + "}";
        // storage
        strval += "{" + pack_dukeid_vector(m_objs) + "}";
        // storage interface
        strval += "{" + m_sif.str() + "}";

        return strval;
    }

    void unpack(const std::string& strval)
    {
        std::string::size_type idx(0);
        std::string strbase, strmap, strif;

        // get all string
        idx = find_between(strval, strbase, "{", "}", idx);
        idx = find_between(strval, strmap, "{", "}", idx);
        idx = find_between(strval, strif, "{", "}", idx);

        m_objs.clear();

        // duke_logic_data_base
        if (!strbase.empty())
            duke_logic_data_base::unpack(strbase);

        // storage
        if (!strmap.empty())
            unpack_dukeid_vector(strmap, m_objs);
        
        // interface handle
        if (!strif.empty())
            m_sif.str(strif);
    }
};

struct duke_logic_data_multi_storage : public duke_logic_data_base
{
    dukeid_multimap m_objs;
    dukeid_t m_sif;
   
    std::string pack() const
    {
        std::string strval;
        // duke_logic_data_base
        strval += "{" + duke_logic_data_base::pack() + "}";
        // storage
        strval += "{" + pack_dukeid_multimap(m_objs) + "}";
        // storage interface
        strval += "{" + m_sif.str() + "}";

        return strval;
    }

    void unpack(const std::string& strval)
    {
        std::string::size_type idx(0);
        std::string strbase, strmap, strif;

        // get all string
        idx = find_between(strval, strbase, "{", "}", idx);
        idx = find_between(strval, strmap, "{", "}", idx);
        idx = find_between(strval, strif, "{", "}", idx);

        m_objs.clear();

        // duke_logic_data_base
        if (!strbase.empty())
            duke_logic_data_base::unpack(strbase);

        // storage
        if (!strmap.empty())
            unpack_dukeid_multimap(strmap, m_objs);
        
        // interface handle
        if (!strif.empty())
            m_sif.str(strif);
    }
};


struct duke_logic_data_wrapper : public duke_logic_data_base
{
};
*/

struct duke_logic_data_declare_expanded : public duke_logic_data_base
{
    std::string             name;
    dukeid_t                m_decl_id;
    dukeid_vector           m_vif; 

    MSGPACK_DEFINE(m_name, m_icon, 
        name, m_decl_id, m_vif);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_declare_expanded()
    {}

    duke_logic_data_declare_expanded(const decl_expanded_data_t& tmp_data)
    {
        name = tmp_data.name;
        m_decl_id = tmp_data.origin_decl_id;
	
        m_vif.clear();
        for(std::size_t i = 0; i < tmp_data.expanded_ifs.size(); ++i)
        {
            m_vif.push_back(tmp_data.expanded_ifs.at(i));
        }	
    }
};

struct duke_logic_data_declaration : public duke_logic_data_base
{
    duke_logic_data_declaration_parameters m_param;
    dukeid_t      m_interface;
    dukeid_t      m_instructionid;
    dukeid_t      m_ifctype;
    std::string   func_type;
    int index;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_param, m_interface, m_instructionid, m_ifctype, func_type, index);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

};


struct duke_logic_data_interface : public duke_logic_data_base
{
    bool            m_singleton;
    dukeid_t        m_ifc;
    dukeid_vector   m_hext;
    dukeid_vector   m_hdecls;
    dukeid_t        m_type;
    std::string     name;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_singleton, m_ifc, m_hext, m_hdecls, m_type, name);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }


    duke_logic_data_interface() : m_singleton(false)
    { }

    bool set_hdecls(dukeid_vector& hdecls)
    {
        m_hdecls = hdecls;
        return true;
    }

};

struct duke_logic_data_user : public duke_logic_data_base
{
    dukeid_t m_hcompose;
    dukeid_t m_hdecompose;
    dukeid_t m_ifid;
    dukeid_pair_vector m_subobjs; // <subobject, constraint interface>
    dukeid_pair_vector m_funcs; // <decl, impl>

    MSGPACK_DEFINE(m_name, m_icon, 
        m_hcompose, m_hdecompose, m_ifid, m_subobjs, m_funcs);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_user()
        : m_hcompose(NBID_TYPE_FUNCTION_COMPOSE),
          m_hdecompose(NBID_TYPE_FUNCTION_DECOMPOSE),
          m_ifid(NB_INTERFACE_USER)
    { }

    bool set_name(const std::string& name)
    {
        duke_logic_data_base::m_name = name;
        return true;
    }

    bool get_name(std::string& name)
    {
        name = duke_logic_data_base::m_name;
        return true;
    }
};

struct duke_logic_data_container : public duke_logic_data_base
{
    dukeid_vector m_anchor;
    dukeid_pair_vector m_funcs;
    size_t m_storagenum;

    dukeid_t m_cif;
    dukeid_pair_vector m_exdecls;
    dukeid_pair_vector m_storage;

    dukeid_t m_hroot;

    //decl id for get anchors
    dukeid_t m_hgetanchors;
    //decl id for get storages (obsoleted)
    dukeid_t m_hgetstorages;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_anchor, m_funcs, m_storagenum,
        m_cif, m_exdecls, m_storage, m_hroot,
        m_hgetanchors, m_hgetstorages);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};


struct duke_logic_data_access : public duke_logic_data_base
{
    dukeid_vector m_hdecls;
    dukeid_t m_hcontainer;
    int anchor_index;
    bool m_registered;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_hdecls, m_hcontainer, anchor_index, m_registered);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_access() : m_hcontainer(NBID_TYPE_NULL), m_registered(false)
    { }
};

struct duke_logic_data_root_access : public duke_logic_data_base
{
    dukeid_t m_hcontainer;
    dukeid_vector m_hdecls;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_hcontainer, m_hdecls);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_root_access() : m_hcontainer(NBID_TYPE_NULL)
    { }
};

struct duke_logic_data_anchor : public duke_logic_data_base
{
    dukeid_t m_hcontainer;
    dukeid_vector m_hdecls;
    dukeid_vector m_exhdecls;
    int index;

    MSGPACK_DEFINE(m_name, m_icon, 
        m_hcontainer, m_hdecls, m_exhdecls, index);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    duke_logic_data_anchor() : m_hcontainer(NBID_TYPE_NULL)
    { }

};

struct duke_logic_data_node
{
    std::string m_name;
    dukeid_t m_hdecl;
    dukeid_vector m_inputs;
    dukeid_vector m_outputs;
    int           cnt;
    dukeid_t m_hOwnerIf;/* needed by some func nodes (by tom) */

    MSGPACK_DEFINE(m_name, m_hdecl, 
        m_inputs, m_outputs, 
        cnt, m_hOwnerIf);

    duke_logic_data_node():cnt(0)
    {
    }

    bool is_object_node() const
    {
        return m_hdecl.is_general_identity();
        //return ((m_hdecl.is_object() && !m_hdecl.is_object_declaration()) || m_hdecl.is_general_identity());
    }

    /*
    bool is_general_generate() const
    {
        return (m_hdecl.get_func_type() == NB_FUNC_GENERAL_IDENTITY);
    }
    */

    void clear()
    {
        m_inputs.clear();
        m_outputs.clear();
        cnt = 0;
    }

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};

struct duke_logic_data_path
{
public:
    std::string m_onode;
    int m_oport; // oport and iport is -1 means time path
    std::string m_inode;
    int m_iport; // oport and iport is -1 means time path

    MSGPACK_DEFINE(m_onode, m_oport, m_inode, m_iport);

public:
    duke_logic_data_path() : m_oport(-1), m_iport(-1)
    { }

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};


struct duke_bridge_object_data
{
    std::string               m_name;   
    dukeid_t                  m_interface;
    dukeid_t                  m_descriptor;
    std::vector<dukeid_t>     m_sub_objects;
    std::vector<std::string>  m_sub_names;

    MSGPACK_DEFINE(m_name, m_interface, m_descriptor,
        m_sub_objects, m_sub_names);

    bool set_name(const std::string& name)
    {
        m_name = name;
        return true;
    }

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
    
    duke_bridge_object_data() {};

    //construct from core structure
    duke_bridge_object_data(const bridge_data_t& data_t)
    {
        this->m_name = data_t.name;
        this->m_descriptor = data_t.descriptor;
        this->m_interface = data_t.interface;
        this->m_sub_names = data_t.sub_names;
        
        nb_id_vector_const_it it = data_t.subobjs.begin();
        for (; it != data_t.subobjs.end(); ++it)
            this->m_sub_objects.push_back(*it);
    }
};

struct duke_bridge_interface_data
{
    int64_t         m_center_index;
    int64_t         m_bridge_id;
    int64_t         m_data_index;
    std::string     m_external_name;

    std::vector<dukeid_t>  m_sub_interfaces;
    std::vector<std::string> m_sub_names;
    std::vector<dukeid_t>  m_decls;

    MSGPACK_DEFINE(m_center_index, m_bridge_id, m_data_index, m_external_name,
        m_sub_interfaces, m_sub_names, m_decls);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }
};
/*
// save the handle and name
struct handle_name
{
    dukeidstr_pair_vector m_handle_name;

    // (first)(second)...(first)(second)
    inline void unpack_dukeid_pair_vector(const std::string& strhmap,
        dukeid_pair_vector& vpair)
    {
        std::string::size_type pos(0);
        vpair.clear();
        while (true && strhmap.length())
        {
            std::string strfirst, strsecond;
            pos = find_between(strhmap, strfirst, "(", ")", pos);
            if (pos == std::string::npos)
                break;
            pos = find_between(strhmap, strsecond, "(", ")", pos);
            assert(pos != std::string::npos);

            dukeid_t hfirst(strfirst);
            dukeid_t hsecond(strsecond);
            vpair.push_back(std::make_pair(hfirst, hsecond));
        }
    }
};
*/
struct file_node
{
    fileid_vector m_vhfileid;
    dukeid_vector m_vhobject;
    dukeid_vector m_vhstorage;
    dukeid_vector m_vhimplement;
    dukeid_vector m_vhinterface;
    dukeid_vector m_vhdeclare;
    dukeid_vector m_vhcontainer;
    dukeid_vector m_vhbridge;
    dukeid_vector m_vhanchor;
    dukeid_vector m_vhaccess;

    MSGPACK_DEFINE(m_vhfileid, m_vhobject, m_vhstorage,
        m_vhimplement, m_vhinterface, m_vhdeclare,
        m_vhcontainer, m_vhbridge, m_vhanchor, m_vhaccess);

    std::string pack() const
    {
        return serialize_by_msgpack(*this);
    }

    void unpack(const std::string& strval)
    {
        deserialize_by_msgpack(strval, *this);
    }

    bool add_handle(const dukeid_t& handle)
    {
        if (handle.is_object() && !handle.is_object_bridge())
            m_vhobject.push_back(handle);
        else if (handle.is_storage())
            m_vhstorage.push_back(handle);
        else if (handle.is_implementation())
            m_vhimplement.push_back(handle);
        else if (handle.is_interface())
            m_vhinterface.push_back(handle);
        else if (handle.is_declaration())
            m_vhdeclare.push_back(handle);
        else if (handle.is_object_container_des())
            m_vhcontainer.push_back(handle);
        else if (handle.is_object_bridge())
            m_vhbridge.push_back(handle);
        else if (handle.is_anchor())
            m_vhanchor.push_back(handle);
        else if (handle.is_access())
            m_vhaccess.push_back(handle);
        return true;
    }
};
typedef  duke_logic_data_node  duke_media_node;
typedef  duke_logic_data_path  duke_media_path;

#endif // __DUKE_LOGIC_OBJECT_DATA_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
