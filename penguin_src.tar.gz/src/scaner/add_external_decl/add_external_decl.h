/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _ADD_EXTERNAL_DECL_JOB_H_
#define _ADD_EXTERNAL_DECL_JOB_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_global_db.h"

#include "../scaner_job_base.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_exec_impl.h"

#include "duke_media_implement.h"
#include "duke_media_formobj_db.h"

class add_external_decl_job : public scaner_job_base
{    
public:

    add_external_decl_job()
        : scaner_job_base(),
        m_converted_impl_num(0),
        m_converted_cond_num(0),
        m_converted_loop_num(0)
    {
        m_name = "add_external_decl_job";
    }
    
    virtual bool start()
    {
        scaner_job_base::start();

        // request a host_commiter_id for the job
        ac_id_dispenser_request_host_committer_id(m_hc_id);

        //collect all the compound_interface ids in core for later check
        m_core_ifc_ids = m_core_ids->m_ifs.com_ifs;

        //collect all the implementation ids in core
        m_core_impl_ids = m_core_ids->m_impls.impl_objs;

        //collect all condition ids in core
        m_core_cond_ids = m_core_ids->m_impls.exec_cond_objs;

        //collect all loop ids in core
        m_core_loop_ids = m_core_ids->m_impls.exec_it_objs;

        return true;
    }

    virtual bool run()
    {
        scaner_job_base::run();

        scan_implementation();

        scan_condition();

        scan_loop();

        return true;
    }

    virtual bool stop()
    {
        scaner_job_base::stop();
        LOG_NOTICE("Total size of implementations in core is "<<m_core_impl_ids.size());
        LOG_NOTICE("Total num of converted implementations : "<<m_converted_impl_num);
        LOG_NOTICE("----------------------------------------");

        LOG_NOTICE("Total size of conditions in core is "<<m_core_cond_ids.size());
        LOG_NOTICE("Total num of converted conditions : "<<m_converted_cond_num);
        LOG_NOTICE("----------------------------------------");

        LOG_NOTICE("Total size of iterators in core is "<<m_core_loop_ids.size());
        LOG_NOTICE("Total num of converted iterators : "<<m_converted_loop_num);
        LOG_NOTICE("----------------------------------------");

        return true;
    }

private:
    void scan_implementation()
    {
        for (std::set<nb_id_t>::const_iterator it = m_core_impl_ids.begin();
                it != m_core_impl_ids.end(); ++it)
        {
            LOG_INFO("start to scan implementation : "<<it->str());

            // read the implementation content
            std::string strval;
            uint32_t ret = ac_object_db_impl::instance().read_(it->str(), strval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            content raw_data;
            unpack_object(strval, raw_data);

            exec_impl_graph_t impl_data;
            nb_id_t impl_id;
            obj_impl_exec_impl::unpack(raw_data, impl_id, impl_data);
            assert(impl_id == (*it));

            if (impl_data.external_decl.is_object_decl_compound())
            {
                // save the impl-decl mapping for later use
                m_impl_decl_map[impl_id] = impl_data.external_decl;

                LOG_INFO("####Origin external decl = "<<impl_data.external_decl.str());
                LOG_INFO("####Already existed, step to next");

                continue;
            }

            // retrieve the ports info from form db
            strval.clear();
            ret = duke_media_formobj_db::instance().read(it->str(), strval);
            if (NB_DB_RESULT_SUCCESS != ret)
            {
                LOG_ERROR("####This implementation can't be found in formobj_db");

                // try to fetch from temp db
                ret = duke_media_tempobj_db::instance().read(it->str(), strval);
                if (NB_DB_RESULT_SUCCESS != ret)
                {
                    LOG_ERROR("####This implementation can't be found in tempobj_db");
                    LOG_ERROR("####Convertion failed, step to next");
                    continue;
                }
            }

            // deserialize to the media data structure
            duke_media_implement mediaImpl;
            mediaImpl.unpack(strval);

            // get implementation's in/out ports
            duke_media_handle_vector iifs, oifs;
            mediaImpl.get_interfaces(iifs, oifs);

            // make a decl_compound according to the port interfaces
            impl_data.external_decl = generate_decl_compound(impl_data.name, iifs, oifs);

            // save the impl-decl mapping for later use
            m_impl_decl_map[impl_id] = impl_data.external_decl;

            // write the impl back to db
            content new_raw_data;
            obj_impl_exec_impl::pack(impl_data, impl_id, new_raw_data);
            std::string newval = pack_object(new_raw_data);
            ret = ac_object_db_impl::instance().write_(impl_id.str(), newval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            // make sure writing succeed
            std::string verify;
            ac_object_db_impl::instance().read_(impl_id.str(), verify);
            assert(newval == verify);


            LOG_NOTICE("####New external decl : "<<impl_data.external_decl.str());
            LOG_NOTICE("####Convertion succeed, step to next");
            m_converted_impl_num++;
        }

    }

    void scan_condition()
    {
        for (std::set<nb_id_t>::const_iterator it = m_core_cond_ids.begin();
                it != m_core_cond_ids.end(); ++it)
        {
            LOG_INFO("start to scan condition : "<<it->str());

            // read the condition content
            std::string strval;
            uint32_t ret = ac_object_db_impl::instance().read_(it->str(), strval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            content raw_data;
            unpack_object(strval, raw_data);

            exec_cond_data_t cond_data;
            nb_id_t cond_id;
            obj_impl_exec_condition::unpack(raw_data, cond_id, cond_data);
            assert(cond_id == (*it));

            if (cond_data.external_decl.is_object_decl_compound())
            {
                LOG_INFO("####Origin external decl = "<<cond_data.external_decl.str());
                LOG_INFO("####Already existed, step to next");

                continue;
            }
    
            assert(cond_data.alternate_execs.size() > 0);

            nb_id_t impl_id = cond_data.alternate_execs[0];
            assert(impl_id.is_function_implement());

            nb_id_t impl_decl = m_impl_decl_map[impl_id];
            assert(impl_decl.is_object_decl_compound());

            // get the decl's ports interfaces
            nb_id_vector viifs, voifs;
            get_decl_compound_interfaces(impl_decl, viifs, voifs);

            // replace the master port if necessary
            if (viifs[0].is_interface_none())
            {
                cond_data.external_decl = impl_decl;
            }
            else
            {
                viifs[0] = NB_INTERFACE_NONE;
                std::string name = cond_data.name + "_external_decl";

                duke_media_handle_vector hiifs, hoifs;
                for (nb_id_vector_const_it itx = viifs.begin(); itx != viifs.end(); ++itx)
                {
                    hiifs.push_back(duke_media_handle(*itx));
                }
                for (nb_id_vector_const_it itx = voifs.begin(); itx != voifs.end(); ++itx)
                {
                    hoifs.push_back(duke_media_handle(*itx));
                }

                nb_id_t new_decl = generate_decl_compound(name, hiifs, hoifs);

                cond_data.external_decl = new_decl;
            }

            // write back to object db
            content new_raw_data;
            obj_impl_exec_condition::pack(cond_data, cond_id, new_raw_data);
            std::string newval = pack_object(new_raw_data);
            ret = ac_object_db_impl::instance().write_(cond_id.str(), newval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            // make sure writing succeed
            std::string verify;
            ac_object_db_impl::instance().read_(cond_id.str(), verify);
            assert(newval == verify);


            LOG_NOTICE("####New external decl : "<<cond_data.external_decl.str());
            LOG_NOTICE("####Convertion succeed, step to next");
            m_converted_cond_num++;
        }

    }

    void scan_loop()
    {
        for (std::set<nb_id_t>::const_iterator it = m_core_loop_ids.begin();
                it != m_core_loop_ids.end(); ++it)
        {
            LOG_INFO("start to scan loop : "<<it->str());

            // read the loop content
            std::string strval;
            uint32_t ret = ac_object_db_impl::instance().read_(it->str(), strval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            content raw_data;
            unpack_object(strval, raw_data);

            exec_iterator_data_t loop_data;
            nb_id_t loop_id;
            obj_impl_exec_iterator::unpack(raw_data, loop_id, loop_data);
            assert(loop_id == (*it));

            if (loop_data.external_decl.is_object_decl_compound())
            {
                LOG_INFO("####Origin external decl = "<<loop_data.external_decl.str());
                LOG_INFO("####Already existed, step to next");

                continue;
            }
    
            nb_id_t impl_id = loop_data.repeated_exec;
            assert(impl_id.is_function_implement());

            nb_id_t impl_decl = m_impl_decl_map[impl_id];
            assert(impl_decl.is_object_decl_compound());

            // get the decl's ports interfaces
            nb_id_vector viifs, voifs;
            get_decl_compound_interfaces(impl_decl, viifs, voifs);

            // replace the master port if necessary
            if (viifs[0].is_interface_none())
            {
                loop_data.external_decl = impl_decl;
            }
            else
            {
                viifs[0] = NB_INTERFACE_NONE;
                std::string name = loop_data.name + "_external_decl";

                duke_media_handle_vector hiifs, hoifs;
                for (nb_id_vector_const_it itx = viifs.begin(); itx != viifs.end(); ++itx)
                {
                    hiifs.push_back(duke_media_handle(*itx));
                }
                for (nb_id_vector_const_it itx = voifs.begin(); itx != voifs.end(); ++itx)
                {
                    hoifs.push_back(duke_media_handle(*itx));
                }

                nb_id_t new_decl = generate_decl_compound(name, hiifs, hoifs);

                loop_data.external_decl = new_decl;
            }

            // write back to object db
            content new_raw_data;
            obj_impl_exec_iterator::pack(loop_data, loop_id, new_raw_data);
            std::string newval = pack_object(new_raw_data);
            ret = ac_object_db_impl::instance().write_(loop_id.str(), newval);
            assert(NB_DB_RESULT_SUCCESS == ret);

            // make sure writing succeed
            std::string verify;
            ac_object_db_impl::instance().read_(loop_id.str(), verify);
            assert(newval == verify);


            LOG_NOTICE("####New external decl : "<<loop_data.external_decl.str());
            LOG_NOTICE("####Convertion succeed, step to next");
            m_converted_loop_num++;
        }

    }

    bool get_decl_compound_interfaces(const nb_id_t& decl_id,
            nb_id_vector& viifs,
            nb_id_vector& voifs)
    {
        std::string strval;
        uint32_t ret = ac_object_db_impl::instance().read_(decl_id.str(), strval);
        assert(NB_DB_RESULT_SUCCESS == ret);

        content raw_data;
        unpack_object(strval, raw_data);

        decl_compound_data_t decl_data;
        nb_id_t id;
        obj_impl_decl_compound::unpack(raw_data, id, decl_data);
        //assert(decl_id == id);

        // get input ports
        for (std::vector<iport_t>::const_iterator it = decl_data.iports.begin();
                it != decl_data.iports.end(); ++it)
        {
            viifs.push_back(it->interface);
        }

        // get output ports
        for (std::vector<oport_t>::const_iterator it = decl_data.oports.begin();
                it != decl_data.oports.end(); ++it)
        {
            voifs.push_back(it->interface);
        }

        assert(viifs.size() > 0 && voifs.size() > 0);

        return true;
    }


    nb_id_t generate_decl_compound(const std::string& impl_name,
            const duke_media_handle_vector& iifs,
            const duke_media_handle_vector& oifs)
    {
        decl_compound_data_t decl_data;

        // name + suffix
        decl_data.name = impl_name + "_external_decl";

        // for inports
        for(duke_media_handle_const_iterator it = iifs.begin();
                it != iifs.end(); ++it)
        {
            nb_id_t if_id = it->get_nb_type();

            // make sure all the interfaces are available in core
            if (!if_id.is_builtin_interface() && !if_id.is_interface_bridge())
            {
                //must be a built-in or compound interface
                assert(if_id.is_compound_interface());
                //must be available in core db
                assert(m_core_ifc_ids.find(if_id) != m_core_ifc_ids.end());
            }

            iport_t iport;
            iport.interface = if_id;
            decl_data.iports.push_back(iport);
        }


        // for outports
        for(duke_media_handle_const_iterator it = oifs.begin();
                it != oifs.end(); ++it)
        {
            nb_id_t if_id = it->get_nb_type();

            // make sure all the interfaces are available in core
            if (!if_id.is_object_interface() && !if_id.is_interface_bridge())
            {
                //must be a built-in or compound interface
                assert(if_id.is_object_interface_compound());
                //must be available in core db
                assert(m_core_ifc_ids.find(if_id) != m_core_ifc_ids.end());
            }

            oport_t oport;
            oport.interface = if_id;
            decl_data.oports.push_back(oport);
        }
        
        // request an id for the decl
        nb_id_t external_decl_id;
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
        decl_info.committer_id = m_hc_id;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);
        assert(ac_id_dispenser_request_nb_id(decl_info, external_decl_id));

        // write the decl to db
        ac_object_db_impl::instance().write_(external_decl_id.str(), pack_object(decl_info.raw_data));

        return external_decl_id;
    }

private:
    // all the compound_interface ids in core
    std::set<nb_id_t> m_core_ifc_ids;

    // all the implementation ids in core
    std::set<nb_id_t> m_core_impl_ids;

    // all the exec_condition ids in core
    std::set<nb_id_t> m_core_cond_ids;

    // all the exec_loop ids in core
    std::set<nb_id_t> m_core_loop_ids;

    // the impl-externel_decl id mapping
    std::map<nb_id_t, nb_id_t> m_impl_decl_map;

    // total num of converted impls
    size_t m_converted_impl_num;
    size_t m_converted_cond_num;
    size_t m_converted_loop_num;

    host_committer_id_t m_hc_id;
};

typedef std::tr1::shared_ptr<add_external_decl_job>  add_external_decl_job_ptr;

#endif /* _ADD_EXTERNAL_DECL_JOB_H_ */
