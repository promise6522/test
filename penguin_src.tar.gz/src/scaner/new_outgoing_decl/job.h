/**************************************************************************
**
** 	Copyright 2011 Nebutown Inc.
**
**************************************************************************/

#ifndef _NEW_OUTGOING_DECL_JOB_H_
#define _NEW_OUTGOING_DECL_JOB_H_

#include <vector>

// Boost header files
#include <boost/tr1/memory.hpp>

#include "ac_global_db.h"

#include "../scaner_job_base.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_declaration.h"

#include "duke_media_formobj_db.h"
#include "duke_logic_object_data.h"

class new_outgoing_decl_job : public scaner_job_base
{    
public:

    new_outgoing_decl_job()
        : scaner_job_base()
    {
        m_name = "new_outgoing_decl_job";
    }
    
    virtual bool start()
    {
        scaner_job_base::start();

        //get bridge factory info
        std::string strval;
        if(!read_bridge_factory_id(m_bf_id.str(), strval))
        {
            return false;
        }
        ac_bridge_factory_impl::unpack(strval, m_bf_id, m_bf_info_set, m_bf_decls, m_out_ac_if);
        LOG_NOTICE("out_ac_if :"<<m_out_ac_if.str());

        ac_id_dispenser_request_host_committer_id(m_hc_id);

        return true;
    }

    virtual bool run()
    {
        scaner_job_base::run();

        //get the data in core
        std::string strval;
        int flag = 0;
        NbDbResult ret = ac_object_db_impl::instance().read(m_out_ac_if.str(), strval, flag);
        if(ret != NB_DB_RESULT_SUCCESS)
        {
            return false;
        }
        
        content raw_data;
        unpack_object(strval, raw_data);

        if_compound_data_t if_data;
        nb_id_t if_id;
        obj_impl_interface_compound::unpack(raw_data, if_id, if_data);
        assert(if_id == m_out_ac_if);

        if(if_data.decls.size() == 12)
        {
            //remove the default_decl
            m_bf_decls.default_decls.erase(m_bf_decls.default_decls.end() - 1);
            
            //the last decl is send out decl
            nb_id_t send_out_decl = if_data.decls[if_data.decls.size() - 1];
            LOG_NOTICE("send_out_decl : "<<send_out_decl.str());
            assert(!send_out_decl.is_instruction_general());

            //replace send_out_sync
            if_data.decls[if_data.decls.size() - 1] = generate_send_out_sync_decl();
            
            //create send_out_asyn decl
            if_data.decls.push_back(generate_send_out_async_decl());

            content new_raw_data;
            obj_impl_interface_compound::pack(if_data, m_out_ac_if.str(), new_raw_data);
        
            //write data to core
            ret = ac_object_db_impl::instance().write_(m_out_ac_if.str(), pack_object(new_raw_data));
            assert(ret == NB_DB_RESULT_SUCCESS);

            //write data to media
            DbTxn* txn(NULL);
            flag = 0;
            bool bret = duke_media_formobj_db::instance().begin_txn(txn);
            assert(bret);
            ret = duke_media_formobj_db::instance().write_(m_out_ac_if.str(),
                                                           duke_logic_data_interface_compound(if_data).pack(), txn, flag);
            assert(ret == NB_DB_RESULT_SUCCESS);
            duke_media_formobj_db::instance().commit(flag);
        }
        else
        {
            LOG_NOTICE("send_out_syn already exist : "<<if_data.decls[if_data.decls.size() - 2].str());
            LOG_NOTICE("send_out_asyn already exist : "<<if_data.decls[if_data.decls.size() - 1].str());
        }
        
        return true;
    }

    virtual bool stop()
    {
        scaner_job_base::stop();
        std::string strval;
        ac_bridge_factory_impl::pack(m_bf_info_set, m_bf_decls, m_out_ac_if, m_bf_id, strval);
        if(!write_bridge_factory_id(m_bf_id.str(), strval))
        {
            return false;
        }
        return true;
    }

private:
    nb_id_t generate_send_out_sync_decl()
    {
        decl_compound_data_t decl_data;
        decl_data.name = "send_out_sync";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TNone
        bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().find("TNone");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //TNone
        it = m_bf_info_set.get<1>().find("TNone");
        op_data.interface = it->if_id;
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC;
        decl_info.committer_id = m_hc_id;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;

        LOG_NOTICE("send_out_sync  : "<<decl_id.str());

        //write data to core
        NbDbResult ret = ac_object_db_impl::instance().write_(decl_id.str(), pack_object(decl_info.raw_data));
        assert(ret == NB_DB_RESULT_SUCCESS);

        //write data to media
        DbTxn* txn(NULL);
        int flag(0);
        bool bret = duke_media_formobj_db::instance().begin_txn(txn);
        assert(bret);
        ret = duke_media_formobj_db::instance().write_(decl_id.str(), duke_logic_data_declare_compound(decl_data).pack(), txn, flag);
        assert(ret == NB_DB_RESULT_SUCCESS);
        duke_media_formobj_db::instance().commit(flag);

        //push those decl to bridge default decls
        id_name_pair decl_pair = {std::string("send_out_sync"), decl_id};
        m_bf_decls.default_decls.push_back(decl_pair);
        
        return decl_id;
    }

    nb_id_t generate_send_out_async_decl()
    {
        decl_compound_data_t decl_data;
        decl_data.name = "send_out_async";
        
        ////input ports
        iport_t ip_data;
        //none
        ip_data.interface = nb_id_t(NB_INTERFACE_NONE);
        decl_data.iports.push_back(ip_data);
        //TNone
        bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().find("TNone");
        ip_data.interface = it->if_id;
        decl_data.iports.push_back(ip_data);

        ////output ports
        oport_t op_data;
        //bool
        op_data.interface = nb_id_t(NB_INTERFACE_BOOL);
        decl_data.oports.push_back(op_data);

        nb_id_t decl_id;        
        request_nb_id_info decl_info;
        decl_info.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC;
        decl_info.committer_id = m_hc_id;
        obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
        ac_id_dispenser_request_nb_id(decl_info, decl_id);
        decl_info.raw_data.object_id = decl_id;

        LOG_NOTICE("send_out_async  : "<<decl_id.str());

        //write data to core
        NbDbResult ret = ac_object_db_impl::instance().write_(decl_id.str(), pack_object(decl_info.raw_data));
        assert(ret == NB_DB_RESULT_SUCCESS);

        //write data to media
        DbTxn* txn(NULL);
        int flag(0);
        bool bret = duke_media_formobj_db::instance().begin_txn(txn);
        assert(bret);
        ret = duke_media_formobj_db::instance().write_(decl_id.str(), duke_logic_data_declare_compound(decl_data).pack(), txn, flag);
        assert(ret == NB_DB_RESULT_SUCCESS);
        duke_media_formobj_db::instance().commit(flag);

        //push those decl to bridge default decls
        id_name_pair decl_pair = {std::string("send_out_async"), decl_id};
        m_bf_decls.default_decls.push_back(decl_pair);
        
        return decl_id;
    }
    
private:
    bridge_factory_id_t m_bf_id;
    bridge_factory_info_set m_bf_info_set;
    bridge_decl_info m_bf_decls;
    nb_id_t m_out_ac_if;

    host_committer_id_t m_hc_id;
};

typedef std::tr1::shared_ptr<new_outgoing_decl_job>  new_outgoing_decl_job_ptr;

#endif /* _NEW_OUTGOING_DECL_JOB_H_ */
