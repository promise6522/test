/**************************************************************************
**
** 	Copyright 2010 Nb Inc.
**
**************************************************************************/

#ifndef _NB_RAWID_H_
#define _NB_RAWID_H_

// C 89 header files
#include <assert.h>

// C 99 header files
#include <stdint.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <iomanip>
#include <sstream>

#include <vector>

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

// nb header file
//#include "ac_nb_bdb.h"
#include "stdx_string.h"
#include "../actor/include/ac_db/ac_object_db_impl.h"

#define NB_ID_MASK 0xFF000000

struct nb_id_alias
{
    union {
        uint8_t  idu_id8[16];
        uint16_t idu_id16[8];
        uint32_t idu_id32[4];
        uint64_t idu_id64[2];
    } id_alias;
#define idalias_id32       id_alias.idu_id32
#define idalias_id64       id_alias.idu_id64
#define idalias_type       id_alias.idu_id8[15]
#define idalias_user       id_alias.idu_id8[14]
#define idalias_host       id_alias.idu_id32[2]
#define idalias_high       id_alias.idu_id64[1]
#define idalias_low        id_alias.idu_id64[0]

    nb_id_alias() {
        initid_(0);
    }

    std::string
    str() const
    {
        std::ostringstream oss;
        oss << std::setw(16) << std::setfill('0') << std::hex << this->idalias_id64[1];
        oss << std::setw(16) << std::setfill('0') << std::hex << this->idalias_id64[0];
        assert(oss.str().size() == 32);
        return oss.str();
    }

    uint8_t get_type() const
    {
        return static_cast<uint8_t>(idalias_type);
    }

    bool is_type_null() const
    {
        return this->get_type() == 0x00;
    }

    friend bool operator<(const nb_id_alias& v1, const nb_id_alias& v2);
    friend bool operator==(const nb_id_alias& v1, const nb_id_alias& v2);
    friend bool operator!=(const nb_id_alias& v1, const nb_id_alias& v2);
    friend bool operator>(const nb_id_alias& v1, const nb_id_alias& v2);
    friend bool operator>=(const nb_id_alias& v1, const nb_id_alias& v2);
    friend bool operator<=(const nb_id_alias& v1, const nb_id_alias& v2);
    friend std::size_t hash_value(const nb_id_alias& id);

protected:
    void initid_(uint64_t low = 0, uint64_t high = 0) {
        idalias_id64[0] = low;
        idalias_id64[1] = high;
    }
};

struct nb_id_32
{
    union {
        uint8_t  idu_id8[4];
        uint16_t idu_id16[2];
        uint32_t idu_id32[1];
    } id_idu;
#define id_id32    id_idu.idu_id32

    nb_id_32() {
        initid_(0);
    }

    bool is_null() const {
        return (id_id32[0] == 0);
    }

    nb_id_alias to_nb_id_alias()
    {
        nb_id_alias alias;
        alias.idalias_id32[0] = id_id32[0];
        return alias;        
    }    
    
    std::string
    str() const
    {
        std::ostringstream oss;
        oss << std::setw(8) << std::setfill('0') << std::hex << this->id_id32[0];
        assert(oss.str().size() == 8);
        return oss.str();
    }

    void
    str(const std::string& strid)
    {
        assert(strid.size() == 8);
        std::istringstream iss(strid.substr(0, 8));
        iss >> std::hex >> this->id_id32[0];
    }

    nb_id_32& operator=(const nb_id_32& v1)
    {
        id_id32[0] = v1.id_id32[0];
        return (*this);
    }

    friend bool operator<(const nb_id_32& v1, const nb_id_32& v2);
    friend bool operator==(const nb_id_32& v1, const nb_id_32& v2);
    friend bool operator!=(const nb_id_32& v1, const nb_id_32& v2);
    friend bool operator>(const nb_id_32& v1, const nb_id_32& v2);
    friend bool operator>=(const nb_id_32& v1, const nb_id_32& v2);
    friend bool operator<=(const nb_id_32& v1, const nb_id_32& v2);
    friend std::size_t hash_value(const nb_id_32& id);    

protected:
    void initid_(uint32_t value = 0) {
        id_id32[0] = value;
    }

    bool set_value(const std::string& ipv4) {
        id_id32[0] = inet_addr(ipv4.c_str());
        return true;
    }

    bool get_value(std::string& ipv4) const {
        struct in_addr addr;
        assert(sizeof(id_id32[0]) == 4);
        memcpy(&addr, &id_id32[0], 4);
        ipv4 = inet_ntoa(addr);
        return true;
    }
};

struct nb_id_64
{
public:
    union {
        uint8_t  idu_id8[8];
        uint16_t idu_id16[4];
        uint32_t idu_id32[2];
        uint64_t idu_id64[1];
    } id_idu;
#define id64_id64    id_idu.idu_id64
#define id_type      id_idu.idu_id8[7]

    nb_id_64() {
        initid_(0);
    }

    nb_id_64(uint8_t type) {
        initid_(0);
        id_type = type;
    }

    bool set_type(uint8_t type) {
        id_type = type;
        return true;
    }

    bool is_null() const {
        return (id64_id64[0] == 0);
    }

    nb_id_alias to_nb_id_alias()
    {
        nb_id_alias alias;
        alias.idalias_id64[0] = id64_id64[0];
        return alias;
    }

    std::string
    str() const
    {
        std::ostringstream oss;
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id64_id64[0];
        assert(oss.str().size() == 16);
        return oss.str();
    }

    void
    str(const std::string& strid)
    {
        //assert(strid.size() == 16);
        std::istringstream iss(strid.substr(0, 16));
        iss >> std::hex >> this->id64_id64[0];
    }

    nb_id_64& operator=(const nb_id_64& v1)
    {
        id64_id64[0] = v1.id64_id64[0];
        return *this;
    }

    friend bool operator<(const nb_id_64& v1, const nb_id_64& v2);
    friend bool operator==(const nb_id_64& v1, const nb_id_64& v2);
    friend bool operator!=(const nb_id_64& v1, const nb_id_64& v2);
    friend bool operator>(const nb_id_64& v1, const nb_id_64& v2);
    friend bool operator>=(const nb_id_64& v1, const nb_id_64& v2);
    friend bool operator<=(const nb_id_64& v1, const nb_id_64& v2);
    friend std::size_t hash_value(const nb_id_64& id); 

protected:
    void initid_(uint64_t value = 0) {
        id64_id64[0] = value;
    }
};

struct nb_id_128
{
private:
    typedef nb_id_128 __self_type;

public:
    union {
        uint8_t  idu_id8[16];
        uint16_t idu_id16[8];
        uint32_t idu_id32[4];
        uint64_t idu_id64[2];
    } id_idu128;
#define id128_id32       id_idu128.idu_id32
#define id128_id64       id_idu128.idu_id64
#define id128_type       id_idu128.idu_id8[15]
#define id128_user       id_idu128.idu_id8[14]
#define id_host          id_idu128.idu_id32[2]
#define id_high          id_idu128.idu_id64[1]
#define id_low           id_idu128.idu_id64[0]

    nb_id_128() {
        initid_(0, 0);
    }

    nb_id_128(uint8_t type) {
        initid_(0, 0);
        id128_type = type;
    }

    bool is_null() const {
        return ((id128_id64[0] == 0) && (id128_id64[1] == 0));
    }

    nb_id_alias to_nb_id_alias()
    {
        nb_id_alias alias;
        alias.idalias_id64[0] = id128_id64[0];
        alias.idalias_id64[1] = id128_id64[1];
        return alias;
    }

    bool is_value_null() const {
        uint64_t flag = (0xFFFFFFFF << 24) + 0xFFFFFF;
        return (!is_null() && 
                (id128_id64[0] == 0) && 
                ((id128_id64[1] & flag) == 0x0));
    }
    /*
    __self_type&
    operator+=(uint64_t val) {
        if ((id128_id64[0] += val) < val) {
            id128_id64[1] += 1;
        }
        return *this;
    }

    __self_type
    operator+(uint64_t val) {
        __self_type tmp = *this;
        return tmp += val;
    }

    __self_type&
    operator-=(uint64_t val) {
        if (id128_id64[0] < val) {
            id128_id64[0] -= val;
            id128_id64[1] -= 1;
        } else {
            id128_id64[0] -= val;
        }
        return *this;
    }

    __self_type
    operator-(uint64_t val) {
        __self_type tmp = *this;
        return tmp -= val;
    }

    __self_type&
    operator++() {
        *this += 1;
        return *this;
    }

    __self_type
    operator++(int) {
        __self_type tmp = *this;
        ++*this;
        return tmp;
    }

    __self_type&
    operator--() {
        *this -= 1;
        return *this;
    }

    __self_type
    operator--(int) {
        __self_type tmp = *this;
        --*this;
        return tmp;
    }
*/
    std::string
    str() const
    {
        /* for performance, not use stream or sprintf
        std::ostringstream oss;
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id128_id64[1];
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id128_id64[0];
        assert(oss.str().size() == 32);
        return oss.str();
        */
        char buf[32+1];
        stdx::ulong_to_hex(this->id128_id64[1], buf);
        stdx::ulong_to_hex(this->id128_id64[0], buf+16);

        std::string str(buf);
        assert(str.size()==32);
        return str;
    }

    void
    str(const std::string& strid)
    {
        assert(strid.size() == 32);
        /* for performance, no use sstream
        std::istringstream iss(strid.substr(0, 16) + " " + strid.substr(16,16));
        iss >> std::hex >> this->id128_id64[1] >> this->id128_id64[0];
        */
        const char* buf = strid.c_str();
        this->id128_id64[1] = stdx::hex_to_ulong(buf);
        this->id128_id64[0] = stdx::hex_to_ulong(buf+16);
    }

    bool set_value(int value) {
        id128_id32[0] = value;
        return true;
    }
    
    bool get_value(int& value) const {
        value = id128_id32[0];
        return true;
    }

#if (((__GNUC__ >= 4) && (__GNUC_MINOR__ < 3)) || (__GNUC__ < 4))
    bool set_value(std::size_t value) {
        id128_id32[0] = value;
        return true;
    }
    
    bool get_value(std::size_t& value) const {
        value = id128_id32[0];
        return true;
    }
#endif

    bool set_value(bool value) {
        id128_id32[0] = static_cast<int>(value);
        return true;
    }

    bool get_value(bool& value) const {
        value = static_cast<bool>(id128_id32[0]);
        return true;
    }

    bool set_value(float value) {
        assert(sizeof(value) == sizeof(id128_id32[0]));
        memcpy(&id128_id32[0], &value, sizeof(value));
        return true;
    }

    bool get_value(float& value) const {
        assert(sizeof(value) == sizeof(id128_id32[0]));
        memcpy(&value, &id128_id32[0], sizeof(value));
        return true;
    }

    bool set_value(uint64_t low, uint64_t high = 0) {
        uint64_t mask = NB_ID_MASK;
        mask <<= 32;
        id128_id64[1] &= mask;
        id128_id64[1] |= high & ~mask;
        id128_id64[0] = low;
        return true;
    }

    bool get_value(uint64_t& low, uint64_t& high) const {
        uint64_t mask = NB_ID_MASK;
        mask <<= 32;
        high = id128_id64[1] & ~mask;
        low  = id128_id64[0];
        return true;
    }

    void set_type(uint8_t type) {
        id128_type = type;
    }

    nb_id_128& operator=(const nb_id_128& v1)
    {
        id128_id64[0] = v1.id128_id64[0];
        id128_id64[1] = v1.id128_id64[1];
        return *this;
    }

    friend bool operator<(const nb_id_128& v1, const nb_id_128& v2);
    friend bool operator==(const nb_id_128& v1, const nb_id_128& v2);
    friend bool operator!=(const nb_id_128& v1, const nb_id_128& v2);
    friend bool operator>(const nb_id_128& v1, const nb_id_128& v2);
    friend bool operator>=(const nb_id_128& v1, const nb_id_128& v2);
    friend bool operator<=(const nb_id_128& v1, const nb_id_128& v2);
    friend std::size_t hash_value(const nb_id_128& id);

protected:
    void initid_(uint64_t low = 0, uint64_t high = 0) {
        id128_id64[0] = low;
        id128_id64[1] = high;
    }

    void set_bit4() {
        id128_user |= 0x10;
    }

    void set_bit3() {
        id128_user |= 0x08;
    }

    void set_bit2() {
        id128_user |= 0x04;
    }

    void set_bit1() {
        id128_user |= 0x02;
    }

    bool set_right96_bit(nb_id_128 id128) {
        id128_id32[2] = id128.id128_id32[2];
        id128_id64[0] = id128.id128_id64[0];
        return true;
    }

    bool get_right96_bit(nb_id_128& id128) const
    {
        id128.id128_id64[0] = id128_id64[0];
        id128.id128_id32[2] = id128_id32[2];
        return true;
    }

    bool set_value(const std::string& ipv6) {
        unsigned char buf[sizeof(struct in6_addr)];
        if (inet_pton(AF_INET6, ipv6.c_str(), buf))
        {
            memcpy(&id_idu128, buf, 16);
            return true;
        }
        return false;
    }

    bool get_value(std::string& ipv6) const {
        struct in6_addr addr;
        char s_ipv6[INET6_ADDRSTRLEN];

        memcpy(&addr, &id_idu128, 16);
        if (inet_ntop(AF_INET6, (void*)&addr, s_ipv6, INET6_ADDRSTRLEN))
        {
            ipv6 = s_ipv6;
            return true;
        }
        return false;
    }

    bool read(const std::string& strid, std::vector<char>& strval, const std::string& strtxn)
    {
        std::string strvalue;

        typedef std::vector<char>::const_iterator const_pointer;

        int ret = ac_object_db_impl::instance().read(strid, strvalue);
        if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
        {
            for (size_t i = 0; i < sizeof(strvalue); ++i)
            {
                const_pointer p = static_cast<const_pointer>(strvalue.c_str()) + i;
                strval.push_back(*p);
            }
            return true;
        }
        else
            return false;
    }
/*
    bool write(const std::string& strid, const std::vector<char>& strval, const std::string& strtxn)
    {
        std::string strvalue;
        
        strvalue.assign(strval.begin(), strval.end());

        int ret = ac_object_db_impl::instance().write(strid, strvalue);
        if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
            return true;
        else
            return false;
    }
    */
};

typedef nb_id_128 nb_rawid_t;

struct nb_id_256
{
    union {
        uint8_t  idu_id8[32];
        uint16_t idu_id16[16];
        uint32_t idu_id32[8];
        uint64_t idu_id64[4];
    } id_idu;
#define id256_id64           id_idu.idu_id64
#define id_center_high       id_idu.idu_id64[3]
#define id_center_low        id_idu.idu_id64[2]
#define id_bridge_high       id_idu.idu_id64[1]
#define id_bridge_low        id_idu.idu_id64[0]
#define id256_type           id_idu.idu_id8[15]
#define id256_host           id_idu.idu_id32[2]

    nb_id_256() {
        initid_(0, 0);
    }

    nb_id_256(uint8_t type) {
        initid_(0, 0);
        id256_type = type;
    }

    bool is_null() {
        return ((id256_id64[0] == 0) && (id256_id64[1] == 0) &&
                id256_id64[2] == 0 && (id256_id64[3] == 0));
    }

    nb_id_alias to_nb_id_alias()
    {
        nb_id_alias alias;
        alias.idalias_id64[0] = id256_id64[0];
        alias.idalias_id64[1] = id256_id64[1];
        return alias;
    }

    bool set_left128_bit(nb_id_128 id128) {
        id_center_high = id128.id_high;
        id_center_low  = id128.id_low;
        return true;
    }

    bool get_left128_bit(nb_id_128& id128) const {
        id128.id_high = id_center_high;
        id128.id_low  = id_center_low;
        return true;
    }

    bool set_right128_bit(nb_id_128 id128) {
        id_bridge_high = id128.id_high;
        id_bridge_low  = id128.id_low;
        return true;
    }

    bool get_right128_bit(nb_id_128& id128) const {
        id128.id_high = id_bridge_high;
        id128.id_low  = id_bridge_low;
        return true;
    }

    bool set_right96_bit(nb_id_128 id128) {
        id256_host = id128.id128_id32[2];
        id256_id64[0] = id128.id128_id64[0];
        return true;
    }

    bool get_right96_bit(nb_id_128& id128) const
    {
        id128.id128_id64[0] = id256_id64[0];
        id128.id128_id32[2] = id256_host;
        return true;
    }

    std::string
    str() const
    {
        std::ostringstream oss;
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id256_id64[3];
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id256_id64[2];
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id256_id64[1];
        oss << std::setw(16) << std::setfill('0') << std::hex << this->id256_id64[0];
        assert(oss.str().size() == 64);
        return oss.str();
    }

    void
    str(const std::string& strid)
    {
        assert(strid.size() == 64);
        std::istringstream iss(strid.substr(0, 16) + " " + strid.substr(16, 16) + " " + strid.substr(32, 16) + " " + strid.substr(48, 16));
        iss >> std::hex >> this->id256_id64[3] >> this->id256_id64[2] >> this->id256_id64[1] >> this->id256_id64[0];
    }

    nb_id_256& 
    operator=(const nb_id_256& v1)
    {
        id256_id64[0] = v1.id256_id64[0];
        id256_id64[1] = v1.id256_id64[1];
        id256_id64[2] = v1.id256_id64[2];
        id256_id64[3] = v1.id256_id64[3];
        return *this;
    }

    nb_id_256& 
    operator=(int value)
    {
        //id256_id32[0] = v1.id256_id64[0];
        return *this;
    }

    friend bool operator<(const nb_id_256& v1, const nb_id_256& v2);
    friend bool operator==(const nb_id_256& v1, const nb_id_256& v2);
    friend bool operator!=(const nb_id_256& v1, const nb_id_256& v2);
    friend bool operator>(const nb_id_256& v1, const nb_id_256& v2);
    friend bool operator>=(const nb_id_256& v1, const nb_id_256& v2);
    friend bool operator<=(const nb_id_256& v1, const nb_id_256& v2);
    friend std::size_t hash_value(const nb_id_256& id);

protected:
    void initid_(uint64_t low = 0, uint64_t high = 0)
    {
        id256_id64[0] = id256_id64[1] = low;
        id256_id64[2] = id256_id64[3] = high;
    }

    void set_type(uint8_t& type) {
        id256_type = type;
    }
};

#endif /* _NB_RAWID_H_ */

// vim:set tabstop=4 shiftwidth=4 expandtab:
