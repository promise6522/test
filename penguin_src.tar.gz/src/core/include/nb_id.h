/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef __NB_ID_H_
#define __NB_ID_H_

// C 89 header files
#include <assert.h>

// C 99 header files
#include <stdint.h>
#include <string.h>

// C++ 98 header filesnb
#include <string>
#include <iomanip>
#include <sstream>

#include <boost/thread/mutex.hpp>

#include "nb_rawid.h"

enum nbid_type_t {
    NBID_TYPE_NULL = 0x00,

    // except the object id
    NBID_TYPE_CONTAINER                              = 0x01,
    NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE_SINGLETON,
    NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE,
    NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE_SINGLETON,
    NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE,
    NBID_TYPE_STORAGE_SINGLEVALUE_SINGLETON,
    //NBID_TYPE_STORAGE_SINGLEVALUE,
    NBID_TYPE_STORAGE_MULTIVALUE_SINGLETON,
    NBID_TYPE_STORAGE_MULTIVALUE,
    NBID_TYPE_STORAGE_SINGLEVALUE                    = 0x0a,
    NBID_TYPE_ANCHOR                                 = 0x0b,
    NBID_TYPE_ROOT_COMMITTER                         = 0x0c,
    NBID_TYPE_CENTER_COMMITTER                       = 0x0d,
    NBID_TYPE_HOST_COMMITTER                         = 0x0e,
    NBID_TYPE_TRANSACTION                            = 0x0f,
    NBID_TYPE_CENTER                                 = 0x10,
    NBID_TYPE_FACADE                                 = 0x11,
    NBID_TYPE_EXECUTE                                = 0x12,
    NBID_TYPE_BRIDGE                                 = 0x13,

    // object builtin flag
    NBID_TYPE_BUILTIN_OBJECT_MIN,
    NBID_TYPE_OBJECT_NONE                            = 0x40,
    NBID_TYPE_OBJECT_BOOL                            = 0x41,
    NBID_TYPE_OBJECT_INT                             = 0x42,
    NBID_TYPE_OBJECT_FLOAT                           = 0x43,
    NBID_TYPE_OBJECT_STRING                          = 0x44,
    NBID_TYPE_OBJECT_BYTES                           = 0x45,
    NBID_TYPE_OBJECT_INTERVAL                        = 0x46,
    NBID_TYPE_OBJECT_TIME                            = 0x47,
    NBID_TYPE_OBJECT_ARRAY                           = 0x48,
    NBID_TYPE_OBJECT_ARRAY_INT                       = 0x49,
    NBID_TYPE_OBJECT_ARRAY_BOOL                      = 0x4a,
    NBID_TYPE_OBJECT_ARRAY_FLOAT                     = 0x4b,
    NBID_TYPE_OBJECT_ARRAY_STRING                    = 0x4c,
    NBID_TYPE_OBJECT_MAP                             = 0x4d,
    NBID_TYPE_OBJECT_DECLARATION                     = 0x4f,
    NBID_TYPE_OBJECT_INTERFACE                       = 0x50,
    NBID_TYPE_OBJECT_CORPSE                          = 0x51,
    NBID_TYPE_BUILTIN_OBJECT_MAX,

    NBID_TYPE_OBJECT_USER                            = 0x80,
    NBID_TYPE_OBJECT_ACCESS                          = 0x81,
    NBID_TYPE_OBJECT_CONTAINER_DEF                   = 0x82,
    NBID_TYPE_OBJECT_BRIDGE_INTERFACE                = 0x83,
    NBID_TYPE_OBJECT_DECLARATION_COMPOUND            = 0x84,
    NBID_TYPE_OBJECT_INTERFACE_COMPOUND              = 0x85,
    NBID_TYPE_OBJECT_IMPLEMENTATION                  = 0x86,
    NBID_TYPE_OBJECT_EXEC_CONDITION                  = 0x87,
    NBID_TYPE_OBJECT_EXEC_ITERATOR                   = 0x88,
    NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC               = 0x89,
    NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC                = 0x8a,
    NBID_TYPE_OBJECT_EXEC_OBJ_FUNC                   = 0x8b,
    NBID_TYPE_OBJECT_DESCRIPTOR                      = 0x8c, 
    NBID_TYPE_OBJECT_ID_STAND_IN                     = 0x8d,
    // for expansion groups ( added on 11/08/22 )
    NBID_TYPE_OBJECT_DECLARATION_EXPANDED            = 0x8e,
    NBID_TYPE_OBJECT_INTERFACE_EXPANDED              = 0x8f,

    // Compose/Decompose ( 11/08/30 )
    // (they are actually declaration compound)
    NBID_TYPE_FUNCTION_COMPOSE                       = 0x90,
    NBID_TYPE_FUNCTION_DECOMPOSE                     = 0x91,
    NBID_TYPE_FUNCTION_BRIDGE_COMPOSE                = 0x92,
    NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE              = 0x93,

    NBID_TYPE_FUNCTION_GET_ANCHORS                   = 0x94,
    NBID_TYPE_FUNCTION_GET_STORAGES                  = 0x95,

    // send_out/send_out_asyn for outgoing( 11/09/28 )
    // (they are actually declaration compound)
    NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC            = 0x96,
    NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC           = 0x97,

    // bridge object
    NBID_TYPE_OBJECT_BRIDGE                          = 0xc0,

    // exception object
    NBID_TYPE_OBJECT_EXCEPTION                       = 0xc1,

    // for reference in media, not used in core
    NBID_TYPE_FUNCTION_EXECUTE                       = 0xf0,
};


typedef nbid_type_t   nb_type_t;

enum nb_builtin_interface_t {
    NB_INTERFACE_NONE = 0x00,
    NB_INTERFACE_BOOL,
    NB_INTERFACE_INT,
    NB_INTERFACE_FLOAT,
    NB_INTERFACE_STRING,
    NB_INTERFACE_BYTES,
    NB_INTERFACE_INTERVAL,
    NB_INTERFACE_TIME,
    NB_INTERFACE_ARRAY,
    NB_INTERFACE_ARRAY_INT,
    NB_INTERFACE_ARRAY_BOOL,
    NB_INTERFACE_ARRAY_FLOAT,
    NB_INTERFACE_ARRAY_STRING,
    NB_INTERFACE_MAP,
    NB_INTERFACE_CONTAINER_DEF,
    NB_INTERFACE_DESCRIPTOR,
    NB_INTERFACE_EXEC_IMPLEMENTATION,
    NB_INTERFACE_EXEC_CONDITION,
    NB_INTERFACE_EXEC_ITERATOR,
    NB_INTERFACE_EXEC_OBJ_FUNC,
    NB_INTERFACE_EXEC_ANCHOR_FUNC,
    NB_INTERFACE_EXEC_STORAGE_FUNC,
    NB_INTERFACE_BRIDGE,
    NB_INTERFACE_CORPSE,

    NB_INTERFACE_INTERFACE,
    NB_INTERFACE_DECLARATION,
    // Obsoleted
    //NB_INTERFACE_DECLARATION_COMPOUND,
    //NB_INTERFACE_DECLARATION_EXPANDED,
    //NB_INTERFACE_INTERFACE_COMPOUND,
    //NB_INTERFACE_INTERFACE_EXPANDED

    NB_INTERFACE_INTERFACE_BRIDGE,

    NB_INTERFACE_STORAGE_SIMPLE,
    NB_INTERFACE_CONTAINER,
    NB_INTERFACE_ROOT_ACCESS,

    NB_INTERFACE_TIME_LINE = 0xff,
};

enum nb_compound_interface_t {
    NB_INTERFACE_USER = 0x00,
    NB_INTERFACE_ACCESS,
    NB_INTERFACE_STORAGE,
    NB_INTERFACE_ARRAY_TYPE,
    NB_INTERFACE_MAP_TYPE,
    NB_INTERFACE_ANCHOR,
};

enum nb_builtin_instruction_t {
    NB_FUNC_GENERAL_NULL = 0x00,
    NB_FUNC_GENERAL_INSTRUCTION = 0x0100,
    NB_FUNC_GENERAL_GET_INTERFACE,
    NB_FUNC_GENERAL_RUN,
    NB_FUNC_GENERAL_IS_NULL,
    NB_FUNC_GENERAL_IS_SINGLETON,
    NB_FUNC_GENERAL_IS_JUSTID,
    NB_FUNC_GENERAL_IS_BUILTIN,
    NB_FUNC_GENERAL_IS_EXPORTABLE,
    NB_FUNC_GENERAL_IS_LOCAL,
    NB_FUNC_GENERAL_IS_VALUECOMPARED,
    NB_FUNC_GENERAL_EXCEPTION_IF_NULL,
    NB_FUNC_GENERAL_COMPARE,
    NB_FUNC_GENERAL_GET_NAME,
    NB_FUNC_GENERAL_INSTRUCTION_END,    //for enumeration and boundary check
    NB_FUNC_GENERAL_GET_REGISTED_ACCESSES,
    NB_FUNC_GENERAL_START,

    //for core
    NB_FUNC_GENERAL_INIT,
    //for media
    NB_FUNC_GENERAL_IDENTITY,
    NB_FUNC_GENERAL_RETURN,
    NB_FUNC_GENERAL_GET_DECLARATION,


    NB_FUNC_DECLARATION_INSTRUCTION = 0x1000,
    NB_FUNC_DECLARATION_GET_INTERFACES,
    NB_FUNC_DECLARATION_GET_IN_PORTS,
    NB_FUNC_DECLARATION_GET_OUT_PORTS,
    NB_FUNC_DECLARATION_GET_IN_PORT_NUM,
    NB_FUNC_DECLARATION_GET_OUT_PORT_NUM,
    NB_FUNC_DECLARATION_GET_ORIGIN_DECL,
    NB_FUNC_DECLARATION_GET_EXPANDED_INTERFACES,
    NB_FUNC_DECLARATION_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_INTERFACE_INSTRUCTION = 0x2100,
    NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME,
    NB_FUNC_INTERFACE_GET_DECLARATIONS,
    NB_FUNC_INTERFACE_EQ,
    NB_FUNC_INTERFACE_COVERS,
    NB_FUNC_INTERFACE_CONVERT,
    NB_FUNC_INTERFACE_IS_SINGLETON,
    NB_FUNC_INTERFACE_ADD,
    NB_FUNC_INTERFACE_REMOVE,
    NB_FUNC_INTERFACE_GROUPS,
    NB_FUNC_INTERFACE_CEG_ASSIGNMENT,
    NB_FUNC_INTERFACE_STORAGE_ASSIGNMENT,
    NB_FUNC_INTERFACE_INTERFACE_CAST,
    NB_FUNC_INTERFACE_INSTRUCTION_END,//for enumeration and boundary check
    NB_FUNC_INTERFACE_SET_BUILTIN_INS,// private between objects
    NB_FUNC_INTERFACE_GET_BUILTIN_INS,// private between objects

    NB_FUNC_IMPLEMENTATION_INSTRUCTION = 0x3100,

    NB_FUNC_USER_INSTRUCTION = 0x3200,
    NB_FUNC_USER_GET_DESCRIPTOR,
    //NB_FUNC_USER_COMPOSE,  // obsoleted, refer to NBID_TYPE_FUNCTION_COMPOSE
    //NB_FUNC_USER_DECOMPOSE,// obsoleted, refer to NBID_TYPE_FUNCTION_DECOMPOSE

    NB_FUNC_BOOL_INSTRUCTION = 0x3300,
    NB_FUNC_BOOL_NOT,
    NB_FUNC_BOOL_AND,
    NB_FUNC_BOOL_OR,
    NB_FUNC_BOOL_EQ,
    NB_FUNC_BOOL_NE,
    NB_FUNC_BOOL_EXCEPTION_TRUE,
    NB_FUNC_BOOL_EXCEPTION_FALSE,
    NB_FUNC_BOOL_BREAK_TRUE,
    NB_FUNC_BOOL_BREAK_FALSE,
    NB_FUNC_BOOL_TO_INT,
    NB_FUNC_BOOL_TO_STRING,
    NB_FUNC_BOOL_INSTRUCTION_END,   //for enumeration and boundary check

    NB_FUNC_INT_INSTRUCTION = 0x3400,
    NB_FUNC_INT_ADD,
    NB_FUNC_INT_SUB,
    NB_FUNC_INT_IMUL,
    NB_FUNC_INT_IDIV,
    NB_FUNC_INT_IDIV_REM,
    NB_FUNC_INT_EQ,
    NB_FUNC_INT_LT,
    NB_FUNC_INT_INC,
    NB_FUNC_INT_DEC,
    NB_FUNC_INT_TO_STRING,
    NB_FUNC_INT_TO_FLOAT,
    NB_FUNC_INT_INSTRUCTION_END,    //for enumeration and boundary check
    NB_FUNC_INT_VERIFY,//not used

    NB_FUNC_FLOAT_INSTRUCTION = 0x3500,
    NB_FUNC_FLOAT_ADD,
    NB_FUNC_FLOAT_SUB,
    NB_FUNC_FLOAT_IMUL,
    NB_FUNC_FLOAT_IDIV,
    NB_FUNC_FLOAT_EQ,
    NB_FUNC_FLOAT_LT,
    NB_FUNC_FLOAT_TO_INT,
    NB_FUNC_FLOAT_TO_STRING,
    NB_FUNC_FLOAT_INSTRUCTION_END,  //for enumeration and boundary check

    NB_FUNC_STR_INSTRUCTION = 0x3600,
    NB_FUNC_STR_APPEND,
    NB_FUNC_STR_FIND,
    NB_FUNC_STR_SUBSTR,
    NB_FUNC_STR_SIZE,
    NB_FUNC_STR_SPLITAT,
    NB_FUNC_STR_TO_INT,
    NB_FUNC_STR_TO_BOOL,
    NB_FUNC_STR_TO_FLOAT,
    NB_FUNC_STR_TO_INTERVAL,
    NB_FUNC_STR_TO_TIME,
    NB_FUNC_STR_TO_BYTES,
    NB_FUNC_STR_INSTRUCTION_END,    //for enumeration and boundary check

    NB_FUNC_BYTES_INSTRUCTION = 0x3700,
    NB_FUNC_BYTES_JOIN,
    NB_FUNC_BYTES_RANGE,
    NB_FUNC_BYTES_SIZE,
    NB_FUNC_BYTES_SPLIT,
    NB_FUNC_BYTES_SPLITAT,
    NB_FUNC_BYTES_CRC,
    NB_FUNC_BYTES_TO_STR,
    NB_FUNC_BYTES_INSTRUCTION_END,  //for enumeration and boundary check

    NB_FUNC_INTERVAL_INSTRUCTION = 0x3800,
    NB_FUNC_INTERVAL_GET,
    NB_FUNC_INTERVAL_ADD,
    NB_FUNC_INTERVAL_SUB,
    //NB_FUNC_INTERVAL_MUL,
    //NB_FUNC_INTERVAL_DIV,
    NB_FUNC_INTERVAL_TO_STRING,
    NB_FUNC_INTERVAL_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_TIME_INSTRUCTION = 0x3900,
    NB_FUNC_TIME_GET,
    NB_FUNC_TIME_SHOW,
    NB_FUNC_TIME_CURRENT,
    NB_FUNC_TIME_ADD,
    NB_FUNC_TIME_SUB,
    NB_FUNC_TIME_SUB_TIME,
    NB_FUNC_TIME_TO_STRING,
    NB_FUNC_TIME_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_ARRAY_INSTRUCTION = 0x4000,
    NB_FUNC_ARRAY_SETTYPE,
    NB_FUNC_ARRAY_GETTYPE,
    NB_FUNC_ARRAY_GET,
    NB_FUNC_ARRAY_GETHEAD,
    NB_FUNC_ARRAY_GETTAIL,
    NB_FUNC_ARRAY_SIZE,
    NB_FUNC_ARRAY_SET,
    NB_FUNC_ARRAY_INSERT,
    NB_FUNC_ARRAY_ADDHEAD,
    NB_FUNC_ARRAY_ADDTAIL,
    NB_FUNC_ARRAY_FIND,
    NB_FUNC_ARRAY_ERASE,
    NB_FUNC_ARRAY_JOIN,
    NB_FUNC_ARRAY_RANGE,
    NB_FUNC_ARRAY_SPLIT,
    NB_FUNC_ARRAY_SPLITAT,
    NB_FUNC_ARRAY_REVERSE,
    NB_FUNC_ARRAY_UNIONSET,
    NB_FUNC_ARRAY_INTERSECTIONSET,
    NB_FUNC_ARRAY_COMPLEMENTARYSET,
    NB_FUNC_ARRAY_INCLUSION,
    NB_FUNC_ARRAY_CONTENT_COMPARE,
    NB_FUNC_ARRAY_INSTRUCTION_END,  //for enumeration and boundary check
    NB_FUNC_ARRAY_GET_COMPOUND_TYPE,//inner use,no expose to users
    NB_FUNC_ARRAY_GET_OBJECT_TYPE,  //inner use,no expose to users

    NB_FUNC_MAP_INSTRUCTION = 0x4100,
    NB_FUNC_MAP_SETTYPE,
    NB_FUNC_MAP_GETTYPE,
    NB_FUNC_MAP_GET,
    NB_FUNC_MAP_GET_OR,
    NB_FUNC_MAP_INSERT,
    NB_FUNC_MAP_REPLACE,
    NB_FUNC_MAP_UPDATE,
    NB_FUNC_MAP_ERASE,
    NB_FUNC_MAP_HAS_KEY,
    NB_FUNC_MAP_SIZE,
    NB_FUNC_MAP_GETALLKEYS,
    NB_FUNC_MAP_CONTENT_COMPARE,
    NB_FUNC_MAP_INSTRUCTION_END,    //for enumeration and boundary check
    NB_FUNC_MAP_GET_TYPE,           //inner use,no expose to users

    NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION = 0x4200,
    NB_FUNC_BRIDGE_INTERFACE_GET_DECLARATIONS,
    NB_FUNC_BRIDGE_INTERFACE_EQ,
    NB_FUNC_BRIDGE_INTERFACE_COVERS,
    NB_FUNC_BRIDGE_INTERFACE_CONVERT,
    NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_CONTAINER_INSTRUCTION = 0x4300,
    NB_FUNC_CONTAINER_INFORM_STORE_SINGLETON_OBJECT,
    NB_FUNC_CONTAINER_GET_ANCHOR,
    NB_FUNC_CONTAINER_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_DESCRIPTOR_INSTRUCTION = 0x4400,
    NB_FUNC_DESCRIPTOR_GET_IMPLEMENTATION,
    NB_FUNC_DESCRIPTOR_GET_SUBOBJ_INTERFACES,
    NB_FUNC_DESCRIPTOR_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_ACCESS_INSTRUCTION = 0x4500,
    NB_FUNC_ACCESS_GET_CONTAINER,
    NB_FUNC_ACCESS_GET_ANCHOR,
    NB_FUNC_ACCESS_IS_REGISTED,
    NB_FUNC_ACCESS_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_ANCHOR_INSTRUCTION = 0x4600,
    NB_FUNC_ANCHOR_GET_CONTAINER,
    NB_FUNC_ANCHOR_GENERATE_ACCESS,
    NB_FUNC_ANCHOR_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_CONTAINER_DEF_INSTRUCTION = 0x6700,
    //NB_FUNC_CONTAINER_DEF_GET_STORAGE_TYPE, obsoleted
    NB_FUNC_CONTAINER_DEF_CREATE_CONTAINER,
    NB_FUNC_CONTAINER_DEF_GET_ANCHOR_INTERFACE,
    NB_FUNC_CONTAINER_DEF_INSTRUCTION_END,//for enumeration and boundary check

    NB_FUNC_STORAGE_INSTRUCTION = 0x6800,
    NB_FUNC_STORAGE_GET_SINGLE,
    NB_FUNC_STORAGE_GET_MORE,
    NB_FUNC_STORAGE_HAS_KEY,
    NB_FUNC_STORAGE_REPLACE_ONE,
    NB_FUNC_STORAGE_DELETE_ONE,
    NB_FUNC_STORAGE_SET_ONE,
    NB_FUNC_STORAGE_UPDATE,
    NB_FUNC_STORAGE_SIZE,           // add on 09/07
    NB_FUNC_STORAGE_GET_RANGE,      // add on 09/07
    NB_FUNC_STORAGE_INSTRUCTION_END,//for enumeration and boundary check
    NB_FUNC_STORAGE_INSERT_ONE,     // currently unavailable
    NB_FUNC_STORAGE_ADD_ONE,        // currently unavailable
    

    NB_FUNC_BRIDGE_INSTRUCTION = 0x6900,
    NB_FUNC_BRIDGE_GET_DESCRIPTOR,
    //NB_FUNC_BRIDGE_COMPOSE,       // obsoleted
    //NB_FUNC_BRIDGE_DECOMPOSE,     // obsoleted
    NB_FUNC_BRIDGE_INSTRUCTION_END,//for enumeration and boundary check



    NB_FUNC_ROOT_ACCESS_INSTRUCTION = 0x7000,
    NB_FUNC_ROOT_ACCESS_CREATE_CONTAINER,
    NB_FUNC_ROOT_ACCESS_DESTROY_CONTAINER,
    NB_FUNC_ROOT_ACCESS_GET_CONT_DEF,
    NB_FUNC_ROOT_ACCESS_GET_STORAGE,
    NB_FUNC_ROOT_ACCESS_GET_STORAGE_TYPE,
    NB_FUNC_ROOT_ACCESS_GET_ANCHOR,
    NB_FUNC_ROOT_ACCESS_GENERATE_ACCESS_FROM_ANCHOR,
    NB_FUNC_ROOT_ACCESS_GET_ACCESS_INTERFACE_FROM_ANCHOR,
    NB_FUNC_ROOT_ACCESS_GET_ANCHOR_LIST,
    NB_FUNC_ROOT_ACCESS_GET_STORAGE_LIST,
    NB_FUNC_ROOT_ACCESS_GET_ACCESS,
    NB_FUNC_ROOT_ACCESS_GET_STORAGE_CONTENT,
    NB_FUNC_ROOT_ACCESS_GET_ANCHORS,
    NB_FUNC_ROOT_ACCESS_GET_STORAGES,
    NB_FUNC_ROOT_ACCESS_INSTRUCTION_END,//for enumeration and boundary check


    NB_FUNC_CORPSE_INSTRUCTION = 0x7100,
    NB_FUNC_CORPSE_PRINT,
    NB_FUNC_CORPSE_GET_NODE_INDEX,
    NB_FUNC_CORPSE_GET_INPUT,
    NB_FUNC_CORPSE_GET_SUB_OBJ,
    NB_FUNC_CORPSE_GET_REASON,
    NB_FUNC_CORPSE_INSTRUCTION_END,//for enumeration and boundary check

   
};

enum nb_exception_type_t
{
    NB_EXCEPTION_NO,
    NB_EXCEPTION_NORMAL,
    NB_EXCEPTION_ZERO,
};

#if defined(__amd64__) || defined(__amd64) || defined(__x86_64__) || defined(__x86_64)
typedef uint64_t ac_id_t;
#else
typedef uint32_t ac_id_t;
#endif

class host_committer_id_t;

class center_id_t : public nb_id_128
{
public:
    center_id_t() {
      initid_(0, 0);
    }

    center_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_ipv6(const std::string& ipv6) {
        return this->set_value(ipv6);
    }

    bool get_ipv6(std::string& ipv6) {
        return this->get_value(ipv6);
    }

};

class host_id_t : public nb_id_32
{
public:
    host_id_t() {
        initid_(0);
    }

    host_id_t(const std::string& strid) {
        this->str(strid);
    }

    host_id_t(const uint32_t& value) {
        id_id32[0] = value;        
    }       

    bool set_ipv4(const std::string& ipv4) {
        return this->set_value(ipv4);
    }

    bool get_ipv4(std::string& ipv4) const {
        return this->get_value(ipv4);
    }

};

class nb_id_t;

class storage_id_t : public nb_id_64
{
public:
    storage_id_t() : nb_id_64(static_cast<uint8_t>(NBID_TYPE_STORAGE_SINGLEVALUE)) {
    }

    storage_id_t(const std::string& strid) {
        this->str(strid);
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id_type);
    }


    storage_id_t& operator=(const storage_id_t& v1)
    {
        id64_id64[0] = v1.id64_id64[0];
        return *this;
    }

    storage_id_t&
    operator+=(uint64_t val) {
        uint64_t flag = (0xFFFFFFFF << 24) + 0xFFFFFF; // 0x00FFFFFFFFFFFFFF
        if (((id64_id64[0] + val) & flag) == flag) {
            id64_id64[0] &= ~flag;
        }
        else {
            id64_id64[0] += val;
        }
        return *this;
    }

    storage_id_t 
    operator+(uint64_t val) {
        storage_id_t tmp = *this;
        return tmp += val;
    }

    bool to_nb_id(nb_id_t& val);

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

class anchor_id_t : public nb_id_64
{
public:
    anchor_id_t() : nb_id_64(static_cast<uint8_t>(NBID_TYPE_ANCHOR)) {
    }

    anchor_id_t(const std::string& strid) {
        this->str(strid);
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id_type);
    }

    anchor_id_t& operator=(const anchor_id_t& v1)
    {
        id64_id64[0] = v1.id64_id64[0];
        return *this;
    }

    anchor_id_t&
    operator+=(uint64_t val) {
        uint64_t flag = (0xFFFFFFFF << 24) + 0xFFFFFF; // 0x00FFFFFFFFFFFFFF
        if (((id64_id64[0] + val) & flag) == flag) {
            id64_id64[0] &= ~flag;
        }
        else {
            id64_id64[0] += val;
        }
        return *this;
    }

    anchor_id_t 
    operator+(uint64_t val) {
        anchor_id_t tmp = *this;
        return tmp += val;
    }

    bool to_nb_id(nb_id_t& val);

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

// root_committer_id256 = center_id128 + root_committer_id128
class root_committer_id_t : public nb_id_256
{
public:
    root_committer_id_t() : nb_id_256(static_cast<uint8_t>(NBID_TYPE_ROOT_COMMITTER)) {
    }

    root_committer_id_t(center_id_t center_id_) : nb_id_256(static_cast<uint8_t>(NBID_TYPE_ROOT_COMMITTER)) {
        set_center_id(center_id_);
    }

    root_committer_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_center_id(const center_id_t& center_id_) {
        assert(sizeof(center_id_) == 16);
        set_left128_bit(center_id_);
        return true; 
    }

    bool get_center_id(center_id_t& center_id_) const {
        get_left128_bit(center_id_);
        return true;
    }

    bool set_host_id(const host_id_t& host_id_) {
        assert(sizeof(host_id_) == 4);
        id256_host = host_id_.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id_) const {
        host_id_ = static_cast<host_id_t>(id256_host);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id256_type);
    }

    root_committer_id_t&
    operator+=(uint64_t val) {
        if ((id256_id64[0] + val) < val) {
            id256_id64[0] = 0;
        }
        else {
            id256_id64[0] += val;
        }
        return *this;
    }

    root_committer_id_t 
    operator+(uint64_t val) {
        root_committer_id_t tmp = *this;
        return tmp += val;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

// center_committer_id256 = center_id128 + center_committer_id128
class center_committer_id_t : public nb_id_256
{
public:
    center_committer_id_t() : nb_id_256(static_cast<uint8_t>(NBID_TYPE_CENTER_COMMITTER)) {
    }

    center_committer_id_t(center_id_t center_id_) : nb_id_256(static_cast<uint8_t>(NBID_TYPE_CENTER_COMMITTER)) {
        set_center_id(center_id_);
    }

    center_committer_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_center_id(const center_id_t& center_id_) {
        assert(sizeof(center_id_) == 16);
        set_left128_bit(center_id_);
        return true; 
    }

    bool get_center_id(center_id_t& center_id_) const {
        get_left128_bit(center_id_);
        return true;
    }

    bool set_host_id(const host_id_t& host_id_) {
        assert(sizeof(host_id_) == 4);
        id256_host = host_id_.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id_) const {
        host_id_ = static_cast<host_id_t>(id256_host);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id256_type);
    }

    center_committer_id_t&
    operator+=(uint64_t val) {
        if ((id256_id64[0] + val) < val) {
            id256_id64[0] = 0;
        }
        else {
            id256_id64[0] += val;
        }
        return *this;
    }

    center_committer_id_t 
    operator+(uint64_t val) {
        center_committer_id_t tmp = *this;
        return tmp += val;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

// host_committer_id128 = host_id32 + host_committer_id96
class host_committer_id_t : public nb_id_128
{
public:
    host_committer_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_HOST_COMMITTER)) {
    }

    host_committer_id_t(uint32_t host_id) : nb_id_128(static_cast<uint8_t>(NBID_TYPE_HOST_COMMITTER)) {
        set_host_id(host_id);
    }

    host_committer_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_host_id(host_id_t host_id) {
        id_host = host_id.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id) const {
        host_id = static_cast<host_id_t>(id_host);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    host_committer_id_t&
    operator+=(uint64_t val) {
        if ((id128_id64[0] + val) < val) {
            id128_id64[0] = 0;
        }
        else {
            id128_id64[0] += val;
        }
        return *this;
    }

    host_committer_id_t 
    operator+(uint64_t val) {
        host_committer_id_t tmp = *this;
        return tmp += val;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

class bridge_id_t;

// container_id256 = center_id128 + container_id128
class container_id_t : public nb_id_256
{
public:
    container_id_t() : nb_id_256(static_cast<uint8_t>(NBID_TYPE_CONTAINER)) {
    }

    container_id_t(const center_id_t& center_id_) : nb_id_256(static_cast<uint8_t>(NBID_TYPE_CONTAINER)) {
        set_center_id(center_id_);
    }

    container_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_center_id(const center_id_t& center_id_) {
        assert(sizeof(center_id_) == 16);
        set_left128_bit(center_id_);
        return true; 
    }

    bool get_center_id(center_id_t& center_id_) const {
        get_left128_bit(center_id_);
        return true;
    }

    bool set_bridge_id(const bridge_id_t& bridge_id_);

    bool get_bridge_id(bridge_id_t& bridge_id_) const;

    bool set_hostcommitterid(host_committer_id_t committer_id) {
        assert(sizeof(committer_id) == 16);
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        set_right96_bit(committer_id);
        return true;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        get_right96_bit(committer_id);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id256_type);
    }

    container_id_t&
    operator+=(uint64_t val) {
        uint64_t flag = (0xFFFFFFFF << 24) + 0xFFFFFF; // 0x00FFFFFFFFFFFFFF
        if (((id64_id64[0] + val) & flag) == flag) {
            id64_id64[0] &= ~flag;
        }
        else {
            id256_id64[0] += val;
        }
        return *this;
    }

    container_id_t 
    operator+(uint64_t val) {
        container_id_t tmp = *this;
        return tmp += val;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;
    }
};

class nb_id_t;

class access_id_t : public nb_id_128
{
public:
    access_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_OBJECT_ACCESS)) {
    }

    access_id_t(const std::string& strid) {
        this->str(strid);
    }

    access_id_t(uint32_t value) {
        initid_(value, 0);
        set_type(NBID_TYPE_OBJECT_ACCESS);
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    bool set_hostcommitterid(host_committer_id_t committer_id) {
        assert(sizeof(committer_id) == 16);
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        set_right96_bit(committer_id);
        return true;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        get_right96_bit(committer_id);
        return true;
    }

    bool to_nb_id(nb_id_t& id) const {
        return true;
    }

    access_id_t&
    operator+=(uint32_t val) {
        if (((id128_id32[3] + val) & 0x00FFFFFF) == 0x00FFFFFF) {
            id128_id32[3] &= 0xFF000000;
        }
        else {
            id128_id32[3] += val;
        }
        return *this;
    }

    access_id_t 
    operator+(uint32_t val) {
        access_id_t tmp = *this;
        return tmp += val;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        host_committer_id_t id;
        get_hostcommitterid(id);        
        return (id == hc_id) ? true : false ;
    }
};

const access_id_t default_transit_access_id(0xFFFFFFFF);

class nb_id_t : public nb_id_128
{
public:
    nb_id_t(nbid_type_t type = NBID_TYPE_NULL) {
        initid_(0, 0);
        set_type(type);
    }

    nb_id_t(nb_builtin_instruction_t ins) {
        initid_(ins, 0);
        set_type(NBID_TYPE_OBJECT_DECLARATION);
    }

    nb_id_t(nb_builtin_interface_t dif) {
        initid_(dif, 0);
        set_type(NBID_TYPE_OBJECT_INTERFACE);
    }
    
    nb_id_t(nb_exception_type_t ex) {
        initid_(ex, 0);
        set_type(NBID_TYPE_OBJECT_EXCEPTION);
    }

    nb_id_t(nb_compound_interface_t dif) {
        initid_(dif, 0);
        set_type(NBID_TYPE_OBJECT_INTERFACE_COMPOUND);
    }

    nb_id_t(const std::string& strid) {
        this->str(strid);
    }

    nb_id_t(const access_id_t& id) {
        (*this).id_high = id.id_high;
        (*this).id_low = id.id_low;
    }

    nb_id_t(const bool value) {
        initid_(0, 0);
        set_type(NBID_TYPE_OBJECT_BOOL);
        set_value(value);
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        host_committer_id_t id;
        get_hostcommitterid(id);        
        return (id == hc_id) ? true : false ;
    }

    std::size_t get_dynamic_num()
    {
        return id128_id32[3] & 0xFFFFFF;
    }

    bool to_anchor_id(anchor_id_t& id) const;
    bool to_storage_id(storage_id_t& id) const;
    bool to_access_id(access_id_t& id) const;

    bool set_hostcommitterid(host_committer_id_t committer_id);

    bool get_hostcommitterid(host_committer_id_t& committer_id) const;

    bool set_singleton();

    bool set_bridge();

    bool set_indepence();

    nb_builtin_instruction_t get_func_type() const;

    nb_builtin_instruction_t get_func_mask() const;

    nb_builtin_interface_t get_interface_type() const;

    nb_compound_interface_t get_compound_interface_type() const;

    nb_exception_type_t get_exception_type() const;
    bool set_exception_type(const nb_exception_type_t& excpType); 

    bool is_builtin_object() const;

    bool is_object_array() const;

    bool is_object_access() const;

    bool is_object_bool() const;

    bool is_object_bytes() const;
    
    bool is_object_container_defination() const;

    bool is_object_declaration() const;

    bool is_object_decl_compound() const;

    bool is_object_decl_expanded() const;

    bool is_object_descriptor() const;

    bool is_object_exec_condition() const;
    bool is_object_exec_implementation() const;

    bool is_object_exec_iterator() const;

    bool is_object_exec_obj_func() const;

    bool is_object_exec_storage_func() const;

    bool is_object_exec_anchor_func() const;

    bool is_object_float() const;
    bool is_object_integer() const;
    
    bool is_object_corpse() const;
    
    bool is_object_interface() const;
    
    bool is_object_interface_compound() const;

    //bool is_object_interface_expanded() const;
    
    bool is_object_bridge_interface() const;
    
    bool is_object_interval() const;
    
    bool is_object_map() const;
    
    bool is_object_none() const;

    bool is_object_string() const;

    bool is_object_time() const;
    
    bool is_user_object() const;

    bool is_bridge_object() const;

    bool is_object() const;
    bool is_object_func() const;
    
    bool is_object_container_des() const;

    bool is_object_des() const;

    bool is_general_identity() const;
    bool is_general_return() const;

    bool is_persistent_type() const;

    bool is_justid_type() const;

    bool is_type_null() const;

    nbid_type_t get_type() const;

    bool get_builtin_interface(nb_id_t& id) const;
    bool is_singleton() const;

    bool is_bridge() const;

    bool is_indepence() const;
    
    bool is_value_compare() const;

    bool is_local() const;

    bool is_exportable() const;

    // Compose/Decompose are special declarations :
    // they can be identified directly via the id type
    bool is_function_compose() const;
    bool is_function_decompose() const;
    bool is_function_bridge_compose() const;
    bool is_function_bridge_decompose() const;

    bool is_function_get_anchors() const;
    bool is_function_get_storages() const;

    bool is_function_outgoing_sync() const;
    bool is_function_outgoing_async() const;

    //////////////////////////////////

    bool is_exception() const;

    bool is_function_instruction() const;

    bool is_access_function() const;

    bool is_executable() const;

    bool is_exec_condition() const;

    bool is_exec_iterator() const;

    bool is_exec_storage_func() const;

    bool is_exec_anchor_func() const;
    bool is_exec_obj_func() const;

    // storage
    bool is_storage_autokey_singlevalue_singleton() const;
    
    bool is_storage_autokey_singlevalue() const;

    bool is_storage_autokey_multivalue_singleton() const;

    bool is_storage_autokey_multivalue() const;

    bool is_storage_singlevalue_singleton() const;

    bool is_storage_singlevalue() const;

    bool is_storage_multivalue_singleton() const;

    // function
    bool is_function_declare() const;
    bool is_function_implement() const;

    bool is_function_executable_normal() const;

    bool is_function_executable_condition() const;

    bool is_function_executable_iterator() const;

    //## instruction ownership
    bool is_instruction_general() const;
    int get_instruction_number() const;

    bool is_instruction_bool() const;
    
    bool is_instruction_exception() const;

    bool is_instruction_int() const;

    bool is_instruction_float() const;

    bool is_instruction_string() const;

    bool is_instruction_bytes() const;

    bool is_instruction_interval() const;

    bool is_instruction_time() const;
    
    bool is_instruction_array() const;

    bool is_instruction_map() const;

    bool is_instruction_user() const;

    bool is_instruction_access() const;

    bool is_instruction_root_access() const;
    
    bool is_instruction_container_def() const;

    bool is_instruction_storage() const;

    bool is_instruction_bridge() const;

    bool is_instruction_bridge_interface() const;

    bool is_instruction_interface() const;

    bool is_instruction_interface_compound() const;

    bool is_instruction_declaration() const;

    bool is_instruction_declaration_compound() const;

    bool is_instruction_implementation() const;


    // add for storage by mike
    bool is_singlevalue_storage() const;

    bool is_autokey_singlevalue_singleton_storage() const;

    bool is_autokey_singlevalue_storage() const;

    bool is_autokey_multivalue_singleton_storage() const;

    bool is_autokey_multivalue_storage() const;

    bool is_singlevalue_singleton_storage() const;

    bool is_multivalue_singleton_storage() const;

    bool is_multivalue_storage() const;


    bool is_builtin_interface() const;

    bool is_compound_interface() const;

    bool is_interface() const;

    bool is_interface_time_line() const;

    bool is_interface_none() const;

    bool is_interface_bool() const;

    bool is_interface_int() const;

    bool is_interface_float() const;

    bool is_interface_string() const;

    bool is_interface_bytes() const;

    bool is_interface_interval() const;

    bool is_interface_time() const;

    bool is_interface_array() const;

    bool is_interface_map() const;

    bool is_interface_bridge() const;
    
    bool is_interface_root_access() const;

    bool is_interface_access() const;

    bool is_interface_anchor() const;

    bool is_interface_storage() const;

    bool is_interface_user() const;


    bool set_usercompose();
    bool set_userdecompose();
    bool set_bridgecompose();
    bool set_bridgedecompose();

    nb_id_t& operator+=(uint32_t val);
    nb_id_t  operator+(uint32_t val);
    bool operator==(const nb_id_t& val);

};

class transaction_id_t : public nb_id_128
{
public:
    transaction_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_TRANSACTION)) {
    }

    transaction_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_hostcommitterid(host_committer_id_t committer_id) {
        assert(sizeof(committer_id) == 16);
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        set_right96_bit(committer_id);
        return true;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        get_right96_bit(committer_id);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    transaction_id_t&
    operator+=(uint32_t val) {
        if (((id128_id32[3] + val) & 0x00FFFFFF) == 0x00FFFFFF) {
            id128_id32[3] &= 0xFF000000;
        }
        else {
            id128_id32[3] += val;
        }
        return *this;
    }

    transaction_id_t 
    operator+(uint32_t val) {
        transaction_id_t tmp = *this;
        return tmp += val;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        host_committer_id_t id;
        get_hostcommitterid(id);        
        return (id == hc_id) ? true : false ;
    }
};

class facade_id_t : public nb_id_128
{
public:
    facade_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_FACADE)) {
    }

    facade_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_hostcommitterid(host_committer_id_t committer_id) {
        assert(sizeof(committer_id) == 16);
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        set_right96_bit(committer_id);
        return true;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        get_right96_bit(committer_id);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    facade_id_t&
    operator+=(uint32_t val) {
        if (((id128_id32[3] += val) & 0x00FFFFFF) == 0x00FFFFFF) {
            id128_id32[3] &= 0xFF000000;
        }
        return *this;
    }

    facade_id_t 
    operator+(uint32_t val) {
        facade_id_t tmp = *this;
        return tmp += val;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        host_committer_id_t id;
        get_hostcommitterid(id);        
        return (id == hc_id) ? true : false ;
    }    
};

class bridge_id_t : public nb_id_128
{
public:
    bridge_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_BRIDGE)) {
    }

    bridge_id_t(uint32_t host_id) : nb_id_128(static_cast<uint8_t>(NBID_TYPE_BRIDGE)) {
        set_host_id(host_id);
    }

    bridge_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_host_id(host_id_t host_id) {
        id_host = host_id.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id) const {
        host_id = static_cast<host_id_t>(id_host);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }


    bridge_id_t&
    operator+=(uint64_t val) {
        if ((id128_id64[0] += val) < val) {
            id128_id64[0] = 0;;
        }
        return *this;
    }

    bridge_id_t 
    operator+(uint64_t val) {
        bridge_id_t tmp = *this;
        return tmp += val;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }
    
    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;        
    }
};

class bridge_factory_id_t : public nb_id_128
{
public:
    bridge_factory_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_BRIDGE)) {
    }

    bridge_factory_id_t(uint32_t host_id) : nb_id_128(static_cast<uint8_t>(NBID_TYPE_BRIDGE)) {
        set_host_id(host_id);
    }

    bridge_factory_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_host_id(host_id_t host_id) {
        id_host = host_id.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id) const {
        host_id = static_cast<host_id_t>(id_host);
        return true;
    }

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    bridge_factory_id_t&
    operator+=(uint64_t val) {
        if ((id128_id64[0] += val) < val) {
            id128_id64[0] = 0;;
        }
        return *this;
    }

    bridge_factory_id_t 
    operator+(uint64_t val) {
        bridge_factory_id_t tmp = *this;
        return tmp += val;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        return false;
    }
    
    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        return false;        
    }
};

class execution_id_t : public nb_id_128
{
public:
    execution_id_t() : nb_id_128(static_cast<uint8_t>(NBID_TYPE_EXECUTE)) {
    }

    /*
    execution_id_t(uint32_t host_id) : nb_id_128(static_cast<uint8_t>(NBID_TYPE_EXECUTE)) {
        set_host_id(host_id);
    }
    */

    execution_id_t(const std::string& strid) {
        this->str(strid);
    }

    bool set_hostcommitterid(host_committer_id_t committer_id) {
        assert(sizeof(committer_id) == 16);
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        set_right96_bit(committer_id);
        return true;
    }

    bool get_hostcommitterid(host_committer_id_t& committer_id) const
    {
        assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
        get_right96_bit(committer_id);
        return true;
    }

    /*
    bool set_host_id(host_id_t host_id) {
        id_host = host_id.id_id32[0];
        return true;
    }

    bool get_host_id(host_id_t& host_id) const {
        host_id = static_cast<host_id_t>(id_host);
        return true;
    }
    */

    nbid_type_t get_type() const {
        return static_cast<nbid_type_t>(id128_type);
    }

    execution_id_t&
    operator+=(uint32_t val) {
        if (((id128_id32[3] += val) & 0x00FFFFFF) == 0x00FFFFFF) {
            id128_id32[3] &= 0xFF000000;
        }
        return *this;
    }

    execution_id_t 
    operator+(uint32_t val) {
        execution_id_t tmp = *this;
        return tmp += val;
    }

    bool is_belong_to_hc(const host_committer_id_t& hc_id)
    {
        host_committer_id_t id;
        get_hostcommitterid(id);        
        return (id == hc_id) ? true : false ;
    }
};

/*
class nb_get_host_committer_helper
{
private:
        template <class TT, bool (TT::*)(host_committer_id_t& committer_id)>
        class Helper{};
   
public:
        template <class TT>
        host_committer_id_t get_hostcommitterid(TT &id, Helper<TT, &TT::get_hostcommitterid> * = 0)
        {
            host_committer_id_t hc_id;            
            id.get_hostcommitterid(hc_id);
            return hc_id;            
        }

        template <class TT>
        host_committer_id_t get_hostcommitterid(TT &id, ...)
        {
            return host_committer_id_t();
        }
};

template <typename T, bool (T::*)(host_committer_id_t&)>
struct nb_get_host_committer_helper {
    nb_get_host_committer_helper(int) {}
};

struct nb_get_host_committer_nil {
    template<typename T>
    nb_get_host_committer_nil(const T&) {}
};

template <typename T>
inline host_committer_id_t 
nb_get_host_committerid(T& id, nb_get_host_committer_helper<T, &T::get_hostcommitterid> unused = 0)
{
    host_committer_id_t hc_id;
    id.get_hostcommitter(hc_id);
    return hc_id;
}

inline host_committer_id_t 
nb_get_host_committerid(nb_get_host_committer_nil)
{
    return host_committer_id_t();
}
*/

#endif /* __NB_ID_H_ */

// vim:set tabstop=4 shiftwidth=4 expandtab:
