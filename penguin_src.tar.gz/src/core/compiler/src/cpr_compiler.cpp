#include "cpr_compiler.h"
#include "cpr_pre_compiler.h"
#include "cpr_checking.h"
#include "cpr_generator.h"



bool compile(const index_info_t& m_index_info, index_id_map& new_id_data, index_string_map& error_info)
{
    cpr_compiler cpr(m_index_info);

    //for dump the editor info
    /*
    for (index_editor_map_const_itr it = m_index_info.idx_xml_map.begin(); it != m_index_info.idx_xml_map.end(); ++it)
    {
        it->second->dump_editor();
        LOG_DEBUG("============================================");
    }
    */

    LOG_INFO("=========================== compile begin ===========================");
    LOG_INFO("compile begin : "<<ac_time_observer::Instance()->print_current_time());
    if (cpr.run(new_id_data, error_info))
    {
        LOG_INFO("    generate " << new_id_data.size() << " objects");
        int i = 0;
        for (index_id_map_itr it = new_id_data.begin(); it != new_id_data.end(); ++it, ++i)
            LOG_INFO("        object[" << i << "]: " << it->second.str());
        LOG_INFO("compile end : "<<ac_time_observer::Instance()->print_current_time());
        LOG_INFO("========================== compile success ==========================");
        return true;
    }
    else
    {
        LOG_ERROR("    error info size = " << error_info.size());
        int i = 0;
        for (index_string_map_itr it = error_info.begin(); it != error_info.end(); ++it, ++i)
            LOG_ERROR("        error info[" << i << "]: " << it->second);
        LOG_INFO("compile end : "<<ac_time_observer::Instance()->print_current_time());
        LOG_INFO("========================== compile failed ===========================");
        return false;
    }
}



cpr_compiler::cpr_compiler(const index_info_t& index_info)
{
    m_index_info = index_info;
    print_generate_data();
}

cpr_compiler::~cpr_compiler()
{
}

bool cpr_compiler::run(index_id_map& new_id_data, index_string_map& error_info)
{
    index_editor_map        editor_data;
    index_id_map            id_data;

    host_committer_id_t     hc_id;

    request_host_committer_id(hc_id);

    // 1. pre compile
    pre_compiler cpr(m_index_info);
    if (!cpr.run(m_index_info.main_idx))
    {
        // pre compile failed
        std::string err_str("complier: missing the compile data");
        error_info.insert(std::make_pair(m_index_info.main_idx, err_str));
        return false;
    }

    cpr.get_run_result(editor_data, id_data);

    // 2. checking
    checking_datas  checker(editor_data, id_data);
    if (!checker.running_checking(error_info))
        return false;

    // 3. request ids
    if (!request_ids(hc_id, editor_data, new_id_data))
    {
        // request ids failed
        std::string err_str("compiler: compile request ids failed");
        error_info.insert(std::make_pair(m_index_info.main_idx, err_str));
        return false;
    }

    // 4. generate
    compiler_generator generator(hc_id, editor_data, id_data, new_id_data);
    if (!generator.generate_object(error_info))
    {
        // generate failed
        std::string err_str("compiler: compile generate objects failed");
        error_info.insert(std::make_pair(m_index_info.main_idx, err_str));
        return false;
    }

    // 5. return
    return true;
}

bool cpr_compiler::request_ids(const host_committer_id_t& hc_id, const index_editor_map& editor_data, index_id_map& new_id_data)
{
    for (index_editor_map_const_itr it = editor_data.begin(); it != editor_data.end(); ++it)
    {
        request_alone_nb_id_info input;
        input.committer_id = hc_id;
        switch (it->second->get_editor_type())
        {
            case e_UserObject_editor:
                input.type = NBID_TYPE_OBJECT_USER;
                break;
            case e_UserContainerDefinition_editor:
                input.type = NBID_TYPE_OBJECT_CONTAINER_DEF;
                break;
            case e_UserAccess_editor:
                input.type = NBID_TYPE_OBJECT_ACCESS;
                break;
            case e_Declaration_editor:
            {
                Declaration_editor_ptr peditor = std::tr1::dynamic_pointer_cast<Declaration_editor>(it->second);
                int decl_type = peditor->get_declarationType();
                if (0 == decl_type)
                    input.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
                else if (1 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_COMPOSE;
                else if (2 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_DECOMPOSE;
                else if (3 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_BRIDGE_COMPOSE;
                else if (4 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE;
                else if (5 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_GET_ANCHORS;
                else if (6 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_GET_STORAGES;
                else if (7 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC;
                else if (8 == decl_type)
                    input.type = NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC;
                else
                    return false;
                break;
            }
            case e_ExpandedDeclaration_editor:
                input.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
                break;
            case e_UserInterface_editor:
                input.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
                break;
            case e_ExpandedInterface_editor:
                input.type = NBID_TYPE_OBJECT_INTERFACE_EXPANDED;
                break;
            case e_Implementation_editor:
                input.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
                break;
            case e_ObjectFunctionExecutable_editor:
                input.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
                break;
            case e_StorageFunctionExecutable_editor:
                input.type = NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC;
                break;
            case e_ConditionalExcutable_editor:
                input.type = NBID_TYPE_OBJECT_EXEC_CONDITION;
                break;
            case e_IterativeExcutable_editor:
                input.type = NBID_TYPE_OBJECT_EXEC_ITERATOR;
                break;
            case e_StringValue_editor:
                input.type = NBID_TYPE_OBJECT_STRING;
                break;
            case e_BytesValue_editor:
                input.type = NBID_TYPE_OBJECT_BYTES;
                break;
            case e_ArrayValue_editor:
                input.type = NBID_TYPE_OBJECT_ARRAY;
                break;
            case e_MapValue_editor:
                input.type = NBID_TYPE_OBJECT_MAP;
                break;
            default:
                return false;
        }

        nb_id_t nid;
        request_alone_nb_id(input, nid);

        new_id_data.insert(std::make_pair<int, nb_id_t>(it->first, nid));
    }

    return true;
}

bool cpr_compiler::print_generate_data()
{
    LOG_INFO("    -----------------------------------------------------------------");

    LOG_INFO("    main idx=" << m_index_info.main_idx);

    LOG_INFO("    idx_xml_map size = " << m_index_info.idx_xml_map.size());
    int i = 0;
    for (index_editor_map_const_itr it = m_index_info.idx_xml_map.begin(); it != m_index_info.idx_xml_map.end(); ++it, ++i)
        LOG_DEBUG("        editing_map[" << i << "]: index = " << it->first);

    LOG_INFO("    idx_id_map size = " << m_index_info.idx_id_map.size());
    i = 0;
    for (index_id_map_const_itr it = m_index_info.idx_id_map.begin(); it != m_index_info.idx_id_map.end(); ++it, ++i)
        LOG_DEBUG("        id_map[" << i << "]: index = " << it->first << ", id = " << it->second.str());

    LOG_INFO("    -----------------------------------------------------------------");

    return true;
}



bool read_from_db(const nb_id_t& obj_id, content& data)
{
    std::string strval;

    ac_object_db_impl::instance().read(obj_id.str(), strval);
    if (strval.empty())
        return false;

    return data_unpacker::unpack_from_stream(strval, data);
}

bool write_to_db(const nb_id_t& obj_id, content& data)
{
    NbDbResult ret = ac_object_db_impl::instance().write_(obj_id.str(), data_packer::pack_to_stream(data));
    return (ret == NB_DB_RESULT_SUCCESS);
}

bool request_host_committer_id(host_committer_id_t& hc_id)
{
    ac_id_t dest_id = g_ac_id_dispenser_acid;

    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    if (pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        return pActor->request_host_committer_id(hc_id);
    }

    return false;    
}

bool request_nb_id(const request_nb_id_info& input, nb_id_t& nid)
{
    ac_id_t dest_id = g_ac_id_dispenser_acid;

    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    if (pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        return pActor->request_nb_id(input, nid);
    }

    return false;    
}

bool request_alone_nb_id(const request_alone_nb_id_info& input, nb_id_t& nid)
{
    ac_id_t dest_id = g_ac_id_dispenser_acid;

    ac_id_dispenser* pActor = dynamic_cast<ac_id_dispenser*>(ac_manager::instance().acid_to_actor(dest_id));
    if (pActor)
    {
        boost::recursive_mutex::scoped_lock lock(pActor->get_sync_mutex());
        return pActor->request_alone_nb_id(input, nid);
    }

    return false;    
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
