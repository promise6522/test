/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <boost/functional/hash.hpp>

#include "nb_rawid.h"
#include "nb_id.h"

// nb_id_alias
bool operator<(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return (v1.idalias_high < v2.idalias_high)
        || ((v1.idalias_high == v2.idalias_high) && (v1.idalias_low < v2.idalias_low));
}

bool operator==(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return (v1.idalias_high == v2.idalias_high) && (v1.idalias_low == v2.idalias_low);
}

bool operator!=(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return !(v1 == v2);
}

bool operator>(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return (v2.idalias_high < v1.idalias_high)
        || ((v2.idalias_high == v1.idalias_high) && (v2.idalias_low < v1.idalias_low));
}

bool operator<=(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return !(v2 < v1);
}

bool operator>=(const nb_id_alias& v1, const nb_id_alias& v2)
{
    return !(v1 < v2);
}

std::size_t hash_value(const nb_id_alias& id)
{
    std::size_t seed = 0;
    boost::hash_combine(seed, id.idalias_id64[0]);
    boost::hash_combine(seed, id.idalias_id64[1]);
    return seed;
}

// nb_id_32
bool operator<(const nb_id_32& v1, const nb_id_32& v2)
{
    return (v1.id_id32 < v2.id_id32);
}

bool operator==(const nb_id_32& v1, const nb_id_32& v2)
{
    return (v1.id_id32 == v2.id_id32);
}

bool operator!=(const nb_id_32& v1, const nb_id_32& v2)
{
    return !(v1.id_id32 == v2.id_id32);
}

bool operator>(const nb_id_32& v1, const nb_id_32& v2)
{
    return (v2.id_id32 < v1.id_id32);
}

bool operator<=(const nb_id_32& v1, const nb_id_32& v2)
{
    return !(v2.id_id32 < v1.id_id32);
}

bool operator>=(const nb_id_32& v1, const nb_id_32& v2)
{
    return !(v1.id_id32 < v2.id_id32);
}

std::size_t hash_value(const nb_id_32& id)
{
    std::size_t seed = 0;
    boost::hash_combine(seed, id.id_id32);
    return seed;
}

// nb_id_64
bool operator<(const nb_id_64& v1, const nb_id_64& v2)
{
    return (v1.id64_id64[0] < v2.id64_id64[0]);
}

bool operator==(const nb_id_64& v1, const nb_id_64& v2)
{
    return (v1.id64_id64[0] == v2.id64_id64[0]);
}

bool operator!=(const nb_id_64& v1, const nb_id_64& v2)
{
    return !(v1.id64_id64[0] == v2.id64_id64[0]);
}

bool operator>(const nb_id_64& v1, const nb_id_64& v2)
{
    return (v2.id64_id64[0] < v1.id64_id64[0]);
}

bool operator<=(const nb_id_64& v1, const nb_id_64& v2)
{
    return !(v2.id64_id64[0] < v1.id64_id64[0]);
}

bool operator>=(const nb_id_64& v1, const nb_id_64& v2)
{
    return !(v1.id64_id64[0] < v2.id64_id64[0]);
}

std::size_t hash_value(const nb_id_64& id)
{
    std::size_t seed = 0;
    boost::hash_combine(seed, id.id64_id64);
    return seed;
}

// nb_id_128
bool operator<(const nb_id_128& v1, const nb_id_128& v2)
{
    return (v1.id_high < v2.id_high)
        || ((v1.id_high == v2.id_high) && (v1.id_low < v2.id_low));
}

bool operator==(const nb_id_128& v1, const nb_id_128& v2)
{
    return (v1.id_high == v2.id_high) && (v1.id_low == v2.id_low);
}

bool operator!=(const nb_id_128& v1, const nb_id_128& v2)
{
    return !(v1 == v2);
}

bool operator>(const nb_id_128& v1, const nb_id_128& v2)
{
    return (v2.id_high < v1.id_high)
        || ((v2.id_high == v1.id_high) && (v2.id_low < v1.id_low));
}

bool operator<=(const nb_id_128& v1, const nb_id_128& v2)
{
    return !(v2 < v1);
}

bool operator>=(const nb_id_128& v1, const nb_id_128& v2)
{
    return !(v1 < v2);
}

std::size_t hash_value(const nb_id_128& id)
{
    std::size_t seed = 0;
    boost::hash_combine(seed, id.id128_id64[0]);
    boost::hash_combine(seed, id.id128_id64[1]);
    return seed;
}

// nb_id_256
bool operator<(const nb_id_256& v1, const nb_id_256& v2)
{
    return (v1.id256_id64[0] < v2.id256_id64[0])
        || ((v1.id256_id64[0] == v2.id256_id64[0]) && (v1.id256_id64[1] < v2.id256_id64[1]))
        || ((v1.id256_id64[0] == v2.id256_id64[0]) && (v1.id256_id64[1] == v2.id256_id64[1])
            && (v1.id256_id64[2] < v2.id256_id64[2]))
        || ((v1.id256_id64[0] == v2.id256_id64[0]) && (v1.id256_id64[1] == v2.id256_id64[1])
            && (v1.id256_id64[2] == v2.id256_id64[2]) && (v1.id256_id64[3] < v2.id256_id64[3]));
}

bool operator==(const nb_id_256& v1, const nb_id_256& v2)
{
    return (v1.id256_id64[0] == v2.id256_id64[0])
        && (v1.id256_id64[1] == v2.id256_id64[1])
        && (v1.id256_id64[2] == v2.id256_id64[2])
        && (v1.id256_id64[3] == v2.id256_id64[3]);
}

bool operator!=(const nb_id_256& v1, const nb_id_256& v2)
{
    return !( v1 == v2);
}

bool operator>(const nb_id_256& v1, const nb_id_256& v2)
{
    return (v2.id256_id64[0] < v1.id256_id64[0])
        || ((v2.id256_id64[0] == v1.id256_id64[0]) && (v2.id256_id64[1] < v1.id256_id64[1]))
        || ((v2.id256_id64[0] == v1.id256_id64[0]) && (v2.id256_id64[1] == v1.id256_id64[1])
            && (v2.id256_id64[2] < v1.id256_id64[2]))
        || ((v2.id256_id64[0] == v1.id256_id64[0]) && (v2.id256_id64[1] == v1.id256_id64[1])
            && (v2.id256_id64[2] == v1.id256_id64[2]) && (v2.id256_id64[3] < v1.id256_id64[3]));
}

bool operator<=(const nb_id_256& v1, const nb_id_256& v2)
{
    return !(v2 < v1);
}

bool operator>=(const nb_id_256& v1, const nb_id_256& v2)
{
    return !(v1 < v2);
}

std::size_t hash_value(const nb_id_256& id)
{
    std::size_t seed = 0;
    boost::hash_combine(seed, id.id256_id64[0]);
    boost::hash_combine(seed, id.id256_id64[1]);
    boost::hash_combine(seed, id.id256_id64[2]);
    boost::hash_combine(seed, id.id256_id64[3]);
    return seed;
}

bool anchor_id_t::to_nb_id(nb_id_t& id)
{    
    id.id_idu128.idu_id64[1] = id64_id64[0];
    return true;
}

bool storage_id_t::to_nb_id(nb_id_t& id)
{
    id.id_idu128.idu_id64[1] = id64_id64[0];
    return true;
}

//nb_id
bool nb_id_t::to_access_id(access_id_t& id) const
{
    id.id_high = (*this).id_high;
    id.id_low  = (*this).id_low;
    return true;
}

bool nb_id_t::to_anchor_id(anchor_id_t& id) const
{
    id.id64_id64[0] = (*this).id_high;
    return true;
}
bool nb_id_t::to_storage_id(storage_id_t& id) const
{
    id.id64_id64[0] = (*this).id_high;
    return true;
}

bool nb_id_t::set_hostcommitterid(host_committer_id_t committer_id)
{
    assert(sizeof(committer_id) == 16);
    assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
    set_right96_bit(committer_id);
    return true;
}

bool nb_id_t::get_hostcommitterid(host_committer_id_t& committer_id) const
{
    assert(committer_id.get_type() == NBID_TYPE_HOST_COMMITTER);
    get_right96_bit(committer_id);
    return true;
}

bool nb_id_t::set_singleton()
{
    assert(this->is_user_object());
    set_bit4();
    return true;
}

bool nb_id_t::set_bridge()
{
    assert(this->is_user_object());
    set_bit3();
    return true;
}

bool nb_id_t::set_indepence()
{
    assert(this->is_user_object());
    set_bit2();
    return true;
}

bool nb_id_t::set_usercompose()
{
    assert(this->is_object_decl_compound());
    set_bit4();
    return true;
}

bool nb_id_t::set_userdecompose()
{
    assert(this->is_object_decl_compound());
    set_bit3();
    return true;
}

bool nb_id_t::set_bridgecompose()
{
    assert(this->is_object_decl_compound());
    set_bit2();
    return true;
}

bool nb_id_t::set_bridgedecompose()
{
    assert(this->is_object_decl_compound());
    set_bit1();
    return true;
}

nb_builtin_instruction_t nb_id_t::get_func_type() const
{
    return static_cast<nb_builtin_instruction_t>(id128_id32[0]);
}

nb_builtin_instruction_t nb_id_t::get_func_mask() const
{
    return static_cast<nb_builtin_instruction_t>(id128_id32[0] & ~0xFF);
}

nb_builtin_interface_t nb_id_t::get_interface_type() const
{
    return static_cast<nb_builtin_interface_t>(id128_id32[0]);
}

nb_compound_interface_t nb_id_t::get_compound_interface_type() const
{
    return static_cast<nb_compound_interface_t>(id128_id32[0]);
}

nb_exception_type_t nb_id_t::get_exception_type() const
{
    return static_cast<nb_exception_type_t>(id128_id32[0]);
}

bool nb_id_t::set_exception_type(const nb_exception_type_t& excpType)
{
    id128_id32[0] = excpType;
    return true;
}

bool nb_id_t::is_builtin_object() const
{
    nbid_type_t type = get_type();
    return NBID_TYPE_BUILTIN_OBJECT_MIN < type && type < NBID_TYPE_BUILTIN_OBJECT_MAX;
}

bool nb_id_t::is_object_array() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_ARRAY == type);
}

bool nb_id_t::is_object_access() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_ACCESS == type);
}

bool nb_id_t::is_object_bool() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_BOOL == type);
}
bool nb_id_t::is_object_bytes() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_BYTES == type);
}

bool nb_id_t::is_object_container_defination() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_CONTAINER_DEF == type);
}

bool nb_id_t::is_object_decl_compound() const
{
    nbid_type_t type = get_type();
    return ((NBID_TYPE_OBJECT_DECLARATION_COMPOUND == type) ||
        (NBID_TYPE_FUNCTION_DECOMPOSE == type) ||
        (NBID_TYPE_FUNCTION_COMPOSE == type) ||
        (NBID_TYPE_FUNCTION_GET_ANCHORS == type) ||
        (NBID_TYPE_FUNCTION_GET_STORAGES == type) ||
        (NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE == type) ||
        (NBID_TYPE_FUNCTION_BRIDGE_COMPOSE == type) ||
        (NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC == type) ||
        (NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC == type));
}

bool nb_id_t::is_object_declaration() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_DECLARATION == type) ;
            //(NBID_TYPE_FUNCTION_DECOMPOSE == type) ||
            //(NBID_TYPE_FUNCTION_COMPOSE == type));
}

bool nb_id_t::is_object_decl_expanded() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_DECLARATION_EXPANDED == type);
}

bool nb_id_t::is_object_descriptor() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_DESCRIPTOR == type);
}

bool nb_id_t::is_object_exec_condition() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_CONDITION == type);
}

bool nb_id_t::is_object_exec_implementation() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_IMPLEMENTATION == type);
}

bool nb_id_t::is_object_exec_iterator() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_ITERATOR == type);
}

bool nb_id_t::is_object_exec_obj_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_OBJ_FUNC == type);
}

bool nb_id_t::is_object_exec_storage_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC == type);
}

bool nb_id_t::is_object_exec_anchor_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC == type);
}

bool nb_id_t::is_object_float() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_FLOAT == type);
}

bool nb_id_t::is_object_integer() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_INT == type);
}

bool nb_id_t::is_object_interface() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_INTERFACE == type);
}

bool nb_id_t::is_object_interface_compound() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_INTERFACE_COMPOUND == type);
}

//bool nb_id_t::is_object_interface_expanded() const
//{
//    nbid_type_t type = get_type();
//    return (NBID_TYPE_OBJECT_INTERFACE_EXPANDED == type);
//}

bool nb_id_t::is_object_bridge_interface() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_BRIDGE_INTERFACE == type);
}

bool nb_id_t::is_object_interval() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_INTERVAL == type);
}

bool nb_id_t::is_object_map() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_MAP == type);
}

bool nb_id_t::is_object_none() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_NONE == type);
}

bool nb_id_t::is_object_corpse() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_CORPSE == type);
}

bool nb_id_t::is_object_string() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_STRING == type);
}

bool nb_id_t::is_object_time() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_TIME == type);
}

bool nb_id_t::is_user_object() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_USER == type);
}

bool nb_id_t::is_bridge_object() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_BRIDGE == type);
}

bool nb_id_t::is_object_container_des() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_CONTAINER_DEF == type);
}

bool nb_id_t::is_object_des() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_DESCRIPTOR == type);
}

bool nb_id_t::is_object() const
{
    return is_builtin_object() 
            || is_user_object() 
            || is_bridge_object() 
            || is_object_func() 
            || is_object_access()
            || is_object_decl_compound()
            || is_object_decl_expanded()// add on 2011/9/14
            || is_object_interface_compound()
            || is_interface_bridge()
            || is_object_container_des()
            || is_object_des()
            || is_object_container_defination()
            || is_function_implement();//add on 2011/7/20
}

bool nb_id_t::is_object_func() const
{
    return get_type() == NBID_TYPE_OBJECT_EXEC_ITERATOR 
        //|| get_type() == NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC
        //|| get_type() == NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC
        //|| get_type() == NBID_TYPE_OBJECT_EXEC_OBJECT_FUNC
        || get_type() == NBID_TYPE_OBJECT_EXEC_CONDITION;
}

bool nb_id_t::is_general_identity() const
{
    return this->get_func_type() == NB_FUNC_GENERAL_IDENTITY;
}

bool nb_id_t::is_general_return() const
{
    return this->get_func_type() == NB_FUNC_GENERAL_RETURN;
}

bool nb_id_t::is_persistent_type() const
{
    return !is_justid_type();
}

bool nb_id_t::is_justid_type() const
{
    nbid_type_t type = get_type();
    return type == NBID_TYPE_NULL         
        || type == NBID_TYPE_OBJECT_NONE
        || type == NBID_TYPE_OBJECT_BOOL
        || type == NBID_TYPE_OBJECT_INT
        || type == NBID_TYPE_OBJECT_FLOAT

        || type == NBID_TYPE_OBJECT_INTERVAL/*TODO*/
        || type == NBID_TYPE_OBJECT_TIME/*TODO*/

        || type == NBID_TYPE_OBJECT_INTERFACE
        || type == NBID_TYPE_OBJECT_DECLARATION;
}

bool nb_id_t::is_type_null() const
{
    return this->get_type() == NBID_TYPE_NULL;
}

nbid_type_t nb_id_t::get_type() const
{
    return static_cast<nbid_type_t>(id128_type);
}

bool nb_id_t::get_builtin_interface(nb_id_t& id) const
{
    nb_builtin_interface_t  bif;

    switch(this->get_type())
    {
        case NBID_TYPE_OBJECT_NONE:
            bif = NB_INTERFACE_NONE;
            break;
        case NBID_TYPE_OBJECT_BOOL:
            bif = NB_INTERFACE_BOOL;
            break;
        case NBID_TYPE_OBJECT_INT:
            bif = NB_INTERFACE_INT;
            break;
        case NBID_TYPE_OBJECT_FLOAT:
            bif = NB_INTERFACE_FLOAT;
            break;
        case NBID_TYPE_OBJECT_STRING:
            bif = NB_INTERFACE_STRING;
            break;
        case NBID_TYPE_OBJECT_BYTES:
            bif = NB_INTERFACE_BYTES;
            break;
        case NBID_TYPE_OBJECT_INTERVAL:
            bif = NB_INTERFACE_INTERVAL;
            break;
        case NBID_TYPE_OBJECT_TIME:
            bif = NB_INTERFACE_TIME;
            break;

        // for expansion groups ( added on 11/08/23 )
        case NBID_TYPE_OBJECT_DECLARATION:
        case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
        case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
        case NBID_TYPE_FUNCTION_COMPOSE:
        case NBID_TYPE_FUNCTION_DECOMPOSE:
        case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE:
        case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE:
        case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC:
        case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC:       
            bif = NB_INTERFACE_DECLARATION;
            break;

        case NBID_TYPE_OBJECT_INTERFACE:
        case NBID_TYPE_OBJECT_INTERFACE_COMPOUND:
            bif = NB_INTERFACE_INTERFACE;
            break;

        case NBID_TYPE_OBJECT_IMPLEMENTATION:
            bif = NB_INTERFACE_EXEC_IMPLEMENTATION;
            break;
        case NBID_TYPE_OBJECT_CONTAINER_DEF:
            bif = NB_INTERFACE_CONTAINER_DEF;
            break;

        default:
            return false;
    }

    id = nb_id_t(bif); 

    return true;
}

bool nb_id_t::is_singleton() const
{
//    if (this->is_builtin_object())
//        return false;
//    assert(this->is_user_object() || this->is_object_access());
    return (id128_user & 0x10);
}

bool nb_id_t::is_bridge() const
{
    if (this->is_builtin_object())
        return false;
    assert(this->is_user_object());
    return (id128_user & 0x08);
}

bool nb_id_t::is_indepence() const
{
    if (this->is_builtin_object())
        return false;
    assert(this->is_user_object());
    return (id128_user & 0x04);
}

bool nb_id_t::is_value_compare() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_STRING == type || NBID_TYPE_OBJECT_BYTES == type || NBID_TYPE_OBJECT_DECLARATION_EXPANDED == type);
}

bool nb_id_t::is_local() const
{
    // TODO
    return true;
}

bool nb_id_t::is_exportable() const
{
    // TODO
    return true;
}

bool nb_id_t::is_function_decompose() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_DECOMPOSE);
}

bool nb_id_t::is_function_compose() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_COMPOSE);
}

bool nb_id_t::is_function_get_anchors() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_GET_ANCHORS);
}

bool nb_id_t::is_function_get_storages() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_GET_STORAGES);
}

bool nb_id_t::is_function_bridge_decompose() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE);
}

bool nb_id_t::is_function_bridge_compose() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_BRIDGE_COMPOSE);
}

bool nb_id_t::is_function_outgoing_sync() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC);
}

bool nb_id_t::is_function_outgoing_async() const
{
    return (this->get_type() == NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC);
}

//////////////////////////////////
bool nb_id_t::is_exception() const
{
    return this->get_type() == NBID_TYPE_OBJECT_EXCEPTION;
}

bool nb_id_t::is_function_instruction() const
{
    return this->get_type() == NBID_TYPE_OBJECT_DECLARATION;
}

bool nb_id_t::is_access_function() const
{
    // TODO
    return true;
}

bool nb_id_t::is_executable() const
{
    return is_exec_condition() || is_exec_iterator() ||
           is_exec_storage_func() || is_exec_anchor_func() || is_exec_obj_func();
}

bool nb_id_t::is_exec_condition() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_CONDITION == type);
}

bool nb_id_t::is_exec_iterator() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_ITERATOR == type);
}

bool nb_id_t::is_exec_storage_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC == type);
}

bool nb_id_t::is_exec_anchor_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC == type);
}

bool nb_id_t::is_exec_obj_func() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_OBJECT_EXEC_OBJ_FUNC == type);
}

// storage
bool nb_id_t::is_storage_autokey_singlevalue_singleton() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE_SINGLETON == type);
}

bool nb_id_t::is_storage_autokey_singlevalue() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE == type);
}

bool nb_id_t::is_storage_autokey_multivalue_singleton() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE_SINGLETON == type);
}

bool nb_id_t::is_storage_autokey_multivalue() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE == type);
}

bool nb_id_t::is_storage_singlevalue_singleton() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_SINGLEVALUE_SINGLETON == type);
}

bool nb_id_t::is_storage_singlevalue() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_SINGLEVALUE == type);
}

bool nb_id_t::is_storage_multivalue_singleton() const
{
    nbid_type_t type = get_type();
    return (NBID_TYPE_STORAGE_MULTIVALUE_SINGLETON == type);
}

// function
bool nb_id_t::is_function_declare() const
{
    return this->get_type() == NBID_TYPE_OBJECT_DECLARATION;
}

bool nb_id_t::is_function_implement() const
{
    return this->get_type() == NBID_TYPE_OBJECT_IMPLEMENTATION;
}

bool nb_id_t::is_function_executable_normal() const
{
    return this->get_type() == NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
}

bool nb_id_t::is_function_executable_condition() const
{
    return this->get_type() == NBID_TYPE_OBJECT_EXEC_CONDITION;
}

bool nb_id_t::is_function_executable_iterator() const
{
    return this->get_type() == NBID_TYPE_OBJECT_EXEC_ITERATOR;
}

bool nb_id_t::is_instruction_general() const
{
    nb_builtin_instruction_t func_type = get_func_type();

    return (this->is_function_instruction()
            && func_type > NB_FUNC_GENERAL_INSTRUCTION
            && func_type < NB_FUNC_GENERAL_INSTRUCTION_END);
}

int nb_id_t::get_instruction_number() const
{
    return (int(NB_FUNC_GENERAL_INSTRUCTION_END - NB_FUNC_GENERAL_INSTRUCTION) - 1);
}

bool nb_id_t::is_instruction_bool() const
{
    return (this->get_func_mask() == NB_FUNC_BOOL_INSTRUCTION
        && this->get_func_type() != NB_FUNC_BOOL_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_exception() const
{
    nb_builtin_instruction_t func_type = get_func_type();

    return (NB_FUNC_BOOL_EXCEPTION_TRUE == func_type
            || NB_FUNC_BOOL_EXCEPTION_FALSE == func_type
            || NB_FUNC_BOOL_BREAK_TRUE == func_type
            || NB_FUNC_BOOL_BREAK_FALSE == func_type);
}

bool nb_id_t::is_instruction_int() const
{
    return (this->get_func_mask() == NB_FUNC_INT_INSTRUCTION);
}

bool nb_id_t::is_instruction_float() const
{
    return (this->get_func_mask() == NB_FUNC_FLOAT_INSTRUCTION);
}

bool nb_id_t::is_instruction_string() const
{
    return (this->get_func_mask() == NB_FUNC_STR_INSTRUCTION);
}

bool nb_id_t::is_instruction_bytes() const
{
    return (this->get_func_mask() == NB_FUNC_BYTES_INSTRUCTION
        && this->get_func_type() != NB_FUNC_BYTES_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_interval() const
{
    return (this->get_func_mask() == NB_FUNC_INTERVAL_INSTRUCTION);
}

bool nb_id_t::is_instruction_time() const
{
    return (this->get_func_mask() == NB_FUNC_TIME_INSTRUCTION);
}

bool nb_id_t::is_instruction_array() const
{
    return (this->get_func_mask() == NB_FUNC_ARRAY_INSTRUCTION
        && this->get_func_type() != NB_FUNC_ARRAY_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_map() const
{
    return (this->get_func_mask() == NB_FUNC_MAP_INSTRUCTION
        && this->get_func_type() != NB_FUNC_MAP_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_user() const
{
    return (this->get_func_mask() == NB_FUNC_USER_INSTRUCTION);
}

bool nb_id_t::is_instruction_access() const
{
    return (this->get_func_mask() == NB_FUNC_ACCESS_INSTRUCTION);
}

bool nb_id_t::is_instruction_root_access() const
{
    return (this->get_func_mask() == NB_FUNC_ROOT_ACCESS_INSTRUCTION);
}

bool nb_id_t::is_instruction_container_def() const
{
    return (this->get_func_mask() == NB_FUNC_CONTAINER_DEF_INSTRUCTION);
}

bool nb_id_t::is_instruction_storage() const
{
    return (this->get_func_mask() == NB_FUNC_STORAGE_INSTRUCTION
        && this->get_func_type() != NB_FUNC_STORAGE_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_bridge() const
{
    return (this->get_func_mask() == NB_FUNC_BRIDGE_INSTRUCTION)
        || this->is_function_bridge_compose()
        || this->is_function_bridge_decompose();
}

bool nb_id_t::is_instruction_interface() const
{
    return (this->get_func_type() == NB_FUNC_INTERFACE_GET_DECLARATIONS
            || this->get_func_type() == NB_FUNC_INTERFACE_GET_DECLARATIONS_NAME);
}

bool nb_id_t::is_instruction_interface_compound() const
{
    return (this->get_func_mask() == NB_FUNC_INTERFACE_INSTRUCTION);
}

bool nb_id_t::is_instruction_bridge_interface() const
{
    return (this->get_func_mask() == NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION
        && this->get_func_type() != NB_FUNC_BRIDGE_INTERFACE_INSTRUCTION_END);
}

bool nb_id_t::is_instruction_declaration() const
{
    return (this->get_func_mask() == NB_FUNC_DECLARATION_INSTRUCTION);
}

bool nb_id_t::is_instruction_declaration_compound() const
{
    return (this->get_func_mask() == NB_FUNC_DECLARATION_INSTRUCTION);
}

bool nb_id_t::is_instruction_implementation() const
{
    return (this->get_func_mask() == NB_FUNC_IMPLEMENTATION_INSTRUCTION);
}

// add for storage by mike
bool nb_id_t::is_singlevalue_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_SINGLEVALUE;
}

bool nb_id_t::is_autokey_singlevalue_singleton_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE_SINGLETON;
}

bool nb_id_t::is_autokey_singlevalue_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_AUTOKEY_SINGLEVALUE;
}

bool nb_id_t::is_autokey_multivalue_singleton_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE_SINGLETON;
}

bool nb_id_t::is_autokey_multivalue_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_AUTOKEY_MULTIVALUE;
}

bool nb_id_t::is_singlevalue_singleton_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_SINGLEVALUE_SINGLETON;
}

bool nb_id_t::is_multivalue_singleton_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_MULTIVALUE_SINGLETON;
}

bool nb_id_t::is_multivalue_storage() const
{
    return this->get_type() == NBID_TYPE_STORAGE_MULTIVALUE;
}

// interface
bool nb_id_t::is_builtin_interface() const
{
    return this->get_type() == NBID_TYPE_OBJECT_INTERFACE;
}

bool nb_id_t::is_compound_interface() const
{
    return this->get_type() == NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
}

bool nb_id_t::is_interface() const
{
    return is_builtin_interface() 
        || is_compound_interface() 
        || is_interface_bridge();
}

bool nb_id_t::is_interface_none() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_NONE;
}

bool nb_id_t::is_interface_bool() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_BOOL;
}

bool nb_id_t::is_interface_time_line() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_TIME_LINE;
}

bool nb_id_t::is_interface_int() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_INT;
}

bool nb_id_t::is_interface_float() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_FLOAT;
}

bool nb_id_t::is_interface_string() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_STRING;
}

bool nb_id_t::is_interface_bytes() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_BYTES;
}

bool nb_id_t::is_interface_interval() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_INTERVAL;
}

bool nb_id_t::is_interface_time() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_TIME;
}

bool nb_id_t::is_interface_array() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_ARRAY;
}

bool nb_id_t::is_interface_map() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_MAP;
}

bool nb_id_t::is_interface_bridge() const
{
    return (this->get_type() == NBID_TYPE_OBJECT_BRIDGE_INTERFACE);
}

bool nb_id_t::is_interface_root_access() const
{
    return is_builtin_interface() && this->get_interface_type() == NB_INTERFACE_ROOT_ACCESS;
}

bool nb_id_t::is_interface_access() const
{
    return is_compound_interface() && this->get_compound_interface_type() == NB_INTERFACE_ACCESS;
}

bool nb_id_t::is_interface_anchor() const
{
    return is_compound_interface() && this->get_compound_interface_type() == NB_INTERFACE_ANCHOR;
}

bool nb_id_t::is_interface_storage() const
{
    return is_compound_interface() && this->get_compound_interface_type() == NB_INTERFACE_STORAGE;
}

bool nb_id_t::is_interface_user() const
{
    return this->get_compound_interface_type() == NB_INTERFACE_USER;
}

/*
bool nb_id_t::is_interface_array_type() const
{
    return is_compound_interface() && this->get_compound_interface_type() == NB_INTERFACE_ARRAY_TYPE;
}

bool nb_id_t::is_interface_map_type() const
{
    return is_compound_interface() && this->get_compound_interface_type() == NB_INTERFACE_MAP_TYPE;
}
*/

nb_id_t& nb_id_t::operator+=(uint32_t val)
{
    if (((id128_id32[3] + val) & 0x00FFFFFF) == 0x00FFFFFF)
        id128_id32[3] &= 0xFF000000;
    else
        id128_id32[3] += val;

    return *this;
}

nb_id_t nb_id_t::operator+(uint32_t val)
{
    nb_id_t tmp = *this;
    return tmp += val;
}

bool nb_id_t::operator==(const nb_id_t& val)
{
    return val.id128_id64[0] == this->id128_id64[0] && val.id128_id64[1] == this->id128_id64[1];
}

//

bool container_id_t::set_bridge_id(const bridge_id_t& bridge_id_) {
    assert(sizeof(bridge_id_) == 16);
    set_right128_bit(bridge_id_);
    return true; 
}

bool container_id_t::get_bridge_id(bridge_id_t& bridge_id_) const {
    get_right128_bit(bridge_id_);
    return true;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
