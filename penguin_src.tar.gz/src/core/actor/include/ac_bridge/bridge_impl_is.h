/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#ifndef _BRIDGE_IMPL_IS_H_
#define _BRIDGE_IMPL_IS_H_

#include "bridge_impl_base.h"
#include "is_dapplication.h"
#include "ac_bridge_impl.h"

class bridge_impl_is : public bridge_impl_base
{
public:
    bridge_impl_is(ac_bridge_helper * pHelper, const bridge_id_t& bridge_id)
        : bridge_impl_base(pHelper, bridge_id),
          m_top_req_num(0)
    {
    }

    ~bridge_impl_is()
    {
    }

    virtual void initialize_with_bridge_content(const bridge_content& data)
    {
        std::string strval;
        ac_bridge_impl::pack(data, strval);
        if(!write_bridge_id_content(m_bridge_id, strval))
        {
            LOG_ERROR("write_bridge_id failed.");
            assert(!"write_bridge_id failed.");
        }
    }

    virtual bool trigger(call_id_t call_id, const byte_stream& input)
    {
        //if current connection is for is engine
        UBuffer ubuf((uint8_t *)(&input.data[0]), input.data.size());
        Unpacker unpacker(ubuf);
        DUCData * pDucData = unpacker.getData();
        TInformServer* pInformServerData = dynamic_cast<TInformServer *>(pDucData);
        if (NULL ==  pInformServerData)
            return false;
        
        if( !m_ptrApp || (pInformServerData->gesture.type == Start) )
        {
            LOG_DEBUG("This is default transit access. Just Create application for IS engine.");
            m_call_id = call_id;
            m_ptrApp.reset(new(std::nothrow)
                           DApplication(this, boost::bind(&ac_bridge_helper::ac_bridge_trigger_respond,
                                                          m_pHelper, call_id, _1)));
        }
        m_ptrApp->exec(pInformServerData->gesture);
        return true;
    }

    virtual bool run_impl_response(req_num_t req_num, object_ids& output)
    {
        duke_media_handle_vector handles;

        for(std::size_t i = 0; i < output.ids.size(); ++i)
        {
            handles.push_back(duke_media_handle(output.ids[i].str()));
        }

        std::map<req_num_t, DPath>::iterator it = req_path_map.find(req_num);

        if((it != req_path_map.end()) && m_ptrApp)
        {
            //set widget path
            std::vector<DPath> paths;
            paths.push_back(it->second);

            //execute the event
            is_response_call res_call =
                boost::bind(&ac_bridge_helper::ac_bridge_trigger_respond, m_pHelper, m_call_id, _1);
            DEvent event(res_call, DEvent::None, paths, handles);
            m_ptrApp->exec(event);
        }
        
        return true;        
    }

    bool run_impl_(DPath path, duke_media_handle handle)
    {
        //request ac_bridge execution id
        bridge_id_t bridge_id;
        bridge_execute_impl_flag flag = { true };
        if(!m_pHelper->ac_id_dispenser_request_exe_bridge_id(flag, bridge_id))
        {
            LOG_ERROR("Syn call failed : ac_id_dispenser_request_exe_bridge_id().");
            return false;
        }
        
        req_num_t req_num = generate_req_num();
        req_path_map.insert(std::make_pair(req_num, path));
        nb_id_t id(handle.str());
        if(!m_pHelper->ac_bridge_run_impl(bridge_id, req_num, id))
		{
			LOG_ERROR("Asyn call failed : ac_object_run().");
            return false;
		}
        return true;        
    }

    req_num_t generate_req_num()
    {
        return ++m_top_req_num;        
    }
    
    
private:
    DApplicationPtr m_ptrApp;
    req_num_t m_top_req_num;
    call_id_t m_call_id;
    std::map<req_num_t, DPath> req_path_map;
};


#endif

