/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/

#ifndef __STORAGE_DB_H
#define __STORAGE_DB_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

#include "ac_tool/ac_nb_bdb.h"
#include "ac_tool/nb_stdx_singleton.h"
#include "nb_id.h"

class ac_storage_env_impl : public boost_singleton<ac_storage_env_impl>
{
public:
    nbnv* get_env() const;

private:
    ac_storage_env_impl();

public:
    virtual ~ac_storage_env_impl(void); 
    friend struct boost_singleton<ac_storage_env_impl>;

private:
    nbnv* penv;
};

class ac_storage_db_impl //: public mutex_singleton<ac_storage_db_impl>
{
private:
    typedef std::vector<std::pair<nb_id_t, nb_id_t> > pair_vid;
    typedef std::vector<nb_id_t> key_vid;

public:
    int write(const std::string& strkey, const std::string& value, DbTxn* txn = NULL);
    int read(const std::string& strkey, std::string& value, DbTxn* txn = NULL);
    bool read(pair_vid& output, DbTxn* txn = NULL);
    bool read_handle(std::string& strval, DbTxn* txn);
    int del(const std::string& strkey, DbTxn* txn);
    void run(nbnv* penv, const std::string& storage_id);
    int size(DbTxn* txn = NULL); 
    int truncate(DbTxn* txn = NULL);
    bool get_range(int start, int end, pair_vid& output, DbTxn* txn);
    bool get_all(key_vid& output, DbTxn* txn);
    nbdb* get() const;

    bool commit(DbTxn* txn = NULL);
    bool rollback(DbTxn* txn = NULL);

    ac_storage_db_impl();

public:
    virtual ~ac_storage_db_impl(void); 
    //friend struct mutex_singleton<ac_storage_db_impl>;

private:
    nbdb* pdb;
};


#endif // __STORAGE_DB_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
