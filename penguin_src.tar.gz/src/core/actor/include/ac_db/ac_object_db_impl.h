/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/


#ifndef __AC_OBJECT_DB_IMPL_H
#define __AC_OBJECT_DB_IMPL_H


// Posix header files
#include <sys/stat.h>
#include <netinet/in.h>

// C 89 header files
#include <assert.h>
#include <errno.h>
#include <string.h>

// C++ 98 header files
#include <string>
#include <sstream>
#include <vector>

#include "ac_tool/ac_nb_bdb.h"
#include "ac_tool/nb_stdx_fs.h"
#include "ac_tool/nb_stdx_singleton.h"


class ac_object_db_impl : public boost_singleton<ac_object_db_impl>
{
public:
    int write(const std::string& strkey, const std::string& value, DbTxn* txn, int& flag);
    int write_(const std::string& strkey, const std::string& value);

    int read(const std::string& strkey, std::string& value, int flag = 0);
    int read_(const std::string& strkey, std::string& value);
    bool read_handle(std::string& strval);

    bool commit(int flag);
    bool rollback(int flag);

    int del(const std::string& strkey);

    bool exist(const std::string& strval) const
    {
        return pdb->exists(strval);
    }

private:    
    ac_object_db_impl();

private:
    DbTxn* find_txn(int flag);
    void close_txn();
    int find_index(DbTxn*& txn);

    int checked_write_(const std::string& key, const std::string& val, DbTxn* txn);

public:
    bool begin_txn(DbTxn*& txn);

public:
    virtual ~ac_object_db_impl(void); 
    friend struct boost_singleton<ac_object_db_impl>;

private:
    typedef std::map<int, DbTxn*> object_txn_map_type;
    boost::mutex m_mtx_txn;
    object_txn_map_type m_idtxns, m_alltxns;

    static int count;
private:
    nbnv* penv;
    nbdb* pdb;

#ifndef NDEBUG
private:
    /* for write performance evaluation */
    long nWrites_;
    long keylens_;
    long vallens_;
#endif
};

#endif // __AC_OBJECT_DB_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
