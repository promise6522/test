#ifndef __EXECUTION_IMPL_TIME_H
#define __EXECUTION_IMPL_TIME_H

#include "execution_base.h"
#include "ac_object/obj_impl_time.h"


class func_time : public execution_base
{
public:
    func_time(const nb_id_t& obj_id, 
              const execution_id_t& exe_id, 
                    ac_execution_helper * pHelper)
        : execution_base(obj_id, exe_id, pHelper)
    { 
    }; 
    virtual ~func_time()
    {
    };

private:
	//get (year, month, day, hour, mimute, second, ms, us, ns, ps)
    bool get(nb_id_t& out1, nb_id_t& out2);
    bool show(nb_id_vector& out);
    bool current(nb_id_t& out);
	bool add(const nb_id_t& in1, nb_id_t& out);
	bool sub(const nb_id_t& in1, nb_id_t& out);
    bool sub_time(const nb_id_t& in1, nb_id_t& out);
    

    bool convert(std::string& strval, struct tm* tm1, uint64_t value, bool is_before);
    bool to_string(nb_id_t& out);
    bool set_type(const nb_id_t& type_id);
    bool get_type(nb_id_t& type_id);

    bool get_name(nb_id_t& out);

	
public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return execution_base::obj_run_response(req_num, output);
    }

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output)
    {
        return true; 
    }
    virtual bool get_value_response(req_num_t req_num, 
            content& output)
    {
        return execution_base::get_value_response(req_num, output);
    }

    static bool get_general_time(const nb_id_t& id, time_data_t& my_time);
    static bool set_general_time(nb_id_t& id, const time_data_t& my_time);
    static bool get_detail_time(const time_data_t& my_time, nb_id_vector& out);
    static bool time_add(const time_data_t& value1, const time_data_t& value2, time_data_t& result);
    static bool time_sub(const time_data_t& value1, const time_data_t& value2, time_data_t& result);
};


#endif // __EXECUTION_IMPL_TIME_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
