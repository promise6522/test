#ifndef __EXECUTION_IMPL_MAP_H
#define __EXECUTION_IMPL_MAP_H

#include "execution_base.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_interface_compound.h"

/****************************** user ******************************/
class func_map : public execution_base
{
    static const bool _TYPE_CHECKING = false;

protected:
	map_data_t       m_cData;

    nb_id_t          m_key_if;
    nb_id_t          m_value_if;

    nb_id_vector     m_key_vec;
    nb_id_vector     m_data_vec;
    size_t           m_key_idx;
    size_t           m_data_idx;

public:
    func_map(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);

    virtual ~func_map();

private:
    bool set_type();
    bool get_type();
    bool get();
    bool get_or();
    bool erase();
    bool insert();
    bool replace();
    bool update();
    bool size();
    bool get_all_keys();
    bool has_key();

    bool get_name(nb_id_t& out);
    bool get_interface(nb_id_t& if_id);
    bool get_compound_interface(const nb_builtin_instruction_t& call, const int& flag, const req_num_t& req_num, const nb_id_t& in);

    bool prepare_add_element(const req_num_t& req_num, const nb_builtin_instruction_t& call);

    // response
    bool run_response_for_key(req_num_t& req_num, instruction_pair_t& call_pair, const nb_id_vector& vid);
    bool run_response_for_value(req_num_t& req_num, instruction_pair_t& call_pair, const nb_id_vector& vid);

    bool func_map_respond(node_invocation_response& response);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output);

    bool generate_map(const map_data_t& logic_data);
};


#endif // __OBJ_IMPL_MAP_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
