#ifndef __EXECUTION_IMPL_EXEC_IMPL_H
#define __EXECUTION_IMPL_EXEC_IMPL_H

#include "execution_base.h"
#include "ac_object/obj_impl_exec_impl.h"


class exec_implement : public execution_base
{
private:
    // executable implement
    exec_impl_graph_t               m_exec_imple;
    nb_id_t*                        mp_inputs_output_objects;   // inputs_output table

    // common definition
    int                             m_execution_status;
    int                             m_executed;
    int                             m_exception_type;
    bool                            m_is_over;

public :
    exec_implement(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~exec_implement();

private:
    bool parse_impl_graph();
    bool execute_run();
    void insert_object(int path_index, nb_id_t obj, int& out_node_index);
    void check_node_ok(int out_node_index);
    void check_all_over();

    bool parsing_get_value_response(req_num_t req_num, content& output);
    bool executing_get_value_response(req_num_t req_num, content& output);
    bool parsing_obj_run_response(req_num_t req_num, node_invocation_response& output);
    bool executing_obj_run_response(req_num_t req_num, node_invocation_response& output);

    bool get_name(nb_id_t& out);
    bool set_type(const nb_id_t& type_id) { return true; }
    bool get_type(nb_id_t& type_id) { return true; }

    bool create_corpse_obj(int index);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, content& output);

    virtual bool access_run_response(req_num_t req_num, node_invocation_response& output) { return true; }

    bool transaction_success_response(req_num_t req_num);
    bool transaction_fail_response(req_num_t req_num);

    static void print_implement(const exec_impl_graph_t& tmp_graph);

};


#endif // __EXECUTION_IMPL_EXEC_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
