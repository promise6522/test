#ifndef __EXECUTION_IMPL_ARRAY_H
#define __EXECUTION_IMPL_ARRAY_H

#include "execution_base.h"
#include "ac_object/obj_impl_array.h"

/****************************** user ******************************/
class func_array : public execution_base
{
    static const bool _TYPE_CHECKING = false;

protected:
    array_data_t    m_cData;
    nb_id_t         m_type;
    int             m_compare_cnt;
    bool            m_find;

    obj_message_info<array_data_t> m_req_input;

private:
    bool set_type();
    bool get_type();
    bool get();
    bool get_head();
    bool get_tail();
    bool size();
    bool set();
    bool insert();
    bool add_head();
    bool add_tail();
    bool find();
    bool erase();
    bool reverse();
    bool range();
    bool split();
    bool split_at();
    bool join(nb_id_vector& input);
    bool union_set(nb_id_vector& input);
    bool intersection_set(nb_id_vector& input);
    bool complementary_set(nb_id_vector& input);
    bool inclusion(nb_id_vector& input);

    bool set_interface(const nb_id_t& if_id);
    bool get_interface(nb_id_t& if_id);

    bool get_name(nb_id_t& out);

    // response
    bool prepare_add_element(const req_num_t& req_num, const nb_builtin_instruction_t& call);

    bool func_array_respond(node_invocation_response& response);

private:
    bool check_exist(const nb_id_vector& vobjs, const nb_id_t& element);

public :
    func_array(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
        ac_execution_helper * pHelper);
    virtual ~func_array();

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output);
    virtual bool get_value_response(req_num_t req_num, 
            content& output);

    bool generate_array(const array_data_t& logic_data);
    bool generate_two_arrays(const size_t& pos);
};
#endif // __EXECUTION_IMPL_ARRAY_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
