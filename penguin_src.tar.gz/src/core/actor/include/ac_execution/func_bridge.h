#ifndef __EXECUTION_IMPL_BRIDGE_H
#define __EXECUTION_IMPL_BRIDGE_H

#include "execution_base.h"
#include "ac_object/obj_impl_bridge.h"

class func_bridge : public execution_base
{
    static const bool _TYPE_CHECKING = false;

protected:
    bridge_data_t m_cData;

    nb_id_vector m_sub_ifs;
    transaction_id_t m_child_transaction;

private:
    // already responded or not (due to exception) 
    bool m_exception_responded;

    // number of already-covered interfaces
    size_t m_covered_ifs;
    
    // req_num <====> port_idx mapping
    std::map<req_num_t, int> m_req_port;

    void set_reqnum_port(req_num_t req_num, int port_idx)
    {
        m_req_port[req_num] = port_idx;
    }

    int get_reqnum_port(req_num_t req_num) const
    {
        std::map<req_num_t, int>::const_iterator it;
        it = m_req_port.find(req_num);
        if (it != m_req_port.end())
            return it->second;
        else
            return -1;
    }


public:
    func_bridge(const nb_id_t& obj_id, 
            const content& raw_data,
            const execution_id_t& exe_id, 
            ac_execution_helper * pHelper);
    virtual ~func_bridge();

private:
    bool get_name(nb_id_t& out);
    bool get_descriptor(nb_id_t& descriptor_id);
    bool set_interface(const nb_id_t& if_id);
    bool get_interface(nb_id_t& if_id);

private:
    bool pre_compose();
    bool do_compose();
    bool do_decompose();
    bool do_decl_compound(const nb_id_t& decl_id);

    bool get_interface_do(int port_idx, const nb_id_t& obj_if);

public:
    virtual bool run();
    virtual bool obj_run_response(req_num_t req_num, 
            node_invocation_response& output);

    virtual bool access_run_response(req_num_t req_num, 
            node_invocation_response& output);

    bool get_value_response(req_num_t req_num, 
            content& output);

};


#endif // __EXECUTION_IMPL_BRIDGE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
