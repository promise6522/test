#ifndef __OBJ_IMPL_CORPSE_H
#define __OBJ_IMPL_CORPSE_H

#include "obj_impl_base.h"


struct corpse_data_t
{
    std::string             name;           // name
    nb_id_t                 node_index;     // node index
    container_id_t          container_id;   // container master
    nb_id_t                 implement_id;   // execute implement id
    nb_id_t                 object_id;      // object master
    std::vector<nb_id_t>    inputs;         // other inputs
    nb_id_t                 sub_corpse;     // sub-corpse
    nb_id_t                 reason;         // exception reason

    bool operator== (const corpse_data_t& val){
        return this->node_index == val.node_index &&
                this->implement_id == val.implement_id &&
                this->container_id == val.container_id &&
                this->object_id == val.object_id &&
                std::equal(this->inputs.begin(), this->inputs.end(), val.inputs.begin()) &&
                this->sub_corpse == val.sub_corpse &&
                this->reason == val.reason;
    }
};

class obj_impl_corpse : public object_implementation_base 
{
protected:
    corpse_data_t  m_cData;

public :
    obj_impl_corpse();
    virtual ~obj_impl_corpse();

    obj_impl_corpse(const nb_id_t& obj_id, const content& raw_data, ac_object_helper* pHelper);

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);

    virtual bool get_value(content& raw_data);
    virtual bool set_value(const content& raw_data);

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool pack(const corpse_data_t& logic_data, const nb_id_t& id, content& raw_data);
    static bool unpack(const content& raw_data, nb_id_t& id, corpse_data_t& logic_data);

    virtual bool get_property(const nb_id_t& input, object_ids& output) { return true; }
    virtual bool set_property(const property_info& input) { return true; }

    virtual bool get_value_response(req_num_t req_num, content& output) { return true; }
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output) { return true; }

};

#endif // __OBJ_IMPL_CORPSE_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
