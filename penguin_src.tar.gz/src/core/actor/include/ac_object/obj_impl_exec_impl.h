#ifndef __OBJ_IMPL_EXEC_IMPL_H
#define __OBJ_IMPL_EXEC_IMPL_H

#include "obj_impl_base.h"

/*
 * node_path_t : key structure of 'lines' in a graph
 */
struct node_path_t
{
    int in_node;
    int in_port;
    /* 
    IF the path is from input :
    in_node = -1 
    in_port = port num of the input;

    IF the path is from a 'constant' :
    in_node = -2
    in_port = index of the constants-table(see below)

    IF the path is from a 'node' :
    in_node = index of the nodes-table(see below)
    in_port = port num of the node's output 
    */

    int out_node;
    int out_port;
    /*
    IF the path is to a node :
    out_node = index of the nodes-table(see below)
    out_port = port num of the node's input

    IF the path is to output :
    out_node = -3
    out_port = port num of the output
    */

    bool operator== (const node_path_t& val){
        return this->in_node == val.in_node &&
                this->in_port == val.in_port &&
                this->out_node == val.out_node &&
                this->out_port == val.out_port;
    }
};

struct out_port_path_idx_t
{
    std::vector<int> path_idxs; /* a list of the node's outpaths, index of the paths-table */

    bool operator== (const out_port_path_idx_t& val){
        return this->path_idxs.size() == val.path_idxs.size() &&
               std::equal(this->path_idxs.begin(), this->path_idxs.end(), val.path_idxs.begin());
    }
};

struct exe_impl_node_t
{
    int   m_start_position;
    int   m_size;
    int   m_confirm_size;
};

/*
 * exec_impl_graph_t : the implementation-graph's key structure
 */
struct exec_impl_graph_t
{
    std::string             name;               // implementation's name set by users when created
    nb_id_t                 visualInformation;
    nb_id_t                 master;             // master of the implementation
    nb_id_t                 external_decl;      // the implementation's coresponding declaration 
    nb_exception_type_t     handlesException;   // the way to handle exception

    nb_id_vector                        constants;  // constants table
    nb_id_vector                        nodes;      // nodes table
    std::vector<int>                    inNodeTimeNum;
    std::vector<node_path_t>            paths;      // path table
    std::vector<out_port_path_idx_t>    out_paths;  // all node's out path info
    std::map<int, nb_id_t>              cut_info;   // cut info

    int                     out_port_size;      // number of out_ports
    int                     m_ss_length;
    exe_impl_node_t*        mp_start_size;      // start_size table
    int                     m_total_size;
    int                     m_io_obj_lenth;

    exec_impl_graph_t() : m_ss_length(0), mp_start_size(0), m_total_size(0), m_io_obj_lenth(0) { }
    ~exec_impl_graph_t()
    {
        if (mp_start_size)
            delete mp_start_size;
    }

    bool operator== (const exec_impl_graph_t& val){
        return this->name == val.name &&
                this->visualInformation == val.visualInformation && 
                this->out_port_size == val.out_port_size &&
                this->master == val.master &&
                this->external_decl == val.external_decl &&
                this->handlesException == val.handlesException &&
                this->constants.size() == val.constants.size() &&
                this->nodes.size() == val.nodes.size() &&
                this->paths.size() == val.paths.size() &&
                this->out_paths.size() == val.out_paths.size() &&
                std::equal(this->constants.begin(), this->constants.end(), val.constants.begin()) &&
                std::equal(this->nodes.begin(), this->nodes.end(), val.nodes.begin()) &&
                std::equal(this->paths.begin(), this->paths.end(), val.paths.begin()) &&
                std::equal(this->out_paths.begin(), this->out_paths.end(), val.out_paths.begin()) &&
                this->m_ss_length == val.m_ss_length &&
                !memcmp(this->mp_start_size, val.mp_start_size, m_ss_length*sizeof(exe_impl_node_t)) &&
                this->m_io_obj_lenth == val.m_io_obj_lenth &&
                this->m_total_size == val.m_total_size;
    }
};

class obj_impl_exec_impl : public object_implementation_base
{
protected:
    exec_impl_graph_t m_cData;

public:
    obj_impl_exec_impl(); 
    obj_impl_exec_impl(const nb_id_t& obj_id, const content& raw_data, ac_object_helper * pHelper);
    virtual ~obj_impl_exec_impl();

public:
    virtual bool run(call_id_t call_id, const node_invocation_request& input);
    virtual bool get_value(content& data);
    virtual bool set_value(const content& data);

    virtual bool get_property(const nb_id_t& input, object_ids& output) { return true; }
    virtual bool set_property(const property_info& input) { return true; }

    bool pack(content& raw_data);
    bool unpack(const content& raw_data);

    static bool json_pack(const exec_impl_graph_t& logic_data, const nb_id_t& id, content& raw_data);
    static bool json_unpack(const content& raw_data, nb_id_t& id, exec_impl_graph_t& logic_data);

    static bool pack(const exec_impl_graph_t& logic_data, const nb_id_t& id, content& raw_data);
    static bool unpack(const content& raw_data, nb_id_t& id, exec_impl_graph_t& logic_data);

    virtual bool get_value_response(req_num_t req_num, content& output) { return true; }
    virtual bool obj_run_response(req_num_t req_num, node_invocation_response& output) { return true; }
};

#endif // __AC_OBJ_IMPL_EXEC_IMPL_H

// vim:set tabstop=4 shiftwidth=4 expandtab:
