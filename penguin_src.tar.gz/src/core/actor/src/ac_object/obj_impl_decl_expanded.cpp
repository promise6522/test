/**************************************************************************
**
**  Copyright 2011 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_decl_expanded.h"

obj_impl_decl_expanded::obj_impl_decl_expanded(
        const nb_id_t& obj_id,
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_decl_expanded());
    set_value(raw_data);
} 

obj_impl_decl_expanded::~obj_impl_decl_expanded()
{
} 

bool obj_impl_decl_expanded::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_decl_expanded::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_decl_expanded::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_decl_expanded::pack(const decl_expanded_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);    
    packer.pack(logic_data.origin_decl_id);
    packer.pack(logic_data.expanded_ifs);
    
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;

    return true;
}

bool obj_impl_decl_expanded::unpack(const content& raw_data, 
	nb_id_t& id,
	decl_expanded_data_t& logic_data)
{
    id = raw_data.object_id;
    data_unpacker unpack(raw_data);

    // unpack name
    logic_data.name = unpack.unpack_string(0);
    // unpack decl_origin_id
    logic_data.origin_decl_id = unpack.unpack_id(0);
    // unpack expanded_ifs 
    int nb_size = raw_data.id_value.ids.size()-1;
    for(int i=0; i < nb_size; ++i)
    {
        logic_data.expanded_ifs.push_back(unpack.unpack_id(i+1));
    }

    return true;        
}

/* obseleted */
bool obj_impl_decl_expanded::json_pack(const decl_expanded_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    assert(!"json_pack is obseleted!");
    return true;
}

bool obj_impl_decl_expanded::unpack(const content& raw_data)
{
    nb_id_t id;    
    unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);    
    return true;
}

/* obseleted */
bool obj_impl_decl_expanded::json_unpack(const content& raw_data, 
	nb_id_t& id,
	decl_expanded_data_t& logic_data)
{
    assert(!"json_unpack is obseleted!");
    return true;
}

bool obj_impl_decl_expanded::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_decl_expanded::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
