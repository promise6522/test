/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_decl_compound.h"

// stdx header files
#include "stdx_json.h"

obj_impl_user::obj_impl_user(const nb_id_t& obj_id, 
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{ 
    assert(obj_id.is_user_object());
    set_value(raw_data);
    //set_builtin_instructions();
} 

obj_impl_user::~obj_impl_user()
{
}

bool obj_impl_user::set_builtin_instructions()
{
    time_t tm;    
    time(&tm);
    req_num_t req_num = req_num_t(tm, true);
    object_get_value_async(m_cData.descriptor, req_num);

    return true; 
}

bool obj_impl_user::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_user::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_user::pack(const user_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    packer.pack(logic_data.water_mark);

    packer.pack(logic_data.visualInformation);
    packer.pack(logic_data.descriptor);
    packer.pack(logic_data.interface);
    packer.pack(logic_data.subobjs);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_user::unpack(const content& raw_data, nb_id_t& id, user_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data.name = unpack.unpack_string(0);
    logic_data.water_mark = unpack.unpack_string(1);
    
    logic_data.visualInformation = unpack.unpack_id(0);
    logic_data.descriptor = unpack.unpack_id(1);
    logic_data.interface = unpack.unpack_id(2);
    int subobj_size = raw_data.id_value.ids.size() - 3;
    for(int i=0; i < subobj_size; ++i)
    {
        logic_data.subobjs.push_back(unpack.unpack_id(i + 3));
    }
    return true;
}

bool obj_impl_user::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_user::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, m_cData);
    assert(id == m_obj_id);

    return true;
}

bool obj_impl_user::json_pack(const user_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    pObj->insert("descriptor", new stdx::json_string(logic_data.descriptor.str()));
    pObj->insert("interface", new stdx::json_string(logic_data.interface.str()));
    pObj->insert("water_mark", new stdx::json_string(logic_data.water_mark));

    // pack nb_id_vector subobjs
    stdx::json_array* pArr = new(std::nothrow) stdx::json_array();
    assert(pArr);
    std::vector<nb_id_t>::const_iterator it = logic_data.subobjs.begin();
    while(it != logic_data.subobjs.end())
    {
        pArr->push_back(new stdx::json_string(it->str()));
        ++it;
    }
    pObj->insert("subobjs", pArr);
    // end subobjs

    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
    // save all internal ids
    raw_data.id_value.ids.clear();
    raw_data.id_value.ids.assign(logic_data.subobjs.begin(), logic_data.subobjs.end());
    raw_data.id_value.ids.push_back(logic_data.descriptor);
    raw_data.id_value.ids.push_back(logic_data.interface);
    // save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);  
    return true;
}

bool obj_impl_user::json_unpack(const content& raw_data, nb_id_t& id, user_data_t& logic_data)
{
    id = raw_data.object_id;
    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    logic_data.name = pObj->find("name")->get_string();
    logic_data.descriptor.str( pObj->find("descriptor")->get_string() );
    logic_data.interface.str( pObj->find("interface")->get_string() );
    logic_data.water_mark = pObj->find("water_mark")->get_string();
    // unpack nb_id_vector subobjs
    logic_data.subobjs.clear();
    stdx::json_array* pArr = dynamic_cast<stdx::json_array*>(pObj->find("subobjs"));
    assert(pArr);
    for(int i=0; i < pArr->size(); ++i)
    {
        stdx::json_node* pNode = pArr->at(i);
        logic_data.subobjs.push_back(nb_id_t(pNode->get_string()));
    }
    // end subobjs

    return true;
}

bool obj_impl_user::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_user::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

bool obj_impl_user::get_value_response(req_num_t req_num, content& output)
{
    node_invocation_response response;

//    response.child_transaction = m_param.transaction_id;
//
//    host_committer_id_t hc_id;
//    m_obj_id.get_hostcommitterid(hc_id);
//
//    descriptor_data_t dp_data;
//    nb_id_t id;
//    obj_impl_descriptor::unpack(output, id, dp_data);
//    assert(id == m_cData.descriptor);
//
//    nb_id_t comp_id, dcomp_id;
//
//    //compose
//    decl_compound_data_t comp_data;
//    comp_data.name = "user_compose";
//
//    ////in ports
//    iport_t cip_data;
//    cip_data.interface = m_cData.interface;
//    comp_data.iports.push_back(cip_data);
//    for (size_t i = 0; i < dp_data.subobj_interfaces.size(); ++i)
//    {
//        iport_t ip_data;
//        ip_data.interface = dp_data.subobj_interfaces[i];
//        comp_data.iports.push_back(ip_data);
//    }
//
//    ////output ports
//    oport_t cop_data;
//    cop_data.interface = m_cData.interface;
//    comp_data.oports.push_back(cop_data);
//
//    request_nb_id_info comp_info;
//    comp_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
//    comp_info.committer_id = hc_id;
//    obj_impl_decl_compound::pack(comp_data, nb_id_t(), comp_info.raw_data);
//    request_nb_id(hc_id, comp_info, comp_id);
//
//    //decompose
//    decl_compound_data_t dcomp_data;
//    dcomp_data.name = "user_decompose";
//
//    ////in ports
//    iport_t dip_data;
//    dip_data.interface = m_cData.interface;
//    dcomp_data.iports.push_back(dip_data);
//
//    ////output ports
//    for (size_t i = 0; i < dp_data.subobj_interfaces.size(); ++i)
//    {
//        oport_t op_data;
//        op_data.interface = dp_data.subobj_interfaces[i];
//        dcomp_data.oports.push_back(op_data);
//    }
//
//    request_nb_id_info dcomp_info;
//    dcomp_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
//    dcomp_info.committer_id = hc_id;
//    obj_impl_decl_compound::pack(dcomp_data, nb_id_t(), dcomp_info.raw_data);
//    request_nb_id(hc_id, dcomp_info, dcomp_id);
//
//    // add decls: compose, decompose
//    property_info pinfo;
//    
//    pinfo.declaration = nb_id_t(NB_FUNC_INTERFACE_SET_BUILTIN_INS);
//    pinfo.objects.push_back(comp_id);
//    pinfo.objects.push_back(dcomp_id);
//
//    object_set_property(m_cData.interface, pinfo);
//
//    initialization_respond();
//
    return true;
}

bool obj_impl_user::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    assert(output.success);
    return true;
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
