/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_bridge_interface.h"
#include"stdx_json.h"
#include<boost/shared_ptr.hpp>

obj_impl_bridge_interface::obj_impl_bridge_interface() 
{
} 

obj_impl_bridge_interface::obj_impl_bridge_interface(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_bridge_interface());
    set_value(raw_data);
} 

obj_impl_bridge_interface::~obj_impl_bridge_interface()
{
} 

bool obj_impl_bridge_interface::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_bridge_interface::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_bridge_interface::pack(content& raw_data)
{
    obj_impl_bridge_interface::pack(this->m_cData, this->m_obj_id, raw_data);
    return true;
}

bool obj_impl_bridge_interface::pack(const bridge_interface_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    nb_id_t sizeType1( NBID_TYPE_OBJECT_INT );
    int subif_size = logic_data.sub_interfaces.size();
    sizeType1.set_value( subif_size );
    packer.pack( sizeType1 );
    packer.pack( logic_data.sub_interfaces );
    
    nb_id_t sizeType2( NBID_TYPE_OBJECT_INT );
    int decl_size = logic_data.decls.size();
    sizeType2.set_value( decl_size );
    packer.pack( sizeType2 );
    packer.pack( logic_data.decls );

    packer.pack( logic_data.bf_id.str() );
    packer.pack( logic_data.data_index ); 
    packer.pack( logic_data.external_name );
    packer.pack( logic_data.sub_names );
    
    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;       
}

bool obj_impl_bridge_interface::unpack(const content& raw_data, nb_id_t& id, bridge_interface_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int sizeType1 = 0;
    unpack.unpack_id(0).get_value( sizeType1 ); 
    for(int i=0; i<sizeType1; ++i)
    {
        logic_data.sub_interfaces.push_back(unpack.unpack_id(i+1));    
    }

    int sizeType2 = 0;
    unpack.unpack_id(sizeType1+1).get_value( sizeType2 ); 
    for(int i=0; i<sizeType2; ++i)
    {
        logic_data.decls.push_back(unpack.unpack_id(i+2+sizeType1));
    }

    logic_data.bf_id.str(unpack.unpack_string(0));
    logic_data.data_index = unpack.unpack_int(1);
    logic_data.external_name = unpack.unpack_string(2);
    int obj_size = raw_data.id_value.values.size() - 3;
    for( int i=0; i < obj_size; ++i )
    {
        logic_data.sub_names.push_back( unpack.unpack_string(i + 3) );
    }

    return true;       
}

bool obj_impl_bridge_interface::json_pack(const bridge_interface_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    boost::shared_ptr<stdx::json_object> pObj(new (std::nothrow) stdx::json_object());
    
    stdx::json_string* pStr = new stdx::json_string(logic_data.bf_id.str());
    assert(pStr);
    pObj->insert("bridge_factory_id", pStr);
    
    stdx::json_int* pInt = new stdx::json_int(logic_data.data_index);
    assert(pInt);
    pObj->insert("data_index", pInt);
    
    pStr = new stdx::json_string(logic_data.external_name);
    assert(pStr);
    pObj->insert("external_name", pStr);
    
    stdx::json_array* pVec = new stdx::json_array();
    assert(pVec);
    nb_id_vector::const_iterator it = logic_data.sub_interfaces.begin();
    while(it != logic_data.sub_interfaces.end())
    {
        pStr = NULL;
        pStr = new stdx::json_string(it->str());
        assert(pStr);
        pVec->push_back(pStr);
        ++it;
    }
    pObj->insert("sub_interfaces", pVec);
    
    pVec = new stdx::json_array();
    std::vector<std::string>::const_iterator itStr = logic_data.sub_names.begin();
    while(itStr != logic_data.sub_names.end())
    {
        pStr = NULL;
        pStr = new stdx::json_string( *itStr);
        assert(pStr);
        pVec->push_back(pStr);
        ++itStr;
    }
    pObj->insert("sub_names", pVec);
    
    pVec = new stdx::json_array();
    nb_id_vector::const_iterator declit = logic_data.decls.begin();
    while(declit != logic_data.decls.end())
    {
        pStr = NULL;
        pStr = new stdx::json_string(declit->str());
        assert(pStr);
        pVec->push_back(pStr);
        ++declit;
    }
    pObj->insert("decls", pVec);
    
    std::string strval = pObj->to_json_string();
    
    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();
    raw_data.object_id = id;
    
    raw_data.id_value.ids.assign(logic_data.sub_interfaces.begin(),logic_data.sub_interfaces.end());
    std::vector<char> vec(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vec);
    
    return true;
}

bool obj_impl_bridge_interface::unpack(const content& raw_data)
{
    nb_id_t id;    
    obj_impl_bridge_interface::unpack(raw_data, id, this->m_cData);
    assert(id == m_obj_id);    
    return true;
}

bool obj_impl_bridge_interface::json_unpack(const content& raw_data, nb_id_t& id, bridge_interface_data_t& logic_data)
{
    id = raw_data.object_id;
    std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    
    boost::shared_ptr<stdx::json_object> pObj(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    
    stdx::json_string* pStr = dynamic_cast<stdx::json_string*>(pObj->find("bridge_factory_id"));
    assert(pStr);
    logic_data.bf_id.str(pStr->get_string());
    
    //pInt = NULL;
    stdx::json_int* pInt = dynamic_cast<stdx::json_int*>(pObj->find("data_index"));
    assert(pInt);
    logic_data.data_index = pInt->get_int();
    
    pStr = dynamic_cast<stdx::json_string*>(pObj->find("external_name"));
    assert(pStr);
    logic_data.external_name = pStr->get_string();
    
    stdx::json_array* pVec = dynamic_cast<stdx::json_array*>(pObj->find("sub_interfaces"));
    assert(pVec);
    for(int i=0; i<pVec->size(); ++i)
    {
        nb_id_t idTem(pVec->at(i)->get_string());
        logic_data.sub_interfaces.push_back(idTem);
    }
    
    pVec = NULL;
    pVec = dynamic_cast<stdx::json_array*>(pObj->find("sub_names"));
    assert(pVec);
    for(int i=0; i<pVec->size(); ++i)
    {
        logic_data.sub_names.push_back(pVec->at(i)->get_string());
    }
    
    pVec = dynamic_cast<stdx::json_array*>(pObj->find("decls"));
    assert(pVec);
    for(int i=0; i<pVec->size(); ++i)
    {
        nb_id_t idTem(pVec->at(i)->get_string());
        logic_data.decls.push_back(idTem);
    }
    
    return true;
}

bool obj_impl_bridge_interface::set_property(const property_info& input)
{
    LOG_DEBUG("*** obj_impl_bridge_interface::set_property()");

    switch(input.declaration.get_func_type())
    {
	case NB_FUNC_INTERFACE_SET_BUILTIN_INS:
	    m_builtin_ins = input.objects;
	    break;
	default:
	    break;
    }

    return true;

}

bool obj_impl_bridge_interface::get_property(const nb_id_t& declaration, object_ids& objects)
{
    LOG_DEBUG("*** obj_impl_bridge_interface::get_property()");

    switch(declaration.get_func_type())
    {
	case NB_FUNC_INTERFACE_GET_BUILTIN_INS:
	    objects.ids = m_builtin_ins;
	    break;
	default:
	    break;
    }

    return true;

}

bool obj_impl_bridge_interface::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_bridge_interface::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
