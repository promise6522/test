/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_container_def.h"
#include "stdx_json.h"
#include "nb_id.h"
#include <boost/shared_ptr.hpp>

typedef boost::shared_ptr<stdx::json_object>  json_objcet_ptr;
//typedef boost::shared_ptr<stdx::json_array>   json_array_ptr;
//typedef boost::shared_ptr<stdx::json_string>  json_string_ptr;
//typedef boost::shared_ptr<stdx::json_int>     json_int_ptr;
//typedef boost::shared_ptr<stdx::json_boolean> json_boolean_ptr;

obj_impl_container_def::obj_impl_container_def()
{

}

obj_impl_container_def::obj_impl_container_def(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_container_defination());
    set_value(raw_data);
}

obj_impl_container_def::~obj_impl_container_def()
{

}

bool obj_impl_container_def::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_container_def::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_container_def::pack(const cont_def_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    data_packer packer; 

    packer.pack(logic_data.name);
    packer.pack(logic_data.visualInformation);
    int storages_size = logic_data.storages.size();
    packer.pack(storages_size);
    for(int i=0; i < storages_size; ++i)
    {
        packer.pack(logic_data.storages[i].name);
        packer.pack(logic_data.storages[i].type);
        packer.pack(logic_data.storages[i].interface);
    }

    int anchors_size = logic_data.anchors.size(); 
    packer.pack(anchors_size);
    for(int i=0; i < anchors_size; ++i)
    {
        packer.pack(logic_data.anchors[i].name);
        packer.pack(logic_data.anchors[i].registed);

        int funcs_size = logic_data.anchors[i].funcs.size();
        nb_id_t temp( NBID_TYPE_OBJECT_INT ); 
        temp.set_value(funcs_size);
        packer.pack(temp);
        for(int j=0; j < funcs_size; ++j)
        {
            packer.pack(logic_data.anchors[i].funcs[j].declaration_id);
            packer.pack(logic_data.anchors[i].funcs[j].implementation_id);
        }
        packer.pack(logic_data.anchors[i].interface);
    }  

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_container_def::unpack(const content& raw_data, 
	nb_id_t& id,
	cont_def_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int nb_index = -1;
    int str_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);   
    logic_data.visualInformation = unpack.unpack_id(++nb_index);

    int storages_size = unpack.unpack_int(++str_index); 
    for(int i=0; i < storages_size; ++i)
    {
        storage_info_t storage_data;
        storage_data.name = unpack.unpack_string(++str_index);
        storage_data.type = static_cast<nbid_type_t>( unpack.unpack_int(++str_index) );
        storage_data.interface = unpack.unpack_id(++nb_index);
        logic_data.storages.push_back(storage_data);
    }

    int anchors_size = unpack.unpack_int(++str_index);
    for(int i=0; i < anchors_size; ++i)
    {
        anchor_info_t anchor_data;
        anchor_data.name = unpack.unpack_string(++str_index);
        anchor_data.registed = unpack.unpack_bool(++str_index);

        int funcs_size = 0;
        unpack.unpack_id(++nb_index).get_value(funcs_size);
        for(int j=0; j < funcs_size; ++j)
        {
           func_pair_t func_data; 
           func_data.declaration_id = unpack.unpack_id(++nb_index);
           func_data.implementation_id = unpack.unpack_id(++nb_index);
           anchor_data.funcs.push_back(func_data);
        }
        anchor_data.interface = unpack.unpack_id(++nb_index);
        logic_data.anchors.push_back(anchor_data);
    }

    return true;
}

bool obj_impl_container_def::pack(content& raw_data)
{
    pack(this->m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_container_def::json_pack(const cont_def_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    json_objcet_ptr pObj(new (std::nothrow) stdx::json_object());
    
    stdx::json_string* pStr = new stdx::json_string(logic_data.name);
    assert(pStr);
    pObj->insert("name", pStr);
    
    stdx::json_array* pArr = new stdx::json_array();
    assert(pArr);
    std::vector<storage_info_t>::const_iterator it = logic_data.storages.begin();
    stdx::json_object* pStInfo = NULL;
    while(it != logic_data.storages.end())
    {
        pStInfo = NULL;
        pStInfo = new stdx::json_object();
        assert(pStInfo);
        pStInfo->insert("name", new stdx::json_string(it->name));
        pStInfo->insert("type", new stdx::json_int(it->type));
        pStInfo->insert("interface", new stdx::json_string(it->interface.str()));
        pArr->push_back(pStInfo);
        ++it;
    }
    pObj->insert("storages", pArr);
    
    stdx::json_array* pAnchor = new stdx::json_array();
    std::vector<anchor_info_t>::const_iterator itInfo = logic_data.anchors.begin();
    stdx::json_object* pInfo = NULL;
    while(itInfo != logic_data.anchors.end())
    {
        pInfo = NULL;
        pInfo = new stdx::json_object();
        assert(pInfo);
        pInfo->insert("name", new stdx::json_string(itInfo->name));
        pInfo->insert("registed", new stdx::json_boolean(itInfo->registed));
        
        stdx::json_array* pFvec = new stdx::json_array();
        assert(pFvec);
        stdx::json_object* pPair = NULL;
        func_vector::const_iterator itFun = itInfo->funcs.begin();
        while(itFun != itInfo->funcs.end())
        {
            pPair = NULL;
            pPair = new stdx::json_object();
            assert(pPair);
            pPair->insert("declaration_id", new stdx::json_string(itFun->declaration_id.str()));
            pPair->insert("implementation_id", new stdx::json_string(itFun->implementation_id.str()));
            pFvec->push_back(pPair);
            ++itFun;
        }
        pInfo->insert("funcs", pFvec);
        
        pInfo->insert("interface", new stdx::json_string(itInfo->interface.str()));
        
        pAnchor->push_back(pInfo);
        ++itInfo;
    }
    pObj->insert("anchors", pAnchor);
    
    std::string strval = pObj->to_json_string();
    
    raw_data.object_id = id;
    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();
    std::vector<char> vec(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vec);
    return true;
}

bool obj_impl_container_def::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, this->m_cData);
    assert(m_obj_id == id);    
    return true;
}

bool obj_impl_container_def::json_unpack(const content& raw_data, 
	nb_id_t& id,
	cont_def_data_t& logic_data)
{
    id = raw_data.object_id;

    assert(raw_data.id_value.values[0].size());
    std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    
    boost::shared_ptr<stdx::json_object> pObj(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    /*-----------------stdx::string name----------------*/
    stdx::json_string* pInt = dynamic_cast<stdx::json_string*>(pObj->find("name"));
    assert(pInt);
    logic_data.name = pInt->get_string();
    
    /*-----std::vector<nb_type_t> storages------------*/
    stdx::json_array* pStorages = dynamic_cast<stdx::json_array*>(pObj->find("storages"));
    assert(pStorages);
    stdx::json_object* pStInfo = NULL;
    for(int i=0; i<pStorages->size(); ++i)
    {
        storage_info_t aTem;
        pStInfo = dynamic_cast<stdx::json_object*>(pStorages->at(i));
        assert(pStInfo);
        //std::string name
        aTem.name = pStInfo->find("name")->get_string();
        aTem.type = static_cast<nb_type_t>(pStInfo->find("type")->get_int());
        aTem.interface.str(pStInfo->find("interface")->get_string());
        logic_data.storages.push_back(aTem);
    }
    /*-----std::vector<anchor_info_t> anchors---------*/
    
    stdx::json_array* pAnchor = dynamic_cast<stdx::json_array*>(pObj->find("anchors"));
    assert(pAnchor);
    stdx::json_object* pInfo = NULL;
    for(int i=0; i<pAnchor->size(); ++i)
    {
        anchor_info_t aTem;
        pInfo = dynamic_cast<stdx::json_object*>(pAnchor->at(i));
        assert(pInfo);
        //std::string name
        aTem.name = pInfo->find("name")->get_string();
        //bool registed
        aTem.registed = pInfo->find("registed")->get_boolean();
        //func_vector funcs;
        stdx::json_array* pFuncs = dynamic_cast<stdx::json_array*>(pInfo->find("funcs"));
        assert(pFuncs);        
        stdx::json_object* pPair = NULL;
        //std::cout << pFuncs->size() << std::endl;
        for(int j=0; j<pFuncs->size(); ++j)
        {
            pPair = NULL;
            pPair = dynamic_cast<stdx::json_object*>(pFuncs->at(j));
            assert(pPair);
            func_pair_t fPair;
            fPair.declaration_id.str(pPair->find("declaration_id")->get_string());
            fPair.implementation_id.str(pPair->find("implementation_id")->get_string());
            aTem.funcs.push_back(fPair);
        }
        //nv_id_t interface
        aTem.interface.str(pInfo->find("interface")->get_string());
        logic_data.anchors.push_back(aTem);
    }
    
    return true;
}

bool obj_impl_container_def::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_container_def::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
