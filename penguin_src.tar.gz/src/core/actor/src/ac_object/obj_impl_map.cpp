/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_object/obj_impl_map.h"

// stdx header files
#include "stdx_json.h"

obj_impl_map::obj_impl_map(const nb_id_t& obj_id, 
		const content& raw_data, 
		ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{ 
	assert(obj_id.is_object_map());
	set_value(raw_data);
} 

obj_impl_map::~obj_impl_map()
{
}

bool obj_impl_map::set_value(const content& data)
{
	unpack(data);
	return true;
}

bool obj_impl_map::get_value(content& data)
{
	pack(data);
	return true;
}

bool obj_impl_map::pack(content& raw_data)
{
	pack(m_cData, m_obj_id, raw_data);
	return true;
}

bool obj_impl_map::unpack(const content& raw_data)
{
	nb_id_t id;
	unpack(raw_data, id, m_cData);
	assert(id == m_obj_id);

	return true;
}

bool obj_impl_map::pack(const map_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
	data_packer packer;

    packer.pack(logic_data.name);
    //packer.pack(logic_data.interface);
	packer.pack(logic_data.type);

    nb_id_t nb_map(NBID_TYPE_OBJECT_INT);
    int map_size = logic_data.data.size();
    nb_map.set_value(map_size);
    packer.pack(nb_map);
    std::map<nb_id_t, nb_id_t>::const_iterator it = logic_data.data.begin();
	while(it != logic_data.data.end())
	{
		packer.pack(it->first);
		packer.pack(it->second);
		++it;
	}

    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
	return true;
}

bool obj_impl_map::unpack(const content& raw_data, nb_id_t& id, map_data_t& logic_data)
{
    id = raw_data.object_id;
    data_unpacker unpack(raw_data);

    logic_data.name = unpack.unpack_string(0);
	int nb_index = -1;
	//logic_data.interface = unpack.unpack_id(++nb_index);
	logic_data.type = unpack.unpack_id(++nb_index);

	int map_size = 0;
	unpack.unpack_id(++nb_index).get_value(map_size);
	for(int i=0; i < map_size; ++i)
	{
		nb_id_t first_value(unpack.unpack_id(++nb_index));
		nb_id_t second_value(unpack.unpack_id(++nb_index));
		logic_data.data.insert(std::make_pair(first_value, second_value));
			
	}
	return true;
}

bool obj_impl_map::json_pack(const map_data_t& logic_data, 
		const nb_id_t& id,
		content& raw_data)
{
	boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
	pObj->insert("type", new stdx::json_string(logic_data.type.str()));

	// pack multimap<nb_id_t, nb_id_t> map
	stdx::json_array* pArr = new(std::nothrow) stdx::json_array();
	assert(pArr);
	std::multimap<nb_id_t, nb_id_t>::const_iterator it = logic_data.data.begin();
	while(it != logic_data.data.end())
	{
		stdx::json_object* pSubObj = new(std::nothrow) stdx::json_object();
		assert(pSubObj);
		pSubObj->insert("first", new stdx::json_string(it->first.str()));
		pSubObj->insert("second", new stdx::json_string(it->second.str()));
		pArr->push_back(pSubObj);
		++it;
	}
	pObj->insert("data", pArr);
	// end map

	std::string strval = pObj->to_json_string();

	raw_data.object_id = id;
	// save all internal ids
	raw_data.id_value.ids.clear();
    //raw_data.id_value.ids.push_back(logic_data.interface);
	raw_data.id_value.ids.push_back(logic_data.type);
	std::multimap<nb_id_t, nb_id_t>::const_iterator itMulmap = logic_data.data.begin();
	while(it != logic_data.data.end())
	{
		raw_data.id_value.ids.push_back(it->first);
		raw_data.id_value.ids.push_back(it->second);
	}
	// save packed str
	raw_data.id_value.values.clear();
	std::vector<char> vchar(strval.begin(), strval.end());
	raw_data.id_value.values.push_back(vchar);
	return true;
}

bool obj_impl_map::json_unpack(const content& raw_data, 
		nb_id_t& id,
		map_data_t& logic_data)
{
	id = raw_data.object_id;

	assert(!raw_data.id_value.values.empty());
	std::vector<char> vchar = raw_data.id_value.values[0];
	std::string strval(vchar.begin(), vchar.end());

	boost::shared_ptr<stdx::json_object> pObj;
	pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
	assert(pObj); 

    //logic_data.interface.str(pObj->find("interface")->get_string());
	logic_data.type.str(pObj->find("type")->get_string());

	// unpack multimap<nb_id_t,nb_id_t> map
	logic_data.data.clear();
	stdx::json_array* pArr = dynamic_cast<stdx::json_array*>(pObj->find("data"));
	assert(pArr);
	for(int i=0; i < pArr->size(); ++i)
	{
		stdx::json_object* pSubObj = dynamic_cast<stdx::json_object*>(pArr->at(i));
		assert(pSubObj);
		std::pair<nb_id_t,nb_id_t> nb_id_pair;
		nb_id_pair.first.str(pSubObj->find("first")->get_string());
		nb_id_pair.second.str(pSubObj->find("second")->get_string());
		logic_data.data.insert(nb_id_pair);
	}
	// end map

	return true;
}

bool obj_impl_map::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_map::run()");

	//request new execution actor
	request_execution_id_info exec_info;
	exec_info.committer_id = input.host_committer_id;
	exec_info.obj_info.object_id = m_obj_id;
	pack(exec_info.obj_info.obj_raw_data);

	return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
