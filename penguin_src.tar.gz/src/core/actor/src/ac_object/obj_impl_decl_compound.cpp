/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
// stdx header files
#include "stdx_json.h"

#include "ac_object/obj_impl_decl_compound.h"

obj_impl_decl_compound::obj_impl_decl_compound(
        const nb_id_t& obj_id,
        const content& raw_data, 
        ac_object_helper * pHelper)
    : object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_decl_compound());
    set_value(raw_data);
} 

obj_impl_decl_compound::~obj_impl_decl_compound()
{
} 

bool obj_impl_decl_compound::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_decl_compound::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_decl_compound::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);
    return true;
}

bool obj_impl_decl_compound::pack(const decl_compound_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    data_packer packer;
    
    packer.pack(logic_data.name);    
    packer.pack(logic_data.visualInformation);

    int iports_size = logic_data.iports.size();
    packer.pack(iports_size);
    for(int i=0; i < iports_size; ++i)
    {
        packer.pack(logic_data.iports[i].name);
        packer.pack(logic_data.iports[i].interface);
        packer.pack(logic_data.iports[i].default_value);
    }    

    int oports_size = logic_data.oports.size();
    packer.pack(oports_size); 
    for(int i=0; i < oports_size; ++i)
    {
        packer.pack(logic_data.oports[i].name);
        packer.pack(logic_data.oports[i].interface);
    }

    int groups_size = logic_data.groups.size();
    packer.pack(groups_size);
    for(int i=0; i < groups_size; ++i)
    {
        packer.pack(logic_data.groups[i].name);
        packer.pack(logic_data.groups[i].min_if);

        int member_size = logic_data.groups[i].members.size();
        packer.pack(member_size);
        for(int j=0; j < member_size; ++j)
        {
            packer.pack(logic_data.groups[i].members[j].is_input);
            packer.pack(logic_data.groups[i].members[j].port_idx);
            packer.pack(logic_data.groups[i].members[j].relay_idx);
        }

        packer.pack(logic_data.groups[i].expanded);
    }

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;

    return true;
}

bool obj_impl_decl_compound::unpack(const content& raw_data, 
	nb_id_t& id,
	decl_compound_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.ids.size()&&raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    int nb_index = -1;
    int str_index = -1;

    logic_data.name = unpack.unpack_string(++str_index);
    logic_data.visualInformation = unpack.unpack_id(++nb_index);

    int iports_size = unpack.unpack_int(++str_index);
    for(int i=0; i < iports_size; ++i)
    {
        iport_t iData;
        iData.name = unpack.unpack_string(++str_index);
        iData.interface = unpack.unpack_id(++nb_index);
        iData.default_value = unpack.unpack_id(++nb_index);
        logic_data.iports.push_back(iData);
    }    

    int oports_size = unpack.unpack_int(++str_index); 
    for(int i=0; i < oports_size; ++i)
    {
        oport_t oData;
        oData.name = unpack.unpack_string(++str_index);
        oData.interface = unpack.unpack_id(++nb_index);
        logic_data.oports.push_back(oData);
    }

    int groups_size = unpack.unpack_int(++str_index);
    for(int i=0; i < groups_size; ++i)
    {
        decl_exp_group group_data;
        group_data.name = unpack.unpack_string(++str_index);
        group_data.min_if = unpack.unpack_id(++nb_index);

        int member_size = unpack.unpack_int(++str_index);
        for(int j=0; j < member_size; ++j)
        {
            decl_exp_idx idx_data;
            idx_data.is_input = unpack.unpack_bool(++str_index);
            idx_data.port_idx = unpack.unpack_int(++str_index);
            idx_data.relay_idx = unpack.unpack_int(++str_index);
            group_data.members.push_back(idx_data);
        }

        group_data.expanded = unpack.unpack_bool(++str_index);
        logic_data.groups.push_back(group_data);
    }

    return true;        
}

bool obj_impl_decl_compound::json_pack(const decl_compound_data_t& logic_data, 
	const nb_id_t& id,
	content& raw_data)
{
    /*struct decl_compound_data_t 
    {
        std::string name;
        std::vector<iport_t> iports; { std::string name; nb_id_t interface; nb_id_t default_value }
        std::vector<oport_t> oports; { std::string name; nb_id_t interface }
        std::vector<decl_exp_group> groups; 
        {
            std::string name; 
            nb_id_t min_if; 
            std::vector<decl_exp_idx> members; { bool is_input; int port_idx; int relay_idx }
            bool expanded;
        }
    };*/    
    boost::shared_ptr<stdx::json_object> pObj(new(std::nothrow) stdx::json_object());
    pObj->insert("name", new stdx::json_string(logic_data.name));
    // pack vector<iport_t> iports
    stdx::json_array* jarr = new stdx::json_array();
    for(std::vector<iport_t>::const_iterator it = logic_data.iports.begin(); it != logic_data.iports.end(); ++it)
    {
        stdx::json_object* obj2 = new stdx::json_object();
        obj2->insert("name", new stdx::json_string(it->name));
        obj2->insert("interface", new stdx::json_string(it->interface.str()));
        obj2->insert("default_value", new stdx::json_string(it->default_value.str()));
        jarr->push_back(obj2);
    }
    pObj->insert("iports", jarr);
    // end iports

    // pack vector<oport_t> oports
    jarr = new stdx::json_array();
    for(std::vector<oport_t>::const_iterator it = logic_data.oports.begin(); it != logic_data.oports.end(); ++it)
    {
        stdx::json_object* obj2 = new stdx::json_object();
        obj2->insert("name", new stdx::json_string(it->name));
        obj2->insert("interface", new stdx::json_string(it->interface.str()));
        jarr->push_back(obj2);
    }
    pObj->insert("oports", jarr);
    // end oports 

    // pack vector<decl_exp_group> groups
    jarr = new stdx::json_array();
    for(std::vector<decl_exp_group>::const_iterator it = logic_data.groups.begin(); it != logic_data.groups.end(); ++it)
    {
        stdx::json_object* obj2 = new stdx::json_object();
        obj2->insert("name", new stdx::json_string(it->name));
        obj2->insert("min_if", new stdx::json_string(it->min_if.str()));
        obj2->insert("expanded", new stdx::json_boolean(it->expanded));
        // pack vector<decl_exp_idx> members
        stdx::json_array* jarr2 = new stdx::json_array();
        for(std::vector<decl_exp_idx>::const_iterator itx = it->members.begin(); itx != it->members.end(); ++itx)
        {
            stdx::json_object* obj3 = new stdx::json_object();
            obj3->insert("is_input", new stdx::json_boolean(itx->is_input));
            obj3->insert("port_idx", new stdx::json_int(itx->port_idx));
            obj3->insert("relay_idx", new stdx::json_int(itx->relay_idx));
            jarr2->push_back(obj3);
        }
        obj2->insert("members", jarr2);
        // end members
        jarr->push_back(obj2);
    }
    pObj->insert("groups", jarr);
    // end groups

    std::string strval = pObj->to_json_string();

    raw_data.object_id = id;
	// save all internal ids
	raw_data.id_value.ids.clear();
	std::vector<iport_t>::const_iterator itIports = logic_data.iports.begin();
	while( itIports != logic_data.iports.end() )
	{
		raw_data.id_value.ids.push_back(itIports->interface);
		raw_data.id_value.ids.push_back(itIports->default_value);
		++itIports;
	}
	std::vector<oport_t>::const_iterator itOports = logic_data.oports.begin();
	while( itOports != logic_data.oports.end() )
	{
		raw_data.id_value.ids.push_back(itOports->interface);
		++itOports;
	}
	std::vector<decl_exp_group>::const_iterator itExpGroups = logic_data.groups.begin();
	while( itExpGroups != logic_data.groups.end() )
	{
		raw_data.id_value.ids.push_back(itExpGroups->min_if);
		++itExpGroups;
	}
	// save packed str
    raw_data.id_value.values.clear();
    std::vector<char> vchar(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vchar);

    return true;
}

bool obj_impl_decl_compound::unpack(const content& raw_data)
{
    nb_id_t id;    
    unpack(raw_data, id, m_cData);
    assert(m_obj_id == id);    
    return true;
}

bool obj_impl_decl_compound::json_unpack(const content& raw_data, 
	nb_id_t& id,
	decl_compound_data_t& logic_data)
{
    id = raw_data.object_id;

    assert(!raw_data.id_value.values.empty());
    std::vector<char> vchar = raw_data.id_value.values[0];
    std::string strval(vchar.begin(), vchar.end());

    boost::shared_ptr<stdx::json_object> pObj;
    pObj.reset(dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval)));
    assert(pObj); 

    stdx::json_node* item;
    item = pObj->find("name");
    logic_data.name = item->get_string();
    // unpack vector<iport_t> iports
    item = pObj->find("iports");
    stdx::json_array* jarr = dynamic_cast<stdx::json_array*>(item);
    assert(jarr);
    logic_data.iports.clear();
    for(int i = 0; i < jarr->size(); ++i )
    {
        stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
        assert(subobj);
        iport_t iport;
        iport.name = subobj->find("name")->get_string();
        iport.interface.str(subobj->find("interface")->get_string());
        iport.default_value.str(subobj->find("default_value")->get_string());
        logic_data.iports.push_back(iport);
    }
    // end iports

    // unpack vector<oport_t> oports
    item = pObj->find("oports");
    jarr = dynamic_cast<stdx::json_array*>(item);
    assert(jarr);
    logic_data.oports.clear();
    for(int i = 0; i < jarr->size(); ++i )
    {
        stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
        assert(subobj);
        oport_t oport;
        oport.name = subobj->find("name")->get_string();
        oport.interface.str(subobj->find("interface")->get_string());
        logic_data.oports.push_back(oport);
    }
    // end oprts

    // unpack vector<decl_exp_group> groups
    item = pObj->find("groups");
    jarr = dynamic_cast<stdx::json_array*>(item);
    assert(jarr);
    logic_data.groups.clear();
    for(int i = 0; i < jarr->size(); ++i )
    {
        stdx::json_object* subobj = dynamic_cast<stdx::json_object*>(jarr->at(i));
        assert(subobj);
        decl_exp_group decl_group;
        decl_group.name = subobj->find("name")->get_string();
        decl_group.min_if.str(subobj->find("min_if")->get_string());
        decl_group.expanded = subobj->find("expanded")->get_boolean();
        // unpack vector<decl_exp_idx> members
        stdx::json_array* jarr2 = dynamic_cast<stdx::json_array*>(subobj->find("members"));
        assert(jarr2);
        decl_group.members.clear();
        for(int j = 0; j < jarr2->size(); ++j )
        {
            stdx::json_object* subobj2 = dynamic_cast<stdx::json_object*>(jarr2->at(j));
            assert(subobj2);
            decl_exp_idx decl_idx;
            decl_idx.is_input = subobj2->find("is_input")->get_boolean();
            decl_idx.port_idx = subobj2->find("port_idx")->get_int();
            decl_idx.relay_idx = subobj2->find("relay_idx")->get_int();
            decl_group.members.push_back(decl_idx);
        }
        // end members
        logic_data.groups.push_back(decl_group);
    }
    // end groups

    return true;
}

bool obj_impl_decl_compound::run(call_id_t call_id, const node_invocation_request& input)
{ 
    LOG_DEBUG("*** obj_impl_decl_compound::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
