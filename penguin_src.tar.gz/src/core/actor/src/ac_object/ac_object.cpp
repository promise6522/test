/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "nb_id.h"
#include "stdx_log.h"
#include "ac_object.h"

#include "ac_object/obj_impl_array.h"
#include "ac_object/obj_impl_bool.h"
#include "ac_object/obj_impl_bytes.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_declaration.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_exec_impl.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_float.h"
#include "ac_object/obj_impl_id_stand_in.h"
#include "ac_object/obj_impl_integer.h"
#include "ac_object/obj_impl_interface.h"
#include "ac_object/obj_impl_interface_compound.h"
#include "ac_object/obj_impl_interval.h"
#include "ac_object/obj_impl_map.h"
#include "ac_object/obj_impl_none.h"
#include "ac_object/obj_impl_string.h"
#include "ac_object/obj_impl_time.h"
#include "ac_object/obj_impl_user.h"
#include "ac_object/obj_impl_bridge.h"
#include "ac_object/obj_impl_bridge_interface.h"
#include "ac_object/obj_impl_corpse.h"
#include "ac_object/obj_impl_container_def.h"
#include "ac_object/obj_impl_decl_expanded.h"

bool ac_object::initialization()
{
    assert(m_ptrHelper);

    // request data to build the actor

    if(m_id.is_justid_type())    
    {
        init_implementation(content());
        m_ptrHelper->initialization_respond();
    }
    else 
    // persistent type,get value from db
    {
        time_t tm;    
        time(&tm);
        req_num_t req_num = req_num_t(tm, true);

        object_ids input;
        input.ids.push_back(m_id);
        
        m_ptrHelper->ac_object_db_read(req_num, input);
    }
    return true;
}

bool ac_object::initialization(const content& data)
{
    init_implementation(data);

    assert(m_ptrHelper);
    if (!m_id.is_user_object())
        m_ptrHelper->initialization_respond();

    return true;    
}

bool ac_object::destruction()
{  
    /* 
    switch (m_id.get_type())
    {
        case NBID_TYPE_OBJECT_NONE:
        case NBID_TYPE_OBJECT_BOOL:
        case NBID_TYPE_OBJECT_INT:
        case NBID_TYPE_OBJECT_FLOAT:
        case NBID_TYPE_OBJECT_INTERVAL:
        case NBID_TYPE_OBJECT_TIME:
            break;
        case NBID_TYPE_OBJECT_USER:
            {

                std::string strval;
                int ret = ac_object_db_impl::instance().read_(m_id.str(), strval);
                if (ret == static_cast<int>(NB_DB_RESULT_FAILED))
                    return false;
                
                if (strval.empty())
                {
                    content raw_data;
                    m_ptrImpl->get_value(raw_data);
                    strval = data_packer::pack_to_stream(raw_data);
                    ret = ac_object_db_impl::instance().write_(m_id.str(), strval);
                    if (ret == static_cast<int>(NB_DB_RESULT_SUCCESS))
                        return true;
                }
            }
            break;
        default:
            break;
    }*/
    return true;
}

bool ac_object::init_implementation(const content& raw_data)
{
    // init impl 
    switch(m_id.get_type())
    {
    case NBID_TYPE_OBJECT_NONE:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_none(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_BOOL:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_bool(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_INT:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_integer(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_FLOAT:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_float(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_STRING:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_string(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_BYTES:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_bytes(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_INTERVAL:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_interval(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_TIME:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_time(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_ARRAY:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_array(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_MAP:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_map(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_DECLARATION:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_declaration(m_id, m_ptrHelper.get()));
        break;

    /* ##Attention## 
    ** Compose/Decompose are actually declaration_compound
    ** but they use the different id type */
    case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
    case NBID_TYPE_FUNCTION_COMPOSE:
    case NBID_TYPE_FUNCTION_DECOMPOSE:
    case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE:
    case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE:
    case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC:
    case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_decl_compound(m_id,raw_data, m_ptrHelper.get()));
        break;

    case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_decl_expanded(m_id,raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_INTERFACE:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_interface(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_INTERFACE_COMPOUND:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_interface_compound(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_IMPLEMENTATION:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_impl(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_obj_func(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_storage_func(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_anchor_func(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_EXEC_ITERATOR:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_iterator(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_EXEC_CONDITION:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_exec_condition(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_DESCRIPTOR: 
        m_ptrImpl.reset(new(std::nothrow) obj_impl_descriptor(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_CONTAINER_DEF: 
        m_ptrImpl.reset(new(std::nothrow) obj_impl_container_def(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_ID_STAND_IN:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_id_stand_in(m_id, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_USER:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_user(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_BRIDGE:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_bridge(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_BRIDGE_INTERFACE:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_bridge_interface(m_id, raw_data, m_ptrHelper.get()));
        break;
    case NBID_TYPE_OBJECT_CORPSE:
        m_ptrImpl.reset(new(std::nothrow) obj_impl_corpse(m_id, raw_data, m_ptrHelper.get()));
        break;
    default:
        LOG_ERROR("ac_object::initialization()=>invalid object id = "<<m_id.str());
        m_ptrImpl.reset(new(std::nothrow) object_implementation_base(m_id,  m_ptrHelper.get()));
        //assert(m_ptrImpl);
        break;
    }

    return true;
}

bool ac_object::set_value(content& value)
{    
    assert(m_ptrImpl);
    return m_ptrImpl->set_value(value);    
}

bool ac_object::get_value_sync(content& value)
{
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(value);    
}

bool ac_object::get_value_async(call_id_t call_id)
{    
    LOG_DEBUG("*** ac_object::get_value_async()");

    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_object initialization failed");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    content value;
    if (!m_ptrImpl->get_value(value))
        return false;

    return m_ptrHelper->ac_object_get_value_async_respond(call_id, value); 
}

bool ac_object::get_property(const nb_id_t& input, object_ids& output)
{
    assert(m_ptrImpl);
    return m_ptrImpl->get_property(input, output);    
}

bool ac_object::set_property(const property_info& input)
{
    assert(m_ptrImpl);
    return m_ptrImpl->set_property(input);    
}

bool ac_object::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_object::run(call_id_t call_id, const node_invocation_request& input)
{ 
    //assert(m_ptrImpl);
    std::string val("ac_object initialization failed");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    node_invocation_request req = input;
    if(typeid(*m_ptrImpl.get()) == typeid(object_implementation_base))
    {
        LOG_ERROR("ac_object::run() failed.");
        return m_ptrImpl->run_exception_respond(call_id, input.transaction_id);
    }

    if (!m_ptrImpl->run_prepare(req))
    {
        LOG_ERROR("ac_object::run_prepare() failed.");
        return m_ptrImpl->run_exception_respond(call_id, input.transaction_id);
    }

    return m_ptrImpl->run(call_id, req);    
}

bool ac_object::ac_object_db_read_response(req_num_t req_num, db_value& output)
{
    //set data by impl
    if(0 == output.all_objects.size())
    {
        LOG_ERROR("ac_object initialization failed");
        //m_ptrHelper->initialization_respond_fail();
        //return false;
        m_ptrImpl.reset(new(std::nothrow) object_implementation_base(m_id,  m_ptrHelper.get()));
    }
    else
    {
        init_implementation(output.all_objects[0]);
    }
    assert(m_ptrHelper);
    return m_ptrHelper->initialization_respond();
}

bool ac_object::ac_execution_start_response(req_num_t req_num, node_invocation_response& output)
{
	LOG_DEBUG("ac_object::ac_execution_start_response().");
	LOG_DEBUG("ac_object::ac_execution_start_response():output size:" << output.output.objects.size());

    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_object initialization failed");

    req_info_t req_info;
    if (!m_ptrImpl->pop_call_info(req_num, req_info))
    {
        LOG_ERROR("ac_object::ac_execution_start_response : could not get call info");
        return false;        
    }

    return m_ptrHelper->ac_object_run_respond(req_info.call_id, output);
}

bool ac_object::ac_object_get_value_async_response(req_num_t req_num, content& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_object initialization failed");

    m_ptrImpl->get_value_response(req_num, output);
    return true;
}

bool ac_object::ac_object_run_response(req_num_t req_num, node_invocation_response& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_object initialization failed");


    m_ptrImpl->obj_run_response(req_num, output);
    return true;
}

bool ac_object::ac_transaction_begin_response(req_num_t req_num)
{
    return true;
}

bool ac_object::ac_transaction_get_host_committer_response(req_num_t req_num, host_committer_id_t& output)
{
    return true;
}

bool ac_object::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
