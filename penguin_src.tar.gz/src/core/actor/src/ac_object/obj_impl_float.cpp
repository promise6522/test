/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_float.h"

obj_impl_float::obj_impl_float(nb_id_t& obj_id, ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{ 
    assert(obj_id.is_object_float());
} 

obj_impl_float::~obj_impl_float()
{
}

bool obj_impl_float::get_value(content& data)
{
    return true;
}

bool obj_impl_float::set_value(const content& data)
{
    return true;
}

bool obj_impl_float::run(call_id_t call_id, const node_invocation_request& input)
{
    LOG_DEBUG("*** obj_impl_float::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;

    return execution_start(call_id, exec_info, input);

}
// vim:set tabstop=4 shiftwidth=4 expandtab:
