/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <string>
#include <vector>

#include "boost/crc.hpp"
#include "ac_object/obj_impl_bytes.h"

obj_impl_bytes::obj_impl_bytes() 
{
} 

obj_impl_bytes::obj_impl_bytes(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_bytes());
    set_value(raw_data);
} 

obj_impl_bytes::~obj_impl_bytes()
{
} 

bool obj_impl_bytes::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_bytes::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_bytes::pack(const bytes_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.crc);
    packer.pack(logic_data.length);
    packer.pack(logic_data.value);

    //raw_data.id_value = packer.get_pack_data();
    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_bytes::unpack(const content& raw_data, nb_id_t& id, bytes_data_t& logic_data)
{
    id = raw_data.object_id;
    //data_unpacker unpack(raw_data.id_value);
    //assert(raw_data.id_value.values.size());
    data_unpacker unpack(raw_data);

    logic_data.crc = unpack.unpack_int(0);
    logic_data.length = unpack.unpack_int(1);
    logic_data.value = unpack.unpack_string(2);

    return true;
}

bool obj_impl_bytes::json_pack(const bytes_data_t& logic_data, 
	const nb_id_t& id, 
	content& raw_data)
{
    //clear the raw_data
    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();

    //set object id
    raw_data.object_id = id;

    std::string   str_crc, str_len;
    std::ostringstream ostr_crc, ostr_len;
    ostr_crc<<logic_data.crc;
    ostr_len<<logic_data.length;
    str_crc = ostr_crc.str(); 
    str_len = ostr_len.str(); 

    std::string strval;
    strval = str_crc;
    strval.resize(10);
    strval.append(str_len);
    strval.resize(20);
    strval.append(logic_data.value);

    raw_data.id_value.values.push_back(std::vector<char>(strval.begin(), strval.end()));
    return true;
}

bool obj_impl_bytes::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);

    return true;
}

bool obj_impl_bytes::json_unpack(const content& raw_data, nb_id_t& id, bytes_data_t& logic_data)
{
    id = raw_data.object_id;

    std::string strval;
    strval.assign(raw_data.id_value.values[0].begin(),
                  raw_data.id_value.values[0].end());

    if (!strval.size())
    {   
        std::string str_crc = strval.substr(0, 10);
        logic_data.crc = atoi(str_crc.c_str());

        std::string str_len = strval.substr(10, 10);
        logic_data.length = atoi(str_len.c_str());
        logic_data.value = strval.substr(20);
    }

    return true;
}

bool obj_impl_bytes::unpack(const content& raw_data)
{
    nb_id_t id;
    unpack(raw_data, id, m_cData);
    assert(id == m_obj_id);
    return true;
}

bool obj_impl_bytes::run(call_id_t call_id, const node_invocation_request& input)
{
    LOG_DEBUG("*** obj_impl_bytes::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
