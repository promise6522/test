/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_array.h"
#include "stdx_json.h"

obj_impl_array::obj_impl_array()
{
} 

obj_impl_array::obj_impl_array(const nb_id_t& obj_id, 
	const content& raw_data, 
	ac_object_helper * pHelper)
: object_implementation_base(obj_id, pHelper)
{
    assert(obj_id.is_object_array());
    set_value(raw_data);
} 

obj_impl_array::~obj_impl_array()
{
}

bool obj_impl_array::get_value(content& data)
{
    pack(data);
    return true;
}

bool obj_impl_array::set_value(const content& data)
{
    unpack(data);
    return true;
}

bool obj_impl_array::pack(content& raw_data)
{
    pack(m_cData, m_obj_id, raw_data);

    return true;
}

bool obj_impl_array::pack(const array_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.name);
    //packer.pack(logic_data.interface);
    packer.pack(logic_data.type);
    packer.pack(logic_data.objs);

    raw_data = packer.get_pack_data();
    raw_data.object_id = id;

    return true;
}

bool obj_impl_array::unpack(const content& raw_data, nb_id_t& id, array_data_t& logic_data)
{
    id = raw_data.object_id;

    data_unpacker unpack(raw_data);

    logic_data.name = unpack.unpack_string(0);
    //logic_data.interface = unpack.unpack_id(0);
    logic_data.type = unpack.unpack_id(0);
    int obj_size = raw_data.id_value.ids.size() - 1;
    for (int i = 0; i < obj_size; ++i)
        logic_data.objs.push_back(unpack.unpack_id(i+1));

    return true;
}

bool obj_impl_array::json_pack(const array_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    /*struct array_data_t
      {
          nb_id_t interface;
          nb_id_t type;
          nb_id_vector objs;
      };
    */
    stdx::json_object* pObj = new stdx::json_object();
    assert(pObj);
    //pObj->insert("interface", new stdx::json_string(logic_data.interface.str()));
    pObj->insert("type", new stdx::json_string(logic_data.type.str()));
    
    stdx::json_array* pArray = new stdx::json_array();
    assert(pArray);
    nb_id_vector::const_iterator it = logic_data.objs.begin();
    while(it!=logic_data.objs.end())
    {
        stdx::json_string* pStr = new stdx::json_string(it->str());
        assert(pStr);
        pArray->push_back(pStr);
        ++it;
    }
    pObj->insert("objs", pArray);
    
    std::string strval = pObj->to_json_string();
    delete pObj;
    //save the data to content
    raw_data.id_value.ids.clear();
    raw_data.id_value.values.clear();
    
    raw_data.object_id = id;
    //raw_data.id_value.ids.push_back(logic_data.interface);
    raw_data.id_value.ids.push_back(logic_data.type);
    nb_id_vector::const_iterator itVec = logic_data.objs.begin();
    while(itVec!=logic_data.objs.end())
    {
        raw_data.id_value.ids.push_back(*itVec);
        ++itVec;
    }
    std::vector<char> vec(strval.begin(), strval.end());
    raw_data.id_value.values.push_back(vec);
    
    return true;
}

bool obj_impl_array::unpack(const content& raw_data)
{
    nb_id_t id;    
    this->unpack(raw_data, id, this->m_cData);
    assert(m_obj_id == id);
    return true;
}

bool obj_impl_array::json_unpack(const content& raw_data, nb_id_t& id,
	array_data_t& logic_data)
{
    id = raw_data.object_id;
    std::string strval(raw_data.id_value.values[0].begin(), raw_data.id_value.values[0].end());
    
    stdx::json_object* pObj = dynamic_cast<stdx::json_object*>(stdx::json_tokener_parse(strval));
    assert(pObj);
    stdx::json_node* pNode = NULL;
    //pNode = pObj->find("interface");
    //assert(pNode);
    //logic_data.interface.str(pNode->get_string());
    
    pNode = pObj->find("type");
    assert(pNode);
    logic_data.type.str(pNode->get_string());
    
    pNode = pObj->find("objs");
    stdx::json_array* pArray = dynamic_cast<stdx::json_array*>(pNode);
    assert(pArray);
    for(int i=0; i<pArray->size(); ++i)
    {
        nb_id_t idTem;
        idTem.str(pArray->at(i)->get_string());
        logic_data.objs.push_back(idTem);
    }
    delete pObj;
    return true;
}

bool obj_impl_array::run(call_id_t call_id, const node_invocation_request& input)
{
    LOG_DEBUG("*** obj_impl_array::run()");

    //request new execution actor
    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
