/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_object/obj_impl_corpse.h"


obj_impl_corpse::obj_impl_corpse(const nb_id_t& obj_id, 
        const content& raw_data,
        ac_object_helper* pHelper)
    :object_implementation_base(obj_id, pHelper)
{
    set_value(raw_data);
}

obj_impl_corpse::obj_impl_corpse()
{
}

obj_impl_corpse::~obj_impl_corpse()
{
}

bool obj_impl_corpse::get_value(content& raw_data)
{
    return pack(raw_data);
}

bool obj_impl_corpse::set_value(const content& raw_data)
{
    return unpack(raw_data);
}

bool obj_impl_corpse::pack(content& raw_data)
{
    return pack(m_cData, m_obj_id, raw_data);
}

bool obj_impl_corpse::unpack(const content& raw_data)
{
    return unpack(raw_data, m_obj_id, m_cData);
}

bool obj_impl_corpse::pack(const corpse_data_t& logic_data, const nb_id_t& id, content& raw_data)
{
    data_packer packer;

    packer.pack(logic_data.node_index);
    packer.pack(logic_data.implement_id);
    packer.pack(logic_data.object_id);

    nb_id_t nb_inputs(NBID_TYPE_OBJECT_INT);
    int input_size = logic_data.inputs.size();
    nb_inputs.set_value(input_size);
    packer.pack(nb_inputs);

    packer.pack(logic_data.inputs);

    packer.pack(logic_data.sub_corpse);
    packer.pack(logic_data.reason);

    packer.pack(logic_data.name);
    packer.pack(logic_data.container_id.str());

    raw_data = packer.get_pack_data();
    raw_data.object_id = id;
    return true;
}

bool obj_impl_corpse::unpack(const content& raw_data, nb_id_t& id, corpse_data_t& logic_data)
{
    id = raw_data.object_id;
    data_unpacker unpack(raw_data);

    int node_index = -1;

    logic_data.node_index = unpack.unpack_id(++node_index);
    logic_data.implement_id = unpack.unpack_id(++node_index);
    logic_data.object_id = unpack.unpack_id(++node_index);

    int input_size = 0;
    unpack.unpack_id(++node_index).get_value(input_size);

    for (int i = 0; i < input_size; ++i)
        logic_data.inputs.push_back(unpack.unpack_id(++node_index));

    logic_data.sub_corpse = unpack.unpack_id(++node_index);
    logic_data.reason = unpack.unpack_id(++node_index);

    logic_data.name = unpack.unpack_string(0);
    logic_data.container_id.str(unpack.unpack_string(1));

    return true;
}

bool obj_impl_corpse::run(call_id_t call_id, const node_invocation_request& input)
{
    LOG_DEBUG("*** obj_impl_corpse::run()");

    request_execution_id_info exec_info;
    exec_info.committer_id = input.host_committer_id;
    exec_info.obj_info.object_id = m_obj_id;
    pack(exec_info.obj_info.obj_raw_data);

    return execution_start(call_id, exec_info, input);
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
