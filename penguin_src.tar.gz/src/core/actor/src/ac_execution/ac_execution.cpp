/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "nb_id.h"

#include "ac_execution.h"

#include "ac_execution/exec_implement.h"
#include "ac_execution/exec_condition.h"
#include "ac_execution/exec_iterator.h"
#include "ac_execution/exec_obj_func.h"
#include "ac_execution/exec_storage_func.h"
#include "ac_execution/exec_anchor_func.h"

#include "ac_execution/func_access.h"
#include "ac_execution/func_array.h"
#include "ac_execution/func_bool.h"
#include "ac_execution/func_bytes.h"
#include "ac_execution/func_decl_compound.h"
#include "ac_execution/func_declaration.h"
#include "ac_execution/func_descriptor.h"
#include "ac_execution/func_float.h"
#include "ac_execution/func_id_stand_in.h"
#include "ac_execution/func_integer.h"
#include "ac_execution/func_interface.h"
#include "ac_execution/func_interface_compound.h"
#include "ac_execution/func_interval.h"
#include "ac_execution/func_map.h"
#include "ac_execution/func_none.h"
#include "ac_execution/func_string.h"
#include "ac_execution/func_time.h"
#include "ac_execution/func_user.h"
#include "ac_execution/func_bridge.h"
#include "ac_execution/func_bridge_interface.h"
#include "ac_execution/func_corpse.h"
#include "ac_execution/func_container_def.h"
#include "ac_execution/func_decl_expanded.h"

bool ac_execution::initialization()
{
    // TODO
    return true;
}

bool ac_execution::initialization(const object_info& data)
{
    // initialize implement
    nb_id_t obj_id = data.object_id;
    content raw_data = data.obj_raw_data;
    execution_id_t exec_id = m_id;

    switch(obj_id.get_type())
    {
        case NBID_TYPE_OBJECT_NONE:
            m_ptrImpl.reset(new(std::nothrow) func_none(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_ACCESS:
            m_ptrImpl.reset(new(std::nothrow) func_access(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_BOOL:
            m_ptrImpl.reset(new(std::nothrow) func_bool(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_INT:
            m_ptrImpl.reset(new(std::nothrow) func_integer(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_FLOAT:
            m_ptrImpl.reset(new(std::nothrow) func_float(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_STRING:
            m_ptrImpl.reset(new(std::nothrow) func_string(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_BYTES:
            m_ptrImpl.reset(new(std::nothrow) func_bytes(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_INTERVAL:
            m_ptrImpl.reset(new(std::nothrow) func_interval(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_TIME:
            m_ptrImpl.reset(new(std::nothrow) func_time(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_ARRAY:
            m_ptrImpl.reset(new(std::nothrow) func_array(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_MAP:
            m_ptrImpl.reset(new(std::nothrow) func_map(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_DECLARATION:
            m_ptrImpl.reset(new(std::nothrow) func_declaration(obj_id, exec_id, m_ptrHelper.get()));
            break;

        /* ##Attention## 
        ** Compose/Decompose are actually declaration_compound
        ** but they use the different id type */
        case NBID_TYPE_OBJECT_DECLARATION_COMPOUND:
        case NBID_TYPE_FUNCTION_COMPOSE:
        case NBID_TYPE_FUNCTION_DECOMPOSE:
        case NBID_TYPE_FUNCTION_BRIDGE_COMPOSE:
        case NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE:
        case NBID_TYPE_FUNCTION_GET_ANCHORS:
        case NBID_TYPE_FUNCTION_GET_STORAGES:
        case NBID_TYPE_FUNCTION_OUTGOING_SEND_SYNC:
        case NBID_TYPE_FUNCTION_OUTGOING_SEND_ASYNC:
	    m_ptrImpl.reset(new(std::nothrow) func_decl_compound(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;

        case NBID_TYPE_OBJECT_DECLARATION_EXPANDED:
            m_ptrImpl.reset(new(std::nothrow) func_decl_expanded(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_INTERFACE:
            m_ptrImpl.reset(new(std::nothrow) func_interface(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_INTERFACE_COMPOUND:
            m_ptrImpl.reset(new(std::nothrow) func_interface_compound(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_IMPLEMENTATION:
            m_ptrImpl.reset(new(std::nothrow) exec_implement(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_EXEC_OBJ_FUNC:
            m_ptrImpl.reset(new(std::nothrow) exec_obj_func(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
            m_ptrImpl.reset(new(std::nothrow) exec_storage_func(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC:
            m_ptrImpl.reset(new(std::nothrow) exec_anchor_func(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_EXEC_ITERATOR:
            m_ptrImpl.reset(new(std::nothrow) exec_iterator(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_EXEC_CONDITION:
            m_ptrImpl.reset(new(std::nothrow) exec_condition(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_DESCRIPTOR: 
            m_ptrImpl.reset(new(std::nothrow) func_descriptor(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_CONTAINER_DEF: 
            m_ptrImpl.reset(new(std::nothrow) func_container_def(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_ID_STAND_IN:
            m_ptrImpl.reset(new(std::nothrow) func_id_stand_in(obj_id, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_USER:
            m_ptrImpl.reset(new(std::nothrow) func_user(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_BRIDGE:
            m_ptrImpl.reset(new(std::nothrow) func_bridge(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_BRIDGE_INTERFACE:
            m_ptrImpl.reset(new(std::nothrow) func_bridge_interface(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        case NBID_TYPE_OBJECT_CORPSE:
            m_ptrImpl.reset(new(std::nothrow) func_corpse(obj_id, raw_data, exec_id, m_ptrHelper.get()));
            break;
        default:
            //assert(m_ptrImpl);
            LOG_ERROR("ac_execution::initialization()=>invalid object id = "<<obj_id.str());

            break;
    }

    assert(m_ptrHelper);
    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_execution::exception_handle(req_num_t req_num, const std::string& str)
{
    transaction_id_t    id;
    m_ptrImpl->get_transaction_id(id);
    m_ptrImpl->run_exception_respond(id, CORPSE_INITIALIZE_FAILED);
    return ac_actor::exception_handle(req_num, str);
}

bool ac_execution::set_parent(const execution_id_t& input)
{
    return m_ptrImpl->set_parent(input);
}

bool ac_execution::start(call_id_t call_id, const node_invocation_request& input)
{
    m_cData.m_call_id = call_id;
    m_cData.m_node_request = input;

    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_execution implement pointer initialization failed");
    if(!this->has_impl_ptr())
        m_ptrHelper->exception_respond(call_id, val);

    m_ptrImpl->run_prepare(call_id, input);
    return  m_ptrImpl->run();
}

/************************ committer operation response ************************/

bool ac_execution::ac_root_committer_pre_commit_response(req_num_t req_num, bool& output)
{
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    return m_ptrImpl->pre_commit_response(req_num, output);
}

bool ac_execution::ac_root_committer_commit_response(req_num_t req_num, bool& output)
{
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    return m_ptrImpl->commit_response(req_num, output);
}


bool ac_execution::ac_object_run_response(req_num_t req_num, node_invocation_response& output)
{
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    //assert(m_ptrImpl);
    return m_ptrImpl->obj_run_response(req_num, output);
}

bool ac_execution::ac_access_run_response(req_num_t req_num, node_invocation_response& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    return m_ptrImpl->access_run_response(req_num, output);
}

bool ac_execution::ac_object_get_value_async_response(req_num_t req_num, content& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    return m_ptrImpl->get_value_response(req_num, output);
}

bool ac_execution::ac_transaction_get_host_committer_response(req_num_t req_num, host_committer_id_t& output)
{
    return true;
}

bool ac_execution::ac_transaction_success_response(req_num_t req_num)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");


    nb_id_t obj_id;
    m_ptrImpl->get_object_id(obj_id);

    switch (obj_id.get_type())
    {
        case  NBID_TYPE_OBJECT_IMPLEMENTATION:
            return dynamic_cast<exec_implement *>(m_ptrImpl.get())->transaction_success_response(req_num);
            break;
        default:
            break;
    }

    return true;
}

bool ac_execution::ac_transaction_fail_response(req_num_t req_num)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");


    nb_id_t obj_id;
    m_ptrImpl->get_object_id(obj_id);

    switch (obj_id.get_type())
    {
        case  NBID_TYPE_OBJECT_IMPLEMENTATION:
            return dynamic_cast<exec_implement *>(m_ptrImpl.get())->transaction_fail_response(req_num);
            break;
        default:
            break;
    }

    return true;
}

bool ac_execution::ac_transaction_is_failed_response(req_num_t req_num, bool& output)
{
    return true;
}

bool ac_execution::ac_transaction_set_cut_info_response(req_num_t req_num)
{
    return true;
}

bool ac_execution::ac_anchor_get_value_async_response(req_num_t req_num, content& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");


    nb_id_t obj_id;
    m_ptrImpl->get_object_id(obj_id);
    switch (obj_id.get_type())
    {
        case  NBID_TYPE_OBJECT_ACCESS:
            return dynamic_cast<func_access *>(m_ptrImpl.get())->get_anchor_value_response(req_num, output);
            break;
        case  NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC:
            return dynamic_cast<exec_anchor_func *>(m_ptrImpl.get())->get_anchor_value_response(req_num, output);
            break;
        default:
            break;
    }

    return true;
}

bool ac_execution::ac_storage_get_value_async_response(req_num_t req_num, content& output)
{
    //assert(m_ptrImpl);

    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    nb_id_t obj_id;
    m_ptrImpl->get_object_id(obj_id);

    switch (obj_id.get_type())
    {
        case  NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
            return dynamic_cast<exec_storage_func *>(m_ptrImpl.get())->get_storage_value_response(req_num, output);
            break;
        default:
            break;
    }

    return true;
}

bool ac_execution::ac_container_get_value_async_response(req_num_t req_num, con_content& output)
{
    //assert(m_ptrImpl);
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    
    nb_id_t obj_id;
    m_ptrImpl->get_object_id(obj_id);

    switch (obj_id.get_type())
    {
        case  NBID_TYPE_OBJECT_ACCESS:
            return dynamic_cast<func_access *>(m_ptrImpl.get())->get_container_value_response(req_num, output);
            break;
        case  NBID_TYPE_OBJECT_EXEC_STORAGE_FUNC:
            return dynamic_cast<exec_storage_func *>(m_ptrImpl.get())->get_container_value_response(req_num, output);
            break;
        case  NBID_TYPE_OBJECT_EXEC_ANCHOR_FUNC:
            return dynamic_cast<exec_anchor_func *>(m_ptrImpl.get())->get_container_value_response(req_num, output);
            break;
        default:
            break;
    }

    return true;
}

// storage facade response
bool ac_execution::ac_storage_facade_get_single_response(req_num_t req_num, object_id& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_get_single_response(req_num, output);
}

bool ac_execution::ac_storage_facade_get_more_response(req_num_t req_num, key_pair_no_version1& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_get_more_response(req_num, output);
}

bool ac_execution::ac_storage_facade_has_key_response(req_num_t req_num, key_array& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_has_key_response(req_num, output);
}

bool ac_execution::ac_storage_facade_replace_one_response(req_num_t req_num, object_id& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_replace_one_response(req_num, output);
}

bool ac_execution::ac_storage_facade_delete_one_response(req_num_t req_num, object_id& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_delete_one_response(req_num, output);
}

bool ac_execution::ac_storage_facade_set_one_response(req_num_t req_num, bool& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_set_one_response(req_num, output);
}

bool ac_execution::ac_storage_facade_update_response(req_num_t req_num, sv_update_output& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_update_response(req_num, output);
}

bool ac_execution::ac_storage_facade_size_response(req_num_t req_num, int& output)
{
    if(!this->has_impl_ptr())
        return exception_handle(req_num, "ac_execution initialization failed");

    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_size_response(req_num, output);
}

bool ac_execution::ac_storage_facade_get_range_response(req_num_t req_num, key_pair_no_version1& output)
{
    /* only exec_storage_func handles this msg */
    exec_storage_func* ptrStFunc = dynamic_cast<exec_storage_func*>(m_ptrImpl.get());
    assert(ptrStFunc);
    return ptrStFunc->storage_facade_get_range_response(req_num, output);
}

// storage facade response
bool ac_execution::ac_bridge_send_out_response(req_num_t req_num, nb_id_t& output)
{
    /* only exec_storage_func handles this msg */
    func_access* ptrAccess = dynamic_cast<func_access*>(m_ptrImpl.get());
    assert(ptrAccess);
    return ptrAccess->bridge_send_out_response(req_num, output);
}

bool ac_execution::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}
// vim:set tabstop=4 shiftwidth=4 expandtab:
