/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_execution_helper.h"
#include "ac_id_dispenser.h"
#include "ac_execution/exec_implement.h"
#include "ac_object/obj_impl_exec_condition.h"
#include "ac_object/obj_impl_exec_iterator.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_exec_storage_func.h"
#include "ac_object/obj_impl_exec_anchor_func.h"
#include "ac_object/obj_impl_string.h"


static const int EXEC_STATUS_NONE      = 0;
static const int EXEC_STATUS_PARSING   = 1;
static const int EXEC_STATUS_EXECUTING = 2;


exec_implement::exec_implement(
        const nb_id_t& obj_id,
        const content& raw_data,
        const execution_id_t& exe_id,
        ac_execution_helper * pHelper)
    : execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_exec_implementation());

    // initialize
    m_execution_status = EXEC_STATUS_NONE;
    m_executed = 0;
    m_exception_type = 0;
    m_is_over = false;

    // save the graph
    nb_id_t id;
    obj_impl_exec_impl::unpack(raw_data, id, m_exec_imple);
    mp_inputs_output_objects = new nb_id_t[m_exec_imple.m_io_obj_lenth];

    print_implement(m_exec_imple);
    //assert(m_obj_id == id);
}

exec_implement::~exec_implement()
{
    if (mp_inputs_output_objects)
        delete mp_inputs_output_objects;
}

bool exec_implement::get_name(nb_id_t& out)
{
    return request_string_object(m_exec_imple.name, out);
}

bool exec_implement::parse_impl_graph()
{
    LOG_DEBUG("*** exec_implement::parse_impl_graph()");

    m_execution_status = EXEC_STATUS_PARSING;
//    m_exec_imple.m_total_size = 0;

    std::vector<nb_id_t>::size_type i = 0;
    for (; i < m_exec_imple.nodes.size(); ++i)
        object_get_value_async(m_exec_imple.nodes[i], i);

    // insert the output node
    exe_impl_node_t   impl_node;
    impl_node.m_start_position = m_exec_imple.nodes.size();
    impl_node.m_size = m_exec_imple.out_port_size;
    impl_node.m_confirm_size = m_exec_imple.out_port_size;
    m_exec_imple.mp_start_size[m_exec_imple.nodes.size()] = impl_node;

//    if (0 == m_exec_imple.nodes.size())
//        execute_run();

    return true;
}

bool exec_implement::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** exec_implement::get_value_response()");

    switch (m_execution_status)
    {
        case EXEC_STATUS_PARSING:
            parsing_get_value_response(req_num, output);
            break;
        case EXEC_STATUS_EXECUTING:
            executing_get_value_response(req_num, output);
            break;
        default:
            break;
    }

    return true;
}

bool exec_implement::parsing_get_value_response(req_num_t req_num, content& output)
{
    // make the run_nodes
    node_invocation_request  exe_get_inport;
    exe_get_inport.execution_id = m_param.execution_id;
    exe_get_inport.transaction_id = m_param.transaction_id;
    exe_get_inport.host_committer_id = m_param.host_committer_id;
    exe_get_inport.declaration_id = nb_id_t(NB_FUNC_DECLARATION_GET_IN_PORT_NUM);
    if (m_exec_imple.nodes[req_num].is_exec_condition())
    {
        exec_cond_data_t obj;
        nb_id_t id;
        obj_impl_exec_condition::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        object_run(obj.external_decl, req_num, exe_get_inport);
    }
    else if (m_exec_imple.nodes[req_num].is_exec_iterator())
    {
        exec_iterator_data_t obj;
        nb_id_t id;
        obj_impl_exec_iterator::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        object_run(obj.external_decl, req_num, exe_get_inport);
    }
    else if (m_exec_imple.nodes[req_num].is_exec_storage_func())
    {
        exec_storage_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_storage_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        object_run(obj.selected_decl, req_num, exe_get_inport);
    }
    else if (m_exec_imple.nodes[req_num].is_exec_anchor_func())
    {
        exec_anchor_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_anchor_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        object_run(obj.selected_decl, req_num, exe_get_inport);
    }
    else if (m_exec_imple.nodes[req_num].is_exec_obj_func())
    {
        exec_obj_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_obj_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        object_run(obj.selected_decl, req_num, exe_get_inport);
    }
    return true;
}

bool exec_implement::executing_get_value_response(req_num_t req_num, content& output)
{
    node_invocation_request  run_in;

    run_in.execution_id = m_param.execution_id;
    run_in.transaction_id = m_param.transaction_id;
    run_in.host_committer_id = m_param.host_committer_id;
    run_in.container_id = m_param.container_id;

    int inout_start = m_exec_imple.mp_start_size[req_num].m_start_position;
    for (int input_index = 0; input_index < m_exec_imple.mp_start_size[req_num].m_confirm_size; ++input_index)
    {
        if (0 == input_index)
            run_in.object_id = mp_inputs_output_objects[inout_start+input_index];
        else
            run_in.input.push_back(mp_inputs_output_objects[inout_start+input_index]);
    }

    if (m_exec_imple.nodes[req_num].is_exec_condition())
    {
        exec_cond_data_t obj;
        nb_id_t id;
        obj_impl_exec_condition::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        run_in.declaration_id = obj.external_decl;
    }
    else if (m_exec_imple.nodes[req_num].is_exec_iterator())
    {
        exec_iterator_data_t obj;
        nb_id_t id;
        obj_impl_exec_iterator::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        run_in.declaration_id = obj.external_decl;
    }
    else if (m_exec_imple.nodes[req_num].is_exec_storage_func())
    {
        exec_storage_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_storage_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        run_in.declaration_id = obj.selected_decl;
    }
    else if (m_exec_imple.nodes[req_num].is_exec_anchor_func())
    {
        exec_anchor_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_anchor_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        run_in.declaration_id = obj.selected_decl;
    }
    else if (m_exec_imple.nodes[req_num].is_exec_obj_func())
    {
        exec_obj_func_data_t obj;
        nb_id_t id;
        obj_impl_exec_obj_func::unpack(output, id, obj);
        //assert(id == m_exec_imple.nodes[req_num]);
        run_in.declaration_id = obj.selected_decl;
    }
    // send node to executable
    m_pHelper->ac_object_run(m_exec_imple.nodes[req_num], req_num, run_in);

    return true;
}

bool exec_implement::run()
{
    LOG_CRIT("@@@@@@@@@@ execution start : " << ac_time_observer::Instance()->print_current_time());
    LOG_NOTICE("$$$$$$$$$$$$$$$$$ implementation run() = "<< m_exec_imple.name);

//    return parse_impl_graph();
    return execute_run();
}

bool exec_implement::execute_run()
{
    m_execution_status = EXEC_STATUS_EXECUTING;

    std::vector<node_path_t>::size_type  k = 0;
    for (; k < m_exec_imple.paths.size(); ++k)
    {
        nb_id_t in_id;
        int in_node_index = m_exec_imple.paths[k].in_node;
        if (-1 == in_node_index)
        {
            if (0 == m_exec_imple.paths[k].in_port)
                in_id = m_param.object_id;
            else
                in_id = m_param.input[m_exec_imple.paths[k].in_port - 1];
        }
        else if (-2 == in_node_index)
            in_id = m_exec_imple.constants[m_exec_imple.paths[k].in_port];
        else
            continue;

        int out_node_index;
        insert_object(k, in_id, out_node_index);
        if (-3 != out_node_index)
            check_node_ok(out_node_index);
    }

    if (0 == m_exec_imple.nodes.size())
        check_all_over();

    return true;
}

bool exec_implement::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("*** exec_implement::obj_run_response(), success_flag="<<output.success);

    switch (m_execution_status)
    {
        case EXEC_STATUS_PARSING:
            parsing_obj_run_response(req_num, output);
            break;
        case EXEC_STATUS_EXECUTING:
            executing_obj_run_response(req_num, output);
            break;
        default:
            break;
    }

    return true;
}

bool exec_implement::parsing_obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("*** exec_implement::parsing_obj_run_response");

    if (!output.success)
    {
        // execution failed
        m_result.success = false;
        m_pHelper->ac_execution_start_respond(m_call_id, m_result);
//        ac_manager::instance().remove_actor(m_id);
        return true;
    }

    // execution success
    int input_size;
    output.output.objects[0].get_value(input_size);

    exe_impl_node_t   impl_node;
    impl_node.m_start_position = req_num;
    impl_node.m_size = input_size;
    impl_node.m_confirm_size = input_size;
    m_exec_imple.mp_start_size[req_num] = impl_node;
//    m_exec_imple.m_total_size += input_size;

    // check parsing end
    if (m_exec_imple.m_ss_length == (static_cast<int>(m_exec_imple.nodes.size())+1))
    {
        for (int i = 1; i < m_exec_imple.m_ss_length; ++i)
            m_exec_imple.mp_start_size[i].m_start_position = m_exec_imple.mp_start_size[i-1].m_start_position + m_exec_imple.mp_start_size[i-1].m_confirm_size;
        LOG_DEBUG("@@@@@@@@@@ execution parsing end : "<<ac_time_observer::Instance()->print_current_time());
//        execute_run();
    }

    return true;
}

bool exec_implement::executing_obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    LOG_DEBUG("*** exec_implement::executing_obj_run_response()");

    if (m_is_over)
        return true;

    // execution failed
    if (!output.success)
    {
        m_result.success = false;
        m_result.corpse_type = output.corpse_type;
        m_result.output.corpse = output.output.corpse;
        return m_pHelper->ac_transaction_fail(output.child_transaction, req_num);
    }

    // execution success
    m_pHelper->ac_transaction_success(output.child_transaction, req_num);

    if (output.output.objects.size() > 0)
    {
        if (output.output.objects[0].is_exception())
        {
            m_exception_type = (NB_EXCEPTION_ZERO == output.output.objects[0].get_exception_type()) ? 2 : 1;
            if (2 == m_exception_type)
            {
                m_result.output.objects.push_back(output.output.objects[0]);
                check_all_over();
                return true;
            }
        }
    }

    if (m_exec_imple.out_paths[req_num].path_idxs.size() > 0)
    {
        int path_num = m_exec_imple.out_paths[req_num].path_idxs.size();
        for (int j = 0; j < path_num; ++j)
        {
            // get output path
            int path_index = m_exec_imple.out_paths[req_num].path_idxs[j];
            int port_index = m_exec_imple.paths[path_index].in_port;
            if (-4 == port_index)
            {
                check_node_ok(m_exec_imple.paths[path_index].out_node);
            }
            else
            {
                if (output.output.objects.size() == 0)
                    return run_exception_respond(m_param.transaction_id);

                nb_id_t result_id = output.output.objects[port_index];
                int out_node_index;
                insert_object(path_index, result_id, out_node_index);
                if (-3 != out_node_index)
                    check_node_ok(out_node_index);
            }
        }
    }

    check_all_over();
    return true;
}

bool exec_implement::transaction_success_response(req_num_t req_num)
{
    return true;
}

bool exec_implement::transaction_fail_response(req_num_t req_num)
{
    create_corpse_obj(req_num);
    return run_respond(m_result);
}

bool exec_implement::create_corpse_obj(int index)
{
    corpse_data_t cData;
    nb_id_t index_id(NBID_TYPE_OBJECT_INT);
    index_id.set_value(index);
    cData.name = m_exec_imple.name;
    cData.implement_id = m_obj_id;
    cData.node_index = index_id;
    cData.container_id = m_param.container_id;
    int inout_start = m_exec_imple.mp_start_size[index].m_start_position;
    for (int input_index = 0; input_index < m_exec_imple.mp_start_size[index].m_confirm_size; ++input_index)
    {
        if (0 == input_index)
            cData.object_id = mp_inputs_output_objects[inout_start+input_index];
        else
            cData.inputs.push_back(mp_inputs_output_objects[inout_start+input_index]);
    }
    cData.sub_corpse = m_result.output.corpse;

    request_nb_id_info  str_info;
    str_info.committer_id = m_param.host_committer_id;
    str_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(run_error_string[m_result.corpse_type], nb_id_t(), str_info.raw_data);
    request_nb_id(m_param.host_committer_id, str_info, cData.reason, true);

    request_nb_id_info  corpse_info;
    corpse_info.committer_id = m_param.host_committer_id;
    corpse_info.type = NBID_TYPE_OBJECT_CORPSE;
    obj_impl_corpse::pack(cData, nb_id_t(), corpse_info.raw_data);

    nb_id_t corpse_id;
    request_nb_id(m_param.host_committer_id, corpse_info, corpse_id, true);
    LOG_INFO("          &&&&&&&&&& corpse_id = "<<corpse_id.str());
    LOG_INFO("          &&&&&&&&&& sub_corpse_id = "<<m_result.output.corpse.str());
    m_result.output.corpse = corpse_id;
    return true;
}

void exec_implement::insert_object(int path_index, nb_id_t obj, int& out_node_index)
{
    // insert object
    out_node_index = m_exec_imple.paths[path_index].out_node;
    int index = 0;
    if (-3 != out_node_index)
        index = m_exec_imple.mp_start_size[out_node_index].m_start_position + m_exec_imple.paths[path_index].out_port;
    else
        index = m_exec_imple.m_total_size + m_exec_imple.paths[path_index].out_port;
    mp_inputs_output_objects[index] = obj;
}

void exec_implement::check_node_ok(int out_node_index)
{
    if (--m_exec_imple.mp_start_size[out_node_index].m_size != 0)
        return;

    if (m_is_over)
        return;

    object_get_value_async(m_exec_imple.nodes[out_node_index], out_node_index);
}

void exec_implement::check_all_over()
{
    LOG_DEBUG("*** exec_implement::check_all_over()");

    ++m_executed;
    int node_size = m_exec_imple.nodes.size();
    if (m_executed == node_size || 2 == m_exception_type || 0 == m_exec_imple.nodes.size())
    {
        m_is_over = true;

        // make the response node
        if (2 != m_exception_type)
        {
            int start = m_exec_imple.m_io_obj_lenth - m_exec_imple.out_port_size;
            for (int i = 0; i < m_exec_imple.out_port_size; ++i)
                m_result.output.objects.push_back(mp_inputs_output_objects[start+i]);
        }
        m_result.child_transaction = m_param.transaction_id;
        m_result.success = true;
        m_result.is_refusal = false;

        LOG_CRIT("@@@@@@@@@@ execution end : " << ac_time_observer::Instance()->print_current_time());
        run_respond(m_result);
    }
}

void exec_implement::print_implement(const exec_impl_graph_t& tmp_graph)
{
    LOG_INFO(std::string(50, '='));

//    LOG_INFO("object id: " << m_obj_id.str());

    LOG_INFO("constants ids:");
    for (std::vector<nb_id_t>::const_iterator it = tmp_graph.constants.begin(); it != tmp_graph.constants.end(); ++it)
        LOG_INFO("    " << (*it).str());

    LOG_INFO("nodes ids:");
    for (std::vector<nb_id_t>::const_iterator it = tmp_graph.nodes.begin(); it != tmp_graph.nodes.end(); ++it)
        LOG_INFO("    " << (*it).str());

    LOG_INFO("paths:");
    for (std::vector<node_path_t>::const_iterator it = tmp_graph.paths.begin(); it != tmp_graph.paths.end(); ++it)
    {
        LOG_INFO("    (" << (int)it->in_node << "," 
            << (int)it->in_port << "," 
            << (int)it->out_node << "," 
            << (int)it->out_port << ")");
    }

#if 1
    LOG_INFO("out paths:");
    int i(0);
    for (std::vector<out_port_path_idx_t>::const_iterator it = tmp_graph.out_paths.begin(); it != tmp_graph.out_paths.end(); ++it)
    {
        std::ostringstream oss;
        oss << "    " <<i<< " out_path_idx: ";
        for (std::vector<int>::const_iterator iter = it->path_idxs.begin(); iter != it->path_idxs.end(); ++iter)
            oss << *iter << ", ";
        std::string strval = oss.str();
        LOG_INFO(strval);
        i++;
    }

    LOG_INFO("out port size: " << tmp_graph.out_port_size);

    LOG_INFO(std::string(50, '-'));

    LOG_INFO("ss table length: " << tmp_graph.m_ss_length);
    LOG_INFO("ss table: ");
    for (int i = 0; i < tmp_graph.m_ss_length; ++i)
        LOG_INFO("    " << tmp_graph.mp_start_size[i].m_start_position << "." 
            << tmp_graph.mp_start_size[i].m_size << "." 
            << tmp_graph.mp_start_size[i].m_confirm_size);
    LOG_INFO("total input size: " << tmp_graph.m_total_size);
    LOG_INFO("io table length: " << tmp_graph.m_io_obj_lenth);
#endif

    LOG_INFO(std::string(50, '='));
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
