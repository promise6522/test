/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "ac_execution_helper.h"
#include "ac_execution/func_bool.h"

func_bool::func_bool(nb_id_t& obj_id, 
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{ 
}; 

func_bool::~func_bool()
{
}; 

bool func_bool::get_name(nb_id_t& out)
{
#if 0
    bool value;
    m_obj_id.get_value(value);

    if (value)
        return request_string_object("boolean_true", out);
    else
        return request_string_object("boolean_false", out);
#endif
	return request_string_object("boolean", out); 
}

bool func_bool::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_bool::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_BOOL);
    return true;
}

bool func_bool::bit_not(nb_id_t& out)
{
    bool value;
    m_obj_id.get_value(value);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(!value);

    LOG_NOTICE("The result of bit not: "<< std::boolalpha << (!value));

    return true;
}

bool func_bool::bit_and(const nb_id_t& in, nb_id_t& out)
{
    bool value1, value2;
    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 && value2);

    LOG_NOTICE("The result of bit and: "<< std::boolalpha << (value1 && value2));

    return true;
}

bool func_bool::bit_or(const nb_id_t& in, nb_id_t& out)
{
    bool value1, value2;
    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 || value2);

    LOG_NOTICE("The result of bit or: "<< std::boolalpha << (value1 || value2));

    return true;
}

bool func_bool::eq(const nb_id_t& in, nb_id_t& out)
{
    bool value1, value2;
    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 == value2);
    
    LOG_NOTICE("The result of bit eq: "<< std::boolalpha << (value1 == value2));

    return true;
}

bool func_bool::ne(const nb_id_t& in, nb_id_t& out)
{
    bool value1, value2;
    m_obj_id.get_value(value1);
    in.get_value(value2);

    out = nb_id_t(NBID_TYPE_OBJECT_BOOL);
    out.set_value(value1 != value2);

    LOG_NOTICE("The result of bit ne: "<< std::boolalpha << (value1 != value2));

    return true;
}

bool func_bool::to_int(nb_id_t& out)
{
    bool value;
    m_obj_id.get_value(value);

    out = nb_id_t(NBID_TYPE_OBJECT_INT);
    if(value)
        out.set_value(1);
    else
        out.set_value(0);
    return true;
}

bool func_bool::to_string(nb_id_t& out)
{
    bool value;
    m_obj_id.get_value(value);

    if(value)
        return request_string_object("true", out);
    else
        return request_string_object("false", out);
}


bool func_bool::_exception_if(bool match, nb_id_t& out)
{
	bool value;
	m_obj_id.get_value(value);
	if(value == match)
		out = nb_id_t(NB_EXCEPTION_ZERO);
	else
		out = nb_id_t(NB_EXCEPTION_NO);
	return true;
}

bool func_bool::_break_if(bool match, nb_id_t& out)
{
	// TODO just follow the same way as exceptions
	return _exception_if(match, out);
}

bool func_bool::exception_if_true(nb_id_t& out)
{
	return _exception_if(true, out);
}

bool func_bool::exception_if_false(nb_id_t& out)
{
	return _exception_if(false, out);
}

bool func_bool::break_if_true(nb_id_t& out)
{
	return _break_if(true, out);
}

bool func_bool::break_if_false(nb_id_t& out)
{
	return _break_if(false, out);
}

bool func_bool::run()
{
    LOG_DEBUG("*** func_bool::run() ");

    bool ret = true;
    node_invocation_response response;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
    	case NB_FUNC_BOOL_NOT:
    	{
    	    nb_id_t out;
    	    ret = bit_not(out);
    	    response.output.objects.push_back(out);
    	    break;
    	}
    	case NB_FUNC_BOOL_AND:
    	{
    	    //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }

    	    nb_id_t out;
    	    ret = bit_and(m_param.input[0], out);
    	    response.output.objects.push_back(out);
    	    break;
    	}
    	case NB_FUNC_BOOL_OR:
    	{
    	    //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    	    nb_id_t out;
    	    ret = bit_or(m_param.input[0], out);
    	    response.output.objects.push_back(out);
    	    break;
    	}
    	case NB_FUNC_BOOL_EQ:
    	{
    	    //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    	    nb_id_t out;
    	    ret = eq(m_param.input[0], out);
    	    response.output.objects.push_back(out);
    	    break;
    	}
    	case NB_FUNC_BOOL_NE:
    	{
    	    //assert(1 == m_param.input.size());
            if(1 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    	    nb_id_t out;
    	    ret = ne(m_param.input[0], out);
    	    response.output.objects.push_back(out);
            
    	    break;
    	}
        case NB_FUNC_BOOL_TO_INT:
        {
            //assert(0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            nb_id_t out;
            ret = to_int(out);
            response.output.objects.push_back(out);
            break;
        }
        case NB_FUNC_BOOL_TO_STRING:
        {
            //assert( 0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
            nb_id_t out;
            ret = to_string(out);
            response.output.objects.push_back(out);
            break;
        }
    	case NB_FUNC_BOOL_EXCEPTION_TRUE:
    	{
    	    //assert(0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    		nb_id_t out;
    		ret = exception_if_true(out);
    		response.output.objects.push_back(out);
    		/********Debug********/
    		if(out.get_exception_type() == NB_EXCEPTION_ZERO)
    			LOG_NOTICE("The result of bool EXCEPTION_TRUE: exception!");
    		else
    			LOG_NOTICE("The result of bool EXCEPTION_TRUE: no exception");
    
    
    	    break;
    	}
    	case NB_FUNC_BOOL_EXCEPTION_FALSE:
    	{
    		//assert(0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    		nb_id_t out;
    		ret = exception_if_false(out);
    		response.output.objects.push_back(out);
    		/********Debug********/
    		if(out.get_exception_type() == NB_EXCEPTION_ZERO)
    			LOG_NOTICE("The result of bool EXCEPTION_FALSE: exception!");
    		else
    			LOG_NOTICE("The result of bool EXCEPTION_FALSE: no exception");
    
    	    break;
    	}
    	case NB_FUNC_BOOL_BREAK_TRUE:
    	{
    		//assert(0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    		nb_id_t out;
    		ret = break_if_true(out);
    		response.output.objects.push_back(out);
    		/********Debug********/
    		if(out.get_exception_type() == NB_EXCEPTION_ZERO)
    			LOG_NOTICE("The result of bool BREAK_TRUE: exception!");
    		else
    			LOG_NOTICE("The result of bool BREAK_TRUE: no exception");
    
    		break;
    	}
    	case NB_FUNC_BOOL_BREAK_FALSE:
    	{
    	    //assert(0 == m_param.input.size());
            if(0 != m_param.input.size())
            {
                return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);
            }
    		nb_id_t out;
    		ret = break_if_false(out);
    		response.output.objects.push_back(out);
    		/********Debug********/
    		if(out.get_exception_type() == NB_EXCEPTION_ZERO)
    			LOG_NOTICE("The result of bool BREAK_FALSE: exception!");
    		else
    			LOG_NOTICE("The result of bool BREAK_FALSE: no exception");
    
    	    break;
    	}
    	default:
    	    return execution_base::run();
    	    break;
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);

}

// vim:set tabstop=4 shiftwidth=4 expandtab:
