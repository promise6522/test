/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/

#include"ac_execution_helper.h"
#include"ac_execution/func_corpse.h"
#include"ac_object/obj_impl_corpse.h"
#include"ac_object/obj_impl_string.h"


func_corpse::func_corpse(const nb_id_t& obj_id,
        content& raw_data,
        execution_id_t& exec_id,
        ac_execution_helper* pHelper)
    : execution_base(obj_id, exec_id, pHelper), m_is_single(false)
{
    nb_id_t id;
    obj_impl_corpse::unpack(raw_data, id, m_cData);
    assert(id == obj_id);
}

func_corpse::func_corpse(): m_is_single(false)
{
}

func_corpse::~func_corpse()
{
}

bool func_corpse::get_name(nb_id_t& out)
{
    return request_string_object("corpse", out);
}

bool func_corpse::set_type(const nb_id_t& type_id)
{
    return true;
}

bool func_corpse::get_type(nb_id_t& type_id)
{
    type_id = nb_id_t(NB_INTERFACE_CORPSE);
    return true;
}

bool func_corpse::run()
{
    LOG_DEBUG("*** func_corpse::run()");

    node_invocation_response response;
    bool ret = true;

    switch (m_param.declaration_id.get_func_type())
    {
        case NB_FUNC_GENERAL_GET_NAME:
        {
            nb_id_t result;
            ret = get_name(result);
            response.output.objects.push_back(result);
            break;
        }
        case NB_FUNC_CORPSE_GET_NODE_INDEX:
            response.output.objects.push_back(m_cData.node_index);
            break;
        case NB_FUNC_CORPSE_GET_INPUT:
            response.output.objects = m_cData.inputs;
            break;
        case NB_FUNC_CORPSE_GET_SUB_OBJ:
            response.output.objects.push_back(m_cData.sub_corpse);
            break;
        case NB_FUNC_CORPSE_GET_REASON:
            response.output.objects.push_back(m_cData.reason);
            break;
        case NB_FUNC_CORPSE_PRINT:
            if (m_cData.sub_corpse.is_null())
            {
                m_is_single = true;
                return print_format_async();
            }
            else
            {
                print_format_async();

                node_invocation_request request;
                request.execution_id = m_param.execution_id;
                request.transaction_id = m_param.transaction_id;
                request.host_committer_id = m_param.host_committer_id;
                request.declaration_id = nb_id_t(NB_FUNC_CORPSE_PRINT);
                return object_run(m_cData.sub_corpse, 2, request);
            }
            break;
        default:
            return execution_base::run();
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

bool func_corpse::obj_run_response(req_num_t req_num, node_invocation_response& response)
{
    return object_get_value_async(response.output.objects[0], req_num);
}

bool func_corpse::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_corpse::get_value_response");

    std::string strval;
    nb_id_t strid;
    obj_impl_string::unpack(output, strid, strval);

    node_invocation_response response;
    response.child_transaction = m_param.transaction_id;

    if (req_num_t(1) == req_num)
    {
        if (m_is_single)
        {
            m_value = assemb_string() + strval;
            response.output.objects.push_back(this->request_string_id(m_value));
            response.success = true;
            return run_respond(response);
        }
        else
        {
            m_value = assemb_string() + strval + "\n---------------------------------------------------------\n";
        }
    }
    else if (req_num_t(2) == req_num)
    {
        std::string result = m_value + strval;
        response.output.objects.push_back(this->request_string_id(result));
        response.success = true;
        return run_respond(response);
    }
    else
    {
        LOG_ERROR("corpse request number error!");
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    return true;
}

nb_id_t func_corpse::request_string_id(const std::string& result)
{
    request_nb_id_info nb_info;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_STRING;
    obj_impl_string::pack(result, nb_id_t(), nb_info.raw_data);

    nb_id_t out;
    request_nb_id(m_param.host_committer_id, nb_info, out, false);
    return out;
}

bool func_corpse::print_format_async()
{
    return object_get_value_async(m_cData.reason, 1);
}

std::string func_corpse::assemb_string()
{
    std::string new_str;

    new_str += "impl_name: " + m_cData.name;
    new_str.append("\n");
    
    new_str += "implpment_id: " + m_cData.implement_id.str();
    new_str.append("\n");

    int index = 0;
    m_cData.node_index.get_value(index);
    new_str += "node_index: " + to_string(index);
    new_str.append("\n");

    if (m_cData.object_id.is_value_null())
        new_str += "container_id: " + m_cData.container_id.str();
    else
        new_str += "object_id: " + m_cData.object_id.str();
    new_str.append("\n");

    int num = m_cData.inputs.size();
    new_str += "inputs_size [" + to_string(num) + "]: ";
    new_str.append("\n");
    for (int i = 0; i < num; ++i)
    {
        new_str.append(1, '\t');
        new_str += "input " + to_string(i) + ": " + m_cData.inputs[i].str();
        new_str.append("\n");
    }
    new_str += "reason: ";
    return new_str;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
