/**************************************************************************
**
**  Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_execution_helper.h"
#include "ac_execution/func_array.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface_compound.h"

func_array::func_array(const nb_id_t& obj_id, 
        const content& raw_data,
        const execution_id_t& exe_id, 
        ac_execution_helper * pHelper)
: execution_base(obj_id, exe_id, pHelper)
{
    //assert(obj_id.is_object_array());
    nb_id_t id;    
    obj_impl_array::unpack(raw_data, id, m_cData);
    //assert(id == obj_id);    
} 

func_array::~func_array()
{
}

bool func_array::get_name(nb_id_t& out)
{
    return request_string_object("array", out); 
}

bool func_array::set_interface(const nb_id_t& if_id)
{
    return true;
}

bool func_array::get_interface(nb_id_t& if_id)
{
    if_id = nb_id_t(NB_INTERFACE_ARRAY);
    return true;
}

bool func_array::check_exist(const nb_id_vector& vobjs, const nb_id_t& element)
{
    for (size_t i = 0; i < vobjs.size(); ++i)
        if (element == vobjs[i])
            return true;

    return false;
}

bool func_array::generate_array(const array_data_t& logic_data)
{
    LOG_DEBUG("func_array::generate_array()");

    request_nb_id_info nb_info;
    nb_id_t array_id;
    nb_info.committer_id = m_param.host_committer_id;
    nb_info.type = NBID_TYPE_OBJECT_ARRAY;
    obj_impl_array::pack(logic_data, nb_id_t(), nb_info.raw_data);
    
    if (!request_nb_id(m_param.host_committer_id, nb_info, array_id))
    {
        LOG_ERROR("func_array::generate_array():request array id failed.");
        return run_exception_respond(m_param.transaction_id);
    }

    node_invocation_response response;
    response.output.objects.push_back(array_id);
    return func_array_respond(response);
}

bool func_array::generate_two_arrays(const size_t& pos)
{
    array_data_t  array_data_1st, array_data_2nd;

    array_data_1st.type = array_data_2nd.type = m_cData.type;
    array_data_1st.objs.insert(array_data_1st.objs.begin(), m_cData.objs.begin(), m_cData.objs.begin() + pos);
    array_data_2nd.objs.insert(array_data_2nd.objs.begin(), m_cData.objs.begin() + pos, m_cData.objs.end());

    node_invocation_response response;

    request_nb_id_info array_info;
    nb_id_t array_id;
    array_info.committer_id = m_param.host_committer_id;
    array_info.type = NBID_TYPE_OBJECT_ARRAY;
    // first semi-array
    obj_impl_array::pack(array_data_1st, nb_id_t(), array_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, array_info, array_id))
    {
        LOG_ERROR("func_array:request first array id failed.");
        return run_exception_respond(m_param.transaction_id);
    }
    response.output.objects.push_back(array_id);

    // second semi-array
    obj_impl_array::pack(array_data_2nd, nb_id_t(), array_info.raw_data);

    if (!request_nb_id(m_param.host_committer_id, array_info, array_id))
    {
        LOG_ERROR("func_array:request second array id failed.");
        return run_exception_respond(m_param.transaction_id);
    }
    response.output.objects.push_back(array_id);

    return func_array_respond(response);
}

bool func_array::set_type()
{
    LOG_DEBUG("func_array::set_type()");
    
    if (m_param.input.size() != 1 || m_cData.objs.size() != 0 || !m_param.input[0].is_interface())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    nb_id_t array_id;
    node_invocation_response response;

    if (execution_base::generate_array(m_cData.objs, m_param.input[0], array_id))
        response.output.objects.push_back(array_id);
    else
    {
        LOG_ERROR("request array_id failed");
        return run_exception_respond(m_param.transaction_id);
    }

    return func_array_respond(response);
}

bool func_array::get_type()
{
    LOG_DEBUG("func_array::get_type()");

    node_invocation_response response;
    response.output.objects.push_back(m_type);
    return func_array_respond(response);
}

bool func_array::get()
{
    LOG_DEBUG("func_array::get()");

    if (m_param.input.size() != 1 || !m_param.input[0].is_object_integer())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    int index;
    m_param.input[0].get_value(index);

    if (index < 0 || (uint32_t)index >= m_cData.objs.size())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    node_invocation_response response;
    response.output.objects.push_back(m_cData.objs[index]);
    return func_array_respond(response);
}

bool func_array::get_head()
{
    LOG_DEBUG("func_array::get_head()");

    if (m_cData.objs.size() <= 0)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    node_invocation_response response;
    response.output.objects.push_back(m_cData.objs[0]);
    return func_array_respond(response);
}

bool func_array::get_tail()
{
    LOG_DEBUG("func_array::get_tail()");

    if (m_cData.objs.size() <= 0)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    node_invocation_response response;
    response.output.objects.push_back(m_cData.objs[m_cData.objs.size() - 1]);
    return func_array_respond(response);
}

bool func_array::size()
{
    LOG_DEBUG("func_array::size()");

    nb_id_t array_size(NBID_TYPE_OBJECT_INT);
    array_size.set_value(m_cData.objs.size());

    node_invocation_response response;
    response.output.objects.push_back(array_size);
    return func_array_respond(response);
}

bool func_array::set()
{
    LOG_DEBUG("func_array::set()");

    if (m_param.input.size() != 2 || !m_param.input[0].is_object_integer())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    int index;
    m_param.input[0].get_value(index);

    if (index < 0 || (uint32_t)index >= m_cData.objs.size())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    array_data_t  array_data = m_cData;
    array_data.objs[index] = m_param.input[1];

    return generate_array(array_data);
}

bool func_array::insert()
{
    LOG_DEBUG("func_array::insert)");

    if (m_param.input.size() != 2 || !m_param.input[0].is_object_integer())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    int index;
    m_param.input[0].get_value(index);

    if (index < 0 || (uint32_t)index > m_cData.objs.size())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    array_data_t  array_data = m_cData;
    array_data.objs.insert(array_data.objs.begin() + index, m_param.input[1]);

    return generate_array(array_data);
}

bool func_array::add_head()
{
    LOG_DEBUG("func_array::add_head()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    array_data_t  array_data = m_cData;
    array_data.objs.insert(array_data.objs.begin(), m_param.input[0]);
    
    return generate_array(array_data);
}

bool func_array::add_tail()
{
    LOG_DEBUG("func_array::add_tail()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    array_data_t  array_data = m_cData;
    array_data.objs.push_back(m_param.input[0]);

    return generate_array(array_data);
}

bool func_array::find()
{
    LOG_DEBUG("func_array::find()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    m_find = false;
    m_compare_cnt = 0;

    size_t index;
    for (index = 0; index < m_cData.objs.size(); ++index)
    {
        node_invocation_request req = m_param;
        req.declaration_id = nb_id_t(NB_FUNC_GENERAL_COMPARE);
        req.input.clear();
        req.input.push_back(m_param.input[0]);

        begin_incoming_ins_call(index, NB_FUNC_GENERAL_COMPARE);
        object_run(m_cData.objs[index], index, req);
    }

    return true;
}

bool func_array::erase()
{
    LOG_DEBUG("func_array::erase()");

    if (m_param.input.size() != 1)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    int index;
    m_param.input[0].get_value(index);

    if (index < 0 || (uint32_t)index >= m_cData.objs.size())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    array_data_t  array_data = m_cData;
    array_data.objs.erase(array_data.objs.begin() + index);

    return generate_array(array_data);
}

bool func_array::reverse()
{
    LOG_DEBUG("func_array::reverse()");

    array_data_t  array_data = m_cData;
    std::reverse(array_data.objs.begin(), array_data.objs.end());

    return generate_array(array_data);
}

bool func_array::range()
{
    LOG_DEBUG("func_array::range()");

    if (m_param.input.size() != 2 || !m_param.input[0].is_object_integer() 
                                  || !m_param.input[1].is_object_integer())
    {
        LOG_ERROR("func_array::range():invalid params");
        return run_exception_respond(m_param.transaction_id);
    }

    int index_1st, index_2nd;
    m_param.input[0].get_value(index_1st);                                           
    m_param.input[1].get_value(index_2nd);                                           

    if (index_1st > index_2nd || index_1st < 0 || (uint32_t)index_2nd >= m_cData.objs.size())
    {
        LOG_ERROR("func_array::range():params out of range");
        return run_exception_respond(m_param.transaction_id);
    }

    array_data_t  array_data;
    array_data.type = m_cData.type;

    for (int i = index_1st; i <= index_2nd; ++i)
        array_data.objs.push_back(m_cData.objs[i]);
    
    return generate_array(array_data);
}

bool func_array::split()
{
    LOG_DEBUG("func_array::split()");

    size_t pos = m_cData.objs.size() / 2;

    return generate_two_arrays(pos);
}

bool func_array::split_at()
{
    LOG_DEBUG("func_array::split_at()");

    if (m_param.input.size() != 1 || !m_param.input[0].is_object_integer())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    int pos;
    m_param.input[0].get_value(pos);

    if (pos <= 0 || (uint32_t)pos >= m_cData.objs.size())
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    return generate_two_arrays(pos);
}

bool func_array::join(nb_id_vector& input)
{
    LOG_DEBUG("func_array::join()");

    array_data_t array_data = m_cData;

    for (size_t i = 0; i < input.size(); ++i)       
        array_data.objs.push_back(input[i]);

    return generate_array(array_data);
}

bool func_array::union_set(nb_id_vector& input)
{
    LOG_DEBUG("func_array::union_set()");

    array_data_t array_data;
    array_data.type = m_cData.type;
    input.insert(input.end(), m_cData.objs.begin(), m_cData.objs.end());

    for (size_t i = 0; i < input.size(); ++i)       
        if (!check_exist(array_data.objs, input[i]))
            array_data.objs.push_back(input[i]);

    return generate_array(array_data);
}

bool func_array::intersection_set(nb_id_vector& input)
{
    LOG_DEBUG("func_array::intersection_set()");

    array_data_t array_data;
    array_data.type = m_cData.type;

    for (size_t i = 0; i < input.size(); ++i)       
        if (check_exist(m_cData.objs, input[i]) && !check_exist(array_data.objs, input[i]))
            array_data.objs.push_back(input[i]);

    return generate_array(array_data);
}

bool func_array::complementary_set(nb_id_vector& input)
{
    LOG_DEBUG("func_array::complementary_set()");

    array_data_t array_data = m_cData;

    bool result = true;
    for (size_t i = 0; i < input.size(); ++i)       
    {
        for (size_t j = 0; j < array_data.objs.size(); ++j)
        {
            if (array_data.objs[j] == input[i])
            {
                array_data.objs.erase(array_data.objs.begin() + j);
                break;
            }
            else if (j == array_data.objs.size() - 1)
                result = false;
        }

        if (!result) break;
    }

    if (!result)
        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

    return generate_array(array_data);
}

bool func_array::inclusion(nb_id_vector& input)
{
    LOG_DEBUG("func_array::inclusion()");

    nb_id_vector  main_objs = m_cData.objs;

    bool result = true;
    for (size_t i = 0; i < input.size(); ++i)       
    {
        for (size_t j = 0; j < main_objs.size(); ++j)
        {
            if (main_objs[j] == input[i])
            {
                main_objs.erase(main_objs.begin() + j);
                break;
            }
            else if (j == main_objs.size() - 1)
                result = false;
        }

        if (!result) break;
    }

    nb_id_t res_id(NBID_TYPE_OBJECT_BOOL);
    res_id.set_value(result);

    node_invocation_response response;
    response.output.objects.push_back(res_id);
    return func_array_respond(response);
}

bool func_array::run()
{
    LOG_DEBUG("func_array::run()");

    node_invocation_response response;
    bool ret = true;

    LOG_NOTICE("func_array:run():decl id:" << m_param.declaration_id.str());

    if (m_param.declaration_id.is_object_decl_expanded())
    {
        req_num_t req_num = generate_req_num();    
        begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_INIT);

        return object_get_value_async(m_cData.type, req_num);
    }
    else
    {
        switch (m_param.declaration_id.get_func_type())
        {
            case NB_FUNC_GENERAL_GET_NAME:
            {
                nb_id_t result;
                ret = get_name(result);
                response.output.objects.push_back(result);
                break;
            }
            case NB_FUNC_GENERAL_GET_INTERFACE:
            {
                response.output.objects.push_back(m_cData.type);
                break;
            }
            default:
                return execution_base::run();
        }
    }

    response.success = ret;
    response.child_transaction = m_param.transaction_id;
    return run_respond(response);
}

////////////////////////////////response

bool func_array::get_value_response(req_num_t req_num, content& output)
{
    LOG_DEBUG("*** func_array::get_value_response");

    nb_builtin_instruction_t builtin_ins;

    if (!get_ins_call(req_num, builtin_ins))
    {
        LOG_ERROR("func_array::get_value_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
    }

    if (NB_FUNC_GENERAL_RUN == builtin_ins)
    {
        return execution_base::get_value_response(req_num, output);
    }

    end_incoming_ins_call(req_num);

    if (builtin_ins == NB_FUNC_GENERAL_GET_DECLARATION)
    {
        decl_expanded_data_t data;
        nb_id_t id;
        obj_impl_decl_expanded::unpack(output, id, data);

        if (!data.origin_decl_id.is_object_declaration())
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);

        switch (data.origin_decl_id.get_func_type())
        {
            case NB_FUNC_ARRAY_SETTYPE:
                return set_type();
            case NB_FUNC_ARRAY_GETTYPE:
                return get_type();
            case NB_FUNC_ARRAY_GET:
                return get();
            case NB_FUNC_ARRAY_GETHEAD:
                return get_head();
            case NB_FUNC_ARRAY_GETTAIL:
                return get_tail();
            case NB_FUNC_ARRAY_SIZE:
                return size();
            case NB_FUNC_ARRAY_SET:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(req_num, NB_FUNC_ARRAY_SET);
                    else
                        return set();
                }
            case NB_FUNC_ARRAY_INSERT:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(req_num, NB_FUNC_ARRAY_INSERT);
                    else
                        return insert();
                }
            case NB_FUNC_ARRAY_ADDHEAD:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(req_num, NB_FUNC_ARRAY_ADDHEAD);
                    else
                        return add_head();
                }
            case NB_FUNC_ARRAY_ADDTAIL:
                {
                    if (_TYPE_CHECKING)
                        return prepare_add_element(req_num, NB_FUNC_ARRAY_ADDTAIL);
                    else
                        return add_tail();
                }
            case NB_FUNC_ARRAY_FIND:
                return find();
            case NB_FUNC_ARRAY_ERASE:
                return erase();
            case NB_FUNC_ARRAY_REVERSE:
                return reverse();
            case NB_FUNC_ARRAY_RANGE:
                return range();
            case NB_FUNC_ARRAY_SPLIT:
                return split();
            case NB_FUNC_ARRAY_SPLITAT:
                return split_at();
            case NB_FUNC_ARRAY_JOIN:
            case NB_FUNC_ARRAY_UNIONSET:
            case NB_FUNC_ARRAY_INTERSECTIONSET:
            case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            case NB_FUNC_ARRAY_INCLUSION:
                {
                    if (m_param.input.size() != 1 || !m_param.input[0].is_object_array())
                        return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_INVALID);

                    begin_incoming_ins_call(req_num, data.origin_decl_id.get_func_type());

                    return object_get_value_async(m_param.input[0], req_num);
                }
            default:
                {
                    LOG_ERROR("func_array:invalid instruction");
                    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
                }
        }
    }
    else if (builtin_ins == NB_FUNC_GENERAL_INIT)
    {
        LOG_NOTICE("func_array::initialize");

        nb_id_t id;
        if_compound_data_t if_data;
        obj_impl_interface_compound::unpack(output, id, if_data);

        if (if_data.groups.size() != 1)
        {
            LOG_ERROR("func_array:get_invalid_interface_compound");
            return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
        }

        m_type = if_data.groups[0].min_if;

        begin_incoming_ins_call(req_num, NB_FUNC_GENERAL_GET_DECLARATION);
        return object_get_value_async(m_param.declaration_id, req_num);
    }
    else if (builtin_ins == NB_FUNC_ARRAY_JOIN || builtin_ins == NB_FUNC_ARRAY_UNIONSET ||
             builtin_ins == NB_FUNC_ARRAY_INTERSECTIONSET || builtin_ins == NB_FUNC_ARRAY_COMPLEMENTARYSET ||
             builtin_ins == NB_FUNC_ARRAY_INCLUSION)
    {
        nb_id_t id;
        array_data_t in_array;
        obj_impl_array::unpack(output, id, in_array);

        if (_TYPE_CHECKING)
        {
            node_invocation_request request;
            request.transaction_id = m_param.transaction_id;
            request.host_committer_id = m_param.host_committer_id;
            request.execution_id = m_param.execution_id;
            // array type is compound interface which only uses the following instruction
            request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_EQ);
            request.input.push_back(m_cData.type);

            instruction_pair_t call_pair;
            call_pair.first = builtin_ins;
            call_pair.second = NB_FUNC_INTERFACE_EQ;

            insert_num_ins_pair(req_num, call_pair);
            m_req_input.begin_incoming_req_info(req_num, in_array);

            return object_run(in_array.type, req_num, request);
        }
        else
        {
            switch (builtin_ins)
            {
                case NB_FUNC_ARRAY_JOIN:
                    return join(in_array.objs);
                case NB_FUNC_ARRAY_UNIONSET:
                    return union_set(in_array.objs);
                case NB_FUNC_ARRAY_INTERSECTIONSET:
                    return intersection_set(in_array.objs);
                case NB_FUNC_ARRAY_COMPLEMENTARYSET:
                    return complementary_set(in_array.objs);
                case NB_FUNC_ARRAY_INCLUSION:
                    return inclusion(in_array.objs);
                default:
                    {
                        LOG_ERROR("func_array::get_value_response::invalid instruction");
                        return run_exception_respond(m_param.transaction_id);
                    }
            }
        }
    }

    LOG_ERROR("func_map::get_value_response() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_GET_VALUE_FAILED);
}

bool func_array::prepare_add_element(const req_num_t& req_num, const nb_builtin_instruction_t& call)
{
    LOG_INFO("func_array::prepare_add_element()");

    node_invocation_response response;

    if (m_type.is_builtin_interface())
    {
        nb_id_t  in_if;
        if (call == NB_FUNC_ARRAY_SET || call == NB_FUNC_ARRAY_INSERT)
            m_param.input[1].get_builtin_interface(in_if);
        else if (call == NB_FUNC_ARRAY_ADDHEAD || call == NB_FUNC_ARRAY_ADDTAIL)
            m_param.input[0].get_builtin_interface(in_if);
        else
            return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

        if (m_type != in_if && !m_type.is_interface_none())
        {
            LOG_INFO("func_array::prepare_add_element=> Builtin type match failed");
            return run_exception_respond(m_param.transaction_id, CORPSE_ARRAY_TYPE_NOT_MATCH);
        }

        if (call == NB_FUNC_ARRAY_SET)
            return set();
        else if (call == NB_FUNC_ARRAY_INSERT)
            return insert();
        else if (call == NB_FUNC_ARRAY_ADDHEAD)
            return add_head();
        else
            return add_tail();
    }
    else  
    {
        nb_id_t  in;
        if (call == NB_FUNC_ARRAY_SET || call == NB_FUNC_ARRAY_INSERT)
            in = m_param.input[1];
        else if (call == NB_FUNC_ARRAY_ADDHEAD || call == NB_FUNC_ARRAY_ADDTAIL)
            in = m_param.input[0];
        else
            return run_exception_respond(m_param.transaction_id, CORPSE_INPUT_NUM_IS_WRONG);

        node_invocation_request request;
        request.transaction_id = m_param.transaction_id;
        request.host_committer_id = m_param.host_committer_id;
        request.execution_id = m_param.execution_id;
        request.declaration_id = nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE);

        instruction_pair_t call_pair;
        call_pair.first = call;
        call_pair.second = NB_FUNC_GENERAL_GET_INTERFACE;

        insert_num_ins_pair(req_num, call_pair);

        if (in.is_object_access())
        {
            access_id_t access_id; 
            in.to_access_id(access_id);
            return access_run(access_id, req_num, request);
        }
        else
            return object_run(in, req_num, request);
    }
}

bool func_array::obj_run_response(req_num_t req_num, node_invocation_response& output)
{
    nb_builtin_instruction_t builtin_ins;
    if (get_ins_call(req_num, builtin_ins))
    {
        switch(builtin_ins)
        {
            case NB_FUNC_GENERAL_RUN:
                end_incoming_ins_call(req_num);
                return execution_base::obj_run_response(req_num, output);
            case NB_FUNC_GENERAL_COMPARE:
            {
                end_incoming_ins_call(req_num);
                if ((3 != output.output.objects.size())
                        || !output.output.objects[0].is_object_bool()
                        || !output.output.objects[1].is_object_bool()
                        || !output.output.objects[2].is_object_bool())
                    {
                        LOG_ERROR("func_array::obj_run_response():compare:invalid response");
                        return run_exception_respond(m_param.transaction_id);
                    }

                int array_size = m_cData.objs.size();
                m_compare_cnt++;
                bool ret;
                output.output.objects[1].get_value(ret);
                if (ret)
                {
                    m_find = true;
                    node_invocation_response response;
                    nb_id_t res_id(NBID_TYPE_OBJECT_INT);
                    int index = req_num;
                    res_id.set_value(index);
                    response.output.objects.push_back(res_id);
                    return func_array_respond(response);
                }
                else if (m_compare_cnt == array_size && !m_find)
                {
                    node_invocation_response response;
                    nb_id_t res_id(NBID_TYPE_OBJECT_NONE);
                    response.output.objects.push_back(res_id);
                    return func_array_respond(response);
                }
                return true;
            }
            default:
                break;
        }
    }

    instruction_pair_t call_pair;

    if (!output.success || !get_ins_pair(req_num, call_pair))
    {
        LOG_ERROR("func_array::obj_run_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    erase_num_ins_pair(req_num);
    
    if (NB_FUNC_GENERAL_GET_INTERFACE == call_pair.second)
    {
        LOG_DEBUG("func_array::obj_run_response():get_interface_response");

        //assert(1 == output.output.objects.size());
        if(1 != output.output.objects.size())
        {
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        }

        node_invocation_request request = m_param;
        request.input.clear();
        request.input.push_back(output.output.objects[0]);

        LOG_NOTICE("insert object:"<<request.input[0].str());
        LOG_NOTICE("insert object if:"<< output.output.objects[0].str());
        LOG_NOTICE("array type:"<<m_type.str());

        if (m_type.is_interface_bridge())
        {
            call_pair.second = NB_FUNC_BRIDGE_INTERFACE_COVERS;
            insert_num_ins_pair(req_num, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_BRIDGE_INTERFACE_COVERS);
            return object_run(m_type, req_num, request);
        }
        else if (m_type.is_compound_interface()) 
        {
            call_pair.second = NB_FUNC_INTERFACE_COVERS;
            insert_num_ins_pair(req_num, call_pair);
            request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);
            return object_run(m_type, req_num, request);
        }
        else 
        {
            LOG_ERROR("func_array::obj_run_response():invalid object type");
            return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
        }
    }
    else if (NB_FUNC_BRIDGE_INTERFACE_COVERS == call_pair.second || NB_FUNC_INTERFACE_COVERS == call_pair.second)
    {
        LOG_DEBUG("func_array::obj_run_response():if_cover_response");

        //assert(1 == output.output.objects.size());
        if(1 != output.output.objects.size()) 
        { 
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        }

        bool result;
        output.output.objects[0].get_value(result);

        if (!result)
        {
            LOG_ERROR("func_array::obj_run_response():object type cover failed");
            return run_exception_respond(m_param.transaction_id);
        }

        switch (call_pair.first)
        {
            case NB_FUNC_ARRAY_SET:
                return set();
            case NB_FUNC_ARRAY_INSERT:
                return insert();
            case NB_FUNC_ARRAY_ADDHEAD:
                return add_head();
            case NB_FUNC_ARRAY_ADDTAIL:
                return add_tail();
            default:
                {
                    LOG_ERROR("func_array::obj_run_response():invalid calling instruction for if cover");
                    return run_exception_respond(m_param.transaction_id);
                }
        }
    }
    else if (NB_FUNC_INTERFACE_EQ == call_pair.second)
    {
        LOG_DEBUG("func_array::obj_run_response():if_eq_response");

        //assert(1 == output.output.objects.size());
        if(1 != output.output.objects.size()) 
        { 
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        }

        bool result;
        output.output.objects[0].get_value(result);

        if (!result)
        {
            LOG_ERROR("func_array::obj_run_response():interface match failed");
            return run_exception_respond(m_param.transaction_id);
        }

        switch (call_pair.first)
        {
            case NB_FUNC_ARRAY_JOIN:
            case NB_FUNC_ARRAY_UNIONSET:
            case NB_FUNC_ARRAY_INTERSECTIONSET:
            case NB_FUNC_ARRAY_COMPLEMENTARYSET:
            case NB_FUNC_ARRAY_INCLUSION:
                {
                    array_data_t arr_data;
                    m_req_input.get_req_info(req_num, arr_data);
                    m_req_input.end_incoming_req_info(req_num);

                    if (call_pair.first == NB_FUNC_ARRAY_JOIN)
                        return join(arr_data.objs);
                    if (call_pair.first == NB_FUNC_ARRAY_UNIONSET)
                        return union_set(arr_data.objs);
                    if (call_pair.first == NB_FUNC_ARRAY_INTERSECTIONSET)
                        return intersection_set(arr_data.objs);
                    if (call_pair.first == NB_FUNC_ARRAY_COMPLEMENTARYSET)
                        return complementary_set(arr_data.objs);
                    else
                        return inclusion(arr_data.objs);
                }
            default:
                {
                    LOG_ERROR("func_array::obj_run_response():invalid calling instruction for compound if cover");
                    return run_exception_respond(m_param.transaction_id);
                }
        }
    }

    LOG_ERROR("func_array::obj_run_response() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_array::access_run_response(req_num_t req_num, node_invocation_response& output)
{
    instruction_pair_t call_pair;

    if (!output.success || !get_ins_pair(req_num, call_pair))
    {
        LOG_ERROR("func_array::access_run_response() failed");
        return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
    }

    erase_num_ins_pair(req_num);

    if (NB_FUNC_GENERAL_GET_INTERFACE == call_pair.second)
    {
        LOG_DEBUG("func_array::access_run_response():get_interface_response");

        //assert(1 == output.output.objects.size());
        if(1 != output.output.objects.size()) 
        { 
            return run_exception_respond(m_param.transaction_id, CORPSE_OUTPUT_NUM_IS_WRONG);
        }

        node_invocation_request request = m_param;
        request.input.clear();
        request.input.push_back(output.output.objects[0]);
        request.declaration_id = nb_id_t(NB_FUNC_INTERFACE_COVERS);

        call_pair.second = NB_FUNC_INTERFACE_COVERS;
        insert_num_ins_pair(req_num, call_pair);

        return object_run(m_type, req_num, request);
    }

    LOG_ERROR("func_array::obj_run_response() failed");
    return run_exception_respond(m_param.transaction_id, CORPSE_OBJ_RUN_FAILED);
}

bool func_array::func_array_respond(node_invocation_response& response)
{
    LOG_DEBUG("*** func_array::func_array_respond()");

    response.success = true;
    response.child_transaction = m_param.transaction_id;

    return run_respond(response);
}
// vim:set tabstop=4 shiftwidth=4 expandtab:

