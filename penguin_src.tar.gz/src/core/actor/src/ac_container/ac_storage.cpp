/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include "ac_storage.h"
#include "ac_facade/storage_db_base.h"

bool ac_storage::initialization()
{
	assert(m_ptrHelper);
	time_t tm;    
	time(&tm);
	req_num_t req_num = req_num_t(tm, true);

	storage_ids input;
	input.ids.push_back(m_id);

    // reopen the storage db
    m_ptrDb.reset(new(std::nothrow) storage_db_base(ac_storage_env_impl::instance().get_env(), m_id.str())); 

	m_ptrHelper->ac_object_db_read_storages(++req_num, input);

	return true;
}

bool ac_storage::initialization(const content& data)
{
    assert(m_ptrHelper);

    // create the storage db by roger
    m_ptrDb.reset(new(std::nothrow) storage_db_base(ac_storage_env_impl::instance().get_env(), m_id.str()));
   
    write_version = 0; 
    m_version = 0; 
    //set data by impl
    m_ptrImpl.reset(new(std::nothrow) storage_implementation(m_id, 
		data, 
		m_ptrHelper.get()));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_storage::get_value_sync(content& output)
{
    assert(m_init_status == ac_init_success);
    assert(m_ptrImpl);
    return m_ptrImpl->get_value(output);    
}

bool ac_storage::get_value_async(call_id_t call_id)
{    
    //assert(m_ptrImpl && m_ptrHelper);
    std::string val("ac_storage initialization");
    if(!this->has_impl_ptr())
        return m_ptrHelper->exception_respond(call_id, val);

    content value;
    if(!m_ptrImpl->get_value(value))
	    assert(true);

    return m_ptrHelper->ac_storage_get_value_async_respond(call_id,
	    value); 
}

bool ac_storage::exception_handle(req_num_t req_num, const std::string& str)
{    
    return ac_actor::exception_handle(req_num, str);    
}

bool ac_storage::ac_object_db_read_storages_response(req_num_t req_num, db_value& output)
{
    assert(m_ptrHelper);
    //assert (0 < output.all_objects.size());
    if(0 == output.all_objects.size())
    {
        LOG_ERROR("ac_storage intialization failed");
        m_ptrHelper->initialization_respond_fail();
        return false;
    }

    m_ptrImpl.reset(new(std::nothrow) storage_implementation(m_id, output.all_objects[0], m_ptrHelper.get()));

    m_ptrHelper->initialization_respond();

    return true;
}

bool ac_storage::has_impl_ptr() const
{
    return (NULL != m_ptrImpl.get());
}

// ========== add by roger
bool ac_storage::get_range(call_id_t call_id, const key_pair_version& input)
{
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;
 
    key_pair iparam;
    iparam.start_num = input.start_num;
    iparam.end_num = input.end_num;

    DbTxn* txn = NULL;
    get_version_txn(input.version, txn);
    m_ptrDb->get_range(iparam, id_pair, txn);

    key_pair_no_version1 output;
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        key_obj_id tmp;
        tmp.key_id.str(const_iter->first.str());
        tmp.obj_id.str(const_iter->second.str());
        output.key_obj_ids.push_back(tmp);
    }

    return m_ptrHelper->ac_storage_get_range_respond(call_id, output);
}
    
bool ac_storage::commit(const storage_version& input, bool& output)
{
    DbTxn* txn = NULL;
    get_version_txn(input.version, txn);
    
    if (txn == NULL)
        return false;
    bool ret = m_ptrDb->commit(txn);
    if (ret)
    {
        end_incoming_txn(input.version);
        LOG_NOTICE("ac_storage::commit success. version:" << input.version);
    }
    ++this->m_version;
    write_version = 0;
    output = ret;
    return ret;
    //return m_ptrHelper->ac_storage_commit_respond(call_id, ret);
}

bool ac_storage::size(call_id_t call_id, const storage_version& input)
{
    DbTxn* txn = NULL;
    //get_version_txn(input.version, txn);

    int count(0);
    count = m_ptrDb->size(txn);
    duke_integer output;
    output.integer = count;
    return m_ptrHelper->ac_storage_size_respond(call_id, output); 
}
    
bool ac_storage::rollback(const storage_version& input, bool& output)
{
    DbTxn* txn = NULL;
    bool ret(true);
    get_version_txn(input.version, txn);
    if (txn != NULL)
    {
        ret = m_ptrDb->rollback(txn);
        if (ret)
        {
            end_incoming_txn(input.version);
            LOG_NOTICE("ac_storage::rollback fail. version:" << input.version);
        }
    }
    ++this->m_version;
    write_version = 0;
    output = ret;
    return ret;
    //return m_ptrHelper->ac_storage_rollback_respond(call_id, ret);
}
    
bool ac_storage::has_key(call_id_t call_id, const key_array_version& input)
{
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;

    DbTxn* txn = NULL;
    get_version_txn(input.version, txn);
    m_ptrDb->has_key(input.keys, id_pair, txn);

    key_array output;
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        output.keys.push_back(const_iter->first);
    }
    return m_ptrHelper->ac_storage_has_key_respond(call_id, output);
}
    
bool ac_storage::update(call_id_t call_id, const sv_update_input_version& input)
{ 
    struct sv_update_output output;
    if (input.version < 0)
        return m_ptrHelper->ac_storage_update_respond(call_id, output);

    if (write_version == 0)
        write_version = input.version;
    else if (write_version != input.version)
        return m_ptrHelper->ac_storage_update_respond(call_id, output);
    
    std::vector<std::pair<nb_id_t, nb_id_t> > s_map, r_map, r_o_map;
    std::vector<nb_id_t> d_i_key, s_o_key, d_o_o;
    std::vector<key_obj_id>::const_iterator const_it;
    std::vector<nb_id_t>::const_iterator const_iter;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator r_it;

    for (const_iter = input.sv_d_update_input.keys.begin(); const_iter != input.sv_d_update_input.keys.end(); ++const_iter)
        d_i_key.push_back(*const_iter);

    for (const_it = input.sv_s_update_input.begin(); const_it != input.sv_s_update_input.end(); ++const_it)
    {
        LOG_NOTICE("################storage key:" << const_it->key_id.str() << ":" << const_it->obj_id.str());
        s_map.push_back(std::make_pair(const_it->key_id, const_it->obj_id));
    }

    for (const_it = input.sv_r_update_input.begin(); const_it != input.sv_r_update_input.end(); ++const_it)
        r_map.push_back(std::make_pair(const_it->key_id, const_it->obj_id));
    
    DbTxn* txn = NULL;
    get_version_txn(input.version, txn);
    LOG_NOTICE("ac_storage::update input.version:" << input.version);
    bool ret = m_ptrDb->update(d_i_key, s_map, r_map, d_o_o, s_o_key, r_o_map, input.version, txn);
    if (ret)
    {
        output.sv_d_update_output.keys = d_o_o;
        output.sv_s_update_output.keys = s_o_key;
        for (r_it = r_o_map.begin(); r_it != r_o_map.end(); ++r_it)
        {
            struct key_obj_id ids;
            ids.key_id = r_it->first;
            ids.obj_id = r_it->second;
            output.sv_r_update_output.push_back(ids);
        }
        return m_ptrHelper->ac_storage_update_respond(call_id, output);
    }
    else
    {
        return m_ptrHelper->ac_storage_update_respond(call_id, output);
    }
}

bool ac_storage::get_version(call_id_t call_id)
{
    unsigned int version(0);
    version = ++this->m_version;

    DbTxn* txn;
    m_ptrDb->get()->txn_snapshot_begin(txn);
    
    this->begin_incoming_txn(version, txn);
    return m_ptrHelper->ac_storage_get_version_respond(call_id, version);
}

bool ac_storage::read(call_id_t call_id, const key_array_version& input)
{
    key_pair_no_version1 output;
    std::vector<std::pair<nb_id_t, nb_id_t> > id_pair;
    std::vector<std::pair<nb_id_t, nb_id_t> >::const_iterator const_iter;

    DbTxn* txn = NULL;
    get_version_txn(input.version, txn);
    bool ret = m_ptrDb->get(input.keys, id_pair, txn);
    
    for (const_iter = id_pair.begin(); const_iter != id_pair.end(); ++const_iter)
    {
        struct key_obj_id keyobj;
        keyobj.key_id = const_iter->first;
        keyobj.obj_id = const_iter->second;
        output.key_obj_ids.push_back(keyobj);
        LOG_DEBUG("facade key-id:" << const_iter->first.str() << " obj-id:" << const_iter->second.str());
    }
    if (ret)
        return m_ptrHelper->ac_storage_read_respond(call_id, output);
    else
    {
        key_pair_no_version1 output;
        return m_ptrHelper->ac_storage_read_respond(call_id, output);
    }

}

// -============= control version funcs ================-
//
void ac_storage::begin_incoming_txn(int version, DbTxn* txn)
{
    if (m_version_txn_map.find(version) != m_version_txn_map.end())
    {
        LOG_ERROR("version has already exist in map.");
        assert(true);
    }
    m_version_txn_map.insert(std::make_pair(version, txn));

    for (version_txn_map_const_it it = m_version_txn_map.begin(); it != m_version_txn_map.end(); ++it)
    {
        LOG_NOTICE("########:first:" << it->first << " ######:second:" << it->second);
    }
}

void ac_storage::end_incoming_txn(int version)
{
    m_version_txn_map.erase(version);
}

bool ac_storage::get_version_txn(int version, DbTxn*& txn)
{
    version_txn_map_const_it it = m_version_txn_map.find(version);

    /*
    for (version_txn_map_const_it iter = m_version_txn_map.begin(); iter != m_version_txn_map.end(); ++iter)
    {
        LOG_NOTICE("########:first:" << iter->first << " ######:second:" << iter->second);
    }*/

    if (it == m_version_txn_map.end())
        return false;

    txn = it->second;

    return true;
}

bool ac_storage::destruction()
{
    for (version_txn_map_it it = m_version_txn_map.begin(); it != m_version_txn_map.end(); ++it)
    {
        m_ptrDb->rollback(it->second);
    }
    return true;
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
