/**************************************************************************
**
** 	Copyright 2011 YunCheng Inc.
**
**************************************************************************/
#include "ac_db/ac_object_db_impl.h"

#include <stdio.h>

#include "nb_profiler.h"
#include "stdx_log.h"

int ac_object_db_impl::count = 0;

ac_object_db_impl::ac_object_db_impl() : nWrites_(0), keylens_(0), vallens_(0)
{
    try
    {
        std::string dbcore = "dbcore/";
        const std::string& db_name = "objectd";
        const std::string dbhome = "dbobject";
        const std::string& dbfile = db_name + ".db";
        const std::string& dbname = "idvalue";

        // recover the database each time
        nb_mkdirs(dbcore + dbhome);
        nbnv::recover(dbcore + dbhome);

        // create database environment
        penv = new nbnv(dbcore + dbhome, SNOW_ENV_TYPE_TDS);
        pdb = new nbdb(dbfile, dbname, *penv);
        
    }
    catch (DbException& e)
    {
        LOG_ERROR("Unexpected exception : " << e.what());
    }
}

bool ac_object_db_impl::begin_txn(DbTxn*& txn)
{
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    int ret = pdb->txn_begin(txn);
    if (ret == 0)
        return true;
    else 
        return false;
}

int ac_object_db_impl::write(const std::string& strkey, const std::string& value, DbTxn* txn, int& flag)
{   
    assert(pdb != NULL);

    int index;
    {
        if ((index = find_index(txn)) == 0)
        {
            object_txn_map_type& idtxns = m_idtxns;
            boost::lock_guard<boost::mutex> guard(m_mtx_txn);
            ++count;
            flag = count;
            idtxns.insert(std::make_pair(flag, txn));
        }
        else
            flag = index;
    }

    return checked_write_(strkey, value, txn);

}

int ac_object_db_impl::write_(const std::string& strkey, const std::string& value)
{
    assert(pdb != NULL);

    // specify the txn NULL would result in an auto-commit transaction
    DbTxn* txn = NULL;

    return checked_write_(strkey, value, txn);
}

// inner implementation of write() & write_()
int ac_object_db_impl::checked_write_(const std::string& key, const std::string& value, DbTxn* txn)
{
#ifndef NDEBUG
    /* for performance evaluation */
    NEW_SCOPE_TIMER("ac_object_db_impl::write_", false);
    nWrites_++;
    keylens_ += key.size();
    vallens_ += value.size();
#endif

    int ret = 0;
    try
    {
        // ##for object_db, we don't allow overwrite
        uint32_t flags = 0;//DB_NOOVERWRITE;// = 0;
        ret = pdb->write(key, value, txn, flags);
    }
    catch (DbException& e)
    {
        ret = DB_NOTFOUND;
    }

    if (0 != ret)
    // On db write failed
    {
        LOG_ERROR(key +  ": WRITE FAILED");

        if (ret == DB_KEYEXIST)
        {
            // Overwrite detected, write to a persist log

            // read the previous value for reference
            std::string old_val;
            pdb->read(key, old_val, txn);

            // get current time
            time_t tm;
            time(&tm);

            FILE* pFile = fopen("obj_db_overwrite.log", "a");//append only
            if (pFile)
            {
                fprintf(pFile, "Overwrite detected at %s Key = %s\n OldVal = %s\n NewVal = %s\n", 
                        ctime(&tm), key.c_str(), old_val.c_str(), value.c_str());
                fclose(pFile);
            } 
        }

        return NB_DB_RESULT_FAILED;
    }

    return NB_DB_RESULT_SUCCESS;
}


int ac_object_db_impl::read(const std::string& strkey, std::string& value, int flag)
{
    assert(pdb != NULL);

    DbTxn* txn = NULL;

    if (flag != 0)
    {
        object_txn_map_type& idtxns = m_idtxns;
        boost::lock_guard<boost::mutex> guard(m_mtx_txn);
        object_txn_map_type::const_iterator it = idtxns.find(flag);
        if (it != idtxns.end())
            txn = it->second;
    }

    int ret = pdb->read(strkey, value, txn);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
    {
        LOG_ERROR(strkey +  ": NOT FOUND");
        ret = NB_DB_RESULT_NOTFOUND;
    }
    else
    {
        LOG_ERROR(strkey +  ": READ FAILED");
        ret = NB_DB_RESULT_FAILED;
    }
    return ret;
}

int ac_object_db_impl::read_(const std::string& strkey, std::string& value)
{
    assert(pdb != NULL);

    DbTxn* txn = NULL;
    int ret = pdb->read(strkey, value, txn);

    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;

    return ret;
}

bool ac_object_db_impl::read_handle(std::string& strval)
{
    assert(pdb != NULL);

    strval.clear();
    nbdbc dbc(pdb->get_db());
    std::string strkey, str_val;
    int ret;
    while ((ret = dbc.read(strkey, str_val)) == 0)
    {
        strval += "(" + strkey + ")";
    }
    return true; 
}

int ac_object_db_impl::del(const std::string& strkey)
{
    assert(pdb != NULL);
    int ret = pdb->del(strkey);
    if (ret == 0)
        ret = NB_DB_RESULT_SUCCESS;
    else if (ret == DB_NOTFOUND)
        ret = NB_DB_RESULT_NOTFOUND;
    else
        ret = NB_DB_RESULT_FAILED;
    return ret;
}

bool ac_object_db_impl::commit(int flag)
{
    assert(pdb != NULL);

    DbTxn* txn = find_txn(flag);
    int ret = pdb->commit(txn);
    return (ret == 0 ? true : false);
}

bool ac_object_db_impl::rollback(int flag)
{
    assert(pdb != NULL);
    DbTxn* txn = find_txn(flag);
    int ret = pdb->rollback(txn);
    return (ret == 0 ? true : false);
}

DbTxn* ac_object_db_impl::find_txn(int flag)
{
    assert(flag != 0);
    DbTxn* txn = NULL;
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it = idtxns.find(flag);
    if (it != idtxns.end())
    {
        txn = it->second;
        idtxns.erase(it);
    }
    return txn;
}

int ac_object_db_impl::find_index(DbTxn*& txn)
{
    object_txn_map_type& idtxns = m_idtxns;
    //boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    for (object_txn_map_type::const_iterator it = idtxns.begin(); it != idtxns.end(); ++it)
    {
        if (it->second == txn)
            return it->first;
    }
    return 0;
}

void ac_object_db_impl::close_txn()
{
    object_txn_map_type& idtxns = m_idtxns;
    boost::lock_guard<boost::mutex> guard(m_mtx_txn);
    object_txn_map_type::iterator it;
    for (it = idtxns.begin(); it != idtxns.end(); ++it)
    {
        if (it->second != NULL)
            pdb->rollback(it->second);
    }
}

ac_object_db_impl::~ac_object_db_impl(void) 
{
    if (m_idtxns.size() != 0)
    {
        this->close_txn();
    }

    if (pdb != NULL)
    {
        delete pdb;
        pdb = NULL;
    }

    if (penv != NULL)
    {
        delete penv;
        penv = NULL;
    }

#ifndef NDEBUG
    if(nWrites_)
    {
        LOG_DEBUG(" ");
        LOG_DEBUG("========== ac_object_db ==========");
        LOG_DEBUG("total writes : "<< nWrites_/* << "    transactional : "<< nTxnWrites_*/);
        LOG_DEBUG("KEY-SIZE  avg : "<< keylens_/nWrites_ << "    total : "<< keylens_);
        LOG_DEBUG("VAL-SIZE  avg : "<< vallens_/nWrites_ << "    total : "<< vallens_);
        LOG_DEBUG(" ");
    }
#endif
}

// vim:set tabstop=4 shiftwidth=4 expandtab:
