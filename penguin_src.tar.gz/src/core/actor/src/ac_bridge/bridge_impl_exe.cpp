/**************************************************************************
**
** 	Copyright 2011 Duke Inc.
**
**************************************************************************/

#include "ac_message_type.h"
#include "ac_bridge/bridge_impl_exe.h"

void bridge_impl_exe::begin_incoming_execution(req_num_t req_num, call_id_t call_id, const nb_id_t& impl_id)
{
    m_req_info_map.insert(req_exeinfo_pair(req_num, bridge_exe_info()));
    bridge_exe_info& info = m_req_info_map[req_num];

    info.call_id = call_id;
    info.req_num = req_num;
    info.impl_id = impl_id;
    info.is_corpse_run= false;
}

void bridge_impl_exe::end_incoming_execution(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool bridge_impl_exe::run_impl(call_id_t call_id, nb_id_t impl_id)
{
    //1. prepare the infomation for incoming trigger
    req_num_t req_num = generate_req_num();
    begin_incoming_execution(req_num, call_id, impl_id);
    bridge_exe_info& info = m_req_info_map[req_num]; 

    //2. create the committer and transaction
    //TBD : check the return value
    create_root_committer(info);
    create_center_committer(info);
    create_host_committer(info);
    create_transaction(info);

    node_invocation_request run_req =
    {
        execution_id_t(),
        nb_id_t(NB_FUNC_INTERFACE_GET_DECLARATIONS),
        info.trans_id,
        container_id_t(),
        info.hc_id,
        nb_id_t(NBID_TYPE_OBJECT_NONE),
        std::vector<nb_id_t>()
    };

    if(!m_pHelper->ac_object_run(impl_id, info.req_num, run_req))
    {
        //return throw_exeception(info.req_num, "Asyn call failed : ac_object_run().");
        LOG_ERROR("Asyn call failed : ac_object_run().");
    }

    return true;
}

bool bridge_impl_exe::ac_object_run_response(req_num_t req_num, node_invocation_response& data)
{
    std::map<req_num_t, bridge_exe_info>::iterator it = m_req_info_map.find(req_num);

    //error happen when impl, and get error information
    if(!it->second.is_corpse_run && !data.success && data.output.corpse.is_object_corpse())
    {
        node_invocation_request request =
        {
            execution_id_t(),
            nb_id_t(NB_FUNC_CORPSE_PRINT),
            it->second.trans_id,
            container_id_t(),
            it->second.hc_id,
            data.output.corpse,
            std::vector<nb_id_t>()
        };
        it->second.is_corpse_run = true; 
        if (!m_pHelper->ac_object_run(data.output.corpse, req_num, request))
        {
            LOG_ERROR("Asyn run corpse object failed : ac_object_run().");
        }
        return true;

    }
    
    //get value of string
    if (it->second.is_corpse_run && data.success && (1 == data.output.objects.size()) 
            && data.output.objects[0].is_object_string())
    {
        content string_content;
        if(m_pHelper->ac_object_get_value_sync(data.output.objects[0], string_content))
        {
            std::string strval;
            // print the corpse std::string strval;
            nb_id_t strid;
            obj_impl_string::unpack(string_content, strid, strval);
            LOG_WARNING("\n===================== corpse output =====================");
            LOG_WARNING(strval);
            LOG_WARNING("=========================================================\n");
            //return false;
        }
        else
        {
            LOG_ERROR("sync get string object failed");
        }
    }


    if(it != m_req_info_map.end())
    {
	bridge_exe_info& info = it->second;
	info.outputs = data.output.objects;

	object_ids objs = {it->second.outputs}	;
	if(!m_pHelper->ac_bridge_run_impl_respond(it->second.call_id, objs))
	{
		LOG_ERROR("Asyn call failed : ac_bridge_run_impl_respond().");
		return false;
	}

	/*
	if(!m_pHelper->ac_root_committer_pre_commit(info.rc_id, req_num, flag))
	{
	    LOG_ERROR("Asyn call failed : ac_root_committer_pre_commit");
	}*/
	return true;
    }
    return false;
}

bool bridge_impl_exe::ac_root_committer_pre_commit_response(req_num_t req_num, bool& output)
{
	
    if(!output)
    	LOG_ERROR("root committer pre commit response.");

    std::map<req_num_t, bridge_exe_info>::iterator it = m_req_info_map.find(req_num);

    if(it != m_req_info_map.end() )
    {    
	 if(!m_pHelper->ac_root_committer_commit(it->second.rc_id, req_num))
	 {
             LOG_ERROR("Asyn call failed : ac_root_commiter_commit().");
	     return false;
	 }

	 object_ids objs = {it->second.outputs}	;
         if(!m_pHelper->ac_bridge_run_impl_respond(it->second.call_id, objs))
         {
             LOG_ERROR("Asyn call failed : ac_bridge_run_impl_respond().");
             return false;
	 }
         return true;
    }
    return false;
}

bool bridge_impl_exe::create_root_committer(bridge_exe_info& info)
{
    //create root committer
    root_committer_id_t rc_id;
    if(!m_pHelper->ac_id_dispenser_request_root_committer_id(rc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_root_committer_id().");
        return false;
    }

    info.rc_id = rc_id;
    return true;
}

bool bridge_impl_exe::create_center_committer(bridge_exe_info& info)
{
    //create center committer
    center_committer_id_t cc_id;    
    if(!m_pHelper->ac_id_dispenser_request_center_committer_id(cc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_center_committer_id().");
        return false;
    }

    if(!m_pHelper->ac_root_committer_regist_center_committer(info.rc_id, cc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_root_committer_regist_center_committer().");
        return false;
    }

    if(!m_pHelper->ac_center_committer_set_root_committer(cc_id, info.rc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_center_committer_set_root_committer().");
        return false;
    }

    info.cc_id = cc_id;
    return true;
}

bool bridge_impl_exe::create_host_committer(bridge_exe_info& info)
{
    //create host committer
    host_committer_id_t hc_id;    
    if(!m_pHelper->ac_id_dispenser_request_host_committer_id(hc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_host_committer_id().");
        return false;
    }

    if(!m_pHelper->ac_center_committer_regist_host_committer(info.cc_id, hc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_center_committer_regist_host_committer().");
        return false;
    }

    if(!m_pHelper->ac_host_committer_set_center_committer(hc_id, info.cc_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_host_committer_set_center_committer().");
        return false;
    }

    info.hc_id = hc_id;
    return true;
}

bool bridge_impl_exe::create_transaction(bridge_exe_info& info)
{
    //create transaction
    transaction_id_t trans_id;
    if(!m_pHelper->ac_id_dispenser_request_transaction_id(info.hc_id, trans_id))
    {
        //throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_transaction_id().");
        return false;
    }

    info.trans_id = trans_id;
    return true;
}



