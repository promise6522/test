/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include "stdx_json.h"
#include "ac_bridge/ac_bridge_impl.h"
#include "ac_container/access_implementation.h"
#include "ac_bridge_helper.h"
#include "duc_parser.h"
#include "ac_global_db.h"

ac_bridge_impl::ac_bridge_impl(ac_bridge_helper * pHelper, const bridge_id_t& bridge_id)
    : bridge_impl_base(pHelper, bridge_id)
{
}

ac_bridge_impl::~ac_bridge_impl()
{
}

//for call id
void ac_bridge_impl::begin_incoming_trigger(req_num_t req_num, call_id_t call_id, const byte_stream& stream)
{
    m_req_info_map.insert(req_info_pair(req_num, bridge_info()));
    bridge_info& info = m_req_info_map[req_num];

    info.is_outgoing = false;
    info.is_run = false;
    info.is_no_builtin_decl = false;
    info.is_no_general_decl = false;
    info.is_finish = false;
    info.call_id = call_id;
    info.req_num = req_num;
    info.stream = stream;
    info.bf_id = m_bridge_content.bf_id;
    info.user_name_id = m_bridge_content.user_name_id; 

    UBuffer ubuf((uint8_t *)(&stream.data[0]), stream.data.size());
    Unpacker unpacker(ubuf);
    DUCData * pDucData = unpacker.getData();
    TInformServer* pInformServerData = dynamic_cast<TInformServer *>(pDucData);
    if (pInformServerData && pInformServerData->gesture.type == Start)
    {
        info.is_start = true;

        const TGesture& rGesture = pInformServerData->gesture;
        std::size_t sep = rGesture.text.find_first_of(default_user_pwd_separator);
        std::string user_name = rGesture.text;
        if(sep != std::string::npos)
        {                
            user_name = rGesture.text.substr(0, sep);
        }
        
        //if there is prefix '$' before user name, it means is_mode
        if((!user_name.empty()) && (user_name[0] == default_is_mode_prefix))
        {
            user_name.erase(0, 1);                
        }
        info.user_name = user_name;        
    }
    else
    {
        info.is_start = false;
    }    
}

//for call id
void ac_bridge_impl::begin_outgoing_trigger(req_num_t req_num, call_id_t call_id, const send_out_info& out_info)
{
    m_req_info_map.insert(req_info_pair(req_num, bridge_info()));
    bridge_info& info = m_req_info_map[req_num];

    info.is_outgoing = true;
    info.is_finish = false;
    info.call_id = call_id;
    info.req_num = req_num;
    info.bf_id = m_bridge_content.bf_id;
    info.user_name_id = m_bridge_content.user_name_id;

    //check the decl and judge it is a async or not
    if(out_info.decl_id.is_function_outgoing_async())
    {
        info.is_send_out_async = true;
    }
    else
    {
        info.is_send_out_async = false;
    }

    info.is_start = false;
}

void ac_bridge_impl::end_outgoing_trigger(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

void ac_bridge_impl::end_incoming_trigger(req_num_t req_num)
{
    m_req_info_map.erase(req_num);
}

bool ac_bridge_impl::create_outgoing_access(bridge_info& info)
{
    nb_id_t out_ac_if;    
    if(!m_pHelper->ac_bridge_factory_get_outgoing_ac_if(m_bridge_content.bf_id, out_ac_if))
    {
        return throw_exeception(info.req_num, "syn call failed : ac_bridge_factory_get_outgoing_ac_if().");
    }

    container_id_t fake_container;
    fake_container.set_bridge_id(m_bridge_id);    
    access_data_t ac_data = {"outgoing_access", 0, fake_container, out_ac_if, false, true };

    request_access_id_info ac_info;
    ac_info.committer_id = info.hc_id;
    ac_info.type = NBID_TYPE_OBJECT_ACCESS;
    access_implementation::pack(ac_data, ac_info.raw_data);

    access_id_t outgoing_ac_id;
    if(!m_pHelper->ac_host_committer_request_access_id(info.hc_id, ac_info, outgoing_ac_id))
    {
        return throw_exeception(info.req_num, "syn call failed : ac_host_committer_request_access_id.");
    }

    info.outgoing_ac = outgoing_ac_id;
    return true;
}

bool ac_bridge_impl::create_root_committer(bridge_info& info)
{
    //create root committer
    root_committer_id_t rc_id;
    if(!m_pHelper->ac_id_dispenser_request_root_committer_id(rc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_root_committer_id().");
        return false;
    }

    info.rc_id = rc_id;
    return true;
}

bool ac_bridge_impl::create_center_committer(bridge_info& info)
{
    //create center committer
    center_committer_id_t cc_id;    
    if(!m_pHelper->ac_id_dispenser_request_center_committer_id(cc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_center_committer_id().");
        return false;
    }

    if(!m_pHelper->ac_root_committer_regist_center_committer(info.rc_id, cc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_root_committer_regist_center_committer().");
        return false;
    }

    if(!m_pHelper->ac_center_committer_set_root_committer(cc_id, info.rc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_center_committer_set_root_committer().");
        return false;
    }

    info.cc_id = cc_id;
    return true;
}

bool ac_bridge_impl::create_host_committer(bridge_info& info)
{
    //create host committer
    host_committer_id_t hc_id;    
    if(!m_pHelper->ac_id_dispenser_request_host_committer_id(hc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_host_committer_id().");
        return false;
    }

    if(!m_pHelper->ac_center_committer_regist_host_committer(info.cc_id, hc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_center_committer_regist_host_committer().");
        return false;
    }

    if(!m_pHelper->ac_host_committer_set_center_committer(hc_id, info.cc_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_host_committer_set_center_committer().");
        return false;
    }

    info.hc_id = hc_id;
    LOG_NOTICE("#######################" << info.hc_id.str() << "########################");
    return true;
}

bool ac_bridge_impl::create_transaction(bridge_info& info)
{
    //create transaction
    transaction_id_t trans_id;
    if(!m_pHelper->ac_id_dispenser_request_transaction_id(info.hc_id, trans_id))
    {
        throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_transaction_id().");
        return false;
    }

    info.trans_id = trans_id;
    return true;
}

bool ac_bridge_impl::trigger(call_id_t call_id, const byte_stream& input)
{
    //try to reload the access id
    std::string strval;
    if(!read_bridge_id_content(m_bridge_id, strval))
    {
        LOG_ERROR("read_bridge_id failed.");
        assert(!"read_bridge_id failed.");
        return false;
    }
    unpack(strval);
    
    //1. prepare the infomation for incoming trigger
    req_num_t req_num = generate_req_num();
    begin_incoming_trigger(req_num, call_id, input);
    bridge_info& info = m_req_info_map[req_num]; 

    //2. create the committer and transaction
    //TBD : check the return value
    create_root_committer(info);
    create_center_committer(info);
    create_host_committer(info);
    create_transaction(info);
    create_outgoing_access(info);

    //3. create bridge object
    create_bridge_object_info cbo_info = {info.hc_id, input};
    bridge_object bobj;
    if(!m_pHelper->ac_bridge_factory_create_bridge_object(m_bridge_content.bf_id, cbo_info, bobj))
    {
        return throw_exeception(info.req_num, "Asyn call failed : ac_bridge_factory_create_bridge_object().");
    }
    info.in_objs.push_back(bobj.bridge_id);

    //4. get access info
    nb_id_t access_id;    
    m_bridge_content.access_id.to_nb_id(access_id);
    node_invocation_request run_req = 
    {
        execution_id_t(),
        nb_id_t(NB_FUNC_GENERAL_GET_INTERFACE),
        info.trans_id,
        container_id_t(),
        info.hc_id,
        access_id,
        std::vector<nb_id_t>()
    };

    LOG_DEBUG("ac_bridge start execute access id = "<<m_bridge_content.access_id.str());    
    if(!m_pHelper->ac_access_run(m_bridge_content.access_id, req_num, run_req))
    {
        return throw_exeception(req_num, "Asyn call failed : ac_access_run().");
    }

    /*---------------------------------------------------------------------
      for test ac_bridge_factory_uncreate_bridge_object
      ---------------------------------------------------------------------*/
    /*
    execution_result_t exe_ret;
    exe_ret.objects.push_back(bobj.bridge_id);
    info.is_run = true;
    node_invocation_response run_res = 
    {
        info.trans_id, exe_ret, true, false
    };
    
    if(!ac_access_run_response(req_num, run_res))
    {
        return throw_exeception(req_num, "Asyn call failed : ac_access_run_response().");
    }
    */
    return true;
}

bool ac_bridge_impl::ac_access_run_response(req_num_t req_num, node_invocation_response& output)
{
	LOG_DEBUG("*** ac_bridge_impl::ac_access_run_response()");

	bridge_info& info = m_req_info_map[req_num];
	if(!output.success)
	{
        LOG_ALERT("========================== bridge rollback end ========================");
	    ac_manager::instance().remove_associated_actors(info.hc_id);
		return throw_exeception(req_num, "Asyn call failed : ac_access_run_response output failed.");
	}

	//if current transaction is end and do not need uncreate bridge object, just remove associated actors
	if(info.is_finish && output.output.objects.empty())
    {
        LOG_ALERT("========================== bridge success end =========================");
	    ac_manager::instance().remove_associated_actors(info.hc_id);
	    return true;        
	}

	if(!info.is_run)
	{
		//5. start get access decls
		nb_id_t access_id;    
		m_bridge_content.access_id.to_nb_id(access_id);
		node_invocation_request run_req = 
		{
			execution_id_t(),
			nb_id_t(NB_FUNC_INTERFACE_GET_DECLARATIONS),
			transaction_id_t(),                              //TBC: if or not need request trans_id
			container_id_t(),
			info.hc_id,
			access_id,
			std::vector<nb_id_t>()
		};

		assert(output.output.objects.size() > 0);        
		LOG_DEBUG("*** ac_bridge_impl::ac_access_run_response:if id:"<<output.output.objects[0].str());

		if(!m_pHelper->ac_object_run(output.output.objects[0], req_num, run_req))
		{
			return throw_exeception(req_num, "Asyn call failed : ac_object_run().");
		}
	}
	else
	{
        if(!info.is_no_builtin_decl)
        {
            //11. try to run more decls if it is not general decl
            duc_parser parser(m_bf_decls_info);
            parser.handle_result(info.exe_decl, output.output.objects, info, m_pHelper);
            if(!info.is_finish)
            {                
                run_access_decls(info);
            }            
        }
        else
        {
            //12. get general decl execution result, and uncreate them
            info.out_objs = output.output.objects;
            if(!output.output.objects.empty())
            {
                bridge_object out_obj = { output.output.objects[0] };
                if(!m_pHelper->ac_bridge_factory_uncreate_bridge_object(m_bridge_content.bf_id,
                                                                        req_num, out_obj))
                {
                    return throw_exeception(info.req_num, "Asyn call failed : ac_access_execute().");
                }
            }
        }
	}
    
	return true;
}

bool ac_bridge_impl::ac_object_run_response(req_num_t req_num, node_invocation_response& data)
{
    LOG_DEBUG("*** ac_bridge_impl::ac_object_run_response()");

    //6. start prepare access run decl
    bridge_info& info = m_req_info_map[req_num];
    info.is_run = true;
    if(data.output.objects.size() != 1)
    {
        LOG_ERROR("output object size is not equal 1");
    }
    
    array_data_t array_data;
    content raw_data;
    nb_id_t array_id;
    m_pHelper->ac_object_get_value_sync(data.output.objects[0], raw_data);
    obj_impl_array::unpack(raw_data, array_id, array_data);
       
    info.access_decls = array_data.objs;    

    //7. fill the decl in bridge info, including start decl and general decl
    for(std::vector<id_name_pair>::iterator it = m_bf_decls_info.start_decls.begin();
        it != m_bf_decls_info.start_decls.end(); ++it)
    {
        nb_id_vector_it iter = std::find(info.access_decls.begin(), info.access_decls.end(), it->id);
        if(iter != info.access_decls.end())
        {            
            info.access_start_decls.push_back(*iter);
            m_pHelper->ac_object_get_value_async(*iter, req_num);
        }        
    }
    nb_id_vector_it iter = std::find(info.access_decls.begin(), info.access_decls.end(),
                                     m_bf_decls_info.general_decl.id);
    if(iter != info.access_decls.end())
    {        
        info.access_general_decl = *iter;
        m_pHelper->ac_object_get_value_async(*iter, req_num);
        info.is_no_general_decl = false;
    }
    else
    {
        info.is_no_general_decl = true;
    }

    if(info.access_start_decls.empty() && info.is_no_general_decl)
    {        
        info.is_no_builtin_decl = true;
        run_access_decls(info);        
    }    
    
    return true;
}

bool ac_bridge_impl::run_access_decls(bridge_info& info)
{
    duc_parser parser(m_bf_decls_info);
    
    //9. try to run start decls
    if(info.is_start && !info.access_start_decls.empty())
    {
        //if it is start, try to call sepcail decl
        nb_id_vector input_objs;        
        parser.parser_parameter(info.access_start_decls.back(), info.in_objs,
                                input_objs, info, m_pHelper);
        parser.call_fun(m_bridge_content.access_id, info.access_start_decls.back(),
                        input_objs, info, m_pHelper);
        info.exe_decl = info.access_start_decls.back();        
        info.access_start_decls.pop_back();
        return true;
    }

    //10. try call the general decl
    nb_id_vector_it iter = std::find(info.access_decls.begin(), info.access_decls.end(),
                                     m_bf_decls_info.general_decl.id);
    if(iter != info.access_decls.end())
    {
        //if find general decl in access and never be called, call general decl
        /*
        if(info.exe_decl == m_bf_decls_info.general_decl.id)
            return true;
        */
        nb_id_vector input_objs;        
        parser.parser_parameter(m_bf_decls_info.general_decl.id, info.in_objs,
                                input_objs, info, m_pHelper);
        info.exe_decl = m_bf_decls_info.general_decl.id;
        info.is_finish = true;        
        parser.call_fun(m_bridge_content.access_id, m_bf_decls_info.general_decl.id,
                        input_objs, info, m_pHelper);
        LOG_ALERT("========================== bridge start ===============================");
    }
    else if(info.is_no_builtin_decl)
    {
        //if not builtin decl, call first decl
        nb_id_t access_id;    
        m_bridge_content.access_id.to_nb_id(access_id);

        //request child transaction
        transaction_id_t trans_id;
        if(!m_pHelper->ac_id_dispenser_request_transaction_id(info.hc_id, trans_id))
        {
            throw_exeception(info.req_num, "Syn call failed : ac_id_dispenser_request_transaction_id().");
            return false;
        }
        trans_comm_pair_t tc_pair;
        tc_pair.m_transaction_id = info.trans_id;
        tc_pair.m_host_committer_id = info.hc_id;
        if(!m_pHelper->ac_transaction_begin(trans_id, info.req_num, tc_pair))
        {
            throw_exeception(info.req_num, "Syn call failed : ac_transaction_set_parent().");
            return false;
        }
        
        node_invocation_request execution_parameter = {
                execution_id_t(),
                info.access_decls[0],     //only using the first decl
                trans_id,        
                container_id_t(),
                info.hc_id,
                info.in_objs[0],
                nb_id_vector(info.in_objs.begin() + 1, info.in_objs.end())
        };

        //Get execution_parameter from m_impl
        info.exe_decl = info.access_decls[0];
        info.is_finish = true;
        if(!m_pHelper->ac_access_run(m_bridge_content.access_id, info.req_num, execution_parameter))
        {
            return throw_exeception(info.req_num, "Asyn call failed : ac_access_run().");
        }
    }

    return true;
}

bool ac_bridge_impl::ac_bridge_factory_uncreate_bridge_object_response(req_num_t req_num, byte_stream& output)
{
    bridge_info& info = m_req_info_map[req_num];

    if(info.is_outgoing)
    {
        req_num_t out_req_num;
        if(!ac_manager::instance().get_outgoing_req_num(m_bridge_id, out_req_num))
        {
            if(!info.is_send_out_async)
            {
                //else if send_out_sync then send exception object
                nb_id_t exp_id;
                request_nb_id_info  exp_info;
                exp_info.type = NBID_TYPE_OBJECT_EXCEPTION;
                exp_info.committer_id = info.hc_id;
                if(!m_pHelper->ac_id_dispenser_request_nb_id(exp_info, exp_id))
                {
                    return throw_exeception(info.req_num, "syn call failed : ac_id_dispenser_request_nb_id().");
                }
                exp_id.set_exception_type(NB_EXCEPTION_NORMAL);
                 
                nb_id_t ret(NBID_TYPE_OBJECT_EXCEPTION);
                bool bret = m_pHelper->ac_bridge_send_out_respond(info.call_id, exp_id);
                end_outgoing_trigger(req_num);
                return bret;
                
            }
            else
            {
                //send fail, if send_out_async return false, 
                nb_id_t ret(false);
                bool bret = m_pHelper->ac_bridge_send_out_respond(info.call_id, ret);
                end_outgoing_trigger(req_num);
                return bret;
            }
        }
        else
        {
            //fill the operation Id
            std::size_t op_id = req_num;
            op_id  = htonl(op_id);
            output.data[8] = op_id & 0xff;
            output.data[9] = (op_id >> 8) & 0xff;
            output.data[10]= (op_id >> 16) & 0xff;
            output.data[11] = (op_id >> 24) & 0xff;
            
            call_id_t call_id = {0, out_req_num};
            if(m_pHelper->ac_bridge_trigger_respond(call_id, output))
            {
                bool bret = true;
                
                //send success, if send_out_async return true, else if send_out_sync do nothing
                if(!info.is_send_out_async)
                {
                    //do nothing, but just return for pass. (need receiver client data and send back to access))
                }
                else
                {
                    //return for send_out asyc
                    nb_id_t ret(true);
                    bret = m_pHelper->ac_bridge_send_out_respond(info.call_id, ret);
                    end_outgoing_trigger(req_num);
                }  
                
                return bret;
            }
            else
            {
                //send fail, if send_out_async return false, 
                bool bret = true;
                if(!info.is_send_out_async)
                {
                    //else if send_out_async then send exception object
                    nb_id_t exp_id;
                    request_nb_id_info  exp_info;
                    exp_info.type = NBID_TYPE_OBJECT_EXCEPTION;
                    exp_info.committer_id = info.hc_id;
                    if(!m_pHelper->ac_id_dispenser_request_nb_id(exp_info, exp_id))
                    {
                        return throw_exeception(info.req_num, "syn call failed : ac_id_dispenser_request_nb_id().");
                    }
                    exp_id.set_exception_type(NB_EXCEPTION_NORMAL);
                 
                    nb_id_t ret(NBID_TYPE_OBJECT_EXCEPTION);
                    bret = m_pHelper->ac_bridge_send_out_respond(info.call_id, exp_id);
                }
                else
                {
                    nb_id_t ret(false);
                    bret = m_pHelper->ac_bridge_send_out_respond(info.call_id, ret);
                }
                end_outgoing_trigger(req_num);
                return bret;
            }

            return true;
        }
    }
    else
    {
        //if current transaction is end, just remove associated actors
        if(info.is_finish)
        {
            LOG_ALERT("========================== bridge success end =========================");
            ac_manager::instance().remove_associated_actors(info.hc_id);
        }
        end_incoming_trigger(req_num);
        return m_pHelper->ac_bridge_trigger_respond(info.call_id, output);
    }
}

bool ac_bridge_impl::get_call_id(req_num_t req_num, call_id_t& call_id)
{
    std::map<req_num_t, bridge_info>::iterator it = m_req_info_map.find(req_num);

    if(it == m_req_info_map.end())
    {
        return false;
    }

    call_id = it->second.call_id;
    return true;
}

bool ac_bridge_impl::ac_object_get_value_async_response(req_num_t req_num, content& raw_data)
{
    bridge_info& info = m_req_info_map[req_num];
    info.decl_data_map.insert(std::make_pair(raw_data.object_id, raw_data));
    
    if(info.decl_data_map.size() == (info.access_start_decls.size() + (info.is_no_general_decl ? 0 : 1)))
    {
        run_access_decls(info);
    }
    return true;    
}

bool ac_bridge_impl::exception_handle(req_num_t req_num, const std::string& str)
{
    return throw_exeception(req_num, "ac_bridge exception->" + str);
}

void ac_bridge_impl::initialize(const bridge_content& bridge_content)    
{
    m_bridge_content = bridge_content;
    m_pHelper->ac_bridge_factory_get_decl_info(m_bridge_content.bf_id, m_bf_decls_info);
}

void ac_bridge_impl::initialize_with_bridge_content(const bridge_content& data)
{
    m_bridge_content = data;    
    std::string strval;
    pack(strval);
    if(!write_bridge_id_content(m_bridge_id, strval))
    {
        LOG_ERROR("write_bridge_id failed.");
        assert(!"write_bridge_id failed.");
    }
    m_pHelper->ac_bridge_factory_get_decl_info(m_bridge_content.bf_id, m_bf_decls_info);
}
    
bool ac_bridge_impl::throw_exeception(req_num_t req_num, std::string exception_string)
{
    call_id_t call_id;

    if (!get_call_id(req_num, call_id))
    {
        LOG_ERROR("Logic failed : could not get call_id.");
        return false;
    }    
    
    //just return exception string if there is exeception;
    if(!m_pHelper->exception_respond(call_id, exception_string))
    {
        //remove the info in m_impl
        end_incoming_trigger(req_num); 
        return false;
    }

    //remove the info in m_impl
    end_incoming_trigger(req_num);
    return true;
}

bool ac_bridge_impl::send_out(call_id_t call_id, const send_out_info& out_info)
{
    req_num_t req_num = generate_req_num();
    begin_outgoing_trigger(req_num, call_id, out_info);
    bridge_info& info = m_req_info_map[req_num];

    bridge_object out_obj = { out_info.obj_id };
    if(!m_pHelper->ac_bridge_factory_uncreate_bridge_object(m_bridge_content.bf_id, req_num, out_obj))
    {
        return throw_exeception(info.req_num, "Asyn call failed : ac_access_execute().");
    }
    return true;
}

bool ac_bridge_impl::client_response(call_id_t call_id, const byte_stream& input)
{
    std::size_t op_id;
    op_id = (input.data[11] << 24) | ((input.data[10] << 16) & 0xFF0000) 
        | ((input.data[9] << 8) & 0xFF00) | (input.data[8] & 0xFF);
    op_id = ntohl(op_id);
    
    req_num_t req_num = op_id;
    bridge_info& info = m_req_info_map[req_num];

    create_bridge_object_info cbo_info = {info.hc_id, input};
    bridge_object bobj;
    if(!m_pHelper->ac_bridge_factory_create_bridge_object(m_bridge_content.bf_id, cbo_info, bobj))
    {
        return throw_exeception(info.req_num, "Asyn call failed : ac_bridge_factory_create_bridge_object().");
    }
    m_pHelper->ac_bridge_send_out_respond(info.call_id, bobj.bridge_id);
    end_outgoing_trigger(req_num);
    return true;
}


// vim:set tabstop=4 shiftwidth=4 expandtab:
