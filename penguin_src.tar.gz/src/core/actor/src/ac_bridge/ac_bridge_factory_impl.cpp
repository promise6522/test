/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/
#include <boost/function.hpp>
#include <boost/bind.hpp>

//global header files
#include "stdx_json.h"
#include "duc_parser.h"

//core header files
#include "ac_global_db.h"
#include "ac_bridge/ac_bridge_factory_impl.h"
#include "ac_object/obj_impl_decl_compound.h"
#include "ac_object/obj_impl_descriptor.h"
#include "ac_object/obj_impl_exec_obj_func.h"
#include "ac_object/obj_impl_decl_expanded.h"
#include "ac_object/obj_impl_interface.h"

bool ac_bridge_factory_impl::load_bridge_factory()
{
    //Read the interfaces from DB
    std::string strval;
    if(read_bridge_factory_id(m_bf_id.str(), strval))
    {
        LOG_DEBUG("reload bridge_factory_id info from DB.");
        unpack(strval);
        dump_bridge_factory();    
        return true;
    }
    return false;    
}

bool ac_bridge_factory_impl::create_bridge_factory()
{
    host_committer_id_t hc_id;    
    m_pHelper->ac_id_dispenser_request_host_committer_id(hc_id);
    std::vector<nb_bridge_struct_desc*> bf_info;
    nb_generate_bridge_factory_info(bf_info);
    generate_bridge_factory_stuff(bf_info, hc_id);    
    save_bridge_factory();
    nb_clean_bridge_factory_info(bf_info);
    return true;    
}

bool ac_bridge_factory_impl::save_bridge_factory()
{
    std::string strval;
    pack(strval);
    if(!write_bridge_factory_id(m_bf_id.str(), strval))
    {
        LOG_ERROR("write_bridge_factory_id failed.");
        return false;
    }
    return true;    
}

bool ac_bridge_factory_impl::pack(std::string& str_value)
{
    return pack(m_bf_info_set, m_bf_decls, m_out_ac_if, m_bf_id, str_value);
}

bool ac_bridge_factory_impl::unpack(const std::string& str_value)
{
    return unpack(str_value, m_bf_id, m_bf_info_set, m_bf_decls, m_out_ac_if);
}

bool ac_bridge_factory_impl::pack(const bridge_factory_info_set& bf_info_set,
                                  const bridge_decl_info& bf_decls, const nb_id_t& out_ac_if,
                                  bridge_factory_id_t bf_id, std::string& str_value)
{
    //add the root 
    stdx::json_object bf_root;
    bf_root.insert("bf_id", new stdx::json_string(bf_id.str()));

    //for bridge declarations
    stdx::json_object* bdecls = new stdx::json_object();
    bf_root.insert("bridge_decls", bdecls);
    stdx::json_array* default_decls = new stdx::json_array();
    bdecls->insert("default_decls", default_decls);    
    for(std::vector<id_name_pair>::const_iterator it = bf_decls.default_decls.begin();
        it != bf_decls.default_decls.end(); ++it)
    {
        stdx::json_object* decl_info = new stdx::json_object();
        default_decls->push_back(decl_info);
        decl_info->insert("name", new stdx::json_string(it->name));
        decl_info->insert("id", new stdx::json_string(it->id.str()));
    }
    stdx::json_array* start_decls = new stdx::json_array();
    bdecls->insert("start_decls", start_decls);    
    for(std::vector<id_name_pair>::const_iterator it = bf_decls.start_decls.begin();
        it != bf_decls.start_decls.end(); ++it)
    {
        stdx::json_object* decl_info = new stdx::json_object();
        start_decls->push_back(decl_info);
        decl_info->insert("name", new stdx::json_string(it->name));
        decl_info->insert("id", new stdx::json_string(it->id.str()));
    }
    stdx::json_object* decl_info = new stdx::json_object();
    bdecls->insert("general_decl", decl_info);
    decl_info->insert("name", new stdx::json_string(bf_decls.general_decl.name));
    decl_info->insert("id", new stdx::json_string(bf_decls.general_decl.id.str()));

    //for bridge interface and object
    stdx::json_array* bifs = new stdx::json_array();
    bf_root.insert("bridge_infos", bifs);    
    for(bf_info_set_by_idx::iterator it = bf_info_set.get<0>().begin();
        it != bf_info_set.get<0>().end(); ++it)
    {
        //add to array
        stdx::json_object* bf_info = new(std::nothrow) stdx::json_object();
        bifs->push_back(bf_info);

        //insert bridge info
        bf_info->insert("index", new stdx::json_int(it->struct_num));
        bf_info->insert("name", new stdx::json_string(it->struct_name));        

        //insert bridge if data
        bf_info->insert("if", new stdx::json_string(it->if_id.str()));
        stdx::json_object* if_data = new(std::nothrow) stdx::json_object();
        bf_info->insert("if_data", if_data);
        if_data->insert("bf_id", new stdx::json_string(it->if_data.bf_id.str()));
        if_data->insert("data_index", new stdx::json_int(it->if_data.data_index));
        if_data->insert("external_name", new stdx::json_string(it->if_data.external_name));

        //add the sub interface
        stdx::json_array* sub_ifs = new stdx::json_array();
        if_data->insert("sub_ifs", sub_ifs);
        for(std::size_t i = 0; i < it->if_data.sub_interfaces.size(); ++i)
        {
            //insert sub bridge if
            stdx::json_object* sub_info = new(std::nothrow) stdx::json_object();
            sub_info->insert("name", new stdx::json_string(it->if_data.sub_names[i]));
            sub_info->insert("id", new stdx::json_string(it->if_data.sub_interfaces[i].str()));
            sub_ifs->push_back(sub_info);
        }

        //add the bridge interface decls        
        stdx::json_array* decls = new stdx::json_array();
        if_data->insert("decls", decls);
        for(std::size_t i = 0; i < it->if_data.decls.size(); ++i)
        {
            decls->push_back(new stdx::json_string(it->if_data.decls[i].str()));
        }

        //insert bridge object
        bf_info->insert("obj", new stdx::json_string(it->obj_id.str()));
        stdx::json_object* obj_data = new(std::nothrow) stdx::json_object();
        bf_info->insert("obj_data", obj_data);
        obj_data->insert("name", new stdx::json_string(it->obj_data.name));
        obj_data->insert("desc", new stdx::json_string(it->obj_data.descriptor.str()));
        obj_data->insert("if", new stdx::json_string(it->obj_data.interface.str()));

        stdx::json_array* sub_objs = new stdx::json_array();
        obj_data->insert("sub_objs", sub_objs);
        for(std::size_t i = 0; i < it->obj_data.subobjs.size(); ++i)
        {
            //insert sub bridge if
            stdx::json_object* sub_info = new(std::nothrow) stdx::json_object();
            sub_info->insert("name", new stdx::json_string(it->obj_data.sub_names[i]));
            sub_info->insert("id", new stdx::json_string(it->obj_data.subobjs[i].str()));
            sub_objs->push_back(sub_info);
        }
    }

    //insert the outgoing access interface
    bf_root.insert("outgoing_access_if", new stdx::json_string(out_ac_if.str()));

    str_value = bf_root.to_json_string();    
    return true;
}

bool ac_bridge_factory_impl::unpack(const std::string& str_value, bridge_factory_id_t bf_id,
                                    bridge_factory_info_set& bf_info_set, bridge_decl_info& bf_decls, nb_id_t& out_ac_if)
{
    //clear
    bf_info_set.clear();
    bf_decls.default_decls.clear();
    bf_decls.start_decls.clear();

    //start parse root
    boost::scoped_ptr<stdx::json_object> bf_root(dynamic_cast<stdx::json_object*>
                                                 (stdx::json_tokener_parse(str_value)));
    assert(bf_root);
    
    //for bridge declarations
    stdx::json_object *bdecls = dynamic_cast<stdx::json_object*>(bf_root->find("bridge_decls"));
    assert(bdecls);
    stdx::json_array *default_decls = dynamic_cast<stdx::json_array*>(bdecls->find("default_decls"));
    assert(default_decls);
    for(int i = 0; i < default_decls->size(); ++i)
    {
        stdx::json_object* decl_info = dynamic_cast<stdx::json_object*>(default_decls->at(i));        
        stdx::json_string* decl_id = dynamic_cast<stdx::json_string*>(decl_info->find("id"));
        stdx::json_string* decl_name = dynamic_cast<stdx::json_string*>(decl_info->find("name"));
        id_name_pair id_name = {decl_name->get_string(), nb_id_t(decl_id->get_string())};
        bf_decls.default_decls.push_back(id_name);        
    }
    stdx::json_array *start_decls = dynamic_cast<stdx::json_array*>(bdecls->find("start_decls"));
    assert(start_decls);
    for(int i = 0; i < start_decls->size(); ++i)
    {
        stdx::json_object* decl_info = dynamic_cast<stdx::json_object*>(start_decls->at(i));        
        stdx::json_string* decl_id = dynamic_cast<stdx::json_string*>(decl_info->find("id"));
        stdx::json_string* decl_name = dynamic_cast<stdx::json_string*>(decl_info->find("name"));
        id_name_pair id_name = {decl_name->get_string(), nb_id_t(decl_id->get_string())};
        bf_decls.start_decls.push_back(id_name);
    }
    stdx::json_object* decl_info = dynamic_cast<stdx::json_object*>(bdecls->find("general_decl"));
    stdx::json_string* decl_id = dynamic_cast<stdx::json_string*>(decl_info->find("id"));
    stdx::json_string* decl_name = dynamic_cast<stdx::json_string*>(decl_info->find("name"));
    bf_decls.general_decl.name = decl_name->get_string();
    bf_decls.general_decl.id.str(decl_id->get_string());    

    //for bridge interface and object
    stdx::json_array *bifs = dynamic_cast<stdx::json_array*>(bf_root->find("bridge_infos"));
    assert(bifs);
    for(int i = 0; i < bifs->size(); ++i)
    {
        //parse array
        stdx::json_object* bf_info = dynamic_cast<stdx::json_object*>(bifs->at(i));
        assert(bf_info);

        //parse bridge info
        int32_t struct_num = bf_info->find("index")->get_int();
        std::string struct_name = bf_info->find("name")->get_string();

        //parse bridge if data
        nb_id_t if_id;
        if_id.str(bf_info->find("if")->get_string());
        stdx::json_object* if_data = dynamic_cast<stdx::json_object*>(bf_info->find("if_data"));
        assert(if_data);
        bf_id.str(if_data->find("bf_id")->get_string());
        int32_t data_index = if_data->find("data_index")->get_int();
        std::string external_name = if_data->find("external_name")->get_string();
        stdx::json_array *sub_ifs = dynamic_cast<stdx::json_array*>(if_data->find("sub_ifs"));
        assert(sub_ifs);
        nb_id_vector sub_interfaces;
        std::vector<std::string> sub_names;
        for(int j = 0; j < sub_ifs->size(); ++j)
        {
            //parse sub interface
            stdx::json_object* sub_info = dynamic_cast<stdx::json_object*>(sub_ifs->at(j));
            assert(sub_info);
            sub_names.push_back(sub_info->find("name")->get_string());
            nb_id_t sub_if;
            sub_if.str(sub_info->find("id")->get_string());
            sub_interfaces.push_back(sub_if);
        }

        stdx::json_array *decls = dynamic_cast<stdx::json_array*>(if_data->find("decls"));
        assert(decls);
        nb_id_vector bif_decls;
        for(int j = 0; j < decls->size(); ++j)
        {
            stdx::json_string* decl_str = dynamic_cast<stdx::json_string*>(decls->at(j));
            bif_decls.push_back(nb_id_t(decl_str->get_string()));
        }
        
        bridge_interface_data_t bif_data = {bf_id, data_index, external_name,
                                            sub_interfaces, sub_names, bif_decls};

        //parse bridge object data
        nb_id_t obj_id;
        obj_id.str(bf_info->find("obj")->get_string());
        stdx::json_object* obj_data = dynamic_cast<stdx::json_object*>(bf_info->find("obj_data"));
        assert(obj_data);        
        std::string obj_name = obj_data->find("name")->get_string();
        nb_id_t descriptor;
        descriptor.str(obj_data->find("desc")->get_string());
        nb_id_t interface;
        interface.str(obj_data->find("if")->get_string());
        stdx::json_array *sub_objs = dynamic_cast<stdx::json_array*>(obj_data->find("sub_objs"));
        assert(sub_objs);
        nb_id_vector sub_objects;
        std::vector<std::string> sub_obj_names;
        for(int j = 0; j < sub_objs->size(); ++j)
        {
            //parse sub interface
            stdx::json_object* sub_info = dynamic_cast<stdx::json_object*>(sub_objs->at(j));
            assert(sub_info);
            sub_obj_names.push_back(sub_info->find("name")->get_string());
            nb_id_t sub_if;
            sub_if.str(sub_info->find("id")->get_string());
            sub_objects.push_back(sub_if);
        }
        
        bridge_data_t b_data = {obj_name, descriptor, interface, sub_objects, sub_obj_names};
        
        bf_info_set.insert(bridge_factory_info(struct_num, struct_name, if_id, bif_data, obj_id, b_data));
    }

    //parse the outgoing interface 
    stdx::json_string* ac_if = dynamic_cast<stdx::json_string*>(bf_root->find("outgoing_access_if"));
    out_ac_if.str(ac_if->get_string());

    return true;
}

void ac_bridge_factory_impl::generate_bridge_factory_stuff(
    const std::vector<nb_bridge_struct_desc*>& nb_bf_structs,
    const host_committer_id_t& hc_id)
{
    //1. generate all the bridge interface id
    for (std::vector<nb_bridge_struct_desc*>::const_iterator it = nb_bf_structs.begin();
         it != nb_bf_structs.end(); ++it)
    {
        //request bridge_interface_id 
        nb_id_t if_id;
        request_alone_nb_id_info nb_if_info = { NBID_TYPE_OBJECT_BRIDGE_INTERFACE, hc_id };
        m_pHelper->ac_id_dispenser_request_alone_nb_id(nb_if_info, if_id);

        //request bridge_object_id 
        nb_id_t obj_id;
        request_alone_nb_id_info nb_obj_info = { NBID_TYPE_OBJECT_BRIDGE, hc_id };
        m_pHelper->ac_id_dispenser_request_alone_nb_id(nb_obj_info, obj_id);

        //for multi index 
        m_bf_info_set.insert(bridge_factory_info((*it)->struct_number, (*it)->struct_name, if_id, obj_id));
    }

    //2. fill up bridge interface
    db_value bf_raw_datas;
    for (std::vector<nb_bridge_struct_desc*>::const_iterator it = nb_bf_structs.begin();
         it != nb_bf_structs.end(); ++it)
    {
        std::string name = (*it)->struct_name;
        bf_info_set_by_name::iterator iter = m_bf_info_set.get<1>().find((*it)->struct_name);
        if (iter != m_bf_info_set.get<1>().end())
        {
            //---------------------------------------------------------------------
            //   !!!!!Attention, do not modify the key in multi_index
            //---------------------------------------------------------------------
            bridge_factory_info& bf_info = const_cast<bridge_factory_info &>(*iter);
            bf_info.if_data.bf_id = m_bf_id;
            bf_info.if_data.data_index = (*it)->struct_number;
            bf_info.if_data.external_name = (*it)->struct_name;
            bf_info.obj_data.name = (*it)->struct_name;
            bf_info.obj_data.interface = bf_info.if_id;

            for (std::vector<nb_bridge_field_desc*>::iterator fd_it = (*it)->fields.begin(); 
                 fd_it != (*it)->fields.end(); ++fd_it)
            {
                //deal with bridge interface
                nb_id_t if_id;
                nb_id_t obj_id;
                generate_sub_bridge_item(*fd_it, hc_id, obj_id, if_id, bf_raw_datas);
                bf_info.if_data.sub_interfaces.push_back(if_id);
                bf_info.if_data.sub_names.push_back((*fd_it)->field_name);
                bf_info.obj_data.subobjs.push_back(obj_id);
                bf_info.obj_data.sub_names.push_back((*fd_it)->field_name);

            }

            generate_bridge_object_additional_info(hc_id, bf_info, bf_raw_datas);            
        }
        else
        {
            assert(!"could not find bridge interface id.");
        }        
    }

    //3. generate bridge factory special declarations.
    duc_parser * parser = new(std::nothrow) duc_parser(m_pHelper, m_bf_info_set, hc_id, bf_raw_datas);
    m_bf_decls = parser->get_decls();
    m_out_ac_if = parser->get_outgoing_access_if();

    //write bridge interface information to database directly
    dump_bridge_factory();    
    m_pHelper->ac_object_db_write(write_bf_init_req_num, bf_raw_datas);

    //write bridge info to media database
    //(not needed anymore)
    //duke_media_write_bridge(bf_raw_datas);

    /*
    for(size_t i =0; i < bf_raw_datas.all_objects.size(); ++i )
    {
        LOG_ERROR("write to db for "<<bf_raw_datas.all_objects[i].object_id.str());
        LOG_DEBUG("   sub ids =  "<<bf_raw_datas.all_objects[i].id_value.ids.size()
                  << " value = " << bf_raw_datas.all_objects[i].id_value.values.size());
        
        std::copy(bf_raw_datas.all_objects[i].id_value.values[0].begin(), 
                  bf_raw_datas.all_objects[i].id_value.values[0].end(), 
                  std::ostream_iterator<char>(std::cout, ""));
    }
    */

}

func_vector ac_bridge_factory_impl::generate_bridge_object_funcs(const host_committer_id_t& hc_id,
                                                                 bridge_factory_info& bf_info,
                                                                 db_value& bf_raw_datas)
{
    func_vector bobj_funcs;

    assert(bf_info.if_data.sub_interfaces.size() == bf_info.obj_data.subobjs.size());
       
    for(std::size_t i = 0; i < bf_info.if_data.sub_interfaces.size(); ++i)
    {
        func_pair_t func_pair;

        //generate set function
        func_pair.declaration_id = generate_bridge_object_set_decl(i, hc_id, bf_info, bf_raw_datas);
        bf_info.if_data.decls.push_back(func_pair.declaration_id);
        func_pair.implementation_id = generate_bridge_object_set_impl(i, func_pair.declaration_id,
                                                                      hc_id, bf_info, bf_raw_datas);
        bobj_funcs.push_back(func_pair);

        //generate get function
        func_pair.declaration_id = generate_bridge_object_get_decl(i, hc_id, bf_info, bf_raw_datas);
        bf_info.if_data.decls.push_back(func_pair.declaration_id);
        func_pair.implementation_id = generate_bridge_object_get_impl(i, func_pair.declaration_id,
                                                                      hc_id, bf_info, bf_raw_datas);
        bobj_funcs.push_back(func_pair);
    }
    
    return bobj_funcs;    
}

nb_id_t ac_bridge_factory_impl::generate_bridge_object_set_decl(std::size_t pos,
                                                                const host_committer_id_t& hc_id,
                                                                bridge_factory_info& bf_info,
                                                                db_value& bf_raw_datas)
{
    decl_compound_data_t decl_data;
    decl_data.name = "set_" + bf_info.if_data.sub_names[pos];

    ////input ports
    iport_t ip_data;
    //None object interface
    ip_data.interface = bf_info.if_id;
    decl_data.iports.push_back(ip_data);
    ip_data.interface = bf_info.if_data.sub_interfaces[pos];
    decl_data.iports.push_back(ip_data);
    
    ////output ports
    oport_t op_data;
    op_data.interface = bf_info.if_id;        
    decl_data.oports.push_back(op_data);
    
    nb_id_t decl_id;        
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;        
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
    m_pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
    decl_info.raw_data.object_id = decl_id;
    bf_raw_datas.all_objects.push_back(decl_info.raw_data);
    return decl_id;    
}

nb_id_t ac_bridge_factory_impl::generate_exec_obj_func(const host_committer_id_t& hc_id, 
                                                       const nb_id_t& decl_id, db_value& bf_raw_datas)
{
	request_nb_id_info exec_info;
    exec_info.type = NBID_TYPE_OBJECT_EXEC_OBJ_FUNC;
    exec_info.committer_id = hc_id;

	// build obj_func_data_t 
    exec_obj_func_data_t obj_func_data;
    obj_func_data.name = "obj_func";
    obj_func_data.owner = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.selected_decl = decl_id;
    obj_func_data.recoverer = nb_id_t(NBID_TYPE_OBJECT_NONE);
    obj_func_data.postcut = false;
    obj_impl_exec_obj_func::pack(obj_func_data, nb_id_t(), exec_info.raw_data);
	
	// request nb_id 
    nb_id_t exec_id;
    m_pHelper->ac_id_dispenser_request_nb_id(exec_info, exec_id);
    exec_info.raw_data.object_id = exec_id;
    bf_raw_datas.all_objects.push_back(exec_info.raw_data);
    
	return exec_id;
}

void ac_bridge_factory_impl::generate_out_path_info(exec_impl_graph_t& impl_data)
{
     // generate nodes' out_path info
    impl_data.out_paths.clear();

    impl_data.out_paths.resize(impl_data.nodes.size());

    for (size_t path_index = 0 ; path_index < impl_data.paths.size() ; ++path_index)
    {
        int from = impl_data.paths[path_index].in_node;
        if (from >= 0)  //from other nodes
            impl_data.out_paths[from].path_idxs.push_back(path_index);
    }
}

void ac_bridge_factory_impl::generate_ss_table_info(exec_impl_graph_t& impl_data,
                                                    const std::map<nb_id_t, nb_id_t>& node_decl_map,
                                                    const std::map<nb_id_t, int>& decl_inum_map)
{
    // set the start_size length
    impl_data.m_total_size = 0;
    impl_data.m_ss_length = impl_data.nodes.size() + 1;
    impl_data.mp_start_size = new exe_impl_node_t[impl_data.m_ss_length];

    for(std::size_t index = 0; index<impl_data.nodes.size(); ++index)
    {
        std::map<nb_id_t, nb_id_t>::const_iterator it = node_decl_map.find(impl_data.nodes[index]);
        assert(it != node_decl_map.end());
        nb_id_t decl_id = it->second;

        std::map<nb_id_t, int>::const_iterator iter = decl_inum_map.find(decl_id);
        assert(iter != decl_inum_map.end());
        int iport_num = iter->second;
        impl_data.m_total_size += iport_num;

        exe_impl_node_t exe_node;
        exe_node.m_start_position = index;
        exe_node.m_size = iport_num;
        exe_node.m_confirm_size = iport_num;
        impl_data.mp_start_size[exe_node.m_start_position] = exe_node;
    }

    for (int i = 1; i < impl_data.m_ss_length; ++i)
    {
        impl_data.mp_start_size[i].m_start_position 
        = impl_data.mp_start_size[i-1].m_start_position + impl_data.mp_start_size[i-1].m_size;
    }
    
    impl_data.m_io_obj_lenth = impl_data.m_total_size + impl_data.out_port_size;
}

nb_id_t ac_bridge_factory_impl::generate_bridge_object_set_impl(std::size_t pos,
                                                                const nb_id_t& decl_id,
                                                                const host_committer_id_t& hc_id,
                                                                bridge_factory_info& bf_info,
                                                                db_value& bf_raw_datas)
{
    exec_impl_graph_t graph_data;
    std::map<nb_id_t, nb_id_t> node_decl_map;
    std::map<nb_id_t, int> decl_inum_map;

    //============for func node==========
    //decompose, pos = 0
    nb_id_t node_id = generate_exec_obj_func(hc_id, bf_info.if_data.decls[1], bf_raw_datas);  
    graph_data.nodes.push_back(node_id);
    node_decl_map.insert(std::make_pair(node_id, bf_info.if_data.decls[1]));
    decl_inum_map.insert(std::make_pair(bf_info.if_data.decls[1], 1));

    //compose, pos = 1
    node_id = generate_exec_obj_func(hc_id, bf_info.if_data.decls[0], bf_raw_datas);          
    graph_data.nodes.push_back(node_id);
    node_decl_map.insert(std::make_pair(node_id, bf_info.if_data.decls[0]));
    decl_inum_map.insert(std::make_pair(bf_info.if_data.decls[0], bf_info.if_data.sub_interfaces.size()+1));

    //============for path============
    node_path_t in_comp_path     = {-1, 1, 1, pos + 1};  //from input port[1] to compose[pos + 1]
    node_path_t bobj_decomp_path = {-1, 0, 0, 0};        //from bridge object[0] to decompose[0] 
    node_path_t bobj_comp_path   = {-1, 0, 1, 0};        //from bridge object[0] to compose[0]
    node_path_t comp_out_path    = {1, 0, -3, 0};       //from compose[0] to output port[0]
    graph_data.paths.push_back(in_comp_path);    
    graph_data.paths.push_back(bobj_decomp_path);
    graph_data.paths.push_back(bobj_comp_path);
    graph_data.paths.push_back(comp_out_path);
    
    node_path_t decomp_comp_path = {0, 0, 1, 0};
    for(std::size_t i = 0; i < bf_info.if_data.sub_interfaces.size(); ++i)
    {
        if(i == pos)
        {            
            continue;
        }
        decomp_comp_path.in_port = i;
        decomp_comp_path.out_port = i + 1;        
        graph_data.paths.push_back(decomp_comp_path);
    }

    graph_data.name = "set_" + bf_info.if_data.sub_names[pos] + "_impl";
    graph_data.out_port_size = 1;
    graph_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    graph_data.external_decl = decl_id;
    graph_data.handlesException = NB_EXCEPTION_NO; 
    
    generate_out_path_info(graph_data);
    generate_ss_table_info(graph_data, node_decl_map, decl_inum_map);
    
    nb_id_t impl_id;    
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(graph_data, nb_id_t(), impl_info.raw_data);
    m_pHelper->ac_id_dispenser_request_nb_id(impl_info, impl_id);
    impl_info.raw_data.object_id = impl_id;
    bf_raw_datas.all_objects.push_back(impl_info.raw_data);
    return impl_id;    
}

nb_id_t ac_bridge_factory_impl::generate_bridge_object_get_decl(std::size_t pos,
                                                                const host_committer_id_t& hc_id,
                                                                bridge_factory_info& bf_info,
                                                                db_value& bf_raw_datas)
{
    decl_compound_data_t decl_data;
    decl_data.name = "get_" + bf_info.if_data.sub_names[pos];
    
    ////input ports
    iport_t ip_data;
    //None object interface
    ip_data.interface = bf_info.if_id;
    decl_data.iports.push_back(ip_data);

    ////output ports
    oport_t op_data;
    op_data.interface = bf_info.if_data.sub_interfaces[pos];        
    decl_data.oports.push_back(op_data);

    nb_id_t decl_id;        
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_COMPOUND;
    decl_info.committer_id = hc_id;        
    obj_impl_decl_compound::pack(decl_data, nb_id_t(), decl_info.raw_data);        
    m_pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
    decl_info.raw_data.object_id = decl_id;
    bf_raw_datas.all_objects.push_back(decl_info.raw_data);
    return decl_id;    
}

nb_id_t ac_bridge_factory_impl::generate_bridge_object_get_impl(std::size_t pos,
                                                                const nb_id_t& decl_id,
                                                                const host_committer_id_t& hc_id,
                                                                bridge_factory_info& bf_info,
                                                                db_value& bf_raw_datas)
{
    exec_impl_graph_t graph_data;
    std::map<nb_id_t, nb_id_t> node_decl_map;
    std::map<nb_id_t, int> decl_inum_map;

    //============for func node==========
    //decompose, pos = 0
    nb_id_t node_id = generate_exec_obj_func(hc_id, bf_info.if_data.decls[1], bf_raw_datas);  
    graph_data.nodes.push_back(node_id);
    node_decl_map.insert(std::make_pair(node_id, bf_info.if_data.decls[1]));
    decl_inum_map.insert(std::make_pair(bf_info.if_data.decls[1], 1));

    //============for path============
    node_path_t bobj_decomp_path = {-1, 0, 0, 0};        //from input port[0] to decompose[0] 
    node_path_t comp_out_path    = {0, pos, -3, 0};       //from decompose[0] to output port[0]
    graph_data.paths.push_back(bobj_decomp_path);
    graph_data.paths.push_back(comp_out_path);    

    graph_data.name = "get_" + bf_info.if_data.sub_names[pos] + "_impl";
    graph_data.out_port_size = 1;
    graph_data.master = nb_id_t(NBID_TYPE_OBJECT_NONE);
    graph_data.external_decl = decl_id;
    graph_data.handlesException = NB_EXCEPTION_NO; 
    
    generate_out_path_info(graph_data);
    generate_ss_table_info(graph_data, node_decl_map, decl_inum_map);
    
    nb_id_t impl_id;    
    request_nb_id_info impl_info;
    impl_info.type = NBID_TYPE_OBJECT_IMPLEMENTATION;
    impl_info.committer_id = hc_id;
    obj_impl_exec_impl::pack(graph_data, nb_id_t(), impl_info.raw_data);
    m_pHelper->ac_id_dispenser_request_nb_id(impl_info, impl_id);
    impl_info.raw_data.object_id = impl_id;
    bf_raw_datas.all_objects.push_back(impl_info.raw_data);
    return impl_id;    
}

void ac_bridge_factory_impl::generate_bridge_object_descriptor(const host_committer_id_t& hc_id,
                                                               bridge_factory_info& bf_info,
                                                               db_value& bf_raw_datas)
{
    descriptor_data_t des_data;
    des_data.name = bf_info.struct_name;
    des_data.subobj_interfaces = bf_info.if_data.sub_interfaces;
    
    //generate decl and impl for bridge object
    des_data.funcs = generate_bridge_object_funcs(hc_id, bf_info, bf_raw_datas);

    nb_id_t des_id;    
    request_nb_id_info des_info;
    des_info.type = NBID_TYPE_OBJECT_DESCRIPTOR;
    des_info.committer_id = hc_id;
    obj_impl_descriptor::pack(des_data, nb_id_t(), des_info.raw_data);    
    m_pHelper->ac_id_dispenser_request_nb_id(des_info, des_id);
    des_info.raw_data.object_id = des_id;
    bf_raw_datas.all_objects.push_back(des_info.raw_data);

    bf_info.obj_data.descriptor = des_id;
}

void ac_bridge_factory_impl::generate_bridge_object_additional_info(const host_committer_id_t& hc_id,
                                                                    bridge_factory_info& bf_info,
                                                                    db_value& bf_raw_datas)
{
    //================create bridge interface's compose and decompose decls==============
    nb_id_t comp_id, dcomp_id;
    content raw_data;

    //compose
    decl_compound_data_t comp_data;
    comp_data.name = "bridge_compose";
            
    ////in ports
    iport_t cip_data;
    cip_data.interface = bf_info.if_id;
    comp_data.iports.push_back(cip_data);
    for (size_t i = 0; i < bf_info.if_data.sub_interfaces.size(); ++i)
    {
        iport_t ip_data;
        ip_data.interface = bf_info.if_data.sub_interfaces[i];
        comp_data.iports.push_back(ip_data);
    }////output ports
    oport_t cop_data;
    cop_data.interface = bf_info.if_id;
    comp_data.oports.push_back(cop_data);

    request_nb_id_info comp_info;
    comp_info.type = NBID_TYPE_FUNCTION_BRIDGE_COMPOSE;
    comp_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(comp_data, nb_id_t(), comp_info.raw_data);
    m_pHelper->ac_id_dispenser_request_nb_id(comp_info, comp_id);
    comp_info.raw_data.object_id = comp_id;
    bf_raw_datas.all_objects.push_back(comp_info.raw_data);

    //decompose
    decl_compound_data_t dcomp_data;
    dcomp_data.name = "bridge_decompose";

    ////in ports
    iport_t dip_data;
    dip_data.interface = bf_info.if_id;
    dcomp_data.iports.push_back(dip_data);

    ////output ports
    for (size_t i = 0; i < bf_info.if_data.sub_interfaces.size(); ++i)
    {
        oport_t op_data;
        op_data.interface = bf_info.if_data.sub_interfaces[i];
        dcomp_data.oports.push_back(op_data);
    }

    request_nb_id_info dcomp_info;
    dcomp_info.type = NBID_TYPE_FUNCTION_BRIDGE_DECOMPOSE;
    dcomp_info.committer_id = hc_id;
    obj_impl_decl_compound::pack(dcomp_data, nb_id_t(), dcomp_info.raw_data);
    m_pHelper->ac_id_dispenser_request_nb_id(dcomp_info, dcomp_id);
    dcomp_info.raw_data.object_id = dcomp_id;
    bf_raw_datas.all_objects.push_back(dcomp_info.raw_data);
    
    bf_info.if_data.decls.push_back(comp_id);
    bf_info.if_data.decls.push_back(dcomp_id);

    //================create bridge object descriptor ==============
    generate_bridge_object_descriptor(hc_id, bf_info, bf_raw_datas);

    //================pack bridge object info and write to database ==============
    obj_impl_bridge_interface::pack(bf_info.if_data, bf_info.if_id, raw_data);
    bf_raw_datas.all_objects.push_back(raw_data);
    obj_impl_bridge::pack(bf_info.obj_data, bf_info.obj_id, raw_data);
    bf_raw_datas.all_objects.push_back(raw_data);
}

bool ac_bridge_factory_impl::ac_object_db_write_response(req_num_t req_num, int& output)
{
    LOG_DEBUG("Write bridge factory info to DB successful.");
    return m_pHelper->ac_object_db_commit(req_num, output);
}

bool ac_bridge_factory_impl::ac_object_db_commit_response(req_num_t req_num, bool& output)
{
    if(!output)
    {
        LOG_ERROR("Commit bridge factory info to DB fail.");
        return true;
    }    

    LOG_DEBUG("Commit bridge factory info to DB successful.");
    return m_pHelper->initialization_respond();
}

bool ac_bridge_factory_impl::generate_sub_bridge_item(nb_bridge_field_desc* fd, host_committer_id_t hc_id,
                                                      nb_id_t& obj_id, nb_id_t& if_id,
                                                      db_value& bf_raw_datas)
{
    if (fd->field_type_name == "integer")
    {
        obj_id = nb_id_t(NBID_TYPE_OBJECT_INT);
        if_id = nb_id_t(NB_INTERFACE_INT);

        if(!fd->default_value.empty())
        {            
            obj_id.set_value(boost::lexical_cast<int>(fd->default_value));
        }
    }
    else if (fd->field_type_name == "boolean")
    {
        obj_id = nb_id_t(NBID_TYPE_OBJECT_BOOL);
        if_id = nb_id_t(NB_INTERFACE_BOOL);

        if(!fd->default_value.empty())
        {            
            obj_id.set_value(fd->default_value == "true" ? true : false);
        }
    }
    else if (fd->field_type_name == "float")
    {
        obj_id = nb_id_t(NBID_TYPE_OBJECT_FLOAT);
        if_id = nb_id_t(NB_INTERFACE_FLOAT);

        if(!fd->default_value.empty())
        {            
            obj_id.set_value(boost::lexical_cast<float>(fd->default_value));
        }

    }
    else if (fd->field_type_name == "string")
    {
        if_id = nb_id_t(NB_INTERFACE_STRING);
        request_alone_nb_id_info nb_info = {NBID_TYPE_OBJECT_STRING, hc_id};
        m_pHelper->ac_id_dispenser_request_alone_nb_id(nb_info, obj_id);
        content raw_data;
        //Set empty string by default
        if(fd->default_value.empty())
        {            
            obj_impl_string::pack("", obj_id, raw_data);
        }
        else
        {
            obj_impl_string::pack(fd->default_value, obj_id, raw_data);
        }
        bf_raw_datas.all_objects.push_back(raw_data);
    }
    else if (fd->field_type_name == "byteArray")
    {
        if_id = nb_id_t(NB_INTERFACE_BYTES);
        request_alone_nb_id_info nb_info = {NBID_TYPE_OBJECT_BYTES, hc_id};
        m_pHelper->ac_id_dispenser_request_alone_nb_id(nb_info, obj_id);
        //Set empty bytes by default
        bytes_data_t bytes = {0, 0, ""};
        content raw_data;
        obj_impl_bytes::pack(bytes, obj_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);
    }
    else
    {
        bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().find(fd->field_type_name);
        if (it != m_bf_info_set.get<1>().end())
        {
            if_id = it->if_id;
            obj_id = it->obj_id;
        }
    }

    if(fd->is_array)
    {
        //fill the compound data
        if_compound_data_t ifc_data;
        //ifc_data.type = NB_INTERFACE_ARRAY_TYPE;
        generate_array_expanded_decls(if_id, hc_id, ifc_data, bf_raw_datas);
        
        if_exp_group ife;
        ife.min_if = if_id;
        ifc_data.groups.push_back(ife);

        //request compound interface id
        request_nb_id_info nb_if_info;
        nb_if_info.type = NBID_TYPE_OBJECT_INTERFACE_COMPOUND;
        nb_if_info.committer_id = hc_id;
        obj_impl_interface_compound::pack(ifc_data, nb_id_t(), nb_if_info.raw_data);
        m_pHelper->ac_id_dispenser_request_nb_id(nb_if_info, if_id);

        //Get compound data directly and prepare to wirte to disk
        content raw_data;                
        m_pHelper->ac_object_get_value_sync(if_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);

        /*
        //Get compound interface decls
        nb_id_t comp_id;        
        obj_impl_interface_compound::unpack(raw_data, comp_id, ifc_data);
        for(nb_id_vector::iterator it = ifc_data.decls.begin(); it != ifc_data.decls.end(); ++it)
        {
            m_pHelper->ac_object_get_value_sync(*it, raw_data);
            bf_raw_datas.all_objects.push_back(raw_data);            
        }
        */

        array_data_t array_data = {"", if_id, nb_id_vector()};
        request_alone_nb_id_info nb_array_info = {NBID_TYPE_OBJECT_ARRAY, hc_id};
        m_pHelper->ac_id_dispenser_request_alone_nb_id(nb_array_info, obj_id);
        obj_impl_array::pack(array_data, obj_id, raw_data);
        bf_raw_datas.all_objects.push_back(raw_data);
    }
    
    return true;    
}

void ac_bridge_factory_impl::generate_array_expanded_decls(const nb_id_t& if_id,
                                                           const host_committer_id_t& hc_id,
                                                           if_compound_data_t& ifc_data,
                                                           db_value& bf_raw_datas)
{
    request_nb_id_info decl_info;
    decl_info.type = NBID_TYPE_OBJECT_DECLARATION_EXPANDED;
    decl_info.committer_id = hc_id;

    nb_id_t decl_id;
    ifc_data.decls.clear();    

    decl_expanded_data_t decl_data;
    decl_data.expanded_ifs.push_back(if_id);

    nb_id_vector decl_ids_array;
    obj_impl_interface::get_builtin_instructions(nb_id_t(NB_INTERFACE_ARRAY), false, decl_ids_array);

    for (uint32_t i = 0; i < decl_ids_array.size(); ++i)
    {
	nb_id_t decl_id;
	obj_impl_declaration::get_instruction_name(decl_ids_array[i], decl_data.name);
	decl_data.origin_decl_id = decl_ids_array[i];
	obj_impl_decl_expanded::pack(decl_data, nb_id_t(), decl_info.raw_data);
	m_pHelper->ac_id_dispenser_request_nb_id(decl_info, decl_id);
	decl_info.raw_data.object_id = decl_id;
	ifc_data.decls.push_back(decl_id);    
	bf_raw_datas.all_objects.push_back(decl_info.raw_data);
    }

    nb_id_vector builtin_decls;
    obj_impl_interface::get_general_instructions(builtin_decls);

    for (uint32_t i = 0; i < builtin_decls.size(); ++i)
        ifc_data.decls.push_back(builtin_decls[i]);
}

nb_id_t ac_bridge_factory_impl::get_ifid_by_idx(const int32_t& index)
{
    bf_info_set_by_idx::iterator it = m_bf_info_set.get<0>().find(index);
    assert(it != m_bf_info_set.get<0>().end());
    return it->if_id;
}

nb_id_t ac_bridge_factory_impl::get_ifid_by_name(const std::string& name)
{
    bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().find(name);
    assert(it != m_bf_info_set.get<1>().end());
    return it->if_id;
}

bridge_interface_data_t ac_bridge_factory_impl::get_bif_data_by_id(const nb_id_t& bif_id)
{
    bf_info_set_by_if::iterator it = m_bf_info_set.get<2>().find(bif_id);
    assert(it != m_bf_info_set.get<2>().end());
    return it->if_data;
}

bool ac_bridge_factory_impl::create_bridge_object(const host_committer_id_t& hc_id,
                                                  UBuffer& buf, nb_id_t& obj_id)
{
    int32_t p = buf.takeInt();
    if(int32_t(STRUCT) != p) 
    {
        obj_id = nb_id_t(NBID_TYPE_OBJECT_NONE);
        return false;
    }

    int32_t idx = buf.takeInt();
    nb_id_t if_id = get_ifid_by_idx(idx);
    buf.reset();    

    try
    {
        obj_id = create_bridge_object(hc_id, if_id, buf);
        return true;
    }
    catch(create_bobj_error& ex)
    {
        LOG_ERROR(boost::diagnostic_information(ex));
        return false;
    }
}

bool ac_bridge_factory_impl::ac_object_get_value_async_response(req_num_t req_num, content& obj_cont)
{
    //-------------------------------------------
    //   !!!!!Attention, do not modify the key
    //-------------------------------------------
    //LOG_DEBUG("Get "<<obj_cont.object_id.str()<<" content");
    pack_set_by_req_num::iterator it = m_async_pack_set.get<1>().find(req_num);
    asyn_pack_bf_info& bf_info = const_cast<asyn_pack_bf_info &>(*it);
    bf_info.waiting_ids.erase(obj_cont.object_id);
    bf_info.id_cont_map.insert(std::make_pair(obj_cont.object_id, obj_cont));

    //if it is array, try to get its compond interface
    if(obj_cont.object_id.get_type() == NBID_TYPE_OBJECT_ARRAY)
    {
         array_data_t array;
         nb_id_t id;
         obj_impl_array::unpack(obj_cont, id,  array);
         assert(id == obj_cont.object_id);
         m_pHelper->ac_object_get_value_async(array.type, req_num);
         bf_info.waiting_ids.insert(array.type);
    }

    //loop to get subobject
    for(std::vector<nb_id_t>::iterator it = obj_cont.id_value.ids.begin();
        it != obj_cont.id_value.ids.end(); ++it )
    {
        nbid_type_t type = it->get_type();
        if (type == NBID_TYPE_OBJECT_BRIDGE || type == NBID_TYPE_OBJECT_STRING
            || type == NBID_TYPE_OBJECT_BYTES || type == NBID_TYPE_OBJECT_ARRAY)
        {
            m_pHelper->ac_object_get_value_async(*it, req_num);
            //LOG_DEBUG("Req "<<it->str()<<" content");
            bf_info.waiting_ids.insert(*it);
        }
    }

    //check pre uncreate completed
    if(bf_info.waiting_ids.empty())
    {
        LOG_DEBUG("============Async get sub item's value completed.===============");
        UBuffer buf;
        recur_uncreate_bridge_object(bf_info.bobj_id, bf_info, buf);        
        byte_stream stream;
        stream.data.assign(buf.data(), buf.data()+buf.size());
        m_pHelper->ac_bridge_factory_uncreate_bridge_object_respond(bf_info.call_id, stream);
    }

    LOG_DEBUG("Async waitiing item size = "<<bf_info.waiting_ids.size());

    return true;
}

void ac_bridge_factory_impl::recur_uncreate_bridge_object(const nb_id_t& obj_id,
                                                          const asyn_pack_bf_info& info, UBuffer& buf)
{
    nbid_type_t type = obj_id.get_type();

    switch(type)
    {
        case NBID_TYPE_OBJECT_BRIDGE :
        {
            bridge_data_t data;
            std::map<nb_id_t, content>::const_iterator it = info.id_cont_map.find(obj_id);
            if(it == info.id_cont_map.end())
            {
                assert(!"counld not find bridge value in map.");
            }
            nb_id_t id;
            obj_impl_bridge::unpack(it->second, id, data);
            assert(id == obj_id);
            unpack_bridge_object(data, info, buf);
            break;
        } 
        case NBID_TYPE_OBJECT_BOOL :
        {
            bool value;
            obj_id.get_value(value);
            unpack_int_object((int32_t)(value ? 1 : 0), buf);
            break;
        }
        case NBID_TYPE_OBJECT_INT :
        {
            int32_t value;
            obj_id.get_value(value);
            unpack_int_object(value, buf);
            break;
        }
        case NBID_TYPE_OBJECT_FLOAT :
        {
            float value;
            obj_id.get_value(value);
            unpack_int_object(int32_t(value * 100000), buf);
            break;
        }
        case NBID_TYPE_OBJECT_STRING :
        {
            std::string str;
            std::map<nb_id_t, content>::const_iterator it = info.id_cont_map.find(obj_id);
            if(it == info.id_cont_map.end())
            {
                assert(!"counld not find string value in map.");
            }
            nb_id_t id;
            obj_impl_string::unpack(it->second, id, str);
            assert(id == obj_id);
            unpack_string_object(str, buf);
            break;
        } 
        case NBID_TYPE_OBJECT_BYTES :
        {
            bytes_data_t bytes;
            std::map<nb_id_t, content>::const_iterator it = info.id_cont_map.find(obj_id);
            if(it == info.id_cont_map.end())
            {
                assert(!"counld not find string value in map.");
            }
            nb_id_t id;
            obj_impl_bytes::unpack(it->second, id, bytes);
            unpack_string_object(bytes.value, buf);
            break;
        }
        case NBID_TYPE_OBJECT_ARRAY :
        {
            array_data_t array;
            std::map<nb_id_t, content>::const_iterator it = info.id_cont_map.find(obj_id);
            if(it == info.id_cont_map.end())
            {
                assert(!"counld not find string value in map.");
            }
            nb_id_t id;
            obj_impl_array::unpack(it->second, id,  array);
            assert(id == obj_id);
            unpack_array_object(array, info, buf);
            break;
        }
        default :
        {
            LOG_ERROR("uncreate_bridge_object: unsupport object type.");
        }
    }
}

void ac_bridge_factory_impl::pre_uncreate_bridge_object(call_id_t call_id, const nb_id_t& obj_id)
{    
    req_num_t req_num = generate_req_num();
    m_async_pack_set.insert(asyn_pack_bf_info(obj_id, call_id, req_num));

    //----------------------------------------
    //   !!!!!Attention, do not modify the key
    //----------------------------------------
    pack_set_by_call_id::iterator it = m_async_pack_set.get<0>().find(call_id);
    asyn_pack_bf_info& bf_info = const_cast<asyn_pack_bf_info &>(*it);
    bf_info.waiting_ids.insert(obj_id);

    nbid_type_t type = obj_id.get_type();
    switch(type)
    {
        case NBID_TYPE_OBJECT_BRIDGE :
        {
            //bridge_object objbridge(data, tx);
            //pack(objbridge, tx);
            m_pHelper->ac_object_get_value_async(obj_id, req_num);
            break;
        } 
        default :
        {
            LOG_ERROR("uncreate_bridge_object: unsupport object type.");
        }
    }
}

bool ac_bridge_factory_impl::uncreate_bridge_object(call_id_t call_id, const nb_id_t& obj_id)
{    
    pre_uncreate_bridge_object(call_id, obj_id);
    return true;
}

void ac_bridge_factory_impl::unpack_string_object(std::string& str, UBuffer& buf) 
{
    buf.add((int32_t) BYTEARRAY);
    buf.add(str.size());
    buf.add((uint8_t*) str.c_str(), str.size());
}

void ac_bridge_factory_impl::unpack_int_object(int32_t d, UBuffer& buf)
{
    buf.add(d);
}

void ac_bridge_factory_impl::unpack_array_object(array_data_t& array, const asyn_pack_bf_info& info,
                                                 UBuffer& buf)
{
    //unpack compound data
    if_compound_data_t compound_data;
    std::map<nb_id_t, content>::const_iterator it = info.id_cont_map.find(array.type);
    if(it == info.id_cont_map.end())
    {
        assert(!"counld not find compound interface in map.");
    }
    nb_id_t id;
    obj_impl_interface_compound::unpack(it->second, id, compound_data);
    assert(id == array.type);

    assert(compound_data.groups.size() == 1);
    nb_id_t array_type = compound_data.groups[0].min_if;

    int32_t atype = (int32_t) STRUCTARRAY;
    if( array_type.is_interface_int() || array_type.is_interface_bool() || array_type.is_interface_float() )
    {
        atype = (int32_t) INTARRAY;
    }
    else if(array_type.is_interface_string())
    {
        atype = (int32_t) STRINGARRAY;
    }
    else
    {
        assert(array_type.is_interface_bridge());
    }

    buf.add((int32_t) atype);
    buf.add(array.objs.size());
    for(std::size_t i = 0; i < array.objs.size(); ++i)
    {
        recur_uncreate_bridge_object(array.objs[i], info, buf);
    }
}

void ac_bridge_factory_impl::unpack_bridge_object(const bridge_data_t& data,
                                                  const asyn_pack_bf_info& info, UBuffer& buf)
{
    bf_info_set_by_if::iterator it = m_bf_info_set.get<2>().find(data.interface);
    assert(it != m_bf_info_set.get<2>().end());
    
    buf.add((int32_t) STRUCT);
    buf.add(it->struct_num);
    for (std::size_t i = 0; i < data.subobjs.size(); ++i)
    {
        recur_uncreate_bridge_object(data.subobjs[i], info, buf);
    }
}

nb_id_t ac_bridge_factory_impl::pack_string_object(const host_committer_id_t& hc_id, UBuffer& buf)
{
    std::string data;
    pack(data, buf);
        
    content raw_data;
    obj_impl_string::pack(data, nb_id_t(), raw_data);
        
    request_nb_id_info info = {raw_data, NBID_TYPE_OBJECT_STRING, hc_id};
    nb_id_t str_id;
    m_pHelper->ac_host_committer_request_nb_id(hc_id, info, str_id);
    return str_id;
}

nb_id_t ac_bridge_factory_impl::pack_bytes_object(const host_committer_id_t& hc_id, UBuffer& buf)
{
    bytes_data_t data;
    pack(data.value, buf);
    
    content raw_data;
    obj_impl_bytes::pack(data, nb_id_t(), raw_data);
    
    request_nb_id_info info = {raw_data, NBID_TYPE_OBJECT_BYTES, hc_id};
    nb_id_t bytes_id;
    m_pHelper->ac_host_committer_request_nb_id(hc_id, info, bytes_id);
    return bytes_id;    
}

nb_id_t ac_bridge_factory_impl::pack_builtin_object(const host_committer_id_t& hc_id, 
                                                    const nb_id_t& if_id, UBuffer& buf)
{
    int32_t value = buf.takeInt();
    if (if_id.is_interface_float())
    {
        nb_id_t temp(NBID_TYPE_OBJECT_FLOAT);
        float fvalue =  value * 0.00001;
        temp.set_value(fvalue);
        return temp;
    }
    else if (if_id.is_interface_int()) 
    {
        nb_id_t temp(NBID_TYPE_OBJECT_INT);
        temp.set_value(value);
        return temp;
    }
    else if (if_id.is_interface_bool()) 
    {
        nb_id_t temp(NBID_TYPE_OBJECT_BOOL);
        temp.set_value(value);
        return temp;
    }
    else
    {
        nb_id_t temp(NBID_TYPE_NULL);
        return  temp;
    }
}

nb_id_t ac_bridge_factory_impl::pack_array_object(const host_committer_id_t& hc_id, 
                                                      const nb_id_t& if_id, UBuffer& buf)
{
    array_data_t data;
    //data.interface = nb_id_t(NB_INTERFACE_ARRAY);
    data.type = if_id;
    int32_t array_type = buf.takeInt();
    int32_t array_size = buf.takeInt();

    switch(array_type)
    {
        case STRUCTARRAY :
        {
            for (int i = 0; i < array_size; ++i)
            {
                data.objs.push_back(pack_bridge_object(hc_id, buf));
            }
            break;
        }
        case STRINGARRAY :
        {
            /*
            for (int i = 0; i < array_size; ++i)
            {
                nb_id_t str_if(NB_INTERFACE_STRING);
                subobjs.push_back(create_bridge_object(hc_id, str_if, buf));
            }
            */
            assert(!"it should not be exist.") ;

            break;
        }
        case INTARRAY :
        {
            nb_id_t int_if(NB_INTERFACE_INT);                
            for (int i = 0; i < array_size; ++i)
            {
                data.objs.push_back(pack_builtin_object(hc_id, int_if, buf));
            }

            break;
        }
        default:
        {
            LOG_ERROR("unknow bridge array type.");
            throw create_bobj_error() << bidx_err_info(array_type);
        }
    }

    content raw_data;
    obj_impl_array::pack(data, nb_id_t(), raw_data);
    
    request_nb_id_info info = {raw_data, NBID_TYPE_OBJECT_ARRAY, hc_id};
    nb_id_t array_id;
    m_pHelper->ac_host_committer_request_nb_id(hc_id, info, array_id);
    return array_id;
}

nb_id_t ac_bridge_factory_impl::pack_bridge_object(const host_committer_id_t& hc_id, UBuffer& buf)
{
    //1. check the type
    int32_t l = check_type(STRUCT, buf);
    nb_id_t if_id = get_ifid_by_idx(l);

    //2. create the sub object id recursively
    bf_info_set_by_if::iterator it = m_bf_info_set.get<2>().find(if_id);
    std::size_t sub_obj_num = it->if_data.sub_interfaces.size();
    nb_id_vector sub_objs;
    for (std::size_t i = 0; i < sub_obj_num; ++i) 
    {
        nb_id_t obj_id = create_bridge_object(hc_id, it->if_data.sub_interfaces[i], buf);
        sub_objs.push_back(obj_id);
    }

    //3. create obj id
    bridge_data_t data;
    data.interface = it->if_id;
    data.subobjs = sub_objs;
    data.name = it->if_data.external_name;
    data.sub_names = it->if_data.sub_names;
    data.descriptor = it->obj_data.descriptor;    

    content raw_data;
    obj_impl_bridge::pack(data, nb_id_t(), raw_data);
        
    request_nb_id_info info = {raw_data, NBID_TYPE_OBJECT_BRIDGE, hc_id};
    nb_id_t obj_id;
    m_pHelper->ac_host_committer_request_nb_id(hc_id, info, obj_id);
    return obj_id;
}

void ac_bridge_factory_impl::pack(std::string& d, UBuffer& buf) 
{
    int32_t l = check_type(BYTEARRAY, buf);
    d.assign((char*) buf.takeBytes(l), l);
}

int32_t ac_bridge_factory_impl::check_type(PACKTYPE t, UBuffer& buf) 
{
    PACKTYPE x = (PACKTYPE) buf.takeInt();
    if (t != x) 
    {
        throw create_bobj_error() << bidx_err_info(x);
        return -1;
    }
    return buf.takeInt();
}

nb_id_t ac_bridge_factory_impl::create_bridge_object(const host_committer_id_t& hc_id, 
                                                     const nb_id_t& if_id, UBuffer& buf)
{
    try
    {
        if (if_id.is_interface_bridge()) 
        {
            return pack_bridge_object(hc_id, buf);
        } 
        else if (if_id.is_interface_string()) 
        {
            return pack_string_object(hc_id, buf);
        } 
        else if (if_id.is_interface_bytes()) 
        {
            return pack_string_object(hc_id, buf);
        } 
        else if (if_id.is_compound_interface()) 
        {
            return pack_array_object(hc_id, if_id, buf);
        } 
        else 
        {
            return pack_builtin_object(hc_id, if_id, buf);
        }
    }
    catch(boost::exception& ex)
    {
        ex << bif_err_info(if_id.str());
        throw;
    }
}

bridge_decl_info ac_bridge_factory_impl::get_bf_decl_info()
{
    return m_bf_decls;
}

nb_id_t ac_bridge_factory_impl::get_outgoing_ac_if()
{
    return m_out_ac_if;
}

void ac_bridge_factory_impl::dump_bridge_factory()
{
    LOG_DEBUG("=================================================================");
    LOG_DEBUG("------------------dump bridge factory's interface info--------------");
    for(bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().begin(); 
        it != m_bf_info_set.get<1>().end(); ++it)
    {
        const bridge_factory_info& bf_info = (*it);
        LOG_DEBUG("if_id: "<<bf_info.if_id.str()<<std::setw(4)<<std::setfill(' ')
                 <<bf_info.if_data.data_index <<" "<<bf_info.if_data.external_name);

        for(std::size_t i = 0; i < bf_info.if_data.sub_interfaces.size(); ++i)
        {
            LOG_DEBUG("       "<< bf_info.if_data.sub_interfaces[i].str()
                     <<"       "<< bf_info.if_data.sub_names[i]);
        }
        LOG_DEBUG("       decl :");
        for(std::size_t i = 0; i < bf_info.if_data.decls.size(); ++i)
        {
            LOG_DEBUG("       "<< bf_info.if_data.decls[i].str());
        }
        LOG_DEBUG("");
    }
    
    LOG_DEBUG("------------------dump bridge factory's object info--------------");
    for(bf_info_set_by_name::iterator it = m_bf_info_set.get<1>().begin(); 
        it != m_bf_info_set.get<1>().end(); ++it)
    {
        const bridge_factory_info& bf_info = (*it);
        LOG_DEBUG("obj_id: "<<bf_info.obj_id.str()<<std::setw(4)<<std::setfill(' ')
                 <<bf_info.if_data.data_index <<" "<<bf_info.if_data.external_name);
        
        for(std::size_t i = 0; i < bf_info.obj_data.subobjs.size(); ++i)
        {
            LOG_DEBUG("        "<< bf_info.obj_data.subobjs[i].str()
                     <<"        "<< bf_info.obj_data.sub_names[i]);
        }
        LOG_DEBUG("");
    }

    LOG_DEBUG("-------------------dump bridge factory's decl info--------------");
    for(std::vector<id_name_pair>::iterator it = m_bf_decls.default_decls.begin();
        it != m_bf_decls.default_decls.end(); ++it)
    {
        LOG_DEBUG("Default decl_id: "<<it->id.str()<<"    name: "<<it->name);
    }
    for(std::vector<id_name_pair>::iterator it = m_bf_decls.start_decls.begin(); it != m_bf_decls.start_decls.end(); ++it)
    {
        LOG_DEBUG("Start   decl_id: "<<it->id.str()<<"    name: "<<it->name);
    }
    LOG_DEBUG("general decl_id: "<<m_bf_decls.general_decl.id.str()<<"    name: "
             <<m_bf_decls.general_decl.name);
    LOG_DEBUG("outgoing access if id: "<<m_out_ac_if.str());

    LOG_DEBUG("=================================================================");
}
