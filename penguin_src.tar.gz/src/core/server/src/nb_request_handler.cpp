/**************************************************************************
**
** 	Copyright 2010 Duke Inc.
**
**************************************************************************/

#include <iostream>

#include "duc.h"
#include "ac_manager.h"
#include "ac_global_db.h"

#include "nb_request_handler.h"
#include "ac_id_dispenser.h"
#include "nb_user_manager.h"
#include <boost/asio/error.hpp>

nb_request_handler::nb_request_handler(nb_response_callback asyn_write)
    : m_is_connected(false), m_is_exception(false),
      m_asyn_write(asyn_write), m_req_num(ac_manager::instance().generate_req_num())
{
}

nb_request_handler::~nb_request_handler()
{
}

void nb_request_handler::handle_exception(const boost::system::error_code& e)
{
    m_is_exception = true;
    if(e == boost::asio::error::eof)
    {
        LOG_NOTICE("user "<<m_user_name<<" logout.");
    }
    else
    {
        LOG_ERROR("nb_request_handler::handle_exception socket error code: "<<e.value()<<"("<<e.message()<<")");
    }

    if(e != boost::asio::error::operation_aborted)
    {
        ac_manager::instance().unregister_outside_response(m_req_num, m_bridge_id);
    }
}

void nb_request_handler::handle_request(const std::vector<char>& inbound_data)
{   
    if(m_is_connected)
    {
        UBuffer ubuf((uint8_t *)(&inbound_data[0]), inbound_data.size());
        Unpacker unpacker(ubuf);
        DUCData * pDucData = unpacker.getData();
        
        TInformServer* pInformServerData = dynamic_cast<TInformServer *>(pDucData);
        if(pInformServerData)
        {
            send_request_to_ac(inbound_data, m_req_num, e_ac_bridge_trigger);
        }
        else
        {
            //TBD: parser req_num in data
            send_request_to_ac(inbound_data, m_req_num, e_ac_bridge_client_response);
        }
    }
    else
    {        
        UBuffer ubuf((uint8_t *)(&inbound_data[0]), inbound_data.size());
        Unpacker unpacker(ubuf);
        DUCData * pDucData = unpacker.getData();
        TInformServer* pInformServerData = dynamic_cast<TInformServer *>(pDucData);
        if (NULL ==  pInformServerData)
            return;

        const TGesture& rGesture = pInformServerData->gesture;        
        if (rGesture.type == Start) 
        {
            std::size_t sep = rGesture.text.find_first_of(default_user_pwd_separator);
            std::string user_name = rGesture.text;
            std::string password;
            if(sep != std::string::npos)
            {                
                user_name = rGesture.text.substr(0, sep);
                password = rGesture.text.substr(sep, rGesture.text.size());
            }
            
            //if there is prefix '$' before user name, it means is_mode
            bool is_mode = false;
            if((!user_name.empty()) && (user_name[0] == default_is_mode_prefix))
            {
                is_mode = true;
                user_name.erase(0, 1);                
            }
            LOG_DEBUG("User "<<user_name<<" Login.");

            //try to get bridge_id from database
            if(!nb_user_manager::instance().get_bridge_by_user(user_name, is_mode, m_bridge_id))
            {
                LOG_DEBUG("read_user_content failed, start to create bridge_id for "<<user_name);
                nb_user_manager::instance().create_user(user_name, "");
                if(!nb_user_manager::instance().get_bridge_by_user(user_name, is_mode, m_bridge_id))
                {
                    LOG_DEBUG("read_user_content failed twice, return for user "<<user_name);
                    return;
                }
            }

            ac_manager::instance().register_outside_response(m_req_num, m_bridge_id,
                            boost::bind(&nb_request_handler::handle_response, shared_from_this(), _1));

            send_request_to_ac(inbound_data, m_req_num, e_ac_bridge_trigger);
            m_is_connected = true;
            m_user_name = user_name;
        }         
    }
}

void nb_request_handler::handle_response(const std::vector<char>& outbound_data)
{
    /*
    LOG_DEBUG("-------------------send data to client------------------------------");
    UBuffer buf((uint8_t *)(&outbound_data[0]), outbound_data.size());
    buf.printData();

    LOG_DEBUG("nb_request_handler::handle_response: start asyn write, size="<<outbound_data.size());
    {
        LOG_DEBUG("------------------------dump outgoing xml---------------------------");
        UBuffer buf((uint8_t *)(&outbound_data[0]), outbound_data.size());
        Unpacker unpacker(buf);
        XPacker p(&std::cout);
        p.pack("informServer", unpacker.getData());
        LOG_DEBUG("--------------------------------------------------------------------");
        buf.printData();
    }
    */
    if(m_is_exception)
    {
        LOG_ERROR("Connection Exception, do not send the data");
        return;
    }
    
    try
    {
        m_asyn_write(outbound_data);
    }
    catch(...)
    {
        LOG_DEBUG("missing the connnection!");        
    }    
}

void nb_request_handler::send_request_to_ac(const std::vector<char>& inbound_data, const req_num_t& req_num, ac_method_t method)
{
    ac_id_t dest_id;

    if(!ac_manager::instance().request_actor(m_bridge_id))
        return;
    
    if(!ac_manager::instance().get_ac_id(m_bridge_id, dest_id))
    {
        assert(!"Could not find the ac_id by bridge_id");
        return;
    }
    
    byte_stream* pData = ac_memory_alloctor<byte_stream>::instance().allocate();
    pData->data = inbound_data;
    ac_manager::instance().send_asyn_message(dest_id, g_ac_framework_acid,
                                             req_num, method, pData);
}
